# GoldBot — Source & Evidence Traceability (تطبیق ادعاها با سورس، گزارش‌ها و شواهد واقعی)

**تاریخ:** 2026-11-24 · **نقش:** ممیز مستقل — Phase 1 (احراز ورودی‌ها)، Phase 5 (تطبیق سورس)، Phase 6 (شواهد و آزمایش‌ها)
**قاعدهٔ حاکم:** «اگر سورس در دسترس نیست، وضعیت تمام ادعاهای مربوط به کد `NOT VERIFIED` است» · «از روی نام فایل/مستندات دربارهٔ عملکرد واقعی کد نتیجه‌گیری قطعی نکن» · «هرگز نتیجهٔ بررسی ایستا یا DDL In-Memory را تست کامل پروژه گزارش نکن».

---

## بخش ۱ — Phase 1: احراز ورودی‌ها

### ۱.۱ ورودی‌های موجود در Workspace این جلسه (فهرست کامل + Hash محاسبه‌شده)

| # | نام فایل | مسیر | حجم | SHA-256 (محاسبه‌شده در این جلسه) | نسخه/تاریخ | دسترسی | تمامیت | ارتباط |
|---|---|---|---:|---|---|---|---|---|
| 1 | `GoldBot_CONSOLIDATED_REMEDIATION_PLAN_v2.md` | `uploads/` | 41,222 B | `73604797c6685c477302a36e4a067c12540fafc8eb040bb1d4416fe7cae727e2` | v2.0 (بدون تاریخ درون‌متنی؛ Change Log: نسخهٔ کنترل‌شده) | **FOUND_AND_VERIFIED** | کامل (۳۰۸+۱ خط، سند جایی نمی‌پرد) | سند مرجع تکمیلی تطبیق |
| 2 | `GoldBot_CONSOLIDATED_REMEDIATION_PLAN_v3_1_1.md` | `uploads/` | 133,066 B | `62a05c27bb60ff002bd808ee69f0a25040b1d5203c767ee7153298e91ecdc72d` | 3.1.1 — 2026-11-23 | **FOUND_AND_VERIFIED** | کامل (۱۴۳۳+۱ خط)؛ **Hash با مقدار اعلام‌شده درون گزارش اعتبارسنجی (بخش ۱) دقیقاً یکسان است — کنترل متقاطع مثبت** | سند مرجع اصلی |
| 3 | `GoldBot_v3_1_vs_v3_1_1_Clause_by_Clause_Traceability.md` | `uploads/` | 22,538 B | `5197ca4307d4602570d8c48e81e6332042d347f873e2affd99fdb6aa894aef0c` | 2026-11-23 | **FOUND_AND_VERIFIED** | کامل؛ **Hash نیز با مقدار اعلامی گزارش اعتبارسنجی یکسان — کنترل متقاطع مثبت** | گزارش تطبیق v3.1↔v3.1.1 (ورودی مأموریت #5) |
| 4 | `GoldBot_v3_1_1_Final_Validation_Report.md` | `uploads/` | 21,490 B | `45fc442bf2d09663f9488b3ff406926a8bf2aefd305cbeab51a789c2577aa1ba` | 2026-11-23 | **FOUND_AND_VERIFIED** | کامل (۱۹۲+۱ خط) | گزارش اعتبارسنجی v3.1.1 (ورودی مأموریت #7) |

### ۱.۲ ورودی‌های اعلامیِ مأموریت که موجود نیستند

| # | ورودی مأموریت | وضعیت | شواهد/ملاحظات |
|---|---|---|---|
| ۱ | سورس اصلی `GoldBot_Final_Release_v8.2.5.zip` (SHA-256 مرجع اعلامی `3baed37d…d930fc7`) | **`NOT_FOUND_IN_WORKSPACE`** + لینک جایگزین GitHub: **`NOT_ACCESSIBLE`** | جستجوی کل Workspace: هیچ ZIP/سورسی نیست. لینک اعلامی `github.com/hamesh5960-oss/GoldBot2/...GoldBot_v8_2_5_Engineering_RC.zip` در این جلسه بررسی شد: صفحهٔ repo (HTML) = **404**، GitHub API `repos/…` = **404**، `raw` = **404** (فایل دانلودشده HTML 404 بود — نه ZIP). نکته: نام فایل لینک (`…Engineering_RC.zip`) با نام Baseline رسمی (`…Final_Release_v8.2.5.zip`) یکی نیست. **توجه: سند v3.1.1 §2 خودش این 404 را قبلاً ثبت کرده — تأیید مستقل این جلسه با آن منطبق است.** E-BASE-01 باز می‌ماند. |
| ۲ | سند `GoldBot_CONSOLIDATED_REMEDIATION_PLAN_v1.md` | **`REFERENCED_BUT_MISSING`** | ارجاع‌ها: v2 §2 و §17 (ارقام v1 قابل اعتبارسنجی نیست) |
| ۳ | نسخهٔ FROZEN `GoldBot_CONSOLIDATED_REMEDIATION_PLAN_v3_1_FROZEN.md` | **`REFERENCED_BUT_MISSING`** | Hash گزارش‌شده (توسط دو ورودی موجود — منطبق با هم): `29a96b75b648b580217b2fa73e6b4b90a98832538869ed1f963d08db6950ac50` — **قابل تأیید نیست بدون فایل**. شمارش‌های «۸۷ بند / بخش‌های ۲۰–۸ / دلتا +۱۶۵/−۱۰۶» فقط بر اساس آن فایل قابل بازتولیدند ⇒ NOT VERIFIED |
| ۴ | `GoldBot_v3_vs_v3_1_Clause_by_Clause_Traceability_FROZEN.md` | **`REFERENCED_BUT_MISSING`** | Hash گزارش‌شده (توسط دو ورودی موجود — منطبق): `9251e2b355ab74ece13abd180ae5d432874f05cd9f1461809a0011b2c7fe05b6` |
| ۵ | گزارش تطبیق v3.1 ↔ v3.1.1 | **`FOUND_AND_VERIFIED`** | = ورودی #3 |
| ۶ | گزارش اعتبارسنجی v2.0 | **`NOT_FOUND_IN_WORKSPACE`** | هیچ فایلی با این نام/مضمون در Workspace نیست؛ خود v2.0 هم ادعا نمی‌کند چنین گزارشی دارد. **وضعیت اعتبارسنجی v2.0: NOT PROVIDED** |
| ۷ | گزارش اعتبارسنجی v3.1.1 | **`FOUND_AND_VERIFIED`** | = ورودی #4 |
| ۸ | گزارش‌های ممیزی معماری و Dual Engine | **`NOT_FOUND_IN_WORKSPACE`** | هیچ فایل ممیزی مستقلی در کار نیست؛ تنها ارجاع پراکنده به Dual Engine در v3.1.1 (خارج از دامنه/ممنوع — §24/Future) و غیاب کامل آن در v2.0. **هرگونه ادعای «ممیزی Dual Engine»: NOT PROVIDED** |
| ۹ | برنامه‌های آزمون و **خروجی واقعی تست‌ها** | **`NOT_FOUND_IN_WORKSPACE`** | برنامه‌ها داخل دو سند هستند (v2: T01..T21 · v3.1.1: T-01..T-36+6). **خروجی خام: هیچ فایلی** — حتی برای ۹ تست اجرای ادعایی v3.1.1 (6 FAIL/3 PARTIAL) |
| ۱۰ | فایل‌های شواهد (Ownership/Reconciliation/Idempotency/انتقال VPS و `evidence/P00..P11`، `evidence/P02..P09`) | **`NOT_FOUND_IN_WORKSPACE`** | به‌جز DDL خروجی ثبت‌شده در گزارش اعتبارسنجی (که متن آن در ورودی #4 آمده)، هیچ artefact خامی نیست |

### ۱.۳ سایر مراجع مفقود که در ورودی‌های موجود شناسایی شدند

| فایل مرجع | محل ارجاع | وضعیت |
|---|---|---|
| `GoldBot_CONSOLIDATED_REMEDIATION_PLAN_v3.md` (v3.0) | v3.1.1 §2 («در متن درج‌شده در دسترس بود») | `NOT_FOUND_IN_WORKSPACE` (E-DOC-01) |
| `GoldBot_v2_vs_v3_Clause_by_Clause_Traceability.md` | v3.1.1 §2 — خود سند آن را «موجود نبود؛ UNRESOLVED» اعلام کرده | `REFERENCED_BUT_MISSING` |
| `GoldBot_v3_Final_Validation_Report.md` | v3.1.1 §2 — «موجود نبود؛ UNRESOLVED» | `REFERENCED_BUT_MISSING` |
| `GoldBot_v3_1_Final_Validation_Report.md` | گزارش اعتبارسنجی v3.1.1 بخش ۱ («خوانده شد») | `REFERENCED_BUT_MISSING` (Hash هم اعلام نشده) |
| `GoldBot_v3_1_FREEZE_MANIFEST.md` | گزارش اعتبارسنجی v3.1.1 بخش ۱ («موجود» در زمان خودش) | `REFERENCED_BUT_MISSING` |
| `GoldBot_REQUIREMENTS_AND_TEST_MATRIX_v3.csv` (۲۰ REQ + ۳۶ TEST + ۳ DEFERRED) | v2 نمی‌شناسد؛ v3.1.1 §16/§2 — «فقط خلاصهٔ عددی در دسترس» | `NOT_FOUND_IN_WORKSPACE` — **NOT PROVIDED** (خود سند هم ساخته/ویرایش نکرده) |
| `KNOWN-ISSUES.md` (بند ۱ — PF 0.95) | v3.1.1 F-22/R-11 | `REFERENCED_BUT_MISSING` |
| فایل‌های سورس ادعاشده: `runtime/live.py`، `scripts/start_live.ps1`، `adapters/mt5_broker.py`، `app/…`، `evidence/*` | هر دو سند | `NOT_ACCESSIBLE` (بخش ۲) |

---

## بخش ۲ — Phase 5: تطبیق ادعاها با سورس واقعی

### ۲.۱ اقدامات انجام‌شده برای دستیابی به سورس

| # | اقدام | نتیجه |
|---|---|---|
| 1 | جستجوی کل Workspace برای ZIP/ سورس/ `*.py` | هیچ فایلی یافت نشد |
| 2 | `GET https://github.com/hamesh5960-oss/GoldBot2/blob/main/GoldBot_v8_2_5_Engineering_RC.zip` (با `raw` ریدایرکت) | **HTTP 404** — پاسخ HTML صفحهٔ 404 بود (نه ZIP) |
| 3 | `GET https://api.github.com/repos/hamesh5960-oss/GoldBot2` | **HTTP 404** `{"message":"Not Found"}` |
| 4 | `GET https://api.github.com/repos/hamesh5960-oss/GoldBot2/contents/` | **HTTP 404** |
| 5 | مقایسهٔ نتیجه با ادعای سند v3.1.1 §2 («404 — قابل دریافت نیست») | **منطبق** — دو بررسی مستقل، یک نتیجه |

**نتیجهٔ Phase 5:** آرشیو استخراج نشد (چون وجود نداشت)؛ ساختار واقعی پروژه، مسیر اجرای Runtime و رفتار کد **قابل پیگیری نیست**. طبق قاعدهٔ مأموریت:

> **وضعیت کل ادعاهای سورسی هر دو سند در این ممیزی: `NOT VERIFIED`.**

### ۲.۲ جدول ادعاهای کلیدی کدی + محل ادعایی + وضعیت

(ستون «محل ادعاشده» = آن‌چه سند ادعا می‌کند؛ **تأیید نشده** است.)

| ادعا | مبدأ سند | محل ادعاشده | وضعیت در این ممیزی |
|---|---|---|---|
| ترتیب: ساخت `MT5Broker` (خط ۲۱۵) و `connect()` (۲۲۴) پیش از `build_components()` (۳۱۴)؛ پایان `disconnect()` در ۳۹۸؛ `live.py` = ۳۹۷ خط | v3.1.1 F-03/§9.3 (+v2 §11 به‌صورت REPORTED) | `runtime/live.py:215,224,314,398` | `NOT VERIFIED` (v2 صادقانه REPORTED نامیده؛ v3.1.1 برچسب VERIFIED باقی‌مانده دارد — CF-11) |
| قفل OS در Launcher: `FileShare::None` روی `var/live.lock`، exit 3، گارد `Get-CimInstance` (check-then-act) | v3.1.1 §1.3/F-02 | `scripts/start_live.ps1:19-48,64-77` | `NOT VERIFIED` |
| Magic = `crc32(slot, magic_base)`؛ باند ۱۳_۰۰۰_۰۰۰… | v3.1.1 F-04 | `app/ids.py:19-31` | `NOT VERIFIED` |
| `adopt_foreign_magic` پیش‌فرض `True` | v3.1.1 F-05 | `position_manager.py:358,381` | `NOT VERIFIED` |
| مالکیت پوزیشن در dict درون‌Process | v3.1.1 F-06 | `position_manager.py:415` | `NOT VERIFIED` |
| کلید idempotency حاوی `run_id`؛ `run_id=uuid4().hex[:8]` | v3.1.1 F-07/§11.1 | `order_coordinator.py:277` · `bootstrap.py:244` | `NOT VERIFIED` (شاهد ادعاشده `evidence/P05` مفقود) |
| `OrderState` درون‌حافظه؛ پس از Restart خالی | v3.1.1 F-08 | `order_coordinator.py:40` + `evidence/P02` | `NOT VERIFIED` (شاهد مفقود) |
| Ledger بروکر dict درون‌حافظه، prune 120s | v3.1.1 F-09/§11.5 | `mt5_broker.py:906` (`close_dedupe_s=120.0`) | `NOT VERIFIED` |
| Reconciler فقط `positions()` می‌خواند | v3.1.1 F-10/§12.2 | `reconciler.py:43` | `NOT VERIFIED` |
| Cancel رد‌شده هم `RETCODE_CANCELED` برمی‌گرداند | v3.1.1 F-11/§12.4 | `mt5_broker.py:816-823` + `evidence/P07` | `NOT VERIFIED` (شاهد مفقود) |
| `modify` کلید idempotency را نادیده می‌گیرد؛ دو نوشتن مخالف موفق | v3.1.1 F-12 | `mt5_broker.py:859-880` + `evidence/P08` | `NOT VERIFIED` |
| سایت‌های `order_send`: ۷۰۵/۸۳۰/۸۷۵ | v3.1.1 P1-4/§23 P01 | `mt5_broker.py:705,830,875` | `NOT VERIFIED` |
| Endpointهای adapter: `orders():452`, `positions():446`, `deals():478`, `history_orders_get():562`, `history_deals_get():483/1138` — «همه از قبل موجودند (VERIFIED)» | v3.1.1 §12.1 | `adapters/mt5_broker.py` | `NOT VERIFIED` (و برچسب VERATED با CF-11 — CF-11) |
| `check_state()` فقط `risk_state == NORMAL` را می‌سنجد | v3.1.1 F-13/§14.4 | `risk/checks.py:11-13` | `NOT VERIFIED` |
| `acknowledge()` با سفارش نامعلوم ورود را باز کرد | v3.1.1 F-14 | `evidence/P04` | `NOT VERIFIED` (شاهد مفقود) |
| KILLED با `auto_clear=True` فعال می‌شود خلاف کامنت | v3.1.1 F-15/§14.5 | `risk_engine.py:300-306` vs `:242-244` | `NOT VERIFIED` |
| `_flatten` روی همهٔ Ticketها حرکت می‌کند | v3.1.1 F-17 | `engine.py:1914-1930` | `NOT VERIFIED` |
| دو Partial Close ۰٫۵، یک پوزیشن ۱٫۰ را کامل بست | v3.1.1 F-18 | `evidence/P08` | `NOT VERIFIED` (شاهد مفقود) |
| دو نویسندهٔ هم‌زمان هر دو exit 0 (A=20/B=20) | v3.1.1 F-01 | `evidence/P09` | `NOT VERIFIED` (شاهد مفقود) |
| `state_db_path` در ۲۰۱؛ بررسی فایل state با `return 2` | v3.1.1 §9.3 | `runtime/live.py:201-209` | `NOT VERIFIED` |
| محل State DB: `GOLDBOT_STATE_DB` > آرگومان > همسایهٔ ژورنال | v3.1.1 §15.1 | `bootstrap.py:390` | `NOT VERIFIED` |
| `journal_mode=WAL:151` · `synchronous=FULL:153` · `append(..., fsync=True)` · Migration افزایشی با `PRAGMA table_info` | v3.1.1 §15.1 | `adapters/sqlite_store.py:151,153` (۵۵۰ خط) | `NOT VERIFIED` |
| State Store تک‌ردیفی `risk_state` (۹۳ خط) | v3.1.1 §15.1 | `adapters/sqlite_state_store.py:33,35` | `NOT VERIFIED` |
| نبود هویت Deployment/Instance در Config/Source (grep ⇒ ۰) | v3.1.1 F-16 | فهرست فایل‌ها | `NOT VERIFIED` |
| سایت‌های نوشتن/رخدادها: `heartbeat.py:153` · `health.py:238` · `web/app.py:564` | v3.1.1 F-19 | `app/*`, `web/app.py` | `NOT VERIFIED` |
| ساختار سورس: ۱۹۱ فایل `.py`، ۴۱٬۷۶۵ خط، ۲۹۲/۲۹۳ ردیف ZIP، BUILD-INFO 8.2.5/`894560d` | v3.1.1 §2 (نقل از v3.0) | ZIP مرجع | `NOT VERIFIED` (فایل غایب) |
| دامنهٔ فایل‌ها: LOC هر فایل (مثلاً `engine.py=1992`) | v3.1.1 §18 | سورس | `NOT VERIFIED` (عدد = ادعای سندی؛ جمع LOC قابل بازشماری است — VERIFIED صرفاً حسابی) |

**جمع:** هیچ ادعای بالا تأیید یا رد نشد — همه `NOT VERIFIED` تا بازیابی `GoldBot_Final_Release_v8.2.5.zip` و بازبینی خط‌به‌خط.

---

## بخش ۳ — Evidence Register ادعاشی (هر دو سند) با وضعیت واقعی

### ۳.۱ شواهد v3.1.1 (§23 — خودِ سند همه را REPORTED تنزل داده)

| شاهد | محتوای ادعاشی | وضعیت در Workspace |
|---|---|---|
| P00 | محیط، Baseline، فهرست API | `NOT PROVIDED` (فایل خام مفقود) |
| P01 | سایت‌های `order_send` ۷۰۵/۸۳۰/۸۷۵ | `NOT PROVIDED` |
| P02 | بقای UNKNOWN در حافظه؛ خالی بعد از Restart | `NOT PROVIDED` |
| P03 | پایداری Risk؛ خالی بودن عملیات بعد از Restart | `NOT PROVIDED` |
| P04 | باز شدن ورود با acknowledge بدون حل عملیات | `NOT PROVIDED` |
| P05 | کلیدهای Close متفاوت بین دو Image (`key_A≠key_B`) | `NOT PROVIDED` |
| P06 | پایداری شش ترکیب Latch | `NOT PROVIDED` |
| P07 | Cancel رد‌شده = `RETCODE_CANCELED` | `NOT PROVIDED` |
| P08 | ۶ سناریو روی Fake Venue | `NOT PROVIDED` |
| P09 | دو نویسندهٔ هم‌زمان هر دو موفق | `NOT PROVIDED` |
| P10 | `1080 passed, 4 skipped, 1 xfailed` (Regression) | `NOT PROVIDED` — عدد فقط `REPORTED` |
| P11 | Suiteهای هدفمند | `NOT PROVIDED` |
| E-WIN-01 | رفتار دو Process روی Windows VPS | `NOT VERIFIED` (Gate 4 — طبق خود سند) |
| E-MT5-01 | Cancel/Fill/Timeout/Disconnect روی MT5 Demo | `NOT VERIFIED` (Gate 4) |
| E-BRK-01 | بیانیهٔ کتبی بروکر دربارهٔ ورود هم‌زمان | `NOT PROVIDED` — پیش‌نیاز Z-2 |
| E-TWO-01 | انتقال Authority بین دو VPS | `NOT VERIFIED` (Gate 4) |
| E-DOC-01 | وجود ورودی‌های v3.0 | **تأیید منفی مستقل در این جلسه: فایل‌ها واقعاً مفقودند** |
| E-BASE-01 | تطابق Hash Baseline | **باز** — فایل مفقود + لینک 404 (تأیید مجدد این جلسه) |
| E-DDL-01 | بررسی DDL در SQLite In-Memory | **`VERIFIED` (سطح constraint فقط) — در این جلسه مستقل بازتولید شد (بخش ۵). تست پروژه نیست.** |

### ۳.۲ شواهد v2.0 (§21 — خود سند همه را NOT VERIFIED/NOT TESTED خوانده)

همهٔ ۱۰ ردیف (Baseline hash · v1 decisions · ترتیب live · قفل/SQLite · authority/fencing · مالکیت/magic · پایداری عملیات · توان Reconciler · latch/ریسک · نتایج تست) ⇒ در این جلسه هم **`NOT VERIFIED` / `NOT TESTED`** باقی ماندند. هیچ فایل شاهد جدیدی یافت نشد. وضعیت v2.0 با موضع خودش سازگار است (نکتهٔ مثبت).

### ۳.۳ شاهد خام برای عدد «۶۲→۰» یا مشابه

- عبارت «۶۲→۰» یا معادل آن در **هیچ‌کدام از چهار ورودی** یافت نشد (`grep` انجام شد).
- هر عدد اجرایی دیگر (`1080 passed`، `292 rows`، `6 FAIL/3 PARTIAL`، `concurrent_returncodes=[0,0]`, `A=20 B=20`) ⇒ **فقط متنِ گزارش‌شده، بدون فایل خام ⇒ `NOT VERIFIED`.**

---

## بخش ۴ — Phase 6: وضعیت آزمایش‌های نام‌بردهٔ مأموریت

| آزمایش (طبق فهرست مأموریت) | نزدیک‌ترین شناسه(ها) در اسناد | نتیجهٔ ادعاشی در اسناد | شاهد خام در Workspace | وضعیت نهایی |
|---|---|---|---|---|
| Dual Engine | — (خارج از دامنه؛ ممنوع در v3.1.1؛ v2 ندارد) | ادعایی نیست | ندارد | `NOT RUN` / `NOT PROVIDED` |
| هم‌زمانی Entry و Management | T-30/T-02/T-03 · (v2: T01) | NOT TESTED (ادعای اجرای P09 مربوط دو نویسندهٔ DB است) | ندارد | `NOT TESTED` · ادعا `NOT VERIFIED` |
| انتقال بین دو VPS | T-36/T-35 · v2: T03/T17 | NOT TESTED | ندارد | `NOT TESTED` |
| Suspend/Resume | T-04/T-05/T-27 · R-08/OPEN-04 | NOT TESTED (T-27 ادعا: FAIL روی Linux با Multi-Writer مصنوعی — جانشین T-28/T-31 نیست) | ندارد | `NOT TESTED` · ادعا `NOT VERIFIED` |
| Crash Recovery | T-33/T-23/T-05 · v2: T05/T21 | ادعاها: FAIL/PARTIAL (P03..P09) | ندارد | `NOT VERIFIED` (ادعا) + `NOT TESTED` (واقعیت Workspace) |
| UNKNOWN Recovery | T-12/T-08 | ادعا: FAIL (P03,P04) | ندارد | `NOT VERIFIED` / `NOT TESTED` |
| Duplicate Entry | T-13/T-09 | ادعا: FAIL (P08?) | ندارد | `NOT VERIFIED` / `NOT TESTED` |
| Duplicate Close | T-13/T-14/T-08 | ادعا: FAIL / PARTIAL | ندارد | `NOT VERIFIED` / `NOT TESTED` |
| Partial Close | T-15/T-09 | ادعا: FAIL (P08) | ندارد | `NOT VERIFIED` / `NOT TESTED` |
| Pending Cancel Race | T-32/T-22/T-10 | NOT TESTED | ندارد | `NOT TESTED` |
| Position Ownership | T-17..T-20/T-11..T-14 | NOT TESTED | ندارد | `NOT TESTED` |
| Reconciliation | T-10..T-14/T-20..T-22/T-32/T-34 | ادعا: PARTIAL (T-11) | ندارد | `NOT VERIFIED` / `NOT TESTED` |
| SQLite Atomicity | OPEN-07 (هیچ آزمونی طراحی نشده — صراحتاً راهکار قطعی ندارد) · DDL In-Memory (E-DDL-01) | ادعای atomicity بین دو DB = ممنوع/منتفی | DDL فقط constraint | **OPEN-07 باز** · E-DDL-01 `VERIFIED` (سطح constraint — تست پروژه نیست) |
| Risk State و KILLED | T-24/T-20/T-19/T-41 | ادعا: PARTIAL (T-24) | ندارد | `NOT VERIFIED` / `NOT TESTED` |
| MT5 Startup و Shutdown | T-01/T-25/T-28..T-31 · v2: T02/T04/T18 | NOT TESTED (Windows) | ندارد | `NOT TESTED` |

**قانون تفکیک رعایت شد:** نتایج «۶ اجرا» v3.1.1 = ادعای `REPORTED` (بدون خروجی خام ⇒ `NOT VERIFIED`)؛ «۲۷+۶» باقی‌مانده = `NOT TESTED`؛ صفر `PASS` در هیچ سطحی. **هیچ آزمونی به‌عنوان تست کامل پروژه گزارش نشد.**

---

## بخش ۵ — دستورات واقعاً اجراشده در این جلسه (کنترل‌شده و قابل بازتولید)

> این‌ها **بررسی سند/کانسترینت** هستند، **نه تست پروژه** — هیچ‌کدام PASS بودن هیچ تستی از تست‌های T-xx/Txx را اثبات نمی‌کنند.

| # | دستور/عملیات | خروجی | دامنه |
|---|---|---|---|
| 1 | `sha256sum uploads/*` (چهار فایل) | مقادیر بخش ۱.۱ | شناسایی/تمامیت ورودی‌ها |
| 2 | کنترل متقاطع Hash درونی: مقادیر بخش ۱ گزارش اعتبارسنجی در برابر مقادیر محاسبه‌شده | v3.1.1: `62a05c27…` = یکسان ✓ · Traceability: `5197ca43…` = یکسان ✓ | تمامیت داخلی زنجیرهٔ اسناد v3.1.1 |
| 3 | `curl` سه URL گیت‌هاب (blob/raw + API repo + API contents) | هر سه **HTTP 404** | دسترسی سورس |
| 4 | اسکریپت Python + `sqlite3 ":memory:"` (Python 3.x، SQLite 3.46.1): DDL قدیمی `position_order_deal` با COALESCE در PK → `OperationalError: expressions prohibited in PRIMARY KEY…`؛ DDL جدید FIX-02 → OK و ۷ کانسترینت (NOT NULL / CHECK ref_type / CHECK pair / NOT NULL + NOT / UNIQUE) همگی رفتار موردنظر؛ UNIQUE قدیمی `operation` (با payload_hash) اجازهٔ درخواست دوم را داد (بازتولید نقص)؛ UNIQUE جدید FIX-01 درخواست دوم هم‌intent را رد کرد و intent متفاوت را پذیرفت | **۱۲/۱۲ PASS در سطح constraint** + خروجی خام در بالا | **بازتولید مستقل E-DDL-01** — «تست پروژه نیست»؛ `db file created: False` |
| 5 | اسکریپت بازشماری جدول‌های §19.2 سند v3.1.1 | جمع `+۱٬۸۲۸/−۲۶۶` ✓ · C-1 `1608/215` ✓ · C-2 `220/51` ✓ · بازه `2028/316` ✓ | بازتولید ادعای P1-6/FIX-08 |
| 6 | بازشماری: REQهای v2=۱۳ ✓ · تست‌های v2=۲۱ ✓ · لایه‌های تست v3.1.1=۳۶ ✓ · ردیف‌های ماتریس این ممیزی=۹۳ ✓ (`grep -c '^\| CR-'`) | همگی منطبق | شمارش سندی |
| 7 | خواندن کامل چهار ورودی + مقایسهٔ متنی (از جمله ادعاهای §25/§1.3 در برابر متن v2.0) | مبنای CF-09 | تطبیق بندبه‌بند |
| — | `pytest` / اجرای کد پروژه / اتصال MT5 / Migration / تغییر سورس / ارسال سفارش | **انجام نشد — `NOT RUN`** | — |

---

## بخش ۶ — جمع‌بندی ردیابی

1. **هیچ ادعای سورسی تأیید یا رد نشد** — همگی `NOT VERIFIED` به‌دلیل فقدان ZIP (E-BASE-01 + لینک 404 تأییدشده).
2. **تمامیت چهار ورودی موجود `FOUND_AND_VERIFIED` است** و دو Hash با کنترل متقاطع درونی تأیید شد.
3. **هیچ خروجی خام تستی در Workspace نیست**؛ حتی ادعاهای اجرای گذشته (P02..P10) `NOT VERIFIED` ماندند؛ `PASS=0`.
4. تنها `VERIFIED`های این ممیزی: (الف) Hash/فایل‌شناسی، (ب) DDL سطح constraint (بازتولید E-DDL-01 — نه تست پروژه)، (ج) جمع/شمارش‌های حسابی درون اسناد، (د) مغایرت‌های متنی داخلی (CF-09/CF-10).
5. هر عدد/ادعای جدید در v4.0 بدون فایل خام باید `REPORTED` یا `NOT VERIFIED` بماند.

**پایان Deliverable 3 · ۰ ادعای تأییدشدهٔ سورس · ۰ تست پروژه · ۰ تغییر سورس**
