# GoldBot — سند تطبیق Clause-by-Clause: v3.1 ↔ v3.1.1

**موضوع:** اصلاح هدفمند هشت‌گانه (FIX-01..FIX-08) بر پایهٔ نسخهٔ FROZEN v3.1 — Document Revision فقط.
**تاریخ:** 2026-11-23
**نقش:** Senior Trading Systems Architect — آخرین دور اصلاح سند پیش از Freeze (تصمیم با بازبینی مستقل انسانی).

## ورودی‌ها (تطبیق‌شده)

| ورودی | وضعیت |
|---|---|
| `GoldBot_CONSOLIDATED_REMEDIATION_PLAN_v3_1_FROZEN.md` | SHA256 `29a96b75b648b580217b2fa73e6b4b90a98832538869ed1f963d08db6950ac50` — با `sha256sum` تأیید شد؛ با نسخهٔ آپلودشده `cmp` بایت‌به‌بایت یکسان |
| `GoldBot_v3_vs_v3_1_Clause_by_Clause_Traceability_FROZEN.md` | SHA256 `9251e2b355ab74ece13abd180ae5d432874f05cd9f1461809a0011b2c7fe05b6` — با `sha256sum` تأیید شد؛ با نسخهٔ آپلودشده `cmp` بایت‌به‌بایت یکسان |
| `GoldBot_v3_1_Final_Validation_Report.md` | ورودی — بازنویسی نشد؛ گزارش جدید `GoldBot_v3_1_1_Final_Validation_Report.md` جایگزین می‌شود |
| Baseline ZIP `GoldBot_Final_Release_v8.2.5.zip` | **موجود نبود** — گزارش نشده، حدس زده نشد (E-BASE-01 باز) |
| `REQUIREMENTS_AND_TEST_MATRIX_v3.csv` | **موجود نبود** — ساخته نشد، ویرایش نشد (NOT PROVIDED) |

**خروجی‌های این مرحله (فقط سه فایل):**
1. `GoldBot_CONSOLIDATED_REMEDIATION_PLAN_v3_1_1.md` (سند اصلی)
2. `GoldBot_v3_1_vs_v3_1_1_Clause_by_Clause_Traceability.md` (همین سند)
3. `GoldBot_v3_1_1_Final_Validation_Report.md`

---

## الف — هشت FIX: وضعیت متن، محل دقیق، و دو وضعیت مجزا

> **قواعد وضعیت (FIX-08):** «وضعیت متن» = آیا متن اصلاح شده؟ «وضعیت اثبات/پیاده‌سازی/آزمون» = آیا اثبات فنی، پیاده‌سازی یا آزمونی وجود دارد؟ هیچ FIX بدون شاهدِ اجراشده «حل فنی» اعلام نمی‌شود. «تعیین تکلیف متنی» ≠ «حل فنی اثبات‌شده».

| FIX | شدت | وضعیت متن (v3.1.1) | محل‌های دقیق در سند اصلی v3.1.1 | خلاصهٔ تغییر | وضعیت اثبات/پیاده‌سازی/آزمون |
|---|---|---|---|---|---|
| FIX-01 — Idempotency: Intent بدون payload_hash | P0 | ✅ APPLIED (متن) | §4 P0-6 بندهای ۵ و۶ + خلاصه · §8 سطر OperationRegistry · §11.2 ستون‌های `submission_attempt_count`/`duplicate_request_count` و کامنت `payload_hash` و `UNIQUE (account_login, server, deployment_id, client_intent_id)` · §11.4 سطرهای Duplicate/Conflict/Retry · §16 REQ-08 | UNIQUE فقط روی intent (بدون `payload_hash`)؛ همان payload ⇒ اتصال + `duplicate_request_count += 1` (بدون تغییر شمارندهٔ ارسال)؛ payload متفاوت ⇒ رویداد `IntentConflictDetected` + پاسخ خطای صریح، بدون ایجاد Operation جدیدِ قابل‌ارسال؛ تفکیک `submission_attempt_count` (فقط ارسال واقعی) از `duplicate_request_count`؛ `CONFLICT` از enum وضعیت‌ها حذف و به رویداد نگاشت شد | **NOT IMPLEMENTED / NOT TESTED** — طراحی سندی؛ پیاده‌سازی `operation_registry.py` و آزمون T-17 اجرا نشده |
| FIX-02 — نحو PK در position_order_deal + CLOSED | P0 | ✅ APPLIED (متن) | §10.3 بلوک `position_order_deal` (DDL بازنویسی‌شده + کامنت‌های FIX-02) · §10.3 کامنت `state` (افزودن `CLOSED`) · §10.3 قاعدهٔ OWNED (تفکیک مسئول) · §10.4 یادداشت CLOSED · §23 سطر E-DDL-01 | حذف `COALESCE` از PK (نامعتبر در SQLite)؛ استراتژی Sentinel: `order_id/deal_id TEXT NOT NULL DEFAULT ''` + `CHECK (order_id <> '' OR deal_id <> '')` + PK شش‌ستونی ساده با همان دامنهٔ یکتایی قبلی (پنج جزء مفهومی هویت)؛ `ref_type` با CHECK صریح؛ بدون FK صریح (ارجاع منطقی، هماهنگ با سایر جداول)؛ نسخهٔ حداقل SQLite: بدون وابستگی فراتر از DDL پایه؛ `CLOSED` به state مالکیت اضافه و با §10.6 هماهنگ شد | **NOT IMPLEMENTED / NOT TESTED** به‌عنوان تست پروژه — فقط بررسی نحو/رفتار constraint در SQLite In-Memory اجرا شد (E-DDL-01؛ جزئیات در گزارش اعتبارسنجی؛ **تست پروژه نیست**) |
| FIX-03 — یک وضعیت Canonical + تفکیک لایه‌ها | P0 | ✅ APPLIED (متن) | §4 P0-4 خلاصه · §11.۳ بازنویسی کامل (جدول سه لایه + جدول گذارهای مجاز + وضعیت‌های پایانی + نگاشت نام‌های بازنشسته + نقشهٔ بازیابی Restart) · §11.۴ بازنویسی کامل · §11.2 کامنت status + ستون‌های `last_broker_outcome`/`last_reconciliation_outcome` · §12.۱ ستون وضعیت/مسیر نهایی + یادداشت · §12.۳ تیتر و پاراگراف P1-1 · §12.۴ بازنویسی کامل · §12.۵ یادداشت · §5 P1-1 (بند۳،۴، خلاصه) و P1-3 (چهار سطر) | ۱۰ وضعیت Canonical: `CREATED · SUBMISSION_PENDING · API_ACCEPTED · PARTIALLY_FILLED · EXECUTED · REJECTED_FINAL · UNKNOWN · RECONCILIATION_REQUIRED · RESOLVED · CANCELLED`؛ نگاشت: `FAILED_FINAL`→`REJECTED_FINAL`، `SUBMITTED`→`SUBMISSION_PENDING`، `CONFLICT`→رویداد، `CONFIRMED` و `RESOLVED_ABSENT`→لایهٔ Reconciliation Outcome (نه وضعیت)، نتیجهٔ `UNKNOWN` در §12.4→`INCONCLUSIVE`؛ وضعیت‌های پایانی برگشت‌ناپذیر صریحاً `RESOLVED · CANCELLED · REJECTED_FINAL`؛ جدول مرجع واحد گذارها + بازیابی Restart؛ ممنوعیت صریح دور زدن با Retry/Run ID؛ `EXECUTED` دیگر پایانی نیست (⇒ `RESOLVED` پس از Reconciliation) | **NOT IMPLEMENTED / NOT TESTED** — طراحی سندی؛ اجرای Runtime و آزمون‌های T-10/T-11/T-32/T-33 اجرا نشده |
| FIX-04 — §6 تنها Normative؛ §14.2 غیرالزامآور | P0 | ✅ APPLIED (متن) | §6 (بند مرجعیت در مقدمه · سطر `**OWNED**` · چهار بند جدید در قواعد الحاقی: Serialization، Grant واحد، Modify فیلدبه‌فیلد، Cancel-Pending/Exposure · تقویت `--emergency-all`) · §14.۲ (تیتر + بنر غیرالزامآور + بازنویسی جدول + یادداشت) · §5 P1-5 (بازنویسی سطر Cancel + دو سطر جدید Protective/Modify ترکیبی) | §6 تنها مرجع Normative تصمیم؛ §14.2 به خلاصهٔ تاریخی/غیرالزامآور تنزل یافت (در تعارض، §6 حاکم؛ پیش‌نیض Ownership=OWNED در بنر)؛ Cancel-Pending فقط اگر واقعاً Exposure کاهش یابد؛ لغو سفارش حفاظتی ≠ Reduce-Risk خودکار؛ Modify SL/TP فیلدبه‌فیلد (تغییر TP ⇒ کل عملیات Reduce-Risk نیست)؛ قاعدهٔ Serialization (حداکثر یک عملیات تغییردهنده به‌ازای هر پوزیشن؛ حجم از Snapshot تازه)؛ تعریف واحد `Grant` (جایگزین OWNED نمی‌شود، Ownership Gate را دور نمی‌زند)؛ `--emergency-all` هرگز Ownership Gate را دور نمی‌زند | **NOT IMPLEMENTED / NOT TESTED** — طراحی سندی؛ آزمون‌های Permission Matrix اجرا نشده |
| FIX-05 — Reconciler کاوش‌گر است، مالکیت نمی‌سازد | P0 | ✅ APPLIED (متن) | §8 سطرهای OwnershipService و Reconciler · §10.3 یادداشت «تفکیک مسئول» · §12.۴ سطر `FILLED` · §12.۵ یادداشت FIX-05 | Reconciler فقط کشف/جمع‌آوری شاهد و ثبت نتیجهٔ Reconciliation می‌کند؛ ایجاد/تغییر state مالکیت فقط توسط OwnershipService؛ فقدان/ناقص/مبهم بودن `opening_operation_id` ⇒ `UNKNOWN`/`AMBIGUOUS`، هرگز `OWNED`؛ نتیجهٔ `FILLED` (لغوی که پر شده) دیگر از وجود Deal خودکار OWNED نمی‌سازد | **NOT IMPLEMENTED / NOT TESTED** — طراحی سندی؛ آزمون‌های Reconciler/Ownership اجرا نشده |
| FIX-06 — حد تشخیص Restore؛ حذف ادعای قطعی | P0 (Open Risk) | ✅ APPLIED (متن) — **بدون بستن ریسک** | §4 P0-3 بند ۳ + سطر وضعیت · §9.۷ جدول بازنویسی‌شده (تفکیک چهار رویداد + حد تشخیص + پیش‌نیاز مرجع آتی) · §10.6 سطر `DB از Backup قدیمی` · §15.4 سطر `Restore از Backup قدیمی` · §22 سطر R-08 · پاسخ صریح (بند OPEN-04) | تصریح شد مقایسهٔ `(boot_epoch, generation)` ذخیره‌شده **به‌تنهایی** بازگردانی سازگار (هر دو از یک Backup) را تشخیص نمی‌دهد؛ تشخیص قطعی نیازمند مرجع مستقل تک‌صعودی خارج از مجموعهٔ Backup است که در Scope فعلی تعریف/تأیید نشده ⇒ **ادعای تشخیص قطعی حذف شد**؛ رفتار: مشاهدهٔ اختلاف ⇒ Fail-Closed، نبود/خرابی مرجع ⇒ Fail-Closed؛ تفکیک Process Restart / Host Restart / VM Suspend-Resume / DB Restore صریح شد؛ `boot_epoch` فقط Provenance/Audit، هرگز MT5 fencing | **OPEN-04 باز می‌ماند** — هیچ راه‌حل اثبات‌شده‌ای وجود ندارد؛ آزمون Suspend/Resume همچنان NOT TESTED |
| FIX-07 — Z-3 ≠ شرط ورود؛ ریسک انسانی ≠ اثبات فنی | P0 | ✅ APPLIED (متن) — **بدون بستن ریسک** | §9.1 جملهٔ Z-4 · §9.2 پاراگراف P-1..P-5 (افزودن boot_epoch + تفکیک پذیرش ریسک) · §9.6 یادداشت بازگشت Host قدیمی · §10.6 سطر VPS Migration (بازنویسی) · §13 یادداشت «مرز Authority ← Entry» · §14.4 یادداشت FIX-07 · §21 سطر Gate 2 · §22 سطر R-01 · پاسخ صریح (بند OPEN-01) | `Z-3` به‌تنهایی هرگز `Ownership Provenable` را برآورده نمی‌کند (فقط `Z-1` یا `Z-2`) — صریح در §13 و §14.4؛ تکمیل Startup به‌تنهایی ورود باز نمی‌کند؛ پذیرش ریسک انسانی/عملیاتی (امضا، تأیید مستقل، سلب Session، Audit) از اثبات فنی تفکیک شد و هرگز به‌عنوان اثبات شمرده نمی‌شود؛ تغییر boot_epoch به‌تنهایی مجوز انتقال نیست؛ جلوگیری قطعی از بازگشت Host قدیمی با همان `deployment_id`/DB فنی اثبات‌نشده ⇒ صریحاً جزئی از **OPEN-01** ثبت شد؛ عدم انتقال امن با صرف توقف Process رد شد | **OPEN-01 باز می‌ماند** (توضیح گسترش یافت؛ مورد جدید اضافه نشد) — سلب دسترسی P-2/Z3-5 خودش NOT VERIFIED است |
| FIX-08 — تراز Traceability/Evidence/Gates/LOC | P0/P1 | ✅ APPLIED (متن) | این سند (الف..و) · سند اصلی: §1 بند تعیین‌تکلیف · §2 بلوک ورودی‌های v3.1.1 · §19.2 بند بازهٔ LOC · §21 Gate 1 و Gate 2 · §23 (E-BASE-01 + E-DDL-01 + یادداشت تفکیک) · پاسخ صریح (q1/q2/ریسک‌ها) · گزارش اعتبارسنجی v3.1.1 | جداسازی شمارش ۸۷ بند از ۱۳ مورد باز (اصلاح عبارت «از آن‌ها UNRESOLVED = ۱۳»)؛ دو وضعیت مجزا برای هر P0/P1 (متن vs اثبات)؛ «تعیین تکلیف متنی» ≠ حل فنی؛ Gate 1 → `CONDITIONAL PASS — DOCUMENT CONSISTENCY ONLY` (شرطی، قابل تنزل)؛ Gate 2 → `NOT APPROVED`؛ Gates 3/4/5 NOT STARTED؛ بازهٔ LOC با روش و دامنهٔ دقیق (+۲۰۰/+۵۰ یک‌طرفه) بدون درصد/زمان‌بندی اختراعی؛ رفع تعارض «اسکریپت اجرا شد vs نشد» در گزارش اعتبارسنجی با فهرست دقیق دستورها/خروجی‌ها/دامنه | **NOT VERIFIED** برای هر ادعای اثباتی — گزارش اعتبارسنجی v3.1.1 فقط بررسی‌های ایستای سند + DDL In-Memory را ثبت می‌کند؛ صفر تست PASS |

---

## ب — بخش‌های تغییریافته و بخش‌های بازمانده

**روش:** مقایسهٔ بخش‌به‌بخش (Split با `## `) و مقایسهٔ خط‌به‌خط (`difflib`) بین `..._v3_1_FROZEN.md` و `..._v3_1_1.md`.

**بافت خط:** ۱٬۳۷۵ خط (FROZEN) → ۱٬۴۳۴ خط (v3.1.1)؛ دلتا: **+۱۶۵ / −۱۰۶** (شامل بازنویسی‌های هدفمند §11.3/§11.4/§12.1/§12.4/§9.7/§14.2 و افزودنی‌های یادداشت‌ها).

**۲۰ بخش سطح‌اول تغییریافته (همه در محدودهٔ هشت FIX):**
عنوان سند (v3.1→v3.1.1) · §1 خلاصهٔ اجرایی · §2 یکپارچگی Baseline · §4 اصلاحات P0 · §5 اصلاحات P1 · §6 ماتریس تصمیم واحد · §8 Single Execution Authority · §9 Locking/مالکیت چند-VPS · §10 مدل مالکیت · §11 Idempotency · §12 Reconciliation · §13 Startup/Shutdown · §14 Risk/Execution State · §15 Database/Persistence · §16 ردیابی الزامات · §19 LOC · §21 Acceptance Gates · §22 ریسک‌ها · §23 Evidence Register · پاسخ صریح.

**۸ بسط سطح‌اول بایت‌به‌بایت یکسان با FROZEN:**
§3 دامنه · §7 معماری هدف · §17 استراتژی آزمون · §18 دامنهٔ فایل‌به‌فایل · §20 فازها · §24 تصمیم‌های معتبر · §25 بازبینی خطاهای v2 · بخش Future Considerations.

**زیربخش‌های بازماندهٔ یکسان (درون بخش‌های تغییریافته) — نمونه‌ها:** §1.5 یافته‌ها · §4 به‌جز پنج هدف FIX (P0-1، P0-2، P0-5، P0-7، P0-8 دست‌نخورده) · §5 به‌جز P1-1/P1-3/P1-5/P1-6 · §9.3/9.4/9.5 · §10.1/10.2/10.5 · §11.1 · §11.5/§11.6 (**بایت‌به‌بایت یکسان — پس از بازیابی**) · §12.2 · §14.1/14.3/14.5 · §15.1/15.2/15.3/15.5 · §19.1/19.3/19.4/19.5.

**سطرهای تغییریافته در §4:** بند ۳ و سطر وضعیت P0-3 · خلاصهٔ P0-4 · بندهای ۵ و ۶ و خلاصهٔ P0-6 · خطایابی سطر تعیین‌تکلیف (بند FIX-08).
**سطرهای تغییریافته در §5:** بندهای ۳ و ۴ و خلاصهٔ P1-1 · چهار سطر P1-3 · سطر Cancel و دو سطر جدید P1-5 · سطر بازهٔ LOC در P1-6.

---

## ج — موارد باز (۱۳ مورد — مستقل از ۸۷ بند)

> **اصلاح شمارشی (FIX-08):** در سند تطبیق v3.1 عبارت «از آن‌ها UNRESOLVED = ۱۳» طوری نوشته شده بود که گویی ۱۳ مورد زیرمجموعهٔ ۸۷ بند است. **تصحیح:** ۸۷ بند = شمارش تغییرات سندی (v3→v3.1)؛ ۱۳ مورد باز = فهرست مستقل Open Itemها. هیچ‌کدام زیرمجموعهٔ دیگری نیستند.

| # | مورد باز | وضعیت در v3.1.1 |
|---|---|---|
| 1 | OPEN-01 — مالکیت بین دو VPS / AL-1 (**توضیح گسترش یافت:** شامل بازگشت Host قدیمی با همان `deployment_id`/DB — FIX-07) | **باز** — بسته نشد |
| 2 | OPEN-02 — L-2، بدون Idempotency سمت بروکر | **باز** — بسته نشد |
| 3 | OPEN-03 — کفایت History برای `RESOLVED_ABSENT` و کالیبراسیون Δ | **باز** — بسته نشد |
| 4 | OPEN-04 — پنجرهٔ بوت هم‌زمان (**ادعای تشخیص قطعی Restore حذف شد — FIX-06؛ خود ریسک باز ماند**) | **باز** — بسته نشد |
| 5 | OPEN-05 — طول comment ۳۱ کاراکتر | **باز** |
| 6 | OPEN-06 — Race بررسی مجوز ←→ ارسال (P0-3) | **باز** — NOT TESTED |
| 7 | OPEN-07 — عدم atomicity بین State DB و Journal DB (P0-8) | **باز** |
| 8 | RS-03 — نیازمند امضا | **باز** |
| 9 | R-07 — Session 0/1 ویندوز | **باز** |
| 10 | R-12 — گارد check-then-act در Launcher | **باز** |
| 11 | E-DOC-01 — وجود فایل‌های ورودی v3.0 در Workspace | **باز** (NOT VERIFIED) |
| 12 | E-BASE-01 — تطابق Baseline ZIP با SHA256 مرجع | **باز** (NOT VERIFIED — فقط با تطابق Hash واقعی بسته می‌شود) |
| 13 | CSV — `REQUIREMENTS_AND_TEST_MATRIX_v3.csv` | **باز** (NOT PROVIDED — ساخته/ویرایش نشد) |

هیچ مورد بازی در v3.1.1 به RESOLVED تغییر نکرد. هیچ Open Risk با بازنویسی متن بسته نشد.

---

## د — شمارش‌ها (راستی‌آزمایی)

| شمارش | مقدار | روش راستی‌آزمایی |
|---|---|---|
| بندهای تغییریافته v3→v3.1 | **۸۷ = ۵۹ تغییر + ۲۸ RETAINED** (۵۹ = ۴۲ REVISED + ۱۲ EXPANDED + ۵ MOVED) | از سند تطبیق FROZEN — بدون تغییر در v3.1.1؛ کنترل‌ها: ۴۲+۱۲+۵+۲۸=۸۷ · الف ۱۳+۲=۱۵ · ب ۲۹+۱۰+۵+۲۸=۷۲ |
| موارد باز (Open Items) | **۱۳** — مستقل از ۸۷ | فهرست بخش ج همین سند |
| FIXهای v3.1.1 | **۸** (FIX-01..FIX-08) | بخش الف همین سند |
| بخش‌های سطح‌اول تغییریافته / یکسان | **۲۰ / ۲۸** | Split مقایسه‌ای (روش در بخش ب) |
| LOC (جمع مستقیم ردیف‌های §19.2) | **+۱٬۸۲۸ / −۲۶۶** (C-1: ۱٬۶۰۸/۲۱۵ · C-2: ۲۲۰/۵۱ · C-3: ۰/۰) | جمع دستی ستون‌ها + کنترل با اسکریپت شمارش؛ جمع دسته‌ها = جمع per-file |
| بازهٔ عدم قطعیت LOC | افزوده **۱٬۸۲۸–۲٬۰۲۸ (+۲۰۰)** · حذف **۲۶۶–۳۱۶ (+۵۰)** | حاشیهٔ قضاوتی یک‌طرفه برای رشد C-1/C-2 — **نه** محاسبهٔ آماری؛ بدون درصد یا زمان‌بندی اختراعی |
| ردیف‌های §18 | ۲۴ موجود + ۳ جدید = **۲۷** | دست‌نخورده |
| تست‌های PASS در این مرحله | **۰** | هیچ تستی اجرا نشد |

---

## ه — وضعیت دوگانهٔ پانزده مورد P0/P1

| مورد | وضعیت اصلاح متن (v3.1) | وضعیت اصلاح متن (v3.1.1) | وضعیت اثبات/پیاده‌سازی/آزمون |
|---|---|---|---|
| P0-1 — یکپارچه‌سازی Ownership/Reduce-Only | APPLIED (§6 واحد) | APPLIED — §6 تقویت + §14.2 تنزل (FIX-04) | NOT IMPLEMENTED · NOT TESTED |
| P0-2 — انتقال مالکیت / Z-3 | APPLIED | APPLIED — صراحت Z-3 بدون ورود (FIX-07) | NOT IMPLEMENTED · NOT TESTED |
| P0-3 — boot_epoch/گیت | APPLIED | APPLIED — حذف ادعای تشخیص قطعی (FIX-06)؛ OPEN-04 باز | NOT IMPLEMENTED · NOT TESTED (Suspend/Resume) |
| P0-4 — ماشین حالت | APPLIED | APPLIED — مرجع واحد + لایه‌ها (FIX-03) | NOT IMPLEMENTED · NOT TESTED |
| P0-5 — مدل مالکیت | APPLIED | APPLIED — DDL/CLOSED (FIX-02) + تفکیک مسئول (FIX-05) | NOT IMPLEMENTED · NOT TESTED |
| P0-6 — Idempotency Intent | APPLIED | APPLIED — UNIQUE بدون payload_hash + شمارنده‌ها (FIX-01) | NOT IMPLEMENTED · NOT TESTED |
| P0-7 — گیت Startup | APPLIED | APPLIED — یادداشت مرز Authority←Entry (FIX-07) | NOT IMPLEMENTED · NOT TESTED |
| P0-8 — Database of Record | APPLIED | دست‌نخورده (خارج از هشت FIX) | NOT IMPLEMENTED · NOT TESTED |
| P1-1 — RESOLVED_ABSENT پنج‌شرطی | APPLIED | APPLIED — زبان «نتیجه ≠ وضعیت» (FIX-03) | NOT TESTED (T-32/T-33) · کالیبراسیون OPEN-03 |
| P1-2 — چند Deal | APPLIED | دست‌نخورده | NOT TESTED |
| P1-3 — شرط CONFIRMED per-type | APPLIED | APPLIED — نگاشت به وضعیت `RESOLVED` (FIX-03) | NOT TESTED |
| P1-4 — پوشش مسیرهای نوشتن | APPLIED | دست‌نخورده | NOT TESTED |
| P1-5 — تعریف دقیق Reduce-Risk | APPLIED | APPLIED — Cancel/Protective/Modify ترکیبی (FIX-04) | NOT TESTED |
| P1-6 — LOC | APPLIED (بازمحاسبه) | APPLIED — روش/دامنهٔ بازه (FIX-08) | NOT VERIFIED (برآورد سندی) |
| P1-7 — Standby (Observer + Forwarder) | APPLIED | دست‌نخورده | NOT IMPLEMENTED · NOT TESTED |

---

## و — تراز Evidence / Gates / LOC با سند اصلی

| موضوع | وضعیت یکسان در سند اصلی v3.1.1 و گزارش اعتبارسنجی v3.1.1 |
|---|---|
| Gate 1 | `CONDITIONAL PASS — DOCUMENT CONSISTENCY ONLY` — فقط انسجام مستندات پس از FIX-01..08؛ شرطی؛ در صورت یافتن تناقض حل‌نشده ⇒ `NOT PASSED` |
| Gate 2 | `NOT APPROVED` — نیازمند مجوز صریح انسانی و تحقق شروط رسمی |
| Gates 3/4/5 | `NOT STARTED` |
| E-BASE-01 | UNRESOLVED / NOT VERIFIED — فقط با تطابق Hash واقعی ZIP بسته می‌شود |
| CSV | NOT PROVIDED — ساخته/ویرایش نشد |
| REQ-21..REQ-26 / T-37..T-42 | **Proposed** فقط — در CSV ثبت نشدند |
| E-DDL-01 | بررسی نحو/رفتار DDL در SQLite In-Memory — فقط constraint؛ **تست پروژه نیست** |
| شاهد جدید از سورس/اجرای پروژه | هیچ — صفر تست PASS؛ هیچ کد/DB/Config/Deployment تغییر نکرد |
| شمارش ۸۷/۱۳ | یکسان با سند اصلی (جداسازی صریح) |
| LOC ۱٬۸۲۸/۲۶۶ + بازه | یکسان با سند اصلی (روش و دامنه در §19.2 و این سند یکسان) |

---

**پایان سند تطبیق. فقط سه فایل v3.1.1 تولید شد · کد/DB/Config تغییر نکرد · تستی اجرا نشد · Phase C آغاز نشد · در انتظار بازبینی مستقل هشت FIX برای تصمیم Freeze/Reject.**
