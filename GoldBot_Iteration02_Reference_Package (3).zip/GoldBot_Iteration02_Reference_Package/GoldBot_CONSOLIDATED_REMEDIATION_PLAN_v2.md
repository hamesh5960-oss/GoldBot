# GoldBot Consolidated Remediation Plan — v2.0

**Document status:** Controlled document revision only. **Implementation has not started.**  
**Evidence posture:** Source archive, v1 document, source tree and test outputs were not present in the supplied workspace at revision time. Accordingly, code-level claims, file inventory, LOC, and test execution are explicitly `NOT VERIFIED`; architectural prescriptions below are `DESIGN PROPOSAL` unless stated otherwise.

## 1. Executive Summary

This revision defines a safety-oriented, testable remediation plan while preserving the v1 decisions stated in the request: baseline archive and SHA-256, Single Execution Authority (SEA), phased separation of Control Plane / Windows Agent / Account Management / Strategy Management, no Phase C before its gates, no real trading before safety gates and Demo validation, and Toobit Futures out of scope.

Five P0 design gaps are addressed: (A) scope and limitations of locking across hosts; (B) deployment-level position ownership; (C) persistent operation idempotency; (D) operation-specific reconciliation; and (E) lock acquisition before MT5 connection. The plan does **not** claim those controls exist or work today. No code, migration, configuration, or test was changed or run. All Gates remain unpassed.

**Decision summary:** A local OS lock can coordinate processes on one host but cannot establish exclusive ownership across VPSs. Cross-VPS execution requires a separately defined, fail-closed ownership/transfer mechanism with positively evidenced fencing or verified cessation of the former host. If that cannot be proven, the new host must not trade. No particular distributed-lock service or fencing capability is assumed available.

## 2. Baseline Integrity

| Item | Required baseline | Status |
|---|---|---|
| Archive | `GoldBot_Final_Release_v8.2.5.zip` | `REPORTED` by request; archive not supplied, integrity not independently verified |
| SHA-256 | `3baed37dc55b44a958229f115b7276a7c959aae7c17dab140b3da1250d930fc7` | `REPORTED`; no archive available to recompute |
| v1 plan | `GoldBot_CONSOLIDATED_REMEDIATION_PLAN_v1.md` | Not present in workspace; v1-specific assertions cannot be independently compared (`NOT VERIFIED`) |
| Source tree / test outputs | Not supplied | `NOT VERIFIED` |

Before implementation, obtain the exact archive and compute SHA-256 (e.g. `sha256sum <archive>` on a trusted system), preserve the command output, and inventory/extract the source into a review-only workspace. Do not modify the baseline artifact.

## 3. Scope and Non-Goals

**In scope:** document-level architecture, requirements, proposed persistence/state semantics, verification plan, file-scope investigation, estimates with explicit uncertainty, and gates for remediation of execution safety.

**Out of scope:** source edits in this task; implementation or Phase C; database/config changes; strategy changes; new trading features; claiming test results; Toobit Futures. No specific database engine, control-plane service, fencing primitive, or broker behavior is assumed beyond the stated baseline.

## 4. Findings and Priorities

| Finding | Priority | Required resolution | Evidence status |
|---|---|---|---|
| P0-A Local lock mistaken for account-wide exclusivity | P0 | Distinguish process/host/account ownership; fail closed on unproven handover | `DESIGN PROPOSAL`; current implementation `NOT VERIFIED` |
| P0-B Magic number insufficient to identify deployment ownership | P0 | Explicit composite ownership and ambiguity policy | `DESIGN PROPOSAL`; code `NOT VERIFIED` |
| P0-C Process-scoped/run-scoped idempotency insufficient | P0 | Durable operation identity, state machine, recovery and no blind retry | `DESIGN PROPOSAL`; persistence `NOT VERIFIED` |
| P0-D Snapshot-only reconciliation insufficient | P0 | Per-operation broker evidence and repeatable audit trail | `DESIGN PROPOSAL`; adapter evidence `NOT VERIFIED` |
| P0-E Lock only in bootstrap is too late if live path connects first | P0 | Acquire authority before MT5 connect; hold through disconnect and process exit | Startup sequence reported in request; source `NOT VERIFIED` |

## 5. Target Architecture

Preserve **Single Execution Authority**: at most one authorized execution agent for a given account/deployment scope may submit trading commands. Strategy/control components may request actions but may not independently submit broker orders. Exact existing component boundaries are `NOT VERIFIED` pending source review.

Separate state domains:
1. **Execution Authority:** who is permitted to submit commands and whether that authority is valid/fenced.
2. **Risk State:** whether risk policy permits each operation class.
3. **Operation Ledger:** durable intent, submissions and outcomes.
4. **Broker Observations:** orders, history, deals, positions and observed account identity.
5. **Ownership Registry:** account, deployment, authority and position/ticket ownership with provenance.

No component may infer durable ownership or a final broker outcome from a magic range, an in-memory run identifier, an API success response, or absence from a single snapshot alone.

## 6. Single Execution Authority

SEA is the target invariant, not a verified property of current code. One execution authority should serialize submission decisions for an account scope and ensure each request is associated with an authorized deployment and durable operation record. The precise account identity format, authority store, fencing mechanism, and failure-domain guarantees require architecture review and are `NOT VERIFIED`.

A host may submit only while it holds valid authority. A lease/heartbeat without broker-enforced fencing is not sufficient proof against a partitioned, still-running prior host. If the system cannot invalidate or positively stop that host, fail closed: no new host submission, and no automatic transfer.

## 7. Locking and Multi-VPS Ownership (P0-A)

### Lock scopes
- **Local Process Lock:** prevents duplicate cooperating processes on one OS host, subject to correct OS semantics and cleanup.
- **Local Host Lock:** host-wide exclusion among cooperating processes on that host; a local file/OS mutex remains local to its host/storage semantics.
- **Account-Level Execution Ownership:** authority for a broker account across all hosts. Requires a shared, authoritative coordination/fencing design; a local lock or local SQLite database is not this mechanism.

**A local OS lock on VPS-A cannot by itself prevent GoldBot on VPS-B from running. Local SQLite is not a distributed lock.** Neither a shared Magic Base nor a heartbeat alone provides cross-host exclusion.

### A. Single-VPS operation — proposal
1. Resolve intended account/deployment identity without connecting to MT5 where feasible.
2. Acquire local execution lock and account authority before MT5 connection.
3. Verify authority and account identity; only then connect MT5.
4. Keep lock/authority valid for the entire connected engine lifetime.
5. Stop accepting new work; stop engine; reconcile/record in-flight operations; disconnect MT5; confirm shutdown; then release local lock. Process exit follows lock release only when shutdown is complete and no work can continue.
6. Failure to acquire/renew/validate authority blocks MT5 connect and all submissions.

The exact ability to identify/validate account before connect is implementation-dependent and `NOT VERIFIED`.

### B. Multi-VPS transfer — proposal
1. Freeze new submissions on the old host through an authoritative control mechanism.
2. Obtain positive evidence that old engine stopped, MT5 disconnected, and its execution capability was revoked/fenced. Record host/process identity, account, authority epoch/token, timestamps and evidence.
3. Reconcile all non-final operations and broker state; ambiguous operations remain `UNKNOWN` and block unsafe retries.
4. Atomically transfer/advance account authority to the new host only after steps 1–3 are evidenced.
5. New host validates current authority epoch and only then connects/submits.

During control-plane/network partition, inability to prove old-host stop or revoke its authority means **no transfer and no new trading**. A manual operator may physically/administratively stop the old host, but a documented, independently verifiable confirmation and reconciliation are required. The design of authoritative ownership, fencing, and proof collection is `NOT VERIFIED` and must be selected before Gate 2. A local lock is never accepted as cross-VPS proof.

## 8. Position Ownership Model (P0-B)

A GoldBot Magic Range is a classification hint, not an instance/deployment ownership credential. If two deployments share a Magic Base/range, each may classify the other's position as its own. `adopt_foreign_magic=False` may prevent a particular adoption behavior but does **not** establish Instance-Level Ownership or prevent interference.

Minimum ownership key/record:
`(account_id, deployment_id, execution_authority_id, position_or_ticket_identity, ownership_state)` plus provenance, observed broker identifiers, strategy/creation operation reference where available, and timestamps. Identity normalization and broker ticket lifecycle must be verified against adapter behavior.

Ownership states: `OWNED_CONFIRMED`, `FOREIGN_CONFIRMED`, `UNOWNED`, `AMBIGUOUS`, `CLOSED/RESOLVED`. Never silently promote ambiguous/unowned positions to owned. No automatic management, close, flatten, or adopt of `FOREIGN_CONFIRMED` or `AMBIGUOUS` positions without a separately approved explicit policy and authenticated authority. Log observations and quarantine from automated destructive action.

**Restart/reconnect/migration:** reload durable ownership ledger; query broker histories and current state; reconcile identity and authority epoch. Preserve confirmed ownership only when identity evidence matches. A missing/contradictory ledger or broker observation yields `AMBIGUOUS`, not inferred ownership. On migration, old authority must be revoked before new host manages existing positions. Flatten scope must be an explicit set of confirmed-owned positions/orders; never “all account positions” by default. Mixed-instance flatten is prohibited absent a separately approved account-wide emergency policy.

## 9. Persistent Operation Idempotency (P0-C)

`run_id` is diagnostic/session metadata and **must not** form part of a durable operation's identity. Every trading intent receives a unique, durable, immutable `operation_id` before submission. Retries/restarts refer to the same operation ID; a new run cannot make an uncertain operation disappear. The ledger must enforce uniqueness and durable commit before broker submission.

Minimum persisted fields: `operation_id`, `account_id`, `deployment_id`, position/ticket identity (nullable only where not yet known, e.g. Entry), `operation_type`, requested/target volume or target parameters, canonical `payload_hash`, `created_at`, `status`, `attempt_count`, `broker_reference` when present, `last_reconciliation_at`. Also record authority identity/epoch, timestamps, request provenance, and append-only attempt/reconciliation audit events as needed; exact schema/migration is not yet authorized.

### State machine
`CREATED → SUBMISSION_PENDING → SUBMITTED → CONFIRMED → RESOLVED`; uncertain submission/response → `UNKNOWN → RECONCILIATION_REQUIRED → (CONFIRMED | RESOLVED | FAILED_FINAL | UNKNOWN)`. `FAILED_FINAL` only after definitive evidence/policy; no transition from UNKNOWN to a resubmittable state based merely on restart or timeout. State transitions are durable, validated, and audited. `RESOLVED` means the intent's final outcome is reconciled, not merely acknowledged by an API.

- **Crash:** before durable intent, no submit; after intent/before submit, reconcile before deciding; during/after send, mark/recover as UNKNOWN unless definitive evidence exists.
- **Timeout / unknown broker reply:** retain same operation ID, reconcile; no retry until authoritative evidence establishes prior action did not occur and retry is safe.
- **Duplicate request:** same logical request must map to same operation ID via stable caller/request identity or deduplication record; same ID with different payload hash is rejected and audited. Deduplication key derivation must be designed per caller and is `NOT VERIFIED`.
- **Broker duplicate detection:** internal idempotency does not guarantee broker recognition/deduplication.

Operation-specific semantics:
- **Entry:** stable client intent; reconcile active orders, order history, deals and positions before any resubmit.
- **Full close:** bind to confirmed position identity and target full volume; duplicate close must not close a newly opened/replaced position. Reconcile deal/order history and resulting position.
- **Partial close:** bind target volume and operation ID; compare exact deal evidence and volume delta; retry only residual amount after proving prior fill/remaining quantity.
- **Modify SL/TP:** bind target values/payload hash; read actual broker SL/TP; repeat only if observed state proves target not applied and retry is safe.
- **Pending cancel:** bind order ticket; reconcile active order, history, deals and possible fill before any repeated cancel or other action.
- **Flatten:** one durable parent intent plus uniquely identified child operations per confirmed-owned position/order; explicit scope snapshot and authority. Reconcile each child; never blindly replay entire flatten.

## 10. Operation-Specific Reconciliation (P0-D)

Reconciliation is idempotent, repeatable, timestamped and auditable: persist inputs/source observations, correlation identifiers, decision, evidence references, state transition and actor. Broker API success alone is not final confirmation.

| Operation | Minimum evidence to determine outcome |
|---|---|
| Entry | Active Orders, Order History, Deals and Positions, correlated to account/order/request where available |
| Full Close | Order/Deal History, volume change or position removal, and final position state |
| Partial Close | Deal History and exact matching of executed volume to requested reduction; resulting remaining volume |
| Modify SL/TP | Broker-observed actual SL and TP values for the exact position/order |
| Pending Cancel | Active Orders, Order History, Deals, and evaluation whether it filled during cancel race |
| Flatten | Final state of all positions and orders in explicit confirmed-ownership scope, plus every child operation outcome |

Pending cancel outcomes: `CANCEL_CONFIRMED` (history/state proves canceled and no fill); `FILLED` (deal/fill evidence); `STILL_LIVE` (active order remains); `UNKNOWN` (insufficient or contradictory evidence). Successful REMOVE response alone is not confirmation. Absence from Active Orders alone does not prove cancellation; the order may have filled between cancel request and broker response. `UNKNOWN` blocks unsafe retry and constrains execution authority/risk according to Section 12.

If required broker history is unavailable or retention/correlation is insufficient, mark `NOT VERIFIED`/`UNKNOWN`, retain evidence gap and escalate; do not infer finality.

## 11. Startup and Shutdown Lifecycle (P0-E)

The requested audit observation is that `runtime/live.py` connects to MT5 before bootstrap; this is `REPORTED`, not independently verified because source is absent. Bootstrap-only locking is too late if that sequence is true.

**Required startup order:** (1) initialize logging/config validation without trading; (2) identify host/deployment/account scope as possible; (3) acquire local lock and account-level authority; (4) verify authority/fencing and no unresolved unsafe ownership transfer; (5) initialize durable ledger and recover UNKNOWN operations; (6) reconcile ownership/broker state as permitted; (7) connect MT5; (8) validate connected account against authorized account; (9) start engine; (10) enable operation classes only when execution and risk states permit. Exact feasible ordering of account identity checks requires inspection. Lock failure means no MT5 connection and no trading operation.

**Required shutdown:** stop ingress/new submissions → stop engine scheduling → persist pending intent/state → reconcile where possible (otherwise retain UNKNOWN) → disconnect MT5 → confirm engine cannot submit → release local lock/authority in safe order → exit. Lock remains valid throughout connection and engine operation; release only after engine stop and disconnect. Exact order for authority revocation versus local lock release must be designed to avoid a gap and reviewed before implementation.

Crash/kill/termination/host restart: OS lock may be released by OS when process dies, but this does not prove broker request outcome or cross-host cessation. On restart, acquire authority first, recover ledger, reconcile UNKNOWN before retry. No stale-lock recovery based solely on elapsed time or missing heartbeat; inspect owner identity, authority epoch, process/host state and in-flight ledger, and require positive fencing/stop evidence. Host restart does not itself resolve outstanding operations.

## 12. Risk State and Execution State

Keep **Risk State** (strategy/account risk permission) distinct from **Execution Authority State** (who may submit and whether connection/authority is safe). Example execution states: `UNAUTHORIZED`, `ACQUIRING`, `ACTIVE`, `DEGRADED`, `REVOKING`, `REVOKED`, `UNKNOWN`. Risk states and their exact existing names are `NOT VERIFIED`; below is required policy, not a claim about current implementation.

| Condition | Entry | Modify | Close owned position | Flatten confirmed-owned scope |
|---|---:|---:|---:|---:|
| Authority ACTIVE; risk NORMAL; reconciled | Permit by strategy/risk | Permit by policy | Permit | Permit by explicit scope/policy |
| Risk HALTED, authority ACTIVE | Block | Block unless explicitly safety-critical policy permits | Permit only controlled risk-reducing action | Permit only controlled, confirmed-owned emergency action |
| Execution/ownership UNKNOWN or authority lost | Block | Block | No blind broker command; only explicitly authorized safe action after reconciliation/authority check | Block automatic broad flatten; preserve/reconcile and escalate |
| KILLED | Block | Block | No automatic action except a separately approved emergency policy | Human-approved, audited procedure only |

Fail-Closed means no new risk-increasing submissions and no unverified ownership/destructive action; it does not mean abandoning open positions. If authority and broker connectivity are valid, a separately specified, tested risk-reducing close policy for confirmed-owned positions may be allowed. Without reliable authority/connectivity/ownership, retain state, alert and require human intervention.

UNKNOWN execution state must never be reset to NORMAL by `acknowledge()` alone. KILLED is latched; default release requires human review, explicit authenticated approval, reason, evidence, and audit record. Auto-clear cannot clear execution uncertainty or KILLED. Risk lock and authority lock are independently evaluated; clearing one does not clear the other. Current `acknowledge()`/auto-clear behavior is `NOT VERIFIED`.

## 13. Database and Persistence Design

Proposed durable operation ledger with unique `operation_id`, validated transitions, payload-hash immutability, durable-before-submit ordering, attempt records, reconciliation evidence and audit trail. Transaction boundaries must ensure intent is committed before network send; submission outcome update follows, while crash between these steps is recoverable as UNKNOWN. Retention, backup, corruption recovery, concurrent access, migration and transaction guarantees depend on the actual persistence module and are `NOT VERIFIED`.

SQLite on a single host may support local durable storage subject to its configured mode, but **must not** be represented as cross-VPS distributed locking. Schema and migration are not produced or authorized in this revision. Before Gate 2, inspect actual persistence and specify schema changes, transaction semantics, backup/restore and compatibility/rollback plan.

## 14. Requirements Traceability Matrix

All requirements below are `DESIGN PROPOSAL`; status is `NOT VERIFIED` until implemented and evidenced. Test IDs are planned tests, not executed tests.

| REQ ID | Priority | Requirement | Source files (provisional) | Failure mode | Acceptance criteria | Test ID(s) | Layer | Evidence required | Status |
|---|---|---|---|---|---|---|---|---|---|
| REQ-A1 | P0 | Local process/host lock serializes cooperating same-host instances before connect | runtime/live.py, persistence/lock module (TBD) | Two local processes connect | Exactly one obtains lock; loser makes zero MT5 connect/submission calls | T01,T02 | Integration, Fault Injection | Process logs, lock owner record, mocked MT5 call trace | NOT VERIFIED |
| REQ-A2 | P0 | Account ownership is cross-host authoritative; local lock/SQLite never claimed distributed | live.py, bootstrap.py, authority/control-plane modules (TBD) | Two VPSs submit | At most one valid authority; absent proof old host stopped/fenced, new host cannot connect/submit | T03,T17 | Fault Injection, Windows/MT5 | Authority audit, host stop/fence evidence, broker logs | NOT VERIFIED |
| REQ-A3 | P0 | Lock/authority acquired before MT5 connect and retained until safe shutdown | runtime/live.py | Connect before lock; early release | Ordered event trace proves acquire < connect < stop < disconnect < release; failure gives zero connect | T04,T18 | Integration, Fault Injection | Timestamped lifecycle trace | NOT VERIFIED |
| REQ-B1 | P0 | Ownership includes account, deployment, authority, ticket and state; magic is not ownership | position_manager.py, ids.py, domain/events.py | Foreign/ambiguous position managed | Foreign/ambiguous never automatically adopted/managed/closed; ownership evidence required | T11,T12 | Unit, Integration | Ownership records and broker-call trace | NOT VERIFIED |
| REQ-B2 | P0 | Restart/reconnect/migration reload and reconcile ownership; flatten is scoped | position_manager.py, reconciler.py, engine.py | Restart or mixed-owner flatten | Only confirmed-owned scope can be acted on; ambiguity blocks destructive operation | T13,T14,T17 | Integration, Windows/MT5 | Ledger, scope snapshot, broker state and audit | NOT VERIFIED |
| REQ-C1 | P0 | Durable operation_id independent of run_id, immutable payload hash and required fields | order_coordinator.py, ids.py, persistence module | Restart loses/duplicates intent | Same operation survives new run; duplicate same payload deduped; altered payload rejected | T05,T06,T07 | Unit, Integration | DB rows, unique constraint/transition trace | NOT VERIFIED |
| REQ-C2 | P0 | UNKNOWN is reconciled before retry; crash/timeout outcomes persist | order_coordinator.py, reconciler.py, persistence, risk_engine.py | Duplicate submit after uncertain reply | No retry while UNKNOWN; restart retains operation and starts reconciliation | T05,T06,T07,T15 | Fault Injection, Integration | Injected send/timeout logs, ledger transitions | NOT VERIFIED |
| REQ-C3 | P0 | Close, partial close, modify, cancel and flatten use operation-specific identity | order_coordinator.py, position_manager.py, mt5_broker.py | Duplicate or stale target action | Each operation binds exact ticket/target; retries only proven safe residual | T08,T09,T10,T16 | Unit, Integration | Requests, tickets, deals, volume/SLTP observations | NOT VERIFIED |
| REQ-D1 | P0 | Reconciliation uses operation-specific broker evidence and is idempotent/audited | reconciler.py, mt5_broker.py, domain/events.py | Snapshot/API response mistaken final | Repeat same evidence yields same state; missing evidence remains UNKNOWN | T08-T10,T15,T16 | Unit, Integration | Raw broker observations, audit decisions | NOT VERIFIED |
| REQ-D2 | P0 | Cancel outcomes distinguish confirmed, filled, live, unknown | reconciler.py, mt5_broker.py | Cancel races fill | Correct four-state result; no retry based only on absent active order/API success | T10 | Fault Injection, Windows/MT5 | Order/deal history, active order snapshots, timestamps | NOT VERIFIED |
| REQ-E1 | P0 | Authority loss/MT5 disconnect blocks new entry and controls management safely | risk_engine.py, engine.py, runtime/live.py | Connection/control-plane loss | Entry blocked; open-position handling follows explicit safe policy; uncertainty not cleared by acknowledge | T15,T19 | Fault Injection, Windows/MT5 | State-transition log and broker-call trace | NOT VERIFIED |
| REQ-E2 | P0 | KILLED latch requires explicit human review; auto-clear/ack cannot clear uncertainty | risk_engine.py, app/engine.py | Accidental unlock | Acknowledge alone leaves latch and execution state unchanged; audited approval required | T20 | Unit, Integration | State transition/audit record | NOT VERIFIED |
| REQ-F1 | P0 | Host crash/restart cannot silently release account ownership or forget operation | live.py, persistence, authority module | Crash/host restart | Reacquire only after ownership check; unresolved operations reconciled; no time-only takeover | T05,T18,T21 | Fault Injection, Windows/MT5 | Crash artifacts, authority epochs, ledger and recovery trace | NOT VERIFIED |

## 15. Test Strategy and Test Matrix

No tests were run for this document. The following are **planned cases**, not PASS results. Tests must use isolated test accounts/mocks first; Windows/MT5 Demo tests require explicit authorization and must not use real trading.

| Test | Preconditions | Steps | Expected result | Evidence |
|---|---|---|---|---|
| T01 Two processes, one VPS | Lock implementation available; fake MT5 | Start two instances for same scope concurrently | One lock winner; loser has zero connect/submit calls | Both process logs, lock metadata, call trace |
| T02 Lock acquisition failure before connect | Force lock conflict/error | Start live entrypoint | Fail closed; no MT5 connect or operation | Event trace and fake adapter call count |
| T03 Two VPS same account | Authoritative ownership design deployed in test environment | Start A; attempt B; partition control plane; try takeover without stop proof | B cannot submit/connect as defined; partition does not grant takeover | Authority epochs, network fault log, both host traces |
| T04 Startup order | Instrument lifecycle events | Run startup with lock success and failure | acquire before connect; failed acquisition stops path | Ordered timestamps and MT5 call trace |
| T05 Crash during order send | Durable ledger; broker simulator with controllable response | Crash at send boundary, restart with same account | Operation retained as UNKNOWN/reconciliation-required; no blind resubmit | Crash injection point, DB before/after, broker simulator log |
| T06 Timeout after send | Simulator accepts then drops response | Submit then timeout; restart/new run | Same operation ID persists; reconcile before any retry | Request IDs, broker history, state transitions |
| T07 Restart with UNKNOWN / duplicate request | UNKNOWN ledger record | Restart; replay same logical request and a changed-payload duplicate | Same intent deduped; changed hash rejected; no retry before evidence | Ledger rows, audit, request trace |
| T08 Duplicate full close | Confirmed owned position and prior close operation | Submit same close twice; reconcile deals/position | One logical close effect; no accidental close of replacement position | Deal history, ticket identity, operation ledger |
| T09 Partial close and retry | Test position with known volume | Partial close; lose response; reconcile exact deal and remaining volume; retry if safe | No excess reduction; retry only proven residual | Deals, before/after volume, operation states |
| T10 Pending cancel simultaneous with fill | Simulator/demo order and controlled race | Send cancel; arrange fill before/around response; inspect all evidence | Outcome is FILLED/CANCEL_CONFIRMED/STILL_LIVE/UNKNOWN correctly; never infer from API response/absence alone | Active orders, history, deals, timestamps, reconciliation audit |
| T11 Foreign position | Position known to other deployment | Start GoldBot and enumerate | No auto-adopt, modify, close or flatten | Ownership decision and zero destructive broker calls |
| T12 Shared Magic Base | Two deployment identities, shared magic | Present positions from both | Magic does not confer ownership; ambiguous/foreign quarantined | Identity records and broker-call trace |
| T13 Flatten mixed ownership | Owned, foreign and ambiguous positions/orders | Request flatten under normal scoped policy | Only explicit confirmed-owned children considered; others untouched/escalated | Scope snapshot, child operation ledger, broker state |
| T14 Reconciliation after restart | Persisted non-final operation and broker evidence | Restart and run reconciliation repeatedly | Same evidence produces idempotent state/audit; gaps remain UNKNOWN | DB snapshots, raw evidence, repeated audit output |
| T15 MT5 disconnect / control-plane outage | Fault injection harness | Disconnect MT5 and separately partition control plane during open position | No new entry; no authority takeover absent proof; safe management policy enforced | State trace, network fault, broker calls |
| T16 Modify SL/TP unknown response | Existing confirmed position | Send modify; drop response; read back actual values | Confirm only broker-observed target; otherwise UNKNOWN, no blind conflicting retry | Request/response fault, actual SL/TP, ledger |
| T17 VPS migration | Old host owns scope and has pending/unknown operation | Attempt transfer with and without positive old-host stop/fence evidence | Without evidence fail closed; with approved proof reconcile before new authority | Old/new host records, authority audit, reconciliation evidence |
| T18 Lock release failure and host restart | Inject release failure; then restart host | Shutdown/crash and start recovery | No unsafe second authority; alerts/recovery evidence; no time-only unlock | OS/authority logs, host event, operation ledger |
| T19 Risk policy under uncertainty | Set execution UNKNOWN and open confirmed position | Attempt entry, modify, close, flatten; exercise allowed policy | Entry blocked; other actions follow explicit safe policy, no blind commands | Risk/authority state and call trace |
| T20 KILLED latch | KILLED state | Call acknowledge and auto-clear; then perform authorized review flow | Simple acknowledge/auto-clear cannot release; explicit approval is audited | State log and approval audit |
| T21 Host crash recovery | Pending operation, host termination/reboot | Restart and recover | Operation not forgotten; reconcile first; ownership not taken on timeout alone | OS event/log, database, authority, broker evidence |

### Test layers / count (planned)
- **Unit:** T07, T11/T12 logic portions, T20; additional isolated transition/property cases to derive from inspected implementation. Current concrete minimum: 4 test IDs with potentially multiple assertions; exact case count `NOT VERIFIED`.
- **Integration:** T01, T02, T04, T06–T09, T13–T14, T19–T20; mocks/fakes, persistent store and adapter boundaries. Exact runnable count `NOT VERIFIED`.
- **Fault Injection:** T03, T05–T10, T15–T18, T21; enumerate crash points and response-loss permutations after code inspection. Exact count `NOT VERIFIED`.
- **Windows/MT5 Demo:** T03, T04, T08–T10, T13–T19, T21 subset on Windows VPS and MT5 Demo, with approved account and raw broker logs. No demo execution evidence supplied; `NOT TESTED`.

Do not report a test as PASS from its definition. Capture command, environment/build identity, timestamps, raw logs/artifacts, expected-vs-actual, tester, and result for every executed case.

## 16. File-Level Change Scope

No source file was available to inspect. The following is a **provisional inspection/change matrix**, not confirmation that paths exist or must change. `Needs Inspection` is mandatory before scope is frozen.

| File/module | Classification | Likely responsibility / rationale |
|---|---|---|
| `runtime/live.py` | Must Change (provisional) | Startup ordering and lock before MT5 connect; shutdown lifecycle |
| `runtime/bootstrap.py` | May Change | Bootstrap must not be sole/late lock site; coordinate initialization/recovery |
| `app/order_coordinator.py` | Must Change (provisional) | Durable operation IDs, dedupe, submission state transitions |
| `app/engine.py` | May Change | Gate operation classes against authority/risk states |
| `app/reconciler.py` | Must Change (provisional) | Operation-specific, restart-safe reconciliation and audit |
| `app/position_manager.py` | Must Change (provisional) | Composite ownership, ambiguity, scoped management/flatten |
| `app/risk_engine.py` | May Change | Separate risk/authority states, latch and acknowledge policy |
| `app/ids.py` | May Change | Stable operation identity / deployment identifiers; inspect current semantics |
| `adapters/mt5_broker.py` | Must Change (provisional) | Expose needed histories, deals, actual SL/TP and order observations |
| `sqlite_store.py` or actual persistence module | Must Change (provisional) | Durable operation ledger/transactions/audit; actual module path unknown |
| `ports/execution.py` | May Change | Port contracts for durable operation identity and reconciliation evidence |
| `domain/events.py` | May Change | Typed operation, ownership, state and audit events |
| Account authority/control-plane module (TBD) | Needs Inspection | Cross-VPS ownership/fencing capability; existence unknown |
| Tests/fixtures and configuration/deployment docs (paths TBD) | Needs Inspection | Test harness, Windows deployment and authorized configuration impacts |

**Classification definitions:** Must Change = expected needed by proposed requirements, subject to inspection; May Change = only if existing interfaces cannot meet requirements; No Change = none can responsibly be assigned without source review; Needs Inspection = path/existence/role unverified. No module is marked No Change because no source was inspected. Gate 2 requires an exact inventory with all files assigned and reasons.

## 17. LOC and Effort Estimates

The v1 figures (400+250 LOC, 6 existing files, 17 tests) cannot be validated because v1 and source tree were absent. They are not carried forward as estimates. Any numerical LOC estimate now would be false precision.

| Work package | LOC estimate | Basis / uncertainty |
|---|---:|---|
| Startup/authority lifecycle (`runtime/live.py`, bootstrap) | NOT VERIFIED; estimate after code inspection | Existing entrypoint and lock support unknown |
| Durable ledger/idempotency | NOT VERIFIED | Persistence module/schema and transaction model unknown; migration may be required but unauthorized |
| Ownership/reconciliation/adapters | NOT VERIFIED | Broker adapter capabilities/history access unknown |
| Risk/engine state policy | NOT VERIFIED | Current state machine and APIs unknown |
| Tests by layer | NOT VERIFIED | Existing fixtures, test framework and current coverage unavailable |

At Gate 2, produce per-file estimates split into additions/modifications/deletions and test LOC, plus ranges and assumptions; inventory migrations separately. Test count must be computed from enumerated distinct cases (including fault permutations), not inferred from requirement or test-ID count. No implementation, migration or configuration work is authorized by these estimates.

## 18. Implementation Phases

Preserve the established separation: Control Plane, Windows Agent, Account Management, Strategy Management. Exact v1 phase mapping and phase definitions are `NOT VERIFIED`; retain rather than redesign them after obtaining v1. **Phase C and any implementation phase are not started by this revision.**

Recommended sequencing constraints (not a redefinition of phase ownership): first approve cross-VPS authority/fencing and persistence design; then implement only after explicit authorization; then integration/fault testing; then Windows/MT5 Demo validation. Strategy Management must not bypass SEA. Real trading remains prohibited until all gates including Gate 5 pass. Toobit Futures remains excluded.

## 19. Acceptance Gates

No gate is passed by this document alone.

- **Gate 1 — Architecture Review:** no unresolved contradiction in ownership, lock, idempotency, reconciliation; every P0 has requirement and measurable acceptance criteria. **Current: NOT APPROVED / NOT VERIFIED** pending review of actual v1/source and selection of cross-host authority/fencing design.
- **Gate 2 — Implementation Authorization:** exact file scope, migration, LOC and tests; cross-VPS concurrency prevention chosen; unproven limitations disclosed; explicit human approval. **Current: NOT READY** because source/archive/v1 and authority design evidence are missing. No work starts absent explicit authorization.
- **Gate 3 — Implementation Review:** only after explicit user authorization; no open P0; all required tests executed with evidence. **NOT STARTED.**
- **Gate 4 — Windows/MT5 Demo Validation:** actual Windows VPS and MT5 Demo tests for crash, timeout, restart, reconnect and migration; raw report/evidence. **NOT STARTED / NOT TESTED.**
- **Gate 5 — Real Trading Readiness:** no open P0; all safety criteria verified; residual risks explicitly accepted; independent human approval recorded. **NOT READY.**

## 20. Residual Risks

1. No source or v1 plan was available; actual implementation, module names, current behavior and prior decisions beyond the prompt are unverified.
2. Cross-VPS fencing/authority design is unresolved. If the prior host cannot be positively stopped or fenced, safe migration cannot be claimed and execution must remain closed.
3. Broker API/history semantics, event retention, correlation identifiers and MT5 Demo behavior are unverified; reconciliation may remain UNKNOWN where evidence is insufficient.
4. Database durability, concurrency, backup/restore, migration and corruption recovery are unverified.
5. Position identity, ticket reuse/change behavior, magic assignment and multi-instance deployment practices are unverified.
6. Real-trading readiness cannot be inferred from design or Demo tests alone; independent approval and residual-risk acceptance remain required.

## 21. Evidence Register

| Claim/evidence | Required source | Status | How to produce/verify |
|---|---|---|---|
| Baseline archive identity/hash | Exact ZIP | `NOT VERIFIED` (hash reported) | Provide archive; compute SHA-256 and retain command output |
| v1 decisions and figures | v1 Markdown | `NOT VERIFIED` | Provide file; compare each claim and record deltas |
| Live connect-before-bootstrap ordering | `runtime/live.py`, `runtime/bootstrap.py` | `REPORTED`, not independently verified | Inspect exact call path; attach line-numbered review excerpt and call-order test |
| Existing lock / SQLite behavior | Source, runtime config, OS | `NOT VERIFIED` | Inspect lock scope and storage path; two-process test on target OS |
| Cross-VPS authority/fencing | Architecture and operational proof | `NOT VERIFIED` | Specify mechanism; test partition, old-host stop/revoke, epochs and takeover denial |
| Position ownership / magic behavior | Source + broker observations | `NOT VERIFIED` | Inspect filtering and test shared-magic deployments |
| Operation persistence/state machine | Persistence source/schema | `NOT VERIFIED` | Inspect transaction semantics; crash/restart fault tests |
| Reconciliation capability | MT5 adapter/API histories | `NOT VERIFIED` | Demonstrate evidence retrieval/correlation per operation; retain raw observations |
| Risk latch/acknowledge behavior | Risk engine source/tests | `NOT VERIFIED` | Inspect transitions and run acknowledge/auto-clear tests |
| Test results | CI/test output and Demo logs | `NOT TESTED` | Execute authorized matrix; preserve raw output, environment and result |

## 22. Change Log

| Version | Change |
|---|---|
| v2.0 | Controlled document revision. Added explicit local-vs-account lock scope and fail-closed multi-VPS handover; composite deployment-level position ownership and ambiguity rules; durable operation identity/state machine and operation-specific retry semantics; reconciliation evidence requirements including cancel race outcomes; pre-MT5 startup lock lifecycle; separate risk/authority states and latched KILLED policy; traceable requirements/tests; provisional file scope and evidence-bounded estimates; explicit unpassed gates. No source, database, configuration or executable artifacts changed. |
| Decision preservation | Baseline name/hash, Single Execution Authority, phased separation, no Phase C before gates, real trading only after safety gates and Demo Validation, and Toobit Futures exclusion retained as required. Their independent verification is pending. |
| Evidence limitation | Source tree, v1 plan, archive and test outputs were absent; therefore prior counts/LOC, actual file roles and reported live startup ordering are not independently verified. No test or gate is marked PASS. |
