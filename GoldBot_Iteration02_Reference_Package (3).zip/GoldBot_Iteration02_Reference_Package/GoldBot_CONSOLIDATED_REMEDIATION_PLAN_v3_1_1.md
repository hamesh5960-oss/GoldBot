# GoldBot — برنامهٔ یکپارچهٔ اصلاح و ارتقای کنترل‌شده — Revision v3.1.1

نسخهٔ نهایی اصلاح سند معماری (Document Revision — بدون پیاده‌سازی) — اصلاح هدفمند FIX-01..FIX-08 بر پایهٔ FROZEN v3.1

---

| مورد | مقدار |
|---|---|
| نسخه | **3.1.1 — 2026-11-23 — جایگزین `GoldBot_CONSOLIDATED_REMEDIATION_PLAN_v3_1_FROZEN.md` (اصلاح هدفمند FIX-01..FIX-08؛ ساختار و شماره‌گذاری v3.1 حفظ شد)** |
| نوع سند | Document Revision فقط. هیچ Source، Migration، Config، تست، Deployment یا اتصال MT5 تغییر/اجرا نشد. |
| Baseline | `GoldBot_Final_Release_v8.2.5.zip` · sha256 `3baed37dc55b44a958229f115b7276a7c959aae7c17dab140b3da1250d930fc7` |
| دامنهٔ Baseline | صرفاً مرجع شناسایی نسخه و شواهد قبلی. دسترسی به فایل Baseline در این مرحله وجود نداشت (UNVERIFIED — به‌صورت صریح گزارش شده است). هیچ مجوز تغییر/بازسازی Baseline صادر نشد. |
| معماری | Single Execution Authority — حفظ‌شده از v1/v2/v3؛ Dual Engine وارد نشد |
| سند تطبیق | `GoldBot_v3_1_vs_v3_1_1_Clause_by_Clause_Traceability.md` |
| گزارش اعتبارسنجی | `GoldBot_v3_1_1_Final_Validation_Report.md` |
| ماتریس الزامات (حفظ‌شده از v3) | `GoldBot_REQUIREMENTS_AND_TEST_MATRIX_v3.csv` — ۲۰ REQ + ۳۶ TEST + ۳ DEFERRED — UNCHANGED در این نسخه |
| Gate 1 — Architecture Review | 🟠 **CONDITIONAL PASS — DOCUMENT CONSISTENCY ONLY** — فقط برای انسجام مستندات پس از FIX-01..08؛ محدودیت‌های اجرایی باز؛ نه اثبات کارکرد. |
| Gate 2 — Implementation Authorization | ⛔ **NOT APPROVED** — نیازمند مجوز صریح انسانی و تحقق شروط رسمی. هیچ تضمین آمادگی Real Trading. |
| Gate 3 / 4 / 5 | ⛔ NOT STARTED — هیچ‌کدام آغاز نشد. |

**برچسب شواهد:** `VERIFIED` (از سورس یا اجرای مشاهده‌شده) · `REPORTED` (نقل از سند قبلی، تأیید مستقل‌نشده) · `DESIGN PROPOSAL` (اجرا نشده) · `NOT VERIFIED` (شاهد کافی نیست) · `NOT TESTED` (آزمون نشده).

**قاعدهٔ حاکم:** اصلاح سند = رفع نقص در کد نیست. تعریف Invariant = اثبات تحقق آن در Runtime نیست. تعریف Test = اجرای موفق آن نیست. در این نسخه صفر تست PASS.

---

## ۱. خلاصهٔ اجرایی

### ۱.۱ واقعیت مرکزی

MT5 هیچ primitive مالکیت سروری ندارد. سطح API موجود (VERIFIED، `adapters/mt5_broker.py`): `initialize`, `shutdown`, `account_info`, `terminal_info`, `order_send`, `orders_get`, `positions_get`, `history_deals_get`, `history_orders_get`, `signal_subscribe`, `symbol_info`, `symbol_info_tick`, `symbol_select`, `last_error`. نه fencing token، نه CAS، نه قفل تک‌نشست، نه OCO.

نتیجه: انحصار اجرایی یک حساب روی دو VPS با ابزار نرم‌افزاری GoldBot قابل اثبات نیست. تنها چیزی که واقعاً انحصار می‌سازد **سلب دسترسی اجرایی از Host قبلی** است — نه فایل Lock محلی، نه boot_epoch، نه تشخیص Process.

### ۱.۲ سه سطح قفل (R-01)

| سطح | ماهیت | محدودهٔ تضمین | وضعیت |
|---|---|---|---|
| Process-Level Lock | mutex درون‌فرایند | همان Process | DESIGN PROPOSAL — برای مسئلهٔ چند‑VPS بی‌اثر |
| Host-Level Lock | قفل انحصاری OS روی یک فایل | همان یک ماشین | DESIGN PROPOSAL — تنها سازندهٔ Z-1 |
| Account-Level Execution Ownership | اینکه کدام ماشین مجاز به ارسال سفارش روی این حساب است | کل حساب، حتی روی دو VPS | **NOT VERIFIED** — در MT5 primitive اثباتی ندارد |

صریح: SQLite محلی و OS Lock محلی نه Distributed Lock هستند و نه Account-Level Ownership. در این سند هیچ‌گاه چنین نامیده نمی‌شوند.

### ۱.۳ وضعیت امروز — قفل موجود در Launcher (بازبینی‌شده در v3)

`scripts/start_live.ps1` یک قفل واقعی OS دارد: `[System.IO.File]::Open(..., FileShare::None)` روی `var/live.lock`، با exit 3 روی شکست، و یک گارد ثانویه برای Processهایی که اسکریپت را دور می‌زنند (`Get-CimInstance Win32_Process` روی `run_goldbot.py live` / `-m goldbot live`). (VERIFIED)

اما این قفل کافی نیست:

| # | شکاف | شاهد |
|---|---|---|
| G-1 | قفل در Launcher است، نه در Engine؛ مسیر `python -m goldbot live` یا `goldbot live` که مستقیماً اجرا شود به قفل Engine دسترسی ندارد و گارد ثانویه یک check-then-act است | `start_live.ps1:64-77` (VERIFIED) |
| G-2 | قفل پیش از ساخت `MT5Broker` و `connect()` در `live.py` نیست (در v2 به‌اشتباه «قفل وجود ندارد» نوشته شده بود؛ درست این است: قفل وجود دارد ولی در لایهٔ اشتباه و در زمان اشتباه) | `live.py:215`, `live.py:224` (VERIFIED) |
| G-3 | قفل هیچ‌چیز دربارهٔ VPS دوم نمی‌گوید | ساختار فایل محلی (VERIFIED) |

### ۱.۴ آنچه در v3 اصلاح شد و در v3.1 تثبیت/گسترش یافت

| ID | اصلاح |
|---|---|
| R-01 | سه سطح قفل، مرز تضمین هر یک، و انتقال مالکیت با پنج شرط اثبات + Fail-Closed |
| R-02 | مالکیت Position مستقل از Magic؛ شش جزء هویت؛ سیاست Fail-Closed برای پنج دسته |
| R-03 | operation_id مستقل از Run ID؛ ثبت Durable؛ UNKNOWN پس از Restart زنده می‌ماند |
| R-04 | Reconciliation per-operation با شاهد و نتیجهٔ نهایی جدا برای هر شش نوع |
| R-05 | محل اخذ/حفظ/آزادسازی Lock در چرخهٔ واقعی + پوشش Crash/Timeout |
| R-06 | جداسازی کامل Execution State از Risk State |

**v3.1** پانزده اصلاح P0/P1 (۸ P0 + ۷ P1) را بر ساختار v3 اعمال کرده (§۴ و §۵ این سند). هیچ‌کدام در سطح runtime اصلاح نشده‌اند. Source تغییر نکرده است. **v3.1.1 (این نسخه)** هشت اصلاح هدفمند FIX-01..FIX-08 را بر پایهٔ `GoldBot_CONSOLIDATED_REMEDIATION_PLAN_v3_1_FROZEN.md` اعمال کرده؛ ساختار و شماره‌گذاری v3.1 حفظ شده است (مراجع دقیق هر FIX: سند تطبیق v3.1↔v3.1.1).

---

### ۱.۵ یافته‌ها و اولویت‌ها (F-01..F-22 — نقل‌شده از v3 §4)

> **دربارهٔ برچسب‌ها:** جدول زیر عیناً از v3 نقل شده و برچسب‌های `VERIFIED` آن مربوط به بازبینی v3 است. طبق §2 و §23 این نسخه، به دلیل عدم دسترسی به سورس در این مرحله، **کلیهٔ این ادعاها عملاً `REPORTED` محسوب می‌شوند** و هیچ‌کدام در v3.1 مستقل تأیید نشدند.

| ID | یافته | شاهد | برچسب (نقل از v3) | P |
|---|---|---|---|---|
| F-01 | هیچ قفل در لایهٔ Python نیست؛ دو Process هم‌زمان هر دو نوشتند و هر دو exit 0 | evidence/P09: concurrent_returncodes=[0,0] · rows_after_concurrent A=20 B=20 | VERIFIED | P0-A |
| F-02 | قفل OS موجود در Launcher است، با گارد ثانویهٔ process-scan | start_live.ps1:19-48, :64-77 | VERIFIED | P0-A |
| F-03 | MT5Broker(...) و connect() پیش از build_components() | live.py:215, :224, :314 | VERIFIED | P0-E |
| F-04 | Magic تابع (slot, magic_base) است، نه Deployment. باند 13_000_000…13_009_000؛ با base 7300: zones_m15=13_005_391، numeric_m5=13_000_163، adopted=13_005_008 | ids.py:19-31 (crc32-slot-v1) | VERIFIED | P0-B |
| F-05 | adopt_foreign_magic پیش‌فرض True — هر پوزیشن بی‌مالک adopt می‌شود | position_manager.py:358, :381 | VERIFIED | P0-B |
| F-06 | مالکیت Position در dict درون‌Process | position_manager.py:415 | VERIFIED | P0-B |
| F-07 | کلید Idempotency شامل run_id؛ run_id هر Boot uuid4 | order_coordinator.py:277 · bootstrap.py:244 · evidence/P05: key_A≠key_B | VERIFIED | P0-C |
| F-08 | OrderState درون‌حافظه؛ پس از Restart خالی | order_coordinator.py:40 · evidence/P02 | VERIFIED | P0-C |
| F-09 | Ledger بروکر dict درون‌حافظه، prune ۱۲۰ ثانیه | mt5_broker.py:906 · close_dedupe_s=120.0 | VERIFIED | P0-C |
| F-10 | Reconciler فقط positions() می‌خواند | reconciler.py:43 | VERIFIED | P0-D |
| F-11 | Cancel رد‌شده هم RETCODE_CANCELED برمی‌گرداند؛ bool نادیده گرفته می‌شود | mt5_broker.py:816-823 · evidence/P07 | VERIFIED | P0-D |
| F-12 | modify کلید Idempotency را نادیده می‌گیرد؛ دو نوشتن مخالف هر دو پذیرفته شدند | mt5_broker.py:859-880 · evidence/P08 | VERIFIED | P1 |
| F-13 | check_state() فقط risk_state == NORMAL | risk/checks.py:11-13 | VERIFIED | P0-D |
| F-14 | یک acknowledge() با سفارش نامعلوم ورود را باز کرد | evidence/P04 | VERIFIED | P1 |
| F-15 | KILLED با auto_clear=True فعال می‌شود، خلاف کامنت :242-244 | risk_engine.py:300-306 · evidence/P06 | VERIFIED | P1 |
| F-16 | هیچ هویت Deployment/Instance در Config یا Source نیست | grep deployment|instance_id|agent_id|host_id ⇒ ۰ | VERIFIED | P0-B |
| F-17 | _flatten روی همهٔ Ticketها حرکت می‌کند | engine.py:1914-1930 | VERIFIED | P0-B |
| F-18 | دو Partial Close ۰٫۵ یک پوزیشن ۱٫۰ را کامل بستند؛ دفتر ۱٫۰ گزارش داد | evidence/P08 | VERIFIED | P0-C |
| F-19 | Control Plane وجود ندارد؛ تنها heartbeat فایل + پنل FastAPI که هم Backtest و هم Live را سرو می‌کند | app/heartbeat.py (۱۵۳) · app/health.py (۲۳۸) · web/app.py (۵۶۴، مسیر /api/run و /api/journal) | VERIFIED | P2 |
| F-20 | دو Strategy Slot موجود: zones_m15، numeric_m5 | config/strategies/zones.toml:2، numeric.toml | VERIFIED | — |
| F-21 | v1 «۹۷٪» و «۲–۳ هفته» را بدون محاسبه آورده بود | بازبینی v1 | VERIFIED | — |
| F-22 | لبهٔ استراتژی اثبات‌شده ندارد؛ بک‌تست ۱۲۰ روزه PF 0.95 | KNOWN-ISSUES.md بند ۱ | REPORTED | خارج از دامنه |

---

## ۲. یکپارچگی Baseline

| مورد | مقدار | برچسب |
|---|---|---|
| ZIP / sha256 / ۲۹۲ ردیف | `GoldBot_Final_Release_v8.2.5.zip` · `3baed37d…d930fc7` · ۰ خطا (طبق v3.0) | REPORTED — تأیید مجدد در این نسخه ممکن نبود (فایل در دسترس نبود) |
| BUILD-INFO | 8.2.5 · git_commit 894560d · built_utc 2026-11-21T01:18:50Z | REPORTED |
| حجم سورس | ۱۹۱ فایل `.py` · ۴۱٬۷۶۵ خط · ۲۹۳ ورودی ZIP | REPORTED |
| Test Suite | 1080 passed, 4 skipped, 1 xfailed (evidence/P10) | REPORTED |
| ZIP ورودی اعلامی (`…/GoldBot2/…zip` — لینک Baseline جایگزین) | **404 — قابل دریافت نیست.** مخزن `hamesh5960-oss/GoldBot2` از بررسی میزبان در دسترس نبود | NOT VERIFIED |
| سورس در پایان این بازنگری | **دسترسی نداشت** — `sha256sum -c SHA256SUMS` قابل اجرا نبود | NOT VERIFIED |
| کلیهٔ ادعاهای F-01..F-22، P00..P11، T-xx و LOC در سند v3.0 | نقل از سند v3.0؛ بدون بازتأیید مستقل در این نسخه | REPORTED (مگر آنکه خود v3.0 آن را از سورس/اجرا گرفته باشد که آن نیز REPORTED می‌ماند مادامی که سورس در دسترس نباشد) |

> ⚠️ **گزارش صریح فقدان ورودی:** فایل‌های زیر در Workspace و محیط بررسی **موجود نبودند**. محتوای آن‌ها حدس زده نشده و تطبیق ساختگی تولید نگردیده است:
> - `GoldBot_CONSOLIDATED_REMEDIATION_PLAN_v3.md` — در متن کامل سند v3.0 به‌صورت درج‌شده توسط کاربر در دسترس بود و مبنای بازنویسی قرار گرفت.
> - `GoldBot_v2_vs_v3_Clause_by_Clause_Traceability.md` — موجود نبود؛ UNRESOLVED.
> - `GoldBot_v3_Final_Validation_Report.md` — موجود نبود؛ UNRESOLVED.
> - `GoldBot_REQUIREMENTS_AND_TEST_MATRIX_v3.csv` — موجود نبود؛ فقط خلاصهٔ عددی آن در متن v3.0 (۲۰ REQ + ۳۶ TEST + ۳ DEFERRED) در دسترس است.
> - `GoldBot_Final_Release_v8.2.5.zip` — موجود نبود؛ UNRESOLVED.
>
> **ورودی‌های v3.1.1 (این نسخه) — تطبیق‌شده:** `GoldBot_CONSOLIDATED_REMEDIATION_PLAN_v3_1_FROZEN.md` (SHA256 `29a96b75b648b580217b2fa73e6b4b90a98832538869ed1f963d08db6950ac50`) و `GoldBot_v3_vs_v3_1_Clause_by_Clause_Traceability_FROZEN.md` (SHA256 `9251e2b355ab74ece13abd180ae5d432874f05cd9f1461809a0011b2c7fe05b6`) — هر دو با `sha256sum` تأیید شدند. Baseline ZIP و CSV همچنان غایب‌اند (E-BASE-01 / CSV — باز؛ FIX-08).

---

## ۳. دامنه و خارج از دامنه

**در دامنه:** اصلاح طراحی پانزده مورد P0/P1 (۸ P0 + ۷ P1) این نسخه؛ مدل مالکیت؛ چرخهٔ عمر Lock؛ Idempotency پایدار Intent؛ ماتریس تصمیم واحد Ownership×Execution×Risk؛ ماشین حالت کامل Operation؛ Reconciliation؛ تفکیک Risk/Execution State؛ Database of Record؛ دامنهٔ فایل؛ برآورد مشروط؛ Gateها.

**خارج از دامنه:** تغییر Source · Migration · تست اجرایی · Deployment · اتصال به حساب واقعی · ارسال سفارش · Phase C · تغییر «مغز معاملاتی» (سیگنال، اندیکاتور، S/R، پارامترهای Risk Engine، استراتژی‌ها) · بازطراحی Dual Engine · Toobit Futures (صفر ارجاع) · برآورد زمانی به هفته/ماه.

---

## ۴. اصلاحات P0 (اجباری) — وضعیت در v3.1

> هر هشت مورد P0 از نظر **متن/طراحی** تعیین تکلیف شده‌اند (وضعیت سندی — **نه حل فنی**؛ FIX-08). «تعیین تکلیف متنی» ≠ «حل فنی اثبات‌شده». جایی که شاهد لازم در دسترس نبود، موضوع **UNRESOLVED / OPEN** نگه داشته شده — نه با پاسخ فرضی بسته شده. هیچ P0 بدون شاهد لازم «بستهٔ فنی» اعلام نشده است.

### P0-1 — یکپارچه‌سازی سیاست Ownership و Reduce-Only

**مراجع v3:** §8 و §12.
**تناقض v3.0:** §8 برای پوزیشن UNKNOWN/AMBIGUOUS هرگونه مدیریت، Close، Modify و Flatten خودکار را ممنوع می‌کرد؛ §12 در برخی وضعیت‌های Execution UNKNOWN عملیات کاهش ریسک را مجاز می‌دانست؛ `--emergency-all` نیز ممکن بود Ownership Gate را دور بزند.

**الزامات اصلاح:**
1. ✅ یک ماتریس تصمیم واحد برای ترکیب Ownership State، Execution State و Risk State تعریف شد.
2. ✅ مالکیت مبهم یا UNKNOWN با برچسب Reduce-Only هیچ مجوز نوشتن دریافت نمی‌کند.
3. ✅ عملیات کاهش ریسک فقط روی پوزیشنی مجاز است که مالکیت آن مستقل و معتبر اثبات شده باشد (OWNED).
4. ✅ هر اختلاف DB/Broker که مالکیت را مخدوش می‌کند، پیش از هر نوشتن به UNKNOWN/AMBIGUOUS منتقل می‌شود.
5. ✅ `--emergency-all` مسیر عادی دور زدن Ownership Gate نیست.
6. ✅ مداخلهٔ اضطراری انسانی از ExecutionAuthority عادی تفکیک شد و نیازمند تأیید صریح، شناسهٔ پوزیشن، هویت اپراتور و Audit Trail است.
7. ✅ تفاوت میان «توقف ریسک جدید» و «اجازهٔ مدیریت پوزیشن» روشن نگه داشته شد.

**خلاصهٔ تصمیم:** منبع حقیقت ترکیبی، **§6 (ماتریس تصمیم واحد)** است که هر دو §10 (مالکیت) و §14 (مجوز) به آن ارجاع می‌دهند. ستون‌ها: Ownership (OWNED / FOREIGN_* / AMBIGUOUS / UNKNOWN) × Execution (CLEAN / PENDING / UNKNOWN_OPERATION / RECONCILE_STALE) × Risk (NORMAL / SOFT_HALT / HALTED / KILLED / QUARANTINE). `--emergency-all` فقط در ردیف Flatten با Ownership=OWNED (یا با فرایند مداخلهٔ انسانی §14.3) اثر دارد و هرگز ردیف‌های AMBIGUOUS/UNKNOWN را باز نمی‌کند.

**وضعیت:** ✅ **RESOLVED (سندی)** — تناقض متنی برداشته شد؛ اجرای Runtime و اثبات‌پذیری آن به Gate 3 و Gate 4 موکول است.

---

### P0-2 — محدودیت واقعی انتقال دستی بین VPSها (Z-3)

**مراجع v3:** §7.1، §7.2، §7.6.
**مشکل v3.0:** Z-3 به‌عنوان تضمین فنی انحصار معرفی شده بود.

**الزامات اصلاح:**
1. ✅ Z-3 صریحاً **Operational Risk Reduction Procedure** معرفی شد — نه تضمین فنی.
2. ✅ نبود Process در Host قبلی به‌تنهایی اثبات سلب دسترسی تلقی نمی‌شود.
3. ✅ وضعیت تمام Terminalهای MT5، Taskها، Processها و مسیرهای مستقل اجرای مرتبط باید بررسی شود.
4. ✅ Credential Revocation و Session Revocation از یکدیگر تفکیک شدند.
5. ✅ اگر نشست معتبر یا مسیر اجرای ناشناخته باقی بماند، انتقال مجاز نیست.
6. ✅ تأیید اپراتور و در صورت امکان تأیید مستقل نفر دوم در گواهی انتقال ثبت می‌شود.
7. ✅ Z-3 هیچ ادعای تضمین Account-Level Ownership ندارد.
8. ✅ در نبود شواهد کافی، سیستم Fail-Closed می‌ماند.

**خلاصهٔ تصمیم:** شرایط پنج‌گانهٔ P-1..P-5 (§9.2) با افزودن **نه گام Z3-1..Z3-9** (§9.2) تکمیل شد: شمارش Terminalها، فهرست Taskها، فهرست Processها/محل‌های اجرای مرتبط، فهرست نشست‌های باقی‌مانده، تفکیک Revocation Credential/Session، امضاء اپراتور + نفر دوم. شکست هر گام ⇒ انتقال رد و Z-4. هیچ سرویس توزیع‌شده یا پروتکل جدیدی طراحی نشد.

**وضعیت:** ✅ **RESOLVED (سندی)** — محدودیت واقعی تعریف شد؛ اجرای عملیاتی Z-3 NOT TESTED (Gate 4).

---

### P0-3 — اصلاح ادعاهای boot_epoch و Fencing

**مراجع v3:** §7.5، §7.6، §20.

**الزامات اصلاح:**
1. ✅ boot_epoch به‌عنوان ابزار **تشخیص، Provenance و Audit** معرفی شد — نه Fencing واقعی در سطح MT5.
2. ✅ صریح ذکر شد: **MT5 Broker Epoch داخلی GoldBot را enforce نمی‌کند.**
3. ✅ منبع مرجع افزایش نسل مشخص شد (§9.7): افزایش boot_epoch فقط در Startup با قفل انحصاری Host-Level انجام می‌شود؛ Host Restart با Startup جدید نسل را افزایش می‌دهد. **FIX-06:** مقایسهٔ `(boot_epoch, generation)` ذخیره‌شده به‌تنهایی DB Restore را تشخیص نمی‌دهد (هر دو مقدار با همان Backup به عقب برمی‌گردند)؛ تشخیص نیازمند مرجع مستقل تک‌صعودی خارج از مجموعهٔ Backup است که در Scope فعلی تعریف/تأیید نشده ⇒ **ادعای تشخیص قطعی حذف شد**؛ اختلاف مشاهده‌شده ⇒ Fail-Closed؛ OPEN-04 باز است.
4. ✅ VM Suspend/Resume تا اجرای آزمون واقعی **NOT TESTED** باقی ماند.
5. ✅ هیچ ادعای توقف قطعی Process قدیمی فقط با تغییر boot_epoch مطرح نشد — صریحاً رد شد.
6. ✅ Race بین بررسی مجوز و ارسال واقعی سفارش به‌عنوان محدودیت باقی‌مانده ثبت شد (§9.7 — **OPEN-06**).
7. ✅ اگر محدودیت قابل حذف نیست، به‌صورت **Open Risk** باقی ماند (OPEN-06 در §21 و §22).

**وضعیت:** ✅ **RESOLVED (سندی)** — ادعاها اصلاح شد؛ آزمون Suspend/Resume و رفع Race **NOT TESTED / OPEN-06**. **FIX-06 (v3.1.1):** ادعای تشخیص قطعی Restore حذف شد — **OPEN-04 باز می‌ماند.**

---

### P0-4 — تکمیل معنای ماشین حالت Operation

**مرجع v3:** §9.

**الزامات اصلاح:**
1. ✅ وضعیت API Submission از Broker Acceptance تفکیک شد.
2. ✅ Broker Acceptance با Trade Execution یکسان نیست.
3. ✅ Partial Execution به‌صورت مستقل مدل شد.
4. ✅ رد قطعی از وضعیت نامعلوم تفکیک شد.
5. ✅ گذارهای مجاز و غیرمجاز برای هر وضعیت تعریف شدند.
6. ✅ شواهد لازم برای انتقال به وضعیت نهایی مشخص شد.
7. ✅ حجم درخواستی، حجم اجراشده و حجم باقی‌مانده مستقل شدند.
8. ✅ Order ID، Deal ID و Position Identifier در مدل داده قابل ردیابی شدند.
9. ✅ Partial Close و Full Close با وضعیت مبهم CONFIRMED یکسان نشدند.
10. ✅ Retcodeها بدون بررسی معنایی به REJECTED_FINAL نگاشت نمی‌شوند.

**خلاصهٔ تصمیم:** ماشین حالت ۸حالتهٔ v3 §9.3 به **۱۰ حالت** ارتقا یافت (§11.3): `CREATED → SUBMISSION_PENDING → API_ACCEPTED → PARTIALLY_FILLED → EXECUTED / REJECTED_FINAL / UNKNOWN → RECONCILIATION_REQUIRED → RESOLVED` + `CANCELLED`. جدول گذارها، ماتریس شواهد نهایی، و قاعدهٔ تفکیک حجم‌ها (Requested/Executed/Remaining) و شناسه‌ها (order_id/deal_id/position_id) اضافه شد. نام وضعیت‌های Canonical حفظ شدند و معنای عملیاتی گسترش یافت. **FIX-03 (v3.1.1):** مرجع واحد گذارها + بازیابی Restart در §11.3 نهایی شد؛ `FAILED_FINAL`→`REJECTED_FINAL`، `CONFLICT`→رویداد `IntentConflictDetected`، `CONFIRMED`/`RESOLVED_ABSENT`→لایهٔ Reconciliation Outcome؛ وضعیت‌های پایانی برگشت‌ناپذیر: `RESOLVED` · `CANCELLED` · `REJECTED_FINAL`.

**وضعیت:** ✅ **RESOLVED (سندی)** — معنای ماشین حالت کامل شد؛ اجرای Runtime و Acceptance Criteria به Gate 3 موکول است.

---

### P0-5 — اصلاح مدل مالکیت Position

**مرجع v3:** §8.

**الزامات اصلاح:**
1. ✅ مشخص شد مالکیت در سطح **Deployment** تعریف می‌شود؛ Instance هویت اجرایی هر Boot است و با Deployment یکی فرض نشد.
2. ✅ قاعدهٔ OWNED حداقل شامل: هویت Account (login+server)، Deployment، هویت پایدار Position، Magic و سابقهٔ ایجاد است.
3. ✅ `opening_operation_id` برای اثبات مالکیت **شرط سوم قاعدهٔ OWNED** شد؛ nullable بودن آن تعیین تکلیف شد: ردیف بدون آن ⇒ **UNKNOWN** (پوزیشن‌های قدیمی/adopt‌نشده دستی ⇒ دستهٔ FOREIGN_EXTERNAL یا UNKNOWN، نه OWNED).
4. ✅ کلید اصلی جدول `position_ownership` بررسی و اصلاح طراحی شد: `PRIMARY KEY (account_login, server, ticket)` — از `ticket INTEGER PRIMARY KEY` تک‌ستونی (که چند حساب/سرور را نمی‌پوشاند) به کلید مرکب.
5. ✅ Ticket عملیاتی از Position Identifier پایدار MT5 تفکیک شد (§10.3).
6. ✅ ارتباط Position با Order و Dealهای ایجادکننده/تغییردهنده مشخص شد (§10.3: جدول پیوند `position_order_deal`).
7. ✅ وضعیت مالکیت در Restart، Reconnect، Partial Close، Full Close و Migration تعریف شد (§10.6).
8. ✅ هر دادهٔ ناقص یا متناقض به UNKNOWN/AMBIGUOUS می‌رود.
9. ✅ Magic به‌تنهایی هرگز دلیل کافی OWNERSHIP نیست.

**خلاصهٔ تصمیم:** جدول `position_ownership` با کلید مرکب و ستون‌های `ticket_broker` / `position_id_mt5` / `opening_order_id` / `opening_deal_id` بازنویسی شد. قاعدهٔ OWNED سه‌شرطی به **چهارشرطی** ارتقا یافت: ردیف وجود دارد ∧ deployment_id برابر ∧ magic واقعی = recorded_magic ∧ `opening_operation_id` معتبر و قابل بازیابی. نقص هر شرط ⇒ UNKNOWN.

**وضعیت:** ✅ **RESOLVED (سندی)** — طراحی Schema اصلاح شد؛ **هیچ Migration تولید یا اجرا نشد**.

---

### P0-6 — شناسهٔ پایدار Intent و Idempotency

**مرجع v3:** §9.
**مشکل v3.0:** `operation_id` به‌تنهایی نمی‌گفت درخواست تکراری پس از Restart باید به عملیات قبلی متصل شود یا عملیات جدید ایجاد کند.

**الزامات اصلاح:**
1. ✅ مفهوم پایدار Intent تعریف شد: `client_intent_id` (idempotency_key).
2. ✅ محدودهٔ یکتایی: **(account_login, server, deployment_id)**.
3. ✅ شناسه قبل از اولین ارسال ساخته و ذخیره می‌شود (قبل از SUBMISSION_PENDING).
4. ✅ Retry و Restart همان Intent را بازیابی می‌کنند.
5. ✅ Intent تکراری با Payload یکسان به عملیات موجود متصل می‌شود (`duplicate_request_count += 1`؛ `submission_attempt_count` دست نمی‌خورد — FIX-01). شمارندهٔ تکرار هرگز مجوز ارسال مجدد نیست.
6. ✅ همان Intent با Payload متفاوت ⇒ **Conflict قابل‌حسابرسی** (رویداد `IntentConflictDetected` + پاسخ خطای صریح — FIX-01)؛ **هیچ Operation جدیدِ قابل‌ارسال ایجاد نمی‌شود** (UNIQUE روی intent)؛ نه بازنویسی بی‌صدا، نه تغییر وضعیت عملیات موجود.
7. ✅ امکان دو سفارش مستقل با Payload کاملاً یکسان حفظ شد (Intent متفاوت ⇒ عملیات متفاوت).
8. ✅ `operation_id` شناسهٔ عملیات باقی ماند؛ `client_intent_id` شناسهٔ درخواست‌کننده است.
9. ✅ Internal Idempotency از Broker Idempotency جدا ماند.
10. ✅ هیچ ادعای Idempotency سمت MT5 مطرح نشد.

**خلاصهٔ تصمیم:** مفهوم `client_intent_id` به §11.2 اضافه شد؛ ستون `client_intent_id TEXT` + `UNIQUE(account_login, server, deployment_id, client_intent_id)` در مدل operation (طراحی سندی). جدول رفتار Retry/Duplicate/Conflict/Payload-mismatch تکمیل شد (§11.4). ادعای Idempotency سمت بروکر همچنان رد شد (OPEN-02). **FIX-01 (v3.1.1):** تناقض §11.2 (UNIQUE حاوی `payload_hash`) با این خلاصه رفع شد — UNIQUE فقط روی intent؛ شمارنده‌ها به `submission_attempt_count` + `duplicate_request_count` تفکیک شدند.

**وضعیت:** ✅ **RESOLVED (سندی)** — شناسهٔ پایدار تعریف شد؛ پیاده‌سازی و اثبات‌پذیری به Gate 3 موکول است.

---

### P0-7 — بستن مسیر نوشتن در Startup تا پایان Recovery

**مرجع v3:** §11.

**الزامات اصلاح:**
1. ✅ حالت اولیهٔ ExecutionAuthority = **DENY_ALL_WRITES**.
2. ✅ این حالت قبل از اتصال MT5 برقرار است.
3. ✅ ساخت MT5Broker، Probe، Bootstrap، Health Check و Build Components مسیر نوشتن را فعال نمی‌کنند.
4. ✅ بازیابی Operationهای ناتمام قبل از باز شدن مجوز Entry انجام می‌شود.
5. ✅ بارگذاری Ownership و Reconciliation قبل از اجازهٔ نوشتن انجام می‌شود.
6. ✅ هیچ Constructor، CLI یا مسیر جایگزین نمی‌تواند گیت را دور بزند.
7. ✅ باز شدن Authority فقط پس از تکمیل تمام گیت‌ها امکان‌پذیر است.
8. ✅ شکست هر مرحله ⇒ Fail-Closed.
9. ✅ مسیرهای Close/Modify مجاز در حالت محدود طبق ماتریس P0-1 کنترل می‌شوند.
10. ✅ ترتیب Startup در **یک نمودار و یک جدول واحد سازگار** ارائه شد.

**خلاصهٔ تصمیم:** بخش §13.1 (نمودار ترتیبی) + §13.2 (جدول گیت‌ها با وضعیت `DENY_ALL_WRITES → PARTIAL → OPEN`) اضافه شد. حالت `PARTIAL` فقط شامل مسیرهای Reduce-Risk روی OWNED طبق ماتریس P0-1 است. هیچ گیتی توسط Constructor یا CLI دور زده نمی‌شود.

**وضعیت:** ✅ **RESOLVED (سندی)** — ترتیب و گیت‌ها تثبیت شد؛ اجرای Runtime به Gate 3 موکول است.

---

### P0-8 — تعیین Database of Record

**مرجع v3:** §13.

**الزامات اصلاح:**
1. ✅ مشخص شد جدول `operation` در **State DB** قرار می‌گیرد.
2. ✅ مشخص شد `position_ownership` و `authority_state` در **State DB** قرار می‌گیرند.
3. ✅ مرجع قطعی هر داده و رابطه با Journal DB و State DB روشن شد (§15.2 جدول Database of Record).
4. ✅ رفتار Crash بین Commitها مشخص شد (§15.3).
5. ✅ رفتار Backup/Restore و DB ناقص تعریف شد (§15.4).
6. ✅ سازگاری Risk State و Execution State توضیح داده شد.
7. ✅ استفاده از WAL و `synchronous=FULL` **به‌عنوان Atomic Transaction بین چند DB معرفی نشد** — صریحاً رد شد.
8. ✅ راه‌حل قطعی برای اتمیک‌بودن بین دو DB قابل تعیین نبود ⇒ موضوع **OPEN** ثبت شد (**OPEN-07**) و هیچ ادعای اتمیک‌بودن نشد.
9. ✅ هیچ DB یا Migration در این مرحله تغییر نکرد.

**خلاصهٔ تصمیم:** State DB (جداول `operation`، `position_ownership`، `authority_state`) مرجع قطعی وضعیت عملیاتی/مالکیت/مقام است. Journal DB مرجع قطعی رویدادها/ Audit است. هیچ تراکنش بین دو DB وجود ندارد؛ هر commit مستقل است؛ رفتار Crash بین دو commit با بازیابی `RECONCILIATION_REQUIRED` تعریف شد (بدون ادعای atomicity). تأمین atomicity واقعی بین دو DB = **OPEN-07**.

**وضعیت:** ✅ **RESOLVED (سندی)** — تکلیف DB of Record مشخص شد؛ atomicity بین DBها **UNRESOLVED / OPEN-07**.

---

## ۵. اصلاحات P1 (اجباری) — وضعیت در v3.1

### P1-1 — محدودیت RESOLVED_ABSENT

1. ✅ عدم مشاهدهٔ Order/Deal در Snapshot به‌تنهایی اثبات عدم اجرا نیست.
2. ✅ کامل‌بودن History و تأخیر آن شرط Reconciliation است.
3. ✅ تا قبل از کالیبراسیون واقعی MT5 Demo، هیچ عملیات به نتیجهٔ Reconciliation = RESOLVED_ABSENT نمی‌رسد و گذار پایانی متناظر انجام نمی‌شود (نتیجه ≠ وضعیت — FIX-03).
4. ✅ RESOLVED_ABSENT (نتیجهٔ Reconciliation) مجوز Retry یا Entry نمی‌دهد مگر شواهد لازم برقرار باشند (پنج شرط §12.3 + کالیبراسیون OPEN-03).

**خلاصهٔ تصمیم:** §10.3 با بند «پیش‌نیاز کالیبراسیون» تقویت شد: تا اجرای T-32/T-33 و ثبت Δ و `absent_confirmation_window` روی MT5 Demo (Gate 4)، هر UNKNOWN در وضعیت `RECONCILIATION_REQUIRED` می‌ماند و هیچ نتیجهٔ `RESOLVED_ABSENT` صادر (و هیچ گذار پایانی متناظر انجام) نمی‌شود.

**وضعیت:** ✅ **RESOLVED (سندی)** — قاعدهٔ سخت‌گیری ثبت شد؛ کالیبراسیون **OPEN-03 / NOT TESTED**.

---

### P1-2 — ثبت چند Deal و Partial Execution

مدل داده (طراحی سندی) امکان ردیابی چند Execution برای یک Operation را دارد. حداقل مفاهیم:

| مفهوم | محل در مدل |
|---|---|
| Requested Volume | `operation.requested_volume` |
| Executed Volume | `execution_attempt.executed_volume` (جمع) |
| Remaining Volume | `operation.target_volume − جمع executed` |
| Broker Order ID | `execution_attempt.broker_order_id` |
| Deal ID / Deal IDs | `execution_attempt.deal_ids_json` |
| Attempt ID | `execution_attempt.attempt_id` |
| زمان هر تلاش | `execution_attempt.created_at` |
| وضعیت نهایی Position | `position_ownership.state` + `operation.status` |

جدول `execution_attempt` (جدول جدید پیشنهادی) فقط در صورت ضرورت واقعی ایجاد می‌شود — الزام به جدول جدید نیست؛ ساختار معادل در همان `operation` نیز پذیرفته است.

**وضعیت:** ✅ **RESOLVED (سندی)** — مفاهیم تعریف شد؛ ایجاد جدول/Migration **در این مرحله انجام نشد**.

---

### P1-3 — تفکیک نتیجهٔ نهایی Operation

تعریف عمومی نتیجهٔ Reconciliation `CONFIRMED` (وضعیت نیست — وضعیت پایانی موفق `RESOLVED` است، FIX-03) برای هر نوع Operation:

| نوع | شرط نتیجهٔ `CONFIRMED` (⇒ وضعیت `RESOLVED`) |
|---|---|
| Entry | وجود Position یا Deal منطبق + `position_id_mt5` ثبت‌شده |
| Full Close | حجم Position = ۰ (یا حذف) ∧ Deal Close منطبق |
| Partial Close | کاهش حجم = `target_volume` دقیق ∧ Deal منطبق |
| Modify | SL/TP واقعی در بروکر = مقدار درخواستی |
| Cancel | تکمیل: `CANCEL_CONFIRMED` ⇒ وضعیت `CANCELLED`؛ `FILLED` ⇒ `EXECUTED` سپس `RESOLVED` (§12.4) |
| Flatten | همهٔ فرزندان per-موقعیت پایانی + صفر عملیات باز در محدوده |

پذیرش درخواست بروکر (`API_ACCEPTED`)، اجرای معامله (`EXECUTED`) و تکمیل عملیات (نتیجهٔ `CONFIRMED` ⇒ وضعیت `RESOLVED`) سه مفهوم/لایهٔ جداگانه‌اند.

**وضعیت:** ✅ **RESOLVED (سندی)**.

---

### P1-4 — پوشش همهٔ مسیرهای نوشتن

تمام مسیرهای تغییردهندهٔ وضعیت بروکر در Scope گیت نهایی ExecutionAuthority هستند:

`Entry` · `Full Close` · `Partial Close` · `Modify SL/TP` · `Pending Order` · `Cancel` · `Retry` · `Flatten` · `Emergency Path` · `Recovery`

توضیح: **Guard در Coordinator به‌تنهایی کافی نیست**؛ مسیر مستقیم به `order_send` نباید باقی بماند. این الزام طراحی است؛ اثبات پوشش Runtime به **Gate 3 و Gate 4** موکول می‌شود. (بازبینی v3: سایت‌های `order_send` در ۷۰۵/۸۳۰/۸۷۵ `mt5_broker.py` — REPORTED.)

**وضعیت:** ✅ **RESOLVED (سندی)** — لیست مسیرها بسته شد؛ اثبات پوشش **NOT VERIFIED**.

---

### P1-5 — تعریف محاسباتی Reduce-Risk

عبارت Reduce-Risk صرفاً برچسب درخواست نیست. تعریف قابل‌آزمون:

| تغییر | آیا Reduce-Risk است؟ | شرط |
|---|---|---|
| کاهش حجم (Partial Close) | ✅ بله | `target_volume < volume_current` |
| Full Close | ✅ بله | حذف کامل Exposure پوزیشن |
| تغییر SL به سمت بدترشدن ریسک | ❌ خیر | حرکت SL دور از قیمت جاری در جهت زیان‌پذیری بیشتر = افزایش ریسک |
| تغییر SL به سمت بهبود | ✅ بله | کاهش فاصله Stop از قیمت جاری در جهت ایمنی |
| تغییر TP | ❌ خیر (خنثی تا افزایش ریسک) | TP تغییری در ریسک لحظه‌ای نمی‌دهد |
| Cancel سفارش در انتظارِ افزایش‌دهندهٔ Exposure (مثلاً Pending Entry) | ✅ بله فقط اگر واقعاً Exposure آینده را حذف کند | حذف Order بازی که در آینده Exposure ایجاد می‌کند |
| Cancel سفارش حفاظتی/محافظ (Protective) | ❌ خیر | حذف آن ریسک/Exposure را افزایش می‌دهد — Reduce-Risk خودکار نیست (FIX-04) |
| Modify ترکیبی (SL و TP هم‌زمان) | ✅ فقط اگر هر فیلد تغییریافته مستقلاً کاهش‌ریسک باشد | ارزیابی فیلدبه‌فیلد؛ TP تغییریافته ⇒ کل عملیات Reduce-Risk نیست (FIX-04) |
| تغییر حجم Pending Order به بالا | ❌ خیر | افزایش Exposure آینده |
| افزایش حجم موجود | ❌ خیر | افزایش Exposure |

اگر برای یک عملیات کاهش ریسک قابل اثبات نباشد، از مسیر محدود (مجوز کامل/Grant) استفاده می‌شود و به‌عنوان Reduce-Risk خودکار مجاز نیست.

**وضعیت:** ✅ **RESOLVED (سندی)** — تعریف محاسباتی ثبت شد؛ اجرای Runtime به Gate 3 موکول است.

---

### P1-6 — اصلاح ناسازگاری‌های عددی و شناسه‌ای

موارد زیر با محاسبه و تطبیق واقعی اصلاح شدند (محاسبات در §19 این سند):

| مورد | v3.0 (ناقص) | v3.1 (اصلاح‌شده) |
|---|---|---|
| «پنج P0 (R-01..R-06)» در برابر شش شناسه | ۵ در برابر ۶ | **شش ریسک اصلاحی R-01..R-06**؛ تعداد P0 در v3.0 پنج بود؛ در v3.1 **هشت P0** (P0-1..P0-8) |
| جمع فایل‌های Must Change / May Change / Needs Inspection / No Change | ۱۴+۴+۴+۲ = ۲۴ | **۱۴+۴+۴+۲ = ۲۴ — تأیید شد (درست بود)** |
| وضعیت شمارش سه فایل جدید در جدول Scope | ذکر جداگانه | **۳ فایل جدید جدا از ۲۴ ردیف** (ردیف‌های ۲۵–۲۷) + ۳ جدول جدید پیشنهادی (`execution_attempt` اختیاری) |
| جمع LOC افزوده/حذف‌شده در v3 §17.2 | ۱٬۷۳۵–۲٬۰۳۵ / ~۳۲۰ | **بازمحاسبه: ۱٬۸۲۸ / ۲۶۶** (ردیف‌های تکی + فایل‌های جدید؛ بدون بازه) |
| ناسازگاری جمع per-file و جمع C-1/C-2/C-3 | C-1 ≈ ۱٬۴۶۵/۲۲۵ · C-2 ≈ ۲۷۰/۹۵ · C-3 ≈ ۲۵ — ناسازگار با ردیف‌ها | **بازمحاسبه: C-1 = ۱٬۶۰۸/۲۱۵ · C-2 = ۲۲۰/۵۱ · C-3 = ۰/۰ · جمع = ۱٬۸۲۸/۲۶۶** |
| بازهٔ کل LOC و مبنای محاسبه | ~۱٬۷۳۵–۲٬۰۳۵ بدون مبنا | **مبنا: جمع مستقیم ردیف‌های §19.2 + فایل‌های جدید = +۱٬۸۲۸/−۲۶۶. بازه: افزوده ۱٬۸۲۸–۲٬۰۲۸ (+۲۰۰) و حذف ۲۶۶–۳۱۶ (+۵۰) — نوار قضاوتی یک‌طرفه؛ مرجع قطعی = جمع مستقیم ۱٬۸۲۸/۲۶۶ (FIX-08)** |
| تداخل شناسه R-03 برای Idempotency با ریسک Exposure در v3 §8.5 | هر دو «R-03» | **تفکیک شد: `R-03` = شناسهٔ ریسک اصلاحی (Idempotency)؛ `RS-03` = شناسهٔ ریسک مالکیتی §10.5 (Refusal-to-adopt ⇒ Exposure بی‌مدیر)** |

تمام اعداد قابل بازتولیدند (محاسبات در §19.2). هیچ عددی صرفاً برای هماهنگ شدن جدول‌ها تغییر نکرده است.

**وضعیت:** ✅ **RESOLVED**.

---

### P1-7 — تعیین تکلیف Standby

عبارت «Standby فقط Reduce-Only، هیچ مسیر نوشتن ندارد» متناقض بود. معماری پیشنهادی نهایی:

1. ✅ Standby هیچ سفارش مستقیمی به MT5 ارسال نمی‌کند.
2. ✅ Standby فقط وضعیت را می‌خواند.
3. ✅ درخواست کاهش ریسک را به **ExecutionAuthority فعال** تحویل می‌دهد.
4. ✅ Standby هیچ مالکیت موازی برای نوشتن ندارد.
5. ✅ اگر ExecutionAuthority فعال در دسترس نباشد، Standby مستقل به MT5 متصل نمی‌شود و سفارش نمی‌فرستد.
6. ✅ با Single Execution Authority هماهنگ شد؛ هیچ قابلیت جدیدی اضافه نشد.

**خلاصهٔ تصمیم:** «Reduce-Only» در توصیف Standby حذف و جایگزین شد با: **«Standby = Read-Only Observer + Request Forwarder به Authority فعال»**. هرگز نویسندهٔ مستقیم نیست.

**وضعیت:** ✅ **RESOLVED (سندی)**.

---

## ۶. ماتریس تصمیم واحد Ownership × Execution × Risk (P0-1 — منبع حقیقت)

> هر دو §10 (مالکیت) و §14 (مجوز) به این جدول ارجاع می‌دهند. هیچ ردیفی جواز نوشتن در شرایط مبهم نمی‌دهد. **این جدول تنها مرجع Normative تصمیم است (FIX-04)** — هر جدول مجوز دیگر در سند (شامل §14.2) خلاصهٔ غیرالزامآور/تاریخی است و در تعارض، اینجا حاکم است.

| Ownership | Exec=CLEAN, Risk=NORMAL | Exec=PENDING/UNKNOWN/RECONCILE_STALE | Risk=SOFT_HALT/HALTED/KILLED/QUARANTINE |
|---|---|---|---|
| **OWNED** | Entry ✅ · Modify ✅ · Partial ✅ · Full Close ✅ · Flatten ✅ · Cancel ✅ · Pending ✅ | فقط Reduce-Risk (P1-5) روی پوزیشن OWNED: Partial ✅ · Full Close ✅ · SL-to-safer ✅ (ارزیابی فیلدبه‌فیلد) · Cancel Pending ✅ (فقط اگر واقعاً Exposure را کاهش دهد) · Flatten فقط با مداخلهٔ انسانی §14.3 · Entry ❌ · Modify-risk-up ❌ | فقط Reduce-Risk (P1-5) روی OWNED: Partial ✅ · Full Close ✅ · SL-to-safer ✅ (فیلدبه‌فیلد) · Cancel (کاهش‌ریسک) ✅ · Flatten با مداخلهٔ انسانی §14.3 · Entry ❌ · Modify-risk-up ❌ |
| **FOREIGN_GOLDBOT / FOREIGN_EXTERNAL** | همه ❌ — OwnershipDenied + رویداد ژورنال | همه ❌ | همه ❌ |
| **AMBIGUOUS** | همه ❌ — هیچ برچسب Reduce-Only مجوز نمی‌دهد | همه ❌ — هیچ برچسب Reduce-Only مجوز نمی‌دهد | همه ❌ |
| **UNKNOWN** | همه ❌ — هیچ برچسب Reduce-Only مجوز نمی‌دهد | همه ❌ — هیچ برچسب Reduce-Only مجوز نمی‌دهد | همه ❌ |

**قواعد الحاقی:**
- `--emergency-all` فقط برای **OWNED + Flatten** با تأیید صریح، شناسهٔ پوزیشن، هویت اپراتور و Audit Trail (§14.3) اثر دارد. **هرگز Ownership Gate را دور نمی‌زند (FIX-04):** هرگز ردیف‌های AMBIGUOUS/UNKNOWN/FOREIGN_* را باز نمی‌کند و شرط Ownership=OWNED پیش‌نیض همیشگی آن است.
- هر اختلاف DB/Broker که مالکیت را مخدوش کند ⇒ انتقال به UNKNOWN **پیش از هر نوشتن**.
- «توقف ریسک جدید» (بستن Entry) ≠ «اجازهٔ مدیریت پوزیشن» (Reduce-Risk روی OWNED).
- **Serialization (FIX-04):** حداکثر **یک** عملیات تغییردهنده (`PARTIAL_CLOSE`/`FULL_CLOSE`/`MODIFY`) در هر لحظه به‌ازای هر پوزیشن. درخواست هم‌زمان با عملیات در جریان همان پوزیشن ⇒ رد/صف با دلیل صریح (هرگز دو تصمیم موازی). حجم همیشه از Snapshot تازهٔ بروکر خوانده می‌شود، نه از مقدار ذخیره‌شده در ردیف — تا دو درخواست هم‌زمان بر اساس یک حجم قدیمی مجاز نشوند.
- **Grant (تعریف واحد — FIX-04):** `Grant` = مجوز صریح **موردی** اپراتور با ثبت Audit (همان الزامات §14.3) برای عملیاتی که شرط Reduce-Risk آن قابل اثبات نیست. Grant **جایگزین شرط OWNED نمی‌شود** و هرگز Ownership Gate را دور نمی‌زند؛ فقط مسیر محدود P1-5 است.
- **ارزیابی Modify فیلدبه‌فیلد (FIX-04):** تغییر SL و TP در یک درخواست، فیلدبه‌فیلد و بر اثر واقعی هر فیلد سنجیده می‌شود؛ عملیات فقط وقتی Reduce-Risk است که **هر فیلد تغییریافته مستقلاً** کاهش‌ریسک باشد (تغییر TP ⇒ کل عملیات Reduce-Risk نیست — P1-5).
- **Cancel-Pending و Exposure (FIX-04):** لغو سفارش در انتظار فقط وقتی Reduce-Risk است که واقعاً Exposure باز/آتی را کاهش دهد؛ لغو سفارش حفاظتی یا هر سفارشی که حذفش ریسک را افزایش می‌دهد، **Reduce-Risk خودکار نیست** (P1-5).

---

## ۷. معماری هدف و ناوردایی‌ها

```text
live.py Startup
  1. هویت Deployment          ← DENY_ALL_WRITES از این لحظه
  2. ACQUIRE Host-Level Lock   ← پیش از ساخت MT5Broker
  3. Provenance (boot_epoch / generation)
  4. connect()
        │
   ExecutionAuthority  (تنها مسیر نوشتن)
   ├── Ownership Gate      ← R-02 / P0-1
   ├── Operation Registry  ← R-03 / P0-6 (client_intent_id)
   └── Reconciliation Gate ← R-04 / P0-4
        │
  RiskEngine │ PositionService │ Reconciler
        │
  State DB: operation / position_ownership / authority_state / execution_attempt
  Journal DB: رویدادها و Audit (P0-8)
```

**اصول تغییرناپذیر:** یک مسیر نوشتن · هر نوشتن با `operation_id` ثبت‌شده · هر نوشتن از Ownership Gate · ورود جدید فقط با Reconciliation تازه و تمیز · ابهام ⇒ توقف ریسک جدید، حفظ مدیریت کاهش‌ریسک روی OWNED · Startup تا پایان Recovery در `DENY_ALL_WRITES` (P0-7).

| ID | ناوردایی | اثبات‌پذیری |
|---|---|---|
| I-0 | Lock پیش از هر اتصال MT5 اخذ شده | 🟢 قابل اثبات (آزمون ترتیب) |
| I-1 | هیچ نوشتنی بدون `operation_id` ثبت‌شده | 🟢 قابل اثبات |
| I-2 | هر تغییر مالکیت در DB پایدار | 🟢 قابل اثبات |
| I-3 | ابهام عملیاتی ورود را می‌بندد | 🟢 قابل اثبات |
| I-4 | هر نوشتن از Ownership Gate عبور می‌کند | 🟢 قابل اثبات |
| I-5 | در هر لحظه یک Host اجرایی برای این حساب | 🔴 قابل اثبات نیست — AL-1 |
| I-6 | Startup تا پایان Recovery هیچ مسیر نوشتنی باز نیست | 🟢 قابل اثبات (آزمون ترتیب گیت‌ها) |
| I-7 | هر Intent تکراری به عملیات موجود متصل یا Conflict می‌شود — هرگز بازنویسی بی‌صدا | 🟢 قابل اثبات |

---

## ۸. Single Execution Authority

| جزء | مسئولیت | فایل |
|---|---|---|
| ExecutionAuthority | چرخهٔ عمر Lock، مالکیت، دروازهٔ عملیات، `entry_allowed`، حالت `DENY_ALL_WRITES` | `app/execution_authority.py` (جدید) |
| OperationRegistry | `operation_id`، `client_intent_id`، `payload_hash`، ماشین حالت، `submission_attempt_count`، `duplicate_request_count` | `app/operation_registry.py` (جدید) |
| OwnershipService | شش جزء هویت، پنج دستهٔ پوزیشن، سیاست Fail-Closed، ماتریس P0-1 — **تنها مرجع ایجاد/تغییر state مالکیت (FIX-05)** | `app/ownership.py` (جدید) |
| Reconciler | کشف/جمع‌آوری شواهد per-operation، چهار نتیجهٔ Cancel، نتایج Reconciliation — **بدون ایجاد/ارتقای مالکیت (FIX-05)** | `app/reconciler.py` (تغییر) |

سه فایل جدید به‌دلیل سه چرخهٔ آزمون مستقل (ترتیب Startup / ماشین حالت / مالکیت). **هیچ سرویس جدید، صف پیام یا پروتکل توزیع‌شده اضافه نمی‌شود** (DESIGN PROPOSAL).

---

## ۹. Locking و مالکیت چند‑VPS (R-01 + R-05 + P0-2 + P0-3)

### ۹.۱ دو محدودهٔ جداگانه

**A) تک‌VPS — Z-1:** یک Host مالک حساب · Lock پیش از اتصال MT5 · حفظ تا پایان Disconnect و خروج واقعی Process · مکانیزم: قفل انحصاری OS روی فایل اختصاصی (نه فایل دیتابیس) · DESIGN PROPOSAL، روی Windows NOT TESTED.

**B) چند‌VPS:**

| منطقه | مکانیزم | تضمین | وضعیت |
|---|---|---|---|
| Z-1 Single Host | OS Lock پیش از Connect | 🟢 قابل اثبات (پس از آزمون) | DESIGN PROPOSAL |
| Z-2 Multi-Host با تضمین سروری | Lock + قفل نشست سمت بروکر (گروه حساب اختصاصی که ورود هم‌زمان را رد می‌کند) | 🟢 مشروط به تأیید کتبی بروکر | NOT VERIFIED |
| Z-3 Multi-Host دستی | رویهٔ شش‌گانه + گواهی توقف + سلب دسترسی | 🟡 **انضباطی — Operational Risk Reduction فقط** | DESIGN PROPOSAL |
| Z-4 Multi-Host بی‌اثبات | هیچ تضمینی | 🔴 Fail-Closed | DESIGN PROPOSAL |

هیچ ادعای انحصار بین دو VPS بر پایهٔ Lock محلی پذیرفته نیست. اگر Z-2 تأییدنشده باشد (و در استقرار تک‌Host، Z-1 اثبات‌نشده) ⇒ Z-4: ورود مسدود، فقط کاهش‌ریسک، رویداد `UnprovableOwnershipBlock`. **اجرا/تکمیل Z-3 به‌تنهایی نه از Z-4 خارج می‌کند و نه ورود جدید باز می‌کند** (FIX-07 — §14.4).

### ۹.۲ شرایط اثبات انتقال مالکیت (R-01.4, R-01.5, R-01.6 + P0-2)

انتقال مالکیت مجاز نیست مگر هر پنج شرط هم‌زمان برقرار و مستند باشد:

| # | شرط | شاهد لازم |
|---|---|---|
| P-1 | موتور قبلی متوقف شده (نه فقط «خاموش به‌نظر می‌رسد») | نبود Process + کد خروج ثبت‌شده |
| P-2 | دسترسی اجرایی آن قطع شده | Task غیرفعال + **Credential Revocation** + **Session Revocation** (تفکیک‌شده — P0-2) |
| P-3 | وضعیت واقعی حساب بررسی شده | `positions()` + `orders()` + `history_*` از Host جدید، پیش از اولین ارسال |
| P-4 | هیچ عملیات باز/UNKNOWN روی حساب نمانده، یا همه Reconciliation شده‌اند | operation table: صفر ردیف غیرپایانی |
| P-5 | گواهی توقف با زمان، `deployment_id`، `instance_id` و آخرین `operation_id` ثبت شده + **تأیید اپراتور و نفر دوم** | فایل گواهی در Journal |

اگر هر یک از P-1..P-5 قابل اثبات نباشد ⇒ انتقال رد و Fail-Closed. صدور Lease جدید یا خاموشی ظاهری موتور قبلی به‌تنهایی مجوز انتقال نیست. **تغییر یا افزایش `boot_epoch` نیز به‌تنهایی مجوز یا اثبات انتقال امن نیست** (FIX-07). پذیرش ریسک انسانی/عملیاتی — امضای اپراتور، تأیید مستقل نفر دوم، سلب Credential/Session و Audit Trail (P-2، P-5، Z3-5، Z3-7، Z3-8) — **کنترل عملیاتی است، نه اثبات فنی**؛ هرگز به‌عنوان شرط `Ownership Provenable` (§14.4) شمرده نمی‌شود (FIX-07).

**گام‌های الزامی Z-3 (P0-2 — تکمیل‌کنندهٔ P-1..P-5):**

| # | گام | شاهد |
|---|---|---|
| Z3-1 | شمارش همهٔ Terminalهای MT5 روی Host قبلی | فهرست PID + مسیر |
| Z3-2 | بررسی Task Scheduler / Startup های مرتبط | خروجی `schtasks` + فهرست Startup |
| Z3-3 | بررسی همهٔ Processها و مسیرهای مستقل اجرای مرتبط | `Get-Process` + فهرست مسیر اجرا |
| Z3-4 | بررسی نشست‌های باقی‌مانده (RDP/غیره) | فهرست نشست‌ها |
| Z3-5 | تفکیک **Credential Revocation** (تغییر/حذف رمز ورود ترمینال/اکانت) از **Session Revocation** (قطع نشست فعال) | دو رکورد مجزا در گواهی |
| Z3-6 | اگر نشست معتبر یا مسیر اجرای ناشناخته باقی ماند ⇒ **انتقال ممنوع** | رویداد + Fail-Closed |
| Z3-7 | تأیید اپراتور | امضاء/هویت در گواهی |
| Z3-8 | تأیید مستقل نفر دوم (در صورت امکان) | امضاء/هویت دوم در گواهی |
| Z3-9 | نبود Process به‌تنهایی اثبات سلب دسترسی **نیست** — فقط یکی از ورودی‌های P-1 است | صریح در گواهی |

Z-3 هیچ ادعای تضمین Account-Level Ownership ندارد. در نبود شواهد کافی ⇒ Fail-Closed (Z-4).

### ۹.۳ محل دقیق اخذ Lock (R-05)

ترتیب فعلی (VERIFIED, `runtime/live.py`, ۳۹۷ خط): خط ۲۰۱ `state_db_path(...)` → ۲۰۲/۲۰۹ بررسی فایل state با `return 2` → ۲۱۵ `MT5Broker(...)` → ۲۲۴ `connect()` → ۲۳۳–۲۴۲ Probe سرد → ۳۱۴ `build_components(...)` → ۳۹۸ `disconnect()` نهایی.

نقطهٔ درست: **بین ۲۰۱ و ۲۱۵** — پیش از ساخت شیء بروکر، نه فقط پیش از `connect()`. هر Lock داخل Bootstrap یا `build_components` بعد از اتصال است و بی‌اثر.

| ID | الزام |
|---|---|
| L-1 | اخذ Lock پیش از ۲۱۵؛ شکست ⇒ خروج غیرصفر بدون هیچ اتصال MT5 |
| L-2 | Lock در تمام مدت اتصال و اجرای Engine معتبر |
| L-3 | Release فقط پس از توقف Engine، `disconnect()` در ۳۹۸ و Flush ژورنال |
| L-4 | هیچ مسیر جایگزینی (CLI، `python -m goldbot live`، Test Harness) نتواند `MT5Broker` بسازد بدون عبور از Authority — این شکاف G-1 را می‌بندد |
| L-5 | شکست Release نباید «قفل بی‌صاحب» بسازد: OS با مرگ Process آزاد می‌کند؛ فایل قفل با محتوای PID + boot_epoch + instance_id برای تشخیص کهنگی استفاده می‌شود |

### ۹.۴ چرخهٔ عمر Lock

```text
[Startup] هویت Deployment → DENY_ALL_WRITES → ACQUIRE (قفل انحصاری + نوشتن PID/boot_epoch/instance_id)
          → [شکست] پیام صریح، exit≠0، هیچ اتصال MT5          ← Fail-Closed
          → [موفق] OwnershipAcquired در ژورنال → connect() → probe → build_components
          → [Recovery] ارتقای ناتمام‌ها به UNKNOWN → Reconciler → بارگذاری مالکیت → باز شدن Authority
[Shutdown] توقف ورود جدید → تخلیهٔ عملیات با سقف زمانی → disconnect()
           → Flush ژورنال → Release Lock → exit 0
```

### ۹.۵ رفتار Crash / Kill / Timeout / Restart / Suspend / قطع Control Plane

| رویداد | رفتار الزامی | وضعیت |
|---|---|---|
| SIGTERM / Ctrl-C | Shutdown مرتب طبق §۹.۴؛ اگر تخلیه در سقف زمانی تمام نشد، عملیات در جریان UNKNOWN می‌ماند و ورود بسته می‌شود | DESIGN PROPOSAL |
| kill -9 / Power loss | OS قفل را آزاد می‌کند؛ فایل کهنه می‌ماند؛ Process بعدی محتوا + boot_epoch + DB را بررسی می‌کند | DESIGN PROPOSAL |
| Lock Timeout | تلاش محدود سپس Fail-Closed با دلیل صریح؛ هیچ چرخهٔ بی‌پایان | DESIGN PROPOSAL |
| Host Restart | boot_epoch افزایش می‌یابد؛ Process زندهٔ قدیمی در اولین نوشتن متوقف می‌شود — **اما توقف قطعی Process قدیمی فقط با تغییر boot_epoch ادعا نمی‌شود** (P0-3) | DESIGN PROPOSAL — پنجره: OPEN-04 |
| VM Suspend/Resume | همان boot_epoch | **NOT TESTED** |
| قطع ارتباط Control Plane | Lock و مالکیت تحت‌تأثیر قرار نمی‌گیرد؛ Heartbeat مبنای Recovery نیست؛ ورود طبق §۱۲ تعیین می‌شود | DESIGN PROPOSAL |
| قطع شبکه / MT5 | عملیات در جریان UNKNOWN؛ ورود بسته؛ رفع فقط با Reconciliation پس از اتصال | DESIGN PROPOSAL |

**قاعدهٔ Recovery (پنج مرحله، اجباری):** (۱) قفل انحصاری گرفته شود، (۲) محتوای فایل قفل کهنه بررسی شود، (۳) عملیات در جریان در DB بررسی شود، (۴) Reconciliation اجرا شود، (۵) تنها پس از این چهار مرحله ورود باز شود. گذشت زمان یا نبود Heartbeat مجوز بازیابی نیست.

### ۹.۶ محدودیت AL-1 (دائمی)

انحصار یک حساب MT5 در سطح دو Host با primitiveهای موجود قابل اثبات نیست؛ خاصیت Venue است، نه نقص طراحی. پذیرش کتبی AL-1 پیش‌نیاز Real Trading است (OPEN-01).
 بازگشت Host قدیمی پس از Z-3 با همان `deployment_id` و کپی DB نیز همین محدودیت را دارد: جلوگیری فنی قطعی وجود ندارد (مگر سلب دسترسی مؤثر P-2/Z3-5 — که خودش NOT VERIFIED است) — صریحاً **جزئی از OPEN-01** ثبت شد (FIX-07).

### ۹.۷ محدودیت‌های boot_epoch / Fencing (P0-3 — تکمیلی)

| موضوع | تکلیف |
|---|---|
| ماهیت boot_epoch | ابزار تشخیص، Provenance و Audit — **نه Fencing** |
| آیا MT5 آن را enforce می‌کند؟ | **خیر.** MT5 Broker Epoch داخلی GoldBot را enforce نمی‌کند. هیچ توقف قطعی Process قدیمی فقط با تغییر boot_epoch ممکن نیست. |
| منبع مرجع افزایش نسل | فقط در Startup با قفل انحصاری Host-Level (یا مداخلهٔ انسانی ثبت‌شده) |
| تفکیک چهار رویداد (FIX-06) | **Process Restart** (همان Host): Startup جدید ⇒ نسل +1 · **Host Restart** (ریبوت OS): Startup جدید ⇒ نسل +1 و آزادسازی قفل OS (فایل قفل کهنه می‌ماند) · **VM Suspend/Resume** (بدون Kill): بدون Startup ⇒ بدون تغییر نسل — **NOT TESTED** · **DB Restore از Backup قدیمی**: مقادیر `(boot_epoch, generation)` درون DB به عقب برمی‌گردند بدون آنکه Startup رخ داده باشد |
| حد تشخیص DB Restore (FIX-06) | مقایسهٔ `(boot_epoch, generation)` ذخیره‌شده **به‌تنهایی** بازگردانی را تشخیص نمی‌دهد: هر دو مقدار با همان Backup به عقب برمی‌گردند و با هم سازگارند. تشخیص فقط با **مرجع مستقل تک‌صعودی خارج از مجموعهٔ Backup** ممکن است (مثلاً فایل قفلِ میزبان — مشروط به اینکه خودش Backup نشود). چنین مرجعی در Scope فعلی **تعریف/تأیید نشده** (اینکه Backup شامل `var/` هست یا نه و فایل قفل در جای امنی نگهداری می‌شود یا نه — NOT VERIFIED). **ادعای تشخیص قطعی حذف شد؛ OPEN-04 باز است.** رفتار عملی: مشاهدهٔ اختلاف (مثلاً DB قدیمی‌تر از فایل قفل) ⇒ Fail-Closed؛ نبود/خرابی مرجع ⇒ Fail-Closed |
| پیش‌نیاز هر ادعای تشخیص آتی | مرجع مستقل تک‌صعودی با: منبع مشخص · ذخیره خارج از Backup DB · ACL نوشتن محدود · رفتار Fail-Closed در نبود/خرابی — تعریف و اثبات چنین مرجعی خارج از Scope فعلی است |
| Race: بررسی مجوز ←→ ارسال سفارش | **باقی‌مانده و ثبت‌شده به‌عنوان Open Risk — OPEN-06** (Gate 3/4) |

---

## ۱۰. مدل مالکیت Position (R-02 + P0-5)

### ۱۰.۱ Magic ≠ مالکیت

Magic تابع `(slot, magic_base)` است. دو Deployment مستقل با `magic_base=7300` دقیقاً همان Magicها را می‌سازند. پس `owns_position_magic()` فقط می‌گوید «در باند GoldBot است»، نه «مال من است».

`adopt_foreign_magic=False` فقط می‌گوید پوزیشن بیرون باند adopt نشود؛ در برابر Instance دیگری که داخل همان باند است هیچ محافظتی نمی‌کند. این تنظیم معادل Instance-Level Ownership نیست.

### ۱۰.۲ شش جزء هویت مالکیت

| جزء | منبع | وضعیت |
|---|---|---|
| Account Identity | `settings.account.login` + `server` | موجود (VERIFIED) |
| **Deployment Identity** | `deployment_id` پایدار — **سطح تعریف مالکیت** | وجود ندارد — باید ساخته شود |
| Execution Authority Identity | `instance_id` هر Boot + `boot_epoch` | وجود ندارد |
| Engine / Instance Identity | `instance_id` + `boot_epoch` + PID قفل | وجود ندارد |
| Position / Order Identity | `ticket_broker` + `position_id_mt5` + `recorded_magic` + `opening_operation_id` | ثبت پایدار ندارد |
| سابقهٔ ایجاد | `opening_operation_id` → ردیف operation → `opening_order_id` / `opening_deal_id` | وجود ندارد |

> **تفکیک Deployment و Instance (P0-5):** مالکیت در سطح **Deployment** تعریف می‌شود (هویت منطقی پایدار سرویس). `instance_id` + `boot_epoch` هویت هر اجرای فیزیکی است و فقط برای Audit و تشخیص کهنگی استفاده می‌شود — هرگز به‌تنهایی دلیل OWNERSHIP نیست.

### ۱۰.۳ جدول مالکیت (Schema سندی — بدون Migration)

```sql
position_ownership(
  account_login     INTEGER NOT NULL,
  server            TEXT    NOT NULL,
  ticket_broker     INTEGER NOT NULL,       -- Ticket عملیاتی بروکر
  position_id_mt5   TEXT,                   -- Position Identifier پایدار MT5 (در صورت وجود)
  deployment_id     TEXT    NOT NULL,       -- سطح تعریف مالکیت
  instance_id       TEXT    NOT NULL,       -- سازنده؛ audit
  boot_epoch        INTEGER NOT NULL,       -- نسل ایجادکننده؛ audit
  opening_operation_id TEXT,               -- سابقهٔ ایجاد؛ nullable ⇒ قاعدهٔ OWNED ناقص ⇒ UNKNOWN
  opening_order_id  TEXT,                   -- Order ایجادکننده (اگر موجود)
  opening_deal_id   TEXT,                   -- Deal ایجادکننده (اگر موجود)
  recorded_magic    INTEGER NOT NULL,
  state             TEXT NOT NULL,          -- OWNED | FOREIGN_GOLDBOT | FOREIGN_EXTERNAL | AMBIGUOUS | UNKNOWN | CLOSED (after Full Close - §10.6)
  volume_at_open    REAL NOT NULL,
  created_at        TEXT NOT NULL,
  updated_at        TEXT NOT NULL,
  PRIMARY KEY (account_login, server, ticket_broker)   -- P0-5: پشتیبانی چند Account و Server
)
```

> **کلید اصلی (P0-5):** `ticket INTEGER PRIMARY KEY` تک‌ستونی در v3.0 چندحسابی/چندسروری نبود. کلید مرکب `(account_login, server, ticket_broker)` جایگزین طراحی شد. شمارهٔ Ticket در MT5 در هر حساب مستقل است، نه سراسری.

**جدول پیوند Position ↔ Order/Deal (P0-5):**

```sql
position_order_deal(
  account_login INTEGER NOT NULL,
  server        TEXT    NOT NULL,
  ticket_broker INTEGER NOT NULL,
  ref_type      TEXT    NOT NULL
                  CHECK (ref_type IN ('OPEN_ORDER','OPEN_DEAL','CLOSE_ORDER','CLOSE_DEAL','MODIFY_ORDER')),
  order_id      TEXT NOT NULL DEFAULT '',   -- absent id = empty string; never NULL in key (FIX-02)
  deal_id       TEXT NOT NULL DEFAULT '',   -- same
  operation_id  TEXT,                       -- logical ref to operation.operation_id (no explicit FK; consistent with other tables)
  created_at    TEXT NOT NULL,
  CHECK (order_id <> '' OR deal_id <> ''), -- every row needs at least one active id (FIX-02)
  PRIMARY KEY (account_login, server, ticket_broker, ref_type, order_id, deal_id)  -- valid SQLite; equivalent to old PK with NULL->''
)
-- FIX-02: uniqueness keeps the exact scope of the old PK (three position keys + ref_type + the
--   order_id/deal_id pair = five conceptual identity parts, expanded to two sentinel columns).
--   NULL: inserting NULL into order_id/deal_id is rejected (NOT NULL); both-empty is rejected (CHECK).
--   Minimum SQLite version: none beyond basic PRIMARY KEY / NOT NULL / DEFAULT / CHECK (long-standing support);
--   checked on SQLite 3.46.1 in-memory with no DB file (details: v3.1.1 validation report, E-DDL-01).
```

**قاعدهٔ OWNED (چهارشرطی):**

1. ردیف وجود دارد ∧
2. `deployment_id` برابر با Deployment جاری ∧
3. magic واقعی بروکر = `recorded_magic` ∧
4. `opening_operation_id` معتبر و قابل بازیابی در `operation` است.

**نقض هر شرط ⇒ UNKNOWN.** `opening_operation_id` NULL ⇒ هرگز OWNED نیست (پوزیشن‌های قدیمی/دستی ⇒ FOREIGN_EXTERNAL یا UNKNOWN). Magic به‌تنهایی هرگز دلیل کافی نیست. **تفکیک مسئول (FIX-05):** ایجاد/تغییر `state` ردیف فقط توسط OwnershipService انجام می‌شود؛ Reconciler شاهد جمع می‌کند و هرگز ردیف نمی‌سازد یا ارتقا نمی‌دهد.

### ۱۰.۴ رفتار پنج دستهٔ پوزیشن

| دسته | تعریف | Adopt | Manage | Close | Modify | Trail | Partial | Flatten |
|---|---|---|---|---|---|---|---|---|
| OWNED | چهارشرط §۱۰.۳ | — | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| FOREIGN_GOLDBOT | Magic در باند، ردیف مال Deployment دیگر | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |
| FOREIGN_EXTERNAL | Magic بیرون باند یا معاملهٔ دستی | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |
| AMBIGUOUS | Magic منطبق، ردیف ناقص/مغایر | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |
| UNKNOWN | بروکر پوزیشن دارد و DB نه (یا برعکس) | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |

هر تلاش روی غیر‑OWNED: `OwnershipDenied` + رویداد ژورنال، بدون فراخوانی بروکر.

پس از Full Close ردیف به `CLOSED` می‌رود (§10.6) و از پنج دستهٔ بالا خارج می‌شود؛ هر بازگشت احتمالی بعدی ⇒ `UNKNOWN`، نه `OWNED` (FIX-02 — هماهنگی Schema با §10.6).

### ۱۰.۵ سیاست Fail-Closed برای مالکیت مبهم (P0-1)

هیچ adopt/close/modify/flatten خودکاری مجاز نیست؛ ورود مسدود (`OrphanPositionDetected` / `AmbiguousOwnership`)؛ پوزیشن دست‌نخورده می‌ماند و به اپراتور گزارش می‌شود؛ هر تصمیم مدیریت با رویداد حسابرسی‌شدهٔ انسانی ثبت می‌شود.

**معاوضهٔ صریح (`RS-03` — ریسک مالکیتی §10.5):** «Exposure بی‌مدیر» پذیرفته می‌شود تا «مدیریت پوزیشن دیگری» حذف شود. این تصمیم کارفرما است و نیازمند امضا است. *(شناسه در v3.0 با `R-03` Idempotency تداخل داشت — P1-6.)*

### ۱۰.۶ مالکیت در Restart / Reconnect / Migration / Reconciliation / Close

| رویداد | سیاست |
|---|---|
| Restart | ردیف‌ها از DB خوانده می‌شود؛ هیچ adopt دوباره؛ پوزیشن OWNED باقی می‌ماند |
| Reconnect | همان مالکیت؛ وضعیت بروکر دوباره Reconciliation؛ اختلاف ⇒ UNKNOWN |
| Partial Close | `state` OWNED می‌ماند؛ `volume_at_open` ثابت تاریخی است؛ حجم جاری از بروکر خوانده می‌شود؛ ثبت `position_order_deal` با ref_type=CLOSE_* |
| Full Close | `state` → `CLOSED` (یا حذف ردیف + رویداد)؛ هر بازگشت احتمالی بعدی ⇒ UNKNOWN، نه OWNED خودکار |
| VPS Migration | انتقال با پنج شرط §۹.۲ + گام‌های Z3-1..Z3-9؛ Host جدید ردیف‌ها را مطابق چهارشرط §10.3 مال خود می‌خواند؛ **جلوگیری قطعی از بازگشت Host قدیمی با همان `deployment_id`/DB فنی اثبات‌نشده است** (مکانیزم عملی: توقف P-1 + سلب دسترسی P-2/Z3-5) — جزئی از OPEN-01 (FIX-07)؛ ورود جدید فقط با Z-1/Z-2 (§14.4) |
| Reconciliation | اختلاف DB/بروکر ⇒ UNKNOWN و ورود مسدود؛ هرگز به‌صورت خودکار به OWNED ارتقا نمی‌یابد |
| DB از Backup قدیمی | تشخیص فقط با مرجع مستقل خارج از Backup ممکن است؛ بدون آن ادعای تشخیص قطعی نیست (FIX-06) — Fail-Closed در صورت مشاهدهٔ اختلاف؛ **OPEN-04 باز** |

---

## ۱۱. Idempotency پایدار عملیات (R-03 + P0-6)

### ۱۱.۱ چرا run_id ممنوع است

`run_id = uuid4().hex[:8]` هر Boot (`bootstrap.py:244`) و کلید Close آن را حمل می‌کند (`order_coordinator.py:277`). اندازه‌گیری: `evidence/P05` ⇒ `key_A='aaaaaaaa:close:i-1' ≠ key_B='bbbbbbbb:close:i-1'`. یک عملیات پس از Restart هویت دیگری دارد — دقیقاً برعکس Idempotency.

### ۱۱.۲ رکورد عملیات (Schema سندی — بدون Migration)

```sql
operation(
  operation_id       TEXT PRIMARY KEY,   -- UUIDv4، یک‌بار در CREATED
  client_intent_id   TEXT NOT NULL,      -- P0-6: شناسهٔ پایدار درخواست‌کننده
  account_login      INTEGER NOT NULL,
  server             TEXT NOT NULL,
  deployment_id      TEXT NOT NULL,
  instance_id        TEXT NOT NULL,      -- سازنده؛ audit، نه هویت
  ticket             INTEGER,
  operation_type     TEXT NOT NULL,      -- ENTRY|FULL_CLOSE|PARTIAL_CLOSE|MODIFY|CANCEL|FLATTEN
  requested_volume   REAL,
  target_volume      REAL,
  executed_volume    REAL NOT NULL DEFAULT 0,   -- P1-2
  remaining_volume   REAL,                      -- P1-2
  payload_json       TEXT NOT NULL,
  payload_hash       TEXT NOT NULL,      -- sha256(canonical_json) — برای مقایسهٔ Duplicate/Conflict؛ عضو UNIQUE نیست (FIX-01)
  created_at         TEXT NOT NULL,
  status             TEXT NOT NULL,      -- P0-4/FIX-03: CREATED|SUBMISSION_PENDING|API_ACCEPTED|PARTIALLY_FILLED|
                                          --        EXECUTED|REJECTED_FINAL|UNKNOWN|RECONCILIATION_REQUIRED|
                                          --        RESOLVED|CANCELLED  (10 status canonical; outcomes in separate columns)
  submission_attempt_count INTEGER NOT NULL DEFAULT 0,  -- FIX-01: فقط تلاش واقعی ارسال (order_send)
  duplicate_request_count  INTEGER NOT NULL DEFAULT 0,  -- FIX-01: درخواست‌های تکراریِ متصل‌شده؛ هرگز مجوز ارسال مجدد نیست
  broker_reference   TEXT,
  last_reconciliation_at TEXT,
  last_broker_outcome TEXT,             -- FIX-03: ACCEPTED|REJECTED|AMBIGUOUS (Broker layer; never replaces status)
  last_reconciliation_outcome TEXT,     -- FIX-03: CONFIRMED|RESOLVED_ABSENT|CANCEL_CONFIRMED|FILLED|STILL_LIVE|INCONCLUSIVE
  parent_operation_id TEXT,
  UNIQUE (account_login, server, deployment_id, client_intent_id)  -- P0-6/FIX-01: intent unique; WITHOUT payload_hash
)
```

`run_id` در هیچ‌جای هویت عملیات حاضر نیست.

### ۱۱.۳ ماشین حالت (۱۰ وضعیت Canonical، پایدار — P0-4 + FIX-03)

**سه لایهٔ مجزا (FIX-03):**

| لایه | مجموعهٔ Canonical | محل ثبت | هرگز |
|---|---|---|---|
| **Operation Lifecycle Status** | `CREATED` · `SUBMISSION_PENDING` · `API_ACCEPTED` · `PARTIALLY_FILLED` · `EXECUTED` · `REJECTED_FINAL` · `UNKNOWN` · `RECONCILIATION_REQUIRED` · `RESOLVED` · `CANCELLED` (۱۰ مقدار) | `operation.status` | — |
| **Broker Outcome** (نتیجهٔ خام هر تلاش ارسال) | `ACCEPTED` · `REJECTED` · `AMBIGUOUS` | ژورنال/record تلاش (+ `last_broker_outcome`) | جایگزین Status نمی‌شود؛ `retcode` ناشناخته هرگز `REJECTED_FINAL` نیست ⇒ `UNKNOWN` |
| **Reconciliation Outcome** (نتیجهٔ هر اجرای Reconciler) | `CONFIRMED` (شرط per-type P1-3) · `RESOLVED_ABSENT` (پنج شرط §12.3 + P1-1) · `CANCEL_CONFIRMED` · `FILLED` · `STILL_LIVE` · `INCONCLUSIVE` | ژورنال/`last_reconciliation_outcome` | وضعیت lifecycle نیست؛ `CONFIRMED` ≠ `RESOLVED` (اولی نتیجه، دومی وضعیت) |

**گذارهای مجاز (مرجع واحد):**

| از | به (مجاز) | مبنا |
|---|---|---|
| CREATED | `SUBMISSION_PENDING` · `REJECTED_FINAL` | ارسال آغاز شد / رد قطعی پیش از ارسال |
| SUBMISSION_PENDING | `API_ACCEPTED` · `UNKNOWN` · `REJECTED_FINAL` | پاسخ بروکر / timeout یا پاسخ مبهم / رد قطعیِ معنادار هنگام ارسال |
| API_ACCEPTED | `PARTIALLY_FILLED` · `EXECUTED` · `REJECTED_FINAL` · `UNKNOWN` | پذیرش ≠ اجرا؛ ردِ بعدیِ قطعی / ابهام |
| PARTIALLY_FILLED | `EXECUTED` · `REJECTED_FINAL` · `UNKNOWN` | تکمیل حجم / رد باقی‌مانده / ابهام |
| EXECUTED | `RESOLVED` | پس از Reconciliation و تأیید شرط تکمیل P1-3 (نتیجه `CONFIRMED`) |
| UNKNOWN | `RECONCILIATION_REQUIRED` **تنها** | بدون Reconciliation هیچ خروج دیگری نیست |
| RECONCILIATION_REQUIRED | `RESOLVED` · `EXECUTED` · `REJECTED_FINAL` · `CANCELLED` · `UNKNOWN` (دوباره) | شاهد کافی (نتیجه `CONFIRMED`/`RESOLVED_ABSENT`) / شاهد اجرا / رد قطعی / `CANCEL_CONFIRMED` / شاهد ناکافی (`INCONCLUSIVE`) |
| RESOLVED | — | پایانی و برگشت‌ناپذیر |
| CANCELLED | — | پایانی و برگشت‌ناپذیر (نتیجه `CANCEL_CONFIRMED`) |
| REJECTED_FINAL | — | پایانی و برگشت‌ناپذیر |

**وضعیت‌های پایانی و برگشت‌ناپذیر (نام‌گذاری صریح):** `RESOLVED` · `CANCELLED` · `REJECTED_FINAL`. هیچ گذار خروجی از این سه مجاز نیست.

**نام‌های بازنشسته و نگاشت‌شده (FIX-03):** `FAILED_FINAL` → `REJECTED_FINAL` (دو نام برای یک مفهومِ شکست قطعی بود) · `CONFIRMED` → Reconciliation Outcome (وضعیت نیست؛ وضعیت پایانی موفق `RESOLVED` است) · `RESOLVED_ABSENT` → Reconciliation Outcome (وضعیت نیست؛ جایگاه دقیق در §12.3) · `CONFLICT` → رویداد `IntentConflictDetected` (FIX-01؛ وضعیت نیست — UNIQUE روی intent مانع ایجاد ردیف دوم می‌شود) · `SUBMITTED` (قدیمی) → `SUBMISSION_PENDING` · `UNKNOWN` به‌عنوان نتیجهٔ §12.4 → `INCONCLUSIVE`.

**گذار غیرمجاز ⇒ Exception + رویداد.** نمونه‌های صریح غیرمجاز: `CREATED`→`EXECUTED` · `UNKNOWN`→`RESOLVED` بدون Reconciliation · هر گذار خروجی از `RESOLVED`/`CANCELLED`/`REJECTED_FINAL` · هر گذار جدید ساخته‌شده توسط Retry یا Run ID. هر گذار پیش از گام بعدی در DB پایدار می‌شود.

**بازیابی Restart (نقشهٔ وضعیت — نه گذار چرخه‌ای):**

| وضعیت هنگام Crash/Restart | وضعیت پس از Startup | قاعده |
|---|---|---|
| `CREATED` | `CREATED` | ارسال نشده؛ ادامه فقط از مسیر گذارهای بالا |
| `SUBMISSION_PENDING` / `API_ACCEPTED` / `PARTIALLY_FILLED` | `UNKNOWN` → `RECONCILIATION_REQUIRED` | هیچ ارسال دوباره بدون Reconciliation |
| `EXECUTED` | `EXECUTED` | شواهد Deal پایدار است؛ تکمیل با Reconciliation → `RESOLVED` |
| `UNKNOWN` / `RECONCILIATION_REQUIRED` | بدون تغییر | هرگز حذف/بازنویسی/«تازه‌سازی» نمی‌شود |
| `RESOLVED` / `CANCELLED` / `REJECTED_FINAL` | بدون تغییر | پایانی |

**هیچ گذاری به‌بهانهٔ Retry یا Run ID جدید دور زده نمی‌شود (FIX-03):** Retry فقط همان `operation_id`/`client_intent_id` را از DB بازیابی می‌کند و از وضعیت بازیابی‌شده فقط از طریق جدول بالا ادامه می‌یابد.

### ۱۱.۴ رفتار Restart / Timeout / Duplicate / پاسخ مبهم / Intent (P0-6 + FIX-01)

| موقعیت | رفتار الزامی |
|---|---|
| Restart با `SUBMISSION_PENDING`/`API_ACCEPTED`/`PARTIALLY_FILLED` (نام قدیمی `SUBMITTED` ⇒ `SUBMISSION_PENDING`) | ارتقا به `UNKNOWN` → `RECONCILIATION_REQUIRED` (نقشهٔ §11.3)؛ هیچ ارسال دوباره |
| Restart با `UNKNOWN`/`RECONCILIATION_REQUIRED` موجود | بدون تغییر باقی می‌ماند؛ هرگز حذف، بازنویسی یا «تازه‌سازی» نمی‌شود |
| Timeout پس از ارسال | `UNKNOWN`؛ نه «موفق» نه «ناموفق» فرض نمی‌شود |
| درخواست تکراری همان `client_intent_id` + همان Payload | اتصال به عملیات موجود؛ `duplicate_request_count += 1`؛ `submission_attempt_count` تغییر نمی‌کند؛ **هیچ ارسال مجدد خودکاری مجاز نیست** |
| همان `client_intent_id` + Payload متفاوت | **Conflict قابل‌حسابرسی**: رویداد `IntentConflictDetected` در ژورنال (هر دو `payload_hash`) + پاسخ خطای صریح؛ **هیچ Operation جدید ساخته/ارسال نمی‌شود** (UNIQUE روی intent — FIX-01)؛ وضعیت عملیات موجود تغییر نمی‌کند؛ بازنویسی بی‌صدا ممنوع |
| Intent متفاوت + Payload یکسان | دو عملیات مستقل مجاز (سفارش عمدی تکراری حفظ می‌شود) |
| Retry پس از Restart | همان Intent/operation از DB بازیابی می‌شود؛ شناسهٔ جدید ساخته نمی‌شود؛ Retry هیچ گذاری را دور نمی‌زند (§11.3) |
| پاسخ مبهم بروکر | `UNKNOWN`؛ ورود مسدود تا Reconciliation |
| Retry بدون Reconciliation | ممنوع و Non-bypassable |
| `UNKNOWN` به‌دلیل گذشت زمان | هرگز «تکرارپذیر» یا «فراموش» نمی‌شود |
| Retcode ناشناخته/بدون معنای قطعی | به `REJECTED_FINAL` نگاشت **نمی‌شود** — `UNKNOWN` |

### ۱۱.۵ Idempotency داخلی ≠ بروکر

`operation_id` + `payload_hash` + `client_intent_id` مانع ارسال دوبارهٔ GoldBot به خودش می‌شود. تضمین نمی‌کند بروکر درخواست تکراری را تشخیص دهد: **MT5 کلید Idempotency ندارد.** تنها artefact سمت بروکر، ledger درون‌حافظه (`mt5_broker.py:906`) است که با مرگ Process از بین می‌رود و پس از ۱۲۰ ثانیه prune می‌شود. محدودیت L-2 + رویداد `LinkIdempotencyScope` در Startup. **(OPEN-02)** هیچ ادعای Idempotency سمت بروکر مجاز نیست.

### ۱۱.۶ تفکیک per-operation

| نوع | کلید هویت | نکتهٔ اجباری |
|---|---|---|
| ENTRY | `payload_hash` = symbol/side/volume/SL/TP/strategy | `ticket` در `API_ACCEPTED`/`EXECUTED` پر می‌شود |
| FULL_CLOSE | `ticket` + `target_volume` = volume فعلی | تغییر حجم ⇒ Payload تغییرکرده ⇒ عملیات جدید |
| PARTIAL_CLOSE | `ticket` + `target_volume` صریح | جمع `target_volume`های در جریان ≤ حجم ثبت‌شده |
| MODIFY | `ticket` + مقادیر دقیق SL/TP | بدون Grant فقط کاهش‌ریسک (P1-5)؛ دو نوشتن مخالف نباید هر دو موفق شوند |
| CANCEL | order ticket | نتیجه با چهار حالت §12.4 |
| FLATTEN | `parent_operation_id` + فرزند per-موقعیت/سفارش | موفقیت فقط وقتی همهٔ فرزندان پایانی شده‌اند |

---

## ۱۲. Reconciliation اختصاصی هر عملیات (R-04 + P1-1 + P1-2)

### ۱۲.۱ ماتریس شواهد و وضعیت نهایی

| عملیات | حداقل شواهد | منبع موجود | وضعیت/مسیر نهایی ممکن (Canonical §11.3 — FIX-03) |
|---|---|---|---|
| Entry | Active Orders + Order History + Deals + Positions | `orders()`:452 · `history_orders_get`:562 · `deals(since)`:478 · `positions()`:446 | `RESOLVED` (شواهد: position یا deal — نتیجه `CONFIRMED`) · `REJECTED_FINAL` · `RESOLVED` با نتیجهٔ `RESOLVED_ABSENT` (فقط پس از P1-1/کالیبراسیون) · در غیر این `UNKNOWN`/`RECONCILIATION_REQUIRED` |
| Full Close | Order/Deal History + تغییر حجم یا حذف Position | `history_deals_get`:483/:1138 · `positions()`:446 | `RESOLVED` (حجم صفر + deal) · `UNKNOWN`/`RECONCILIATION_REQUIRED` · نتیجهٔ `RESOLVED_ABSENT` مشابه بالا |
| Partial Close | Deal History + تطبیق دقیق کاهش حجم + چند Deal احتمالی (P1-2) | `history_deals_get` · `positions()` · `execution_attempt` | `RESOLVED` (کاهش حجم = `target_volume`) · `UNKNOWN`/`RECONCILIATION_REQUIRED` |
| Modify SL/TP | مقادیر واقعی SL/TP در بروکر | `positions()`:446 | `RESOLVED` (SL/TP برابر مقدار درخواستی) · `UNKNOWN`/`RECONCILIATION_REQUIRED` |
| Pending Cancel | Active Orders + Order History + Deals | `orders()`:452 · `history_orders_get`:562 · `deals()`:478 | نتایج §12.4: `CANCEL_CONFIRMED`→`CANCELLED` · `FILLED`→`EXECUTED`→`RESOLVED` · `STILL_LIVE`→`UNKNOWN` · `INCONCLUSIVE`→`RECONCILIATION_REQUIRED` |
| Flatten | وضعیت نهایی همهٔ Position/Order در محدودهٔ مالکیت + عملیات در جریان | ترکیب بالا + `position_ownership` | `RESOLVED` (همهٔ فرزندان پایانی) · `UNKNOWN`/`RECONCILIATION_REQUIRED` |

`EXECUTED` وضعیت پایانی نیست (⇒ `RESOLVED` پس از Reconciliation — §11.3). `UNKNOWN`/`RECONCILIATION_REQUIRED` وضعیت پایانی نیستند؛ حالت استراک/مسدود تا شاهد بیشترند. نتایج Reconciliation (`CONFIRMED`، `RESOLVED_ABSENT`، چهار نتیجهٔ §12.4) لایهٔ جداگانه‌اند و هرگز جایگزین `operation.status` نمی‌شوند (FIX-03).

همهٔ Endpointها از قبل در Adapter موجودند؛ زیرساخت جدید لازم نیست (VERIFIED).

### ۱۲.۲ قاعدهٔ پایه

یک Snapshot از `positions()` برای تعیین نتیجهٔ قطعی همهٔ عملیات کافی نیست. Reconciler امروز فقط همان را می‌خواند (`reconciler.py:43`، VERIFIED).

### ۱۲.۳ RESOLVED_ABSENT — نتیجهٔ Reconciliation (پنج شرط هم‌زمان + P1-1)

1) هیچ Position متناظر · 2) هیچ Order فعال متناظر · 3) هیچ Deal منطبق از `created_at − Δ` · 4) گذشت زمان > `absent_confirmation_window` · 5) دو مشاهدهٔ با فاصله با نتیجهٔ یکسان.

Δ و `absent_confirmation_window` عمداً بدون عدد: NOT VERIFIED. عدد بدون اندازه‌گیری روی MT5، ادعای ایمنی بی‌پشتوانه است. **کالیبراسیون: OPEN-03.**

**سخت‌گیری P1-1:** تا قبل از کالیبراسیون واقعی MT5 Demo (Gate 4، T-32/T-33)، هیچ عملیات به نتیجهٔ `RESOLVED_ABSENT` نمی‌رسد و در `RECONCILIATION_REQUIRED` می‌ماند. `RESOLVED_ABSENT` یک **Reconciliation Outcome** است، نه وضعیت lifecycle (FIX-03 — جایگاه دقیق: نتیجهٔ ثبت‌شده در Reconciliation با اثرِ گذارِ `RECONCILIATION_REQUIRED`→`RESOLVED`)؛ مجوز Retry یا Entry نمی‌دهد مگر پنج شرط + کالیبراسیون برقرار باشند. کامل‌بودن History و تأخیر آن شرط Reconciliation است.

### ۱۲.۴ چهار نتیجهٔ الزامی Pending Cancel (Reconciliation Outcome — FIX-03)

| نتیجه (Outcome) | شرط اثبات | اثر بر Lifecycle Status |
|---|---|---|
| `CANCEL_CONFIRMED` | در Active Orders نیست ∧ در Order History با وضعیت Canceled ثبت شده | `CANCELLED` |
| `FILLED` | Deal متناظر وجود دارد | `EXECUTED`؛ ایجاد/تغییر ردیف مالکیت **فقط توسط OwnershipService** پس از تحقق چهارشرط §10.3 — وجود Deal به‌تنهایی هرگز `OWNED` نمی‌سازد (FIX-05) |
| `STILL_LIVE` | سفارش هنوز در `orders()` است | `UNKNOWN` + ورود مسدود |
| `INCONCLUSIVE` (نام بازنشستهٔ `UNKNOWN` در همین جدول) | شواهد متناقض یا ناکافی | `RECONCILIATION_REQUIRED` + ورود مسدود |

ممنوعیت‌های صریح: (1) پاسخ موفق API تأیید نهایی لغو نیست (`mt5_broker.py:816-823` امروز `RETCODE_CANCELED` را بی‌قید برمی‌گرداند). (2) دیده‌نشدن در یک Snapshot اثبات لغو نیست. (3) ممکن است سفارش بین درخواست و پاسخ اجرا شده باشد. (4) بدون شاهد قطعی، `INCONCLUSIVE` می‌ماند و Authority محدود می‌شود. (5) این چهار مورد **Reconciliation Outcome** هستند، نه وضعیت lifecycle — گذارهای سمت راست فقط از طریق جدول §11.3 اعمال می‌شوند.

### ۱۲.۵ الزامات کیفیت Reconciler

Idempotent (اجرای دوباره همان شاهد، همان نتیجه؛ بدترکردن وضعیت ممنوع) · قابل تکرار (دستی و خودکار) · Audit Trail (زمان، ورودی، نتیجه، `operation_id`های متأثر) · بدون اثر جانبی (هرگز سفارش نمی‌فرستد، پوزیشن را تغییر نمی‌دهد، مالکیت را ارتقا نمی‌دهد). **تفکیک مالکیت (FIX-05):** Reconciler فقط **کشف/جمع‌آوری شاهد** (Order/Deal/Position) و ثبت نتیجهٔ Reconciliation می‌کند؛ **تشخیص، ایجاد و ارتقای state مالکیت صرفاً توسط OwnershipService** (§10.3) انجام می‌شود. فقدان/ناقص/مبهم بودن `opening_operation_id` ⇒ `UNKNOWN`/`AMBIGUOUS` — هرگز `OWNED`. وجود Deal به‌تنهایی (حتی در نتیجهٔ `FILLED` §12.4) هرگز مدرک خودکار OWNED نیست.

---

## ۱۳. چرخهٔ Startup و Shutdown (P0-7)

### ۱۳.۱ نمودار ترتیبی (منبع حقیقت ترتیب)

```text
[0] DENY_ALL_WRITES  ← از لحظهٔ شروع فرایند، پیش از هر چیز
      │
[1] بارگذاری Config + deployment_id          ── شکست ⇒ exit≠0
      │
[2] ACQUIRE Host-Level Lock                  ── شکست ⇒ exit≠0، هیچ اتصال MT5
      │
[3] Provenance: boot_epoch، نسل DB           ── شکست ⇒ exit≠0
      │
[4] MT5Broker(...) + connect()               ── شکست ⇒ disconnect + exit≠0   (هنوز DENY_ALL_WRITES)
      │
[5] Demo/Real (--allow-real)                 ── شکست ⇒ disconnect + exit≠0
      │
[6] Probe سرد (--cold-start)                 ── شکست ⇒ disconnect + exit≠0
      │
[7] build_components(...)                    ── شکست ⇒ disconnect + release + exit≠0
      │
[8] ارتقای SUBMISSION_PENDING/API_ACCEPTED → UNKNOWN   ── شکست ⇒ ورود مسدود
      │
[9] Reconciler + بارگذاری مالکیت             ── شکست ⇒ ورود مسدود تا نتیجه
      │
[10] باز شدن Authority: DENY_ALL_WRITES → (PARTIAL|OPEN) طبق ماتریس P0-1
      │
[11] Engine loop
```

> هیچ گام از [0] تا [9] مسیر نوشتن را باز نمی‌کند. ساخت `MT5Broker`، Probe، Bootstrap، Health Check و `build_components` در گیت `DENY_ALL_WRITES` اجرا می‌شوند. هیچ Constructor، CLI یا مسیر جایگزین نمی‌تواند گیت را دور بزند (L-4).

### ۱۳.۲ جدول گیت‌ها (سازگار با نمودار)

| # | گام | حالت Authority پس از گام | روی شکست |
|---|---|---|---|
| 0 | شروع فرایند | `DENY_ALL_WRITES` | — |
| 1 | Config + deployment_id | `DENY_ALL_WRITES` | exit≠0 |
| 2 | ACQUIRE Lock | `DENY_ALL_WRITES` | exit≠0، بدون MT5 |
| 3 | Provenance | `DENY_ALL_WRITES` | exit≠0 |
| 4 | Connect | `DENY_ALL_WRITES` | disconnect + exit≠0 |
| 5 | Demo/Real check | `DENY_ALL_WRITES` | disconnect + exit≠0 |
| 6 | Cold Probe | `DENY_ALL_WRITES` | disconnect + exit≠0 |
| 7 | build_components | `DENY_ALL_WRITES` | disconnect + release + exit≠0 |
| 8 | ارتقای ناتمام‌ها | `DENY_ALL_WRITES` | ورود مسدود |
| 9 | Reconciler + Ownership | `DENY_ALL_WRITES` | ورود مسدود |
| 10 | باز شدن Authority | `PARTIAL` یا `OPEN` | Fail-Closed |
| 11 | Engine loop | `OPEN` (یا `PARTIAL` در شرایط §6) | — |

**حالت `PARTIAL`:** فقط مسیرهای Reduce-Risk روی OWNED طبق ماتریس P0-1 (§6). Entry و Modify-risk-up همیشه `DENY` در `PARTIAL`.

**مرز Authority ← Entry (FIX-07):** تکمیل گیت‌های §13 فقط Authority را باز می‌کند (§6). ورود جدید (Entry) جداگانه مشروط به `entry_allowed` (§14.4) است — از جمله شرط `Ownership Provenable` (**Z-1 یا Z-2**). `Z-3`/انتقال دستی، حتی با تکمیل کامل گام‌های Z3-1..Z3-9، به‌تنهایی هرگز این شرط را برآورده نمی‌کند.

**Shutdown:** توقف ورود جدید → تخلیهٔ عملیات با سقف زمانی → `disconnect()` → Flush → Release Lock → exit 0.

**تناقض‌آزمایی v3:** این ترتیب I-0 را برمی‌آورد؛ در v1 قفل درون ExecutionAuthority (ساخته‌شده در گام ۷) پیشنهاد شده بود ⇒ تناقض، رفع شد. در v3.1 این تناقض با جدول/نمودار واحد P0-7 نهایی شد.

---

## ۱۴. Risk State و Execution State (R-06 + P0-1)

### ۱۴.۱ دو محور مستقل

| محور | سؤال | مقادیر |
|---|---|---|
| Risk State | آیا اجازهٔ گرفتن ریسک جدید داریم؟ | `NORMAL`, `SOFT_HALT`, `HALTED`, `KILLED`, `QUARANTINE` |
| Execution State | آیا می‌دانیم در بروکر چه رخ داده؟ | `CLEAN`, `PENDING_OPERATION`, `UNKNOWN_OPERATION`, `RECONCILE_STALE`, `OWNERSHIP_AMBIGUOUS` |

`acknowledge()` فقط محور Risk را تغییر می‌دهد و هرگز Execution State را `CLEAN` نمی‌کند. بازگشت Risk به `NORMAL` به‌هیچ‌وجه رفع Execution Uncertainty نیست.

### ۱۴.۲ ماتریس مجوز (خلاصهٔ غیرالزامآور — تاریخی؛ مرجع Normative فقط §6)

> **غیرالزامآور (FIX-04):** این جدول صرفاً خلاصه/پیشینه است و هیچ جوازی صادر نمی‌کند. **مرجع Normative تصمیم فقط §6 است**؛ در هر اختلاف، §6 حاکم است. همهٔ سلول‌های ✅/⚠️ مشروط به **Ownership=OWNED** هستند (ردیف‌های FOREIGN/AMBIGUOUS/UNKNOWN در §6: همه ❌). ستون‌های Risk این جدول بدون محور Ownership نمایش داده شده‌اند؛ **QUARANTINE** نیز طبق §6 همان شرط SOFT_HALT/HALTED/KILLED را دارد. شرط‌های OWNED / Grant / Execution / Risk معنای واحد در §6، §14.3 و P1-5 دارند (تعریف Grant در قواعد §6).

| عملیات | Risk=NORMAL ∧ Exec=CLEAN | Exec=PENDING/UNKNOWN | SOFT_HALT | HALTED | KILLED |
|---|---|---|---|---|---|
| Entry | ✅ | ❌ | ❌ | ❌ | ❌ |
| Modify (کاهش ریسک) | ✅ | ⚠️ فقط Reduce-Risk قابل‌اثبات (P1-5) روی OWNED؛ غیرقابل‌اثبات ⇒ فقط با Grant | ✅ | ✅ | ✅ |
| Modify (افزایش ریسک) | ✅ | ❌ | ❌ | ❌ | ❌ |
| Partial Close | ✅ | ⚠️ فقط کاهش‌ریسک روی OWNED | ✅ | ✅ | ✅ |
| Full Close | ✅ | ⚠️ فقط کاهش‌ریسک روی OWNED | ✅ | ✅ | ✅ |
| Flatten | ✅ (فقط OWNED) | ⚠️ فقط با مداخلهٔ انسانی §14.3 + audit | ✅ | ✅ | ✅ |
| Cancel Pending | ✅ | ⚠️ فقط اگر واقعاً Exposure را کاهش دهد (P1-5) و روی OWNED | ✅ | ✅ | ✅ |

> **اصلاح P0-1:** ستون‌های «Exec=PENDING/UNKNOWN» در v3.0 بدون توجه به Ownership مجوز کاهش‌ریسک می‌دادند. در v3.1 همهٔ این سلول‌ها مشروط به **Ownership=OWNED** شدند و به ماتریس واحد §6 گره خوردند. `--emergency-all` در v3.0 می‌توانست Flatten را در این ستون‌ها باز کند — اکنون فقط با فرایند §14.3 (مداخلهٔ انسانی) ممکن است و هرگز AMBIGUOUS/UNKNOWN را باز نمی‌کند.
 **FIX-04:** این جدول به خلاصهٔ غیرالزامآور تنزل یافت؛ مرجع Normative فقط §6 است.

**Fail-Closed = توقف ریسک جدید، نه توقف مدیریت.** کاهش‌ریسک روی OWNED در همهٔ حالت‌ها مجاز است؛ مسدود‌شده «ریسک جدید» و «اقدام کورکورانه» است.

### ۱۴.۳ مداخلهٔ اضطراری انسانی (P0-1 — تفکیک از ExecutionAuthority عادی)

| شرط | الزام |
|---|---|
| تأیید صریح | اپراتور باید عملیات را صریحاً تأیید کند (نه ضمنی) |
| شناسهٔ پوزیشن | هر عملیات به `ticket_broker`/`position_id_mt5` مشخص گره می‌خورد — نه «همه» کورکورانه |
| هویت اپراتور | نام/شناسهٔ اپراتور در Audit Trail ثبت می‌شود |
| Audit Trail | رویداد `EmergencyIntervention` با زمان، پوزیشن، عملیات، هویت اپراتور |
| محدوده | فقط روی **OWNED**؛ هرگز AMBIGUOUS/UNKNOWN |
| تفکیک | مسیر جدا از ExecutionAuthority عادی؛ `--emergency-all` مسیر عادی دور زدن Ownership Gate **نیست** |

### ۱۴.۴ `entry_allowed` — عطف هفت گیت

```text
entry_allowed = (Risk == NORMAL)
             ∧ (Execution == CLEAN)
             ∧ (هیچ عملیات باز)
             ∧ (ReconcileResult.clean ∧ تازه)
             ∧ (مالکیت سازگار: هیچ AMBIGUOUS/UNKNOWN)
             ∧ (Ownership Provenable: Z-1 یا Z-2 تأییدشده)
             ∧ (Authority == OPEN)          ← P0-7: نه DENY_ALL_WRITES، نه PARTIAL
```

امروز `check_state()` فقط شرط اول را می‌سنجد (`risk/checks.py:11-13`، VERIFIED).

> **FIX-07:** `Z-3` (انتقال دستی Operational) به‌تنهایی هرگز `Ownership Provenable` را برآورده نمی‌کند — فقط `Z-1` (اثبات‌شده) یا `Z-2` (تأییدشده). تکمیل Startup (§13) به‌تنهایی ورود جدید باز نمی‌کند. پذیرش ریسک انسانی/عملیاتی (AL-1 مکتوب، RS-03 — با امضا، تأیید مستقل، سلب Session و Audit) **جدا از اثبات فنی** تعریف شده و درگیت‌های §21 پیگیری می‌شود؛ هرگز به‌عنوان اثبات شمرده نمی‌شود.

### ۱۴.۵ KILLED — Latch

فعال‌سازی با `auto_clear = False`. امروز با `auto_clear=True` فعال می‌شود (`risk_engine.py:300-306` vs کامنت `:242-244`).
آزادسازی فقط با: بررسی انسانی + Reconciliation تمیز حساب + صفر عملیات باز + رویداد `KillClearAttempt` با هویت اپراتور.
Auto-clear نباید Execution Uncertainty یا KILLED را دور بزند.
`SOFT_HALT` / `HALTED` / `KILLED` پس از Restart پایدار می‌مانند (امروز درست است، `evidence/P06`).
قاعدهٔ سخت: هیچ وضعیت ریسکی مجوز دور زدن Execution Ownership یا Reconciliation نمی‌دهد — حتی KILLED (که فقط اقدام کاهش‌ریسک را باز می‌کند، نه Flatten بی‌قید را).

---

## ۱۵. دیتابیس و Persistence (P0-8)

### ۱۵.۱ وضعیت فعلی

| مورد | وضعیت فعلی | برچسب |
|---|---|---|
| محل State DB | `bootstrap.py:390` · `GOLDBOT_STATE_DB` > آرگومان صریح > همسایهٔ ژورنال | VERIFIED |
| Journal DB | `adapters/sqlite_store.py` (۵۵۰ خط) | VERIFIED |
| State DB | `adapters/sqlite_state_store.py` (۹۳ خط)، جدول تک‌ردیفی `risk_state` | VERIFIED |
| دوام | `journal_mode=WAL` (:151)، `synchronous=FULL` (:153)؛ State Store :33, :35 | VERIFIED |
| نوشتن | `append(event, *, fsync=True)` ⇒ commit | VERIFIED |
| Migration | افزایشی با `PRAGMA table_info` + `ALTER TABLE` | VERIFIED |
| جداول جدید پیشنهادی | `operation`، `position_ownership`، `authority_state`، (`execution_attempt` اختیاری) | DESIGN PROPOSAL |

الزام: فقط Migration افزایشی — بدون حذف ستون، بدون تغییر معنا. **هیچ Migration در این بازبینی اجرا نشد.**

### ۱۵.۲ Database of Record (P0-8 — تکلیف‌شده)

| داده | DB مرجع (Database of Record) | DB فرعی/مکمل | رابطه |
|---|---|---|---|
| `operation` | **State DB** | — | Journal فقط رویدادهای `OperationCreated`/`OperationTransition` را ثبت می‌کند؛ مرجع وضعیت، State DB است |
| `position_ownership` | **State DB** | — | Journal رویدادهای `OwnershipChanged` را ثبت می‌کند |
| `authority_state` (boot_epoch, generation, authority_mode) | **State DB** | — | Journal رویدادهای `AuthorityChanged` را ثبت می‌کند |
| رویدادها / Audit Trail | **Journal DB** | — | مرجع تاریخچهٔ رویدادها |
| `risk_state` | State DB (تک‌ردیفی موجود) | Journal رویدادهای تغییر | — |

**هیچ تراکنش بین دو DB وجود ندارد.** هر commit مستقل است. WAL + `synchronous=FULL` دوام **هر DB را به‌تنهایی** بالا می‌برد — **Atomic Transaction بین چند DB نیست** و هرگز چنین معرفی نمی‌شود.

### ۱۵.۳ رفتار Crash بین Commitها (بدون ادعای atomicity)

| سناریو | نتیجه | رفتار بازیابی |
|---|---|---|
| Commit در State DB، Journal ناتمام | وضعیت عملیات در State DB هست؛ رویداد ناقص | بازیابی از State DB؛ رویداد ناقص با `RecoveryGap` تکمیل می‌شود |
| Commit در Journal، State DB ناتمام | رویداد هست؛ وضعیت قدیمی | در Startup، مقایسهٔ State DB با Journal ⇒ عملیات ناهماهنگ → `RECONCILIATION_REQUIRED` |
| Crash وسط هر دو | نامشخص | Startup: قاعدهٔ پنج‌مرحله‌ای §9.5 + ارتقای ناتمام‌ها به UNKNOWN (P0-7 گام 8) |

**هرگز ادعای atomicity بین دو DB نمی‌شود. تأمین atomicity واقعی = OPEN-07 (UNRESOLVED).**

### ۱۵.۴ رفتار Backup/Restore و DB ناقص

| سناریو | رفتار |
|---|---|
| Restore از Backup قدیمی | مقایسه فقط با مرجع مستقل خارج از Backup معنا دارد؛ در Scope فعلی تعریف/تأیید نشده ⇒ **ادعای تشخیص قطعی حذف (FIX-06)**؛ مشاهدهٔ اختلاف ⇒ Fail-Closed؛ بازگردانی سازگارِ بدون مرجع ⇒ تشخیص‌ناپذیر — **OPEN-04 باز** |
| DB ناقص/خراب | Startup Fail-Closed؛ بدون بازیابی خودکار حدسی؛ اپراتور باید تصمیم بگیرد |
| فایل WAL باقی‌مانده | SQLite خودش بازیابی می‌کند؛ اگر ناقص باشد ⇒ Fail-Closed |
| جدول جدید غایب (Migration انجام‌نشده) | Startup تشخیص می‌دهد ⇒ Fail-Closed با پیام صریح |

### ۱۵.۵ سازگاری Risk State و Execution State

- هر دو در State DB ولی در جداول/ردیف‌های مجزا؛ هیچ تراکنش مشترک بین‌آن‌ها نیست.
- `acknowledge()` فقط `risk_state` را تغییر می‌دهد؛ هرگز `authority_state` یا `operation.status` را دست نمی‌زند (§14.1).
- در صورت ناهماهنگی (Risk=NORMAL ولی وجود `UNKNOWN_OPERATION`)، `entry_allowed` عطف همهٔ گیت‌ها (§14.4) ناهمسانی را می‌بندد — **نه با اتمیک‌بودن، بلکه با عطف چندگانه.**

---

## ۱۶. ماتریس ردیابی الزامات

جدول کامل با همهٔ ستون‌ها در `GoldBot_REQUIREMENTS_AND_TEST_MATRIX_v3.csv` (۲۰ REQUIREMENT + ۳۶ TEST + ۳ DEFERRED) — **UNCHANGED در v3.1** (فایل در دسترس نبود؛ خلاصهٔ عددی از v3.0 نقل شد). خلاصه:

| REQ | R | الزام | فایل‌ها | Test IDs |
|---|---|---|---|---|
| REQ-01 | R-01/R-05 | قفل پیش از ساخت بروکر؛ هیچ مسیر جایگزینی MT5Broker نسازد | `runtime/live.py`, `execution_authority.py` | T-01, T-02, T-03, T-25, T-28, T-29 |
| REQ-02 | R-01/R-05 | boot_epoch + نسل DB برای تشخیص Restore | `sqlite_store.py`, `execution_authority.py` | T-04, T-05, T-27, T-30, T-31 |
| REQ-03 | R-01 | UNPROVABLE = Fail-Closed (Z-4) | `execution_authority.py`, `risk/checks.py` | T-06, T-35 |
| REQ-04 | R-01 | انتقال مالکیت با پنج شرط اثبات + Z-3 (P0-2) | `docs/`, `runtime/cli.py` | T-36 |
| REQ-05 | R-02 | `position_ownership` با شش جزء + کلید مرکب (P0-5) | `sqlite_store.py`, `ownership.py` | T-17, T-18, T-19, T-36 |
| REQ-06 | R-02 | حذف Adopt پیش‌فرض در live | `position_manager.py`, `reconciler.py` | T-19 |
| REQ-07 | R-02/R-04 | همهٔ عملیات محدود به OWNED (شامل Flatten) | `engine.py`, `order_coordinator.py` | T-17, T-18, T-20 |
| REQ-08 | R-03 | `operation_id` پایدار + `client_intent_id` با UNIQUE بدون `payload_hash` + شمارنده‌های جداگانه (P0-6/FIX-01) | `operation_registry.py`, `sqlite_store.py` | T-09, T-13 |
| REQ-09 | R-03 | ماشین حالت ۱۰حالتهٔ پایدار (P0-4) | `operation_registry.py` | T-10, T-11 |
| REQ-10 | R-03 | ارتقای Startup به UNKNOWN؛ UNKNOWN پس از Restart زنده می‌ماند | `operation_registry.py` | T-08, T-12, T-23, T-33 |
| REQ-11 | R-03 | تفکیک Idempotency داخلی/بروکر (L-2) | `docs/`, `domain/events.py` | T-14 |
| REQ-12 | R-03/R-04 | Partial Close مقید به `target_volume` | `order_coordinator.py` | T-15 |
| REQ-13 | R-04 | ماتریس شواهد + وضعیت نهایی per-operation | `reconciler.py`, `ports/execution.py` | T-20, T-21, T-22, T-26, T-32, T-34 |
| REQ-14 | R-04 | چهار نتیجهٔ Cancel | `mt5_broker.py`, `reconciler.py` | T-22, T-32 |
| REQ-15 | R-04 | RESOLVED_ABSENT پنج‌شرطی + P1-1 | `reconciler.py` | T-07 |
| REQ-16 | R-06 | `entry_allowed` عطف هفت گیت؛ جداسازی دو محور | `risk/checks.py`, `engine.py` | T-07, T-11, T-12, T-24 |
| REQ-17 | R-04 | modify بدون Grant فقط کاهش‌ریسک (P1-5) | `mt5_broker.py` | T-16 |
| REQ-18 | R-06 | KILLED latched + خروج با شاهد | `risk_engine.py` | T-24 |
| REQ-19 | همه | رویدادهای حسابرسی مالکیت/عملیات/بلاک | `domain/events.py` | T-10, T-33 |
| REQ-20 | R-02 | `deployment_id` + `instance_id` | `adapters/config.py`, `ids.py`, `config/base.toml` | T-18, T-25 |
| REQ-21 (P0-1) | جدید | ماتریس تصمیم واحد Ownership×Execution×Risk | `docs/`, `execution_authority.py`, `ownership.py` | T-37 (پیشنهادی) |
| REQ-22 (P0-7) | جدید | `DENY_ALL_WRITES` در Startup تا پایان Recovery | `execution_authority.py`, `live.py` | T-38 (پیشنهادی) |
| REQ-23 (P0-8) | جدید | Database of Record تعریف‌شده + عدم ادعای atomicity بین DB | `docs/`, `sqlite_store.py` | T-39 (پیشنهادی) |
| REQ-24 (P1-4) | جدید | پوشش همهٔ مسیرهای نوشتن توسط Authority | `execution_authority.py`, `mt5_broker.py` | T-40 (پیشنهادی) |
| REQ-25 (P1-5) | جدید | تعریف محاسباتی Reduce-Risk | `ownership.py`, `order_coordinator.py` | T-41 (پیشنهادی) |
| REQ-26 (P1-7) | جدید | Standby = Read-Only + Forwarder | `docs/` | T-42 (پیشنهادی) |

> **نکته (P1-6):** REQ-21..REQ-26 برای پوشش مستقل اصلاحات جدید به ماتریس پیشنهاد شدند. چون فایل CSV در دسترس نبود، **به‌صورت سندی ثبت شدند و در فایل CSV اعمال نشدند** (UNRESOLVED برای CSV — ن.ک. گزارش Traceability، بخش ج).

هیچ REQ در وضعیت VERIFIED نیست — همه DESIGN PROPOSAL، چون هیچ‌کدام پیاده نشده است.

---

## ۱۷. استراتژی آزمون

### ۱۷.۱ دسته‌بندی (۳۶ تست، پیوسته T-01…T-36 + ۶ پیشنهادی T-37..T-42)

| لایه | تعداد | شناسه‌ها | CI |
|---|---|---|---|
| Unit | 9 | T-01…T-09 | ✅ |
| Integration (fake venue) | 15 | T-10…T-24 | ✅ |
| Fault Injection | 3 | T-25…T-27 | ✅ |
| Windows MT5 | 4 | T-28…T-31 | ❌ VPS ویندوز |
| MT5 Demo | 3 | T-32…T-34 | ❌ ترمینال واقعی |
| Two-VM | 2 | T-35, T-36 | ❌ دو VPS |
| **جمع** | **36** | — | **۲۷** |

۹ تست فیزیکی (T-28…T-36) جایگزین‌پذیر با هیچ تست مستند/شبیه‌سازی نیستند.

**تست‌های پیشنهادی v3.1 (T-37..T-42)** برای اصلاحات جدید P0-1/P0-7/P0-8/P1-4/P1-5/P1-7 — **NOT TESTED** و نیازمند افزودن به ماتریس پس از دسترسی به CSV.

### ۱۷.۲ وضعیت واقعی اجرا

| وضعیت | تعداد | شناسه‌ها |
|---|---|---|
| PASS | **0** | — |
| FAIL | 6 | T-12, T-13, T-15, T-16, T-23, T-27 |
| PARTIAL | 3 | T-11, T-14, T-24 |
| NOT TESTED | 27 | بقیه |

۹ از ۳۶ اجرا شده، ۲۷ اجرا نشده، صفر PASS. شواهد: `evidence/P02…P09` (REPORTED در این نسخه).

T-27 روی Linux با Multi-Writer مصنوعی اجرا شد، نه Windows. حکم FAIL واقعی است ولی جانشین T-28/T-31 نیست.

### ۱۷.۳ نگاشت ۱۹ سناریوی الزامی

| # | سناریو | Test ID | لایه | وضعیت |
|---|---|---|---|---|
| 1 | دو Process روی یک VPS | T-30 (پایه T-02, T-03) | Windows MT5 | NOT TESTED |
| 2 | دو VPS برای یک Account | T-35 | Two-VM | NOT TESTED |
| 3 | Lock پیش از MT5 Connect | T-01 | Unit | NOT TESTED |
| 4 | Crash هنگام ارسال | T-33 (پایه T-23) | MT5 Demo | NOT TESTED |
| 5 | Timeout پس از ارسال | T-23 | Fault Injection | FAIL (P08) |
| 6 | Restart با UNKNOWN | T-12 | Integration | FAIL (P03,P04) |
| 7 | Duplicate Close | T-13 / T-14 | Integration | FAIL / PARTIAL |
| 8 | Partial Close و Retry | T-15 | Integration | FAIL (P08) |
| 9 | Pending Cancel هم‌زمان با Fill | T-32 (پایه T-22) | MT5 Demo | NOT TESTED |
| 10 | Modify SL/TP با پاسخ نامشخص | T-16 | Integration | FAIL (P08) |
| 11 | Foreign Position | T-17 / T-19 | Integration | NOT TESTED |
| 12 | Shared Magic Base بین دو Deployment | T-18 | Integration | NOT TESTED |
| 13 | Flatten با Positionهای چند Instance | T-20 | Integration | NOT TESTED |
| 14 | Reconciliation پس از Restart | T-11 (پایه T-10) | Integration | PARTIAL (P03) |
| 15 | قطع ارتباط MT5 | T-34 | MT5 Demo | NOT TESTED |
| 16 | قطع ارتباط Control Plane | T-21 | Integration | NOT TESTED |
| 17 | VPS Migration | T-36 (پایه T-17) | Two-VM | NOT TESTED |
| 18 | شکست در آزادسازی Lock | T-29 | Windows MT5 | NOT TESTED |
| 19 | بازیابی پس از Host Restart | T-04 / T-05 / T-27 | Unit / Fault Injection | FAIL (P09 → T-27) |

### ۱۷.۴ معیار PASS

یک تست فقط وقتی PASS است که: خروجی خام ذخیره شده باشد · در لایهٔ درست اجرا شده باشد · شرط شکست نقض نشده باشد · با یک دستور بازتولید شود. **Simulated ≠ Real MT5.**

---

## ۱۸. دامنهٔ فایل‌به‌فایل (تخمینی، مشروط)

| # | فایل | LOC | طبقه | REQ |
|---|---|---|---|---|
| 1 | `runtime/live.py` | 397 | Must Change | REQ-01, REQ-02, REQ-22 |
| 2 | `runtime/bootstrap.py` | 437 | Must Change | REQ-01, REQ-08 |
| 3 | `app/order_coordinator.py` | 385 | Must Change | REQ-08, REQ-12, REQ-25 |
| 4 | `app/engine.py` | 1992 | Must Change | REQ-07, REQ-16 |
| 5 | `app/reconciler.py` | 158 | Must Change | REQ-13, REQ-14, REQ-15 |
| 6 | `app/position_manager.py` | 452 | Must Change | REQ-05, REQ-06 |
| 7 | `app/risk_engine.py` | 898 | Must Change | REQ-18 |
| 8 | `app/ids.py` | 51 | Must Change | REQ-20 |
| 9 | `adapters/mt5_broker.py` | 1488 | Must Change | REQ-14, REQ-17, REQ-24 |
| 10 | `adapters/sqlite_store.py` | 550 | Must Change | REQ-05, REQ-08, REQ-09, REQ-23 |
| 11 | `ports/execution.py` | 64 | Must Change | REQ-13 |
| 12 | `domain/events.py` | 206 | Must Change | REQ-19 |
| 13 | `app/risk/checks.py` | 175 | Must Change | REQ-16 |
| 14 | `tests/fake_broker.py` | 458 | Must Change | همه |
| 15 | `adapters/config.py` | 418 | May Change | REQ-20 |
| 16 | `config/base.toml` | — | May Change | REQ-20 |
| 17 | `runtime/cli.py` | 1273 | May Change | REQ-04 |
| 18 | `scripts/start_live.ps1` | — | May Change | REQ-01 (L-4) |
| 19 | `adapters/sqlite_state_store.py` | 93 | Needs Inspection | REQ-02, REQ-23 |
| 20 | `ports/broker.py` | 64 | Needs Inspection | REQ-13 |
| 21 | `app/health.py` | 238 | Needs Inspection | REQ-16 |
| 22 | `app/heartbeat.py` | 153 | Needs Inspection | — |
| 23 | `web/app.py` | 564 | No Change | — (جداسازی Backtest UI از Live Control Center یک تصمیم طراحی است، نه تغییر لازم این مرحله) |
| 24 | مدل‌ها / استراتژی‌ها / اندیکاتورها | — | No Change | — (مغز معاملاتی) |
| **25** | **(جدید) `app/execution_authority.py`** | ~270 | **New File** | REQ-01, REQ-03, REQ-22, REQ-24 |
| **26** | **(جدید) `app/operation_registry.py`** | ~210 | **New File** | REQ-08, REQ-09, REQ-10 |
| **27** | **(جدید) `app/ownership.py`** | ~170 | **New File** | REQ-05, REQ-21, REQ-25 |

**جمع:** ۱۴ Must Change · ۴ May Change · ۴ Needs Inspection · ۲ No Change (۲۴ ردیف اصلی) + **۳ فایل جدید** (ردیف ۲۵–۲۷). **۲۷ ردیف کل.**

هشدار: این طبقه‌بندی تخمینی است؛ Must Change یعنی «تغییر در این فایل لازم است»، نه «حجم تغییر قطعی است». نهایی‌شدن فقط پس از Gate 3.

---

## ۱۹. برآورد LOC (تخمینی و مشروط — P1-6 بازمحاسبه‌شده)

### ۱۹.۱ سه دستهٔ قطعیت

**C-1** = خوانده و اندازه‌گیری‌شده از سورس، تغییر قطعاً لازم · **C-2** = لازم ولی شکل نهایی هنگام پیاده‌سازی · **C-3** = نامشخص، نیازمند بررسی بیشتر.

### ۱۹.۲ برآورد per-file (بازمحاسبه — P1-6)

| فایل | + | − | دسته | مبنا |
|---|---|---|---|---|
| `runtime/live.py` | 45 | 12 | C-1 | ۵ نقطهٔ مداخله در ۳۹۷ خط |
| `runtime/bootstrap.py` | 30 | 15 | C-1 | wiring + حذف run_id از هویت |
| `app/order_coordinator.py` | 95 | 40 | C-1 | بازنویسی مسیر کلید + Intent |
| `app/engine.py` | 80 | 25 | C-2 | `_flatten` + دروازه + `entry_allowed` در ۱۹۹۲ خط |
| `app/reconciler.py` | 190 | 20 | C-1 | ماتریس شواهد + چهار نتیجه + RESOLVED_ABSENT |
| `app/position_manager.py` | 130 | 60 | C-1 | حذف Adopt + ردیف مالکیت |
| `app/risk_engine.py` | 30 | 8 | C-2 | Latch + خروج |
| `app/ids.py` | 30 | 8 | C-1 | هویت‌ها |
| `adapters/mt5_broker.py` | 120 | 30 | C-1 | Cancel + modify + مسیرهای نوشتن |
| `adapters/sqlite_store.py` | 175 | 5 | C-1 | جداول + Migration |
| `ports/execution.py` | 35 | 5 | C-1 | Interface |
| `domain/events.py` | 18 | 0 | C-1 | ~۱۲ ثابت |
| `app/risk/checks.py` | 50 | 10 | C-2 | دو Gate |
| `adapters/config.py` + `config/base.toml` | 20 | 3 | C-2 | deployment_id |
| `runtime/cli.py` | 40 | 5 | C-2 | گواهی/انتقال |
| `tests/fake_broker.py` | 90 | 20 | C-1 | پشتیبانی شواهد |
| **(جدید) `execution_authority.py`** | **270** | — | C-1 | Lock + Provenance + Gates + DENY_ALL_WRITES |
| **(جدید) `operation_registry.py`** | **210** | — | C-1 | ماشین حالت + Payload + Intent |
| **(جدید) `ownership.py`** | **170** | — | C-1 | مالکیت شش‌جزئی + ماتریس P0-1 |

**جمع ردیف‌ها:** **+۱٬۸۲۸ / −۲۶۶**

**تفکیک دسته‌ها (بازمحاسبه — P1-6):**

| دسته | + | − |
|---|---|---|
| C-1 | ۱٬۶۰۸ | ۲۱۵ |
| C-2 | ۲۲۰ | ۵۱ |
| C-3 | ۰ | ۰ |
| **جمع** | **۱٬۸۲۸** | **۲۶۶** |

**بازهٔ کل و مبنا (P1-6 + FIX-08):** مبنا = **جمع مستقیم ردیف‌های بالا: +۱٬۸۲۸ / −۲۶۶** (قابل بازتولید با جمع ستون‌ها). نوار عدم قطعیت = **حاشیهٔ قضاوتی یک‌طرفه** برای رشد احتمالی C-1/C-2 در پیاده‌سازی (هیچ محاسبهٔ آماری در کار نیست): **افزوده: ۱٬۸۲۸–۲٬۰۲۸ (+۲۰۰)** · **حذف: ۲۶۶–۳۱۶ (+۵۰)**. تفکیک صریح: جمع مستقیم (۱٬۸۲۸/۲۶۶) مرجع قطعی و بازتولیدپذیر است؛ نوار (+۲۰۰/+۵۰) صرفاً عدم قطعیت تخمینی است. جمع C-1/C-2/C-3 دقیقاً برابر جمع per-file است (۱٬۸۲۸/۲۶۶) — ناسازگاری v3.0 برطرف شد.

### ۱۹.۳ تعداد تست

۹ Unit · ۱۵ Integration · ۳ Fault Injection · ۴ Windows MT5 · ۳ MT5 Demo · ۲ Two-VM = **۳۶** (۲۷ CI-runnable، ۹ فیزیکی) + ۶ پیشنهادی v3.1 (T-37..T-42 — NOT TESTED).

### ۱۹.۴ آنچه حذف شد

«~۹۷٪ کد دست نمی‌خورد» و «۲ تا ۳ هفته» پس گرفته شدند و جایگزین نشدند. «۴۰۰+۲۵۰ LOC / ۶ فایل / ۱۷ تست» بازمحاسبه شد (§۱۸، §۱۹.۲).

### ۱۹.۵ فرضیات

برآورد بر پایهٔ خواندن همان فایل‌ها است، نه ابزار پیچیدگی. اگر `engine.py` (۱۹۹۲ خط) بازآرایی بیشتری بخواهد، سهم C-2 رشد می‌کند. هیچ عدد قطعی اعلام نمی‌شود؛ تثبیت فقط پس از Gate 3.

---

## ۲۰. فازهای پیاده‌سازی

| فاز | محتوا | پیش‌نیاز | خروجی |
|---|---|---|---|
| Phase 0 | تصویب سند؛ بستن یا پذیرش صریح OPEN-01..07 | این سند | Gate 2 |
| Phase 1 (R-01/R-05) | Authority + Lock + هویت + چرخهٔ عمر + DENY_ALL_WRITES | Gate 2 | T-01…T-06 |
| Phase 2 (R-02) | مالکیت + حذف Adopt + دروازه + کلید مرکب | Phase 1 | T-17…T-20 |
| Phase 3 (R-03) | Registry + ماشین حالت + Payload + `client_intent_id` | Phase 1 | T-08…T-15 |
| Phase 4 (R-04) | Reconciler + Cancel + RESOLVED_ABSENT + چند Deal | Phase 3 | T-21…T-23 |
| Phase 5 (R-06 + P1) | modify جهت‌دار، KILLED latch، رویدادها، Reduce-Risk محاسباتی | Phase 2–4 | T-16, T-24 |
| Phase 6 | آزمون واقعی Windows + MT5 Demo + Z-3 + Boot Race | Gate 3 | T-28…T-36, T-37..T-42 |
| Phase 7 (آینده) | Control Plane / Windows Agent / Account Mgmt / Dual Engine | Gate 5 | خارج از دامنه |

Phase 2 و 3 می‌توانند موازی شوند ولی هر دو به Phase 1 نیاز دارند. **Phase C آغاز نمی‌شود** تا Gate مربوطه تأیید شود. هیچ فازی قابلیت جدید خارج از Scope اضافه نمی‌کند.

---

## ۲۱. Acceptance Gates

### Gate 1 — Architecture Review 🟠 CONDITIONAL PASS — DOCUMENT CONSISTENCY ONLY

پس از FIX-01..FIX-08: هیچ تناقض مستنداتِ شناخته‌شده در مالکیت، Lock، Idempotency، Reconciliation، ماشین حالت (§11.3 مرجع واحد) و ماتریس مجوز (§6 تنها Normative) باقی نمانده · هر هشت P0 دارای Requirement + AC (وضعیت متنی — نه اثبات فنی) · هر هفت P1 دارای تعریف · مالکیت سازگار با Flatten/Reconciliation · Lock Lifecycle سازگار با Startup/Shutdown · Operation ID پایدار در Restart · Retry UNKNOWN بدون Reconciliation ممنوع · آزادسازی Risk Lock با Acknowledge ممکن نیست · DB of Record تعریف‌شده.

> **شرطی (CONDITIONAL) — FIX-08:** این PASS فقط برای **انسجام مستندات پس از FIX-01..08** است — نه اثبات کارکرد، نه بستن هیچ Open Risk. محدودیت‌های اجرایی/محیطی (دسترسی به سورس و Baseline، آزمون Windows/MT5، OPEN-01..07) همچنان باز است. اگر در بازبینی مستقل تناقض حل‌نشده‌ای یافت شود، وضعیت به `NOT PASSED` تنزل می‌یابد.

### Gate 2 — Implementation Authorization ⛔ NOT APPROVED

| شرط | وضعیت |
|---|---|
| Scope فایل‌ها، Migration، LOC، تست‌ها مشخص | ✅ §۱۸، §۱۹ (تخمینی) |
| روش جلوگیری از اجرای هم‌زمان چند VPS تعیین شده | 🟡 Z-1 قابل اثبات · Z-2 NOT VERIFIED · Z-3 Operational فقط (P0-2) — **به‌تنهایی ورود باز نمی‌کند (FIX-07)** · Z-4 Fail-Closed · شرایط پنج‌گانهٔ انتقال §۹.۲ + Z3-1..Z3-9 · بازگشت Host قدیمی = بخشی از OPEN-01 |
| محدودیت‌های اثبات‌نشده شفاف | ✅ AL-1 · L-2 · OPEN-01..07 |
| تأیید صریح انسانی | ⏳ لازم است |

**Gate 2: NOT APPROVED — تا اخذ مجوز صریح انسانی و تحقق شروط رسمی. به‌صورت خودکار PASS نمی‌شود.**

### Gate 3 — Implementation Review ⛔ NOT STARTED

مجوز صریح کاربر + Gate 2. صفر P0 باز · همهٔ تست‌های لازم اجرا و شاهد ثبت · Regression (1080 passed) بدون تغییر · Backtest بیت‌به‌بیت.

### Gate 4 — Windows/MT5 Demo Validation ⛔ NOT STARTED

۹ تست فیزیکی T-28…T-36 + T-37..T-42. Crash، Timeout، Restart، Reconnect، Migration، Z-3 عملیاتی، Boot Race (OPEN-06)، Suspend/Resume. گزارش خام الزامی.

### Gate 5 — Real Trading Readiness ⛔ NOT STARTED

صفر P0 باز · پذیرش کتبی AL-1 · دورهٔ Demo بدون حادثهٔ حل‌نشده · تأیید انسانی مستقل.

**هیچ Gateی صرفاً با تکمیل سند PASS نمی‌شود. هیچ ادعای آمادگی Real Trading مطرح نشد.**

---

## ۲۲. ریسک‌های باقی‌مانده

| ID | ریسک | سطح | کاهش | وضعیت |
|---|---|---|---|---|
| R-01 | I-5 غیرقابل اثبات (دو VPS) + بازگشت Host قدیمی با همان deployment_id/DB (FIX-07) | 🔴 دائمی | AL-1 · Z-2 (تنها اثبات سروری) · Z-3 فقط کاهش ریسک · Fail-Closed Z-4 · سلب دسترسی P-2/Z3-5 | باز (OPEN-01) |
| R-02 | Regression در مغز معاملاتی | 🟠 | Backtest بیت‌به‌بیت · صفر تغییر استراتژی | کنترل‌شده |
| **RS-03** | Refusal to adopt ⇒ Exposure بی‌مدیر | 🟠 | معاوضهٔ صریح §۱۰.۵ | نیازمند امضای کارفرما |
| R-04 | boot_epoch در بوت هم‌زمان | 🟠 | پنجرهٔ باقی‌مانده ثبت‌شده | باز (OPEN-04) |
| R-05 | Idempotency داخلی ≠ بروکر (L-2) | 🟠 | مستندسازی + `LinkIdempotencyScope` | باز (OPEN-02) |
| R-06 | History ناکافی برای RESOLVED_ABSENT | 🟠 | UNKNOWN باقی می‌ماند + P1-1 | باز (OPEN-03) |
| R-07 | Session 0/1 ویندوز تأییدنشده | 🔴 | Gate 4 | NOT VERIFIED |
| R-08 | DB + Backup هم‌زمان rollback (بازگردانی سازگار بدون مرجع مستقل) | 🔴 | ادعای تشخیص قطعی حذف (FIX-06)؛ Fail-Closed در صورت مشاهدهٔ اختلاف | باز (OPEN-04) |
| R-09 | Scope creep | 🔴 | قید Phase 1..5 | کنترل‌شده |
| R-10 | Erosion گاردها | 🟠 | آزمون معماری در Gate 3 | برنامه‌ریزی‌شده |
| R-11 | لبهٔ استراتژی اثبات‌نشده (PF 0.95) | 🔴 | خارج از دامنهٔ ایمنی | REPORTED |
| R-12 | قفل Launcher با گارد process-scan (check-then-act) | 🟠 | L-4 (قفل در Engine) | باز تا Phase 1 |
| **R-13** | Race بین بررسی مجوز و ارسال سفارش (P0-3) | 🟠 | ثبت به‌عنوان Open Risk | **باز (OPEN-06)** |
| **R-14** | عدم atomicity بین State DB و Journal DB (P0-8) | 🟠 | عطف چندگانه §14.4 + بازیابی §15.3 | **باز (OPEN-07)** |

---

## ۲۳. Evidence Register

| شاهد | محتوا | برچسب |
|---|---|---|
| P00 | محیط، Baseline، فهرست API | REPORTED (v3.0 — سورس در دسترس نبود) |
| P01 | تمام سایت‌های نوشتن (`order_send` ۷۰۵/۸۳۰/۸۷۵) | REPORTED (v3.0) |
| P02 | بقای UNKNOWN در حافظه؛ خالی پس از Restart | REPORTED (v3.0) |
| P03 | Restart: پایداری Risk، خالی بودن عملیات | REPORTED (v3.0) |
| P04 | `acknowledge` بدون حل عملیات ورود را باز می‌کند | REPORTED (v3.0) |
| P05 | کلیدهای Close بین دو Image متفاوت | REPORTED (v3.0) |
| P06 | پایداری شش ترکیب Latch | REPORTED (v3.0) |
| P07 | Cancel رد‌شده = `RETCODE_CANCELED` | REPORTED (v3.0) |
| P08 | ۶ سناریو روی Fake Venue | REPORTED (v3.0) |
| P09 | دو نویسندهٔ هم‌زمان، هر دو موفق | REPORTED (v3.0) |
| P10 | 1080 passed, 4 skipped, 1 xfailed | REPORTED (v3.0) |
| P11 | Suiteهای هدفمند | REPORTED (v3.0) |
| E-WIN-01 | رفتار واقعی دو Process روی Windows VPS | NOT VERIFIED — Gate 4، T-28/T-29/T-30/T-31 با لاگ و کد خروج |
| E-MT5-01 | Cancel/Fill/Timeout/Disconnect روی MT5 Demo | NOT VERIFIED — Gate 4، T-32/T-33/T-34 با retcode خام |
| E-BRK-01 | بیانیهٔ بروکر دربارهٔ ورود هم‌زمان | NOT VERIFIED — بیانیهٔ کتبی؛ پیش‌نیاز Z-2 |
| E-TWO-01 | انتقال Authority بین دو VPS | NOT VERIFIED — Gate 4، T-35/T-36 + گواهی توقف |
| E-DOC-01 | وجود فایل‌های ورودی v3.0 در Workspace | **NOT VERIFIED** — فایل‌ها موجود نبودند (§2) |
| E-BASE-01 | تطابق Baseline ZIP با SHA256 مرجع | **NOT VERIFIED** — فایل در دسترس نبود (باز — FIX-08: فقط با تطابق Hash واقعی بسته می‌شود) |
| E-DDL-01 | بررسی نحو/رفتار DDL سندی (`position_order_deal`، `operation`) در SQLite In-Memory موقت (بدون فایل DB) | VERIFIED — محدود به نحو و رفتار constraint (NULL/Duplicate/CHECK)؛ **تست پروژه نیست**؛ جزئیات در گزارش اعتبارسنجی v3.1.1 |

> **تفکیک:** هیچ شاهد جدیدی از سورس/اجرای پروژه VERIFIED نشد چون سورس/اجرای در دسترس نبود. کلیهٔ P00..P11 به REPORTED تنزل یافتند (نقل از v3.0 بدون بازتأیید). طراحی‌های جدید v3.1 همگی DESIGN PROPOSAL هستند. استثنای v3.1.1: E-DDL-01 (بررسی نحو DDL در SQLite In-Memory — فقط constraint، نه تست پروژه).

---

## ۲۴. تصمیم‌های معتبر حفظ‌شده

| تصمیم | وضعیت در v3.1 |
|---|---|
| Single Execution Authority به‌عنوان مسیر اصلی | 🟢 حفظ شد (§۶، §۱۳) |
| موتور Standby بدون اختیار اجرای سفارش | 🟢 حفظ و **تصحیح شد** (P1-7: Read-Only + Forwarder — نه «Reduce-Only با مسیر نوشتن») |
| تفکیک Control Plane از Execution Plane | 🟢 حفظ شد؛ Control Plane در Phase 7، خارج از مسیر سفارش (§۹.۵، §۲۰) |
| حفظ دو Strategy Slot موجود (`zones_m15`, `numeric_m5`) | 🟢 حفظ شد؛ هیچ تناقض فنی مستندی وجود ندارد (REPORTED، F-20) |
| جداسازی Backtest UI از Live Control Center | 🟢 حفظ شد به‌عنوان تصمیم طراحی. وضعیت امروز: `web/app.py` هر دو را سرو می‌کند (F-19) — جداسازی هدف است، نه واقعیت. تغییر آن در دامنهٔ این مرحله نیست (§۱۸ ردیف ۲۳ = No Change) |
| Toobit خارج از دامنه | 🟢 حفظ شد (صفر ارجاع) |
| Baseline v8.2.5 + Hash مرجع | 🟢 حفظ شد (§۲) — دسترسی NOT VERIFIED |
| ممنوعیت Phase C تا تأیید مستقل + مجوز صریح | 🟢 حفظ شد (§۲۰، §۲۱) |
| مغز معاملاتی تغییر نمی‌کند | 🟢 حفظ شد (§۱۸ ردیف ۲۴) |
| عدم صدور مجوز Real Trading | 🟢 حفظ شد (§۲۱ Gate 5 ⛔) |

---

## ۲۵. بازبینی صریح خطاهای v2 که در v3 اصلاح شد + تکمیل‌های v3.1

| # | خطای v2 | اصلاح در v3 | تکمیل در v3.1 |
|---|---|---|---|
| 1 | «قفل اجرایی در لایهٔ Python وجود ندارد» — نادرست | §۱.۳: قفل وجود دارد ولی در لایه/زمان اشتباه | حفظ شد |
| 2 | «هیچ Codeٔ قفل‌کننده‌ای نیست» در F-01 بدون تفکیک لایه | F-01 تفکیک شد | حفظ شد |
| 3 | فایل `scripts/start_live.ps1` در Scope نبود | §۱۸ ردیف ۱۸ = May Change (L-4) | حفظ شد |
| 4 | «سه دستهٔ پوزیشن» ولی پنج دسته تعریف شده بود | §۱۰.۴: پنج دسته | حفظ شد |
| 5 | جداسازی Backtest UI بدون وضعیت واقعی | §۲۴: تصمیم حفظ + واقعیت امروز | حفظ شد |
| 6 | انتقال مالکیت بدون شرط اثبات عددی | §۹.۲: پنج شرط P-1..P-5 | **تکمیل شد (P0-2): +گام‌های Z3-1..Z3-9** |
| 7 | تناقض §8 با §12 دربارهٔ UNKNOWN | — (باقی‌مانده در v3.0) | **رفع شد (P0-1): ماتریس واحد §6** |
| 8 | Z-3 به‌عنوان تضمین فنی | — (باقی‌مانده) | **رفع شد (P0-2)** |
| 9 | boot_epoch به‌عنوان Fencing | — (باقی‌مانده) | **رفع شد (P0-3): §9.7** |
| 10 | ماشین حالت ناقص | — (باقی‌مانده) | **رفع شد (P0-4): §11.3 ده حالت** |
| 11 | مدل مالکیت با PK تک‌ستونی | — (باقی‌مانده) | **رفع شد (P0-5): §10.3 کلید مرکب** |
| 12 | نبود Intent پایدار | — (باقی‌مانده) | **رفع شد (P0-6): §11.2** |
| 13 | گیت Startup ناقص | — (باقی‌مانده) | **رفع شد (P0-7): §13** |
| 14 | DB of Record مبهم | — (باقی‌مانده) | **رفع شد (P0-8): §15 — با OPEN-07** |
| 15 | ناسازگاری‌های عددی | — (باقی‌مانده) | **رفع شد (P1-6): §19 بازمحاسبه** |
| 16 | تناقض Standby | — (باقی‌مانده) | **رفع شد (P1-7): §24** |
| 17 | RESOLVED_ABSENT سست | — (باقی‌مانده) | **رفع شد (P1-1): §12.3** |
| 18 | چند Deal مدل‌نشده | — (باقی‌مانده) | **رفع شد (P1-2): §12.1 + §19.2** |
| 19 | CONFIRMED مبهم | — (باقی‌مانده) | **رفع شد (P1-3): §12.1** |
| 20 | پوشش مسیرهای نوشتن | — (باقی‌مانده) | **رفع شد (P1-4): §6 + §13** |
| 21 | Reduce-Risk برچسبی | — (باقی‌مانده) | **رفع شد (P1-5): جدول §5** |

---

## پاسخ صریح به پرسش‌های پایانی

**Gate 1 وضعیتش چیست؟** 🟠 CONDITIONAL PASS — DOCUMENT CONSISTENCY ONLY — فقط انسجام مستندات پس از FIX-01..08؛ نه اثبات کارکرد؛ شرطی و قابل تنزل در صورت یافتن تناقض (FIX-08).

**Gate 2 وضعیتش چیست؟** ⛔ NOT APPROVED — نیازمند مجوز صریح انسانی و تحقق شروط رسمی؛ به‌صورت خودکار PASS نشد.

**ریسک‌های باز:** OPEN-01 (مالکیت بین دو VPS / AL-1 — **شامل بازگشت Host قدیمی با همان deployment_id/DB — FIX-07**) · OPEN-02 (L-2، بدون Idempotency سمت بروکر) · OPEN-03 (کفایت History برای RESOLVED_ABSENT و کالیبراسیون Δ) · OPEN-04 (پنجرهٔ بوت هم‌زمان — **تشخیص قطعی Restore حذف شد؛ باز — FIX-06**) · OPEN-05 (طول comment ۳۱ کاراکتر) · **OPEN-06 (Race بررسی مجوز ←→ ارسال — P0-3)** · **OPEN-07 (عدم atomicity بین State DB و Journal DB — P0-8)** · RS-03 (نیازمند امضا) · R-07 (Session 0/1 ویندوز) · R-12 (گارد check-then-act در Launcher).

**شواهد لازم برای مرحلهٔ بعد:** تأیید انسانی سند · تصمیم مکتوب OPEN-01 + E-BRK-01 · پذیرش کتبی AL-1 و RS-03 · مجوز شروع پیاده‌سازی · سپس ۲۷ تست CI + Regression 1080 passed + Backtest بیت‌به‌بیت · و برای Gate 4: E-WIN-01، E-MT5-01، E-TWO-01، Z-3 عملیاتی، Boot Race.

---

**تکمیل‌های v3.1.1 (FIX-01..FIX-08):** هشت اصلاح هدفمند بر FROZEN v3.1 — مراجع دقیق هر FIX در سند تطبیق `GoldBot_v3_1_vs_v3_1_1_Clause_by_Clause_Traceability.md`.


**پایان سند. Source تغییر نکرد · Migration اجرا نشد · Deployment انجام نشد · سفارشی ارسال نشد · Phase C آغاز نشد · صفر تست PASS.**

---

## بخش Future Considerations (بدون تبدیل به Requirement)

- جداسازی کامل Backtest UI از Live Control Center (تصمیم طراحی — خارج از Scope این مرحله).
- Control Plane و Windows Agent (Phase 7 — خارج از Scope).
- Dual Engine — خارج از Scope و ممنوع در معماری جاری.
- Toobit Futures — خارج از Scope.
- هرگونه توسعهٔ استراتژیک جدید — خارج از Scope.

---

**DOCUMENT REVISION COMPLETE — IMPLEMENTATION NOT AUTHORIZED — SOURCE UNCHANGED — TESTS NOT EXECUTED — PHASE C NOT STARTED — AWAITING INDEPENDENT REVIEW**
