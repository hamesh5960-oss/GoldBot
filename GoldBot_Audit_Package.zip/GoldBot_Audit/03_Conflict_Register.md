# خروجی سوم — گزارش تناقضها (Conflict Register)

**نسخه:** AUDIT-REV-1.0 | **تاریخ:** 2026-11-21
**دامنه:** (الف) تناقضات درونی سند ورودی، (ب) تناقض سند با مست文档ات/API زنده Toobit، (ج) تناقضات احتمالی با سورس واقعی (مشروط به تکمیل دانلود).

---

## 1. تناقضات داخلی سند ورودی

| ID | محل دقیق | متن/مفهوم متناقض | نوع | پیامد | اصلاح | بخشهای همزمان |
|---|---|---|---|---|---|---|
| CF-01 | «معماری هدف» + CR-05 | از یک طرف «یک process فقط یک venue/instrument» و از طرف «پروفایل 24/7 Toobit» در حالی که همان سند RWA/TradFi بودن و تعطیلات را مطرح میکند | تعریف session | ورود در ساعات غیرقابل معامله | MarketStatus Engine زنده + OPEN-CAL-01 | §2, §5, §11 سند اجرایی |
| CF-02 | «Futures Risk» | هزینهها بهعنوان خط جداگانه بین فرمولها آمدهاند بدون مشخص بودن جایگاهشان | ابهام فرمول |-sizing اشتباه | فرمول cost-inclusive §4 | RTM-RISK |
| CF-03 | «قراردادهای دامنهای» + «Toobit API» | `qty_step/min_qty` را از exchangeInfo میگیرد، ولی جداگانه میگوید quantity بر حسب contracts است | واحد | خطای 1000× | OPEN-UNIT-01 + جدول واحد | §1.1, §4 |
| CF-04 | «Execution State Machine» + «TP/SL» | PROTECTED را موکول به استعلام algo-order میدهد، ولی نحوه filter TP/SL را نیاورده | نقص الگوریتم |positionme محافظتنشده | dual-query + stopCategory | §3.4 |
| CF-05 | «Toobit API» + «Position Mode» | از positionSide=V2 و Hedge Mode بهصورت همزمان یاد میکند ولی endpoint خواندن mode را معرفی نمیکند | قابلیت اثباتنشده | close اشتباه | OPEN-POSMODE-01 | §3.5 |
| CF-06 | «Roadmap» + «Test Strategy» | Roadmap «controlled validation» را بعد از simulation میدهد، ولی شروط آزادسازی real-money در انتها دوباره تکرار میشود بدون تعیین exactly gate | تکرار غیرقابلاندازهگیری | تفسیر سلیقهای | Gate E/G تعریفشده در خروجی هفتم | خروجی 7 |
| CF-07 | «وضعیت پذیرش» | «READY FOR KICKOFF / NOT READY FOR LIVE TRADING» یک وضعیت ترکیبی است و در انتها هم «REJECTED/APPROVED» خواسته شده | طبقهبندی وضعیت | ابهام حکم نهایی | جداسازی: حکم سند = REJECTED تا بسته شدن blockers؛ readiness توسعه = مشروط | خروجی 0/1 |
| CF-08 | اسناد بسته (طبق ادعای سند) | 77 / 79 / 80 فایل تست در سه سند + 71 فایل test_*.py واقعی | شواهد | عدم اعتماد به manifest | منبع واحد شمارش | AUD-M01 |
| CF-09 | README (طبق ادعای سند) | ارجاع به reports/audit و reports/review بدون وجود مسیر | ارجاع شکسته |LOSE rate | اضافه/حذف artefact | AUD-M02 |

---

## 2. تناقض سند با مست文档ات و API زنده Toobit

| ID | ادعای سند | شواهد مستقل | نوع | اصلاح |
|---|---|---|---|---|
| CF-10 | «Funding از 4H به 8H و سقف ±0.05% تغییر یافته» | `/api/v1/futures/fundingRate?symbol=XAU-SWAP-USDT` در 2026-11-21: `period=4H`, `cap=0.005`, `floor=-0.005`; اعلامیه 2026-01-30 همان ادعا را میدهد ولی API مرجع زنده است | منابع متعارض | API زنده مرجع؛ حذف عدد ثابت |
| CF-11 | «mins notional / step معمولی» (FAQ 5 USDT) | XAU-SWAP-USDT: `MIN_NOTIONAL=0`, `stepSize=0.001`, `maxQty=10000` | عمومی vs اختصاصی | per-symbol metadata |
| CF-12 | «24/7 futures profile» | `isRwa=true`, `rwaType=STOCK`, `categories=["TradFi"]` | فرض session | MarketStatus Engine |
| CF-13 | «Leverage announcement 500x tiers» | live tier1 value=1,000,000 / initial 0.002 / maint 0.001 / max 500؛ announce tier 60,000 / 0.1% | historical vs live | live riskLimits |
| CF-14 | «Index Price» بدون mapping | `?symbol=XAU` → `{}`؛ `?symbol=XAUUSDT` → مقدار | mapping | سه فیلد symbol جدا |
| CF-15 | «V2 مبنای regular و plan/TP-SL» | V2 algo-order type فقط STOP/STOP_MARKET؛ TP/SL مستقل V1 trading-stop | endpoint family | جدولاستثنا V1 |
| CF-16 | «پس از fill استعلام algo-order» | open-algo-orders بدون stopCategory فقط STOP؛ trading-stop بدون order id | الگوریوم ناقص | dual query |
| CF-17 | «کدام position mode؟» | مستندات positionMode endpoint ندارند | capability unknown | block |
| CF-18 | «هیچ testnet خارجی وجود ندارد» | مستندات بررسیشده بهصراحت این را تأیید نمیکنند، اگرچه چنین endpoint مستندشده نیست | نیازمند تأیید | OPEN-TESTNET-01 |

---

## 3. تناقضات احتمالی با سورس واقعی (تا تکمیل AUD-C01)

> موارد زیر **ادعاهای سند ورودی**اند و هنوز مستقیماً از ZIP تأیید نشدهاند. در صورتی که سورس پس از دانلود مغایرتی نشان دهد، این جدول بهروزرسانی میشود و RTM اصلاح میگردد.

| ID | ادعای سند درباره سورس | ریسک در صورت غلط بودن | اقدام هنگام در دسترس قرار گرفتن سورس |
|---|---|---|---|
| CF-S01 | `src/goldbot/ports/broker.py` حاوی `IBrokerGateway` | **تأیید شد** — متدها شامل connect/disconnect/health/is_ready/symbol_info/account/positions/orders/deals/submit/modify/close/find_by_client_ref/on_market_tick | مسیر واقعی همان است؛ قرارداد Futures جداگانه اضافه شود |
| CF-S02 | `src/goldbot/domain` مدلهای Tick/Bar/SymbolInfo/AccountSnapshot/PositionSnapshot/ApprovedOrder دارد | **تأیید شد** — علاوه برآنها `domain/execution.py`, `domain/money.py`, `domain/fsm/*`, `domain/symbol_meta.py` وجود دارند | مدلهای Futures جداگانه؛ Tick فعلی فاقد mark/index/funding |
| CF-S03 | `src/goldbot/app/order_coordinator.py` الگوی write-ahead/idempotency/UNKNOWN دارد | **تأیید شد** — `fsync=True` قبل از submit، idem=`run_id:intent_id`، `SubmitUncertain` → UNKNOWN | الگوی قابلاستفاده؛ stateها فاقد PROTECTION_PENDING/PROTECTEDاند (AUD-S01) |
| CF-S04 | `src/goldbot/runtime/bootstrap.py` composition root با injection است | **تأیید شد** — پارامترهای `live_broker/live_feed/live_clock/info_override` | runtime_toobit جداگانه؛ 0 import MT5 |
| CF-S05 | 1085 تست collect و 93 تست منتخب PASS | **collect=1085 تأیید شد**؛ اجرای کامل 1080 pass / 4 skip / 1 xfail (نه 1084 PASS) | اصلاح اعداد (AUD-S03) |
| CF-S06 | 73 فایل Python تحت tests/ و 71 test_*.py | **تأیید شد**؛ تناقض 77/79/80 applying باقی است | منبع واحد شمارش |

---

## 4. تصمیم نهایی درباره تناقضها

- تمام تناقضات Critical/High در سند اجرایی §05 اصلاح شده و دارای معیار پذیرشاند (CF-01…CF-17 بهجز CF-18 و CF-S01…S06).
- CF-18 بهعنوان **Open Decision** و CF-S01…S06 **بستهشده**اند و مانع صدور حکم APPROVED کاملاند.
- هر تناقض جدید کشفشده حین پیادهسازی باید با(ID جدول + ADR) درج و توسط مالک پروژه بسته شود.

---

## 5. تناقض با artefact اضافی مخزن GitHub

| ID | مورد | مفهوم | تصمیم |
|---|---|---|---|
| CF-V11 | `GoldBot_Toobit_Audit_v1_1.md` در مخزن GitHub | ممیزی قبلی حکم **APPROVED WITH CONDITIONS** با 3 شرط C-01…C-03 میدهد و مدعی «1084 pass + 1 xfail» است؛ برخی یافتههای آن (stopCategory، X-BB-APIKEY، position mode، هزینه circular) با ممیزی حاضر همخوانی دارد، ولی شمارش تست ومجموعهای از ادعاها متفاوتاند | آن سند بهعنوان **artefact تاریخی** ثبت شد و مرجع حکم حاضر نیست. اختلاف شمارش تست با شواهد اجرای مستقل حل شد (AUD-S03). تفاوتها در Change Log ثبتاند. |
