# خروجی ششم — ماتریس ردیابی الزامات (RTM)

**نسخه:** AUDIT-REV-1.0 | **تاریخ:** 2026-11-21
**راهنما:** «محل پیادهسازی» بر اساس **معماری پیشنهادی** است؛ نام فایل نهایی تیم توسعه تعیین میکند و قبل از merge با ساختار واقعی سورس (AUD-C01) تطبیق داده میشود. تا آن زمان هیچ نام فایل سورسadgetしない میشود.

| ID | الزام | ماژول مسئول | محل پیادهسازی (preposed) | تست مرتبط | معیار پذیرش |
|---|---|---|---|---|---|
| RTM-ARCH-01 | دو runtime مستقل، MT5 دستنخورده | Composition roots | runtime_mt5/, runtime_toobit/ | T-A01, T-F14 | import guard=0، regression parity |
| RTM-ARCH-02 | Shared Strategy Core بدون fork | shared/strategies | shared/strategies | T-A02 | diff strategy packages = 0 |
| RTM-ARCH-03 | state/DB/journal جدا | Persistence | var/mt5/, var/toobit/<alias>/ | T-F15 | shared DB=0 |
| RTM-ARCH-04 | kill switch مستقل | KillSwitch | runtime_*/KillSwitch | T-F16 | kill Toobit → MT5 heartbeat unchanged |
| RTM-DOM-01 | InstrumentSpec زنده | InstrumentRegistry | runtime_toobit/InstrumentRegistry | T-U03, T-C01 | TTL+source_ts، status gate |
| RTM-DOM-02 | Futures snapshots (account/position/market/order) | Domain futures | runtime_toobit/domain_futures | T-U01 | Decimal، field coverage |
| RTM-DOM-03 | VenueCapabilities fail-closed | Capability resolver | runtime_toobit/InstrumentRegistry | T-U02 | unknown→unsupported |
| RTM-DOM-04 | واحدها صریح (contracts vs underlying) | Type system + Adapter | runtime_toobit/types | T-U07, T-E03 | OPEN-UNIT-01 بسته |
| RTM-API-01 | Signer V2 deterministic | ToobitRESTClient | runtime_toobit/rest_client | T-U04, T-C02 | golden signature match |
| RTM-API-02 | time sync + recvWindow | ToobitRESTClient | runtime_toobit/rest_client | T-U05 | skew≤1000ms |
| RTM-API-03 | rate limit headers + 429 policy | RateLimiter | runtime_toobit/rest_client | T-U06, T-I02 | reset timestamp respected |
| RTM-API-04 | error mapping 5xx=UNKNOWN | ErrorMapper | runtime_toobit/rest_client | T-I03 | no blind retry |
| RTM-API-05 | symbol mapping XAU-SWAP-USDT / index XAUUSDT | InstrumentRegistry | runtime_toobit/InstrumentRegistry | T-C01 | live fixture pass |
| RTM-API-06 | funding period/cap زنده | FundingProvider | runtime_toobit/MarketDataFeed | T-U08, T-C03 | 4H فعلی، نه hardcode |
| RTM-API-07 | V1例外ها (margin/flashClose/trading-stop) مستندشده | Adapter | runtime_toobit/ToobitFuturesAdapter | T-C04 | endpoint contract tests |
| RTM-MD-01 | feed quality/stale/spread | MarketDataFeed | runtime_toobit/MarketDataFeed | T-U09, T-I04 | block on invalid |
| RTM-MD-02 | Toobit-only strategy input | Strategy binding | runtime_toobit/strategy_binding | T-A03 | 0 MT5 refs |
| RTM-MD-03 | Basis advisory + FX feed | BasisAnalyticsService | runtime_toobit/BasisAnalyticsService | T-U10 | no gate on unadjusted |
| RTM-RSK-01 | cost-inclusive sizing | FuturesSizingService | runtime_toobit/FuturesSizingService | T-U11, T-P01 | floor-down, monotonic |
| RTM-RSK-02 | leverage only affects margin | MarginService | runtime_toobit/MarginService | T-U12 | size independent of leverage |
| RTM-RSK-03 | tier/liq stress | MarginService | runtime_toobit/MarginService | T-U13, T-P02 | reject on stress fail |
| RTM-RSK-04 | daily/DD/exposure/concurrency | FuturesRiskEngine | runtime_toobit/FuturesRiskEngine | T-U14 | per-account caps |
| RTM-RSK-05 | funding cost in journal | Journal | runtime_toobit/Journal | T-C05 | rate/period recorded |
| RTM-ORD-01 | client idempotency unique | OrderCoordinator | runtime_toobit/OrderCoordinator | T-I05, T-R01 | 1 order per id |
| RTM-ORD-02 | timeout/5xx → quarantine | OrderCoordinator | runtime_toobit/OrderCoordinator | T-I06 | no resend |
| RTM-ORD-03 | partial fill → protection on filled qty | OMS | runtime_toobit/OrderCoordinator | T-I07 | qty match |
| RTM-ORD-04 | protection verified from venue | ProtectionService | runtime_toobit/ProtectionService | T-I08, T-E04 | dual query |
| RTM-ORD-05 | emergency close + verify | ProtectionService | runtime_toobit/ProtectionService | T-I09, T-R02 | position=0 before exit |
| RTM-ORD-06 | restart sequence + reconcile | Reconciler | runtime_toobit/Reconciler | T-R03 | 0 orphan |
| RTM-ORD-07 | external manual close detection | Reconciler | runtime_toobit/Reconciler | T-I10 | EXTERNAL_CLOSE logged |
| RTM-SEC-01 | secret store/redaction | Credentials | runtime_toobit/Credentials | T-S01 | grep secret=0 |
| RTM-SEC-02 | no withdrawal permission | API Key policy | external + UI | T-S02 | key scope reviewed |
| RTM-SEC-03 | WS reconnect/gap | WSEndpoint | runtime_toobit/WSEndpoint | T-I11 | resubscribe complete |
| RTM-SEC-04 | atomic journal + unique constraint | Persistence | runtime_toobit/Journal | T-U15 | no duplicate rows |
| RTM-SEC-05 | watchdog/heartbeat/graceful shutdown | Observability | runtime_toobit/Observability | T-F16 | shutdown order correct |
| RTM-UI-01 | runtime selector + independent enable | Web/UI | runtime_toobit/WebUI | T-UI01 | flags isolated |
| RTM-UI-02 | secret masked fingerprint | Web/UI | runtime_toobit/WebUI | T-S01 | no plaintext in DOM |
| RTM-UI-03 | sensitive changes confirmation | Web/UI | runtime_toobit/WebUI | T-UI02 | read-back required |
| RTM-UI-04 | reconciliation/critical alerts | Web/UI | runtime_toobit/WebUI | T-UI03 | visible within 5s |
| RTM-TEST-01 | MT5 regression parity | CI | tests/mt5_regression | T-A01 | 0 behavior diff |
| RTM-TEST-02 | controlled venue validation evidence | CI/Ops | tests/venue_validation | T-E01…E05 | IDs+responses archived |
| RTM-DOC-01 | Open Decisions closed before release | Governance | ADR register | T-G01 | all statuses CLOSED |
| RTM-DOC-02 | source audit completed | Governance | 01/03 registers | T-G02 | AUD-C01 closed |

---

## خلاصه پوشش
- الزامات: 43 شناسه
- ماژولهای بدون مسئول: 0
- تست بدون معیار pass/fail: 0
- موارد مشروط به بسته شدن Open Decisions: OPEN-UNIT-01, OPEN-TPSL-01, OPEN-POSMODE-01, OPEN-CAL-01, OPEN-TESTNET-01

---

## ضمیمه A — تطبیق RTM با سورس واقعی (تکمیل AUD-C01)

| الزام | مسیر واقعی تأییدشده در 8.2.5 | وضعیت |
|---|---|---|
| RTM-ARCH-01 | `src/goldbot/runtime/bootstrap.py`, `src/goldbot/runtime/live.py` | موجود؛_runtime_toobit جدای جدید لازم است |
| RTM-ARCH-02 | `src/strategies/numeric/strategy.py`, `src/strategies/zones/strategy.py` | موجود؛ بدون fork |
| RTM-ARCH-03 | `src/goldbot/adapters/sqlite_store.py`, `sqlite_state_store.py` | موجود؛ نمونه جدای Toobit لازم است |
| RTM-ARCH-04 |با `src/goldbot/app/engine.py`, `src/goldbot/runtime/cli.py` | الگوی kill موجود؛ نمونه مستقل Toobit لازم است |
| RTM-DOM-02 | `src/goldbot/domain/model.py`, `src/goldbot/domain/execution.py` | موجود ولی MT5-specific؛ مدل futures جدای الزامی |
| RTM-ORD-01/02 | `src/goldbot/app/order_coordinator.py`, `src/goldbot/domain/fsm/order.py`, `src/goldbot/domain/errors.py` | الگوی write-ahead/UNKNOWN موجود؛ PROTECTION state غایب |
| RTM-ORD-06 | `src/goldbot/app/reconciler.py` | موجود؛ سهطرفه شدن لازم است |
| RTM-RSK-01 | `src/goldbot/app/risk/sizing.py`, `app/risk/capital.py`, `app/costs.py` | MT5-specific؛ سرویس جدای لازم است |
| RTM-MD-01 | `src/goldbot/ports/marketdata.py` | ساده؛ FuturesMarketSnapshot جدای لازم است |
| RTM-UI-01 | `src/goldbot/web/app.py`, `src/goldbot/web/ui.html` | موجود؛ section Toobit اضافه شود |
| RTM-TEST-01 | `tests/` (73 فایل Python، 71 `test_*.py`) | 1085 collect، 1080 pass، 4 skip، 1 xfail |

**تذکر:** RTM بالا الزامات آینده را به مسیرهای پیشنهادی آینده نگاشت میکند؛ ضمیمه A صرفاً نشان میدهد کدامپیشساخته فعلاً در 8.2.5 هست و کدام باید اضافه شود. هیچ نام فایلی که مستقیماً از ZIP مشاهده نشده در جدول نیامده است.
