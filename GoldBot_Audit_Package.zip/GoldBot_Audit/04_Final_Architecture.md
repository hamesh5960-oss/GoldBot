# خروجی چهارم — معماری نهایی پیشنهادی

**نسخه:** AUDIT-REV-1.0 | **تاریخ:** 2026-11-21

---

## 1. اصول حاکم (غیرقابل مذاکره)

1. **یک Codebase، دو Runtime مستقل.** Shared Strategy Core تنها بخشی است که بهطور عمدی shared است.
2. **MT5 Immutable Baseline.**یک Toobit additive است: ماژول/config/runtime/test جدید؛ بدون تغییر رفتاری MT5.
3. **Venue-owned truth.** وضعیت سفارش/پوزیشن/حفاظت فقط ازvenue تأیید میشود.
4. **Fail-closed.** هر ابهام در وضعیت/واحد/حفاظت → block new entry + reconciliation.
5. **Account-scoped ownership.** یک نویسنده برای state هر (account, symbol)؛ idempotency توسط client order id.
6. **Independent kill switch.** STOP_NEW_ENTRIES و EMERGENCY_FLATTEN=jداگانه بهازای_runtime.

---

## 2. نقشه اجزا و مرز مسئولیت

```
GoldBot Repository
├── shared/
│   ├── strategies/            zones, numeric, signal/confirmation/tier/decision
│   ├── risk_policy/           risk_pct, daily/DD/concurrency caps (بدون sizing)
│   ├── journal_contracts/     correlation id, payload hash, redaction
│   └── observability/         heartbeat, metrics, alert contract
│
├── runtime_mt5/               (existing v8.2.5 composition — دستنخورده)
│   ├── MT5BrokerAdapter       (بدون تغییر)
│   ├── MT5MarketDataFeed      XAUUSD
│   ├── MT5Sizing              contract_size/volume_step
│   ├── mt5/{journal, risk_state}.db
│   └── KillSwitchMT5
│
└── runtime_toobit/            (جدید، process مستقل)
    ├── config/                toobit_enabled, trading_enabled, account_alias
    ├── ToobitRESTClient       signer, time sync, rate limiter, error map
    ├── ToobitWSEndpoint       reconnect/resubscribe/gap detection
    ├── ToobitMarketDataFeed   bid/ask/last/mark/index/funding/book + quality
    ├── InstrumentRegistry     exchangeInfo cache + TTL + validation
    ├── ToobitFuturesAdapter   regular/plan/tp-sl/close/flashClose
    ├── FuturesSizingService   risk budget → contracts (cost-inclusive)
    ├── MarginService          tier/leverage/margin/liquidation guards
    ├── ProtectionService      attach + verify + retry + emergency
    ├── ToobitOrderCoordinator write-ahead/idempotency/unknown/quarantine
    ├── ToobitReconciler       startup + periodic + post-error
    ├── FuturesRiskEngine      limits per account
    ├── toobit/{journal, risk_state}.db؛ aliases مستقل
    ├── BasisAnalyticsService  advisory only
    ├── WebAPI + UI            جداگانه از MT5، بدون calls مستقیم بهvenue
    └── KillSwitchToobit
```

### جدول مسئولیتها

| جزء | مسئول | **مسئول نیست** |
|---|---|---|
| Shared Strategy Core | سیگنال، zone، confirmation | pricing اجرایی، sizing، API calls |
| ToobitMarketDataFeed |Data quality, timestamp, stale, mark/index/funding | تصمیم معامله |
| InstrumentRegistry | metadata زنده + expiry | حجم/ریسک |
| FuturesSizingService | تعداد قرارداد،成本، step | ارسال سفارش |
| MarginService | tier, margin, liquidation guard | ریسک per-trade |
| ToobitOrderCoordinator | state machine, idempotency, timeout | تصمیم استراتژی |
| ProtectionService | ایجاد + **اثبات** SL/TP | فرض PROTECTED |
| ToobitReconciler | venue truth → local state | ارسال ورودی جدید |
| FuturesRiskEngine | daily/DD/exposure/concurrency | محاسبه contracts |
| BasisAnalytics | monitoring/advisory | gate معاملاتی |
| MT5 Adapter | رفتار فعلی 8.2.5 | هرگونه Futures logic |

---

## 3. جریان داده (Data Flow)

### 3.1 مسیر عادی
```
Toobit WS/REST → Feed (quality gate) → FuturesMarketSnapshot
   → Shared Strategy Core (بدون MT5 data) → Signal
   → FuturesRiskEngine (limit check) → FuturesSizingService (contracts)
   → MarginService (tier/margin/liq stress) → Risk Approval
   → OrderCoordinator (ticket + write-ahead + client id)
   → ToobitFuturesAdapter → V2 REST order
   → fills/position → ProtectionService → verify via algo orders
   → PositionManager → Exit → Reconciler → Journal
```

### 3.2 مسیرreference اختیاری
```
MT5 XAUUSD feed → BasisAnalytics (با FX feed) → UI advisory
                     └─iagnostic flags → block gate فقط در صورت data corruption (نه basis threshold)
```
هیچ استقراری از XAUUSD MT5 به سیگنال/entry/SL/TP Toobit وجود ندارد.

---

## 4. چرخه سفارش و_positionstate

### 4.1 States
```
CREATED → SUBMITTING → ACKNOWLEDGED → PARTIALLY_FILLED → FILLED
        → PROTECTION_PENDING → PROTECTED → MANAGED → CLOSING → CLOSED
        ↘ REJECTED / CANCELED / EXPIRED / UNKNOWN / QUARANTINE
```

### 4.2 جدول انتقال (خلاصه)
| از | به | شرط | مسئول |
|---|---|---|---|
| CREATED | SUBMITTING | risk approval + client id | Coordinator |
| SUBMITTING | ACKNOWLEDGED | `orderId` + `status` معتبر | Adapter |
| SUBMITTING | UNKNOWN | timeout/5xx | Adapter |
| UNKNOWN | QUARANTINE | عدم اثبات absence | Coordinator |
| QUARANTINE | SUBMIT/REJECT | reconciliation نتیجه داد | Reconciler |
| ACKNOWLEDGED | PARTIALLY_FILLED | `0<executedQty<origQty` | Adapter |
| PARTIALLY_FILLED | FILLED | sum trades == origQty + position تأیید | Reconciler |
| FILLED | PROTECTION_PENDING | position>0 | ProtectionService |
| PROTECTION_PENDING | PROTECTED | ردیف venue با مشخصات کامل | ProtectionService |
| PROTECTION_PENDING | QUARANTINE/EMERGENCY | فقدان ردیف | ProtectionService |
| MANAGED | CLOSING | exit signal / risk stop / kill | PositionManager |
| CLOSING | CLOSED | position=0 + algo terminal | Reconciler |

### 4.3 قواعد منع
- Client Order Id ثابت و یکتا؛ duplicate → استعلام، نه ارسال مجدد.
- Retry policy: فقط auth/symbol/permission خطا → **no retry**؛ 429 → reset header؛ 5xx/timeouts → QUARANTINE + query؛ network pre-send → retry با همان id.
- Protection quantity بر اساس fill واقعی، نه intention.
- Post-restart: توالی `time → exchangeInfo → account → positions → regular orders → algo orders (STOP و STOP_PROFIT_LOSS) → trades → local reconcile`.

---

## 5. استقلال Runtime و اثر متقابل

| سناریو | نتیجه مورد انتظار |
|---|---|
| Toobit process crash | MT5 heartbeat/signals/orders بدون تغییر؛ Toobit DB قفل نشود |
| MT5 process crash | Toobit runtime به کار خود ادامه دهد |
| Toobit kill switch | MT5 کماکان معامله کند (مگر policy مالک مخالف) |
| Toobit config corrupt | فقط Toobit fail-closed؛ MT5 config دستنخورده |
| Shared package change | golden regression MT5 قبل از merge الزامی |

---

## 6. مرز Strategy Core / Execution Adapter (پاسخ صریح)

- **Strategy Core** فقط ورودی `FuturesMarketSnapshot` معتبر میپذیرد و خروجی آن `Signal intent` است (بدون symbol venue،بدون quantity، بدون credential).
- **Execution Adapter** intent را به `FuturesOrderCommand` با symbol/positionSide/quantity/client id تبدیل میکند و مسئول acknowledgment/fill/protection است.
- وابستگی MT5 وارد Futures نمیشود: هیچ import از `adapters.mt5*`، `MetaTrader`، `symbol_info` MT5 در runtime_toobit مجاز نیست (Test: architecture import-guard).
- مدلهای MT5 برای Futures استفاده نمیشوند (مدلهای additive جدا).

---

## 7. استقرار و Rollback

- دو process، دو config، دو DB، دو credential store.
- Feature flags: `toobit_enabled=false`, `trading_enabled=false`, `read_only_mode=true` پیشفرض.
- Start order: read-only validation → simulation → controlled write.
- Rollback: stop-new → read venue positions/orders/protection → flatten in lieu of leaving open → سپس process خاموش. Migration additive/versioned.
- Emergency CLI مستقل از پنل،verify نتیجه درvenue الزامی.

---

## 8. معیارهای معماری قابل اندازهگیری

| معیار | آستانه |
|---|---|
| import MT5 در runtime_toobit | 0 |
| state DB shared بین runtime | 0 |
| سفارش تکراری با همان client id | 0 |
|positionme بدون protection تأییدشده بعد از fill | 0 |
| تفاوت رفتار MT5 golden regression | 0 یا ADR مصوب |
| اثر kill Toobit بر MT5 heartbeat | 0 |
| الزام stopCategory در protection verification | 100%雙 query |
