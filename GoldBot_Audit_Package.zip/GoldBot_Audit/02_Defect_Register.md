# خروجی دوم — جدول کامل ایرادات (Defect & Finding Register)

**نسخه:** AUDIT-REV-1.0 | **تاریخ:** 2026-11-21
**سطوح:** Critical / High / Medium / Low
**وضعیت:** `OPEN` = حل نشده؛ `FIXED-IN-SPEC` = در سند اجرایی اصلاح شده ولی نیازمند پیادهسازی/تست؛ `BLOCKER` = مانع تأیید نهایی.

> هیچ Iranian Critical یا High بدون راهکار و معیار پذیرش باقی نمانده است؛ BUT پیادهسازی و اثبات عملکرد واقعی **انجام نشده** و این جدول فقط وضعیت مستند را توصیف میکند.

---

## A. ایرادات Critical

| ID | شدت | محل (سند ورودی / منبع) | یافته و شواهد | پیامد فنی | راهکار اصلاح | معیار پذیرش | وضعیت |
|---|---|---|---|---|---|---|---|
| AUD-C01 | Critical | مرحله ۱ — لینک ZIP | **`CLOSED 2026-11-21`**: لینک Gofile مسدود بود؛ مالک مخزن GitHub جایگزین معرفی کرد. ZIP همان فایل (`3baed37d…`, 769,436 bytes, 293 عضو) از مخزن `hamesh5960-oss/GoldBot` دانلود و استخراج شد. تمام ادعاهای سورس بازبینی شدند. | — | — | SHA256SUMS 292/292، compileall PASS، pytest 1080 pass/4 skip/1 xfail، 0 refs Toobit. | **CLOSED — شواهد در `evidence/`** |
| AUD-C02 | Critical | سند ورودی، بخش Futures Risk؛ «اطلاعیه 2026-01-30 … 8 ساعته» | API زنده 2026-11-21: `period=4H`, `cap=0.005`, `floor=-0.005`, `rate=0`. اعلامیه 8H/±0.05% با API زنده تناقض دارد. (`evidence/funding_XAU.json`) | funding buffer 2× اشتباه و سقف هزینه 10× اشتباه → ریسک واقعی > محاسباتی. | حذف عدد ثابت 8H؛ خواندن `period/rate/cap/floor/nextFundingTime` در startup و هر دوره؛文书 notify تغییر. | Golden fixture شامل پاسخ زنده؛ تست تأیید میکند buffer براساس `period` API محاسبه شده و در journal ثبت میشود. | FIXED-IN-SPEC |
| AUD-C03 | Critical | سند ورودی، قراردادهای دامنهای `qty_step/min_qty` و «quantity API بر حسب contracts» | مستند exchangeInfo میگوید LOT_SIZE «token quantity not contracts»؛ ولی userTrades.qty صریحاً contracts است و historyPositions یادآوری میکند مقادیر به underlying تبدیلشدهاند. واحد `positions[].position` مبهم است. | حجم 1000 برابر اشتباه، sizing و protection quantity غلط، ریسک کنترلنشده. | OPEN-UNIT-01: قبل از هر write، controlled validation با حداقل حجم + read-back order/position؛ نگهداری `quantity_unit_source` در مدل؛ fail-closed تا اثبات. | پاسخ order نشان دهد `origQty` با quantity ارسالی و `position` با multiplier چگونه مطابقت دارد؛ تست unit حالت «واحد نامعلوم → reject» pass کند. | FIXED-IN-SPEC / OPEN |
| AUD-C04 | Critical | سند ورودی، Execution State Machine: «پس از fill … از endpointهای algo-order استعلام شود» | مستند V2: `GET /api/v2/futures/open-algo-orders` در صورت حذف `stopCategory` **فقط plan STOP** را برمیگرداند؛ `POST /api/v1/futures/position/trading-stop` اصلاً order id برنمیگرداند. |.positionme بدون حفاظت واقعی PROTECTED تلقی شود → زیان کنترلنشده. | dual query (`stopCategory=STOP_PROFIT_LOSS` و بدون آن) + تطبیق `stopOrderType/side/positionSide/stopPrice/origQty` + orderId؛ در نبود ردیف → protection retry سپس emergency close. | Failure-injection تست نشان دهد halted entries + flatten وقتی ردیف TP/SL غایب است. | FIXED-IN-SPEC |
| AUD-C05 | Critical | سند ورودی، فرمول Futures Risk (خطوط جداگانه fees/slippage/funding) | مشخص نشده هزینهها در numerator قرار میگیرند یا در loss_per_contract؛ ورود بر mid فرض شده. | ریسک محاسباتی کمتر از واقعی؛ capitalization اشتباه. | فرمول cost-inclusive و execution-entry-based در §4 سند اجرایی؛ تمام مقادیر Decimal؛ stress check. | Property test: برای هزینه مثبت، حجم محاسباتی严格 کمتر از حجم بدون هزینه است؛ stop distance صفر → reject. | FIXED-IN-SPEC |
| AUD-C06 | Critical | معماری دو runtime (سند ورودی درست گفته ولی اجرای آن الزام نشده) | هرگونه state/risk DB مشترک یا Gateway مشترک میتواند MT5 و Toobit را بههم گره بزند. | خرابی/kill One runtime روی دیگری اثر میگذارد؛ سفارش تکراریبین حسابها. | DB و journal و credential و kill switch کاملاً جدا؛ single-writer per account/symbol؛ unique `(account_alias, client_order_id)`. | Restart/chaos test: kill Toobit runtime → MT5 heartbeat و رفتار سفارش بدون تغییر. | FIXED-IN-SPEC (نیاز به تست) |

---

## B. ایرادات High

| ID | شدت | محل | یافته | پیامد | راهکار | معیار پذیرش | وضعیت |
|---|---|---|---|---|---|---|---|
| AUD-H01 | High | سند ورودی: «در API V2 … PLAN/TP-SL جدا» | `POST /api/v2/futures/algo-order` فقط `type=STOP/STOP_MARKET` را میپذیرد؛TP/SL مستقل از طریق V1 `position/trading-stop` یا پارامترهای چسبیده است. | پیادهساز نمیتواند SL stand-alone را در V2 ایجاد کند. | قرار دادن سه مسیر حفاظت جدول §3.4 و OPEN-TPSL-01. | Controlled validation每一位 مسیر؛ لاگ order id قابل استعلام. | FIXED-IN-SPEC |
| AUD-H02 | High | سند ورودی CR-05: «Toobit پروفایل 24/7» | exchangeInfo زنده: `isRwa=true, rwaType=STOCK, categories=[TradFi]`. فرض 24/7 اثباتنشده. | ورود در ساعات بسته/تعطیل یا رفتار متفاوت RWA. | MarketStatus Engine زنده؛ OPEN-CAL-01؛ fail-closed در نبود status. | لاگ چند بازه زمانی و رفتار block/open مطابقvenue. | FIXED-IN-SPEC / OPEN |
| AUD-H03 | High | سند ورودی: جدول leverage/announcement 500x | اعلامیه 2026-03-02 tier 0–60k/0.10% را میدهد؛ API زنده tier 0–1M/0.2%/0.1% میدهد. | محاسبه margin tier غلط. | `riskLimits` زنده مرجع؛ announce فقط historical. | Golden fixture + unit test tier selection. | FIXED-IN-SPEC |
| AUD-H04 | High | سند ورودی: Position mode | مستندات بررسیشده endpointی برای read/switch position mode نشان نمیدهد؛ `accountLeverage` فقط marginType/leverage میدهد. | فرض One-Way/Hedge اشتباه → close و protection اشتباه. | OPEN-POSMODE-01 + block ورود تا تأیید；液面از positionSide صریح V2. | تأیید مالک + controlled read + تست close LONG/SHORT. | FIXED-IN-SPEC / OPEN |
| AUD-H05 | High | سند ورودی: مدلهای MT5 (Tick, SymbolInfo, ApprovedOrder) | مدلها فاقد mark/index/funding/positionSide/margin/contractsاند (طبق سند ورودی؛ تأیید سورس بماند). | خطای واحد و ریسک مالی. | مدلهای additive futures؛ بدون تغییر مدل MT5. | Contract test: مدل MT5 قدیمی compile و regression parity. | FIXED-IN-SPEC (مشروط به سورس) |
| AUD-H06 | High | سند ورودی: `compute_volume` فعلی | فرمول MT5 بر contract_size/volume_step است و نباید مستقیماً فراخوانی شود. | حجم اشتباه. | futures-specific sizing service؛ نامگذاری جداگانه. | Unit testsță مرزها +عدم فراخوانی تابع MT5 توسط adapter. | FIXED-IN-SPEC (مشروط به سورس) |
| AUD-H07 | High | سند ورودی: Basis و XAUUSD MT5 reference | خطر تأخیر/قیمت متفاوت و فرض USD=USDT. | سیگنال اشتباه. | strategy Toobit فقط feed Toobit؛ Basis advisory؛ FX feed معتبر. | Golden fixtures + stale test + absence → gate off. | FIXED-IN-SPEC |
| AUD-H08 | High | سند ورودی: تستها | بکـتست منفی (−158.34 USD, PF 0.95, DD 8.66%) و دمو بدون fill واقعی. | هرگونه ادعای readiness/sودآوری نادرست. | Release gate صریح NOT READY；شواهد fill قبل از ادعا. | اجرای Gate E و موجود بودن Order ID/journal. | FIXED-IN-SPEC |
| AUD-H09 | High | سند ورودی: «No testnet» | این ادعا در مستندات بررسیشده بهصورت صریح تأیید نشد؛ فقدان testnet عملاً ریسک controlled validation را بالا میبرد. | تست write روی capital واقعی. | OPEN-TESTNET-01؛ read-only → simulation → controlled small-size. | بررسی رسمی/poc و ثبت نتیجه در ADR. | OPEN |
| AUD-H10 | High | سند ورودی: order lifecycle | 5xx بهعنوان UNKNOWN و 403/429_policyTokenبهطور یکسان retry میشدند. | سفارش تکراری یا لاگ اشتباه. | جدول طبقهبندی خطا + QUARANTINE. | Failure injection: 5xx → query، 403 → no retry. | FIXED-IN-SPEC |
| AUD-H11 | High | سند ورودی: emergency stop | Flash close مستند در سند ورودی نیامده؛ تنها «close اضطراری» مبهم است. |positionme باز بماند. | flashClose V1 + verify reconciliation. | تست shutdown با position باز → position=0 قبل از exit. | FIXED-IN-SPEC |
| AUD-H12 | High | سند ورودی: Spot/Futures symbol format | `XAUUSDT` (نمایش) در برابر `XAU-SWAP-USDT` (API) و index `XAUUSDT` (نه `XAU`). `/quote/v1/index?symbol=XAU` خالی است. | mark/index اشتباه. | canonical/venue/index symbols جداگانه در InstrumentSpec. | Golden fixture index/mark. | FIXED-IN-SPEC |

---

## C. ایرادات Medium

| ID | محل | یافته | راهکار | معیار پذیرش |
|---|---|---|---|---|
| AUD-M01 | اسناد بسته (طبق سند ورودی) | شمارش تست 77/79/80 در حالی که 71 فایل `test_*.py` ادعا شده | منبع واحد شمارش + generate自动了 manifest | اجرای اسکریپت شمارش، تطابق سه سند |
| AUD-M02 | README (طبق سند ورودی) | ارجاع به `reports/audit`, `reports/review` بدون وجود مسیرها | اضافه کردن artefact یا حذف ارجاع | برقراری تمام linked paths در ZIP |
| AUD-M03 | سند ورودی: conditional update | changelog 2026-11-17: update سفارش conditional قدیم را لغو و order id جدید میسازد | ذخیره order id جدید و abort-on-mismatch | تست update → journal两只 id |
| AUD-M04 | سند ورودی: `min_notional` | زنده `0` است؛ FAQ عدد 5 عمومی میگوید | خواندن per-symbol | golden fixture |
| AUD-M05 | سند ورودی: rate limits | هدرها ذکر شده ولی رفتار 5xx/-1003/-1015 تفکیک نشده | جدول retry policy | contract test signer + limiter |
| AUD-M06 | سند ورودی: secrets | DPAPI پیشنهاد شده ولی تست عدم نشت تعریف نشده | redaction test در log/UI/export | grep secret → 0 نتیجه |
| AUD-M07 | سند ورودی: UI | تغییر position/margin mode بدون compatibility check صریح | confirmation + read-back | UI test |
| AUD-M08 | سند ورودی: معیارها | عبارات «بهصورت مناسب» و … در متن | جایگزینی با شرط/عدد/مسئول | بازبینی لغتشناسی |
| AUD-M09 | سند ورودی: V1/V2 | endpointهای margin/flashClose/position/trading-stop V1اند ولی سند «V2 مبنا» میگوید | جدولاستثنای V1 با دلیل | RTM_endpoint |
| AUD-M10 | سند ورودی: valueQuantity | پذیرفتهشده ولی sizing بر contracts نوشته شده | جدول واحد + policy: valueQuantity ممنوع در فاز اول | unit test reject |

---

## D. ایرادات Low

| ID | محل | یافته | اقدام |
|---|---|---|---|
| AUD-L01 | اسناد بسته | نسخهها/تاریخها و منابع中的一些 غلط املائی و عبارات ترکیبی | ویرایش نهایی توسط تیم فنی |
| AUD-L02 | سند ورودی | نامگذاری `Basis Engine` مبهم (indicator یا gate؟) | یکپارچه `BasisAnalyticsService`، advisory فقط |
| AUD-L03 | سند ورودی | «Signal → … → Reconciliation» بدون correlation id| اضافه correlation id الزامی |

---

## E. یافتههای جدید پس از در دسترس شدن سورس (2026-11-21)

| ID | شدت | محل واقعی (مشاهدهشده در ZIP) | یافته | پیامد | اقدام | معیار پذیرش |
|---|---|---|---|---|---|---|
| AUD-S01 | High | `src/goldbot/domain/fsm/order.py`, `src/goldbot/domain/model.py` | `OrderState` فاقد `PROTECTION_PENDING/PROTECTED` است؛ `PositionSnapshot.has_protection` فقط `sl is not None` است |positionme بدون تأیید venue میتواند «محافظت‌شده» تلقی شود | FSM/جدالگانه جداگانه futures؛ مدل MT5 بدون تغییر | تست:sl داخلی موجود ولی ردیف algo غایب → حالت `PROTECTION_PENDING` و block |
| AUD-S02 | Medium | `tests/test_failure_injection_execution.py::test_already_closed_duplicate_delivery_returns_the_cached_ack` | xfail موجود: cached close ack بعد از replay بازیابی نمیشود (ولی سفارش تکراری ارسال نمیشود) | دقت journal/پاسخ اپراتور کمتر از حد انتظار | رفع در MT5 adapter **یا** ADR صریح و allowlist در Gate AC-01 | xfail حذف شود یا در ADR مصوب ثبت و در pytest allowlist باشد |
| AUD-S03 | Medium | README / RELEASE-MANIFEST / docs/TEST-COVERAGE-STATUS.md | سه عدد متفاوت: 1,084 PASS / 1,084 PASS / «1,082 passed, 2 skipped, 1 xfailed» در MANIFEST؛ اجرای مستقل: 1080 passed, 4 skipped, 1 xfailed | شواهد غیرقابل بازتولید | منبع واحد producing report + اصلاح اعداد | اسکریپت شمارش،deviation=0 |
| AUD-S04 | Low | README.md خط 93–94 | مسیرهای `reports/audit/` و `reports/review/` وجود ندارند (تأیید CR-08) | ارجاع شکسته | اضافه artefact یا حذف ارجاع | تمام linkها معتبر |
| AUD-S05 | Medium | `src/goldbot/app/risk/sizing.py`, `src/goldbot/app/costs.py` | sizing بر lot/contract_size/point و swap MT5 است؛ `compute_volume` عملاً reference و pipeline جاری `plan_entry` است | کپی مستقیم به Futures اشتباه است | سرویس sizing کاملاً جدا؛ import guard | 0 فراخوانی sizing MT5 از futures |
| AUD-S06 | Low | `BUILD-INFO.txt` (`files: 291`) در برابر 293 عضو ZIP | شمارش فایل در build-info با بسته نهایی مطابقت ندارد | عدم一侧یابی manifest | اصلاح builder | Build info == ZIP count |
| AUD-S07 | Medium | مخزن GitHub: `GoldBot_Toobit_Audit_v1_1.md` | سند ممیزی قبلی وضعیت APPROVED WITH CONDITIONS و 3 شرط C-01..C-03 میدهد؛ حکم ممیزی حاضر مستقل است و conversations متفاوتاند | دو مرجع بالقوه متعارض | ثبت بهعنوان artefact تاریخی + ADR تفاوتها | ADR صریح در Change Log |
| AUD-S08 | Medium | محیط اجرا | بسته ادعای Python 3.14.7/Windows است؛ ممیزی روی 3.13/Linux اجرا شد | parity کامل محیط مبنا اثبات نشد | اجرای مجدد suite در محیط رسمی تیم | log با Python و OS رسمی |

---

## F. خلاصه وضعیت نهایی

| سطح | تعداد | حلشده در سند | باز/Blocker |
|---|---|---|---|
| Critical | 6 | 6 | 0 (اما 4 OPEN DECISION مانع APPROVED) |
| High | 12+1 | 11 | 2 (AUD-H09, AUD-S01-needs test) |
| Medium | 10+5 | 14 | 1 (AUD-S03 نیاز به اجرا در محیط رسمی) |
| Low | 3+2 | 5 | 0 |

**حکم:** AUD-C01 بسته شد. با وجود تعطیل blockers سورس، چهار OPEN DECISION (واحد،TPSL،position mode،testnet) و نبود شواهد fill/protection واقعی مانع صدور `APPROVED`اند. حکم نهایی: **REJECTED** برای «سند نهایی تأییدشده»؛ **قابل استفاده مشروط برای Kickoff** طبق خروجی هفتم. `APPROVED` بدون اجرای واقعی Gateها و شواهد fill/protection صادر نمیشود.
