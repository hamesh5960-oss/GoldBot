# خروجی هشتم — Change Log (نسبت به سند ورودی v1.0)

**نسخه ممیزی:** AUDIT-REV-1.0 | **تاریخ:** 2026-11-21
**دلیل کلی:** سند ورودی بهعنوان معتبر فرض نشد؛ هر تغییر بر اساس شواهد مستقل (مستند رسمی / API زنده / منطق ریاضی / اصل fail-closed) صورت گرفته است.

| ID | محل تغییر در سند ورودی | تغییر اعمالشده | دلیل | اثر فنی |
|---|---|---|---|---|
| CH-01 | وضعیت پذیرش | جداسازی «READY FOR KICKOFF» از حکم ممیزی؛ حکم موقت REJECTED تا بسته شدن blockers | دو وضعیت را در هم آمیخته بود | جلوگیری از تفسیر اشتباه مجوز توسعه بهعنوان مجوز معامله |
| CH-02 | خلاصه ممیزی بسته | اضافه شدن AUD-C01: عدم تأیید مستقیم سورس تا تکمیل دانلود | اصل «سند را تأییدشده فرض نکن» | تمام ادعاهای مربوط به فایلها مشروط شدند |
| CH-03 | Funding «8H/±0.05%» | جایگزینی با خواندن زنده `period/rate/cap/floor`؛ درج شواهد 4H/±0.5% | API زنده 2026-11-21 با اعلامیه 2026-01-30 تناقض دارد | جلوگیری از funding buffer اشتباه |
| CH-04 | Leverage tiers announce | مرجع= `riskLimits` زنده؛ announce historical | tier زنده متفاوت است | margin/tier صحیح |
| CH-05 | فرمول sizing | بازنویسی cost-inclusive + execution entry Ask/Bid + Decimal | ابهام محل هزینهها و فرض mid | کاهش ریسک زیان واقعی>محاسباتی |
| CH-06 | `qty_step/min_qty` | اضافه OPEN-UNIT-01 + جدول واحدها + fail-closed | LOT_SIZE، order quantity و position quantity واحدهای متفاوتی دارند | جلوگیری از خطای 1000× |
| CH-07 | حفاظت بعد از fill |dual query algo orders با `stopCategory=STOP_PROFIT_LOSS` + تطبیق fields + emergency | open-algo-orders پیشفرض TP/SL را نشان نمیدهد |positionme بدون حفاظت PROTECTED نمیشود |
| CH-08 | «V2 مبنا» | جدول استثنای V1 (marginType, trading-stop, flashClose, positions) با دلیل | مستندات V2 این مسیرها را ندارند | پیادهساز دچار سردرگمی نمیشود |
| CH-09 | Position mode | OPEN-POSMODE-01 + block until discovery | endpoint مستندشدهای یافت نشد |close اشتباه رخ ندهد |
| CH-10 | «24/7 Toobit» | جایگزینی MarketStatus Engine زنده + OPEN-CAL-01 | `isRwa=true, rwaType=STOCK` | ورود در ساعات بسته مسدود |
| CH-11 | Index Price | سه symbol جدا: canonical/venue/index (`XAUUSDT`) | `?symbol=XAU` خالی است | mark/index اشتباه رخ ندهد |
| CH-12 | Reduce Only | تأکید بر عدم ارسال پارامتر اختراعشده | در V2 new order مستند نشده |رد سفارش توسط venue |
| CH-13 | Conditional update | ثبت order id جایگزین (changelog 2026-11-17) | update-old را لغو و new ایجاد میکند | جلوگیری از مانیتورING سفارش منسوخ |
| CH-14 | Emergency stop | اضافه flashClose V1 + verify position=0 | مسیر اضطراری مبهم بود |positionme رها نشود |
| CH-15 | خطاها/Timeout | جدول طبقهبندی: 5xx=UNKNOWN، 403/no retry، 429/reset | retry یکسان اشتباه است | جلوگیری از سفارش تکراری |
| CH-16 | Basis | FX feed الزامی و UNADJUSTED در نبود آن | فرض USDT=USD ممنوع است | تصمیم اشتباه کاهش یابد |
| CH-17 | UI/Secrets | تأیید کاربر برای margin/position/leverage + masked fingerprint | تغییر حساس بدون read-back خطرناک است | کاهش خطای اپراتور و نشت secret |
| CH-18 | تستها | الگوی 7 ستونی + 12 دسته + الزام شواهد Order ID | «وجود تست» کافی نیست | قابلاندازهگیری شدن |
| CH-19 | شمارش تستها/README | اضافه AUD-M01/M02 مشروط به بررسی سورس | تناقض 77/79/80 و مسیرهای گم |نقص مستندات |
| CH-20 | عبارات مبهم | جایگزینی با شرط/عدد/مسئول | قاعده کاربر | implementation بدون تفسیر شخصی |
| CH-21 | معماری | نمودار اجزا + جدول مسئول + import guards | لزوم مرز Strategy/Execution | استقلال دو runtime قابل تست |
| CH-22 | RTM | 43 شناسه با مسئول/تست/معیار | الزام خروجی ششم | ردیابیپذیری |

---

## اثری که تغییرات **نداشتهاند**
- منطق استراتژی change نکرده است (Shared Strategy Core حفظ شد).
- رفتار MT5 تغییر نکرده و بهعنوان immutable baseline فرض شده است.
- هیچ کدی نوشته، اجرا یا تست واقعی نشده است.
- هیچ مجوز معامله real-money صادر نشده است.

---

## الحاقیه — تغییرات ناشی از دردسترس شدن سورس (2026-11-21، پس از نسخه اولیه Change Log)

| ID | تغییر | دلیل | اثر |
|---|---|---|---|
| CH-23 | بسته شدن AUD-C01 و جایگزینی لینک Gofile با مخزن GitHub `hamesh5960-oss/GoldBot` | لینک اصلی مسدود شد و مالک لینک جایگزین داد | تطبیق با سورس واقعی اکنون اثباتشده است |
| CH-24 | درج مسیرهای واقعی سورس در §7.1 سند اجرایی و ضمیمه RTM | جلوگیری از نام فایل فرضی | RTM قابل اجرا شد |
| CH-25 | اصلاح عدد تستها: 1080 pass / 4 skip / 1 xfail بهجای 1084 PASS | اجرای واقعی suite در ممیزی | شواهد قابل بازتولید |
| CH-26 | اضافه AUD-S01: FSM فعلی فاقد PROTECTION states و `has_protection` داخلی است | بازرسی `domain/fsm/order.py` و `domain/model.py` | FSM futures جداگانه الزامی |
| CH-27 | اضافه AUD-S02: xfail close-idempotency | اجرای pytest | Gate AC-01 نیازمند allowlist/رفع |
| CH-28 | اضافه AUD-S03/S04/S06: سه عدد شمارش تست، مسیرهای گم README، files=291 در BUILD-INFO | بازرسی مستندات وManifest | الزام اصلاح اسناد بسته |
| CH-29 | ثبت `GoldBot_Toobit_Audit_v1_1.md` بهعنوان artefact تاریخی (CF-V11) | دو سند ممیزی در مخزن وجود دارند | جلوگیری از تناقض حکم |
| CH-30 | اضافه Freeze List شش فایل MT5 | حفظ رفتار نسخه فعلی | حداقل تغییر در MT5 |
| CH-31 | اصلاح حکم Kickoff مشروط + NOT READY FOR LIVE، حکم رسمی REJECTED تا بسته شدن OPENها | الزام کاربر برای اعلام صریح وضعیت | شفافیت مجوزها |
