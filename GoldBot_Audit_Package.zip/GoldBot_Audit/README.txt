GoldBot 8.2.5 + Toobit Futures — بسته ممیزی مستقل
تاریخ: 2026-11-21 | نسخه: AUDIT-REV-1.0

حکم نهایی: REJECTED (سند نهایی تأییدشده نیست)
قابلاستفاده برای Kickoff: مشروط (APPROVED WITH CONDITIONS)
مجوز معامله واقعی: صفر

فهرست:
  00_INDEX.md                     فهرست و خلاصه حکم
  01_Independent_Audit_Report.md  خروجی 1
  02_Defect_Register.md           خروجی 2
  03_Conflict_Register.md         خروجی 3
  04_Final_Architecture.md        خروجی 4
  05_Implementation_Spec.md       خروجی 5 (مرجع اصلی)
  06_Requirements_Traceability.md خروجی 6
  07_Test_and_Delivery_Plan.md    خروجی 7
  08_Change_Log.md                خروجی 8
  evidence/                       pytest log + پاسخهای زنده Toobit
  source/                         ZIP مبنا + artefact تاریخی v1.1

شواهد کلیدی: SHA256SUMS 292/292، pytest 1080 passed / 4 skipped / 1 xfailed.
