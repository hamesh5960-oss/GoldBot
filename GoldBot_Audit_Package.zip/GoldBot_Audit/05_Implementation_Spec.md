# خروجی پنجم — سند اجرایی اصلاح‌شده (Baseline for Kickoff)

**عنوان:** GoldBot Multi-Platform — مشخصات اجرایی ممیزی‌شده اتصال Toobit USDT-M Futures
**نسخه:** AUDIT-REV-1.0
**تاریخ ممیزی:** 2026-11-21 (Asia/Tehran)
**مبنا:** سند ورودی «Engineering Source Audit & Implementation Specification — v1.0» + بررسی مستقل مستندات رسمی Toobit + مشاهده زنده API عمومی Toobit
**وضعیت:** قابل استفاده بهعنوان مبنای Kickoff توسعه؛ **NOT READY FOR LIVE TRADING**. مجوز معامله با سرمایه واقعی تنها پس از بسته شدن تمام Gateهای خروجی هفتم و تأیید مالک صادر می‌شود.

> اصل حاکم بر این سند: هیچ عدد، Endpoint،enum، فرمول یا رفتاری که در این سند آمده، صرفاً به دلیل نوشته شدن در سند اولیه پذیرفته نشده است. مواردی که با منبع رسمی یا مشاهده زنده تناقض داشتند، **اصلاح و در Change Log ثبت شدند**. مواردی که قابل اثبات نبودند، بهعنوان **OPEN DECISION** یا **نیازمند تأییدvenue** علامتگذاری شدهاند، نه بهعنوان واقعیت.

---

## 0. دامنه، تعاریف و قواعد تفسیر

### 0.1 دامنه پذیرفتهشده
- یک Codebase مشترک، **Shared Strategy Core**، و **دو Runtime مستقل**: MT5 فعلی (دستنخورده) و Toobit Futures (جدید).
- هر Runtime تنها یک venue/account/instrument актив را manage میکند. Multi-account orchestration در این فاز خارج از دامنه است.
- جداسازی کامل: تنظیمات، اعتبارنامه، feed، دامنه Futures، sizing، state DB، journal DB، Kill Switch و چرخه استقرار.
- منطق استراتژی مشترک است؛ pricing، sizing، margin، protection و execution مختص venue است.

### 0.2 قواعد تفسیر (جایگزین عبارات مبهم)
| عبارت ممنوعه در سند اولیه | جایگزین الزامی در این سند |
|---|---|
| «در صورت نیاز» | شرط صریح + رفتار صریح + مسئول ماژول |
| «بهصورت مناسب» | آستانه عددی یا enum مشخص |
| «در شرایط لازم» | نام شرط از جدول خطاها |
| «سیستم هوشمندانه عمل کند» | حذف؛ جایگزین با الگوریتم قابل تست |
| «پیشنهادی» در مسیر بحرانی | OPEN-DECISION با Gate بستهشدن |

### 0.3 منابع اعتبار (Authority Order)
1. پاسخ زنده صرافی (`exchangeInfo`, `fundingRate`, `riskLimits`, `positions`, `order`, `algo-order`) در لحظه اجرا.
2. مستندات رسمی Toobit تاریخ 2026-11-17 به بعد (بخش 12).
3. اعلامیههای رسمی Toobit **فقط بهعنوان زمینه تاریخی**، نه مرجع پارامتر زنده.
4. کد منبع GoldBot 8.2.5 (برای تطبیق معماری، نه برای تعریف رفتار Toobit).

---

## 1. واحدها، قراردادها و مدلهای دامنه

### 1.1 جدول واحدها (الزامیترین اصلاح سند اولیه)
| کمیت | واحد در API | تبدیل | محل خطر |
|---|---|---|---|
| `quantity` در سفارش V2 | **contracts** (طبق مستند V2: «unit: contracts») | `underlying = contracts × contract_multiplier` | اشتباه با واحد LOT_SIZE |
| `valueQuantity` | USDT notional | جایگزین quantity (حداقل یکی الزامی) | مخلوط نشود |
| `LOT_SIZE.minQty/stepSize/maxQty` در exchangeInfo | مستند میگوید «token quantity not contracts»،اما riskLimits.amount/value و userTrades.qty نشان میدهند برخی پاسخها **contracts**اند | **OPEN-UNIT-01**: تا controlled validation، واحد LOT_SIZE راharزگ بهعنوان contracts فرض نکن؛ فقط بهعنوان «unit آزمایشی» ذخیره و با پاسخ سفارش read-back مقایسه کن | Critical |
| `positions[].position` (V1) | «pieces»؛ یادداشت مستند history میگوید مقادیر به underlying تبدیلشدهاند و دوباره نباید ضرب شوند | `contracts_from_position = position / contract_multiplier` تنها پس از تأیید زنده | Critical |
| `userTrades[].qty` (V1) | صریحاً **contracts** طبق مستند | ضرب در multiplier → underlying | High |
| `riskLimits[].quantity` / `value` | quantity تعداد قرارداد، value USDT طبق مشاهده زنده | tier selection بر اساس notional>USDT و quantity<contracts هر دو بررسی شود | High |
| Funding | نرخ بر notional position، دوره از API (`period`) | `funding = notional × rate` | High |

**قانون:** هر فیلد پولی `Decimal` است. `float` در حساب ریسک، sizing، مارجین، PnL و funding ممنوع است.`t()` به millisecond UTC نرمال میشود.

### 1.2 مدلهای پیشنهادی (جدید، additive)
- `InstrumentSpec` — شامل `venue, market_type, canonical_symbol, venue_symbol, base, quote, settlement_asset, contract_multiplier, tick_size, qty_step, min_qty, max_qty, min_notional, price_precision, qty_precision, status, risk_limits[], is_rwa, rwa_type, categories, max_condition_num, expires_at, source_ts`.
- `FuturesAccountSnapshot` — `available_balance, wallet_balance, position_margin, order_margin, unrealized_pnl, margin_type, currency, exchange_ts`.
- `FuturesPositionSnapshot` — `position_side, contracts, underlying_qty, avg_entry, mark, liquidation_price, initial_margin, maintenance_margin, leverage, margin_mode, quantity_unit_source`.
- `FuturesOrderCommand` / `FuturesOrderSnapshot` — جدا نگه داشتن intention و نتیجه venue، حامل `client_order_id`, `side`, `position_side`, `order_kind ∈ {REGULAR, PLAN, TP_SL, CLOSE}`, `trigger`, `execution_type`.
- `VenueCapabilities` — شامل `supports_reduce_only` (پیشفرض `UNKNOWN → false`)، `supports_position_mode_read` (پیشفرض UNKNOWN)، `supports_attached_tp_sl`, `supports_standalone_tp_sl`, `supports_flash_close`.
- `FuturesMarketSnapshot` — `bid, ask, bid_qty, ask_qty, last, mark, index, index_symbol, funding_rate, next_funding_time, period, exchange_ts, received_ts, data_quality`.

مدلهای MT5 فعلی (`Tick`, `SymbolInfo`, `ApprovedOrder`, `AccountSnapshot` طبق ادعای سند ورودی) **تغییر نمیکنند**. هیچ تبدیل اجباری ApprovedOrder به مدل Futures مجاز نیست.

### 1.3 Symbol mapping
- نمایش کاربر: `XAUUSDT` ( renaming اختیاری).
- شناسه API: `XAU-SWAP-USDT` — **تأییدشده زنده** در `exchangeInfo` تاریخ 2026-11-21 با وضعیت `TRADING`.
- Index Symbol: `XAUUSDT` (نه `XAU`) — `/quote/v1/index?symbol=XAU` پاسخ خالی `{"index":{},"edp":{}}` میدهد؛ `/quote/v1/index?symbol=XAUUSDT` مقدار میدهد.
- Unlock شرط: `status == TRADING` و `API_TRADE_FORBIDDEN != status` و `OPEN_FORBIDDEN != status` و `marginToken == USDT` و `inverse == false` و multiplier/step/funding/tierها معتبر.

---

## 2. مشخصات زنده قرارداد XAU-SWAP-USDT (اسنپشات 2026-11-21)

| فیلد | مقدار مشاهدهشده | منبع |
|---|---|---|
| `symbol` | `XAU-SWAP-USDT` | `/api/v1/exchangeInfo` |
| `status` | `TRADING` | همان |
| `contractMultiplier` | `0.001` | همان |
| `tickSize` | `0.01` | PRICE_FILTER |
| `minPrice / maxPrice` | `0.01 / 10000000.00000000` | PRICE_FILTER |
| `LOT_SIZE` | `minQty=0.001, stepSize=0.001, maxQty=10000` (واحد نامشخص — OPEN-UNIT-01) | همان |
| `MIN_NOTIONAL` | `0` (_not 5 و نه 10_) | همان |
| `marginToken` | `USDT` | همان |
| `inverse` | `false` | همان |
| `index / indexToken` | `XAU / XAUUSDT` | همان |
| `baseAssetPrecision` | `0.001` | همان |
| `maxEntrustNum / maxConditionNum` | `200 / 50` | LIMIT_TRADING |
| `buyPriceUpRate / sellPriceDownRate` | `0.05` | LIMIT_TRADING / MARKET_TRADING |
| `isRwa / rwaType / categories` | `true / STOCK / ["TradFi"]` | همان |
| Funding زنده | `rate=0`, `period=4H`, `cap=0.005`, `floor=-0.005`, `nextFundingTime=1795291200000` | `/api/v1/futures/fundingRate?symbol=XAU-SWAP-USDT` |
| Mark زنده | `3565.56` @ `1795282356000` | `/quote/v1/markPrice` |
| Index زنده | `XAUUSDT = 3565.25997533` (edp 3565.13907547) | `/quote/v1/index?symbol=XAUUSDT` |
| Book زنده | bid `3565.25` (qty `123829`) / ask `3565.44` (qty `99234`) | `/quote/v1/contract/ticker/bookTicker` |
| ریسک لایه 1 | `value=1000000`, `initialMargin=0.002`, `maintainMargin=0.001`, `maxLeverage=500` | `/api/v1/futures/riskLimits` |

**نکات بحرانی:**
1. اعلامیه 2026-01-30 میگوید دوره funding از 4H به 8H و سقف به ±0.05% تغییر یافته؛ ولی API زنده 2026-11-21 میگوید **4H و ±0.5%**. مرجع اجرا **API زنده** است. کد نباید 8H را hardcode کند.
2. اعلامیه 2026-03-02 جدول 0–60,000 USDT با 500x و 0.10% maintenance meiدهد؛ API زنده tier اول را تا 1,000,000 USDT با 0.2% initial / 0.1% maint میدهد. مرجع اجرا API است.
3. `isRwa=true, rwaType=STOCK` بدان معناست که فرض «24/7 بودن» بدون شواهد معتبر نیست. سند ورودی CR-05 را «فعالسازی weekend flatten» مینویسد ولی پروفایل 24/7 را هم الزام میکند — تناقض. رفتار نهایی: **Market Status Engine** زنده (status + ability to open/close + خطاهای OPEN_FORBIDDEN/CLOSE_FORBIDDEN)؛ در نبود وضعیت معتبر، ورود مسدود و پوزیشنهای باز طبق سیاستmanage میشوند. جدول ساعت معاملاتی RWA باید ازvenue تأیید و در规格 ثبت شود (OPEN-CAL-01).

---

## 3. قرارداد API Toobit (V2 مبنا، V1 محدود و مشخص)

### 3.1 عمومی
- Base: `https://api.toobit.com`. V2 Futures: `/api/v2/futures/...` (paths kebab-case).
- Envelope موفق: `{"code":200,"msg":"success","data":...}`؛ خطاها `code` منفی.
- Header API Key: `X-BB-APIKEY`. Signature: `HMAC-SHA256(secret, totalParams)` hex **lowercase**.
- `totalParams = queryString + rawJsonBody` **بدون `&`**، body فشرده تکخطی و دقیقاً همان بایتهای ارسالی.
- `timestamp` اجباری؛ `recvWindow` پیشفرض 5000، حداکثر 60000؛ تقاضای آینده >1s رد میشود. Sync با `/api/v1/time` الزامی.
- 64-bitها در JSON بهصورت رشته میآیند؛ فیلدهای null اغلب حذف میشوند.
- 5xx → **UNKNOWN**، نه شکست. 403 → WAF/permission، retry ممنوع. 429 → backoff تا `X-Api-Limit-Reset-Timestamp`.
- حدود: `REQUEST_WEIGHT 3000/min`، `ORDERS 60/2s`؛ هدرها: `X-Api-Limit-Status`, `X-Api-Limit`, `X-Api-Limit-Reset-Timestamp`.
- **هیچ مجوز Withdrawal در API Key درخواست نمیشود.** حداقل: Read + Futures Trade. IP whitelist در صورت پشتیبانی حساب الزامی.

### 3.2 Endpointهای مجاز در فازها
| هدف | Endpoint | مرحله |
|---|---|---|
| Server time | `GET /api/v1/time` | Read-only |
| Instrument | `GET /api/v1/exchangeInfo` | Read-only |
| Funding / history | `GET /api/v1/futures/fundingRate`, `GET /api/v1/futures/historyFundingRate` | Read-only |
| Mark / Index / Book / Kline | `/quote/v1/markPrice`, `/quote/v1/index`, `/quote/v1/contract/ticker/bookTicker`, `/quote/v1/klines` | Read-only |
| Leverage / margin tiers | `GET /api/v1/futures/accountLeverage`, `GET /api/v1/futures/riskLimits` | Read-only |
| Balance / Positions | `GET /api/v1/futures/balance`, `GET /api/v1/futures/positions` | Read-only |
| Orders (regular) | `POST /api/v2/futures/order`, `DELETE /api/v2/futures/order`, `GET /api/v2/futures/order`, `/open-orders`, `/history-orders`, `/user-trades` | Controlled write |
| Plan/TP-SL | `POST /api/v2/futures/algo-order`, `POST /api/v2/futures/algo-order/update`, `GET/DELETE /api/v2/futures/algo-order`, `/open-algo-orders`, `/history-algo-orders`, `DELETE /api/v2/futures/batch-cancel-algo-orders` | Controlled write |
| TP/SL مستقل روی پوزیشن | `POST /api/v1/futures/position/trading-stop` (V1) | Controlled write، OPEN-TPSL-01 |
| Flash close اضطراری | `POST /api/v1/futures/flashClose` (V1) | Emergency only |
| Margin mode | `POST /api/v1/futures/marginType` (V1) | فقط با تأیید کاربر + read-back |
| Leverage | `POST /api/v2/futures/leverage`، read-back از `GET /api/v1/futures/accountLeverage` | Controlled |

### 3.3 قواعد سفارش (غیرقابل تخلف)
- V2: `side ∈ {BUY,SELL}` و `positionSide ∈ {LONG,SHORT}` مستقلاند. نگاشت:
  - open LONG = `BUY/LONG`؛ close LONG = `SELL/LONG`
  - open SHORT = `SELL/SHORT`؛ close SHORT = `BUY/SHORT`
  (همان جدول رسمی v1→v2: BUY_CLOSE → BUY/SHORT, SELL_CLOSE → SELL/LONG).
- V1-style `BUY_OPEN/SELL_CLOSE` **هرگز** به V2 ارسال نشود.
- `newClientOrderId` اجباری و یکتا per runtime/account. فرمت: `{account_alias}-{strategy_id}-{yyyyMMddTHHmmssfff}-{seq}-{purpose}`؛ purpose ∈ `ENTRY, SL, TP, CLOSE, EMERG`.
- `reduceOnly` در مستند V2 new order **وجود ندارد**؛ ارسال آن ممنوع است (CR-AUDIT-14). Close صرفاً با side/positionSide و مقدار دقیق انجام میشود.
- قبل از close: خواندن position truth + open regular orders + open algo orders (هر دو `STOP` و `STOP_PROFIT_LOSS`)، سپس محاسبه `close_contracts = min(position_contracts - pending_close_contracts, available_contracts)`.
- `timeInForce=IOC` بهعنوان ورود پیشفرض (marketable limit)؛ price cap بر اساس ask/bid و حداکثر slippage. pricecap توسط `buyPriceUpRate/sellPriceDownRate=0.05` محدود میشود؛ فقط محدوده صرافی معتبر است.
- بعد از timeout: **QUARANTINE** → استعلام `GET /api/v2/futures/order?origClientOrderId=...` + user-trades + positions + algo orders؛ تنها پس از اثبات absence، retry با همان client id (یا در صورت policy جدید، id_new) مجاز است. Resend کورکورانه ممنوع.
- Partial fill: وضعیت `PARTIALLY_FILLED`، protection باید روی **مقدار پرشده واقعی** تنظیم شود، نه intention初期.

### 3.4 حفاظت پوزیشن (Critical)
سه مسیر مستندشده وجود دارد و نباید بهجای هم اشتباه شوند:
1. پارامترهای چسبیده `takeProfit/stopLoss` + `tpTriggerBy/slTriggerBy` + `tpOrderType/slOrderType` در `POST /api/v2/futures/order`.
2. `POST /api/v1/futures/position/trading-stop` — سفارش TP/SL مستقل روی position (side=LONG/SHORT, tpSize/slSize). پاسخ فقط price/size میدهد، **order id نمیدهد**.
3. `POST /api/v2/futures/algo-order` — خانواده plan `STOP`/`STOP_MARKET`. سفارش TP/SL با `stopOrderType` در پاسخها ظاهر میشود ولی نوع درخواست V2 `STOP`/`STOP_MARKET` است.

**قانون تحقیقپذیری (PROTECTED):** وضعیت PROTECTED تنها زمانی ثبت میشود که ردیف متناظر از **venue** خوانده شده و دارای: `symbol`, `positionSide/side` صحیح، `stopPrice`، `triggerBy`، `type`، `status=ORDER_NEW` (یا معتبر autre)، `origQty`/`slSize` مطابق position، و `orderId` یا `clientOrderId` باشد. چون `GET /api/v2/futures/open-algo-orders` در صورت حذف `stopCategory` **فقط plan STOP** برمیگرداند، verification باید با `stopCategory=STOP_PROFIT_LOSS` **و** بدون آن (دو فراخوان) انجام شود. فقدان ردیف = `PROTECTION_PENDING` →应急 path.

**OPEN-TPSL-01 (باز، Critical):** کدام مسیر (attached، trading-stop، یا algo-order) برای حفاظت پیشفرض انتخاب شود؟ پیشنهاد تیم ممیز: **attached TP/SL هنگام entry + verification دوگانه از open-algo-orders**؛ دلیل: کمترین تعداد write و قابلیت ردیابی. Gate بستهشدن: controlled validation نشان دهد سفارش حفاظتی با order id/content قابل استعلام است و در restart باقی میماند. تا بسته شدن، `trading_enabled=false`.

**Emergency path:** `POST /api/v1/futures/flashClose` (لغو تمام سفارشهای معلق position + market close) یا close سفارش V2 با client id `EMERG`. اولویت: تلاش close با quantity دقیق؛ در صورت شکست یا timeout، flashClose؛ سپس reconciliation تا position venue صفر شود. نباید process خاموش شود در حالی که position باز است.

### 3.5 Position mode / Margin mode
- مستند V2 `positionSide` را الزامی میدهد، ولی **endpoint مستندشدهای برای خواندن/تغییر position mode (One-Way/Hedge) یافت نشد**. `GET /api/v1/futures/accountLeverage` فقط `leverage` و `marginType` میدهد. بنابراین `supports_position_mode_read=UNKNOWN` و رفتار پیشفرض: **Block ورود** مگر controlled validation ثابت کند کدام حالت حساب فعال است و policy مالک آن را تأیید کند (OPEN-POSMODE-01, High).
- Margin mode: `POST /api/v1/futures/marginType` موجود است؛ `ISOLATED` پیشفرض پیشنهادی تاworkspaceپوزیشن باز. الزام: read-back از `/api/v1/futures/accountLeverage` قبل و بعد؛ عدم تطابق → QUARANTINE. تغییر بدون تأیید کاربر ممنوع.
- Leverage: مقدار user-configured و سقف سخت (پیشنهاد 5x یا کمتر در فاز validation)؛ `maxLeverage` زنده tierها محدودیت بالایی است، نه هدف. تغییر با پوزیشن باز ممنوع (مگر endpoint/policy صریحاً تست شده باشد).

---

## 4. فرمولهای ریسک و sizing (اعتبارسنجیشده)

### 4.1 ترتیب محاسبه (الزامی)
```
1) equity = wallet_balance + unrealized_pnl        (Decimal, USDT)
2) risk_budget = min(equity * risk_pct, daily_risk_cap_remaining, portfolio_cap_remaining)
3) if risk_budget <= 0 → REJECT
4) execution_entry = ask*(1+slippage_rate)  Long  |  bid*(1-slippage_rate)  Short
5) stop_price = strategy_stop (بر همان market Toobit)
6) stop_distance = |execution_entry - stop_price| ; if <= 0 → REJECT
7) loss_per_contract =
      stop_distance * contract_multiplier
    + fee_rate_taker * execution_entry * contract_multiplier * 2   (ورود+خروج)
    + funding_estimate_per_contract                                 (rate زنده × notional / contracts)
    + extra_slippage_buffer_per_contract
8) if loss_per_contract <= 0 → REJECT
9) raw_contracts = risk_budget / loss_per_contract
10) contracts = floor_to_step(raw_contracts, qty_step)   (ROUND_DOWN، هرگز ROUND_HALF)
11) if contracts < min_qty_unit_or_unknown → REJECT / OPEN-UNIT-01 gate
12) notional = contracts * contract_multiplier * execution_entry
13) if min_notional > 0 and notional < min_notional → REJECT
14) if notional > max_notional(از riskLimit.quantity × multiplier × price) → کاهش رو به پایین یا REJECT
15) tier = first tier where notional <= tier.value AND contracts <= tier.quantity
16) initial_margin = notional * tier.initialMargin
17) maintenance_margin = notional * tier.maintainMargin
18) require available_balance >= initial_margin + entry_fee + buffer
19) require leverage <= tier.maxLeverage AND leverage <= user_cap
20) liquidation_estimate = venue_liq_price (در صورت وجود)؛ else warning-only model
21) stress: adverse_move ≥ 2×stop_distance → margin still > maintenance? در غیر اینصورت کاهش حجم/رد
22) ثبت تمام مقادیر در Journal قبل از ارسال سفارش
```

### 4.2 اصلاحات بحرانی نسبت به سند ورودی
- سند ورودی هزینهها را بهعنوان خط جداگانه مینوشت و مشخص نکرد که در numeratorsigma قرار میگیرند یا denominator. در این سند **cost-inclusive loss_per_contract** تعریف شد (گام 7). بدون آن، ریسک واقعی > ریسک محاسباتی است.
- ورود بر اساس **Ask/Bid اجرایی** است، نه mid. Basis صرفاً تحلیلی است.
- اهرم **هیچ نقشی در تعیین حجم** ندارد؛ فقط مارجین و tier را کنترل میکند.
- `floor_to_step` با واحد نامشخص LOT_SIZE نمیتواند پیاده شود تا OPEN-UNIT-01 بسته شود.
- Funding buffer از `period` زنده (در حال حاضر 4H) و `rate/cap/floor` زنده محاسبه میشود؛ عدد 8H ممنوع.

### 4.3 مواقعی که زیان واقعی > زیان محاسباتی است (الزاماً لاگ و buffer)
Gap در RWA/TradFi، slippage فراتر از cap، partial fill قبل از protection، عدم ثبت TP/SL، liquidation قبل از stop trigger، funding تسویهشده درون معامله، فرقیزان index/mark/contract price، تغییر tier در اثر افزایش حجم، خطای واحد قرارداد، close با market در emergency، قطع اتصال هنگام trigger،ADL.

### 4.4 Limits حساب
`max_daily_loss`, `max_drawdown`, `max_open_positions`, `max_aggregate_exposure`, `consecutive_loss_protection`, `kill_switch` همگی **per runtime/account** و بر اساس equity همان حساب.-sharing state با MT5 ممنوع.

---

## 5. Basis و Market Data

### 5.1 فرمول اصلاحشده
```
usdt_per_usd = feed معتبر مستقل (USD/USDT)، با timestamp و stale policy
reference_xau_usdt = mid(XAUUSD_MT5) * usdt_per_usdt
crypto_mid = (bid_toobit + ask_toobit) / 2
basis_abs = crypto_mid - reference_xau_usdt
basis_pct = 100 * basis_abs / reference_xau_usdt
```
- اگر `usdt_per_usd` ناموجود/stale/nonpositive → `basis_quality=UNADJUSTED`، Basis صرفاً نمایشی و **هر gate معاملاتی غیرفعال**.
- فرض USDT=USD دقیقاً 1 ممنوع.
- mt5 timestamp و toobit timestamp همتراز شوند؛ اختلاف > `MAX_TS_SKEW_MS` (پیشنهاد 5000ms، قابل تنظیم) → block.
- Strategy Core در Toobit فقط از candle/tick Toobit تغذیه میشود. XAUUSD MT5 صرفاً reference اختیاری است و **هرگز** وارد سیگنال، entry، SL، TP، sizing یا protection Toobit نمیشود.
- Mark Price → mark-to-market/liquidation؛ Index (`XAUUSDT`) → فقط مصارف تعریفشدهvenue؛ Last → تنها نمایش، не price اجرایی.
- Z-score Basis صرفاً monitoring/advisory تا calibration + walk-forward جداگانه.

### 5.2 جدول fail-closed
| شرط | رفتار |
|---|---|
| Bid>=Ask، price<=0، NaN | feed invalid، block new entry |
| stale beyond threshold | DATA_STALE، block new entry، manage موجود با venue truth |
| mark/index/funding missing و policy نیاز دارد | block |
| basis unadjusted | gate basis خاموش، هشدار UI |
| spread/depth نامناسب | block یا کاهش حجم طبق policy مصوب |
| gap در candle | candle'invalid' → block signal تا تکمیل |

---

## 6. چرخه عمر سفارش / پوزیشن

### 6.1 states و transition
`CREATED → SUBMITTING → ACKNOWLEDGED → PARTIALLY_FILLED → FILLED → PROTECTION_PENDING → PROTECTED → MANAGED → CLOSING → CLOSED`
و مسیرهای خطا: `REJECTED`, `CANCELED`, `EXPIRED`, `UNKNOWN`, `QUARANTINE`.

| State | ورودی | خروجی/شرط عبور | ownership | timeout | خطا | recovery |
|---|---|---|---|---|---|---|
| CREATED | signal+risk approval | ticket currency valid | Strategy/Risk | — | invalid | reject+log |
| SUBMITTING | ticket | write-ahead journal + client id | OrderCoordinator | 5s HTTP | network | QUARANTINE |
| ACKNOWLEDGED | orderId+status | venue acknowledged ≠ filled | Adapter | 10s | 5xx | query by client id |
| PARTIALLY_FILLED | executedQty>0 | انباشت fillها | Adapter/OMS | 30s | drop | query trades |
| FILLED | sum fills == origQty و position تأیید شد | → protection | OMS | 5s | mismatch | QUARANTINE |
| PROTECTION_PENDING | position>0 | درخواست SL/TP ارسالشده | ProtectionService | 10s | error | retryQueryAfterRead |
| PROTECTED | ردیف venue تأییدشده | management آزاد | ProtectionService | — | — | monitor |
| MANAGED | mark/funding/price | trailing/adjust/close | PositionManager | per policy | stale | freeze |
| CLOSING | close ticket | venue position→0 | OMS | 15s | unknown | reconcile/flashClose |
| CLOSED | position=0 و algo orders terminal | journal finalize | Reconciler | — | orphan orders | cancel |

### 6.2 قوانین P0
1. Timeout یا 5xx در submit → **QUARANTINE**، بدون resend کور.
2. Duplicate client id → تنها استعلام؛ ایجاد سفارش جدید ممنوع.
3. Fill بدون protection تأییدشده → retry امن (پس از استعلام) سپس close اضطراری.
4. وضعیت داخلی هرگز جایگزین venue truth نمیشود.
5. Restart: sequence `server time → instrument → account → positions → regular orders → algo orders (STOP + STOP_PROFIT_LOSS) → trades → local DB reconcile`؛ اختلاف → QUARANTINE، ورود جدید ممنوع.
6. بستهشدن دستی از پنل صرافی → reconciler position=0 و两只 algo orders را پاک/لغو میکند；journal ثبت `EXTERNAL_CLOSE`.
7. Kill switch دو سطح: `STOP_NEW_ENTRIES` (مدیریت پوزیشن ادامه مییابد) و `EMERGENCY_FLATTEN` (close + verify). مستقل از MT5، و قابل اجرا از CLI خارج از پنل.

---

## 7. جداسازی Runtime و پیکربندی

| مورد | MT5 Runtime | Toobit Runtime |
|---|---|---|
| Codebase | shared | shared |
| Strategy | shared packages | همان، بدون fork |
| Feed | MT5 XAUUSD | Toobit XAU-SWAP-USDT |
| Broker adapter | MT5 adapter ( unchanged) | Toobit adapter (new) |
| DB path | `var/mt5/` (طبق سند ورودی، باید تأیید شود) | `var/toobit/<account_alias>/` |
| Secrets | MT5账户 | OS secure store / DPAPI، جداگانه |
| Kill switch | مستقل | مستقل |
| Config flags |现有 | `toobit_enabled=false`, `trading_enabled=false`, `read_only_mode=true` پیشفرض |

Feature flagها در کد بهگونهای پیاده شوند که absence از config = false (fail-closed). تغییرات MT5 additiveاند؛ هرگونه تغییر رفتاری MT5 نیازمند Change Request جدا و golden regression parity است.

### 7.1 نقاط اتصال واقعی سورس 8.2.5 (ممیزیشده 2026-11-21)
| قابلیت | وضعیت فعلی | مسیر واقعی تأییدشده | اقدام |
|---|---|---|---|
| قرارداد broker | `IBrokerGateway` با connect/disconnect/health/is_ready/symbol_info/account/positions/orders/deals/submit/modify/close/find_by_client_ref/on_market_tick | `src/goldbot/ports/broker.py` | قرارداد Futures جداگانه اضافه؛ قرارداد فعلی ثابت بماند |
| مدلها | Tick فقط bid/ask؛ SymbolInfo بر point/contract_size/volume_step/sessions؛ AccountSnapshot MT5-specific؛ PositionSnapshot.has_protection=از `sl is not None` | `src/goldbot/domain/model.py`, `src/goldbot/domain/execution.py` | مدلهای futures additive؛ **تغییر مدل MT5 ممنوع** |
| sizing | `compute_volume` و `compute_capital_volume` (legacy) بر lot/contract_size/swap MT5؛ pipeline جاری `plan_entry` | `src/goldbot/app/risk/sizing.py`, `app/risk/capital.py`, `app/costs.py` | سرویس sizing futures کاملاً جدا |
| هماهنگکننده سفارش | write-ahead با fsync، idem=`run_id:intent_id`، UNKNOWN، uncertain dict | `src/goldbot/app/order_coordinator.py` | الگو قابلاستفاده؛ FSM futures جداگانه با PROTECTION_PENDING/PROTECTED |
| FSM سفارش | OrderState شامل ACKED/PARTIAL/UNKNOWN/RESOLVED_ABSENT ولی **بدون** protection states | `src/goldbot/domain/fsm/order.py` | FSM futures جداگانه |
| reconciliation | broker truth wins، adopt orphan، unreadable→unclean→quarantine | `src/goldbot/app/reconciler.py` | الگو قابلاستفاده؛ TP/SL query دوگانه اضافه شود |
| composition root | injection صریح `live_broker/live_feed/live_clock/info_override` | `src/goldbot/runtime/bootstrap.py` | runtime_toobit مستقل، 0 import MT5 |
| feed | IMarketDataFeed ساده + MarketSnapshot(last_tick,last_bar,spread) | `src/goldbot/ports/marketdata.py` | FuturesMarketSnapshot جداگانه |
| adapter فعلی | تنها MT5 | `src/goldbot/adapters/mt5_broker.py` | بدون تغییر |
| پنل | FastAPI + auth | `src/goldbot/web/app.py` | section جداگانه Toobit، بدون API مستقیم بهvenue |

**فایلهای MT5 منجمد (Freeze List)** — هرگونه تغییر نیازمند CR جدا و golden regression:
`src/goldbot/domain/model.py`, `src/goldbot/domain/execution.py`, `src/goldbot/ports/broker.py`, `src/goldbot/adapters/mt5_broker.py`, `src/goldbot/app/engine.py`, `src/goldbot/runtime/live.py`.

**شواهدbaseline:** SHA256SUMS 292/292، compileall PASS، pytest `1080 passed / 4 skipped / 1 xfailed`؛ log در `evidence/pytest_full.log`. عدد 1084 PASS در README/TEST-REPORT/MANIFEST قابل بازتولید نیست (AUD-S03).

### 7.2 artefact HISTORICAL
مخزن GitHub حاوی `GoldBot_Toobit_Audit_v1_1.md` است که حکم APPROVED WITH CONDITIONS و 3 شرط C-01..C-03 را مینویسد. این سند بهعنوان artefact تاریخی ثبت شد و **مرجع حکم ممیزی حاضر نیست**؛ یافتههای مشترک (stopCategory، signer header، circular cost) توسط ممیزی مستقل تأیید شدند، ولی اختلاف شمارش تست و حکم نهایی در Change Log ثبت شده است.

---

## 8. امنیت و پایداری

- Secretها فقط یکبار ورود، ذخیره در OS secure store/DPAPI؛ کلید رمزگذاری جدا از ciphertext؛ نمایش فقط masked fingerprint؛ حذف از HTML، localStorage، logs، exports، tracebacks.
- Deterministic signer with unit tests (query ordering, JSON compact bytes, lowercase hex, timestamp injection).
- Timestamp sync با `/api/v1/time`، recvWindow≤5000 پیشفرض.
- WebSocket: backoff + jitter، heartbeat، sequence/gap detection، resubscribe، و همیشه REST reconciliation بهعنوان مرجع نهایی.
- Rate limit: token bucket per weight/order، respectful 429 reset header؛ auth/permission/symbol errors non-retryable.
- Race condition: single writer per (account, symbol) state؛ atomic DB transaction write-ahead؛ idempotency unique constraint `(account_alias, client_order_id)`.
- DB: WAL/backup versioned additive migrations؛ migration destructiveness ممنوع.
- Monitoring: heartbeat، watchdog، process liveness، orphan position detector، critical alerts به UI + خارج از آن.
- Graceful shutdown: stop new → wait protection/close → flush journal → exit. خاموش کردن process با position باز و بدون verify ممنوع.

---

## 9. پنل و تنظیمات

| قابلیت | اجرا |
|---|---|
| Runtime selector | MT5 / Toobit، فعالسازی مستقل |
| Account dashboard | balance/equity/available/margin، connection, feed quality |
| Positions/orders/algo orders | تقسیم regular/plan/TP-SL، نمایش order idها |
| Risk settings | per runtime، تغییر با تأیید و versioning |
| Leverage/margin mode | فقط با تأیید صریح کاربر + compatibility check + read-back |
| Kill switch | دو دکمه جداگانه با نتیجه verifyشده |
| Reconciliation panel | آخرین نتیجه، discrepancies، timestamp |
| Secrets | masked fingerprint فقط، بدون کپی متن |

**تصمیم کاربر در مقابل سیستم:**
- کاربر تأیید میکند: position mode (پس از کشف)، margin mode، leverage cap، risk_pct، funding buffer، emergency policy.
- سیستم خودکار و ایمن managing میکند: symbol status، metadata refresh، timestamp sync، rate limits، stale feed block، duplicate prevention، protection verification، retry بعد از استعلام، journaling.

---

## 10. Open Decisions (نباید به تشخیص programmer واگذار شوند)

| ID | تصمیم | پیشنهاد | Gate بستهشدن |
|---|---|---|---|
| OPEN-UNIT-01 | واحد LOT_SIZE و position quantity | Controlled validation با قرارداد حداقل + read-back | تطابق quantity返 با محاسبه |
| OPEN-TPSL-01 | مسیر پیشفرض حفاظت | Attached TP/SL + dual verification | مشاهده order id پایدار |
| OPEN-POSMODE-01 | position mode حساب | بدون تغییرAutomatic؛ block تا کشف | تست read/تأیید مالک |
| OPEN-CAL-01 | ساعات معاملات RWA/XAU | Market status engine زنده | لاگ وضعیت در چند بازه |
| OPEN-LEV-01 | سقف leverage | 5x یا کمتر در validation | stress tests |
| OPEN-BASIS-01 | threshold Basis | advisory، بدون gate | calibration/walk-forward |
| OPEN-FX-01 | منبع USD/USDT | feed معتبر + timestamp | تأیید منبع |
| OPEN-CRED-01 | ذخیره اعتبار | OS secure store | threat model + leak test |
| OPEN-TESTNET-01 | وجود testnet خارجی | فرض عدم وجود تا اثبات | بررسی رسمی/poc |

---

## 11. خروجیهای مورد انتظار تیم توسعه
سورس Toobit adapter/feed/runtime جداگانه؛ suite کامل تست MT5+Toobit با_report؛ پاسخ خام redacted؛ golden fixtures؛ migration scripts؛ security checklist؛ journal sample signal→order→fill→protection→close→fees/funding؛ runbook؛ registers بهروز؛ ZIP نهایی با SHA256SUMS بازتولیدپذیر.

---

## 12. مراجع  (محافظهکارانه، تاریخ دسترسی 2026-11-21)
- Toobit API Basic Information — https://api-docs.toobit.com/api/basic-information.html
- Toobit USDT-M Futures Market Data — https://api-docs.toobit.com/api/usdt-m-market-data
- Toobit USDT-M Futures Account & Trading V2 — https://api-docs.toobit.com/api/usdt-m-api-v2
- Toobit USDT-M Account/Trades V1 — https://api-docs.toobit.com/api/usdt-m-account-and-trading
- Toobit Changelog (2026-11-17 و 2026-04-24) — https://api-docs.toobit.com/api/changelog.html
- Toobit Code Examples / JSON body signing — https://api-docs.toobit.com/api/code-examples.html
- Toobit FAQ (symbol format) — https://api-docs.toobit.com/agent/faq.html
- Announcement XAU 500x (2026-03-02) — https://www.toobit.com/en-US/announcement/trade-xauusdt-perpetual-contracts-with-up-to-500x-leverage-on-toobit
- Announcement funding update (2026-01-30) — https://www.toobit.com/announcement/important-updates-on-the-funding-rate-of-xau-and-xag-perpetual-contracts-%282026-01-30%29
- پاسخهای زنده ذخیرهشده در `evidence/`.
