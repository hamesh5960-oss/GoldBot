# خروجی هفتم — برنامه آزمون، تحویل و شرایط انتشار

**نسخه:** AUDIT-REV-1.0 | **تاریخ:** 2026-11-21
**قاعده:** تست شبیهسازی一个有 label `SIMULATION` است و هرگز بهعنوان «اجرای واقعی صرافی»/report نمیشود. نبود testnet external (در صورت تأیید OPEN-TESTNET-01) بدان معناست که مرحله E تنها با حجمtypically کوچک و تأیید مالک قابل اجرا است.

---

## 1. الگوی الزامی هر Test Case
`هدف | شرایط اولیه | ورودی | مراحل | نتیجه مورد انتظار | Pass/Fail | شواهد`

---

## 2. فاز A — MT5 Regression (Gate: exit=0 behavior diff)

**T-A01 Golden parity**
- هدف: اطمینان از عدم تغییر رفتار 8.2.5.
- شرایط: baseline immutable + hash ثبتشده + همان tape golden.
- ورودی: golden fixture XAUUSD M15 و signal log نسخه مبنا.
- مراحل: اجرای کامل suite روی Windows/Python پشتیبانیشده؛ مقایسه signal/order/journal outputs.
- انتظار: تمام تستها pass؛ خروجیها با golden برابر.
- Pass/Fail: هرگونه diff بدون ADR مصوب = Fail.
- شواهد: pytest report + hashes + diff.

**T-A02 Import guard**
- هدف: عدم وابستگی runtime_toobit به MT5.
- ورودی: AST/import graph.
- Pass/Fail: تعداد import از `mt5_broker` در runtime_toobit برابر 0.

**T-A03 Strategy input guard**
- هدف: فقط feed Toobit وارد strategy Toobit شود.
- Pass/Fail: 0 مسیر ورودی MT5 به strategy_bindingToobit.

---

## 3. فاز B — Unit Futures (Gate: fail-closed در مرزها)

| ID | هدف | ورودی/clamp | نتیجه مورد انتظار | Pass/Fail | شواهد |
|---|---|---|---|---|---|
| T-U01 | Decimal dictها | "0.1"+0.2 | 0.3 دقیق | خطای float = Fail | pytest |
| T-U02 | capability unknown | `{}` | unsupported → block | otherwise Fail | pytest |
| T-U03 | instrument validation | status=OPEN_FORBIDDEN | reject |Fail | fixture |
| T-U04 | signer V2 | query+compact JSON | HMAC golden | hex uppercase=Fail | vector |
| T-U05 | time sync | skew 2000ms | reject | accept=Fail | pytest |
| T-U06 | rate limit | 429 + reset header | backoff until reset | immediate retry=Fail | log |
| T-U07 | واحد | unit=UNKNOWN | reject order | send=Fail | pytest |
| T-U08 | funding | period=4H،rate=0.001 | buffer بر 4H | 8H=Fail | fixture |
| T-U09 | feed quality | bid>=ask | DATA_INVALID+block | signal=Fail | pytest |
| T-U10 | basis | FX missing | UNADJUSTED, gate off | gate on=Fail | pytest |
| T-U11 | sizing | cost>0 | contracts strictly smaller | برابر=Fail | property test |
| T-U12 | leverage | leverage 5→20 | contracts unchanged | تغییر=Fail | pytest |
| T-U13 | tier stress | adverse 2×stop | reject/reduce | ignore=Fail | pytest |
| T-U14 | limits | daily cap reached | block | pass=Fail | pytest |
| T-U15 | journal atomic | duplicate client id | unique constraint | 2 rows=Fail | DB test |

---

## 4. فاز C — API Read-Only (Gate: mapping واقعی، بدون write)

**T-C01 exchangeInfo**
- شرایط: network + gateway صرفاً read.
- ورودی: `GET /api/v1/exchangeInfo`.
- مراحل: فیلتر XAU-SWAP-USDT، مقایسه با golden fields.
- انتظار: symbol, status, multiplier=0.001, tick=0.01, minNotional=0, marginToken=USDT, riskLimits 12 tier.
- Pass/Fail: فقدان/تغییر بدون ADR = Fail.
- شواهد: raw JSON redacted + timestamp.

**T-C02 signed read**
- ورودی: `/api/v1/futures/balance` و `/positions` با read-only key.
- انتظار: code=200، secrets的红acted، rate headers مصرفشده.
- Pass/Fail: هرگونه secret در log = Fail.

**T-C03 funding/mark/index**
- انتظار: funding `period` زنده؛ index با `symbol=XAUUSDT`؛ mark معتبر.
- Pass/Fail: hardcode 8H یا index symbol=XAU = Fail.

**T-C04 endpoint contract matrix**
- بررسی V2 order/algo و V1 trading-stop/marginType/flashClose طبق جدول §3.2.
- Pass/Fail: ارسال reduceOnly در V2 new order = Fail.

---

## 5. فاز D — Simulated Execution (Gate: 0 سفارش واقعی)

| ID | سناریو | تزریق | نتیجه | Fail criterion |
|---|---|---|---|---|
| T-I01 | timeout بعد از send | 5xx/network | QUARANTINE+query | resend کور |
| T-I02 | 429 | reset header | backoff | high-frequency retry |
| T-I03 | 403 permission | auth error | no retry + alert | retry |
| T-I04 | stale feed | timestamp عقب | block | signal |
| T-I05 | duplicate client id | همان ticket 2 بار | 1 order | 2 order |
| T-I06 | unknown order | پاسخ گم | query by client id | retry کور |
| T-I07 | partial fill | 40% fill | protection=40% | protection=100% intent |
| T-I08 | missing SL | algo query خالی | retry→emergency close | PROTECTED |
| T-I09 | emergency fail | close error | flashClose+verify | process exit با position |
| T-I10 | external close | position=0 ازvenue | EXTERNAL_CLOSE | stateset internal |
| T-I11 | WS disconnect | drop 3 بار | resubscribe+REST sync | gap نادیده |

---

## 6. فاز E — Controlled Venue Validation (فقط پس از E-Gate)

**پیششرطها:** تأیید کتبی مالک، API key با Read+Trade (بدون withdrawal)، کوچکترین حجم مجاز، مانیتورینگ لحظهای، قابلیت flatten دستی.

| ID | هدف | مراحل | شواهد الزامی | Pass/Fail |
|---|---|---|---|---|
| T-E01 | entry | marketable LIMIT IOC، client id | Order ID + response + journal | protection تأیید نشد → Fail |
| T-E02 | fill | user-trades + position query | fill ids + avg price | عدم تطابق → Fail |
| T-E03 | protection | dual algo query | order id + stopPrice + qty | فقدان → Fail |
| T-E04 | cancel | cancel regular + algo | final snapshots | orphan → Fail |
| T-E05 | close | position=0 + algo terminal | history position + journal | باقی position → Fail |

> simulation را SIMULATION برچسب بزن؛ هر report واقعی باید Order ID, Exchange Response, Execution Report, Position Snapshot و Journal داشته باشد.

---

## 7. فاز F — Restart / Soak / Security

| ID | هدف | Pass/Fail |
|---|---|---|
| T-F14 | restart با position و TP/SL باز | 0 duplicate، 0 unprotected position |
| T-R02 | قطع/net به مدت 30 دقیقه | reconciliation به venue truth |
| T-F15 | DB separation | 0 shared table/file |
| T-F16 | kill switches | MT5 heartbeat بدون تغییر |
| T-S01 | secret leak scan | 0 نتیجه در log/HTML/export |
| T-S02 | permission review | withdrawal=disabled |
| T-G01 | Open Decisions | تمام statuses CLOSED |

Soak: حداقل 8 ساعت در read-only + simulation، سپس (در صورت مجوز) 2 ساعت controlled with position؛ معیار: 0 orphan order، 0 stale decision، 0 leaked secret.

---

## 8. فاز G — Release Gate (همه شرایط الزامی)

1. AUD-C01 بسته و سورس ممیزی شده.
2. تمام Critical/High دارای ADR + تست pass.
3. MT5 golden regression=pass.
4. T-E01…E05 با شواهد واقعی (یا GUI/دستی governance تصمیم بدهد که write مجاز نیست → حکم NOT READY باقی میماند).
5. restart/soak/security pass.
6. Runbook + rollback + ZIP + SHA256SUMS.

**شرط انتشار واقعی:** صفر P0/P1 باز + sign-off مالک. در نبود شواهد fill/protection واقعی، وضعیت `NOT READY FOR LIVE TRADING` باقی میماند حتی اگر کد کامل باشد.

---

## 9. ترتیب تحویل (Roadmap اصلاحشده)

| فاز | خروجی | Gate |
|---|---|---|
| 0 Freeze | hash baseline + source audit | AUD-C01 closed |
| 1 Domain/Ports | مدلها و capability | contract tests |
| 2 Read-only adapter | signer+exchangeInfo+feed | T-C01…C04 |
| 3 Market/Basis | profile + FX | golden fixtures |
| 4 Futures Risk | sizing+margin | property/stress |
| 5 Execution/Protection | regular+algo+verify | failure injection |
| 6 Runtime/UI | DB/secret/kill separation | restart/security |
| 7 Validation | simulation then controlled | شواهد fill |
| 8 Handover | runbook+ADR+ZIP | sign-off |

---

## 10. وضعیت اجرای تست تاکنون

### 10.1 آنچه واقعاً اجرا شد (سورس مبنا)
پس از دردسترس قرار گرفتن مخزن جایگزین GitHub، ZIP استخراج و موارد زیر واقعاً اجرا شد:
- `unzip` + `zipfile.testzip()` → 293 عضو، بدون خطا.
- `SHA256SUMS` → 292/292 تطابق.
- `python -m compileall src tests conftest.py run_goldbot.py` → PASS.
- `python -m pytest --collect-only -q` → 1085 تست (پس از نصب `fastapi`، چون 2 تست وب نیاز داشتند).
- `python -m pytest -q` → **1080 passed, 4 skipped, 1 xfailed, exit=0, 71.43s** — log: `evidence/pytest_full.log`.
- `grep -rilE 'toobit|XAUUSDT|Futures|ExchangeAdapter|basis'` در سورس → 0 نتیجه.

XFAIL: `test_already_closed_duplicate_delivery_returns_the_cached_ack` — رفتار فعلیMT5 سفارش تکراری نمiفرستد ولی cached ack را بازیابی نمیکند. 4 skip مربوط به نبود PowerShell است.

### 10.2 آنچه اجرا نشده است
هیچیک از تستهای B…G مربوط به Toobit **اجرا نشدهاند**، چون کد Toobit وجود ندارد و API key و مجوزی در اختیار ممیز نیست. تمام موارد فوق در فاز A تا G **برنامه و معیار**اند، نه گواهی عملکرد. حکم NOT READY FOR LIVE TRADING پابرجاست.
