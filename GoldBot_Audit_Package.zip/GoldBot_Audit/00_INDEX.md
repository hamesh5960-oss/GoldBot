# بسته ممیزی مستقل GoldBot 8.2.5 + Toobit Futures

**تاریخ:** 2026-11-21 | **نسخه:** AUDIT-REV-1.0

## حکم نهایی

**REJECTED** بهعنوان «سند نهایی تأییدشده» — دلیل: چهار OPEN DECISION مسیر اجرایی را تحت تأثیر میدهند (واحد Quantity، مسیر حفاظت، Position Mode، محیط تست) و هیچ شواهد اجرای واقعی سفارش/حفاظت Toobit وجود ندارد.

**قابلاستفاده برای جلسه Kickoff:** بله، **APPROVED WITH CONDITIONS** مشروط به بسته شدن OPEN-UNIT-01, OPEN-TPSL-01, OPEN-POSMODE-01, OPEN-TESTNET-01 قبل از فاز ۱.
**مجوز معامله واقعی:** صفر.

---

## فهرست خروجیهای الزامی

| # | فایل | محتوا |
|---|---|---|
| ۱ | `01_Independent_Audit_Report.md` | نقاط قوت/ضعف، ریسکها، ارزیابی کلی، شواهد بازتولید |
| ۲ | `02_Defect_Register.md` | جدول کامل ایرادات با شدت، محل، پیامد، راهکار و معیار پذیرش |
| ۳ | `03_Conflict_Register.md` | تناقضات داخلی، با API زنده، با سورس واقعی و با artefact v1.1 |
| ۴ | `04_Final_Architecture.md` | اجزا، مرز مسئولیتها، جریان داده، چرخه سفارش |
| ۵ | `05_Implementation_Spec.md` | سند اجرایی اصلاحشده (مرجع اصلی توسعه) |
| ۶ | `06_Requirements_Traceability.md` | 43 الزام + مسئول + محل + تست + معیار |
| ۷ | `07_Test_and_Delivery_Plan.md` | تستها، Gateها، Roadmap، شرایط انتشار |
| ۸ | `08_Change_Log.md` |全部 تغییرات نسبت به سند ورودی + دلیل و اثر |

## شواهد و منابع

- `source_repo/GoldBot_Final_Release_v8.2.5.zip` —_hash `3baed37dc55b44a958229f115b7276a7c959aae7c17dab140b3da1250d930fc7` (از مخزن GitHub جایگزین).
- `source_extracted/GoldBot_Final_Release/` — 293 فایل استخراجشده.
- `evidence/pytest_full.log` — نتیجه thực اجرا: **1080 passed, 4 skipped, 1 xfailed**.
- `evidence/*.json` — پاسخ زنده Toobit: exchangeInfo, funding, mark, index, bookTicker, riskLimits, serverTime.
- `source_repo/GoldBot_Toobit_Audit_v1_1.md` — artefact تاریخی، مرجع حکم حاضر نیست.

## مخفف یافتهها

| مورد | نتیجه |
|---|---|
| سورس 8.2.5 بررسی شد | بله، مستقیم |
| کد Toobit در سورس | صفر |
| SHA256SUMS / compileall | 292/292 PASS / PASS |
| تست مبنا | 1085 collect، 1080 pass، 4 skip، 1 xfail |
| تناقض funding سند با API زنده | بله: 8H/±0.05% در برابر 4H/±0.5% |
| تناقض main notional | بله: FAQ عمومی 5 در برابر XAU: 0 |
| Position mode قابل خواندن از API | مستند نشده → OPEN |
| حفاظت قابل اثبات | فقط با dual-query `stopCategory` → OPEN-TPSL-01 |

## نحله استفاده

1. جلسه Kickoff: خروجی ۱ + ۴ + ۵ + ۸ را مبنا قرار دهید.
2. فاز ۱: چهار OPEN DECISION را با ADR ببندید.
3. فاز ۲ به بعد: خروجی ۶ (RTM) و ۷ (تست) را به backlog تبدیل کنید.
4. مجوز real-money: تنها پس از Gate G و شواهد Order ID/Response/Position Snapshot/Journal.
EOF
python3 - <<'PY'
p='/home/user/GoldBot_Audit/00_INDEX.md'
s=open(p).read().replace('全部 تغییرات','تمام تغییرات').replace('_hash ','hash ').replace('نتیجه thực','نتیجه واقعی').replace('نحله','نحوه')
open(p,'w').write(s)
PY
echo done