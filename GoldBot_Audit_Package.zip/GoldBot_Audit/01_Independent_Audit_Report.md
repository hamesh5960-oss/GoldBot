# خروجی اول — گزارش ممیزی مستقل

**موضوع:** ممیزی سورس GoldBot 8.2.5 + سند «Engineering Source Audit & Implementation Specification v1.0» و مشخصات اجرایی اتصال Toobit USDT-M Futures
**تاریخ:** 2026-11-21 | **نسخه:** AUDIT-REV-1.0
**هیئت:** معماری معاملاتی / Forex-Crypto Futures / Toobit API / MT5 Adapter / ریسک / سیستمهای توزیعشده / تست / امنیت (بهصورت یک تیم ممیزی مستقل)

---

## 0. خلاصه اجرایی و حکم

| مورد | نتیجه ممیزی |
|---|---|
| وضعیت نهایی سند | **REJECTED** (برای این حکم دلیل فنی باقیمانده وجود دارد: Open Decisions و عدم اثبات عملیاتی Toobit) |
| قابل استفاده برای Kickoff | **بله، با شرایط** — پس از بسته شدن OPEN-UNIT-01, OPEN-TPSL-01, OPEN-POSMODE-01, OPEN-TESTNET-01 و تکمیل نقشه RTM |
| مجوز معامله واقعی | **صفر** |
| تطبیق با سورس واقعی | **انجام شد** (پس از در دسترس قرار گرفتن مخزن GitHub جایگزین لینک Gofile مسدود) |
| کد Toobit در سورس | **صفر** — ادعای سند ورودی تأیید شد |
| صحت ادعاهای API سند ورودی | عمدتاً صحیح؛ ولی ۵ مورد تناقض جدی با API زنده/مستندشده یافت شد (funding، unit، TP/SL query، position mode، index symbol) |

---

## 1. دامنه و شیوه ممیزی

### 1.1 منابع بررسیشده
1. سند ورودی v1.0 (متن ارسالشده توسط مالک پروژه).
2. مخزن جایگزین سورس: `https://github.com/hamesh5960-oss/GoldBot/` حاوی:
   - `GoldBot_Final_Release_v8.2.5.zip` — SHA256: `3baed37dc55b44a958229f115b7276a7c959aae7c17dab140b3da1250d930fc7`
   - `GoldBot_Toobit_Audit_v1_1.md` — یک ممیزی قبلی (v1.1) که **مرجع ممیزی حاضر قرار نگرفت**، فقط بهعنوان artefact اضافی ثبت شد.
3. استخراج کامل ZIP: 293 فایل در پوشه `GoldBot_Final_Release/`.
4. مستندات رسمی Toobit (بخش 12 سند اجرایی) و پاسخهای زنده API عمومی ذخیرهشده در `evidence/`.

### 1.2 کنترلهای قابل بازتولید (نتایج واقعی ممیزی)
| کنترل | نتیجه |
|---|---|
| ZIP integritetz | PASS — `zipfile.testzip()` بدون خطا، 293 عضو |
| SHA256SUMS | PASS — 292 ورودی، 292 تطابق، 0 missing؛ فایل SHA256SUMS self-excluded |
| Python compileall | PASS — `src`, `tests`, `conftest.py`, `run_goldbot.py` |
| Test collection | **1085 collected** (پس از نصب optional `fastapi` موردنیاز 2 فایل وب) |
| اجرای کامل suite | **1080 passed, 4 skipped, 1 xfailed, exit=0, 71.43s** (Python 3.13 محیط ممیزی) |
| XFAIL شناختهشده | `test_already_closed_duplicate_delivery_returns_the_cached_ack` — دلیل: mt5_broker.py خط 901–903 caching ack را مهر نمیزند؛ **هیچ سفارش تکراری رخ نمیدهد**، ولی cached ack بازیابی نمیشود |
| Skipها | 4 مورد `test_live_launcher.py` چون PowerShell در محیط Linux نیست |
| جستجوی Toobit در سورس | 0 نتیجه (`toobit`, `XAUUSDT`, `Futures`, `ExchangeAdapter`, `basis`) |
| شمارش فایل تست | 73 فایل Python در `tests/`، 71 فایل `test_*.py` — ادعای سند تأیید شد |
| ارجاع README به reports/audit و reports/review | **مسیرها وجود ندارند** — ادعای CR-08 تأیید شد |
| نصب/اجرا | محیط aws pytest log در `evidence/pytest_full.log` |

**نکته مهم درباره عدد 1084:** README و RELEASE-MANIFEST مینویسند «1,084 PASS / 0 FAIL» و TEST-COVERAGE-STATUS «1,084 تست 모두 PASS» مینویسد. اجرای مستقل نشان میدهد 1080 pass + 4 skip + 1 xfail است. عدد 1084 ظاهراً «1080 pass + 4 skip» است، نه 1084 PASS. MANIFEST در جای دیگری مینویسد «1,082 passed، 2 skipped، 1 xfailed» — یعنی **سه عدد متفاوت در سه سند بسته**. این یکنقص مستنداتی واقعی است (AUD-M01).

### 1.3 محدودیتهای ممیزی
- تستها روی Python 3.13 اجرا شدند، در حالی که بسته ادعای Python 3.14.7/Windows را میدهد. بنابراین parity دقیق环境与 نسخه مبنا اثبات نشده است.
- MT5 واقعی (MetaTrader5 on Windows) در محیط ممیزی موجود نبود؛ تستها با FakeBroker/parity tape اجرا شدند. اجرای سفارش واقعی MT5 یا Toobit **اثبات نشده** است.
- عملیات write Toobit بدون API key مجاز و سرمایه控制系统无法通过 حاضر قابل اجرا نیست.

---

## 2. نقاط قوت سورس و سند (بر اساس شواهد، не تعارف)

| điểm قوت | شاهد |
|---|---|
| مرزبندی domain/ports/app/adapters/runtime/web | فهرست واقعی `src/goldbot/` — ساختار دقیقاً همان است که سند ادعا میکند |
| IBrokerGateway با قرارداد صریح و idempotency by key | `src/goldbot/ports/broker.py` — متدهای connect/health/symbol_info/account/positions/orders/deals/submit/modify/close/find_by_client_ref |
| Write-ahead + fsync + idempotency + UNKNOWN | `src/goldbot/app/order_coordinator.py` — `journal.append(..., fsync=True)` قبل از `broker.submit`، idem=`run_id:intent_id`، `SubmitUncertain` → `OrderState.UNKNOWN` |
| State machine صریح | `src/goldbot/domain/fsm/order.py` — انتقالات مجاز و `IllegalTransition` |
| Reconciliation با adopt orphan و fail-closed | `src/goldbot/app/reconciler.py` —broker truth wins، unreadable → unclean → quarantine |
| Composition root تزریقپذیر | `src/goldbot/runtime/bootstrap.py` — پارامترهای `live_broker`, `live_feed`, `live_clock`, `info_override` |
| مدلهای پولی و sealing سفارش | `domain/money.py`, `domain/execution.py` — HMAC seal در `ApprovedOrder` |
| Cost model کامل MT5 | `app/costs.py` — commission/spread/slippage/swap + triple-swap، در sizing فراخوانی میشود |
| صداقت در مستندات منفی | `BACKTEST-REPORT.md` — خالص −158.34 USD، PF 0.95، DD 8.66%؛ RELEASE-MANIFEST وضعیت «READY FOR DEMO VALIDATION» |
| تستهای گسترده | 1085 تست collect، 1080 pass واقعی، failure injection و soak |

---

## 3. نقاط ضعف و ریسکها

### 3.1 نقاط ضعف سورس
1. **FSMها فاقد حالت حفاظتاند.** `OrderState` شامل `PROTECTED/PROTECTION_PENDING` نیست؛ `PositionSnapshot.has_protection` صرفاً `sl is not None` است (وضعیت داخلی، نه venue truth). برای Futures باید FSM جداگانه و verification اضافه شود؛ مدل MT5 تغییر نکند.
2. **`compute_volume` و `compute_capital_volume` با lot/contract_size/point/group float کار میکنند.** `compute_volume` در کد بهعنوان reference نگه داشته شده و pipeline جاری `plan_entry` است. هر دو نباید در Futures فراخوانی شوند.
3. **xfail واقعی در close idempotency.** یادداشت: replay سفارش close already-closed، cached ack را برنمیگرداند. امنیت سفارش تکراری حفظ شده ولی دقت journal کم است. Gate MT5 اجازه xfail فقط در allowlist میدهد — تست مربوطه اکنون xfail است، قبل از freeze باید یا رفع یا بهصورت رسمی در ADR پذیرفته شود.
4. **وابستگی قوی به MT5 semantics** در `SymbolInfo` (sessions، stops_level، freeze_level، trade_mode hedging/netting، swap) و `AccountSnapshot` (login/server/magic). مدل Futures جدا لازم است.
5. **نسخه Python ادعاشده (3.14.7) در محیط ممیزی قابل بازتولید نبود.**
6. **سه عدد متفاوت شمارش تست در README/RELEASE-MANIFEST/TEST-COVERAGE-STATUS** و مسیرهای گم reports/audit, reports/review.

### 3.2 نقاط ضعف سند ورودی
1. Funding 8H/±0.05% با API زنده 4H/±0.5% تناقض دارد.
2. واحد LOT_SIZE و quantity/position مبهم است (OPEN-UNIT-01).
3. استعلام حفاظت بدون `stopCategory=STOP_PROFIT_LOSS` ناقص است.
4. Position mode فرض شده ولی endpoint خواندن آن مستند نشده است.
5. جایگاه هزینهها در sizing مشخص نشده و ورود بر mid فرض شده است.
6. فرض «24/7» با `isRwa=true, rwaType=STOCK` تناقض دارد.
7. Index symbol `XAU` اشتباه است؛ `XAUUSDT` صریح است.
8. برخی عبارات مبهم («در صورت نیاز»، «بهصورت مناسب») بدون شرط/رفتار مشخص باقی ماندهاند.
9. تستها صرفاً «تست»اند و شواهد قابل بررسی Order ID/Response در آنها تعریف نشده است (در سند اصلاحی جداگانه خروجی هفتم اضافه شد).

### 3.3 ریسکهای کلیدی باقیمانده
| ریسک | سطح | وضعیت |
|---|---|---|
| واحد قرارداد اشتباه → sizing 1000× | Critical | OPEN until controlled validation |
|positionme بدون SL به دلیل query ناقص | Critical | FIXED-IN-SPEC، نیاز به تست |
| funding/tier historical → هزینه اشتباه | Critical | FIXED-IN-SPEC |
| position mode ناشناخته → close معکوس | High | OPEN until discovery |
| فقدان testnet → write روی سرمایه واقعی | High | OPEN |
| بکـتست منفی + demo بدون fill | High | بهصورت صریح Gate قفل شده |
| secret leakage | Medium | تست طراحی شده، اجرا نشده |
| وابستگی MT5 وارد Futures شود | High | import guard طراحی شده، اجرا نشده |

---

## 4. ارزیابی کلی

سورس 8.2.5 یک پایه مهندسی قابل قبول و دارای انضباط است: مرزها واضحاند، state recovery جدی گرفته شده و تستها واقعاً گستردهاند. سند ورودی v1.0 نیازمند اصلاحات دقیقAPI و ریاضیاتی است، ولی تصمیم معماری اصلی آن (یک کدبیس، دو runtime، Shared Strategy Core) **صحیح و از ممیزی مستقل تأیید میشود**.

با وجود این، سند به ادعای «READY FOR KICKOFF» نزدیک است ولی **بهعنوان سند نهایی قابل تأیید نیست**، چون:
- چهار OPEN DECISION مسیر اجرا را تحت تأثیر قرار میدهند (واحد، حفاظت، position mode، محیط تست)؛
- سورس Toobit وجود ندارد و هیچ شواهد fill/protection واقعی وجود ندارد؛
- بکـتست مبنا منفی است و نمیتواند مبنای مجوز capital واقعی باشد.

**حکم نهایی:** `REJECTED` (برای نسخه نهایی سند). سند اصلاحشده §05 میتواند مبنای جلسه Kickoff باconditions فوق قرار گیرد ولی عنوان «سند نهایی تأییدشده» تنها پس از بسته شدن FULL GATES خروجی هفتم صادر میشود.

---

## 5. پیوست: فهرست فایلهای سورس واقعی مورد استناد
- `src/goldbot/ports/broker.py`, `src/goldbot/ports/marketdata.py`
- `src/goldbot/domain/model.py`, `src/goldbot/domain/execution.py`, `src/goldbot/domain/fsm/order.py`
- `src/goldbot/app/order_coordinator.py`, `src/goldbot/app/reconciler.py`, `src/goldbot/app/engine.py`
- `src/goldbot/app/risk/sizing.py`, `src/goldbot/app/risk/capital.py`, `src/goldbot/app/costs.py`
- `src/goldbot/runtime/bootstrap.py`, `src/goldbot/runtime/live.py`
- `src/goldbot/adapters/mt5_broker.py`, `src/goldbot/web/app.py`
- `config/base.toml`, `config/risk_profiles.toml`, `config/strategies/{numeric,zones}.toml`
- `README.md`, `RELEASE-MANIFEST.md`, `TEST-REPORT.md`, `docs/TEST-COVERAGE-STATUS.md`, `BACKTEST-REPORT.md`, `reports/live_demo_validation.md`
- `tests/test_failure_injection_execution.py` (xfail), `tests/test_live_launcher.py` (4 skip)

تمام مسیرهای فوق مستقیماً از ZIP استخراجشده مشاهده شدهاند؛ هیچ نام فایل فرضی диگری در اسناد ممیزی به کار نرفته است.
