# Targeted remediation — final report

**Date:** 2026-11-25
**Base package:** `GoldBot_v8.2.5_PHASE_A_AUDIT_PACKAGE_2026-11-25.zip`
**Base SHA-256:** `fcca706e2476116ef10272b66a31093a83cb5be48598d64dd9a81ec9539954d1` (verified before any edit; internal `SHA256SUMS.txt` 10/10 OK, `SOURCE-MANIFEST.txt` 292/292 OK)
**Scope:** FIX-01 … FIX-06 plus the A3/A4/A7/A8 regression controls. No PHASE B, no PHASE C.

---

## 0. Answer summary (the 15 mandatory questions)

| # | Question | Answer |
| --- | --- | --- |
| 1 | Which FIXes were really fixed? | **All six** (FIX-01…FIX-06), each with a dedicated executed test module. One extra defect found by the A7 control was also fixed (§7 of the matrix). |
| 2 | Which files changed? | 6 source files: `ports/ledger.py`, `app/operation_ledger.py`, `adapters/sqlite_operation_ledger.py`, `app/order_coordinator.py`, `adapters/mt5_broker.py`, `ports/execution.py`. 5 test modules updated (4 pure renames, 1 strengthened). `SOURCE-MANIFEST.txt` regenerated. |
| 3 | Which files were added? | 6 test modules `tests/test_fix01…test_fix06_*.py`; `docs/adr/020-ledger-identity-digests-and-counters.md`. |
| 4 | Was a real migration from the previous version tested? | Yes — real v1-schema and real v2-schema SQLite databases with the real v1/v2 digests, migrated by the real migration, then driven through the real coordinator. |
| 5 | Were old and new hashes compared in a real test? | Yes. Both historical algorithms are pinned as constants (`fa5e0715…`, `342cf62d…`), recomputed independently inside the test file, and compared to the current digest (`e22bc09f…`). No placeholder hashes. |
| 6 | Was MT5 history `None` tested? | Yes — `tests/test_fix03_mt5_history_none.py` drives the real `MT5Broker` against a fake terminal with `None`, raising, valid-empty and valid-with-order answers. Real MT5 remains **NOT VERIFIED**. |
| 7 | Does ENTRY matching check economic fields? | Yes — symbol, side, volume (symbol `volume_step`/2 tolerance), magic, client ref, order state, SL, TP and timing. Any single mismatch blocks adoption; >1 match is ambiguous. |
| 8 | Do InMemory and SQLite counters behave identically? | Yes — same sequence on both yields `(claim_attempts, submit_call_markers, duplicate_requests) == (1, 2, 1)` and the same state. Only durability differs, and that is asserted. |
| 9 | Do all live paths pass the gate? | Yes — `runtime/live.py` calls `ensure_live_ready()`; AU-29…AU-33 assert refusal without a durable ledger or a resolved scope. |
| 10 | Was any test deleted, skipped or weakened? | **No.** 4 modules changed by mechanical rename only (5/5, 3/3, 1/1, 5/5 lines, shown in full in `SOURCE_DIFF_FULL.diff`); AU-36 was **strengthened** (+54/−7). The 6 skips are the same pre-existing ones (4 PowerShell launcher, 2 soak under `GOLDBOT_SOAK=0`). |
| 11 | Real full-test result | **1224 passed, 6 skipped, 3 warnings in 16.57 s** (baseline: 1142 passed, 6 skipped in 18.62 s). |
| 12 | Which tests were not run? | The 6 skipped (4 × PowerShell launcher, 2 × soak) and everything requiring Windows, a real MT5 terminal, a broker account or two VPS hosts. All are **NOT RUN**, not "passed". |
| 13 | Remaining limits | `REPORTS/REMAINING_LIMITS.md`. |
| 14 | Final ZIP hash | An archive cannot contain its own hash, so it is published **next to** the archive: `iteration02/04_TARGETED_DELIVERY/FINAL_ZIP_SHA256.txt`, and repeated in the delivery message. The internal `SHA256SUMS.txt` covers all 316 files inside the package. |
| 15 | Exact path and name of the final file | `/home/user/iteration02/04_TARGETED_DELIVERY/GoldBot_v8.2.5_PHASE_A_TARGETED_REMEDIATION_2026-11-25.zip` |

---

## 1. Method

1. Hashed and verified the base ZIP; extracted it without modifying it; built an
   independent working copy (`03_TARGETED_WORKING_COPY/SRC`).
2. Reproduced the baseline suite **before** touching anything: **1142 passed, 6
   skipped, 18.62 s** — exactly the reference number in the mission.
3. Confirmed all six defects in the source at the reported locations.
4. Rewrote only what each FIX requires, then wrote a dedicated test module per FIX
   **and ran it**; a claim without a red/green test was not accepted.
5. Ran the full suite, the A3/A4/A7/A8 controls and the multi-process test
   repeatedly, then packaged and re-ran everything from the extracted archive.

Nothing was taken on trust from another tool's summary; every verdict in
`FIX_MATRIX_FIX-01_06.md` is backed by a test executed here.

## 2. What changed, per fix

| FIX | The defect | The fix |
| --- | --- | --- |
| 01 | `_clean()` mapped `#`/whitespace → `_` and empty → `-`, merging distinct scopes onto one `op_id` | percent-encoded, injective key; strict scope validation; legacy key kept only for recognising old rows |
| 02 | no digest scheme marker; only the current algorithm accepted → false `OperationConflict` after migration | v1/v2/v3 schemes reproduced exactly; `legacy_hashes` normalises a matching stored hash instead of conflicting, without touching state |
| 03 | `history_orders_get(...) or ()` turned a failed query into an empty result → `RESOLVED_ABSENT` → resend | `None` is an error with `last_error()` captured; completeness, window and retention are part of the evidence model |
| 04 | adoption matched comment + magic only | full economic comparison per candidate; missing venue data is inconclusive; >1 match ambiguous; ties never resend |
| 05 | `submit_calls` incremented before the call, readable as "orders sent" | `submit_call_markers` with documented meaning; `count_submit` removed; rename recorded in the migration report |
| 06 | `PRAGMA integrity_check` executed, never asserted | `== "ok"` asserted, plus row counts, PK, indexes, idempotent re-migration, post-migration usability |

A seventh, unlisted defect surfaced while running the A7 control: whole-row rewrites
from a stale snapshot could revert `SUBMITTING`/`UNKNOWN` to `APPROVED` across
processes. It was fixed under the A7 control (targeted SQL inside `BEGIN IMMEDIATE`),
not left as a note, because A7 cannot be claimed otherwise. It is reported as such in
`FIX_MATRIX_FIX-01_06.md` §7.

## 3. Test totals

| run | result |
| --- | --- |
| baseline, before edits | 1142 passed, 6 skipped, 18.62 s |
| after all six fixes | **1224 passed, 6 skipped, 3 warnings, 16.57 s** |
| new tests | 82 (20 + 13 + 13 + 22 + 9 + 5) |
| A3/A4 control | 47 passed |
| A7 control | 5 consecutive runs × 2 passed (15 consecutive runs earlier, 0 failures) |
| A8 control | 31 passed |
| tests deleted / skipped / xfailed | 0 / 0 / 0 (6 pre-existing skips unchanged) |

## 4. Package contents

```
GoldBot_v8.2.5_PHASE_A_TARGETED_REMEDIATION_2026-11-25/
├── README-DELIVERY.md
├── SHA256SUMS.txt                      ← hashes of all 316 files in this package
├── GoldBot_Source_v8.2.5/              ← corrected source (299-entry SOURCE-MANIFEST.txt)
└── REPORTS/
    ├── TARGETED_REMEDIATION_REPORT.md          ← this file
    ├── FIX_MATRIX_FIX-01_06.md
    ├── SOURCE_DIFF_REPORT.md
    ├── SOURCE_DIFF_FULL.diff                   ← complete unified diff
    ├── MIGRATION_AND_HASH_COMPATIBILITY.md
    ├── RECOVERY_AND_UNKNOWN.md
    ├── REGRESSION_A3_A4_A7_A8.md
    ├── REMAINING_LIMITS.md
    ├── REPRODUCTION.md
    └── TEST_LOGS/
        ├── BASELINE_full_suite.log
        ├── FINAL_full_suite.log
        ├── REGRESSION_A3_A4.log
        ├── REGRESSION_A7.log
        └── REGRESSION_A8.log
```

## 5. Status

`TARGETED REMEDIATION COMPLETE — PENDING INDEPENDENT VERIFICATION`

This is **not** an approval of MT5 Demo, Windows, soak, cross-VPS or production
readiness, and it grants no licence for real trading.
