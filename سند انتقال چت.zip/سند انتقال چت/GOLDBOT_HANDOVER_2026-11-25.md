# سند انتقال کار — GoldBot v8.2.5 / PHASE A Targeted Remediation

**تاریخ سند:** 2026-11-25
**هدف سند:** انتقال کامل و قابل استناد همهٔ کاری که در این چت روی بات انجام شده، به یک چت جدید.
**زبان مرجع مأموریت:** فارسی. **واژگان وضعیت (Status) عیناً انگلیسی می‌ماند.**
**وضعیت نهایی کار تا این لحظه:**

```
TARGETED REMEDIATION COMPLETE — PENDING INDEPENDENT VERIFICATION
```

> این وضعیت به‌معنای تأیید MT5 Demo، ویندوز، Soak، Cross-VPS یا آمادگی تولید **نیست** و هیچ مجوزی برای معاملهٔ واقعی صادر نمی‌کند.

---

## فهرست

1. خلاصهٔ مدیریتی
2. خط زمانی کار در این چت
3. مفاهیم و طراحی فعلی لجر (برای ادامهٔ کار لازم است)
4. شش نقص اصلاح‌شده (FIX-01 … FIX-06)
5. نقص هفتم که در کنترل A7 پیدا شد
6. فهرست دقیق فایل‌های تغییر‌یافته و افزوده‌شده
7. وضعیت تست‌ها و شواهد اجرا
8. تنها تغییر غیرتغییرنام در تست‌های ممیزی (افشا)
9. مهاجرت اسکیما و سازگاری هش
10. مسیرهای ورود/خروج حالت UNKNOWN
11. محدودیت‌های باقی‌مانده و آنچه اثبات نشده
12. دارایی‌ها: ZIPها، هش‌ها، مسیرها، دستور بازتولید
13. قواعد الزامی برای چت جدید (چه باید/نباید بشود)
14. قالب گزارش پایان کار (۱۵ پرسش + سه خط وضعیت مجاز)
15. واژه‌نامه و پیوست دستورها

---

## 1. خلاصهٔ مدیریتی

در این چت، روی بات GoldBot v8.2.5 در سه لایه کار شد:

1. **بازبینی مستقل اصلاحات A1…A8** روی بستهٔ تحویلی `GoldBot_v8.2.5_PHASE_A_AUDIT_PACKAGE_2026-11-25.zip`.
2. **شناسایی و اثبات شش نقص باقی‌مانده** در سورس واقعی (FIX-01…FIX-06) و سپس **اصلاح واقعی آن‌ها در سورس**، نه گزارش‌نویسی.
3. **اثبات با تست:** هر FIX با یک ماژول تست اختصاصی، همراه با اثبات جهش (mutation) که نشان می‌دهد تست روی کد اصلاح‌نشده شکست می‌خورد.

نتیجهٔ عددی:

| سنجه | مقدار |
| --- | --- |
| تست‌های مبنا (قبل از هر تغییری) | **1142 passed, 6 skipped, 3 warnings** — 18.62s |
| تست‌های نهایی (بعد از شش اصلاح) | **1224 passed, 6 skipped, 3 warnings** — 16.55s |
| تست‌های جدید | **82** (20+13+13+22+9+5) |
| تست حذف/ضعیف/اسکیپ‌شدهٔ جدید | **0** (همان ۶ اسکیپ قبلی) |
| کنترل A3/A4 | 47 passed |
| کنترل A7 (دو فرایند، یک DB) | 6 اجرای متوالی، هر بار 2 passed |
| کنترل A8 (دروازهٔ Live) | 31 passed |
| اجرای کامل از نسخهٔ استخراج‌شدهٔ ZIP | **1224 passed, 6 skipped** — 18.41s |
| هش نهایی ZIP | `937517037894c99916e6b30d4b5ff3a63530e9bf9931f3b10616384f52d1758d` |

---

## 2. خط زمانی کار در این چت

| # | گام | نتیجه |
| --- | --- | --- |
| 1 | دریافت و بررسی بستهٔ پایه | `GoldBot_v8.2.5_PHASE_A_AUDIT_PACKAGE_2026-11-25.zip` — SHA-256 `fcca706e2476116ef10272b66a31093a83cb5be48598d64dd9a81ec9539954d1` (1.7MB، 304 فایل) — هش تأیید شد؛ `SHA256SUMS.txt` ۱۰/۱۰ OK؛ `SOURCE-MANIFEST.txt` ۲۹۲/۲۹۲ OK |
| 2 | ساخت کپی کاری مستقل (بستهٔ مرجع دست‌نخورده می‌ماند) | `/home/user/iteration02/03_TARGETED_WORKING_COPY/` شامل استخراج دست‌نخورده + `SRC/` برای ویرایش |
| 3 | بازتولید مجموعهٔ تست مبنا | **1142 passed, 6 skipped, 3 warnings, 18.62s** — دقیقاً برابر عدد مرجع مأموریت (بدون انحراف) |
| 4 | بازبینی سورس و تأیید محل هر شش نقص | همهٔ شش مورد در سورس تأیید شد (فایل/خط دقیق) |
| 5 | بازنویسی لایهٔ پرت `ports/ledger.py` برای FIX-01/02/05 | هویت بدون تصادم + سه اسکیم هش + معنای شمارنده‌ها |
| 6 | تطبیق پیاده‌سازی‌های لجر و هماهنگ‌کننده | `app/operation_ledger.py`، `adapters/sqlite_operation_ledger.py`، `app/order_coordinator.py` |
| 7 | FIX-03 (MT5 `None`) و FIX-04 (تطبیق اقتصادی) | `adapters/mt5_broker.py`، `ports/execution.py`، `app/order_coordinator.py` |
| 8 | کشف نقص هفتم ضمن اجرای کنترل A7 (Lost Update بین‌فرایندی) | اصلاح شد؛ جزئیات در بخش ۵ |
| 9 | FIX-06: تقویت AU-36 (assert واقعی روی `integrity_check`) | +54/−7 خط در همان تست |
| 10 | نوشتن و اجرای شش ماژول تست اختصاصی | 82 تست، همه سبز |
| 11 | اجرای مجموعهٔ کامل + کنترل‌های A3/A4/A7/A8 | همه سبز (جدول بخش ۷) |
| 12 | تولید گزارش‌ها، بازسازی `SOURCE-MANIFEST.txt` (۲۹۹ رکورد) و بسته‌بندی ZIP | `GoldBot_v8.2.5_PHASE_A_TARGETED_REMEDIATION_2026-11-25.zip` |
| 13 | استخراج مجدد ZIP و اجرای کامل تست از نسخهٔ استخراج‌شده | 316/316 هش OK، ۲۹۹/۲۹۹ مانیفست OK، **1224 passed** |
| 14 | (ثبت نهایی) هش خود ZIP | `9375170378…52d1758d` |

> برای جزئیات مراحل پیش از این چت (Iteration 01، PHASE A، و اصلاحات A1…A8) مرجع رسمی، گزارش‌های داخل همان بستهٔ تحویلی است: `REPORTS/AUDIT_MATRIX_A1_A8.md`، `REPORTS/PHASE_A_AUDIT_REMEDIATION_REPORT.md`، `REPORTS/PHASE_A_REPORT.md`، `REPORTS/TRACEABILITY_PHASE_A.md`، `REPORTS/MIGRATION_AND_RECOVERY_PHASE_A.md`. این سند آن‌ها را بازنویسی نمی‌کند و ادعای بیشتری از آن‌ها ندارد.

---

## 3. مفاهیم و طراحی فعلی لجر

### 3.1 هویت عملیات (Operation Identity)

هر اقدام معاملاتی (ENTRY, CLOSE, PARTIAL_CLOSE, MODIFY_SL, MODIFY_TP, MODIFY_PROTECTION, CANCEL, FLATTEN) یک «عملیات» با هویت پایدار دارد:

```
op_id = enc(server) "#" login "#" enc(deployment_id) "#" KIND "#" enc(intent_id)
```

* `enc` = percent-encoding با `safe = "-._~"` → **تزریقی (injective)**: رشته‌های متفاوت همیشه کلیدهای متفاوت می‌دهند و `#` هرگز داخل یک جزء ظاهر نمی‌شود.
* `parse_operation_id()` معکوس‌پذیر است (رفت‌وبرگشت دقیق).
* `run_id` **هرگز** جزء هویت نیست (ری‌استارت باید به همان ردیف برسد)؛ اما `account/server/deployment` **هست** (دو استقرار با intent یکسان نباید تصادم کنند).

### 3.2 `OperationScope` — اعتبارسنجی، نه ترمیم

| ورودی | نتیجه |
| --- | --- |
| `account_login` از نوع bool / غیر int / منفی | `ScopeUnresolved` |
| `server` یا `deployment_id` با فاصلهٔ ابتدا/انتها یا کاراکتر کنترلی | `ScopeUnresolved` |
| نیمه‌بسته (مثل `0, "S", ""`) | `ScopeUnresolved` |
| کاملاً باز `(0, "", "")` | مجاز ولی `bound is False`؛ کد Live آن را رد می‌کند |
| کاملاً بسته | مجاز |

کلید قدیمی و «Lossy» فقط برای **شناسایی ردیف‌های قدیمی** باقی مانده است: `legacy_key()` و `legacy_scoped_operation_id()`؛ هیچ‌گاه برای کار جدید ساخته نمی‌شود.

### 3.3 سه اسکیم هش محموله (Payload Digest)

| اسکیم | ورودی canonical | منشأ |
| --- | --- | --- |
| **v1** | `{kind, intent_id, ...economic fields}` | PHASE A (بدون scope) |
| **v2** | v1 + `"scope": "<lossy key>"` | بستهٔ ممیزی |
| **v3** | `{"scheme":"v3", "kind", "intent_id", "scope":"<encoded key>", ...}` | این اصلاح |

* در هر سه اسکیم: floatها به ۸ رقم اعشار نرمال و کلیدها مرتب می‌شوند (`0.12` و `0.1200000000001` یک محموله‌اند).
* مقادیر مرجع (در تست‌ها هم مستقلاً بازمحاسبه می‌شوند):

```
payload: ENTRY / "fix02-entry" / XAUUSD buy 0.12 sl=1990.0 tp=2020.4 magic=770001 client_ref=gb-fix02-0001
scope:   Fake-Demo / 12345678 / audit-vps

v1 = fa5e0715cf4fc80e8d711442bacec511
v2 = 342cf62de8e2a5ddc188206235ff4bb4
v3 = e22bc09f47a0f1c8cefdd2d8daf9948e
```

### 3.4 قواعد تصمیم لجر هنگام `record()`

| هش ذخیره‌شده | هش پیشنهادی | نتیجه |
| --- | --- | --- |
| مساوی | — | درخواست تکراری؛ `duplicate_requests += 1` |
| داخل `legacy_hashes` | متفاوت | **نرمال‌سازی**: هش v3 ذخیره می‌شود، `digest_scheme="v3"`؛ **state، ticket، ارجاع‌ها و شمارنده‌ها دست‌نخورده** |
| هر چیز دیگر | متفاوت | `OperationConflict` — چیزی نوشته نمی‌شود |

### 3.5 معنای شمارنده‌ها (FIX-05)

| ستون | چه‌وقت نوشته می‌شود | چه چیزی را اثبات می‌کند |
| --- | --- | --- |
| `claim_attempts` | وقتی CAS پایدار برنده می‌شود (قبل از هر فراخوانی) | این فرایند حق تلاش را گرفت |
| `submit_call_markers` | بلافاصله **قبل از** `submit/close/modify` | «قصد فراخوانی» محقق و پایدار شد — **نه** رسیدن به venue |
| `duplicate_requests` | وقتی درخواستی تکراری ارائه شود | درخواست دی‌دوپلیکیت شد |

نام‌های بازنشسته: `send_attempts` (v1) و `submit_calls` (v2). برای اینکه گزارش‌های قدیمی دوباره تفسیر نشوند، مهاجرت این تغییر نام را در `migration_report()["counter_rename"]` ثبت می‌کند:

```
"send_attempts -> claim_attempts, submit_calls -> submit_call_markers"
```

**قاعدهٔ سخت:** «تعداد سفارش‌هایی که واقعاً به venue رسید» فقط از حقیقت venue (ack/ticket/reconcile) قابل دانستن است؛ هیچ‌جا از شمارنده استنتاج نمی‌شود.

### 3.6 اسکیمای لجر: نسخهٔ ۳

`LEDGER_SCHEMA_VERSION = 3` و نسخه در جدول `operation_ledger_schema(id=1, version)`.

* v1 → v2: `send_attempts` → `claim_attempts`؛ افزودن `submit_calls`؛ افزودن ستون‌های scope.
* v2 → v3: `submit_calls` → `submit_call_markers`؛ افزودن `digest_scheme`.
* ردیف‌ها **Adopt** می‌شوند نه Duplicate: اولین `record()` برای یک intent، کلید قدیمی (بدون scope یا lossy) را پیدا می‌کند، `op_id` و سه ستون scope را بازنویسی می‌کند و رویداد `OperationKeyScoped` را با هر دو شناسه ثبت می‌کند.

### 3.7 قواعد اتمیسیتی (عیناً و بدون ادعای بیشتر)

* لجر و ژورنال **یک اتصال SQLite** مشترک دارند؛ بنابراین ردیف لجر و رویداد حسابرسی آن در **یک** `COMMIT` نوشته می‌شوند.
* **هیچ** ادعایی دربارهٔ اتمی‌بودن SQLite ↔ broker وجود ندارد. فراخوانی venue بعد از commit رخ می‌دهد و کرش بین آن دو، همان دلیلی است که `SUBMITTING` در ری‌استارت `UNKNOWN` می‌شود.

---

## 4. شش نقص اصلاح‌شده

> واژگان: **FIXED** = سورس تغییر کرد **و** تستی اجرا و سبز شد که روی کد قبلی شکست می‌خورد. **NOT VERIFIED** = شاهدی تولید نشده. حالت «احتمالاً اصلاح شده» وجود ندارد.

| FIX | شدت | وضعیت | فایل‌های تغییر‌یافته | تست اختصاصی |
| --- | --- | --- | --- | --- |
| FIX-01 کدگذاری بدون تصادم scope | P1 | FIXED | `ports/ledger.py`، `app/operation_ledger.py`، `adapters/sqlite_operation_ledger.py`، `app/order_coordinator.py` | `test_fix01_scope_identity.py` (20) |
| FIX-02 مهاجرت هش قدیمی | P1 (مسدودکنندهٔ پذیرش) | FIXED | همان چهار فایل | `test_fix02_legacy_hash_migration.py` (13) + `test_fix06_*` (5) |
| FIX-03 `None` در تاریخچهٔ MT5 | P1 | FIXED در لایهٔ آداپتر؛ واقعیت MT5 **NOT VERIFIED** | `adapters/mt5_broker.py`، `ports/execution.py`، `app/order_coordinator.py` | `test_fix03_mt5_history_none.py` (13) |
| FIX-04 تطبیق فیلدهای اقتصادی | P1 | FIXED | `app/order_coordinator.py` | `test_fix04_economic_matching.py` (22) |
| FIX-05 معنای شمارنده‌ها | P2 | FIXED | چهار فایل لجر/هماهنگ‌کننده + ۴ ماژول تست (فقط تغییر نام) | `test_fix05_counter_semantics.py` (9) |
| FIX-06 نبودِ assert روی `integrity_check` | P2 | FIXED | `tests/test_phase_a_audit_fsm_and_live.py` (AU-36) | `test_fix06_migration_integrity.py` (5) |

### FIX-01 — کدگذاری بدون تصادم
**نقص:** `_clean()` با `_UNSAFE = re.compile(r"[#\s]")` هر `#` و هر فاصله را `_` می‌کرد و جزء خالی `-` می‌شد؛ پس `Broker A` و `Broker_A` یک `op_id` می‌دادند.
**اصلاح:** percent-encoding تزریقی؛ اعتبارسنجی سخت‌گیرانهٔ scope؛ کلید Lossy فقط برای شناسایی.
**شاهد:** `test_fix01_the_old_encoding_merged_distinct_servers_the_new_one_does_not` (خود نقص را هم نشان می‌دهد)؛ ماتریس >500 شناسهٔ یکتا؛ رفت‌وبرگشت دقیق؛ ۱۱ شکل scope نامعتبر؛ و `test_fix01_an_unresolved_scope_cannot_create_an_operation_or_reach_the_venue` → `ScopeUnresolved`، **۰ ارسال**، **۰ ردیف**.

### FIX-02 — مهاجرت هش
**نقص:** هش بدون نشانهٔ اسکیم و تنها اسکیم جاری پذیرفته می‌شد → `OperationConflict` کاذب برای محمولهٔ اقتصادی یکسان پس از مهاجرت.
**اصلاح:** سه اسکیم صریح؛ `legacy_payload_digests()`؛ نرمال‌سازی به‌جای تعارض؛ حفظ کامل state.
**شاهد:** دو هش تاریخی Pin شده و مستقلاً بازمحاسبه‌شده؛ DB واقعی v1 و v2 با هش واقعی و مهاجرت واقعی در سه حالت `APPROVED`/`UNKNOWN`/`ACKED` (۱ ردیف قبل و بعد، state حفظ‌شده)؛ محمولهٔ متفاوت همچنان Conflict؛ **هیچ عملیات جدید و هیچ اتصال اشتباه**؛ و اجرای کامل با هماهنگ‌کننده و بروکر شمارنده → **۰ ارسال**.

### FIX-03 — `None` در تاریخچه
**نقص:** `history_orders_get(...) or ()` شکستِ پرس‌وجو را «خالی» می‌کرد و می‌توانست به `RESOLVED_ABSENT` (و مجوز ارسال مجدد) منتهی شود.
**اصلاح:** `None` = خطا با ثبت `last_error()`؛ `complete=False`؛ افزودن `retention_known`/`window_note` به `ClientRefQuery` و `ResolutionEvidence`؛ در `find_by_client_ref` نیز `or ()` با بررسی صریح `None` و لاگ جایگزین شد.
**شاهد:** ۱۳ تست با `MT5Broker` واقعی روی ترمینال Fake: `None`، استثنا، خالی معتبر، سفارش معتبر، ترمینال قطع، positionهای ناخوانا، پنجرهٔ نامنطبق، و `test_fix03_no_history_answer_can_license_a_resend[None|raise]` → `UNKNOWN` + ۰ ارسال.

### FIX-04 — تطبیق اقتصادی
**نقص:** پذیرش بر اساس comment + magic.
**اصلاح:** مقایسهٔ هر کاندید با symbol، side، volume (تلورانس = نصف `volume_step` سمبل از `symbol_info`، و fallback سخت‌گیرانهٔ `1e-8`)، magic، client_ref، state سفارش (سفارش market که `placed` گزارش شود = ناسازگاری)، SL/TP (تلورانس = ۲×point و حداقل `1e-5`) و زمان (سفارش نباید قبل از عملیات یا در آینده باشد). فیلد غایب venue **با فرض پر نمی‌شود**. صفر تطبیق «در میان کاندیدها» = `inconclusive` نه `absent`. بیش از یک تطبیق = مبهم. تساوی هرگز باعث ارسال مجدد نمی‌شود.
**شاهد:** ۲۲ تست شامل تک‌تک فیلدها، تلورانس حجم، داده‌های ناقص، ابهام، ref تکراری، تاریخچهٔ ناخوانا و `test_fix04_no_economic_tie_ever_leads_to_a_resubmission` (۰ ارسال).

### FIX-05 — شمارنده‌ها
**اصلاح:** `submit_calls` → `submit_call_markers` با معنای مستند؛ حذف `count_submit` (تست `hasattr` مانع بازگشت آن است)؛ InMemory و SQLite هم‌رفتار.
**شاهد:** ۹ تست شامل **کشت واقعی فرایند** (`os._exit(9)`) در دو مرز (قبل از marker: ۰، بعد از marker: ۱)، استثنا حین فراخوانی، موفقیت (۱ claim / ۱ marker / ticket واقعی)، و parity دقیق `(1, 2, 1)`.

### FIX-06 — assert روی مهاجرت
**اصلاح:** AU-36 حالا `PRAGMA integrity_check == "ok"` را assert می‌کند، به‌همراه مجموعهٔ ستون‌ها، PK، سه ایندکس، `IntegrityError` روی کلید تکراری، حفظ تعداد ردیف، حفظ مقادیر (`claim_attempts == 3`، `digest_scheme == "legacy"`)، `foreign_key_check`، و بی‌اثر بودن مهاجرت تکراری. ماژول `test_fix06_*` مسیر v2→v3، مهاجرت نیمه‌کاره، اعتبار بکاپ و قابلیت استفادهٔ DB بعد از مهاجرت را می‌افزاید.

---

## 5. نقص هفتم — Lost Update بین‌فرایندی (کشف‌شده توسط کنترل A7)

این نقص در فهرست FIX نبود، اما **بدون اصلاح آن، کنترل A7 قابل ادعا نبود**، لذا در همین چارچوب اصلاح شد.

**علامت:** تست دوفرایندی A7 متناوباً قرمز می‌شد (`claim_attempts == 0` در حالی که یک ارسال ثبت شده بود؛ گاهی `BrokenBarrierError`).

**علت واقعی:** `_update()` **کل ردیف** را از یک snapshot درون‌حافظه‌ای بازنویسی می‌کرد. اگر یک درخواست تکراری ردیف را قبل از claim فرایند دیگر می‌خواند و بعد می‌نوشت، می‌توانست `SUBMITTING`/`UNKNOWN` را به `APPROVED` **برگرداند** — یعنی یک عملیات حل‌نشده دوباره قابل ارسال می‌شد.

**اصلاح:**
* مسیرهای read-modify-write (`transition`، شمارش تکراری، نرمال‌سازی digest) با SQL هدفمند داخل `BEGIN IMMEDIATE`.
* سازنده‌های خالص رکورد (`_apply_transition`، `_apply_bump`، `_apply_digest_normalisation`) در هستهٔ مشترک می‌مانند تا قواعد یک‌جا باشد.
* مهاجرت با `BEGIN IMMEDIATE` و بازبینی نسخه سریال می‌شود (دو فرایند هم‌زمان نمی‌توانند هر دو مهاجرت کنند).
* بکاپ پیش از مهاجرت فقط وقتی گرفته می‌شود که جدول لجر از قبل وجود داشته باشد (بکاپ هم‌زمان از فایل WAL زنده، شروع را ~۲۰ ثانیه معطل می‌کرد).

**شاهد:** `test_phase_a_audit_multiprocess.py` پس از اصلاح ۱۵ اجرای متوالی بدون خطا، سپس ۵ اجرا، و ۶ اجرای دیگر پس از تنظیم timeout (بخش ۸) — همه `2 passed`.

---

## 6. فهرست دقیق فایل‌های تغییر‌یافته و افزوده‌شده

### 6.1 تغییر‌یافته (۶ فایل سورس + ۱ مانیفست)

| فایل | + | − | چرا |
| --- | --- | --- | --- |
| `src/goldbot/ports/ledger.py` | 184 | 89 | FIX-01 کدگذاری تزریقی + scope سخت‌گیرانه، FIX-02 سه اسکیم، FIX-05 در پروتکل |
| `src/goldbot/app/operation_ledger.py` | 108 | 48 | `record(legacy_hashes=…)`، نرمال‌سازی، `mark_submit_attempt`، سازنده‌های خالص |
| `src/goldbot/adapters/sqlite_operation_ledger.py` | 320 | 128 | اسکیمای v3، Adopt کردن کلید v1 **و** v2، مهاجرت سریال idempotent، بکاپ معتبرسنجی‌شده، RMW با `BEGIN IMMEDIATE` |
| `src/goldbot/app/order_coordinator.py` | 164 | 53 | ارسال `legacy_hashes`، `mark_submit_attempt`، تطبیق اقتصادی FIX-04 |
| `src/goldbot/adapters/mt5_broker.py` | 43 | 12 | FIX-03 (`None` + `last_error()`)، همین رفتار در `find_by_client_ref` |
| `src/goldbot/ports/execution.py` | 4 | 0 | `ClientRefQuery.retention_known` / `window_note` |
| `SOURCE-MANIFEST.txt` | — | — | بازسازی: **۲۹۹** رکورد |

### 6.2 افزوده‌شده

| فایل | محتوا |
| --- | --- |
| `tests/test_fix01_scope_identity.py` | ۲۰ تست |
| `tests/test_fix02_legacy_hash_migration.py` | ۱۳ تست |
| `tests/test_fix03_mt5_history_none.py` | ۱۳ تست |
| `tests/test_fix04_economic_matching.py` | ۲۲ تست |
| `tests/test_fix05_counter_semantics.py` | ۹ تست |
| `tests/test_fix06_migration_integrity.py` | ۵ تست |
| `docs/adr/020-ledger-identity-digests-and-counters.md` | تصمیم‌های هویت/هش/شمارنده به شکل ADR |

### 6.3 تست‌های موجود که دست خوردند

| فایل | تغییر | حکم |
| --- | --- | --- |
| `tests/test_operation_ledger_phase_a.py` | ۵ خط تغییر نام | فقط rename |
| `tests/test_phase_a_audit_scope.py` | ۳ خط (۱ داک‌استرینگ) | فقط rename |
| `tests/test_phase_a_audit_resolution.py` | ۱ خط | فقط rename |
| `tests/test_phase_a_audit_multiprocess.py` | ۵ تغییر نام + تنظیم timeout هارنس (بخش ۸) | rename + plumbing |
| `tests/test_phase_a_audit_fsm_and_live.py` | بازنویسی AU-36 (+54/−7) | **تقویت‌شده** |

هیچ assertion حذف نشد، هیچ تستی حذف/اسکیپ/xfail نشد و هیچ تلورانسی شل‌تر نشد.

### 6.4 دست‌نخوردهٔ عمدی

* `src/goldbot/domain/fsm/order.py` — بایت‌به‌بایت برابر مبنا؛ SHA-256:
  `bf4154c69d89b3fcfd30bd720a03bec939fee808418911be66b147d6f1774d0f`
* هیچ فایل استراتژی/اندیکاتور/پارامتر/ورود-خروج/مدل ریسک.
* هیچ فایل magic-number یا سیاست مالکیت موقعیت.
* هیچ فایل runtime/supervisor/deployment/VPS. (`runtime/live.py` نیازی به تغییر نداشت؛ دروازه از طریق `ensure_live_ready()` در هماهنگ‌کننده اعمال می‌شود.)

---

## 7. وضعیت تست‌ها و شواهد اجرا

### 7.1 محیط

```
Python 3.13.18 | pytest 9.0.3 | pydantic 2.14.3 | Linux 6.1.189+ x86_64
GOLDBOT_SOAK=0
بدون ترمینال MT5، بدون حساب بروکر، بدون شبکه
```

### 7.2 اجراها

| اجرا | نتیجه |
| --- | --- |
| مبنا (قبل از هر تغییری) | 1142 passed, 6 skipped, 3 warnings — 18.62s |
| نهایی (پس از شش اصلاح) | **1224 passed, 6 skipped, 3 warnings — 16.55s** |
| از نسخهٔ استخراج‌شدهٔ ZIP | **1224 passed, 6 skipped — 18.41s** |
| کنترل A3/A4 | 47 passed (0.54s) |
| کنترل A7 | ۶ اجرا × 2 passed |
| کنترل A8 | 31 passed (0.39s) |
| جمع‌آوری تست‌ها | 1230 collected |

### 7.3 اثبات جهش (Mutation) — تست‌ها به اصلاح گره خورده‌اند

هر اصلاح در یک کپی موقت برگردانده و ماژول مربوطه اجرا شد (کپی بعداً حذف شد):

| جهش (برگرداندن اصلاح) | ماژول | نتیجه |
| --- | --- | --- |
| `_encode` → همان `_clean` قدیمی | `test_fix01_scope_identity.py` | **5 failed**، 15 passed |
| غیرفعال‌کردن شاخهٔ `None` (رفتار `or ()`) | `test_fix03_mt5_history_none.py` | **1 failed**، 12 passed |
| `_economic_mismatch` همیشه `""` (فقط comment+magic) | `test_fix04_economic_matching.py` | **13 failed**، 9 passed |
| `legacy_payload_digests` → `()` | `test_fix02_legacy_hash_migration.py` | **8 failed**، 5 passed |

FIX-05 و FIX-06 با assertهای نام/شکل (`hasattr`، `integrity_check == "ok"`) و تست‌های کرش واقعی پوشش داده می‌شوند؛ برگرداندن آن‌ها باعث می‌شود ماژول اصلاً اجرا نشود، نه اینکه یک assertion شکست بخورد.

### 7.4 آنچه اجرا **نشد**

* ۴ تست لانچر PowerShell (`tests/test_live_launcher.py`) — روی Linux skip می‌شوند (اسکیپ از قبل موجود بود).
* ۲ تست soak (`tests/test_soak.py`) — با `GOLDBOT_SOAK=0` (اسکیپ از قبل موجود بود).
* هر چیزی که به ویندوز، ترمینال MT5 واقعی، حساب بروکر یا دو VPS نیاز دارد.

همهٔ این‌ها **NOT RUN** هستند، نه «passed».

---

## 8. تنها تغییر غیرتغییرنام در تست‌های ممیزی (افشا)

`tests/test_phase_a_audit_multiprocess.py`: **timeoutهای هارنس** بالا رفت — barrier از ۲۰ به ۶۰ ثانیه، انتظار نتیجه از ۱۰ به ۶۰ ثانیه، join از ۶۰ به ۱۲۰ ثانیه.

هیچ assertion، تلورانس یا گاردی تغییر نکرد. فایل همچنان تأیید می‌کند: دقیقاً یک claim، دقیقاً یک ارسال، یک ردیف، `claim_attempts == 1`، `submit_call_markers == 1`، تعداد رویداد `OperationClaimed` و `integrity_check == 'ok'`.

**دلیل (عیناً):** در جریان تأیید نهایی، یک اجرا در یک فرآیند فرزند `BrokenBarrierError` داد در حالی که ماشین زیر بار سنگین بود؛ همان فایل بعداً ۱۸ اجرای متوالی سبز بود، از جمله سه نمونه که عامدانه هم‌زمان اجرا شدند. خطا در plumbing شروع فرایند بود، نه در لجر. یک بازبین مستقل اگر مخالف باشد می‌تواند این سه عدد را برگرداند بدون اینکه هیچ ادعایی از این بسته تغییر کند.

---

## 9. مهاجرت اسکیما و سازگاری هش

### 9.1 قاعدهٔ سازگاری
`record(legacy_hashes=…)` — هماهنگ‌کننده همیشه `legacy_payload_digests(...)` را برای عملیات خودش پاس می‌دهد؛ لجر طبق جدول بخش ۳.۴ تصمیم می‌گیرد. نرمال‌سازی یک `UPDATE` شرطی تک‌ردیفی داخل `BEGIN IMMEDIATE` است (`WHERE op_id=? AND payload_hash=?`)، پس تغییر هم‌زمان را از بین نمی‌برد؛ اگر ردیف جابه‌جا شده باشد، عملیات دوباره خوانده می‌شود.

### 9.2 نکات عملیاتی مهاجرت (که با خطا یاد گرفته شد)
* **ترتیب:** ارتقای ستون‌ها باید **قبل** از اسکریپت اسکیما اجرا شود، چون `CREATE TABLE IF NOT EXISTS` جدول موجود را تغییر نمی‌دهد و ایندکس `idx_ledger_scope` به ستون‌های جدید ارجاع می‌دهد.
* **هم‌زمانی:** نسخه داخل `BEGIN IMMEDIATE` کوتاه خوانده و بازبینی می‌شود؛ فرایند بازنده هیچ تغییری نمی‌دهد. حالت پایدار هیچ قفلی نمی‌گیرد.
* **بکاپ:** با SQLite backup API (کپی بایتی از فایل WAL بکاپ نیست)، سپس `integrity_check` + برابری تعداد ردیف برای `events`، `trades`، `operation_ledger`؛ در صورت شکست، مهاجرت متوقف می‌شود. هش SHA-256 بکاپ در `migration_report()` ثبت و در تست بازبینی می‌شود.
* **DDL:** به‌صورت دستورات جداگانه (نه `executescript`) تا ردیف نسخه و اسکیما در یک تراکنش بنشینند.
* **rollback:** مهاجرت افزایشی است؛ بازگشت = بازگرداندن فایل بکاپ. یک DB نسخهٔ ۳ با بیلد قبلی خوانده نمی‌شود؛ این یک گام یک‌طرفه است و دقیقاً به همین دلیل بکاپ وجود دارد.
* **هیچ DB عملیاتی/تولیدی مهاجرت نشد.** DBهای v1/v2 در تست‌ها بازسازی وفادار اسکیمای قدیم با الگوریتم‌های قدیم‌اند، نه کپی داده‌های میدانی.

---

## 10. مسیرهای ورود/خروج حالت UNKNOWN

### 10.1 ورود به UNKNOWN

| مسیر | محرک | چه نوشته می‌شود |
| --- | --- | --- |
| `SubmitUncertain` حین فراخوانی | قطعی، timeout، retcode مبهم | `UNKNOWN` + `last_error`؛ marker قبلاً نوشته شده |
| هر استثنا حین فراخوانی | باگ، خطای انتقال | همان |
| پذیرش بدون اثبات اجرا | ack بدون ticket/volume/price | `UNKNOWN`، دلیل `accepted_without_fill` |
| ری‌استارت با وضعیت `SUBMITTING` | فرایند بعد از claim مرده | `recover_incomplete()` → `UNKNOWN`، دلیل `restart_before_confirmation` |
| درخواست تکراری روی ردیف `UNKNOWN` | تلاش مجدد فراخوان | همان `UNKNOWN`، `duplicate_requests += 1`، رویداد `resend: false` |

### 10.2 خروج از UNKNOWN
فقط `resolve_uncertain()` و فقط برای `ENTRY`:

| شاهد | حکم | گذار |
| --- | --- | --- |
| پرس‌وجوی کامل، بدون کاندید | absent | `RESOLVED_ABSENT` |
| پرس‌وجوی کامل، دقیقاً یک کاندید با تطبیق کامل اقتصادی | present | `ADOPTED` + ticket |
| کاندیدها موجود ولی هیچ‌کدام منطبق نیست | inconclusive | می‌ماند `UNKNOWN` |
| بیش از یک تطبیق | مبهم | می‌ماند `UNKNOWN` |
| پرس‌وجوی ناقص/خطا/`None` | inconclusive | می‌ماند `UNKNOWN` |
| پنجرهٔ پرس‌وجو قبل از ثبت عملیات شروع نشود | inconclusive | می‌ماند `UNKNOWN` |
| بروکر نتواند کامل‌بودن را گزارش کند | inconclusive | می‌ماند `UNKNOWN` |
| انواع غیر از ENTRY | پشتیبانی‌نشده | می‌ماند `UNKNOWN` (مالکیت: PHASE C) |

`RESOLVED_ABSENT` تنها حالتی است که ارسال مجدد را مجاز می‌کند و اکنون فقط از یک پاسخ **کامل** با **صفر** کاندید منطبق قابل دستیابی است.

### 10.3 قواعد FSM (کنترل A3)
* `APPROVED → EXPIRED` فقط برای عملیات claim‌نشده (`recover_incomplete`)، هرگز برای `UNKNOWN`.
* `claim_for_send` فقط `APPROVED` و `RETRYABLE` را می‌پذیرد (در SQL صریح).
* `SUBMITTING → UNKNOWN` در ری‌استارت؛ `UNKNOWN` دست‌نخورده می‌ماند.
* مهاجرت `state` را هرگز تغییر نمی‌دهد (برای هر سه حالت تست شده).

---

## 11. محدودیت‌های باقی‌مانده و آنچه اثبات نشده

| حوزه | وضعیت | چرا |
| --- | --- | --- |
| ترمینال MT5 واقعی | **NOT RUN** | هیچ ترمینال/حساب/اتصالی نبود؛ آداپتر فقط با ماژول Fake آزموده شد |
| کامل‌بودن تاریخچهٔ MT5 | **NOT ESTABLISHED** | رفتار `None` صادقانه گزارش می‌شود، اما اینکه ترمینال واقعی همهٔ تاریخچهٔ مرتبط را بدهد قابل اثبات در این مجموعه نیست؛ `retention_known=False` عمدی است |
| ارسال سفارش واقعی / دمو | **NOT RUN** | ممنوعیت مأموریت |
| ویندوز / PowerShell | **NOT RUN** | ۴ تست لانچر روی Linux اسکیپ |
| Session 0/1 | **NOT RUN** | نیازمند ویندوز |
| Soak | **NOT RUN** | ۲ تست soak با `GOLDBOT_SOAK=0` اسکیپ؛ soak زمان‌دار pass نیست |
| Cross-VPS / fencing | خارج از دامنه | هیچ ادعایی نیست؛ A7 فقط تک‌هاست است |
| مالکیت موقعیت/استقرار | خارج از دامنه | magic و سیاست مالکیت تغییر نکرد |
| حل‌وفصل غیر ENTRY | باز | CLOSE/PARTIAL/MODIFY/CANCEL/FLATTEN شاهد مثبت عدم‌وجود ندارند؛ مالک: PHASE C |
| DB عملیاتی | مهاجرت نشد | فقط DBهای بازسازی‌شده در تست |

---

## 12. دارایی‌ها: ZIPها، هش‌ها، مسیرها، دستور بازتولید

### 12.1 ZIPهای این مسیر کاری

| فایل | SHA-256 | نقش |
| --- | --- | --- |
| `GoldBot_v8.2.5_PHASE_A_2026-11-25.zip` | `58e76cda…50d504` | خروجی PHASE A |
| `GoldBot_v8.2.5_PHASE_A_AUDIT_2026-11-25.zip` | `1d6c326b…db1b7` | مجموعهٔ اصلاحات A1…A8 |
| `GoldBot_v8.2.5_PHASE_A_AUDIT_PACKAGE_2026-11-25.zip` | `fcca706e2476116ef10272b66a31093a83cb5be48598d64dd9a81ec9539954d1` | **بستهٔ پایهٔ** این اصلاح |
| **`GoldBot_v8.2.5_PHASE_A_TARGETED_REMEDIATION_2026-11-25.zip`** | **`937517037894c99916e6b30d4b5ff3a63530e9bf9931f3b10616384f52d1758d`** | **تحویل نهایی این چت** |

مسیر فایل نهایی:

```
/home/user/iteration02/04_TARGETED_DELIVERY/GoldBot_v8.2.5_PHASE_A_TARGETED_REMEDIATION_2026-11-25.zip
```

محتوای بستهٔ نهایی: ۳۱۷ فایل (۳۱۶ فایل هش‌شده در `SHA256SUMS.txt` + خود فایل هش‌ها)، حجم ۹۴۲KB، `SOURCE-MANIFEST.txt` با ۲۹۹ رکورد، ۳۴ گزارش/لاگ/داکیومنت.

### 12.2 ساختار بستهٔ نهایی

```
GoldBot_v8.2.5_PHASE_A_TARGETED_REMEDIATION_2026-11-25/
├── README-DELIVERY.md
├── SHA256SUMS.txt
├── GoldBot_Source_v8.2.5/            ← سورس اصلاح‌شده (299-entry manifest)
└── REPORTS/
    ├── TARGETED_REMEDIATION_REPORT.md      ← گزارش اصلی + پاسخ ۱۵ پرسش
    ├── FIX_MATRIX_FIX-01_06.md            ← حکم و شاهد هر FIX
    ├── SOURCE_DIFF_REPORT.md              ← فایل‌های تغییر‌یافته + اثبات mutation
    ├── SOURCE_DIFF_FULL.diff              ← diff کامل (۲۱۱۶ خط)
    ├── MIGRATION_AND_HASH_COMPATIBILITY.md
    ├── RECOVERY_AND_UNKNOWN.md
    ├── REGRESSION_A3_A4_A7_A8.md
    ├── REMAINING_LIMITS.md
    ├── REPRODUCTION.md
    └── TEST_LOGS/
        ├── BASELINE_full_suite.log        ← 1142 passed, 6 skipped
        ├── FINAL_full_suite.log           ← 1224 passed, 6 skipped
        ├── FINAL_extracted_copy.log       ← اجرا از نسخهٔ استخراج‌شده
        ├── REGRESSION_A3_A4.log           ← 47 passed
        ├── REGRESSION_A7.log              ← ۶ اجرا × 2 passed
        └── REGRESSION_A8.log              ← 31 passed
```

### 12.3 دستور بازتولید

```bash
# 1) صحت آرشیو
sha256sum GoldBot_v8.2.5_PHASE_A_TARGETED_REMEDIATION_2026-11-25.zip
#    انتظار: 937517037894c99916e6b30d4b5ff3a63530e9bf9931f3b10616384f52d1758d
cd GoldBot_v8.2.5_PHASE_A_TARGETED_REMEDIATION_2026-11-25
sha256sum -c SHA256SUMS.txt          # 316/316 OK

# 2) صحت سورس
cd GoldBot_Source_v8.2.5
python3 - <<'PY'
import hashlib, pathlib
lines = pathlib.Path("SOURCE-MANIFEST.txt").read_text().splitlines()
bad = [n for d, n in (l.split("  ", 1) for l in lines[4:])
       if not pathlib.Path(n).exists()
       or hashlib.sha256(pathlib.Path(n).read_bytes()).hexdigest().upper() != d]
print(lines[3], "| problems:", len(bad))
PY
#    انتظار: files: 299 | problems: 0

# 2.5) محیط (بین دورها حفظ نمی‌شود؛ ابتدا نصب کن)
python3 -m pip install "pydantic>=2.7,<3" "fastapi>=0.110,<1" "uvicorn>=0.29,<1"

# 3) مجموعهٔ کامل تست
GOLDBOT_SOAK=0 python3 -m pytest -q -p no:cacheprovider
#    انتظار: 1224 passed, 6 skipped, 3 warnings

# 4) هر FIX جداگانه
GOLDBOT_SOAK=0 python3 -m pytest -q tests/test_fix01_scope_identity.py        # 20
GOLDBOT_SOAK=0 python3 -m pytest -q tests/test_fix02_legacy_hash_migration.py # 13
GOLDBOT_SOAK=0 python3 -m pytest -q tests/test_fix03_mt5_history_none.py      # 13
GOLDBOT_SOAK=0 python3 -m pytest -q tests/test_fix04_economic_matching.py     # 22
GOLDBOT_SOAK=0 python3 -m pytest -q tests/test_fix05_counter_semantics.py     #  9
GOLDBOT_SOAK=0 python3 -m pytest -q tests/test_fix06_migration_integrity.py   #  5

# 5) کنترل‌ها
GOLDBOT_SOAK=0 python3 -m pytest -q tests/test_phase_a_audit_fsm_and_live.py \
  tests/test_operation_ledger_phase_a.py \
  tests/test_fix02_legacy_hash_migration.py tests/test_fix06_migration_integrity.py   # 47
GOLDBOT_SOAK=0 python3 -m pytest -q tests/test_phase_a_audit_multiprocess.py          # 2
GOLDBOT_SOAK=0 python3 -m pytest -q tests/test_live_bootstrap.py tests/test_live_cleanup.py \
  tests/test_live_instance_lock.py tests/test_fix01_scope_identity.py                 # 31
```

### 12.4 پوشه‌های کاری در فضای فعلی

| مسیر | محتوا | وضعیت |
| --- | --- | --- |
| `/home/user/iteration02/00_BASELINE_ITERATION_01/` | سورس دست‌نخوردهٔ Iteration 01 | **ویرایش نشود** |
| `/home/user/iteration02/01_WORKING_COPY/` | سورس PHASE A تحویل‌شده | مرجع قدیمی |
| `/home/user/iteration02/02_AUDIT_WORKING_COPY/audited/` | درخت A1…A8 | **تاریخی**، منسوخ |
| `/home/user/iteration02/03_TARGETED_WORKING_COPY/` | کپی کاری این اصلاح (`SRC/` + بستهٔ استخراج‌شده) | فعال/مرجع |
| `/home/user/iteration02/04_TARGETED_DELIVERY/` | بستهٔ نهایی + `FINAL_ZIP_SHA256.txt` | **تحویل** |
| `/home/user/iteration02/06_EXTRACT_VERIFY/` | استخراج موقت برای تأیید | scratch |
| گزارش‌های قدیمی در `/home/user/iteration02/*.md` و `*.log` | PHASE A / A1…A8 | مرجع تاریخی |

### 12.5 وضعیت فضای کاری و نکات محیطی (مهم برای چت جدید)

* فضای کاری از ۱۸۲MB به **۳۰MB** کاهش یافت. منبع مصرف، `var/tests` (scratch تست) بود که داخل هیچ مانیفست/هشی نیست.
* **یک هشدار واقعی و درس‌گرفته:** در پایان دور قبل، فضای کاری از سقف snapshot (حدود ۱۲۸MB) گذشته بود و بخشی از فایل‌های استخراج‌شده (مثل `tests/` و `reports/` در بسته و چند فایل تست در کپی کاری) در snapshot بعدی حاضر نبود. **تنها مرجع سالم و هش‌تأییدشده، همان فایل ZIP است** (اجرای `unzip -t` بدون خطا). در این دور، درخت‌ها از ZIP بازسازی شدند و مجموعهٔ تست دوباره **1224 passed** داد.
  * درس: بستهٔ نهایی را همیشه به‌عنوان ZIP نگه دار؛ اگر درخت استخراج‌شده ناقص دیده شد، آن را از ZIP بازسازی کن و **قبل از هر ادعا** هش‌ها را بررسی کن.
* **محیط اجرا پایدار نیست:** بسته‌های نصب‌شدهٔ pip بین دورها حفظ نمی‌شوند. در چت جدید پیش از اجرای تست، محیط را بازسازی کن:

```bash
python3 -m pip install "pydantic>=2.7,<3" "fastapi>=0.110,<1" "uvicorn>=0.29,<1"
python3 -m pytest --version
```

  (بدون `fastapi`، دو ماژول `tests/test_web.py` و `tests/test_web_auth.py` در مرحلهٔ collection خطا می‌دهند و کل اجرا Interrupt می‌شود — این خطا مربوط به بات نیست، مربوط به محیط است.)
* برای دسترسی راحت، یک نسخه از ZIP نهایی در ریشهٔ فضای کاری هم قرار دارد:
  `/home/user/GoldBot_v8.2.5_PHASE_A_TARGETED_REMEDIATION_2026-11-25.zip`
  (همان هش `9375170378…52d1758d`؛ نسخهٔ رسمی همان مسیر `04_TARGETED_DELIVERY` است).

---

## 13. قواعد الزامی برای چت جدید (چه باید/نباید بشود)

### 13.1 قواعد کاری که کاربر تعیین کرده و همچنان معتبرند
* **هرگز بستهٔ مرجع را در جا تغییر نده**؛ استخراج کن، هش بگیر، تأیید کن، بعد کپی کاری مستقل بساز.
* **تغییر واقعی سورس + تست اجراشده** بده؛ گزارشِ صرفِ ادعا ممنوع است.
* ادعاهای ابزار دیگر (DeepSeek Harness) پذیرفته نیست: diff، سورس، تست و رفتار را خودت بازبینی و اجرا کن.
* نقص جدید = **Finding** مستند و **قبل از** هر بازطراحی گسترده، مجوز بگیر.
* **حذف/ضعیف‌کردن/اسکیپ/xfail کردن تست‌های موجود ممنوع.** Skip ≠ PASS؛ timeout ⇒ `NOT VERIFIED`.
* **زبان مرجع مأموریت فارسی است**؛ واژگان وضعیت گزارش‌ها عیناً انگلیسی.
* گزارش پایان کار باید با **دقیقاً یکی** از سه خط وضعیت مجاز تمام شود و به **هر ۱۵ پرسش** پاسخ دهد.
* تحویل به‌صورت **ZIP**.
* دست‌نزدن به `/home/user/V4_REASSESSMENT_OUTPUT/`، `/home/user/V4_READINESS_*.md` و `00_BASELINE_ITERATION_01`.

### 13.2 خارج از دامنه (بدون مجوز جداگانه ممنوع)
PHASE B، PHASE C، Cross-VPS fencing، تغییر معماری مالکیت، تغییر استراتژی/اندیکاتور/پارامتر/ورود-خروج/مدل ریسک، تغییر سیاست magic-number یا مالکیت موقعیت، بازنویسی گستردهٔ coordinator/reconciler، استفاده از InMemory ledger در Live، اتصال واقعی به بروکر، سفارش واقعی، مهاجرت DB عملیاتی، تغییر VPS/تسک زمان‌بندی‌شده.

### 13.3 گام‌های منطقی بعدی (پیشنهادی، نیازمند تصمیم مالک)
1. **تأیید مستقل** همین بسته: هش‌ها، diff، اجرای تست، و بازبینی `FIX_MATRIX` و `MIGRATION_AND_HASH_COMPATIBILITY`.
2. **تصمیم دربارهٔ PHASE C** (حل‌وفصل CLOSE/PARTIAL/MODIFY/CANCEL/FLATTEN) و مدل مالکیت موقعیت — این‌ها صریحاً خارج از دامنهٔ فعلی بوده‌اند.
3. **برنامهٔ اعتبارسنجی MT5 Demo** در محیط کنترل‌شده (ویندوز + ترمینال واقعی): `None`، تاریخچهٔ ناقص، پنجرهٔ نگه‌داری، تطبیق اقتصادی روی دادهٔ واقعی. تا آن زمان MT5 = **NOT VERIFIED**.
4. **تصمیم دربارهٔ Cross-VPS** (fencing یا عدم آن) و سیاست انتقال fail-closed.
5. **Soak** زمان‌دار در محیط هدف.

---

## 14. قالب گزارش پایان کار (برای استفادهٔ مجدد در چت جدید)

### 14.1 سه خط وضعیت مجاز — فقط یکی در پایان

```
TARGETED REMEDIATION COMPLETE — PENDING INDEPENDENT VERIFICATION
TARGETED REMEDIATION PARTIALLY COMPLETE — BLOCKERS REMAIN
TARGETED REMEDIATION BLOCKED — DESIGN DECISION REQUIRED
```

### 14.2 پانزده پرسش اجباری (پاسخ‌های این دور در پرانتز)
1. کدام FIXها واقعاً اصلاح شدند؟ (هر شش؛ هر کدام با ماژول تست اختصاصی)
2. کدام فایل‌ها تغییر کردند؟ (۶ سورس + ۵ تست + مانیفست)
3. کدام فایل‌ها اضافه شدند؟ (۶ ماژول تست + ADR-020)
4. آیا مهاجرت واقعی از نسخهٔ قبل تست شد؟ (بله: DBهای واقعی v1/v2 با هش‌های واقعی)
5. آیا هش قدیم و جدید در تست واقعی مقایسه شد؟ (بله؛ هر دو Pin و مستقل بازمحاسبه)
6. آیا `None` تاریخچهٔ MT5 تست شد؟ (بله؛ ۱۳ تست؛ واقعیت MT5 همچنان NOT VERIFIED)
7. آیا تطبیق ENTRY فیلدهای اقتصادی را می‌بیند؟ (بله: symbol/side/volume/magic/ref/state/SL/TP/زمان)
8. آیا شمارنده‌های InMemory و SQLite یکسان‌اند؟ (بله: `(1,2,1)` و همان state)
9. آیا همهٔ مسیرهای Live از دروازه می‌گذرند؟ (بله: `ensure_live_ready()` + AU-29…AU-33)
10. آیا تستی حذف/اسکیپ/ضعیف شد؟ (خیر؛ ۶ اسکیپ همان قبلی‌هاست)
11. نتیجهٔ واقعی مجموعهٔ کامل تست؟ (1224 passed, 6 skipped)
12. کدام تست‌ها اجرا نشدند؟ (۴ لانچر PowerShell، ۲ soak، و هر چیز وابسته به ویندوز/MT5/دو VPS)
13. محدودیت‌های باقی‌مانده؟ (`REMAINING_LIMITS.md` / بخش ۱۱ همین سند)
14. هش نهایی ZIP؟ (`9375170378…52d1758d`)
15. مسیر و نام دقیق فایل نهایی؟ (`/home/user/iteration02/04_TARGETED_DELIVERY/GoldBot_v8.2.5_PHASE_A_TARGETED_REMEDIATION_2026-11-25.zip`)

---

## 15. واژه‌نامه و پیوست

| اصطلاح | معنا |
| --- | --- |
| **Operation** | یک اقدام معاملاتی با هویت پایدار و اسکوپ‌شده |
| **Scope** | `(account_login, server, deployment_id)` — کاملاً بسته یا کاملاً باز |
| **Adoption** | بازنویسی کلید قدیمی یک ردیف روی کلید جدید بدون ساخت ردیف دوم |
| **Normalisation** | بازنویسی هش قدیمی موجود به اسکیم جاری وقتی محمولهٔ اقتصادی یکسان است |
| **claim / CAS** | `APPROVED`/`RETRYABLE → SUBMITTING` با یک UPDATE اتمیک؛ پیش از هر فراخوانی venue |
| **submit_call_markers** | نشانهٔ نوشته‌شده بلافاصله قبل از فراخوانی؛ اثبات intent، نه delivery |
| **RESOLVED_ABSENT** | «در پنجرهٔ تأییدشده نبود» — هرگز «هرگز وجود نداشت» |
| **UNKNOWN** | نمی‌دانیم venue سفارش را دارد یا نه؛ خروج فقط با شاهد مثبت |
| **Mutation check** | برگرداندن یک اصلاح در کپی موقت و نشان‌دادن اینکه تست مربوطه قرمز می‌شود |
| **Harness timeout** | سقف زمانی plumbing تست (barrier/join/result wait)، نه یک assertion ایمنی |

### 15.1 فایل‌های کلیدی برای ادامهٔ کار

```
src/goldbot/ports/ledger.py                      ← هویت، حافظهٔ هش، پروتکل
src/goldbot/app/operation_ledger.py              ← قواعد گذار و سازنده‌های خالص
src/goldbot/adapters/sqlite_operation_ledger.py  ← اسکیمای v3، مهاجرت، CAS، RMW اتمیک
src/goldbot/app/order_coordinator.py             ← اجرای سفارش، شواهد client_ref، تطبیق اقتصادی
src/goldbot/adapters/mt5_broker.py               ← آداپتور MT5 (FIX-03)
src/goldbot/ports/execution.py                   ← مدل ClientRefQuery
docs/adr/020-ledger-identity-digests-and-counters.md  ← تصمیم‌های ثبت‌شده
tests/test_fix0{1..6}_*.py                       ← شواهد هر اصلاح
REPORTS/TARGETED_REMEDIATION_REPORT.md           ← گزارش اصلی + پاسخ ۱۵ پرسش
```

### 15.2 کاری که در چت جدید باید اول انجام شود
1. ZIP نهایی را آپلود/استخراج کن و **هش** آن را با `9375170378…52d1758d` مقایسه کن.
2. `sha256sum -c SHA256SUMS.txt` و بررسی `SOURCE-MANIFEST.txt` (۲۹۹ رکورد).
3. `GOLDBOT_SOAK=0 python3 -m pytest -q` → انتظار **1224 passed, 6 skipped**.
4. اگر همه سبز بود، سراغ تصمیم‌های بخش ۱۳.۳ برو؛ اگر نه، **هیچ ادعایی نکن** و ابتدا انحراف را توضیح بده.

---

**پایان سند.**
