# Test Report — GoldBot 8.2.5 Final Engineering Release

**Date:** 2026-11-21 · **Host:** Windows 11, Python 3.14.7 · **Tree:** committed release tree
**Command:** `python -m pytest -q -p no:cacheprovider -p no:warnings`

## نتیجهٔ اجرای واقعی

| معیار | مقدار |
|---|---|
| تعداد تست | **1,084** |
| PASS | **1,084** |
| FAIL | **0** |
| ERROR | **0** |
| زمان | **127.98 s** |
| خروجی | exit code 0 |
| تعداد فایل تست | 77 |

> این عدد نتیجهٔ اجرای واقعی روی درخت تحویلی است. ادعای ۵۶ تست نسخهٔ RC فقط همان مجموعهٔ بازسازی‌شده بود و در اینجا با مجموعهٔ کامل تاریخی (از جمله golden, chaos, parity, property, failure-injection و soak) جایگزین شده است.

## دامنهٔ پوشش

| دسته | نمونه فایل‌ها |
|---|---|
| Unit — تصمیم/تأیید/Tier | test_decision, test_confirmations_new, test_tier_confirmation, test_tier_system, test_arbiter, test_confluence, test_arbiter_confirmation_identity |
| Unit — ریسک/سرمایه | test_capital, test_capital_levels, test_risk_engine, test_profiles, test_open_risk_truth, test_sizing, test_budget |
| Unit — اجرا/FSM | test_execution, test_position_fsm, test_close_idempotency, test_retry_reseal, test_mt5_broker, test_spec_guard, test_retcodes |
| Integration | test_end_to_end, test_engine_signal_journal, test_signal_journal, test_walk_forward, test_parity_tapes |
| Golden / parity | test_parity_tapes, test_excel_signals, test_zones_xlsx |
| Recovery | test_state_recovery, test_position_adoption, test_live_cleanup, test_live_bootstrap, test_chaos |
| Failure injection | test_failure_injection_execution, test_failure_injection_persistence |
| Soak/performance | test_soak |
| Config/panel/security | test_config_profiles, test_config_hash, test_config_consistency, test_web, test_web_auth, test_live_launcher, test_deploy_vps, test_release_metadata |

## تست‌هایی که در نسخهٔ RC شکست خورده بودند

| تست | علت | تصمیم |
|---|---|---|
| test_capital::test_gate_d_remaining_budget_shrinks_the_trade | پیش‌فرض Gate D از ۲٪ به ۳٪ منحرف شده بود | باگ کد؛ پیش‌فرض به ۲٪ برگشت (ADR-001) |
| test_confluence::test_confluence_filter_helper | API بازنشستهٔ confluence_ok | تست به قرارداد جدید بازنویسی شد |
| test_confluence::test_dynamic_rr_applies_only_when_confirmed | API بازنشستهٔ apply_confirmation_rr | تست بازنویسی شد |
| test_v2_layers::test_weak_confluence_defaults_to_reject | کلید بازنشستهٔ weak_confluence_mode | تست به «رد شدن قطعی کلید» تغییر کرد |
| test_web::test_min_confirmations_can_be_saved | کلید بازنشسته + نیمه‌مهاجرت پنل | پنل ۴۰۰ می‌دهد؛ تست بازنویسی شد |

## محدودیت‌های آزمون

- تست‌های MT5 با fake terminal اجرا می‌شوند؛ رفتار واقعی بروکر فقط در نشست دمو اندازه‌گیری می‌شود (بخش Live در `reports/live_demo_validation.md`).
- تست‌های soak به‌صورت پیش‌فرض فعال‌اند اما زمان‌بر هستند؛ با `GOLDBOT_SOAK=0` رد می‌شوند.
- اعداد بک‌تست، شاهد سودآوری نیستند.

## نتیجه‌گیری

**PASS** برای گیت تست نرم‌افزاری: ۱٬۰۶۷ تست بدون خطا اجرا شد. این وضعیت فقط برای «DEMO VALIDATION» کافی است، نه برای معاملهٔ پول واقعی.
