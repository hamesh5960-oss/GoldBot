# GoldBot — launcher for a live MetaTrader 5 session (demo account by default).
# Credentials must be injected through the process environment; never store them in the repo.
#   GOLDBOT_MT5_LOGIN, GOLDBOT_MT5_PASSWORD, GOLDBOT_MT5_SERVER,
#   GOLDBOT_MT5_PATH, GOLDBOT_MT5_SYMBOL.
# The password is NEVER accepted on the command line (argv is visible in Task
# Scheduler and Win32_Process): set GOLDBOT_MT5_PASSWORD, or point
# GOLDBOT_MT5_PASSWORD_FILE at an operator-only file containing only the password.
# Native commands write warnings to stderr; under "Stop" PowerShell 5.1 turns
# those into terminating errors and kills a perfectly healthy session.
$ErrorActionPreference = "Continue"
$repo = Split-Path -Parent $PSScriptRoot
Set-Location $repo

# --- single-instance lock -------------------------------------------------
# A process-name check alone is check-then-act: two scheduled fires (or a
# manual launch while the task starts) could both pass it and start two live
# sessions on one account. Hold an exclusive OS handle on var/live.lock for
# the whole session instead; Windows releases it if this process dies.
$lockPath = $env:GOLDBOT_LIVE_LOCK
if (-not $lockPath) { $lockPath = Join-Path $repo "var/live.lock" }
$lockDir = Split-Path -Parent $lockPath
if ($lockDir -and -not (Test-Path -LiteralPath $lockDir)) {
    New-Item -ItemType Directory -Force -Path $lockDir | Out-Null
}
$liveLock = $null
try {
    $liveLock = [System.IO.File]::Open(
        $lockPath,
        [System.IO.FileMode]::OpenOrCreate,
        [System.IO.FileAccess]::ReadWrite,
        [System.IO.FileShare]::None
    )
} catch [System.IO.IOException] {
    Write-Output "GoldBot live already running (lock $lockPath is held by another launcher)."
    exit 3
} catch [System.UnauthorizedAccessException] {
    Write-Output "GoldBot live already running (lock $lockPath is not writable by this account)."
    exit 3
}

# Test hook (tests/test_live_launcher.py): prove the lock is exclusive and
# bounded, without credentials, state checks or a real MT5 session.
if ($env:GOLDBOT_LAUNCHER_SELFTEST -eq "lock") {
    $holdSeconds = 0
    if ($env:GOLDBOT_LAUNCHER_SELFTEST_HOLD) {
        try { $holdSeconds = [int]$env:GOLDBOT_LAUNCHER_SELFTEST_HOLD } catch { $holdSeconds = 0 }
    }
    Write-Output "lock acquired: $lockPath"
    if ($holdSeconds -gt 0) { Start-Sleep -Seconds $holdSeconds }
    exit 0
}

# Refuse the unsafe password habit before doing anything else: argv leaks into
# Task Scheduler history, Win32_Process and crash dumps.
foreach ($arg in $args) {
    if ($arg -eq "--password" -or $arg -like "--password=*") {
        Write-Error "MT5 password must not be passed on the command line; use GOLDBOT_MT5_PASSWORD or GOLDBOT_MT5_PASSWORD_FILE."
        exit 2
    }
}

# Secondary guard for sessions started directly (bypassing this script):
# python run_goldbot.py live, python -m goldbot live and the installed
# goldbot console script. The lock above cannot see those processes.
$livePatterns = @('*run_goldbot.py live*', '*-m goldbot live*', '*goldbot.exe* live*')
$liveProcesses = @(Get-CimInstance Win32_Process -Filter "Name='python.exe' OR Name='pythonw.exe' OR Name='goldbot.exe'" -ErrorAction SilentlyContinue | Where-Object {
    $commandLine = [string]$_.CommandLine
    $hit = $false
    foreach ($pattern in $livePatterns) {
        if ($commandLine -like $pattern) { $hit = $true; break }
    }
    $hit
})
if ($liveProcesses.Count -gt 0) {
    Write-Output "GoldBot live already running (pid $($liveProcesses[0].ProcessId))."
    exit 3
}

# --- credentials and environment -----------------------------------------
if (-not $env:GOLDBOT_MT5_PASSWORD -and $env:GOLDBOT_MT5_PASSWORD_FILE) {
    $passwordFile = $env:GOLDBOT_MT5_PASSWORD_FILE
    if (-not (Test-Path -LiteralPath $passwordFile)) {
        Write-Error "GOLDBOT_MT5_PASSWORD_FILE does not exist: $passwordFile"
        exit 2
    }
    $env:GOLDBOT_MT5_PASSWORD = (Get-Content -LiteralPath $passwordFile -Raw).Trim()
}
$env:PYTHONIOENCODING = "utf-8"
$env:PYTHONUNBUFFERED = "1"
# In-process structured logging: goldbot/log.py reads these and rotates the file
# (5 MiB x 5 backups) so a long live session cannot fill the disk.
if (-not $env:GOLDBOT_LOG_PATH) { $env:GOLDBOT_LOG_PATH = Join-Path $repo "var/live.jsonl" }
if (-not $env:GOLDBOT_LOG_MAX_BYTES) { $env:GOLDBOT_LOG_MAX_BYTES = "5242880" }
if (-not $env:GOLDBOT_LOG_BACKUPS) { $env:GOLDBOT_LOG_BACKUPS = "5" }

if (-not $env:GOLDBOT_MT5_PATH) { $env:GOLDBOT_MT5_PATH = "C:\Program Files\ePlanet MetaTrader 5 Terminal\terminal64.exe" }
if (-not $env:GOLDBOT_MT5_LOGIN) { $env:GOLDBOT_MT5_LOGIN = Read-Host "MT5 demo login" }
if (-not $env:GOLDBOT_MT5_SERVER) { $env:GOLDBOT_MT5_SERVER = "ePlanet-MT5" }
if (-not $env:GOLDBOT_MT5_SYMBOL) { $env:GOLDBOT_MT5_SYMBOL = "XAUUSD.st" }
if (-not $env:GOLDBOT_MT5_PASSWORD) {
    Write-Error "GOLDBOT_MT5_PASSWORD is not set in the process environment (or provide GOLDBOT_MT5_PASSWORD_FILE)."
    exit 2
}

# A missing durable state is never silently treated as a fresh account.
# First run only: operator must pass --cold-start explicitly and confirm no
# open positions exist in MT5. Normal restarts must omit --cold-start.
$journalDb = "var/live.db"
$explicitStateDb = $env:GOLDBOT_STATE_DB
for ($i = 0; $i -lt $args.Count; $i++) {
    if ($args[$i] -eq "--db" -and ($i + 1) -lt $args.Count) { $journalDb = $args[$i + 1] }
    elseif ($args[$i] -like "--db=*") { $journalDb = $args[$i].Substring(5) }
    elseif ($args[$i] -eq "--state-db" -and ($i + 1) -lt $args.Count) { $explicitStateDb = $args[$i + 1] }
    elseif ($args[$i] -like "--state-db=*") { $explicitStateDb = $args[$i].Substring(12) }
}
if ($explicitStateDb) {
    $stateDb = $explicitStateDb
} else {
    $journalDir = [System.IO.Path]::GetDirectoryName($journalDb)
    $journalStem = [System.IO.Path]::GetFileNameWithoutExtension($journalDb)
    $stateName = if ($journalStem -eq "goldbot") { "risk_state.db" } else { "${journalStem}_risk_state.db" }
    $stateDb = if ($journalDir) { Join-Path $journalDir $stateName } else { $stateName }
}
$hasColdStart = [Array]::IndexOf($args, "--cold-start") -ge 0
if ($hasColdStart) {
    if (Test-Path $stateDb) {
        Write-Error "Risk state already exists at $stateDb; remove --cold-start for a normal restart."
        exit 2
    }
    $confirmation = Read-Host "Confirm MT5 has NO open positions by typing NO-OPEN-POSITIONS"
    if ($confirmation -cne "NO-OPEN-POSITIONS") {
        Write-Error "Cold start cancelled; no order session was started."
        exit 2
    }
} elseif (-not (Test-Path $stateDb)) {
    Write-Error "Risk state is missing. Do not auto-initialize. Verify MT5 positions and explicitly pass --cold-start only for a genuinely fresh account."
    exit 2
}

python run_goldbot.py live --profile medium --db var/live.db @args
exit $LASTEXITCODE
