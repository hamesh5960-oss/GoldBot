# Scheduled-task wrapper: run the live session and append its console to
# var/live.log with bounded size-based rotation (keep-N backups). Without this,
# a long-running scheduled task grows the log until the disk is full and the
# next write fails closed.
$repo = Split-Path -Parent $PSScriptRoot
$log = Join-Path $repo "var/live.log"
$maxBytes = 5242880
$keep = 5

function Rotate-LiveLog {
    param([string]$Path, [long]$MaxBytes, [int]$Keep)
    if ($MaxBytes -le 0 -or $Keep -lt 1) { return }
    if (-not (Test-Path -LiteralPath $Path)) { return }
    $size = (Get-Item -LiteralPath $Path).Length
    if ($size -le $MaxBytes) { return }
    for ($index = $Keep - 1; $index -ge 1; $index--) {
        $older = $Path + "." + $index
        $newer = $Path + "." + ($index + 1)
        if (Test-Path -LiteralPath $older) {
            Move-Item -LiteralPath $older -Destination $newer -Force
        }
    }
    Move-Item -LiteralPath $Path -Destination ($Path + ".1") -Force
}

# Test hook (tests/test_live_launcher.py): rotate a supplied file and exit
# without touching MT5, so the rotation logic is covered by the suite.
if ($env:GOLDBOT_LOG_ROTATE_SELFTEST) {
    $testMax = 1024
    if ($env:GOLDBOT_LOG_ROTATE_MAX_BYTES) {
        try { $testMax = [long]$env:GOLDBOT_LOG_ROTATE_MAX_BYTES } catch { $testMax = 1024 }
    }
    $testKeep = 2
    if ($env:GOLDBOT_LOG_ROTATE_KEEP) {
        try { $testKeep = [int]$env:GOLDBOT_LOG_ROTATE_KEEP } catch { $testKeep = 2 }
    }
    Rotate-LiveLog -Path $env:GOLDBOT_LOG_ROTATE_SELFTEST -MaxBytes $testMax -Keep $testKeep
    Write-Output "rotated: $($env:GOLDBOT_LOG_ROTATE_SELFTEST)"
    exit 0
}

Rotate-LiveLog -Path $log -MaxBytes $maxBytes -Keep $keep

# Decode the console as UTF-8 so the Persian banner stays readable in the log.
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.Encoding]::UTF8
& (Join-Path $PSScriptRoot "start_live.ps1") --db var/live.db *>&1 |
    Out-File -FilePath $log -Append -Encoding utf8
exit $LASTEXITCODE
