# Changelog — GoldBot 8.2.5 Engineering RC

## RC 8.2.5

### Core logic and safety
- Corrected cross-strategy confirmation identity: strategy IDs are compared with strategy IDs, never slot IDs.
- Preserved `last_exec_bar=0` during Gate A state restoration.
- Added MT5 disconnect cleanup for setup failures and normal live-session shutdown.
- Refused cold-start when a state database already exists; cold-start now also requires no open broker positions or orders.
- Removed retired `min_confirmations`, `weak_confluence_mode`, `dynamic_tier_margin`, and obsolete composite scoring controls from active configuration, CLI and panel.
- Synchronized Gate D default hard limit at 3.0% and updated panel risk/volume explanations.

### Deployment and packaging
- Added `run_goldbot.py`, `python -m goldbot`, `pyproject.toml`, optional dependency groups and pytest configuration.
- Fixed duplicate SSH connection attempt in VPS deployment.
- Require trusted SSH host keys, shell-quote panel token writes, and redact token-bearing commands/errors from deployment logs.
- Updated VPS preflight Python requirement to 3.12+ and pinned compatible dependency ranges.
- Archived obsolete research scripts that depended on the retired confirmation threshold.

### Validation
- Reconstructed automated test suite; current snapshot: 56 tests expected to pass.
- Added architecture, live cleanup/cold-start, deployment and release metadata tests.
- Added explicit validation report; live MT5 and 100-day performance tests remain incomplete.


## FINAL 8.2.5 — engineering release (2026-11-21)

### Safety-critical fixes (P0)
- **Idempotent close on the real MT5 adapter:** per-intent ledger (key+ticket+volume), venue truth read before and after the send, acked-with-lagging-history settles once instead of retrying, an uncertain close is never re-sent.
- **Flatten never claims flat:** every close result is classified; bounded retries, `FlattenFailed` journal event, HALTED latch, pending flatten retried on later bars; `FlattenCompleted` only when the book is empty.
- **Restart position adoption:** on start the engine adopts venue positions into the position book (hedging), attaches a close-only policy with broker SL/TP preserved, journals `PositionAdopted`, re-reconciles and keeps entries blocked until clean; netting fails closed.
- PLACED is not a fill; limit orders are reconciled or cancelled; lagging close deals keep the ticket tracked; TIMEOUT is uncertain, not a clean reject; terminal POSITION_CLOSED/10036 settle instead of looping.

### Recovery and runtime
- Fail-closed live cold start (refused before MT5 connect without `--cold-start`).
- `GOLDBOT_STATE_DB` precedence per ADR-016.
- Per-journal heartbeat (`<journal>.heartbeat.json`) so demo/backtest never clobber live.
- Live session-table guard: the synthetic `00:00-23:59` placeholder is rejected; config now carries the observed ePlanet week (`01:05-23:55` broker time, derived from 120 days of real M15 history).
- Exclusive launcher lock (`var/live.lock`, exit 3), password never accepted in argv, rotated bounded logs.

### Risk and money math
- ADR-001/025 fail-safe defaults restored (Gate D hard 2.0, profile open-risk 2.0); `config/base.toml` keeps the explicit 3.00.
- Untracked/foreign positions are counted at the worst-case per-trade cap (never 0.0) and journaled once.
- Swap nights derived from the profile max holding time (no under-count for 36/48/72h holds).
- Deterministic order magic from crc32 instead of the per-process salted `hash()` (restart reconciliation).

### Decision and scoring
- Confirmations are read strictly earlier and registered only after capital approval; rejected/D/NOISE signals can no longer confirm the next signal.
- Zone distance (ADR-035) enforced for both the numeric and zones paths.
- The journal carries the real zone score; the EMA200 vote requires 200 bars and a real slope.
- Retired config/API tests rewritten to pin the new contract (no silent deletions).

### Config, docs and tooling
- `config_hash` now covers the resolved risk-profile document; duplicated cost constants are validated at load and fail closed.
- 32-code MT5 retcode table with an explicit uncertain-outcome policy; DST-aware news fallback.
- Panel rejects retired/unknown keys with 400 and exposes `effective_config`; no number shown that the engine does not use.
- MT5 real-data tape harvester (fail-closed, deterministic intrabar expansion); tape validation before any broker interaction; final-bar flush and explicit bar-gap records.
- Full historical test suite restored and extended: **1,084 tests** (from the RC's 56 reconstructed ones), including chaos, failure injection and soak.
- Conflict, defect, risk and change registers plus 8 independent domain audits and 5 cross-reviews under `reports/`.

### Honest status
- Real-data 120-day backtest: 147 trades, net −158.34 USD, PF 0.95, MaxDD 8.66% (IS −671.44 / OOS +180.45). **No profitability claim.**
- Live demo validation covered startup/recovery/journal while the market was closed; order execution on the venue is still unverified.
