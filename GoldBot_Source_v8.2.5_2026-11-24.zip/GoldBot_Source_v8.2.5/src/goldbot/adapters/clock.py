"""Clocks. The simulated clock is what makes replay reproducible."""

from __future__ import annotations

import time as _time
from dataclasses import dataclass, field
from datetime import datetime, time, timedelta, timezone

from ..domain.model import Symbol, SymbolInfo, Ts, utc
from ..ports.clock import ClockDrift, SessionState


class SystemClock:
    """Live clock: UTC wall time plus monotonic, broker offset learned from ticks."""

    def __init__(self, symbol_info: SymbolInfo, *, offset: timedelta | None = None) -> None:
        self._info = symbol_info
        self._offset = offset if offset is not None else symbol_info.broker_offset
        self._samples: list[float] = []

    def now(self) -> Ts:
        return Ts(datetime.now(tz=timezone.utc), _time.monotonic())

    def broker_now(self) -> datetime:
        return self.now().wall + self._offset

    def drift(self) -> ClockDrift:
        if not self._samples:
            return ClockDrift(self._offset, timedelta(0), False)
        spread = max(self._samples) - min(self._samples)
        return ClockDrift(self._offset, timedelta(seconds=spread), spread > 5.0)

    def observe(self, tick_time: datetime, received: datetime) -> None:
        delta = (tick_time - received).total_seconds()
        self._samples.append(delta)
        if len(self._samples) > 200:
            self._samples.pop(0)
        self._offset = timedelta(seconds=sum(self._samples) / len(self._samples))

    def set_offset(self, offset: timedelta) -> None:
        """Adopt the server offset the venue adapter learned (DST-safe, live only)."""
        self._offset = offset

    def to_broker(self, ts: datetime) -> datetime:
        return utc(ts) + self._offset

    def to_utc(self, ts: datetime) -> datetime:
        return utc(ts) - self._offset

    def session(self, symbol: Symbol, at: datetime | None = None) -> SessionState:
        local = (at or self.broker_now()).time()
        for window in self._info.sessions:
            if window.contains(local):
                return SessionState.OPEN
        return SessionState.CLOSED


@dataclass
class SimulatedClock:
    """Deterministic clock driven by the tape; identical behaviour in backtest and replay."""

    start: datetime
    offset: timedelta = timedelta(hours=2)
    _now: datetime = field(init=False)
    _mono: float = field(default=0.0, init=False)
    _info: SymbolInfo | None = field(default=None, init=False)

    def __post_init__(self) -> None:
        self._now = utc(self.start)

    def bind(self, info: SymbolInfo) -> None:
        self._info = info
        self.offset = info.broker_offset

    def advance(self, ts: datetime) -> None:
        target = utc(ts)
        if target > self._now:
            self._mono += (target - self._now).total_seconds()
            self._now = target

    def now(self) -> Ts:
        return Ts(self._now, self._mono)

    def broker_now(self) -> datetime:
        return self._now + self.offset

    def drift(self) -> ClockDrift:
        return ClockDrift(self.offset, timedelta(0), False)

    def to_broker(self, ts: datetime) -> datetime:
        return utc(ts) + self.offset

    def to_utc(self, ts: datetime) -> datetime:
        return utc(ts) - self.offset

    def session(self, symbol: Symbol, at: datetime | None = None) -> SessionState:
        info = self._info
        if info is None:
            return SessionState.OPEN
        local = (at or self.broker_now()).time()
        for window in info.sessions:
            if window.contains(local):
                return SessionState.OPEN
        return SessionState.CLOSED
