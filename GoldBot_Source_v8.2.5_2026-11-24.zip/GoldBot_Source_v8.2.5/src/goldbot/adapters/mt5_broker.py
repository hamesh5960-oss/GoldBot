"""MetaTrader 5 venue adapter: broker gateway, tick feed and history warm-up.

The rest of the system never imports MetaTrader5. This module is the only place
that speaks the terminal API, and it takes the module by injection so the whole
adapter is testable with a fake terminal (tests/test_mt5_broker.py).

Broker time: MT5 reports server-wall-clock seconds (a naive epoch). Every value
crossing this boundary is converted to UTC by subtracting the learned server
offset, so the engine's bars, clocks and risk checks keep one time base.
"""

from __future__ import annotations

import time as _time
from dataclasses import dataclass
from datetime import datetime, time, timedelta, timezone
from typing import Any, Iterable, Sequence

from ..domain.errors import GoldbotError, ErrorClass, SubmitUncertain
from ..domain.execution import ApprovedOrder, OrderAck
from ..domain.model import (
    AccountSnapshot,
    Bar,
    ClosedTrade,
    ConnectionInfo,
    DealRecord,
    OrderSnapshot,
    PositionSnapshot,
    SessionWindow,
    Symbol,
    SymbolInfo,
    TF_SECONDS,
    Tick,
    Ticket,
    Timeframe,
    Ts,
    utc,
)
from ..domain.money import money
from ..log import get_logger
from ..ports.broker import GatewayHealth

log = get_logger("mt5")


class MT5ConnectionError(GoldbotError):
    error_class = ErrorClass.NETWORK
    code = "mt5_connection"


# --- MT5 constants (fallbacks keep a fake module minimal) -------------------
TRADE_ACTION_DEAL = 1
TRADE_ACTION_PENDING = 5
TRADE_ACTION_SLTP = 6
ORDER_TYPE_BUY = 0
ORDER_TYPE_SELL = 1
ORDER_TYPE_BUY_LIMIT = 2
ORDER_TYPE_SELL_LIMIT = 3
ORDER_FILLING_FOK = 0
ORDER_FILLING_IOC = 1
ORDER_FILLING_RETURN = 2
ORDER_TIME_GTC = 0
RETCODE_PLACED = 10008
RETCODE_DONE = 10009
RETCODE_DONE_PARTIAL = 10010
RETCODE_INVALID_FILL = 10030
RETCODE_MARKET_CLOSED = 10018
RETCODE_TRADE_DISABLED = 10017
RETCODE_CLIENT_DISABLES_AT = 10027
RETCODE_POSITION_CLOSED = 10036
RETCODE_INVALID_VOLUME = 10014
RETCODE_INVALID_STOPS = 10016
RETCODE_CONNECTION = 10031
DEAL_ENTRY_OUT = 1

TRADE_ACTION_REMOVE = 3
RETCODE_CANCELED = 10007
RETCODE_ERROR = 10011
RETCODE_TIMEOUT = 10012

# Only DONE/DONE_PARTIAL prove execution. PLACED proves acceptance, nothing else:
# a pending order is not a position and must never be booked as one.
FILLED_RETCODES = frozenset({RETCODE_DONE, RETCODE_DONE_PARTIAL})
# Outcome unknown at the venue: the request may already have been executed.
UNCERTAIN_RETCODES = frozenset({RETCODE_TIMEOUT, RETCODE_ERROR})
ACCEPTED_RETCODES = frozenset({RETCODE_PLACED, RETCODE_DONE, RETCODE_DONE_PARTIAL})

RETCODE_NAMES: dict[int, str] = {
    10004: "REQUOTE",
    10006: "REJECTED",
    10007: "CANCELED",
    10008: "PLACED",
    10009: "DONE",
    10010: "DONE_PARTIAL",
    10011: "ERROR",
    10012: "TIMEOUT",
    10013: "INVALID",
    10014: "INVALID_VOLUME",
    10015: "INVALID_PRICE",
    10016: "INVALID_STOPS",
    10017: "TRADE_DISABLED",
    10018: "MARKET_CLOSED",
    10019: "NO_MONEY",
    10020: "PRICE_CHANGED",
    10021: "PRICE_OFF",
    10024: "TOO_MANY_REQUESTS",
    10026: "SERVER_DISABLES_AT",
    10027: "CLIENT_DISABLES_AT",
    10030: "INVALID_FILL",
    10031: "CONNECTION",
    10036: "POSITION_CLOSED",
}

_ORDER_STATES = {
    0: "placed",
    1: "placed",
    2: "canceled",
    3: "partial",
    4: "filled",
    5: "rejected",
    6: "expired",
}

_FILLING_FROM_INFO = {
    "fok": ORDER_FILLING_FOK,
    "ioc": ORDER_FILLING_IOC,
    "return": ORDER_FILLING_RETURN,
}

_SYMBOL_TRADE_MODE = {0: "disabled", 1: "longonly", 2: "shortonly", 3: "closeonly", 4: "full"}

_KNOWN_CLOSE_REASONS = ("weekend", "kill", "manual", "strategy", "timeout", "sl", "tp")


@dataclass
class _CloseAttempt:
    """Bookkeeping for one close idempotency key.

    ack is set exactly when the venue truth confirmed an execution; uncertain
    marks an attempt whose outcome is still unknown (never resent blindly).
    """

    key: str
    ticket: int
    volume_before: float
    sends: int = 0
    stamp: float = 0.0
    ack: OrderAck | None = None
    uncertain: bool = False
    uncertain_reason: str = ""
    rejected: bool = False


def _const(module: Any, name: str, fallback: int) -> int:
    return int(getattr(module, name, fallback))


def _from_server(epoch: Any, offset: timedelta) -> datetime:
    """Server-wall-clock seconds -> aware UTC datetime."""
    return datetime.fromtimestamp(int(epoch), tz=timezone.utc) - offset


def _server_naive(moment: datetime, offset: timedelta) -> datetime:
    """Aware UTC datetime -> naive server datetime for the history API."""
    return (utc(moment) + offset).replace(tzinfo=None)


def _rate_value(row: Any, key: str, default: Any = 0.0) -> Any:
    """Read one field of a numpy structured record without .get()."""
    try:
        return row[key]
    except (KeyError, ValueError, TypeError, IndexError):
        return default


def _opt_float(value: Any) -> float | None:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return None if number == 0.0 else number


class MT5Broker:
    """IBrokerGateway over a logged-in MetaTrader 5 terminal (demo or real)."""

    def __init__(
        self,
        info: SymbolInfo,
        *,
        login: int,
        password: str,
        server: str,
        path: str = "",
        timeout_ms: int = 60_000,
        mt5_module: Any = None,
        settlement_poll_s: float = 2.0,
        close_dedupe_s: float = 120.0,
        pending_fill_timeout_s: float = 1.0,
        pending_fill_poll_s: float = 0.1,
    ) -> None:
        self._info = info
        self._login = int(login)
        self._password = password
        self._server = server
        self._path = path
        self._timeout_ms = max(1_000, int(timeout_ms))
        self._mt5 = mt5_module
        self._initialized = False
        self._connection: ConnectionInfo | None = None
        self._offset = info.broker_offset
        self._tracked: dict[int, PositionSnapshot] = {}
        self._reported_deals: set[int] = set()
        self._handled_close: set[int] = set()
        self._last_poll = 0.0
        self._settlement_poll_s = max(0.2, float(settlement_poll_s))
        self._last_tick: Tick | None = None
        self._last_tick_utc: datetime | None = None
        # POS-01: one close key -> one send. A second identical request is answered
        # from this ledger (or from venue truth), never by a blind second send.
        self._close_attempts: dict[str, _CloseAttempt] = {}
        # MT5-02: tickets whose closing deal is not visible yet stay tracked.
        self._pending_settlements: dict[int, PositionSnapshot] = {}
        self._settlement_warned: dict[int, int] = {}
        self._close_dedupe_s = max(0.0, float(close_dedupe_s))
        self._pending_fill_timeout_s = max(0.0, float(pending_fill_timeout_s))
        self._pending_fill_poll_s = max(0.0, float(pending_fill_poll_s))
        # Whole-second residual the 15-minute offset rounding cannot express.
        # None until the first live tick calibrates it (see `raw_tick`).
        self._skew_seconds: float | None = None

    # -- basic accessors -------------------------------------------------
    @property
    def mt5(self) -> Any:
        if self._mt5 is None:
            from .goldbot_gateway.terminal import load_mt5

            self._mt5 = load_mt5()
        return self._mt5

    @property
    def info(self) -> SymbolInfo:
        return self._info

    @property
    def offset(self) -> timedelta:
        return self._offset

    @property
    def skew_seconds(self) -> float | None:
        """Clock residual between the PC and the broker once a tick calibrated it."""
        return self._skew_seconds

    @property
    def login(self) -> int:
        return self._login

    def bind_info(self, info: SymbolInfo) -> None:
        """Adopt the metadata rebuilt after the server offset was learned."""
        self._info = info

    def is_demo(self) -> bool:
        account = self.mt5.account_info() if self._initialized else None
        if account is None:
            return False
        return int(getattr(account, "trade_mode", -1)) == 0

    def trade_allowed(self) -> bool:
        if not self._initialized:
            return False
        terminal = self.mt5.terminal_info()
        account = self.mt5.account_info()
        return bool(
            terminal is not None
            and getattr(terminal, "trade_allowed", False)
            and account is not None
            and getattr(account, "trade_allowed", True)
        )

    # -- lifecycle -------------------------------------------------------
    def connect(self) -> ConnectionInfo:
        if self._initialized and self._connection is not None:
            return self._connection
        kwargs: dict[str, Any] = {
            "login": self._login,
            "password": self._password,
            "server": self._server,
            "timeout": self._timeout_ms,
        }
        if self._path:
            kwargs["path"] = self._path
        if not self.mt5.initialize(**kwargs):
            raise MT5ConnectionError(f"MT5 initialize failed: {self.mt5.last_error()}")
        self._initialized = True
        try:
            account = self.mt5.account_info()
            terminal = self.mt5.terminal_info()
            if account is None or terminal is None:
                raise MT5ConnectionError("MT5 connected but account/terminal info is unavailable")
            if int(getattr(account, "login", 0)) != self._login:
                raise MT5ConnectionError(
                    f"terminal is logged into {getattr(account, 'login', '?')}, expected {self._login}"
                )
            actual_server = str(getattr(account, "server", "") or "")
            if actual_server.strip().lower() != self._server.strip().lower():
                raise MT5ConnectionError(
                    f"terminal server is {actual_server!r}, expected {self._server!r}"
                )
            self._ensure_symbol()
            self._learn_offset()
            trade_mode = "hedging" if int(getattr(account, "margin_mode", 2)) == 2 else "netting"
            self._connection = ConnectionInfo(
                server=actual_server,
                login=int(account.login),
                trade_mode=trade_mode,  # type: ignore[arg-type]
                broker_offset=self._offset,
                terminal=f"MT5 build {int(getattr(terminal, 'build', 0))}",
            )
            log.info(
                "MT5 connected",
                extra={
                    "fields": {
                        "login": int(account.login),
                        "server": actual_server,
                        "balance": float(account.balance),
                        "offset_minutes": self._offset.total_seconds() / 60.0,
                        "trade_allowed": bool(getattr(terminal, "trade_allowed", False)),
                    }
                },
            )
            return self._connection
        except Exception:
            self.disconnect()
            raise

    def disconnect(self) -> None:
        if self._initialized:
            try:
                self.mt5.shutdown()
            except Exception:  # noqa: BLE001 - shutdown must never mask a real error
                log.exception("MT5 shutdown failed")
        self._initialized = False
        self._connection = None

    def is_ready(self) -> bool:
        if not self._initialized:
            return False
        try:
            return self.mt5.account_info() is not None
        except Exception:  # noqa: BLE001
            return False

    def health(self) -> GatewayHealth:
        started = _time.perf_counter()
        alive = False
        message = "not initialized"
        try:
            terminal = self.mt5.terminal_info() if self._initialized else None
            account = self.mt5.account_info() if self._initialized else None
            alive = bool(terminal is not None and account is not None and terminal.connected)
            message = "ok" if alive else "terminal not connected"
        except Exception as exc:  # noqa: BLE001 - health must never raise
            message = repr(exc)
        latency = (_time.perf_counter() - started) * 1000.0
        age = (
            (_time.time() - self._last_tick_utc.timestamp())
            if self._last_tick_utc is not None
            else float("inf")
        )
        return GatewayHealth(alive=alive, latency_ms=latency, last_tick_age_s=age, message=message)

    def _ensure_symbol(self) -> None:
        symbol = self.mt5.symbol_info(self._info.broker_symbol)
        # A broker symbol that exists but is not in Market Watch answers
        # symbol_info_tick() with zeros, which the live runner misreads as a
        # closed market. Selecting it is idempotent and cheap, so do it
        # whenever the symbol is missing *or* merely not visible.
        invisible = symbol is not None and not bool(getattr(symbol, "visible", True))
        if symbol is None or invisible:
            if not self.mt5.symbol_select(self._info.broker_symbol, True):
                raise MT5ConnectionError(
                    f"symbol {self._info.broker_symbol!r} is not available and cannot be selected"
                )
            symbol = self.mt5.symbol_info(self._info.broker_symbol)
        if symbol is None:
            raise MT5ConnectionError(f"symbol {self._info.broker_symbol!r} is not available")
        checks = [
            ("digits", float(self._info.digits), float(getattr(symbol, "digits", -1))),
            ("point", float(self._info.point), float(getattr(symbol, "point", 0.0))),
            (
                "contract_size",
                float(self._info.contract_size),
                float(getattr(symbol, "trade_contract_size", 0.0)),
            ),
            ("min_volume", float(self._info.min_volume), float(getattr(symbol, "volume_min", 0.0))),
            (
                "volume_step",
                float(self._info.volume_step),
                float(getattr(symbol, "volume_step", 0.0)),
            ),
        ]
        broken = [
            f"{name}: config {expected} != broker {actual}"
            for name, expected, actual in checks
            if abs(expected - actual) > max(1e-9, abs(expected) * 1e-6)
        ]
        if broken:
            raise MT5ConnectionError(
                "symbol metadata mismatch (fix config/live.toml): " + "; ".join(broken)
            )

    def _learn_offset(self, raw_tick: Any = None) -> None:
        try:
            tick = raw_tick if raw_tick is not None else self.mt5.symbol_info_tick(
                self._info.broker_symbol
            )
        except Exception:  # noqa: BLE001 - a missing tick must not break the loop
            return
        if tick is None:
            return
        epoch = int(getattr(tick, "time", 0) or 0)
        if epoch <= 0:
            return
        difference = epoch - _time.time()
        rounded = int(round(difference / 900.0)) * 900
        if -12 * 3600 <= rounded <= 14 * 3600:
            new_offset = timedelta(seconds=rounded)
            if new_offset != self._offset:
                # A real timezone move invalidates the sub-15-minute residual.
                self._skew_seconds = None
            self._offset = new_offset

    # -- reads -----------------------------------------------------------
    def _to_snapshot(self, raw: Any) -> PositionSnapshot:
        side = "buy" if int(getattr(raw, "type", 0)) == 0 else "sell"
        return PositionSnapshot(
            ticket=Ticket(int(raw.ticket)),
            symbol=self._info.symbol,
            side=side,  # type: ignore[arg-type]
            volume=float(raw.volume),
            open_price=float(raw.price_open),
            sl=_opt_float(getattr(raw, "sl", 0.0)),
            tp=_opt_float(getattr(raw, "tp", 0.0)),
            magic=int(getattr(raw, "magic", 0)),
            comment=str(getattr(raw, "comment", "") or ""),
            open_time=_from_server(getattr(raw, "time", 0), self._offset),
            profit=money(float(getattr(raw, "profit", 0.0) or 0.0)),
            swap=money(float(getattr(raw, "swap", 0.0) or 0.0)),
        )

    def positions(self) -> Sequence[PositionSnapshot]:
        if not self._initialized:
            return ()
        raw_positions = self.mt5.positions_get(symbol=self._info.broker_symbol) or ()
        return tuple(self._to_snapshot(raw) for raw in raw_positions)

    def orders(self) -> Sequence[OrderSnapshot]:
        if not self._initialized:
            return ()
        raw_orders = self.mt5.orders_get(symbol=self._info.broker_symbol) or ()
        out: list[OrderSnapshot] = []
        for raw in raw_orders:
            side = "buy" if int(getattr(raw, "type", 0)) in (0, 2, 4, 6) else "sell"
            state = _ORDER_STATES.get(int(getattr(raw, "state", 0)), "placed")
            out.append(
                OrderSnapshot(
                    ticket=Ticket(int(raw.ticket)),
                    symbol=self._info.symbol,
                    side=side,  # type: ignore[arg-type]
                    volume=float(getattr(raw, "volume_initial", 0.0) or 0.0),
                    price=float(getattr(raw, "price_open", 0.0) or 0.0),
                    sl=_opt_float(getattr(raw, "sl", 0.0)),
                    tp=_opt_float(getattr(raw, "tp", 0.0)),
                    state=state,  # type: ignore[arg-type]
                    magic=int(getattr(raw, "magic", 0)),
                    comment=str(getattr(raw, "comment", "") or ""),
                    created_at=_from_server(getattr(raw, "time_setup", 0), self._offset),
                    filled_volume=float(getattr(raw, "volume_current", 0.0) or 0.0),
                )
            )
        return tuple(out)

    def deals(self, *, since: datetime) -> Sequence[DealRecord]:
        if not self._initialized:
            return ()
        now = datetime.now(tz=timezone.utc)
        raw_deals = (
            self.mt5.history_deals_get(
                _server_naive(since, self._offset), _server_naive(now, self._offset)
            )
            or ()
        )
        out: list[DealRecord] = []
        for raw in raw_deals:
            deal_symbol = str(getattr(raw, "symbol", "") or "")
            symbol = (
                self._info.symbol
                if deal_symbol == self._info.broker_symbol
                else Symbol(deal_symbol or self._info.symbol)
            )
            out.append(
                DealRecord(
                    ticket=Ticket(int(raw.ticket)),
                    order_ticket=Ticket(int(getattr(raw, "order", 0) or 0)),
                    symbol=symbol,
                    side=(
                        "buy" if int(getattr(raw, "type", 0)) == 0 else "sell"
                    ),  # type: ignore[arg-type]
                    volume=abs(float(getattr(raw, "volume", 0.0) or 0.0)),
                    price=float(getattr(raw, "price", 0.0) or 0.0),
                    commission=money(-float(getattr(raw, "commission", 0.0) or 0.0)),
                    swap=money(float(getattr(raw, "swap", 0.0) or 0.0)),
                    profit=money(float(getattr(raw, "profit", 0.0) or 0.0)),
                    time=_from_server(getattr(raw, "time", 0), self._offset),
                    comment=str(getattr(raw, "comment", "") or ""),
                )
            )
        return tuple(out)

    def account(self) -> AccountSnapshot:
        if not self._initialized:
            raise MT5ConnectionError("account() called before connect()")
        raw = self.mt5.account_info()
        if raw is None:
            raise MT5ConnectionError("account_info() returned None (terminal disconnected?)")
        trade_mode = "hedging" if int(getattr(raw, "margin_mode", 2)) == 2 else "netting"
        now = datetime.now(tz=timezone.utc)
        return AccountSnapshot(
            login=int(raw.login),
            server=str(raw.server),
            currency=str(raw.currency),
            balance=money(float(raw.balance)),
            equity=money(float(raw.equity)),
            margin=money(float(getattr(raw, "margin", 0.0) or 0.0)),
            free_margin=money(float(getattr(raw, "margin_free", 0.0) or 0.0)),
            leverage=int(getattr(raw, "leverage", 1) or 1),
            trade_mode=trade_mode,  # type: ignore[arg-type]
            ts=Ts(now, _time.monotonic()),
        )

    def symbol_info(self, symbol: Symbol) -> SymbolInfo:
        return self._info

    def find_by_client_ref(self, client_ref: str, *, since: datetime) -> Sequence[OrderSnapshot]:
        out: list[OrderSnapshot] = []
        for position in self.positions():
            if position.comment == client_ref:
                out.append(
                    OrderSnapshot(
                        ticket=position.ticket,
                        symbol=position.symbol,
                        side=position.side,
                        volume=position.volume,
                        price=position.open_price,
                        sl=position.sl,
                        tp=position.tp,
                        state="filled",
                        magic=position.magic,
                        comment=position.comment,
                        created_at=position.open_time,
                        filled_volume=position.volume,
                    )
                )
        if self._initialized:
            try:
                history = (
                    self.mt5.history_orders_get(
                        _server_naive(since, self._offset),
                        _server_naive(datetime.now(tz=timezone.utc), self._offset),
                    )
                    or ()
                )
            except Exception:  # noqa: BLE001 - adoption is best effort
                history = ()
            for raw in history:
                if str(getattr(raw, "comment", "") or "") != client_ref:
                    continue
                out.append(
                    OrderSnapshot(
                        ticket=Ticket(int(raw.ticket)),
                        symbol=self._info.symbol,
                        side="buy" if int(getattr(raw, "type", 0)) == 0 else "sell",
                        volume=float(getattr(raw, "volume_initial", 0.0) or 0.0),
                        price=float(getattr(raw, "price_open", 0.0) or 0.0),
                        sl=_opt_float(getattr(raw, "sl", 0.0)),
                        tp=_opt_float(getattr(raw, "tp", 0.0)),
                        state="filled" if int(getattr(raw, "state", 0)) == 4 else "placed",
                        magic=int(getattr(raw, "magic", 0)),
                        comment=client_ref,
                        created_at=_from_server(getattr(raw, "time_setup", 0), self._offset),
                        filled_volume=float(getattr(raw, "volume_current", 0.0) or 0.0),
                    )
                )
        return tuple(out)

    # -- writes ----------------------------------------------------------
    def _filling_candidates(self) -> list[int]:
        configured = _FILLING_FROM_INFO.get(str(self._info.filling_mode), ORDER_FILLING_IOC)
        candidates = [configured, ORDER_FILLING_IOC, ORDER_FILLING_FOK, ORDER_FILLING_RETURN]
        seen: list[int] = []
        for value in candidates:
            if value not in seen:
                seen.append(value)
        return seen

    def _reject(self, intent_id: str, retcode: int, message: str) -> OrderAck:
        return OrderAck(
            intent_id=intent_id,
            accepted=False,
            retcode=int(retcode),
            retcode_name=RETCODE_NAMES.get(int(retcode), str(retcode)),
            message=message,
        )

    def _trade_gate(self) -> OrderAck | None:
        if not self.is_ready():
            raise SubmitUncertain("terminal not ready")
        if not self.trade_allowed():
            return self._reject(
                "",
                RETCODE_CLIENT_DISABLES_AT,
                "AutoTrading is off (enable the Algo Trading button in the terminal)",
            )
        return None

    def submit(self, order: ApprovedOrder, *, idempotency_key: str) -> OrderAck:
        gate = self._trade_gate()
        if gate is not None:
            return self._reject(order.intent_id, gate.retcode, gate.message)
        info = self._info
        volume = info.round_volume(float(order.volume))
        if (
            volume < info.min_volume - 1e-9
            or volume > info.max_volume + 1e-9
            or abs(volume / info.volume_step - round(volume / info.volume_step)) > 1e-6
        ):
            return self._reject(
                order.intent_id,
                RETCODE_INVALID_VOLUME,
                f"volume {order.volume} is outside broker limits",
            )
        # Idempotent submit (ADR-040): a replayed intent whose client_ref already
        # exists at the venue is adopted instead of opening a second position.
        existing = self._position_by_ref(str(order.client_ref))
        if existing is not None:
            now = datetime.now(tz=timezone.utc)
            self._tracked[int(existing.ticket)] = existing
            return OrderAck(
                intent_id=order.intent_id,
                accepted=True,
                retcode=RETCODE_DONE,
                retcode_name=RETCODE_NAMES.get(RETCODE_DONE, str(RETCODE_DONE)),
                message="adopted existing client_ref",
                ticket=int(existing.ticket),
                fill_price=float(existing.open_price),
                filled_volume=float(existing.volume),
                ts=Ts(now, _time.monotonic()),
            )
        raw_tick = self.mt5.symbol_info_tick(info.broker_symbol)
        if raw_tick is None or float(getattr(raw_tick, "ask", 0.0)) <= 0.0:
            return self._reject(order.intent_id, RETCODE_MARKET_CLOSED, "no tradable tick")
        self._learn_offset(raw_tick)
        if order.order_type == "limit" and order.limit_price is not None:
            action = TRADE_ACTION_PENDING
            order_type = ORDER_TYPE_BUY_LIMIT if order.side == "buy" else ORDER_TYPE_SELL_LIMIT
            price = info.round_price(float(order.limit_price))
        else:
            action = TRADE_ACTION_DEAL
            order_type = ORDER_TYPE_BUY if order.side == "buy" else ORDER_TYPE_SELL
            price = info.round_price(
                float(raw_tick.ask) if order.side == "buy" else float(raw_tick.bid)
            )
        request: dict[str, Any] = {
            "action": action,
            "symbol": info.broker_symbol,
            "volume": volume,
            "type": order_type,
            "price": price,
            "sl": info.round_price(float(order.sl)) if order.sl else 0.0,
            "tp": info.round_price(float(order.tp)) if order.tp else 0.0,
            "deviation": int(order.max_slippage_points),
            "magic": int(order.magic),
            "comment": str(order.client_ref)[:31],
            "type_time": ORDER_TIME_GTC,
        }
        result = self._send_with_filling(request)
        retcode = int(getattr(result, "retcode", -1))
        if retcode in UNCERTAIN_RETCODES:
            # MT5-06: TIMEOUT/ERROR means the order may already exist at the venue.
            raise SubmitUncertain(
                f"order_send retcode {retcode} ({RETCODE_NAMES.get(retcode, '?')}) "
                "leaves the order outcome unknown"
            )
        if retcode not in ACCEPTED_RETCODES:
            return OrderAck(
                intent_id=order.intent_id,
                accepted=False,
                retcode=retcode,
                retcode_name=RETCODE_NAMES.get(retcode, str(retcode)),
                message=str(getattr(result, "comment", "") or ""),
            )
        if action == TRADE_ACTION_PENDING:
            return self._reconcile_pending_order(order, request, result, info)
        return self._executed_submit_ack(order, result, info)

    def _send_with_filling(self, request: dict[str, Any]) -> Any:
        result = None
        for filling in self._filling_candidates():
            request["type_filling"] = filling
            result = self.mt5.order_send(dict(request))
            if result is None:
                raise SubmitUncertain(f"order_send returned None: {self.mt5.last_error()}")
            if int(getattr(result, "retcode", -1)) != RETCODE_INVALID_FILL:
                break
        assert result is not None
        return result

    def _executed_submit_ack(
        self, order: ApprovedOrder, result: Any, info: SymbolInfo
    ) -> OrderAck:
        """Build a fill ack only from proof of execution (DONE/DONE_PARTIAL).

        MT5-01: a PLACED order has no volume and no position; the requested size
        must never be fabricated as a fill (that created phantom positions).
        """
        retcode = int(getattr(result, "retcode", -1))
        if retcode not in FILLED_RETCODES:
            raise SubmitUncertain(
                f"order accepted with retcode {retcode} but no execution proof"
            )
        filled = float(getattr(result, "volume", 0.0) or 0.0)
        fill_price = float(getattr(result, "price", 0.0) or 0.0)
        ticket = int(getattr(result, "order", 0) or getattr(result, "deal", 0) or 0)
        position = self._position_by_ref(str(order.client_ref))
        if position is not None:
            ticket = int(position.ticket)
            filled = max(filled, float(position.volume))
            if fill_price <= 0.0:
                fill_price = position.open_price
        if filled <= 0.0:
            raise SubmitUncertain("venue reported DONE without a filled volume")
        if fill_price <= 0.0:
            raise SubmitUncertain("venue reported a fill without an execution price")
        if ticket <= 0:
            raise SubmitUncertain("filled but the venue returned no order ticket")
        now = datetime.now(tz=timezone.utc)
        self._tracked[ticket] = PositionSnapshot(
            ticket=Ticket(ticket),
            symbol=info.symbol,
            side=order.side,
            volume=filled,
            open_price=fill_price,
            sl=_opt_float(order.sl),
            tp=_opt_float(order.tp),
            magic=int(order.magic),
            comment=str(order.client_ref)[:31],
            open_time=now,
            profit=money(0.0),
            swap=money(0.0),
        )
        return OrderAck(
            intent_id=order.intent_id,
            accepted=True,
            retcode=retcode,
            retcode_name=RETCODE_NAMES.get(retcode, str(retcode)),
            message=str(getattr(result, "comment", "") or "accepted"),
            ticket=ticket,
            fill_price=fill_price,
            filled_volume=filled,
            ts=Ts(now, _time.monotonic()),
        )

    def _reconcile_pending_order(
        self, order: ApprovedOrder, request: dict[str, Any], result: Any, info: SymbolInfo
    ) -> OrderAck:
        """MT5-01: a placed limit is reconciled to a position or cancelled.

        Pending-order lifecycle management is not modelled, so an unfilled limit
        must not be left live as an unmanaged order and must not be booked as a
        position. It is polled briefly, then cancelled; only a real position can
        become POSITION_OPEN.
        """
        retcode = int(getattr(result, "retcode", -1))
        if retcode in FILLED_RETCODES:
            return self._executed_submit_ack(order, result, info)
        if retcode not in (RETCODE_PLACED,):
            return OrderAck(
                intent_id=order.intent_id,
                accepted=False,
                retcode=retcode,
                retcode_name=RETCODE_NAMES.get(retcode, str(retcode)),
                message=str(getattr(result, "comment", "") or ""),
            )
        order_ticket = int(getattr(result, "order", 0) or 0)
        deadline = _time.monotonic() + self._pending_fill_timeout_s
        while True:
            position = self._position_by_ref(str(order.client_ref))
            if position is not None:
                now = datetime.now(tz=timezone.utc)
                self._tracked[int(position.ticket)] = position
                return OrderAck(
                    intent_id=order.intent_id,
                    accepted=True,
                    retcode=RETCODE_DONE,
                    retcode_name="DONE",
                    message="limit order filled",
                    ticket=int(position.ticket),
                    fill_price=position.open_price,
                    filled_volume=float(position.volume),
                    ts=Ts(now, _time.monotonic()),
                )
            if _time.monotonic() >= deadline:
                break
            _time.sleep(self._pending_fill_poll_s)
        cancelled = self._cancel_pending_order(order_ticket)
        log.warning(
            "unfilled limit order cancelled instead of being booked",
            extra={"fields": {"intent_id": order.intent_id, "order": order_ticket, "cancelled": cancelled}},
        )
        return OrderAck(
            intent_id=order.intent_id,
            accepted=False,
            retcode=RETCODE_CANCELED,
            retcode_name="CANCELED",
            message=(
                "limit order was not filled and has been cancelled "
                "(pending lifecycle is not modelled)"
            ),
        )

    def _cancel_pending_order(self, order_ticket: int) -> bool:
        if order_ticket <= 0:
            return False
        try:
            result = self.mt5.order_send(
                {
                    "action": TRADE_ACTION_REMOVE,
                    "order": int(order_ticket),
                    "symbol": self._info.broker_symbol,
                }
            )
        except Exception:  # noqa: BLE001 - cancellation is best effort, callers are told
            log.exception("pending order cancel failed")
            return False
        if result is None:
            return False
        return int(getattr(result, "retcode", -1)) in ACCEPTED_RETCODES

    def _position_by_ref(self, client_ref: str) -> PositionSnapshot | None:
        try:
            for position in self.positions():
                if position.comment == client_ref:
                    return position
        except Exception:  # noqa: BLE001 - adoption is best effort
            return None
        return None

    def _raw_position(self, ticket: int) -> Any:
        if not self._initialized:
            return None
        raw = self.mt5.positions_get(ticket=int(ticket)) or ()
        return raw[0] if raw else None

    def modify(
        self, ticket: Ticket, *, sl: float | None, tp: float | None, idempotency_key: str
    ) -> OrderAck:
        if not self._initialized:
            return self._reject("", RETCODE_CONNECTION, "not connected")
        raw = self._raw_position(int(ticket))
        if raw is None:
            return self._reject("", RETCODE_POSITION_CLOSED, f"position {ticket} not found")
        request = {
            "action": TRADE_ACTION_SLTP,
            "symbol": self._info.broker_symbol,
            "position": int(ticket),
            "sl": self._info.round_price(float(sl)) if sl is not None else float(raw.sl or 0.0),
            "tp": self._info.round_price(float(tp)) if tp is not None else float(raw.tp or 0.0),
            "magic": int(getattr(raw, "magic", 0)),
        }
        result = self.mt5.order_send(dict(request))
        if result is None:
            raise SubmitUncertain(f"modify order_send returned None: {self.mt5.last_error()}")
        retcode = int(getattr(result, "retcode", -1))
        if retcode in UNCERTAIN_RETCODES:
            raise SubmitUncertain(
                f"modify retcode {retcode} ({RETCODE_NAMES.get(retcode, '?')}) "
                "leaves the modify outcome unknown"
            )
        return OrderAck(
            intent_id="",
            accepted=retcode in ACCEPTED_RETCODES,
            retcode=retcode,
            retcode_name=RETCODE_NAMES.get(retcode, str(retcode)),
            message=str(getattr(result, "comment", "") or ""),
            ticket=int(ticket),
        )

    def close(
        self,
        ticket: Ticket,
        *,
        volume: float | None,
        idempotency_key: str,
        reason: str = "manual",
    ) -> OrderAck:
        if not self._initialized:
            return self._reject("", RETCODE_CONNECTION, "not connected")
        ticket_no = int(ticket)
        self._prune_close_attempts()
        key = f"{idempotency_key}|{ticket_no}|{volume}"
        attempt = self._close_attempts.get(key)
        if attempt is not None and attempt.ack is not None:
            # POS-01: one key, one close. A duplicate delivery is answered from
            # the ledger, never by touching the position again.
            return attempt.ack
        if attempt is not None and attempt.uncertain:
            raise SubmitUncertain(attempt.uncertain_reason or "close outcome still unknown")
        raw = self._raw_position(ticket_no)
        if raw is None:
            # The venue proves the position is gone: settle it, never re-send.
            ack = self._already_closed_ack(ticket_no, volume, reason)
            if attempt is None:
                attempt = _CloseAttempt(key=key, ticket=ticket_no, volume_before=0.0)
                self._close_attempts[key] = attempt
            attempt.ack = ack
            return ack
        info = self._info
        position = self._to_snapshot(raw)
        raw_tick = self.mt5.symbol_info_tick(info.broker_symbol)
        if raw_tick is None:
            return self._reject("", RETCODE_MARKET_CLOSED, "no tradable tick")
        self._learn_offset(raw_tick)
        closing_side = "sell" if position.side == "buy" else "buy"
        requested = position.volume if volume is None else float(volume)
        full_volume = volume is None or requested >= position.volume - 1e-9
        close_volume = position.volume if full_volume else info.round_volume(requested)
        if close_volume < info.min_volume - 1e-9:
            close_volume = position.volume
            full_volume = True
        # Venue truth wins: never ask for more than the position holds.
        close_volume = min(close_volume, float(position.volume))
        price = float(raw_tick.bid) if closing_side == "sell" else float(raw_tick.ask)
        request: dict[str, Any] = {
            "action": TRADE_ACTION_DEAL,
            "symbol": info.broker_symbol,
            "position": ticket_no,
            "volume": close_volume,
            "type": ORDER_TYPE_SELL if closing_side == "sell" else ORDER_TYPE_BUY,
            "price": info.round_price(price),
            "deviation": 30,
            "magic": int(getattr(raw, "magic", 0)),
            "comment": str(reason)[:31],
            "type_time": ORDER_TIME_GTC,
        }
        if attempt is None:
            attempt = _CloseAttempt(
                key=key, ticket=ticket_no, volume_before=float(position.volume)
            )
            self._close_attempts[key] = attempt
        attempt.sends += 1
        attempt.stamp = _time.monotonic()
        attempt.rejected = False
        result = self._send_with_filling(request)
        retcode = int(getattr(result, "retcode", -1))
        if retcode in UNCERTAIN_RETCODES:
            attempt.uncertain = True
            attempt.uncertain_reason = (
                f"close retcode {retcode} ({RETCODE_NAMES.get(retcode, '?')}) "
                "leaves the close outcome unknown"
            )
            raise SubmitUncertain(attempt.uncertain_reason)
        if retcode not in FILLED_RETCODES:
            attempt.rejected = True  # a definitive rejection never executed
            return OrderAck(
                intent_id="",
                accepted=False,
                retcode=retcode,
                retcode_name=RETCODE_NAMES.get(retcode, str(retcode)),
                message=str(getattr(result, "comment", "") or ""),
            )
        fill_price = float(getattr(result, "price", 0.0) or 0.0) or price
        closed = self._closed_trade_from_history(
            ticket_no,
            expected_volume=close_volume,
            snapshot=position,
            fallback_reason=reason,
        )
        if closed is None:
            closed = self._resolve_lagged_close(
                attempt, close_volume, fill_price, position, reason
            )
        if full_volume and closed is not None:
            self._handled_close.add(ticket_no)
        ack = OrderAck(
            intent_id="",
            accepted=True,
            retcode=retcode,
            retcode_name=RETCODE_NAMES.get(retcode, str(retcode)),
            message=str(getattr(result, "comment", "") or "closed"),
            ticket=ticket_no,
            fill_price=fill_price,
            filled_volume=float(close_volume),
            ts=Ts(datetime.now(tz=timezone.utc), _time.monotonic()),
            closed_trade=closed,
        )
        attempt.ack = ack
        return ack

    def _prune_close_attempts(self) -> None:
        if self._close_dedupe_s <= 0.0:
            return
        cutoff = _time.monotonic() - self._close_dedupe_s
        stale = [key for key, attempt in self._close_attempts.items() if attempt.stamp < cutoff]
        for key in stale:
            self._close_attempts.pop(key, None)

    def _resolve_lagged_close(
        self,
        attempt: _CloseAttempt,
        close_volume: float,
        fill_price: float,
        snapshot: PositionSnapshot,
        reason: str,
    ) -> ClosedTrade:
        """Settle from venue truth when the closing deal lags the execution.

        Position gone  -> the close executed; book it from the snapshot.
        Volume reduced -> book the executed slice from the snapshot.
        Volume same    -> no evidence of execution; never retry blindly.
        """
        truth = self._raw_position(attempt.ticket)
        if truth is None:
            self._handled_close.add(attempt.ticket)
            self._pending_settlements.pop(attempt.ticket, None)
            log.warning(
                "close settled from the snapshot: history lagged the closing deal",
                extra={"fields": {"ticket": attempt.ticket, "volume": close_volume}},
            )
            return self._fallback_closed_trade(
                attempt.ticket, close_volume, fill_price, snapshot, reason
            )
        remaining = float(getattr(truth, "volume", 0.0) or 0.0)
        executed = max(0.0, float(snapshot.volume) - remaining)
        if executed > 1e-9:
            return self._fallback_closed_trade(
                attempt.ticket, executed, fill_price, snapshot, reason
            )
        attempt.uncertain = True
        attempt.uncertain_reason = (
            "close was accepted but the venue still shows the unchanged position "
            "and no closing deal is visible"
        )
        raise SubmitUncertain(attempt.uncertain_reason)

    def _already_closed_ack(
        self, ticket: int, volume: float | None, reason: str
    ) -> OrderAck:
        snapshot = self._tracked.get(ticket) or self._pending_settlements.get(ticket)
        expected = (
            float(snapshot.volume)
            if snapshot is not None
            else (float(volume) if volume is not None else 0.0)
        )
        trade = None
        if snapshot is not None:
            trade = self._closed_trade_from_history(
                ticket, expected_volume=expected, snapshot=snapshot, fallback_reason=reason
            )
        if trade is not None:
            self._handled_close.add(ticket)
            return OrderAck(
                intent_id="",
                accepted=True,
                retcode=RETCODE_DONE,
                retcode_name="DONE",
                message="position was already closed",
                ticket=ticket,
                fill_price=trade.close_price,
                filled_volume=float(trade.volume),
                ts=Ts(datetime.now(tz=timezone.utc), _time.monotonic()),
                closed_trade=trade,
            )
        if snapshot is not None:
            self._pending_settlements.setdefault(ticket, snapshot)
        raise SubmitUncertain(
            f"position {ticket} is already closed but its closing deal is not visible yet"
        )

    def _fallback_closed_trade(
        self,
        ticket: int,
        volume: float,
        price: float,
        snapshot: PositionSnapshot,
        reason: str,
    ) -> ClosedTrade:
        direction = 1.0 if snapshot.side == "buy" else -1.0
        gross = (
            (float(price) - float(snapshot.open_price))
            * direction
            * float(self._info.contract_size)
            * float(volume)
        )
        close_time = datetime.now(tz=timezone.utc)
        inferred = self._infer_reason(str(reason or ""), snapshot, float(price))
        return ClosedTrade(
            ticket=Ticket(int(ticket)),
            symbol=snapshot.symbol,
            side=snapshot.side,
            volume=float(volume),
            open_price=float(snapshot.open_price),
            close_price=float(price),
            open_time=snapshot.open_time,
            close_time=close_time,
            pnl_gross=money(gross),
            commission=money(0.0),
            swap=money(0.0),
            reason=inferred,  # type: ignore[arg-type]
        )

    # -- settlement ------------------------------------------------------
    def _infer_reason(self, comment: str, snapshot: PositionSnapshot, close_price: float) -> str:
        text = (comment or "").lower()
        for reason in _KNOWN_CLOSE_REASONS:
            if reason in text:
                return reason
        tolerance = max(self._info.point * 2.0, 1e-9)
        if snapshot.sl is not None and abs(close_price - snapshot.sl) <= max(tolerance, 0.05):
            return "sl"
        if snapshot.tp is not None and abs(close_price - snapshot.tp) <= max(tolerance, 0.05):
            return "tp"
        return "manual"

    def _closed_trade_from_history(
        self,
        ticket: int,
        *,
        expected_volume: float,
        snapshot: PositionSnapshot,
        fallback_reason: str = "",
    ) -> ClosedTrade | None:
        try:
            raw_deals = self.mt5.history_deals_get(position=int(ticket)) or ()
        except Exception:  # noqa: BLE001 - history may lag the deal by a moment
            return None
        deals = [
            raw
            for raw in raw_deals
            if int(getattr(raw, "entry", -1)) == DEAL_ENTRY_OUT
            and int(getattr(raw, "ticket", 0)) not in self._reported_deals
        ]
        if not deals:
            return None
        deals.sort(key=lambda raw: int(getattr(raw, "time", 0)))
        volume = sum(abs(float(getattr(raw, "volume", 0.0) or 0.0)) for raw in deals)
        if volume <= 0.0:
            return None
        last = deals[-1]
        close_price = float(getattr(last, "price", 0.0) or 0.0)
        reason = self._infer_reason(str(getattr(last, "comment", "") or ""), snapshot, close_price)
        if fallback_reason and fallback_reason in _KNOWN_CLOSE_REASONS:
            reason = fallback_reason
        commission = -sum(float(getattr(raw, "commission", 0.0) or 0.0) for raw in deals)
        swap = sum(float(getattr(raw, "swap", 0.0) or 0.0) for raw in deals)
        gross = sum(float(getattr(raw, "profit", 0.0) or 0.0) for raw in deals)
        for raw in deals:
            self._reported_deals.add(int(getattr(raw, "ticket", 0)))
        return ClosedTrade(
            ticket=Ticket(int(ticket)),
            symbol=snapshot.symbol,
            side=snapshot.side,
            volume=min(volume, max(expected_volume, 0.0)) or volume,
            open_price=snapshot.open_price,
            close_price=close_price,
            open_time=snapshot.open_time,
            close_time=_from_server(getattr(last, "time", 0), self._offset),
            pnl_gross=money(gross),
            commission=money(commission),
            swap=money(swap),
            reason=reason,  # type: ignore[arg-type]
        )

    @property
    def pending_settlements(self) -> tuple[int, ...]:
        """Tickets whose closing deal is not visible yet (never dropped)."""
        return tuple(sorted(self._pending_settlements))

    def on_market_tick(self, tick: Tick) -> Sequence[ClosedTrade]:
        self._last_tick = tick
        self._last_tick_utc = tick.ts_recv.wall
        now = _time.monotonic()
        if now - self._last_poll < self._settlement_poll_s:
            return ()
        self._last_poll = now
        try:
            current = {int(position.ticket): position for position in self.positions()}
        except Exception:  # noqa: BLE001 - a failed poll is retried on the next tick
            log.exception("MT5 position poll failed")
            return ()
        closed: list[ClosedTrade] = []
        for ticket, snapshot in list(self._tracked.items()):
            if ticket in current or ticket in self._handled_close:
                continue
            trade = self._closed_trade_from_history(
                ticket, expected_volume=snapshot.volume, snapshot=snapshot
            )
            if trade is None:
                # MT5-02: a live position may never be forgotten because history
                # lagged the closing deal. Keep it tracked and retry next poll.
                self._pending_settlements[ticket] = snapshot
                warned = self._settlement_warned.get(ticket, 0)
                if warned < 3:
                    self._settlement_warned[ticket] = warned + 1
                    log.warning(
                        "position disappeared before its closing deal was visible; keeping it tracked",
                        extra={"fields": {"ticket": ticket, "attempt": warned + 1}},
                    )
                continue
            self._pending_settlements.pop(ticket, None)
            self._settlement_warned.pop(ticket, None)
            self._handled_close.add(ticket)
            closed.append(trade)
            log.info(
                "position settled from venue history",
                extra={
                    "fields": {
                        "ticket": ticket,
                        "volume": float(trade.volume),
                        "pnl_net": float(trade.pnl_net.amount),
                        "reason": trade.reason,
                    }
                },
            )
        # Keep tickets with a lagging closing deal in the tracked book so the next
        # poll retries them; otherwise the venue positions are the new truth.
        self._tracked = {**self._pending_settlements, **current}
        if closed:
            return tuple(closed)
        return ()

    # -- market data -----------------------------------------------------
    def _calibrate_skew(self, epoch: int, now: datetime) -> None:
        """Lock the sub-15-minute clock residual from the freshest tick seen.

        `_learn_offset` rounds the server offset to 15 minutes so DST is safe,
        which leaves up to +-450 s of PC/server clock skew in the timestamps. The
        staleness gate compares the tick with the PC clock, so that skew used to
        make every tick look old and blocked every entry. A stale feed can only
        lower the sample, so the maximum over the session is the true residual;
        a genuinely frozen feed still ages normally.
        """
        candidate = epoch - now.timestamp() - self._offset.total_seconds()
        if not (-450.0 <= candidate <= 450.0):
            return
        previous = self._skew_seconds
        if previous is None or candidate > previous:
            self._skew_seconds = candidate
            if previous is not None and abs(candidate - previous) >= 1.0:
                log.info(
                    "broker clock skew updated",
                    extra={"fields": {"skew_seconds": round(candidate, 3)}},
                )

    @property
    def _event_offset(self) -> timedelta:
        if self._skew_seconds is None:
            return self._offset
        return self._offset + timedelta(seconds=self._skew_seconds)

    def raw_tick(self) -> Tick | None:
        if not self._initialized:
            return None
        try:
            raw = self.mt5.symbol_info_tick(self._info.broker_symbol)
        except Exception:  # noqa: BLE001
            log.exception("symbol_info_tick failed")
            return None
        if raw is None:
            return None
        epoch = int(getattr(raw, "time", 0) or 0)
        bid = float(getattr(raw, "bid", 0.0) or 0.0)
        ask = float(getattr(raw, "ask", 0.0) or 0.0)
        if epoch <= 0 or bid <= 0.0 or ask <= 0.0:
            return None
        self._learn_offset(raw)
        now = datetime.now(tz=timezone.utc)
        self._calibrate_skew(epoch, now)
        return Tick(
            symbol=self._info.symbol,
            bid=bid,
            ask=ask,
            ts_event=Ts(_from_server(epoch, self._event_offset)),
            ts_recv=Ts(now, _time.monotonic()),
            volume=int(getattr(raw, "volume", 0) or 0),
        )


class MT5TickFeed:
    """Polling tick stream; the engine consumes it exactly like a tape."""

    def __init__(
        self,
        broker: MT5Broker,
        *,
        clock: Any = None,
        poll_s: float = 0.2,
        idle_log_s: float = 30.0,
        max_tick_age_s: float = 120.0,
    ) -> None:
        self._broker = broker
        self._clock = clock
        self._poll_s = max(0.05, float(poll_s))
        self._idle_log_s = max(1.0, float(idle_log_s))
        self._max_tick_age_s = max(10.0, float(max_tick_age_s))
        self._stopped = False
        self._last: Tick | None = None
        self._last_key: tuple[Any, ...] | None = None
        self._last_emit = 0.0
        self._last_idle_log = 0.0

    def stop(self) -> None:
        self._stopped = True

    def last_known(self, symbol: Symbol) -> Any:
        return self._last

    def staleness(self, symbol: Symbol, now: datetime) -> float:
        if self._last is None:
            return float("inf")
        return (utc(now) - self._last.ts_event.wall).total_seconds()

    def stream(self) -> Iterable[Tick]:
        while not self._stopped:
            try:
                tick = self._broker.raw_tick()
            except Exception:  # noqa: BLE001 - a bad read must not kill the feed
                log.exception("tick read failed")
                tick = None
            if tick is None:
                moment = _time.monotonic()
                if moment - self._last_idle_log >= self._idle_log_s:
                    self._last_idle_log = moment
                    log.warning("no tradable MT5 tick (market closed or disconnected)")
                _time.sleep(self._poll_s)
                continue
            # A closed market returns the last pre-close tick forever; it must
            # never be mistaken for a live price by the risk staleness check.
            if (datetime.now(tz=timezone.utc) - tick.ts_event.wall).total_seconds() > self._max_tick_age_s:
                moment = _time.monotonic()
                if moment - self._last_idle_log >= self._idle_log_s:
                    self._last_idle_log = moment
                    log.warning("MT5 tick is stale (market closed?)")
                _time.sleep(self._poll_s)
                continue
            key = (tick.ts_event.wall, tick.bid, tick.ask)
            moment = _time.monotonic()
            if key == self._last_key and (moment - self._last_emit) < 1.0:
                _time.sleep(self._poll_s)
                continue
            self._last_key = key
            self._last_emit = moment
            self._last = tick
            if self._clock is not None:
                setter = getattr(self._clock, "set_offset", None)
                if setter is not None:
                    setter(self._broker.offset)
            yield tick


def load_history(
    mt5_module: Any,
    *,
    broker_symbol: str,
    info: SymbolInfo,
    timeframes: Sequence[Timeframe],
    offset: timedelta,
    counts: dict[str, int] | None = None,
) -> dict[str, list[Bar]]:
    """Closed bars per timeframe, converted to UTC, for the warm-up seed."""
    counts = dict(counts or {})
    server_now = _time.time() + offset.total_seconds()
    out: dict[str, list[Bar]] = {}
    for timeframe in timeframes:
        constant = getattr(mt5_module, "TIMEFRAME_" + str(timeframe), None)
        if constant is None:
            out[str(timeframe)] = []
            continue
        try:
            rates = mt5_module.copy_rates_from_pos(
                broker_symbol, constant, 0, int(counts.get(str(timeframe), 9_600))
            )
        except Exception:  # noqa: BLE001 - a missing history is a degraded warm-up
            log.exception("copy_rates_from_pos failed", extra={"fields": {"timeframe": timeframe}})
            rates = None
        bars: list[Bar] = []
        seconds = TF_SECONDS[str(timeframe)]
        # copy_rates_from_pos returns a numpy array; do not use its truthiness.
        rows = rates if rates is not None else ()
        for rate in rows:
            open_epoch = int(rate["time"])
            if open_epoch + seconds > server_now + 1:
                continue
            bars.append(
                Bar(
                    symbol=info.symbol,
                    timeframe=timeframe,  # type: ignore[arg-type]
                    open_time=_from_server(open_epoch, offset),
                    o=float(rate["open"]),
                    h=float(rate["high"]),
                    l=float(rate["low"]),
                    c=float(rate["close"]),
                    tick_volume=int(rate["tick_volume"]),
                    spread_avg=float(_rate_value(rate, "spread", 0.0) or 0.0)
                    * float(info.point),
                    is_closed=True,
                )
            )
        out[str(timeframe)] = bars
    return out


def seed_builder(builder: Any, bars_by_timeframe: dict[str, list[Bar]]) -> int:
    """Fill a BarBuilder with historical closed bars; returns the row count."""
    total = 0
    for bars in bars_by_timeframe.values():
        if bars:
            builder.seed(bars)
            total += len(bars)
    return total

def symbol_info_from_broker(
    mt5_module: Any,
    *,
    broker_symbol: str,
    logical_name: str,
    broker_offset: timedelta,
    fallback: SymbolInfo | None = None,
) -> SymbolInfo:
    """Broker truth -> SymbolInfo. Sizing must never run on config guesses."""
    raw = mt5_module.symbol_info(broker_symbol)
    if raw is None:
        if fallback is None:
            raise MT5ConnectionError(f"symbol {broker_symbol!r} is not available")
        return replace_info(fallback, broker_offset=broker_offset)
    base = fallback
    filling_bits = int(getattr(raw, "filling_mode", 0) or 0)
    # MT5 filling_mode is a bitmask: FOK=1, IOC=2, RETURN=4, BOC=8.
    if filling_bits & 2:
        filling = "ioc"
    elif filling_bits & 1:
        filling = "fok"
    elif filling_bits & 4:
        filling = "return"
    else:
        filling = "unknown"
    trade_mode = _SYMBOL_TRADE_MODE.get(int(getattr(raw, "trade_mode", 4)), "full")
    return SymbolInfo(
        symbol=Symbol(logical_name),
        broker_symbol=broker_symbol,
        digits=int(getattr(raw, "digits", base.digits if base else 2)),
        point=float(getattr(raw, "point", base.point if base else 0.01)),
        tick_size=float(getattr(raw, "trade_tick_size", 0.0) or (base.tick_size if base else 0.01)),
        contract_size=float(
            getattr(raw, "trade_contract_size", base.contract_size if base else 100.0)
        ),
        min_volume=float(getattr(raw, "volume_min", base.min_volume if base else 0.01)),
        max_volume=float(getattr(raw, "volume_max", base.max_volume if base else 50.0)),
        volume_step=float(getattr(raw, "volume_step", base.volume_step if base else 0.01)),
        stops_level_points=int(
            getattr(raw, "trade_stops_level", base.stops_level_points if base else 0)
        ),
        freeze_level_points=int(
            getattr(raw, "trade_freeze_level", base.freeze_level_points if base else 0)
        ),
        margin_rate=float(base.margin_rate) if base is not None else 0.01,
        currency_profit=str(getattr(raw, "currency_profit", "USD") or "USD"),
        trade_mode=trade_mode,  # type: ignore[arg-type]
        sessions=base.sessions if base is not None else (
            SessionWindow(time(0, 0), time(23, 59)),
        ),
        broker_offset=broker_offset,
        swap_long=float(getattr(raw, "swap_long", 0.0) or 0.0),
        swap_short=float(getattr(raw, "swap_short", 0.0) or 0.0),
        tick_value=float(getattr(raw, "trade_tick_value", 0.0) or 0.0),
        filling_mode=filling,  # type: ignore[arg-type]
    )


def replace_info(info: SymbolInfo, **updates: Any) -> SymbolInfo:
    """Tiny helper to avoid importing dataclasses.replace at call sites."""
    from dataclasses import replace as _replace

    return _replace(info, **updates)
