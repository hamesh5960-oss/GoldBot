# GoldBot XAUUSD — Final Engineering Release 8.2.5

موتور معاملاتی GoldBot برای XAUUSD روی MetaTrader 5 با دو استراتژی `zones` و `numeric`، لایه‌های تصمیم و ریسک، ژورنال SQLite، پنل وب و آداپتور MT5.

> **وضعیت: READY FOR DEMO VALIDATION.**
> این بسته برای اجرای تحت نظارت روی حساب دمو آماده است. مجوز معامله با پول واقعی نیست: نتیجهٔ بک‌تست واقعی ۱۲۰ روزه منفی است، آزمون دمو کوتاه است و لبهٔ استراتژی روی دادهٔ مستقل اثبات نشده است.

## این نسخه چه تفاوتی با RC 8.2.5 دارد؟

نسخهٔ RC ناقص بود: فقط ۵۶ تست بازسازی‌شده داشت، P0های اجرای واقعی (بستن تکراری، flatten دروغین، عدم بازپذیرش پوزیشن پس از restart) باز بودند و اسنادش با کد نمی‌خواند. در این انتشار:

- کل مجموعهٔ تست تاریخی بازگردانده شد و به **۱٬۰۶۷ تست سبز** رسید (۰ خطا، حدود ۱۰۶ ثانیه).
- سه P0 و بیش از ۲۰ P1 شناسایی و رفع شد (فهرست کامل: `reports/audit/`).
- backtest واقعی ۱۲۰ روزه روی تاریخ MT5 با هزینه‌های واقعی اجرا و ثبت شد (نتیجه منفی، بدون پنهان‌کاری).
- رجیستری تعارض اسناد/کد، رجیستری ریسک و رجیستری تغییرات تولید شد.
- بستهٔ قابل استخراج و اجرا با SHA-256 ساخته شد.

## پیش‌نیازها

- Windows 10/11 یا Windows Server (برای MT5)؛ Linux فقط برای پنل/بک‌تست.
- Python 3.12+ (آزمون شده روی 3.14.7).
- نصب: `python -m pip install -e .`
- پنل: `python -m pip install -e ".[web]"`
- تست: `python -m pip install -e ".[test]"`
- MT5: `python -m pip install -e ".[mt5]"`
- استقرار پنل VPS: `python -m pip install -e ".[deploy]"`

## اجرای سریع

```powershell
python run_goldbot.py --help
python run_goldbot.py selftest
python -m pytest -q
python run_goldbot.py demo --days 10 --profile medium --db var/demo.db
python run_goldbot.py report --db var/demo.db --funnel
```

اجرای زنده روی حساب دمو (رمز فقط از محیط یا فایل):

```powershell
$env:GOLDBOT_MT5_LOGIN='<login>'
$env:GOLDBOT_MT5_PASSWORD_FILE='C:\secure\mt5.pw'
$env:GOLDBOT_MT5_SERVER='ePlanet-MT5'
$env:GOLDBOT_MT5_SYMBOL='XAUUSD.st'
python run_goldbot.py live --profile medium --db var/live.db --state-db var/live.state.db --cold-start
```

`--cold-start` فقط برای اولین اجرای زنده (نبودِ state db) لازم است؛ در اجرای بعدی عمداً رد می‌شود تا وضعیت ریسک قبلی نادیده گرفته نشود. رمز در argv پذیرفته **نمی‌شود** (SEC-02).

## خط لولهٔ تصمیم

1. سیگنال از `zones` یا `numeric`.
2. ناحیهٔ لایهٔ صفر و `Zone_Score`؛ بدون ناحیهٔ معتبر سیگنال D است و اجرا نمی‌شود.
3. پنج تأیید مستقل با مقادیر ۰/۰.۵/۱ (ADR-033) + یک امتیاز برای سیگنال قبلیِ استراتژی دیگر، فقط اگر آن سیگنال واقعاً وارد مسیر اجرا شده باشد و در پنجرهٔ ۳۰ دقیقه‌ای قبلی باشد.
4. هفت رأی لایهٔ سوم با وزن ۰.۲، سقف ±۱.۲، آستانهٔ ±۰.۶.
5. Tier پایه: `[0,1)=D`، `[1,2)=C`، `[2,3)=B`، `[3,4)=A`، `[4,6]=A+`؛ D کف سخت است.
6. R:R خالص < ۱.۰ رد می‌شود؛ R:R دیگر Tier را تغییر نمی‌دهد.
7. Gate A/B/C، بودجهٔ سفارش، سرمایه/Gate D، کنترل‌های اجرایی، ارسال و تطبیق سفارش.

## ریسک

| پروفایل | Tierها | سقف Tier | open risk | پوزیشن هم‌زمان |
|---|---|---|---|---|
| low | A/A+ | A=0.50٪، A+=0.75٪ | 1.5٪ | 1 |
| medium | A+/A/B/C | A+=1.00٪، A=0.75٪، B=0.50٪، C=0.25٪ | 3.0٪ | 2 |
| high | A+/A/B/C | همان ماتریس | 3.0٪ | 2 |

Gate D: soft 2.0٪ و hard 3.0٪ (hard فقط با ویرایش صریح پیکربندی از ۲٪ بالا رفته است؛ پیش‌فرض کد ۲٪ می‌ماند).

## ساختار بسته

```
src/goldbot/        موتور (domain, ports, app, adapters, runtime, strategy_api, web)
src/strategies/     استراتژی‌های zones و numeric
config/             base.toml + risk_profiles.toml + strategies/
tests/              1,084 تست (unit, integration, golden, chaos, failure injection, soak)
docs/               ADR 001-046، معماری، Live MT5، Runbook، SPEC
scripts/            launcher، watchdog، harvester، deploy پنل
reports/            ژورنال زنده، بک‌تست‌ها، audit و review
```

## مستندات

| فایل | محتوا |
|---|---|
| `INSTALLATION-GUIDE.md` | نصب، اجرا، Task Scheduler، عیب‌یابی |
| `CONFIGURATION-GUIDE.md` | همهٔ کلیدهای پیکربندی و دام‌ها |
| `TEST-REPORT.md` | نتیجهٔ اجرای واقعی تست‌ها |
| `BACKTEST-REPORT.md` | بک‌تست مصنوعی و واقعی + IS/OOS |
| `SECURITY-REPORT.md` | وضعیت secrets، پنل، SSH، لاگ |
| `KNOWN-ISSUES.md` | محدودیت‌ها و موارد باز |
| `RELEASE-MANIFEST.md` | دامنه، نسخه‌ها، چک‌سام |
| `reports/audit/` | رجیستری تعارض، ریسک، نقص و گزارش ۸ ممیزی مستقل |
| `reports/review/` | بازبینی مستقل تغییرات توسط تیم دیگر |

## هشدار

- بک‌تست واقعی ۱۲۰ روزه **منفی** است (PF 0.95). هیچ ادعای سودآوری وجود ندارد.
- توزیع Tier با هدف سند مالک فاصله دارد (A+ بیش از هدف)؛ تغییر آستانه بدون walk-forward مجاز نیست.
- معامله با پول واقعی مسدود است (`--allow-real` و ADR-030).
