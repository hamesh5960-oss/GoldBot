# GoldBot 8.2.5 — VPS deployment notes (2026-11-24)

Production host: **Windows Server 2022 Datacenter @ 213.176.21.205**

## Layout on the VPS

| Path | Purpose |
|---|---|
| `C:\GoldBot` | this source tree (editable install) |
| `C:\GoldBot\.venv` | dedicated virtualenv (Python 3.12) |
| `C:\GoldBot\var\live.db` | live journal (SQLite) |
| `C:\GoldBot\var\live_risk_state.db` | risk state (SQLite) |
| `C:\GoldBot\var\mt5.pw` | MT5 demo password file (do not commit) |
| `C:\GoldBot\var\panel_token.txt` | panel bearer token (do not commit) |
| `C:\Program Files\MetaTrader 5` | MetaTrader 5 terminal (official build 6328) |
| `C:\Users\Administrator\AppData\Roaming\MetaQuotes\Terminal\D0E8...` | terminal data dir (ePlanet servers/accounts) |

## Service management

```powershell
Start-ScheduledTask -TaskName GoldBot     # start panel + engine
Stop-ScheduledTask  -TaskName GoldBot     # stop them
Get-ScheduledTask   -TaskName GoldBot     # state
Get-Content C:\GoldBot\var\supervisor.log -Tail 20
Get-Content C:\GoldBot\var\engine.out.log -Tail 20
```

The task `GoldBot` runs at startup as `Administrator` (highest privileges, unlimited
runtime, restart-on-failure, single instance). It launches
`C:\GoldBot\goldbot_vps_supervisor.py`, which owns the panel (0.0.0.0:8200) and the
live engine.

## Health checks

```
GET http://213.176.21.205:8200/api/health   (Bearer token)
GET http://213.176.21.205:8200/api/status
```

## Operational rules

1. Do **not** launch `terminal64.exe` by hand while the service is running — the engine
   owns that terminal instance (session 0).
2. `--cold-start` is added automatically by the supervisor only when the risk-state
   DB is absent; normal restarts resume persisted state.
3. The panel is plain HTTP; put it behind TLS (Caddy/nginx) before exposing it widely.
4. Rotate `var\mt5.pw` and `var\panel_token.txt` after any credential change.

## Why the broker symbol is selected explicitly

`MT5Broker._ensure_symbol` now selects the configured symbol when it exists but is not
visible in Market Watch. Without that, a freshly launched terminal returns an all-zero
tick, which the live runner interprets as “market closed”.
