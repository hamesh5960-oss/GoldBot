"""GoldBot VPS supervisor: keeps the panel and the live MT5 demo engine alive."""
from __future__ import annotations

import os
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
VAR = ROOT / "var"
LOG = VAR / "supervisor.log"
LOCK = VAR / "supervisor.lock"
PY = sys.executable

PANEL_TOKEN = (VAR / "panel_token.txt").read_text(encoding="utf-8").strip() if (VAR / "panel_token.txt").exists() else ""
PANEL_PORT = 8200
STATE_DB = VAR / "live_risk_state.db"
MT5_PW_FILE = VAR / "mt5.pw"
MT5_PATH = r"C:\Program Files\MetaTrader 5\terminal64.exe"

CHILDREN: dict[str, tuple] = {}


def log(msg: str) -> None:
    line = time.strftime("%Y-%m-%d %H:%M:%S ") + msg
    print(line, flush=True)
    try:
        with LOG.open("a", encoding="utf-8") as fh:
            fh.write(line + "\n")
    except OSError:
        pass


def _open(name: str, header: str):
    # A transient disk/AV error must never stop the supervisor from starting
    # a child; fall back to discarding output rather than raising.
    try:
        fh = (VAR / name).open("a", encoding="utf-8", buffering=1)
        fh.write("\n===== " + header + " =====\n")
        fh.flush()
        return fh
    except OSError as exc:
        log("log open failed for %s: %s" % (name, exc))
        return subprocess.DEVNULL


def spawn_panel() -> subprocess.Popen:
    env = dict(os.environ, GOLDBOT_PANEL_TOKEN=PANEL_TOKEN, PYTHONIOENCODING="utf-8")
    out = _open("panel.out.log", time.strftime("panel start %Y-%m-%d %H:%M:%S"))
    return subprocess.Popen(
        [PY, "-u", "run_goldbot.py", "serve", "--host", "0.0.0.0", "--port", str(PANEL_PORT)],
        cwd=str(ROOT), env=env, stdout=out, stderr=subprocess.STDOUT,
    )


def spawn_engine() -> subprocess.Popen:
    args = [PY, "-u", "run_goldbot.py", "live", "--profile", "medium"]
    if not STATE_DB.exists():
        args.append("--cold-start")
    env = dict(
        os.environ,
        GOLDBOT_MT5_LOGIN="80180927",
        GOLDBOT_MT5_PASSWORD_FILE=str(MT5_PW_FILE),
        GOLDBOT_MT5_SERVER="ePlanet-MT5",
        GOLDBOT_MT5_SYMBOL="XAUUSD.st",
        GOLDBOT_MT5_PATH=MT5_PATH,
        PYTHONIOENCODING="utf-8",
    )
    out = _open("engine.out.log", time.strftime("engine start %Y-%m-%d %H:%M:%S"))
    return subprocess.Popen(args, cwd=str(ROOT), env=env, stdout=out, stderr=subprocess.STDOUT)


def main() -> int:
    VAR.mkdir(parents=True, exist_ok=True)
    log("VPS supervisor starting pid=%d python=%s" % (os.getpid(), PY))
    CHILDREN["panel"] = (spawn_panel, None)
    time.sleep(2)
    CHILDREN["engine"] = (spawn_engine, None)
    for name, (factory, _proc) in list(CHILDREN.items()):
        try:
            proc = factory()
            CHILDREN[name] = (factory, proc)
            log("%s started pid=%d" % (name, proc.pid))
        except Exception as exc:  # noqa: BLE001
            log("%s start failed: %s" % (name, exc))
    while True:
        time.sleep(15)
        for name, (factory, proc) in list(CHILDREN.items()):
            try:
                alive = proc is not None and proc.poll() is None
            except Exception as exc:  # noqa: BLE001
                log("%s poll failed: %s" % (name, exc))
                alive = False
            if alive:
                continue
            rc = None if proc is None else proc.returncode
            log("%s exited rc=%s; restarting" % (name, rc))
            time.sleep(3)
            try:
                new_proc = factory()
                CHILDREN[name] = (factory, new_proc)
                log("%s restarted pid=%d" % (name, new_proc.pid))
            except Exception as exc:  # noqa: BLE001
                log("%s restart failed: %s" % (name, exc))
                time.sleep(30)


if __name__ == "__main__":
    raise SystemExit(main())
