# Performance Baseline — 8.2.5 Final

اندازه‌گیری‌ها روی Windows 11 / Python 3.14.7 (ممکن است با بار همزمان سیستم ±۲۰٪ تغییر کند).

| سناریو | ticks | bars | trades | wall |
|---|---:|---:|---:|---:|
| demo 10 روزه | 20,161 | 672 | 14 | **22.1 s** |
| demo 100 روزه | 204,480 | 6,815 | 147 | **200.8 s** |
| backtest واقعی 120 روزه (M15 → tape) | 79,031 | 7,903 | 147 | **203.6 s** |
| harvest واقعی 120 روزه از MT5 | — | 7,903 | — | **2.2 s** |
| full test suite (1,084 تست) | — | — | — | **128.0 s** |

## نکات

- flush شدن کندل آخر (اصلاح D01) یک تیک و یک کندل به آمار دموی ۱۰ روزه اضافه کرد؛ اقتصاد بدون تغییر ماند و زمان اجرا از ۳۰s به ۲۲s رسید.
- اعتبارسنجی eager فایل tape حدود ۱ ثانیه برای tape ۴.۴ مگابایتی هزینه دارد و در عوض هیچ replay نیمه‌کاره‌ای رخ نمی‌دهد.
- نقاط داغ باقی‌مانده: commitهای SQLite (journal/state)، ساخت bar و warm-up اولیه؛ بهینه‌سازی بیشتر فقط با پروفایل و بدون تغییر رفتار استراتژی مجاز است.

## بازتولید

```powershell
python run_goldbot.py demo --days 10 --profile medium --db var/perf10.db
python run_goldbot.py demo --days 100 --profile medium --db var/perf100.db
python scripts/harvest_mt5_tape.py --days 120 --out var/xauusd_st_m15_120d.jsonl
python run_goldbot.py backtest --tape var/xauusd_st_m15_120d.jsonl --profile medium --db var/real.db
```
