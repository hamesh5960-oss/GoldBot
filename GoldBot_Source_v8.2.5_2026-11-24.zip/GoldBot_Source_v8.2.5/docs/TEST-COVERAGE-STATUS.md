# وضعیت پوشش تست — 8.2.5 Final

## واقعیت نسخهٔ RC

ZIP ورودی RC هیچ پوشهٔ `tests/` نداشت؛ ادعای ۸۳۷ تست از روی همان بسته قابل بازتولید نبود. پکیج‌کننده ۱۱ فایل تست و ۵۶ تست بازسازی کرده بود.

## وضعیت این انتشار

- مجموعهٔ کامل تست تاریخی از مخزن توسعه بازیابی و با مالکیت همان کد اجرا شد.
- **1,084 تست** در 80 فایل، همه PASS، در ≈106 ثانیه (Python 3.14.7، Windows).
- تست‌های افزوده‌شده در این انتشار: failure injection (اجرا/venue و persistence/data)، soak/performance، idempotent close، position adoption، magic identity، open-risk truth، tape validation، bar-builder edge، retcodes، arbiter confirmation identity، config consistency.

## آنچه هنوز اثبات نشده

- اجرای سفارش واقعی روی venue (بازار در زمان آزمون بسته بود).
- netting adoption (fail-closed است و تست ندارد).
- رفتار settlement با history چندروزهٔ واقعی بروکر در حجم بالا.
- soak چند ساعته روی VPS (تست soak محدود است).

## اجرای تست

```powershell
python -m pytest -q                 # کامل ≈128s
$env:GOLDBOT_SOAK='0'; python -m pytest -q   # بدون soak
python -m pytest tests/test_close_idempotency.py tests/test_failure_injection_execution.py -q
```
