"""Numeric strategy.

The base number comes from the last two digits of the anchor price: add the
units and tens digit, then map the sum to 12/15/18. Entries sit at multiples of
that base measured from the swing high (downwards) or the swing low (upwards);
a stopped level steps to the next multiple and arms a pullback reversal.

Exit geometry is the same as the S/R strategy (1.1): the stop sits behind the
swing/level structure with an ATR buffer, and the target is the next liquidity
pool clamped to 2R..3R.
"""

from __future__ import annotations

from typing import Sequence

from pydantic import BaseModel, ConfigDict, Field

from goldbot.strategy_api import (
    Bar,
    BaseStrategy,
    Signal,
    StrategyContext,
    TradeSummary,
    Zone,
    entry_signal,
    indicators,
)

SET_12 = {1, 4, 7, 10, 13, 16}
SET_15 = {2, 5, 8, 11, 14, 17}
SET_18 = {3, 6, 9, 12, 15, 18}


def base_from_price(price: float) -> int:
    """Map the units+tens digit sum of price to the 12/15/18 base.

    The document reads the digits from the truncated integer price
    (4136.87 -> "36"), not the rounded one.
    """
    digits = abs(int(price)) % 100
    total = digits // 10 + digits % 10
    if total in SET_12:
        return 12
    if total in SET_15:
        return 15
    if total in SET_18:
        return 18
    return 12


def _clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


class NumericParams(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    pip_size: float = Field(default=0.1, gt=0)
    # Fallback stop only when ATR is unavailable (first bars of a tape).
    sl_pips: float = Field(default=50.0, gt=0, le=500)
    atr_period: int = Field(default=14, ge=2, le=100)
    sl_atr: float = Field(default=1.5, ge=0.5, le=4.0)
    tp_min_r: float = Field(default=2.0, ge=1.0, le=5.0)
    tp_max_r: float = Field(default=3.0, ge=1.0, le=6.0)

    max_level: int = Field(default=3, ge=1, le=6)
    swing_span: int = Field(default=2, ge=1, le=10)
    pullback_pips: float = Field(default=20.0, ge=0, le=500)
    early_entry_pips: float = Field(default=0.0, ge=0, le=50)
    lookback: int = Field(default=120, ge=30, le=500)

    allow_long: bool = True
    allow_short: bool = True


class NumericStrategy(BaseStrategy):
    id = "numeric"
    version = "1.1.0"
    warmup_bars = 160
    max_concurrent_positions = 1

    def __init__(self, *, params: NumericParams, risk_multiplier: float = 1.0) -> None:
        super().__init__(params=params, risk_multiplier=risk_multiplier)
        self._anchor_high: float | None = None
        self._anchor_low: float | None = None
        self._level = 1
        self._side = "long"
        self._reversal_side: str | None = None
        self._reversal_ref: float = 0.0
        self._last_signal_time = None

    def on_init(self, ctx: StrategyContext) -> None:
        self._anchor_high = None
        self._anchor_low = None
        self._level = 1
        self._reversal_side = None

    # ------------------------------------------------------------------
    def on_bar(self, ctx: StrategyContext, bar: Bar) -> Sequence[Signal]:
        p: NumericParams = self.params
        if ctx.positions():
            return ()

        bars = ctx.bars(bar.timeframe, p.lookback)
        if len(bars) < max(40, p.swing_span * 4):
            return ()

        high, low = self._swings(bars, p.swing_span)
        if high is None or low is None:
            return ()

        if self._anchor_high is None or high[1] > self._anchor_high:
            self._anchor_high = high[1]
        if self._anchor_low is None or low[1] < self._anchor_low:
            self._anchor_low = low[1]

        side = "long" if high[0] > low[0] else "short"
        if side != self._side:
            self._side = side
            self._level = 1
            self._reversal_side = None

        atr = indicators.atr(bars, p.atr_period)
        zones = ctx.zones()

        if self._reversal_side is not None:
            if self._reversal_side == "short" and bar.c < self._reversal_ref:
                signal = self._build(ctx, bars, bar, "sell", "numeric_pullback_reversal", atr, zones, low[1])
                self._reversal_side = None
                return (signal,)
            if self._reversal_side == "long" and bar.c > self._reversal_ref:
                signal = self._build(ctx, bars, bar, "buy", "numeric_pullback_reversal", atr, zones, high[1])
                self._reversal_side = None
                return (signal,)
            return ()

        if self._side == "long" and p.allow_long and self._anchor_high is not None:
            base = base_from_price(self._anchor_high)
            level_price = self._anchor_high - self._level * base
            offset = indicators.pips_to_price(p.early_entry_pips, p.pip_size)
            trigger = level_price + offset
            if bar.l <= trigger <= bar.h:
                self._last_signal_time = bar.open_time
                return (
                    self._build(
                        ctx, bars, bar, "buy", f"numeric_level_{self._level}", atr, zones, low[1]
                    ),
                )

        if self._side == "short" and p.allow_short and self._anchor_low is not None:
            base = base_from_price(self._anchor_low)
            level_price = self._anchor_low + self._level * base
            offset = indicators.pips_to_price(p.early_entry_pips, p.pip_size)
            trigger = level_price - offset
            if bar.l <= trigger <= bar.h:
                self._last_signal_time = bar.open_time
                return (
                    self._build(
                        ctx, bars, bar, "sell", f"numeric_level_{self._level}", atr, zones, high[1]
                    ),
                )
        return ()

    # ------------------------------------------------------------------
    def _build(
        self,
        ctx: StrategyContext,
        bars: Sequence[Bar],
        bar: Bar,
        side: str,
        pattern: str,
        atr: float | None,
        zones: Sequence[Zone],
        swing: float | None = None,
    ) -> Signal:
        p: NumericParams = self.params
        digits = ctx.symbol_info.digits
        entry = bar.c
        base = base_from_price(self._anchor_high if side == "buy" else (self._anchor_low or entry))
        level_price = (
            (self._anchor_high or entry) - self._level * base
            if side == "buy"
            else (self._anchor_low or entry) + self._level * base
        )

        if atr and atr > 0 and p.sl_atr > 0:
            anchor = swing if swing is not None else level_price
            if side == "buy":
                anchor = min(anchor, bar.l, level_price)
                stop = anchor - p.sl_atr * atr
            else:
                anchor = max(anchor, bar.h, level_price)
                stop = anchor + p.sl_atr * atr
            sl_mode = "structure"
        else:
            risk = indicators.pips_to_price(p.sl_pips, p.pip_size)
            stop = entry - risk if side == "buy" else entry + risk
            anchor = stop
            sl_mode = "fixed"

        stops_level = ctx.symbol_info.stops_level_points * ctx.symbol_info.point
        if abs(entry - stop) < stops_level:
            stop = entry - stops_level if side == "buy" else entry + stops_level

        risk = abs(entry - stop)
        reward, target_zone = self._zone_target(side, entry, risk, zones, atr or 0.0, p)
        target = entry + reward if side == "buy" else entry - reward
        return entry_signal(
            slot=ctx.slot,
            symbol=ctx.symbol,
            side=side,  # type: ignore[arg-type]
            stop=round(stop, digits),
            target=round(target, digits),
            entry_hint=round(entry, digits),
            rationale=f"{pattern} base={base} level={self._level}",
            tags={
                "pattern": pattern,
                "setup_type": "numeric_grid" if "level" in pattern else "numeric_pullback",
                "base": base,
                "level": self._level,
                "anchor_high": self._anchor_high,
                "anchor_low": self._anchor_low,
                "sl_mode": sl_mode,
                "sl_atr": p.sl_atr,
                "stop_anchor": round(anchor, 2),
                "rr": round(reward / risk, 2) if risk > 0 else 0.0,
                "target_zone": target_zone,
                "confirmation_tools": ["zone_target"] if target_zone else [],
                "quality_source": "numeric",
            },
        )

    @staticmethod
    def _zone_target(
        side: str,
        entry: float,
        risk: float,
        zones: Sequence[Zone],
        atr: float,
        p: NumericParams,
    ) -> tuple[float, str]:
        pools: list[tuple[float, str]] = []
        for zone in zones:
            if side == "buy" and atr > 0 and zone.low > entry + 0.3 * atr:
                pools.append((zone.low, zone.zone_id))
            elif side == "sell" and atr > 0 and zone.high < entry - 0.3 * atr:
                pools.append((zone.high, zone.zone_id))
        if pools and risk > 0:
            # Nearest pool in either direction: min(|level - entry|).
            pool, zone_id = min(pools, key=lambda item: abs(item[0] - entry))
            reward = abs(pool - entry) * 0.95
            rr = _clamp(reward / risk, p.tp_min_r, p.tp_max_r)
            return (rr * risk, zone_id)
        return (p.tp_min_r * risk, "")

    # ------------------------------------------------------------------
    def on_close(self, ctx: StrategyContext, trade: TradeSummary) -> None:
        """A stop advances the grid and can arm the pullback reversal."""
        p: NumericParams = self.params
        if trade.reason != "sl":
            return
        if trade.side == "buy" and self._side == "long":
            self._level = min(p.max_level, self._level + 1)
            pullback = indicators.pips_to_price(p.pullback_pips, p.pip_size)
            self._reversal_ref = trade.entry_price - pullback
            self._reversal_side = "short"
        elif trade.side == "sell" and self._side == "short":
            self._level = min(p.max_level, self._level + 1)
            pullback = indicators.pips_to_price(p.pullback_pips, p.pip_size)
            self._reversal_ref = trade.entry_price + pullback
            self._reversal_side = "long"

    # ------------------------------------------------------------------
    @staticmethod
    def _swings(bars: Sequence[Bar], span: int) -> tuple[tuple[int, float] | None, tuple[int, float] | None]:
        """Most recent fractal high/low (a wick beyond both neighbours)."""
        last_high: tuple[int, float] | None = None
        last_low: tuple[int, float] | None = None
        for i in range(len(bars) - span - 1, span - 1, -1):
            window_h = [b.h for b in bars[i - span : i + span + 1]]
            window_l = [b.l for b in bars[i - span : i + span + 1]]
            if last_high is None and bars[i].h == max(window_h) and window_h.count(bars[i].h) == 1:
                last_high = (i, bars[i].h)
            if last_low is None and bars[i].l == min(window_l) and window_l.count(bars[i].l) == 1:
                last_low = (i, bars[i].l)
            if last_high is not None and last_low is not None:
                break
        return last_high, last_low
