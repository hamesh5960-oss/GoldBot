"""Strategy registry: the only place that knows which plugins exist.

Adding a strategy = add a package + one entry here + one TOML file.
The core is never touched. Version 1.0 ships exactly two strategies: the
auto S/R zones strategy and the untouched numeric grid.
"""

from __future__ import annotations

import tomllib
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from pydantic import BaseModel

from goldbot.domain.errors import ConfigError
from goldbot.strategy_api import BaseStrategy

from .numeric import NumericParams, NumericStrategy
from .zones import ZonesParams, ZonesStrategy


@dataclass(frozen=True)
class StrategySpec:
    id: str
    factory: type[BaseStrategy]
    params_model: type[BaseModel]
    default_timeframe: str
    description: str


REGISTRY: dict[str, StrategySpec] = {
    "zones": StrategySpec(
        "zones",
        ZonesStrategy,
        ZonesParams,
        "M15",
        "Auto S/R zones: rejection, sweep and reclaim, break and retest",
    ),
    "numeric": StrategySpec(
        "numeric",
        NumericStrategy,
        NumericParams,
        "M15",
        "Numeric base 12/15/18 grid from swing anchors, with pullback reversal",
    ),
}


@dataclass
class StrategyInstance:
    slot: str
    strategy_id: str
    timeframe: str
    risk_multiplier: float
    params: dict[str, Any] = field(default_factory=dict)
    enabled: bool = True
    confirm_only: bool = False

    def build(self) -> BaseStrategy:
        spec = REGISTRY.get(self.strategy_id)
        if spec is None:
            raise ConfigError(f"unknown strategy '{self.strategy_id}'; known: {sorted(REGISTRY)}")
        params = spec.params_model.model_validate(self.params)
        return spec.factory(params=params, risk_multiplier=self.risk_multiplier)


def available() -> list[str]:
    return sorted(REGISTRY)


def load_instances(directory: str | Path, *, include_disabled: bool = False) -> list[StrategyInstance]:
    path = Path(directory)
    if not path.exists():
        return []
    instances: list[StrategyInstance] = []
    for file in sorted(path.glob("*.toml")):
        raw = tomllib.loads(file.read_text(encoding="utf-8"))
        enabled = bool(raw.get("enabled", True))
        if not enabled and not include_disabled:
            continue
        strategy_id = raw.get("strategy") or raw.get("id") or file.stem
        if strategy_id not in REGISTRY:
            raise ConfigError(f"{file.name}: unknown strategy '{strategy_id}'")
        spec = REGISTRY[strategy_id]
        slot = raw.get("slot", f"{strategy_id}_{raw.get('timeframe', spec.default_timeframe)}")
        instances.append(
            StrategyInstance(
                slot=slot,
                strategy_id=strategy_id,
                timeframe=raw.get("timeframe", spec.default_timeframe),
                risk_multiplier=float(raw.get("risk_multiplier", 1.0)),
                params=dict(raw.get("params", {})),
                enabled=enabled,
                confirm_only=bool(raw.get("confirm_only", False)),
            )
        )
    return instances
