"""Support/resistance zone strategy (replaces the hand-drawn rectangle).

Zones come from the shared engine and now include the daily levels of the last
completed broker day (PDH/PDL/PDC/pivot/R1/S1), operator rectangles and H1 swing
zones, in that order of precedence.

Entries are only taken when price interacts with a zone:
* rejection     - wick into the zone, close back out with the candle's body;
* sweep         - liquidity taken beyond the zone, price reclaims it;
* break_retest  - a confirmed break and the first pullback holding the edge.

Every signal carries signal_score, zone_score, setup_type, zone source and the
confirmation tags (RSI, relative volume, candle pattern) so the decision matrix
and the journal can grade it without re-deriving anything.
"""

from __future__ import annotations

from typing import Literal, Sequence

from pydantic import BaseModel, ConfigDict, Field

from goldbot.strategy_api import (
    Bar,
    BaseStrategy,
    Signal,
    StrategyContext,
    Zone,
    entry_signal,
    exit_signal,
    indicators,
    source_rank,
)


def _clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


class ZonesParams(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    atr_period: int = Field(default=14, ge=2, le=100)
    sl_atr: float = Field(default=1.5, ge=0.5, le=4.0, description="stop buffer behind structure")
    tp_min_r: float = Field(default=2.0, ge=1.0, le=5.0)
    tp_max_r: float = Field(default=3.0, ge=1.0, le=6.0)

    min_zone_score: int = Field(default=40, ge=0, le=100)
    min_signal_score: float = Field(default=0.3, ge=0.0, le=2.0)

    h1_window: int = Field(default=200, ge=50, le=600)
    ema_period: int = Field(default=200, ge=20, le=400)
    adx_period: int = Field(default=14, ge=5, le=50)
    rsi_period: int = Field(default=14, ge=5, le=50)
    volume_period: int = Field(default=20, ge=5, le=100)

    break_buffer_atr: float = Field(default=0.25, ge=0.0, le=2.0)
    retest_tolerance_atr: float = Field(default=0.10, ge=0.0, le=1.0)
    retest_bars: int = Field(default=8, ge=1, le=40)
    invalidate_atr: float = Field(default=1.0, ge=0.0, le=3.0)
    # "fixed" keeps invalidate_atr; "dynamic" scales it 0.8..1.5 with ATR ratio.
    invalidate_mode: Literal["fixed", "dynamic"] = "fixed"

    max_zone_distance_atr: float = Field(default=1.2, ge=0.2, le=3.0)

    allow_long: bool = True
    allow_short: bool = True


class ZonesStrategy(BaseStrategy):
    id = "zones"
    version = "1.1.0"
    warmup_bars = 240
    max_concurrent_positions = 1
    # The daily S/R plan is the primary one; it bypasses the confluence count
    # but never removes a competing signal from the bar.
    priority = 10

    def __init__(self, *, params: ZonesParams, risk_multiplier: float = 1.0) -> None:
        super().__init__(params=params, risk_multiplier=risk_multiplier)
        self._bar_index = 0
        self._armed: dict[str, int] = {}
        self._pending_zone: Zone | None = None
        self._pending_side: str | None = None
        self._zone_of_ticket: dict[int, Zone] = {}

    def on_init(self, ctx: StrategyContext) -> None:
        self._armed.clear()
        self._pending_zone = None
        self._pending_side = None
        self._zone_of_ticket.clear()

    # ------------------------------------------------------------------
    def on_bar(self, ctx: StrategyContext, bar: Bar) -> Sequence[Signal]:
        p: ZonesParams = self.params
        if bar.timeframe != "M15":
            return ()
        self._bar_index += 1

        exits = self._manage(ctx, bar)
        if exits:
            return exits
        if ctx.positions():
            return ()

        bars = ctx.bars("M15", 800)
        if len(bars) < 120:
            return ()
        zones = ctx.zones()
        if not zones:
            return ()

        h1 = indicators.resample(bars, "H1")[-p.h1_window :]
        atr = indicators.atr(bars, p.atr_period)
        atr_h1 = indicators.atr(h1, p.atr_period)
        if not atr or atr <= 0 or not atr_h1:
            return ()

        closes = [b.c for b in h1]
        period = p.ema_period if len(closes) >= p.ema_period else max(20, len(closes) // 2)
        series = indicators.ema_series(closes, period)
        ema = series[-1] if series else None
        ema_prev = series[-11] if len(series) >= 11 else None
        adx_h1 = indicators.adx(h1, p.adx_period)
        rsi_m15 = indicators.rsi([b.c for b in bars], p.rsi_period)
        relative_volume = indicators.volume_ratio(bars, p.volume_period)
        previous_bar = bars[-2]

        self._arm_breaks(bar, zones, atr, p)
        for zone in sorted(zones, key=lambda item: (source_rank(item), -item.score)):
            if zone.score < p.min_zone_score:
                continue
            if abs(zone.mid - bar.c) > p.max_zone_distance_atr * atr:
                continue
            setup = self._setup(bar, zone, atr, p)
            if setup is None:
                continue
            side, pattern, reaction = setup
            if side == "buy" and not p.allow_long:
                continue
            if side == "sell" and not p.allow_short:
                continue
            candle = self._candle_pattern(previous_bar, bar, side)
            score = self._signal_score(
                side,
                reaction,
                bar,
                zone,
                atr,
                ema,
                ema_prev,
                adx_h1,
                rsi_m15,
                relative_volume,
                candle,
            )
            if score < p.min_signal_score:
                continue
            return (
                self._build(
                    ctx,
                    bar,
                    side,
                    pattern,
                    zone,
                    score,
                    atr,
                    zones,
                    candle,
                    relative_volume,
                    rsi_m15,
                ),
            )
        return ()

    # ------------------------------------------------------------------
    def _arm_breaks(self, bar: Bar, zones: Sequence[Zone], atr: float, p: ZonesParams) -> None:
        buffer = p.break_buffer_atr * atr
        for zone in zones:
            if bar.c > zone.high + buffer and bar.o <= zone.high + buffer:
                self._armed[f"{zone.zone_id}:buy"] = self._bar_index + p.retest_bars
            if bar.c < zone.low - buffer and bar.o >= zone.low - buffer:
                self._armed[f"{zone.zone_id}:sell"] = self._bar_index + p.retest_bars

    def _setup(self, bar: Bar, zone: Zone, atr: float, p: ZonesParams) -> tuple[str, str, float] | None:
        buffer = p.break_buffer_atr * atr
        tolerance = p.retest_tolerance_atr * atr

        for side in ("buy", "sell"):
            key = f"{zone.zone_id}:{side}"
            expiry = self._armed.get(key)
            if expiry is not None and self._bar_index > expiry:
                self._armed.pop(key, None)
                expiry = None
            if expiry is not None:
                if side == "buy" and bar.l <= zone.high + tolerance and bar.c > zone.high and bar.o >= zone.low:
                    return ("buy", "break_retest", 0.85)
                if side == "sell" and bar.h >= zone.low - tolerance and bar.c < zone.low and bar.o <= zone.high:
                    return ("sell", "break_retest", 0.85)

        if bar.l < zone.low and bar.c > zone.high:
            return ("buy", "sweep_reclaim", 1.0)
        if bar.h > zone.high and bar.c < zone.low:
            return ("sell", "sweep_reclaim", 1.0)

        if bar.l <= zone.high and bar.c > zone.high + tolerance and bar.c > bar.o:
            return ("buy", "rejection", 0.65)
        if bar.h >= zone.low and bar.c < zone.low - tolerance and bar.c < bar.o:
            return ("sell", "rejection", 0.65)

        if bar.c > zone.high + buffer and bar.o <= zone.high + buffer:
            self._armed[key] = self._bar_index + p.retest_bars
        if bar.c < zone.low - buffer and bar.o >= zone.low - buffer:
            self._armed[key] = self._bar_index + p.retest_bars
        return None

    @staticmethod
    def _candle_pattern(previous: Bar, bar: Bar, side: str) -> str:
        if indicators.is_pin_bar(bar, side):
            return "pin"
        if indicators.is_engulfing(previous, bar, side):
            return "engulfing"
        return ""

    def _signal_score(
        self,
        side: str,
        reaction: float,
        bar: Bar,
        zone: Zone,
        atr: float,
        ema: float | None,
        ema_prev: float | None,
        adx_h1: float | None,
        rsi_m15: float | None,
        relative_volume: float | None,
        candle: str,
    ) -> float:
        bonus = 0.0
        if relative_volume is not None and relative_volume >= 1.2:
            bonus += 0.10
        if candle:
            bonus += 0.15
        f1 = _clamp(reaction + bonus, 0.0, 1.0)

        f2 = 0.0
        aligned = False
        if ema is not None and ema > 0:
            aligned = (side == "buy" and bar.c > ema) or (side == "sell" and bar.c < ema)
            f2 += 0.5 if aligned else -0.5
            if ema_prev is not None:
                rising = ema > ema_prev
                f2 += 0.2 if ((side == "buy") == rising) else -0.1
        if adx_h1 is not None and adx_h1 >= 25:
            f2 += 0.2 if aligned else -0.2
        if rsi_m15 is not None:
            if side == "buy":
                if rsi_m15 > 75:
                    f2 -= 0.20
                elif 45 <= rsi_m15 <= 70:
                    f2 += 0.10
            else:
                if rsi_m15 < 25:
                    f2 -= 0.20
                elif 30 <= rsi_m15 <= 55:
                    f2 += 0.10
        f2 = _clamp(f2, -1.0, 1.0)

        direction = 1.0 if side == "buy" else -1.0
        body = (bar.c - bar.o) * direction
        span = max(bar.h - bar.l, atr * 0.25)
        close_position = (bar.c - bar.l) / span if side == "buy" else (bar.h - bar.c) / span
        f3 = _clamp(
            0.7 * _clamp(close_position, 0.0, 1.0) + 0.3 * _clamp((body / atr) * 2.0, -1.0, 1.0),
            -1.0,
            1.0,
        )

        f4 = _clamp(zone.score / 100.0, 0.0, 1.0)
        f5 = self._session_factor(bar.open_time)

        return (25.0 * f1 + 20.0 * f2 + 20.0 * f3 + 20.0 * f4 + 15.0 * f5) / 50.0

    @staticmethod
    def _session_factor(open_time) -> float:
        hour = open_time.hour
        if 7 <= hour <= 16:
            return 1.0
        if 17 <= hour <= 21:
            return 0.9
        if hour <= 6:
            return 0.4
        return 0.3

    def _build(
        self,
        ctx: StrategyContext,
        bar: Bar,
        side: str,
        pattern: str,
        zone: Zone,
        score: float,
        atr: float,
        zones: Sequence[Zone],
        candle: str,
        relative_volume: float | None,
        rsi_m15: float | None,
    ) -> Signal:
        p: ZonesParams = self.params
        digits = ctx.symbol_info.digits
        entry = bar.c
        anchor = bar.l if side == "buy" else bar.h
        if side == "buy":
            anchor = min(anchor, zone.low)
            stop = anchor - p.sl_atr * atr
        else:
            anchor = max(anchor, zone.high)
            stop = anchor + p.sl_atr * atr

        stops_level = ctx.symbol_info.stops_level_points * ctx.symbol_info.point
        if abs(entry - stop) < stops_level:
            stop = entry - stops_level if side == "buy" else entry + stops_level

        risk = abs(entry - stop)
        reward = self._liquidity_reward(side, entry, zones, atr, risk, p)
        target = entry + reward if side == "buy" else entry - reward

        tools: list[str] = []
        if relative_volume is not None and relative_volume >= 1.2:
            tools.append("volume")
        if candle:
            tools.append(f"pattern_{candle}")
        if rsi_m15 is not None:
            rsi_ok = (45 <= rsi_m15 <= 70) if side == "buy" else (30 <= rsi_m15 <= 55)
            if rsi_ok:
                tools.append("rsi")
        if zone.source == "daily":
            tools.append(f"daily_{zone.note.lower() or 'level'}")

        self._pending_zone = zone
        self._pending_side = side
        setup_type = "sweep" if pattern == "sweep_reclaim" else pattern
        return entry_signal(
            slot=ctx.slot,
            symbol=ctx.symbol,
            side=side,  # type: ignore[arg-type]
            stop=round(stop, digits),
            target=round(target, digits),
            entry_hint=round(entry, digits),
            rationale=(
                f"{pattern} {zone.note or zone.zone_id} {zone.low:.2f}-{zone.high:.2f} "
                f"score={zone.score} ss={score:.2f}"
            ),
            tags={
                "pattern": pattern,
                "setup_type": setup_type,
                "zone_id": zone.zone_id,
                "zone_low": round(zone.low, 2),
                "zone_high": round(zone.high, 2),
                "zone_score": int(zone.score),
                "zone_source": zone.source,
                "zone_name": zone.note,
                "signal_score": round(score, 3),
                "rsi": None if rsi_m15 is None else round(rsi_m15, 1),
                "volume_ratio": None if relative_volume is None else round(relative_volume, 2),
                "candle_pattern": candle,
                "confirmation_tools": tools,
                "rr": round(reward / risk, 2) if risk > 0 else 0.0,
                "anchor": round(anchor, 2),
            },
        )

    @staticmethod
    def _liquidity_reward(
        side: str,
        entry: float,
        zones: Sequence[Zone],
        atr: float,
        risk: float,
        p: ZonesParams,
    ) -> float:
        pools: list[float] = []
        for zone in zones:
            if side == "buy" and zone.low > entry + 0.5 * atr:
                pools.append(zone.low)
            elif side == "sell" and zone.high < entry - 0.5 * atr:
                pools.append(zone.high)
        if pools:
            # Nearest pool in either direction: min(|level - entry|).
            pool = min(pools, key=lambda level: abs(level - entry))
            reward = abs(pool - entry) * 0.95
        else:
            reward = p.tp_min_r * risk
        rr = _clamp(reward / risk if risk > 0 else 0.0, p.tp_min_r, p.tp_max_r)
        return rr * risk

    # ------------------------------------------------------------------
    def _invalidation_multiplier(self, bars: Sequence[Bar], p: ZonesParams) -> float:
        if p.invalidate_mode != "dynamic":
            return p.invalidate_atr
        h1 = indicators.resample(bars, "H1")
        atr_h1 = indicators.atr(h1, p.atr_period)
        median = indicators.median([item.range for item in h1[-20:]]) if len(h1) >= 20 else None
        if not atr_h1 or not median:
            return p.invalidate_atr
        return _clamp(0.8 + 0.4 * (atr_h1 / median), 0.8, 1.5)

    def _manage(self, ctx: StrategyContext, bar: Bar) -> list[Signal]:
        p: ZonesParams = self.params
        if p.invalidate_atr <= 0 and p.invalidate_mode == "fixed":
            return []
        out: list[Signal] = []
        invalidate = self._invalidation_multiplier(ctx.bars("M15", 200), p)
        for pos in ctx.positions():
            if pos.ticket not in self._zone_of_ticket and self._pending_zone is not None:
                if self._pending_side in (None, pos.side):
                    self._zone_of_ticket[pos.ticket] = self._pending_zone
                    self._pending_zone = None
                    self._pending_side = None
            zone = self._zone_of_ticket.get(pos.ticket)
            if zone is None:
                continue
            buffer = invalidate * (ctx.atr("M15", p.atr_period) or 0.0)
            if pos.side == "buy" and bar.c < zone.low - buffer:
                out.append(
                    exit_signal(slot=ctx.slot, symbol=ctx.symbol, ticket=pos.ticket, reason="zone_lost")
                )
            elif pos.side == "sell" and bar.c > zone.high + buffer:
                out.append(
                    exit_signal(slot=ctx.slot, symbol=ctx.symbol, ticket=pos.ticket, reason="zone_lost")
                )
        return out

    def on_close(self, ctx: StrategyContext, trade) -> None:
        self._zone_of_ticket.pop(trade.ticket, None)
