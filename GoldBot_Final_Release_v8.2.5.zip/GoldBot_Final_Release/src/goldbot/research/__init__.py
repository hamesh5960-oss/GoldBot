"""Research toolkit: walk-forward validation, Monte Carlo, regime splits."""

from .monte_carlo import (
    HIGH_VOL,
    LOW_VOL,
    RANGING,
    REGIMES,
    TRENDING,
    MonteCarloSummary,
    RegimeStats,
    group_stats,
    percentile,
    regime_split,
    shuffle_trades,
)
from .walk_forward import (
    FoldRow,
    WalkForwardReport,
    Window,
    accept,
    make_windows,
    run_walk_forward,
)

__all__ = [
    "HIGH_VOL",
    "LOW_VOL",
    "RANGING",
    "REGIMES",
    "TRENDING",
    "FoldRow",
    "MonteCarloSummary",
    "RegimeStats",
    "WalkForwardReport",
    "Window",
    "accept",
    "group_stats",
    "make_windows",
    "percentile",
    "regime_split",
    "run_walk_forward",
    "shuffle_trades",
]
