"""Monte Carlo robustness and pure regime labelling.

Both tools are dependency-free (stdlib + domain value objects) so they can grade
an experiment without importing the application or engine layers.
"""

from __future__ import annotations

import math
import random
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from statistics import median

from ..domain.model import Bar

TRENDING = "trending"
RANGING = "ranging"
HIGH_VOL = "high_vol"
LOW_VOL = "low_vol"
REGIMES = (TRENDING, RANGING, HIGH_VOL, LOW_VOL)

# Volatility buckets are relative to the expanding ATR median; ADX 25 is the
# conventional trend/range boundary.
HIGH_VOL_MULT = 1.5
LOW_VOL_MULT = 0.75
ADX_TREND = 25.0


def percentile(values: Sequence[float], q: float) -> float:
    """Linear-interpolation percentile: q in [0, 100]; deterministic."""
    if not values:
        raise ValueError("percentile of an empty sequence")
    if not 0.0 <= q <= 100.0:
        raise ValueError(f"q must be in [0, 100], got {q}")
    ordered = sorted(values)
    if len(ordered) == 1:
        return ordered[0]
    position = (len(ordered) - 1) * q / 100.0
    low = math.floor(position)
    high = math.ceil(position)
    if low == high:
        return ordered[low]
    weight = position - low
    return ordered[low] * (1.0 - weight) + ordered[high] * weight


@dataclass(frozen=True, slots=True)
class MonteCarloSummary:
    """Distribution of final equity and drawdown over shuffled trade orders."""

    n: int
    trades_per_sim: int
    initial_equity: float
    final_equity_p5: float
    final_equity_p50: float
    final_equity_p95: float
    p95_max_drawdown_pct: float
    median_max_drawdown_pct: float
    prob_profit: float
    worst_streak: int
    mean_final_equity: float
    worst_final_equity: float
    best_final_equity: float

    def as_dict(self) -> dict[str, float]:
        return {
            "n": float(self.n),
            "trades_per_sim": float(self.trades_per_sim),
            "initial_equity": float(self.initial_equity),
            "final_equity_p5": float(self.final_equity_p5),
            "final_equity_p50": float(self.final_equity_p50),
            "final_equity_p95": float(self.final_equity_p95),
            "p95_max_drawdown_pct": float(self.p95_max_drawdown_pct),
            "median_max_drawdown_pct": float(self.median_max_drawdown_pct),
            "prob_profit": float(self.prob_profit),
            "worst_streak": float(self.worst_streak),
            "mean_final_equity": float(self.mean_final_equity),
            "worst_final_equity": float(self.worst_final_equity),
            "best_final_equity": float(self.best_final_equity),
        }


def shuffle_trades(
    pnls: Sequence[float],
    *,
    n: int = 10_000,
    seed: int = 42,
    initial_equity: float = 10_000.0,
) -> MonteCarloSummary:
    """Shuffle the same trade PnLs n times and summarise equity outcomes.

    Equity is marked to market after every trade, so the maximum drawdown is
    computed on the shuffled equity path, starting from 'initial_equity'.
    'worst_streak' is the longest run of consecutive losing trades seen in any
    simulation. Deterministic for a given seed.
    """
    values = [float(pnl) for pnl in pnls]
    if not values:
        raise ValueError("shuffle_trades needs at least one trade PnL")
    if n <= 0:
        raise ValueError(f"n must be >= 1, got {n}")
    if initial_equity <= 0.0:
        raise ValueError(f"initial_equity must be > 0, got {initial_equity}")

    rng = random.Random(seed)
    order = list(values)
    finals: list[float] = []
    drawdowns: list[float] = []
    worst_streak = 0
    profitable = 0

    for _ in range(int(n)):
        rng.shuffle(order)
        equity = initial_equity
        peak = initial_equity
        max_dd = 0.0
        streak = 0
        for pnl in order:
            equity += pnl
            if equity > peak:
                peak = equity
            if peak > 0.0:
                drawdown = (peak - equity) / peak * 100.0
                if drawdown > max_dd:
                    max_dd = drawdown
            if pnl < 0.0:
                streak += 1
                if streak > worst_streak:
                    worst_streak = streak
            else:
                streak = 0
        finals.append(equity)
        drawdowns.append(max_dd)
        if equity > initial_equity:
            profitable += 1

    return MonteCarloSummary(
        n=int(n),
        trades_per_sim=len(values),
        initial_equity=float(initial_equity),
        final_equity_p5=percentile(finals, 5.0),
        final_equity_p50=percentile(finals, 50.0),
        final_equity_p95=percentile(finals, 95.0),
        p95_max_drawdown_pct=percentile(drawdowns, 95.0),
        median_max_drawdown_pct=percentile(drawdowns, 50.0),
        prob_profit=profitable / len(finals),
        worst_streak=worst_streak,
        mean_final_equity=sum(finals) / len(finals),
        worst_final_equity=min(finals),
        best_final_equity=max(finals),
    )


def _true_ranges(bars: Sequence[Bar]) -> list[float]:
    ranges: list[float] = []
    for index in range(1, len(bars)):
        bar = bars[index]
        previous_close = bars[index - 1].c
        ranges.append(
            max(bar.h - bar.l, abs(bar.h - previous_close), abs(bar.l - previous_close))
        )
    return ranges


def _atr_series(bars: Sequence[Bar], period: int) -> list[float | None]:
    """Rolling simple-average ATR per bar; None while warming up."""
    output: list[float | None] = [None] * len(bars)
    if period <= 0:
        return output
    ranges = _true_ranges(bars)
    window_sum = 0.0
    for index, value in enumerate(ranges):
        window_sum += value
        if index >= period:
            window_sum -= ranges[index - period]
        if index >= period - 1:
            output[index + 1] = window_sum / period
    return output


def _adx_series(bars: Sequence[Bar], period: int) -> list[float | None]:
    """Wilder ADX per bar; None until there is enough history."""
    output: list[float | None] = [None] * len(bars)
    if period <= 0 or len(bars) < period * 2 + 1:
        return output

    ranges: list[float] = []
    plus_dm: list[float] = []
    minus_dm: list[float] = []
    for index in range(1, len(bars)):
        current = bars[index]
        previous = bars[index - 1]
        up = current.h - previous.h
        down = previous.l - current.l
        plus_dm.append(up if up > down and up > 0.0 else 0.0)
        minus_dm.append(down if down > up and down > 0.0 else 0.0)
        ranges.append(
            max(
                current.h - current.l,
                abs(current.h - previous.c),
                abs(current.l - previous.c),
            )
        )

    atr = sum(ranges[:period]) / period
    plus = sum(plus_dm[:period]) / period
    minus = sum(minus_dm[:period]) / period
    dxs: list[float] = []
    value: float | None = None

    for index in range(period, len(ranges)):
        atr = (atr * (period - 1) + ranges[index]) / period
        plus = (plus * (period - 1) + plus_dm[index]) / period
        minus = (minus * (period - 1) + minus_dm[index]) / period
        if atr <= 0.0:
            continue
        pdi = 100.0 * plus / atr
        ndi = 100.0 * minus / atr
        total = pdi + ndi
        dxs.append(100.0 * abs(pdi - ndi) / total if total > 0.0 else 0.0)
        bar_index = index + 1
        if len(dxs) < period:
            continue
        if value is None:
            value = sum(dxs[:period]) / period
        else:
            value = (value * (period - 1) + dxs[-1]) / period
        output[bar_index] = value
    return output


def regime_split(
    bars: Sequence[Bar],
    atr_period: int = 14,
    adx_period: int = 14,
) -> list[str]:
    """Label every bar trending / ranging / high_vol / low_vol.

    Volatility extremes win over trend: a bar is 'high_vol' when its ATR is
    more than 1.5x the expanding median ATR, 'low_vol' when below 0.75x; in the
    normal band it is 'trending' when ADX >= 25, else 'ranging'. Warmup bars
    (no ATR yet) are labelled 'ranging'. Pure and deterministic: same bars give
    the same labels.
    """
    if atr_period <= 0 or adx_period <= 0:
        raise ValueError("atr_period and adx_period must be positive")

    atrs = _atr_series(bars, atr_period)
    adxs = _adx_series(bars, adx_period)
    labels: list[str] = []
    history: list[float] = []

    for index in range(len(bars)):
        atr = atrs[index]
        adx = adxs[index]
        label = RANGING
        if atr is not None:
            history.append(atr)
            baseline = median(history)
            if baseline > 0.0 and atr > baseline * HIGH_VOL_MULT:
                label = HIGH_VOL
            elif baseline > 0.0 and atr < baseline * LOW_VOL_MULT:
                label = LOW_VOL
            elif adx is not None and adx >= ADX_TREND:
                label = TRENDING
        labels.append(label)
    return labels


@dataclass(frozen=True, slots=True)
class RegimeStats:
    """Aggregated trade statistics for one regime bucket."""

    regime: str
    count: int
    total: float
    mean: float
    win_rate: float
    profit_factor: float | None
    best: float
    worst: float


def group_stats(labels: Sequence[str], values: Sequence[float]) -> dict[str, RegimeStats]:
    """Group numeric outcomes (e.g. trade PnLs) by regime label."""
    if len(labels) != len(values):
        raise ValueError(f"labels {len(labels)} != values {len(values)}")
    buckets: dict[str, list[float]] = {}
    for label, value in zip(labels, values):
        buckets.setdefault(str(label), []).append(float(value))

    output: dict[str, RegimeStats] = {}
    for regime, rows in buckets.items():
        wins = [row for row in rows if row > 0.0]
        losses = [row for row in rows if row < 0.0]
        gross_loss = -sum(losses)
        output[regime] = RegimeStats(
            regime=regime,
            count=len(rows),
            total=sum(rows),
            mean=sum(rows) / len(rows),
            win_rate=len(wins) / len(rows),
            profit_factor=(sum(wins) / gross_loss) if gross_loss > 0.0 else None,
            best=max(rows),
            worst=min(rows),
        )
    return output
