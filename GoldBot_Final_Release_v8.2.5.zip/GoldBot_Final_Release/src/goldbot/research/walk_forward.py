"""Walk-forward validation: strict fold accounting, no OOS leakage.

The framework is deliberately data-type agnostic: 'bars' is any sequence and
'run_fn' is the caller's backtest hook. That keeps this module free of the
engine and strategy internals, so the same accounting can grade a real replay
or a synthetic stub.
"""

from __future__ import annotations

import math
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass
from typing import Any

# Defaults calibrated for a daily-to-intraday XAUUSD system: five folds, 70/30
# IS/OOS split, 50% window overlap, at least four positive OOS folds.
DEFAULT_FOLDS = 5
DEFAULT_IS_RATIO = 0.7
DEFAULT_SLIDE_FRAC = 0.5

DEFAULT_MIN_OOS_POSITIVE_FOLDS = 4
DEFAULT_MAX_P95_DD_PCT = 15.0
DEFAULT_MIN_OOS_TRADES = 300
DEFAULT_MIN_REGIMES_POSITIVE = 2

REQUIRED_METRICS = ("trades", "expectancy", "pnl", "max_dd_pct")


@dataclass(frozen=True, slots=True)
class Window:
    """One walk-forward fold.

    'start'/'end' are bar indexes (end exclusive) covering the consecutive
    in-sample block plus the untouched out-of-sample block that follows it.
    """

    start: int
    end: int
    is_bars: int
    oos_bars: int

    def __post_init__(self) -> None:
        if self.is_bars < 1 or self.oos_bars < 1:
            raise ValueError("a window needs at least one IS bar and one OOS bar")
        if self.start < 0:
            raise ValueError(f"window start must be >= 0, got {self.start}")
        if self.end != self.start + self.is_bars + self.oos_bars:
            raise ValueError(
                f"end {self.end} != start {self.start} + is_bars {self.is_bars} "
                f"+ oos_bars {self.oos_bars}"
            )

    @property
    def is_end(self) -> int:
        return self.start + self.is_bars

    @property
    def span(self) -> int:
        return self.is_bars + self.oos_bars

    @property
    def is_range(self) -> tuple[int, int]:
        """Half-open (start, end) index range of the in-sample block."""
        return (self.start, self.is_end)

    @property
    def oos_range(self) -> tuple[int, int]:
        """Half-open (start, end) index range of the out-of-sample block."""
        return (self.is_end, self.end)


@dataclass(frozen=True, slots=True)
class FoldRow:
    """Metrics for one fold, IS and OOS evaluated by the same 'run_fn'."""

    fold: int
    window: Window
    is_metrics: Mapping[str, float]
    oos_metrics: Mapping[str, float]


@dataclass(frozen=True, slots=True)
class WalkForwardReport:
    """Per-fold rows plus the aggregate the 'accept' gate reads."""

    rows: tuple[FoldRow, ...]
    aggregate: Mapping[str, float]

    @property
    def windows(self) -> tuple[Window, ...]:
        return tuple(row.window for row in self.rows)

    def __len__(self) -> int:
        return len(self.rows)


def make_windows(
    n_bars: int,
    folds: int = DEFAULT_FOLDS,
    is_ratio: float = DEFAULT_IS_RATIO,
    slide_frac: float = DEFAULT_SLIDE_FRAC,
) -> list[Window]:
    """Build a sliding walk-forward grid whose last OOS block ends at n_bars.

    Each fold gets an equal share 'n_bars // folds' of history, split
    'is_ratio' / '1 - is_ratio' into IS and OOS. Folds advance by
    'slide_frac' of that share but never less than one OOS block, so OOS
    blocks never overlap. The grid is anchored at the tail, so the final OOS
    block always ends exactly at the last bar.
    """
    if folds < 1:
        raise ValueError(f"folds must be >= 1, got {folds}")
    if not 0.0 < is_ratio < 1.0:
        raise ValueError(f"is_ratio must be in (0, 1), got {is_ratio}")
    if not 0.0 < slide_frac <= 1.0:
        raise ValueError(f"slide_frac must be in (0, 1], got {slide_frac}")
    if n_bars < folds * 2:
        raise ValueError(f"n_bars {n_bars} is too small for {folds} folds")

    span = n_bars // folds
    is_bars = min(span - 1, max(1, int(round(span * is_ratio))))
    oos_bars = span - is_bars
    slide = max(oos_bars, int(round(span * slide_frac)))
    last_start = n_bars - span

    windows: list[Window] = []
    for fold in range(folds):
        start = last_start - (folds - 1 - fold) * slide
        if start < 0:  # defensive: the slide is capped at one span above
            raise ValueError("window grid ran past the start of history")
        windows.append(
            Window(start=start, end=start + span, is_bars=is_bars, oos_bars=oos_bars)
        )
    return windows


def _percentile(values: Sequence[float], q: float) -> float:
    """Linear-interpolation percentile (same convention as Monte Carlo)."""
    if not values:
        raise ValueError("percentile of an empty sequence")
    ordered = sorted(values)
    if len(ordered) == 1:
        return ordered[0]
    position = (len(ordered) - 1) * q / 100.0
    low = math.floor(position)
    high = math.ceil(position)
    if low == high:
        return ordered[low]
    weight = position - low
    return ordered[low] * (1.0 - weight) + ordered[high] * weight


def _coerce_metrics(metrics: Mapping[str, Any], *, fold: int, role: str) -> dict[str, float]:
    if not isinstance(metrics, Mapping):
        raise ValueError(f"run_fn must return a mapping, got {type(metrics).__name__}")
    missing = [key for key in REQUIRED_METRICS if key not in metrics]
    if missing:
        raise ValueError(f"{role} metrics in fold {fold} miss required keys {missing}")
    return {key: float(metrics[key]) for key in REQUIRED_METRICS} | {
        "regimes_positive": float(metrics.get("regimes_positive", 0.0)),
    }


def _aggregate(rows: Sequence[FoldRow]) -> dict[str, float]:
    oos = [row.oos_metrics for row in rows]
    in_sample = [row.is_metrics for row in rows]

    oos_trades = sum(m["trades"] for m in oos)
    is_trades = sum(m["trades"] for m in in_sample)
    oos_pnl = sum(m["pnl"] for m in oos)
    is_pnl = sum(m["pnl"] for m in in_sample)
    oos_expectancy = (
        sum(m["expectancy"] * m["trades"] for m in oos) / oos_trades if oos_trades > 0 else 0.0
    )
    is_expectancy = (
        sum(m["expectancy"] * m["trades"] for m in in_sample) / is_trades if is_trades > 0 else 0.0
    )
    oos_dds = [m["max_dd_pct"] for m in oos]
    regimes_positive = max((m["regimes_positive"] for m in oos), default=0.0)

    return {
        "folds": float(len(rows)),
        "is_trades": float(is_trades),
        "oos_trades": float(oos_trades),
        "is_pnl": float(is_pnl),
        "oos_pnl": float(oos_pnl),
        "is_expectancy": float(is_expectancy),
        "oos_expectancy": float(oos_expectancy),
        "is_positive_folds": float(sum(1 for m in in_sample if m["expectancy"] > 0.0)),
        "oos_positive_folds": float(sum(1 for m in oos if m["expectancy"] > 0.0)),
        "oos_max_dd_pct": float(max(oos_dds) if oos_dds else 0.0),
        "p95_dd_pct": float(_percentile(oos_dds, 95.0) if oos_dds else 0.0),
        "regimes_positive": float(regimes_positive),
    }


def run_walk_forward(
    bars: Sequence[Any],
    run_fn: Callable[[Sequence[Any]], Mapping[str, Any]],
    *,
    folds: int = DEFAULT_FOLDS,
    is_ratio: float = DEFAULT_IS_RATIO,
    slide: float = DEFAULT_SLIDE_FRAC,
) -> WalkForwardReport:
    """Evaluate 'run_fn' on every IS and OOS block; return rows + aggregate.

    'run_fn' must return a mapping with at least 'trades', 'expectancy',
    'pnl' and 'max_dd_pct'; an optional 'regimes_positive' counts regimes
    with positive expectancy in that block.
    """
    windows = make_windows(len(bars), folds=folds, is_ratio=is_ratio, slide_frac=slide)
    rows: list[FoldRow] = []
    for fold, window in enumerate(windows):
        is_slice = bars[window.start : window.is_end]
        oos_slice = bars[window.is_end : window.end]
        is_metrics = _coerce_metrics(run_fn(is_slice), fold=fold, role="IS")
        oos_metrics = _coerce_metrics(run_fn(oos_slice), fold=fold, role="OOS")
        rows.append(
            FoldRow(
                fold=fold,
                window=window,
                is_metrics=is_metrics,
                oos_metrics=oos_metrics,
            )
        )
    return WalkForwardReport(rows=tuple(rows), aggregate=_aggregate(rows))


def accept(
    report: WalkForwardReport,
    *,
    min_oos_positive_folds: int = DEFAULT_MIN_OOS_POSITIVE_FOLDS,
    max_p95_dd_pct: float = DEFAULT_MAX_P95_DD_PCT,
    min_oos_trades: int = DEFAULT_MIN_OOS_TRADES,
    min_regimes_positive: int = DEFAULT_MIN_REGIMES_POSITIVE,
) -> tuple[bool, tuple[str, ...]]:
    """Fail-closed acceptance gate for a walk-forward report.

    Returns (ok, reasons); every failed rule adds one human-readable reason.
    """
    aggregate = report.aggregate
    reasons: list[str] = []

    positive_folds = int(aggregate.get("oos_positive_folds", 0.0))
    if positive_folds < min_oos_positive_folds:
        reasons.append(
            f"oos_positive_folds {positive_folds} < required {min_oos_positive_folds}"
        )

    p95_dd = float(aggregate.get("p95_dd_pct", math.inf))
    if p95_dd > max_p95_dd_pct:
        reasons.append(f"p95_dd_pct {p95_dd:.2f} > allowed {max_p95_dd_pct:.2f}")

    oos_trades = int(aggregate.get("oos_trades", 0.0))
    if oos_trades < min_oos_trades:
        reasons.append(f"oos_trades {oos_trades} < required {min_oos_trades}")

    regimes = int(aggregate.get("regimes_positive", 0.0))
    if regimes < min_regimes_positive:
        reasons.append(
            f"regimes_positive {regimes} < required {min_regimes_positive}"
        )

    return (not reasons, tuple(reasons))
