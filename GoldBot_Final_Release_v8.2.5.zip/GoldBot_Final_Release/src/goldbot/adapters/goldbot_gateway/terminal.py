"""Terminal SDK loader. Importing MetaTrader5 anywhere else fails CI."""

from __future__ import annotations

from typing import Any


def load_mt5() -> Any:
    """Import the installed MetaTrader5 package lazily (Windows only)."""
    import MetaTrader5 as mt5  # noqa: N813 - official module name

    return mt5
