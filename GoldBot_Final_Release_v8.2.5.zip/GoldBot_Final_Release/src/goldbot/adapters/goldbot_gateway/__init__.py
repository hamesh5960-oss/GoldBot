"""Venue gateway package: the only place allowed to import a terminal SDK."""
