"""Economic-calendar CSV adapter (stdlib csv only).

The calendar is an optional, degrading input (spec A13): a missing or broken
file must never crash the bot.  It only marks the calendar unavailable, and the
news policy then applies its fail-safe.  This adapter is deliberately tolerant
about column names and formats so a hand-maintained CSV keeps working.

Accepted layouts
----------------
* one datetime column: datetime, date_time, timestamp, utc_time, time_utc,
  when, utc, datetime_utc (ISO 8601 or 'YYYY-MM-DD HH:MM');
* separate date + time columns (time may be omitted for an all-day row, which
  is skipped: only intraday events matter for a blackout);
* optional impact/importance (unknown values become MEDIUM, the conservative
  choice), title/event and currency (USD when absent).

Naive timestamps are treated as UTC, matching the calendar feed convention.
"""

from __future__ import annotations

import csv
from datetime import date as Date
from datetime import datetime, time as Time
from pathlib import Path

from ..app.news import Impact, NewsEvent, NewsParams, classify_events

__all__ = ["load_calendar", "write_example_calendar"]

_STRONG_DATETIME_COLUMNS = (
    "datetime",
    "date_time",
    "timestamp",
    "utc_time",
    "time_utc",
    "when",
    "utc",
    "datetime_utc",
)
_DATE_COLUMNS = ("date", "date_utc", "day")
_TIME_COLUMNS = ("time", "time_utc", "hour")
_IMPACT_COLUMNS = ("impact", "importance", "importance_level")
_TITLE_COLUMNS = ("title", "event", "name", "description")
_CURRENCY_COLUMNS = ("currency", "cur", "ccy", "symbol")

_EXAMPLE_ROWS = (
    ("2026-01-09", "14:30", "high", "US non-farm payrolls", "USD"),
    ("2026-01-09", "18:00", "medium", "ECB commentary", "EUR"),
    ("2026-01-12", "14:30", "high", "US CPI", "USD"),
    ("2026-01-13", "18:00", "low", "Fed speaker", "USD"),
)


def _cell(row: dict[str, str], headers: dict[str, str], aliases: tuple[str, ...]) -> str:
    for alias in aliases:
        field = headers.get(alias)
        if field is None:
            continue
        value = row.get(field)
        if value is not None and str(value).strip():
            return str(value).strip()
    return ""


def _parse_datetime_token(token: str) -> datetime | None:
    """Parse a full timestamp; date-only (all-day) tokens return None."""
    text = token.strip()
    if not text or ":" not in text:
        return None
    try:
        return datetime.fromisoformat(text)
    except ValueError:
        pass
    for fmt in (
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%d %H:%M",
        "%Y/%m/%d %H:%M:%S",
        "%Y/%m/%d %H:%M",
        "%d.%m.%Y %H:%M",
    ):
        try:
            return datetime.strptime(text, fmt)
        except ValueError:
            continue
    return None


def _parse_date_token(token: str) -> Date | None:
    text = token.strip()
    try:
        return Date.fromisoformat(text)
    except ValueError:
        pass
    for fmt in ("%Y/%m/%d", "%d.%m.%Y"):
        try:
            return datetime.strptime(text, fmt).date()
        except ValueError:
            continue
    return None


def _parse_time_token(token: str) -> Time | None:
    text = token.strip()
    try:
        return Time.fromisoformat(text)
    except ValueError:
        pass
    for fmt in ("%H:%M:%S", "%H:%M"):
        try:
            return datetime.strptime(text, fmt).time()
        except ValueError:
            continue
    return None


def _parse_impact(token: str) -> Impact:
    text = token.strip().lower()
    if text in ("high", "h", "3"):
        return Impact.HIGH
    if text in ("low", "l", "1"):
        return Impact.LOW
    # Unknown or empty importance is medium: never under-state a release.
    return Impact.MEDIUM


def _row_datetime(row: dict[str, str], headers: dict[str, str]) -> datetime | None:
    """Resolve one row's timestamp; None means all-day/unreadable (skip row)."""
    for alias in _STRONG_DATETIME_COLUMNS:
        token = _cell(row, headers, (alias,))
        if token:
            return _parse_datetime_token(token)
    day_token = _cell(row, headers, _DATE_COLUMNS)
    if day_token:
        day = _parse_date_token(day_token)
        if day is None:
            return None
        time_token = _cell(row, headers, _TIME_COLUMNS)
        if not time_token:
            return None
        tod = _parse_time_token(time_token)
        if tod is None:
            return None
        return datetime.combine(day, tod)
    token = _cell(row, headers, ("time",))
    if token:
        return _parse_datetime_token(token)
    return None


def _parse_row(row: dict[str, str], headers: dict[str, str]) -> NewsEvent | None:
    try:
        when = _row_datetime(row, headers)
        if when is None:
            return None
        return NewsEvent(
            when_utc=when,
            impact=_parse_impact(_cell(row, headers, _IMPACT_COLUMNS)),
            title=_cell(row, headers, _TITLE_COLUMNS),
            currency=_cell(row, headers, _CURRENCY_COLUMNS) or "USD",
        )
    except (AttributeError, TypeError, ValueError):
        return None


def _has_timestamp_source(headers: dict[str, str]) -> bool:
    aliases = _STRONG_DATETIME_COLUMNS + _DATE_COLUMNS + ("time",)
    return any(alias in headers for alias in aliases)


def _read_csv(path: Path) -> tuple[list[dict[str, str]], dict[str, str]] | None:
    """Read rows and the normalised header map; None means "unavailable"."""
    try:
        with path.open("r", encoding="utf-8-sig", newline="") as handle:
            reader = csv.DictReader(handle)
            fieldnames = reader.fieldnames
            if not fieldnames:
                return None
            headers: dict[str, str] = {}
            for name in fieldnames:
                if name is None:
                    continue
                key = str(name).strip().lower()
                if key:
                    headers[key] = name
            if not _has_timestamp_source(headers):
                return None
            return list(reader), headers
    except (OSError, UnicodeError, csv.Error):
        return None
    except Exception:  # a broken calendar must never take the bot down
        return None


def load_calendar(
    path: str | Path, *, params: NewsParams | None = None
) -> tuple[list[NewsEvent], bool]:
    """Load the calendar CSV as (events, calendar_available).

    Missing, unreadable or structurally invalid input returns ([], False); a
    readable calendar with zero usable rows returns ([], True).  Invalid rows
    are skipped individually.  Events are sorted and capped by the policy
    snapshot rules (params.max_events).
    """
    policy = params or NewsParams()
    file = Path(path)
    if not file.is_file():
        return [], False
    read = _read_csv(file)
    if read is None:
        return [], False
    rows, headers = read
    events = [event for event in (_parse_row(row, headers) for row in rows) if event is not None]
    return list(classify_events(events, policy)), True


def write_example_calendar(path: str | Path) -> Path:
    """Write a small deterministic example calendar and return its path."""
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(("date", "time", "impact", "title", "currency"))
        writer.writerows(_EXAMPLE_ROWS)
    return target
