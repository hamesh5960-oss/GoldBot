"""In-memory venue with realistic-enough microstructure to exercise every code path.

It is *the* replacement for a real broker in tests and backtests: same port, same
idempotency semantics, same rejection codes, same uncertainty behaviour.
"""

from __future__ import annotations

import itertools
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Sequence

from ..domain.errors import SubmitUncertain
from ..domain.execution import ApprovedOrder, OrderAck
from ..domain.model import (
    AccountSnapshot,
    ClosedTrade,
    ConnectionInfo,
    DealRecord,
    Fill,
    OrderSnapshot,
    PositionSnapshot,
    Side,
    Symbol,
    SymbolInfo,
    Tick,
    Ticket,
    Ts,
    utc,
)
from ..domain.money import Money, money
from ..ports.broker import GatewayHealth

RETCODE_DONE = 10009
RETCODE_REQUOTE = 10004
RETCODE_INVALID_STOPS = 10016
RETCODE_NO_MONEY = 10019
RETCODE_INVALID_VOLUME = 10014
RETCODE_MARKET_CLOSED = 10018


@dataclass
class _OpenPosition:
    ticket: int
    symbol: Symbol
    side: Side
    volume: float
    open_price: float
    sl: float | None
    tp: float | None
    magic: int
    comment: str
    open_time: datetime
    strategy: str
    entry_commission: float


class FakeBroker:
    """Deterministic, offline, and intentionally strict about invalid orders."""

    def __init__(
        self,
        info: SymbolInfo,
        *,
        balance: float = 10_000.0,
        leverage: int = 100,
        trade_mode: str = "hedging",
        commission_per_lot: float = 7.0,
        slippage_points: float = 2.0,
        reject_next: str | None = None,
        fail_next_modify: int = 0,
        fail_next_close: int = 0,
        scenario: str | None = None,
    ) -> None:
        self.info = info
        self.leverage = leverage
        self.trade_mode = trade_mode  # type: ignore[assignment]
        self.commission_per_lot = commission_per_lot
        self.slippage_points = slippage_points
        self.balance = balance
        self._positions: dict[int, _OpenPosition] = {}
        self._orders: list[OrderSnapshot] = []
        self._deals: list[DealRecord] = []
        self._idem: dict[str, OrderAck] = {}
        self._tickets = itertools.count(100_000)
        self._order_tickets = itertools.count(500_000)
        self._offline = False
        self._reject_next = reject_next
        self._last_tick: Tick | None = None
        self._started = False
        # -- deterministic failure injection (test only) -----------------
        # Counters are plain ints and may be written directly. Injected
        # rejections are *not* cached under the idempotency key, so a caller's
        # retry with the same key is a real retry and can succeed.
        self.fail_next_modify = max(0, int(fail_next_modify))
        self.fail_next_close = max(0, int(fail_next_close))
        self.scenario = scenario
        self._fail_modify_after_partial = 1 if scenario == "partial_then_sl_fail" else 0

    # -- lifecycle -------------------------------------------------------
    def connect(self) -> ConnectionInfo:
        self._started = True
        return ConnectionInfo(
            server="Fake-Demo",
            login=12345678,
            trade_mode=self.trade_mode,  # type: ignore[arg-type]
            broker_offset=self.info.broker_offset,
            terminal="fake",
        )

    def disconnect(self) -> None:
        self._started = False

    def is_ready(self) -> bool:
        return self._started and not self._offline

    def set_offline(self, offline: bool) -> None:
        self._offline = offline

    def health(self) -> GatewayHealth:
        age = 0.0 if self._last_tick is None else 0.0
        return GatewayHealth(alive=self._started, latency_ms=1.0, last_tick_age_s=age)

    # -- reads -----------------------------------------------------------
    def symbol_info(self, symbol: Symbol) -> SymbolInfo:
        return self.info

    def _mark_price(self, side: Side) -> float:
        tick = self._last_tick
        if tick is None:
            return 0.0
        return tick.ask if side == "buy" else tick.bid

    def _position_profit(self, pos: _OpenPosition) -> float:
        price = self._mark_price(pos.side)
        if price <= 0:
            return 0.0
        direction = 1.0 if pos.side == "buy" else -1.0
        return (price - pos.open_price) * direction * self.info.contract_size * pos.volume

    def account(self) -> AccountSnapshot:
        unrealized = sum(self._position_profit(p) for p in self._positions.values())
        margin = sum(
            p.volume * self.info.contract_size * p.open_price / self.leverage
            for p in self._positions.values()
        )
        equity = self.balance + unrealized
        now = self._last_tick.ts_event if self._last_tick else Ts(datetime.now(tz=timezone.utc))
        return AccountSnapshot(
            login=12345678,
            server="Fake-Demo",
            currency="USD",
            balance=money(self.balance),
            equity=money(equity),
            margin=money(margin),
            free_margin=money(equity - margin),
            leverage=self.leverage,
            trade_mode=self.trade_mode,  # type: ignore[arg-type]
            ts=now,
        )

    def positions(self) -> Sequence[PositionSnapshot]:
        out = []
        for p in self._positions.values():
            out.append(
                PositionSnapshot(
                    ticket=Ticket(p.ticket),
                    symbol=p.symbol,
                    side=p.side,
                    volume=p.volume,
                    open_price=p.open_price,
                    sl=p.sl,
                    tp=p.tp,
                    magic=p.magic,
                    comment=p.comment,
                    open_time=p.open_time,
                    profit=money(self._position_profit(p)),
                )
            )
        return out

    def orders(self) -> Sequence[OrderSnapshot]:
        return list(self._orders)

    def deals(self, *, since: datetime) -> Sequence[DealRecord]:
        since_utc = utc(since)
        return [d for d in self._deals if utc(d.time) >= since_utc]

    # -- writes ----------------------------------------------------------
    def submit(self, order: ApprovedOrder, *, idempotency_key: str) -> OrderAck:
        if idempotency_key in self._idem:
            return self._idem[idempotency_key]
        if self._offline:
            raise SubmitUncertain("disconnected")

        ack = self._validate_and_fill(order)
        self._idem[idempotency_key] = ack
        return ack

    def _validate_and_fill(self, order: ApprovedOrder) -> OrderAck:
        info = self.info
        if self._reject_next is not None:
            name = self._reject_next
            self._reject_next = None
            code = {"requote": RETCODE_REQUOTE, "invalid_stops": RETCODE_INVALID_STOPS}.get(name, 0)
            return OrderAck(
                intent_id=order.intent_id,
                accepted=False,
                retcode=code,
                retcode_name=name.upper(),
                message=f"simulated {name}",
            )

        if order.volume < info.min_volume - 1e-9 or order.volume > info.max_volume + 1e-9:
            return self._reject(order, RETCODE_INVALID_VOLUME, "INVALID_VOLUME", "volume out of bounds")
        if abs((order.volume / info.volume_step) - round(order.volume / info.volume_step)) > 1e-6:
            return self._reject(order, RETCODE_INVALID_VOLUME, "INVALID_VOLUME", "volume step")

        tick = self._last_tick
        if tick is None:
            return self._reject(order, RETCODE_MARKET_CLOSED, "MARKET_CLOSED", "no price")

        slip = info.from_points(self.slippage_points)
        price = tick.ask + slip if order.side == "buy" else tick.bid - slip

        if order.sl is not None:
            distance = abs(price - order.sl)
            if distance < info.from_points(info.stops_level_points):
                return self._reject(order, RETCODE_INVALID_STOPS, "INVALID_STOPS", "stop too close")
            if order.side == "buy" and order.sl >= price:
                return self._reject(order, RETCODE_INVALID_STOPS, "INVALID_STOPS", "sl above entry")
            if order.side == "sell" and order.sl <= price:
                return self._reject(order, RETCODE_INVALID_STOPS, "INVALID_STOPS", "sl below entry")
        if order.tp is not None:
            if order.side == "buy" and order.tp <= price:
                return self._reject(order, RETCODE_INVALID_STOPS, "INVALID_STOPS", "tp below entry")
            if order.side == "sell" and order.tp >= price:
                return self._reject(order, RETCODE_INVALID_STOPS, "INVALID_STOPS", "tp above entry")

        margin = order.volume * info.contract_size * price / self.leverage
        if margin > float(self.account().free_margin.amount):
            return self._reject(order, RETCODE_NO_MONEY, "NO_MONEY", "insufficient free margin")

        ticket = next(self._tickets)
        entry_commission = self.commission_per_lot / 2.0 * order.volume
        self.balance -= entry_commission
        pos = _OpenPosition(
            ticket=ticket,
            symbol=order.symbol,
            side=order.side,
            volume=order.volume,
            open_price=price,
            sl=order.sl,
            tp=order.tp,
            magic=order.magic,
            comment=order.client_ref,
            open_time=tick.ts_event.wall,
            strategy=order.strategy,
            entry_commission=entry_commission,
        )
        self._positions[ticket] = pos
        self._orders.append(
            OrderSnapshot(
                ticket=Ticket(next(self._order_tickets)),
                symbol=order.symbol,
                side=order.side,
                volume=order.volume,
                price=price,
                sl=order.sl,
                tp=order.tp,
                state="filled",
                magic=order.magic,
                comment=order.client_ref,
                created_at=tick.ts_event.wall,
                filled_volume=order.volume,
            )
        )
        return OrderAck(
            intent_id=order.intent_id,
            accepted=True,
            retcode=RETCODE_DONE,
            retcode_name="DONE",
            message="filled",
            ticket=ticket,
            fill_price=price,
            filled_volume=order.volume,
            ts=tick.ts_event,
        )

    def _reject(self, order: ApprovedOrder, code: int, name: str, message: str) -> OrderAck:
        return OrderAck(
            intent_id=order.intent_id,
            accepted=False,
            retcode=code,
            retcode_name=name,
            message=message,
        )

    def modify(
        self, ticket: Ticket, *, sl: float | None, tp: float | None, idempotency_key: str
    ) -> OrderAck:
        if idempotency_key in self._idem:
            return self._idem[idempotency_key]
        if self.fail_next_modify > 0:
            self.fail_next_modify -= 1
            return OrderAck(
                "", False, RETCODE_REQUOTE, "INJECTED_MODIFY_FAILURE", "injected modify failure"
            )
        pos = self._positions.get(int(ticket))
        if pos is None:
            return OrderAck("", False, 10013, "INVALID_TICKET", "unknown ticket")
        price = self._mark_price(pos.side)
        if sl is not None:
            if abs(price - sl) < self.info.from_points(self.info.stops_level_points):
                return OrderAck("", False, RETCODE_INVALID_STOPS, "INVALID_STOPS", "stop too close")
            if pos.side == "buy" and sl >= price:
                return OrderAck("", False, RETCODE_INVALID_STOPS, "INVALID_STOPS", "sl above market")
            if pos.side == "sell" and sl <= price:
                return OrderAck("", False, RETCODE_INVALID_STOPS, "INVALID_STOPS", "sl below market")
        pos.sl = sl if sl is not None else pos.sl
        pos.tp = tp if tp is not None else pos.tp
        ack = OrderAck("", True, RETCODE_DONE, "DONE", "modified", ticket=int(ticket))
        self._idem[idempotency_key] = ack
        return ack

    def close(
        self, ticket: Ticket, *, volume: float | None, idempotency_key: str, reason: str = "manual"
    ) -> OrderAck:
        if idempotency_key in self._idem:
            return self._idem[idempotency_key]
        if self.fail_next_close > 0:
            self.fail_next_close -= 1
            return OrderAck(
                "", False, RETCODE_REQUOTE, "INJECTED_CLOSE_FAILURE", "injected close failure"
            )
        pos = self._positions.get(int(ticket))
        if pos is None:
            return OrderAck("", False, 10013, "INVALID_TICKET", "unknown ticket")
        was_partial = volume is not None
        closed = self._close_position(pos, reason=reason, volume=volume)
        if (
            was_partial
            and self._fail_modify_after_partial > 0
            and pos.volume > 1e-9
            and pos.ticket in self._positions
        ):
            # Scenario "partial then sl fail": the slice fills, the follow-up
            # stop move fails once, so the caller must retry idempotently.
            self._fail_modify_after_partial -= 1
            self.fail_next_modify += 1
        ack = OrderAck(
            "",
            True,
            RETCODE_DONE,
            "DONE",
            "closed",
            ticket=closed.ticket,
            fill_price=closed.close_price,
            filled_volume=closed.volume,
            closed_trade=closed,
        )
        self._idem[idempotency_key] = ack
        return ack

    # -- market simulation ----------------------------------------------
    def _close_position(
        self, pos: _OpenPosition, *, reason: str, volume: float | None = None
    ) -> ClosedTrade:
        tick = self._last_tick
        assert tick is not None
        qty = pos.volume if volume is None else min(volume, pos.volume)
        price = tick.bid if pos.side == "buy" else tick.ask
        direction = 1.0 if pos.side == "buy" else -1.0
        gross = (price - pos.open_price) * direction * self.info.contract_size * qty
        exit_commission = self.commission_per_lot / 2.0 * qty
        # Release the entry commission in proportion to the slice being closed,
        # otherwise a three-layer exit charges the full entry fee to every slice
        # and the journal under-reports realised PnL against the balance.
        entry_commission_share = pos.entry_commission * (qty / pos.volume)
        pos.entry_commission -= entry_commission_share
        self.balance += gross - exit_commission
        pos.volume -= qty
        if pos.volume <= 1e-9:
            self._positions.pop(pos.ticket, None)

        trade = ClosedTrade(
            ticket=Ticket(pos.ticket),
            symbol=pos.symbol,
            side=pos.side,
            volume=qty,
            open_price=pos.open_price,
            close_price=price,
            open_time=pos.open_time,
            close_time=tick.ts_event.wall,
            pnl_gross=money(gross),
            commission=money(exit_commission + entry_commission_share),
            swap=money(0),
            reason=reason,  # type: ignore[arg-type]
        )
        self._deals.append(
            DealRecord(
                ticket=Ticket(pos.ticket),
                order_ticket=Ticket(pos.ticket),
                symbol=pos.symbol,
                side=pos.side,
                volume=qty,
                price=price,
                commission=trade.commission,
                swap=trade.swap,
                profit=money(gross),
                time=tick.ts_event.wall,
                comment=reason,
            )
        )
        return trade

    def on_market_tick(self, tick: Tick) -> Sequence[ClosedTrade]:
        self._last_tick = tick
        closed: list[ClosedTrade] = []
        for pos in list(self._positions.values()):
            if pos.sl is not None:
                if (pos.side == "buy" and tick.bid <= pos.sl) or (pos.side == "sell" and tick.ask >= pos.sl):
                    closed.append(self._close_position(pos, reason="sl"))
                    continue
            if pos.tp is not None:
                if (pos.side == "buy" and tick.bid >= pos.tp) or (pos.side == "sell" and tick.ask <= pos.tp):
                    closed.append(self._close_position(pos, reason="tp"))
        return closed

    # -- orphan detection ------------------------------------------------
    def find_by_client_ref(self, client_ref: str, *, since: datetime) -> Sequence[OrderSnapshot]:
        return [o for o in self._orders if o.comment == client_ref and utc(o.created_at) >= utc(since)]

    # -- failure injection (tests) ---------------------------------------
    def inject_modify_failure(self, n: int = 1) -> None:
        """Make the next n modify calls return a deterministic rejection."""
        self.fail_next_modify += max(1, int(n))

    def inject_close_failure(self, n: int = 1) -> None:
        """Make the next n close calls return a deterministic rejection."""
        self.fail_next_close += max(1, int(n))

    def arm_scenario(self, name: str) -> None:
        """Arm a named deterministic scenario (currently partial_then_sl_fail)."""
        self.scenario = name
        self._fail_modify_after_partial = 1 if name == "partial_then_sl_fail" else 0

    # -- test helpers ----------------------------------------------------
    def force_close_all(self, reason: str = "kill") -> list[ClosedTrade]:
        out = []
        for pos in list(self._positions.values()):
            out.append(self._close_position(pos, reason=reason))
        return out

    @property
    def open_tickets(self) -> list[int]:
        return list(self._positions.keys())
