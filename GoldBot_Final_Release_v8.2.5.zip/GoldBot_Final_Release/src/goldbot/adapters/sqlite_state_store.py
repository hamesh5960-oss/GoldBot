"""SQLite-backed durable risk state: one row, write-through, crash durable."""

from __future__ import annotations

import json
import sqlite3
from dataclasses import replace
from datetime import datetime, timezone
from pathlib import Path

from ..domain.model import utc
from ..ports.state import SCHEMA_VERSION, PersistedRiskState, StateCorruption

SCHEMA = """
CREATE TABLE IF NOT EXISTS risk_state (
    key TEXT PRIMARY KEY,
    schema_version INTEGER NOT NULL,
    payload TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
"""


class SqliteRiskStateStore:
    """Single-record store. WAL + explicit commits keep a kill durable."""

    def __init__(self, path: str | Path, key: str = "default") -> None:
        self.path = Path(path)
        self.key = key
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(self.path, timeout=10.0)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        # FULL: a state transition is on disk before the engine acts on it.
        self._conn.execute("PRAGMA synchronous=FULL")
        self._conn.executescript(SCHEMA)
        self._conn.commit()

    def close(self) -> None:
        self._conn.close()

    # -- port ------------------------------------------------------------
    def load(self) -> PersistedRiskState | None:
        row = self._conn.execute(
            "SELECT schema_version, payload, updated_at FROM risk_state WHERE key = ?",
            (self.key,),
        ).fetchone()
        if row is None:
            return None
        stored_version = int(row["schema_version"])
        if stored_version != SCHEMA_VERSION:
            raise StateCorruption(
                f"unsupported risk state schema {stored_version} (expected {SCHEMA_VERSION})"
            )
        try:
            data = json.loads(row["payload"])
        except (TypeError, ValueError) as exc:
            raise StateCorruption(f"risk state payload is not valid JSON: {exc}") from exc
        if not isinstance(data, dict):
            raise StateCorruption("risk state payload is not a JSON object")
        state = PersistedRiskState.from_dict(data)
        if not state.updated_at:
            state = replace(state, updated_at=str(row["updated_at"]))
        return state

    def save(self, state: PersistedRiskState) -> None:
        if state.schema_version != SCHEMA_VERSION:
            raise StateCorruption(
                f"refusing to persist risk state schema {state.schema_version}"
            )
        payload = json.dumps(state.to_dict(), ensure_ascii=False, sort_keys=True)
        updated = state.updated_at or now_iso()
        # One transaction per write-through; no buffering anywhere above this.
        with self._conn:
            self._conn.execute(
                """
                INSERT INTO risk_state(key, schema_version, payload, updated_at)
                VALUES (?, ?, ?, ?)
                ON CONFLICT(key) DO UPDATE SET
                    schema_version = excluded.schema_version,
                    payload = excluded.payload,
                    updated_at = excluded.updated_at
                """,
                (self.key, state.schema_version, payload, updated),
            )

    def clear(self) -> None:
        with self._conn:
            self._conn.execute("DELETE FROM risk_state WHERE key = ?", (self.key,))


def now_iso() -> str:
    return utc(datetime.now(tz=timezone.utc)).isoformat()
