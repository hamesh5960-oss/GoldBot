"""One source of time: UTC, broker and local (Iran) views."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone

# Iran has used a fixed +03:30 offset since 2022 (no DST). A fixed offset avoids
# a hard dependency on the optional tzdata package on Windows.
TEHRAN = timezone(timedelta(hours=3, minutes=30), name="Asia/Tehran")


class TimeService:
    def __init__(self, clock) -> None:
        self._clock = clock

    @property
    def utc(self) -> datetime:
        return self._clock.now().wall.astimezone(timezone.utc)

    @property
    def broker(self) -> datetime:
        broker_now = getattr(self._clock, "broker_now", None)
        if broker_now is not None:
            return broker_now()
        return self.utc

    @property
    def local(self) -> datetime:
        return self.utc.astimezone(TEHRAN)

    def trading_day(self) -> str:
        return self.local.strftime("%Y-%m-%d")

    @staticmethod
    def in_window(moment: datetime, start: str, end: str) -> bool:
        def minutes(value: str) -> int:
            hour, minute = value.split(":")
            return int(hour) * 60 + int(minute)

        current = moment.hour * 60 + moment.minute
        first, last = minutes(start), minutes(end)
        if first <= last:
            return first <= current <= last
        return current >= first or current <= last
