"""Persistent store for hand-drawn daily price zones (JSON, Iran trading day).

Two rules matter operationally:
* a day's zones expire at Iran midnight — the next day starts empty;
* at most 40 zones per day (the panel enforces the same limit).
"""

from __future__ import annotations

import json
import re
from datetime import date
from pathlib import Path
from typing import Sequence

from ..strategy_api.zones import Zone
from ..timeutil import iran_day

MAX_ZONES_PER_DAY = 40

_DIGIT_MAP = str.maketrans(
    "۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789"
)
_TRUE_TOKENS = {"1", "true", "yes", "y", "*", "star", "ستاره", "مهم"}
_SPLIT = re.compile(r"\s*(?:[,;\t]|\s{2,}|\s)\s*")


def normalize_digits(text: str) -> str:
    return text.translate(_DIGIT_MAP)


def parse_zones_text(text: str) -> list[Zone]:
    """Parse zones from JSON or line-based (CSV/TSV/space) text.

    Accepted line formats:
        high,low
        high,low,starred
        high,low,starred,note
    High/low are sorted if the author wrote them the other way round.
    """
    cleaned = text.replace("\ufeff", "").strip()
    if not cleaned:
        raise ValueError("فایل خالی است")

    if cleaned[0] in "[{":
        return _parse_json(cleaned)
    return _parse_lines(cleaned)


def _parse_json(text: str) -> list[Zone]:
    try:
        raw = json.loads(text)
    except json.JSONDecodeError as exc:
        raise ValueError(f"JSON نامعتبر: {exc.msg} (خط {exc.lineno})") from exc
    if isinstance(raw, dict):
        raw = raw.get("zones", raw.get("data", []))
    if not isinstance(raw, list):
        raise ValueError("ساختار JSON باید آرایه‌ای از ناحیه‌ها باشد")
    zones: list[Zone] = []
    for index, item in enumerate(raw, start=1):
        try:
            if isinstance(item, dict):
                high, low = float(item["high"]), float(item["low"])
                starred = bool(item.get("starred", False))
                note = str(item.get("note", ""))
            else:
                values = list(item)
                high, low = float(values[0]), float(values[1])
                starred = bool(values[2]) if len(values) > 2 else False
                note = str(values[3]) if len(values) > 3 else ""
        except (KeyError, TypeError, ValueError, IndexError) as exc:
            raise ValueError(f"ردیف {index}: ساختار نامعتبر") from exc
        zones.append(_make_zone(high, low, starred, note, index))
    return zones


def _parse_lines(text: str) -> list[Zone]:
    zones: list[Zone] = []
    for line_no, raw_line in enumerate(text.splitlines(), start=1):
        line = normalize_digits(raw_line.strip())
        if not line or line.startswith("#") or line.startswith(";") or line.startswith("//"):
            continue
        # Prefer explicit separators so a note like "ناحیه مهم" keeps its space.
        if any(sep in line for sep in (",", ";", "\t")):
            parts = [part.strip() for part in re.split(r"[,;\t]", line)]
        else:
            parts = [part.strip() for part in line.split()]
        parts = [part for part in parts if part]
        if len(parts) < 2:
            raise ValueError(f"خط {line_no}: حداقل دو عدد (سقف و کف) لازم است")
        try:
            first, second = float(parts[0]), float(parts[1])
        except ValueError as exc:
            raise ValueError(f"خط {line_no}: عدد نامعتبر «{parts[0]}» یا «{parts[1]}»") from exc
        high, low = (first, second) if first >= second else (second, first)
        starred = len(parts) > 2 and parts[2].strip().lower() in _TRUE_TOKENS
        note = parts[3].strip() if len(parts) > 3 else ""
        zones.append(_make_zone(high, low, starred, note, line_no))
    if not zones:
        raise ValueError("هیچ ناحیه‌ای در فایل پیدا نشد")
    return zones


def _make_zone(high: float, low: float, starred: bool, note: str, row: int) -> Zone:
    if high <= 0 or low <= 0:
        raise ValueError(f"ردیف {row}: قیمت باید مثبت باشد")
    if high == low:
        raise ValueError(f"ردیف {row}: سقف و کف برابر است")
    return Zone(high=high, low=low, starred=starred, note=note)


def zone_to_row(zone: Zone) -> str:
    return f"{zone.high},{zone.low},{int(zone.starred)},{zone.note}"


class ZoneStore:
    """One file, keyed by Iran trading day: ``{"2024-03-04": [{high, low, ...}]}``."""

    def __init__(self, path: str | Path, *, fallback_latest: bool = False) -> None:
        self.path = Path(path)
        # Backtests run on historical days; reusing the newest set keeps them
        # testable. Live trading must keep strict daily expiry (default).
        self.fallback_latest = fallback_latest

    # -- io --------------------------------------------------------------
    def _load(self) -> dict[str, list[dict]]:
        if not self.path.exists():
            return {}
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return {}
        return data if isinstance(data, dict) else {}

    def _save(self, data: dict[str, list[dict]]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")

    # -- provider API ----------------------------------------------------
    def for_day(self, day: date) -> Sequence[Zone]:
        data = self._load()
        raw = data.get(day.isoformat(), [])
        if not raw and self.fallback_latest and data:
            keys = sorted(data)
            earlier = [k for k in keys if k <= day.isoformat()]
            raw = data[earlier[-1] if earlier else keys[-1]]
        zones: list[Zone] = []
        for item in raw:
            try:
                zones.append(
                    Zone(
                        high=float(item["high"]),
                        low=float(item["low"]),
                        starred=bool(item.get("starred", False)),
                        note=str(item.get("note", "")),
                    )
                )
            except (KeyError, TypeError, ValueError):
                continue
        return tuple(sorted(zones, key=lambda z: z.high, reverse=True))

    def for_datetime(self, moment) -> Sequence[Zone]:
        return self.for_day(iran_day(moment))

    def has_day(self, day: date) -> bool:
        """True only if coordinates were explicitly loaded for *this* day."""
        return bool(self._load().get(day.isoformat()))

    # -- editing API (used by the web panel) -----------------------------
    def replace_day(self, day: date, zones: Sequence[Zone]) -> None:
        if len(zones) > MAX_ZONES_PER_DAY:
            raise ValueError(f"حداکثر {MAX_ZONES_PER_DAY} ناحیه در هر روز مجاز است (دریافتی: {len(zones)})")
        data = self._load()
        data[day.isoformat()] = [
            {"high": z.high, "low": z.low, "starred": z.starred, "note": z.note} for z in zones
        ]
        self._save(data)

    def add(self, day: date, high: float, low: float, starred: bool = False, note: str = "") -> Zone:
        zone = Zone(high=high, low=low, starred=starred, note=note)
        current = list(self.for_day(day))
        if len(current) >= MAX_ZONES_PER_DAY:
            raise ValueError(f"حداکثر {MAX_ZONES_PER_DAY} ناحیه در هر روز مجاز است")
        current.append(zone)
        self.replace_day(day, current)
        return zone

    def remove(self, day: date, index: int) -> bool:
        current = list(self.for_day(day))
        if not 0 <= index < len(current):
            return False
        current.pop(index)
        self.replace_day(day, current)
        return True

    def days(self) -> list[str]:
        return sorted(self._load().keys(), reverse=True)
