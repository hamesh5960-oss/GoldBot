"""Minimal, dependency-free .xlsx writer (multi-sheet, inline strings, numbers).

XLSX is a ZIP of XML parts; writing the sheets by hand keeps the project free of
an extra dependency while still opening cleanly in Excel and LibreOffice.
"""

from __future__ import annotations

import json
import zipfile
from collections.abc import Mapping
from dataclasses import fields
from datetime import date, datetime
from pathlib import Path
from typing import Any, Sequence
from xml.sax.saxutils import escape

from ..domain.events import CAPITAL_LEVEL_ORDER, SignalLevelRecord, SignalRecord


def _content_types(count: int) -> str:
    overrides = "".join(
        f'<Override PartName="/xl/worksheets/sheet{i}.xml" '
        'ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
        for i in range(1, count + 1)
    )
    return (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
        '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
        '<Default Extension="xml" ContentType="application/xml"/>'
        '<Override PartName="/xl/workbook.xml" '
        'ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
        f"{overrides}"
        '<Override PartName="/xl/styles.xml" '
        'ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
        "</Types>"
    )


RELS = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>"""

STYLES = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <fonts count="2">
    <font><sz val="11"/><name val="Calibri"/></font>
    <font><b/><sz val="11"/><name val="Calibri"/></font>
  </fonts>
  <fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills>
  <borders count="1"><border/></borders>
  <cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
  <cellXfs count="2">
    <xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
    <xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/>
  </cellXfs>
</styleSheet>"""


def _column(index: int) -> str:
    name = ""
    index += 1
    while index:
        index, rem = divmod(index - 1, 26)
        name = chr(65 + rem) + name
    return name


def _cell(ref: str, value: Any, *, header: bool) -> str:
    style = ' s="1"' if header else ""
    if value is None:
        return f'<c r="{ref}"{style}/>'
    if isinstance(value, bool):
        return f'<c r="{ref}"{style} t="b"><v>{int(value)}</v></c>'
    if isinstance(value, (int, float)):
        return f'<c r="{ref}"{style}><v>{value}</v></c>'
    if isinstance(value, (datetime, date)):
        value = value.isoformat(sep=" ") if isinstance(value, datetime) else value.isoformat()
    text = escape(str(value))
    return f'<c r="{ref}"{style} t="inlineStr"><is><t xml:space="preserve">{text}</t></is></c>'


def _sheet_xml(headers: Sequence[str], rows: Sequence[Sequence[Any]]) -> str:
    all_rows = [list(headers)] + [list(r) for r in rows]
    xml_rows: list[str] = []
    for r_idx, row in enumerate(all_rows, start=1):
        cells = "".join(
            _cell(f"{_column(c_idx)}{r_idx}", value, header=(r_idx == 1))
            for c_idx, value in enumerate(row)
        )
        xml_rows.append(f'<row r="{r_idx}">{cells}</row>')
    return (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
        "<sheetData>" + "".join(xml_rows) + "</sheetData></worksheet>"
    )


def write_workbook(path: str | Path, sheets: Sequence[tuple[str, Sequence[str], Sequence[Sequence[Any]]]]) -> Path:
    """Write several sheets: ``[(name, headers, rows), ...]``."""
    if not sheets:
        raise ValueError("at least one sheet is required")
    out = Path(path)
    out.parent.mkdir(parents=True, exist_ok=True)

    sheet_tags = "".join(
        f'<sheet name="{escape(name)}" sheetId="{i}" r:id="rId{i}"/>'
        for i, (name, _, _) in enumerate(sheets, start=1)
    )
    workbook = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
        'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
        f"<sheets>{sheet_tags}</sheets></workbook>"
    )
    rels = "".join(
        f'<Relationship Id="rId{i}" '
        'Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" '
        f'Target="worksheets/sheet{i}.xml"/>'
        for i in range(1, len(sheets) + 1)
    )
    rels += (
        f'<Relationship Id="rId{len(sheets) + 1}" '
        'Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" '
        'Target="styles.xml"/>'
    )
    workbook_rels = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        f"{rels}</Relationships>"
    )

    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("[Content_Types].xml", _content_types(len(sheets)))
        zf.writestr("_rels/.rels", RELS)
        zf.writestr("xl/workbook.xml", workbook)
        zf.writestr("xl/_rels/workbook.xml.rels", workbook_rels)
        zf.writestr("xl/styles.xml", STYLES)
        for i, (_, headers, rows) in enumerate(sheets, start=1):
            zf.writestr(f"xl/worksheets/sheet{i}.xml", _sheet_xml(headers, rows))
    return out


def write_xlsx(path: str | Path, headers: Sequence[str], rows: Sequence[Sequence[Any]], sheet: str = "Sheet1") -> Path:
    return write_workbook(path, [(sheet, headers, rows)])


# -- signal workbook -------------------------------------------------------
# The signal journal is exported as a multi-sheet workbook.  Everything here is
# pure data shaping: the caller writes the result with write_workbook(), so the
# sheets can be unit-tested without touching the filesystem.

_SIGNAL_HEADERS: tuple[str, ...] = tuple(item.name for item in fields(SignalRecord))
_SIGNAL_JSON_FIELDS = frozenset({"gate_status", "params_snapshot"})
_LEVEL_HEADERS: tuple[str, ...] = tuple(item.name for item in fields(SignalLevelRecord))
_LEVEL_JSON_FIELDS = frozenset({"params_snapshot"})
_LEVEL_FALLBACK_REASON = "not_evaluated"

_MATRIX_BASE_HEADERS: tuple[str, ...] = (
    "signal_id",
    "tier",
    "session",
    "active_level",
    "active_decision",
    "was_missed_opportunity",
    "best_eligible_level",
)
_MATRIX_LEVEL_METRICS: tuple[str, ...] = ("eligible", "reason", "would_be_lot", "capital_gap")

_SESSION_HEADERS: tuple[str, ...] = (
    "session",
    "bucket_type",
    "bucket",
    "signals",
    "executed",
    "watch",
    "missed",
    "pnl_dollars",
)
_SUMMARY_HEADERS: tuple[str, ...] = ("metric", "value")
# Locked tier ladder (ADR-034): D is the hard-floor tier, WATCH no longer exists.
_TIER_ORDER: tuple[str, ...] = ("A+", "A", "B", "C", "D", "NOISE")
_OUTCOME_ORDER: tuple[str, ...] = ("win", "loss", "breakeven", "open")

_LEGACY_SIGNAL_HEADERS: tuple[str, ...] = (
    "row",
    "open_time",
    "close_time",
    "strategy",
    "side",
    "symbol",
    "entry",
    "exit",
    "volume",
    "profit",
    "loss",
    "net",
    "r_multiple",
    "exit_reason",
    "profile",
)


def _json_cell(value: Any) -> Any:
    """Compact, key-sorted JSON for structured cells; None stays a blank cell."""
    if value is None:
        return None
    if isinstance(value, Mapping):
        return json.dumps(
            dict(value), sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str
        )
    if isinstance(value, (list, tuple)):
        return json.dumps(list(value), sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    return value


def _signal_row(signal: SignalRecord) -> list[Any]:
    row: list[Any] = []
    for item in fields(SignalRecord):
        value = getattr(signal, item.name)
        row.append(_json_cell(value) if item.name in _SIGNAL_JSON_FIELDS else value)
    return row


def _level_row(record: SignalLevelRecord) -> list[Any]:
    row: list[Any] = []
    for item in fields(SignalLevelRecord):
        value = getattr(record, item.name)
        row.append(_json_cell(value) if item.name in _LEVEL_JSON_FIELDS else value)
    return row


def _level_index(
    levels: Sequence[SignalLevelRecord],
) -> dict[tuple[str, str], SignalLevelRecord]:
    index: dict[tuple[str, str], SignalLevelRecord] = {}
    for record in levels:
        index[(record.signal_id, record.level)] = record
    return index


def _decision_of(signal: SignalRecord) -> str:
    return (signal.active_decision or "").strip().lower()


def _is_watch_signal(signal: SignalRecord) -> bool:
    """Non-executed rows: legacy WATCH, the D hard floor, or a watch decision.

    D is the hard-floor tier (ADR-034): it never executes, it is exported for
    analysis, and its tier label stays "D" (never relabelled to WATCH).
    """
    tier = (signal.tier or "").strip().upper()
    return (
        _decision_of(signal) == "watch"
        or tier in ("WATCH", "D")
        or bool(signal.d_hard_floor)
    )


def _sum_pnl(signals: Sequence[SignalRecord]) -> float:
    return round(sum(item.pnl_dollars for item in signals if item.pnl_dollars is not None), 2)


def _tier_sort_key(tier: str) -> tuple[int, str]:
    upper = (tier or "").strip().upper()
    if upper in _TIER_ORDER:
        return (_TIER_ORDER.index(upper), "")
    return (len(_TIER_ORDER), upper)


def _outcome_sort_key(outcome: str) -> tuple[int, str]:
    if outcome in _OUTCOME_ORDER:
        return (_OUTCOME_ORDER.index(outcome), "")
    return (len(_OUTCOME_ORDER), outcome)


def _level_capability_rows(
    signals: Sequence[SignalRecord], levels: Sequence[SignalLevelRecord]
) -> list[list[Any]]:
    """Exactly four rows per signal (BASE, LOW_RISK, MEDIUM_RISK, HIGH_RISK).

    A level that was never evaluated gets a synthetic all-blank row with reason
    not_evaluated, so the sheet always has the same shape for every signal.
    """
    index = _level_index(levels)
    rows: list[list[Any]] = []
    for signal in signals:
        for level in CAPITAL_LEVEL_ORDER:
            record = index.get((signal.signal_id, level))
            if record is None:
                record = SignalLevelRecord(
                    signal_id=signal.signal_id,
                    level=level,
                    reason=_LEVEL_FALLBACK_REASON,
                    session=signal.session,
                    tier=signal.tier,
                )
            rows.append(_level_row(record))
    return rows


def _capability_matrix_headers() -> tuple[str, ...]:
    headers = list(_MATRIX_BASE_HEADERS)
    for level in CAPITAL_LEVEL_ORDER:
        for metric in _MATRIX_LEVEL_METRICS:
            headers.append(f"{level}_{metric}")
    return tuple(headers)


def _capability_matrix_rows(
    signals: Sequence[SignalRecord], levels: Sequence[SignalLevelRecord]
) -> list[list[Any]]:
    index = _level_index(levels)
    rows: list[list[Any]] = []
    for signal in signals:
        row: list[Any] = [
            signal.signal_id,
            signal.tier,
            signal.session,
            signal.active_level,
            signal.active_decision,
            signal.was_missed_opportunity,
            signal.best_eligible_level,
        ]
        for level in CAPITAL_LEVEL_ORDER:
            record = index.get((signal.signal_id, level))
            if record is None:
                row.extend([None, None, None, None])
            else:
                row.extend([record.eligible, record.reason, record.would_be_lot, record.capital_gap])
        rows.append(row)
    return rows


def _session_analysis_rows(signals: Sequence[SignalRecord]) -> list[list[Any]]:
    """Pivot-ready long rows: session x tier, session x outcome, session x missed."""
    sessions: dict[str, list[SignalRecord]] = {}
    for signal in signals:
        sessions.setdefault(signal.session or "unknown", []).append(signal)

    rows: list[list[Any]] = []
    for session in sorted(sessions):
        group = sessions[session]
        tiers = sorted({(item.tier or "unknown") for item in group}, key=_tier_sort_key)
        for tier in tiers:
            members = [item for item in group if (item.tier or "unknown") == tier]
            executed = sum(1 for item in members if _decision_of(item) == "executed")
            watch = sum(1 for item in members if _is_watch_signal(item))
            missed = sum(
                1 for item in members if _decision_of(item) in ("missed_capital", "missed_level")
            )
            rows.append([session, "tier", tier, len(members), executed, watch, missed, _sum_pnl(members)])

        outcomes: dict[str, list[SignalRecord]] = {}
        for item in group:
            key = (item.outcome or "open").strip().lower() or "open"
            outcomes.setdefault(key, []).append(item)
        for outcome in sorted(outcomes, key=_outcome_sort_key):
            members = outcomes[outcome]
            rows.append(
                [session, "outcome", outcome, len(members), None, None, None, _sum_pnl(members)]
            )

        missed_members = [
            item for item in group if _decision_of(item) in ("missed_capital", "missed_level")
        ]
        not_missed = [item for item in group if item not in missed_members]
        rows.append(
            [session, "missed", "missed", len(missed_members), None, None, len(missed_members),
             _sum_pnl(missed_members)]
        )
        rows.append(
            [session, "missed", "not_missed", len(not_missed), None, None, 0, _sum_pnl(not_missed)]
        )
    return rows


def _summary_rows(
    signals: Sequence[SignalRecord], levels: Sequence[SignalLevelRecord]
) -> list[list[Any]]:
    stamps = [item.ts_utc for item in signals if item.ts_utc]
    executed = sum(1 for item in signals if _decision_of(item) == "executed")
    watch = sum(1 for item in signals if _is_watch_signal(item))
    return [
        ["sheet_version", 1],
        ["signals_total", len(signals)],
        ["signals_executed", executed],
        ["signals_watch", watch],
        ["missed_capital", sum(1 for item in signals if _decision_of(item) == "missed_capital")],
        ["missed_level", sum(1 for item in signals if _decision_of(item) == "missed_level")],
        ["capability_rows", len(levels)],
        ["signals_with_outcome", sum(1 for item in signals if item.outcome)],
        ["pnl_dollars_total", _sum_pnl(signals)],
        ["period_start", min(stamps) if stamps else ""],
        ["period_end", max(stamps) if stamps else ""],
        ["levels_per_signal", len(CAPITAL_LEVEL_ORDER)],
    ]


def _legacy_signal_row(index: int, signal: SignalRecord) -> list[Any]:
    pnl = signal.pnl_dollars or 0.0
    profile = ""
    if isinstance(signal.params_snapshot, Mapping):
        profile = str(signal.params_snapshot.get("profile", "") or "")
    return [
        index,
        signal.ts_utc,
        signal.outcome_updated_at or "",
        signal.strategy,
        signal.side,
        signal.symbol,
        signal.entry,
        None,  # exit price is not stored on a signal row
        signal.active_lot,
        round(max(pnl, 0.0), 2),
        round(abs(min(pnl, 0.0)), 2),
        round(pnl, 2),
        None,  # realised R is a trade concept; the signal only stores planned rr_net
        signal.outcome or "",
        profile or signal.tier,
    ]


def build_signal_workbook(
    signals: Sequence[SignalRecord],
    levels: Sequence[SignalLevelRecord],
    *,
    legacy: bool = False,
) -> list[tuple[str, Sequence[str], Sequence[Sequence[Any]]]]:
    """Shape the signal journal as sheets for write_workbook().

    Full mode returns five sheets in a fixed order: Signals (one scalar column
    per SignalRecord field, dict fields as compact JSON), Level_Capability (four
    rows per signal), Capability_Matrix (wide, one row per signal),
    Session_Analysis (long pivot rows) and Summary (metadata plus counts).
    legacy=True returns a single Signals sheet with the classic trades-like
    column set for existing consumers.
    """
    if legacy:
        rows = [_legacy_signal_row(position, signal) for position, signal in enumerate(signals, start=1)]
        return [("Signals", _LEGACY_SIGNAL_HEADERS, rows)]

    return [
        ("Signals", _SIGNAL_HEADERS, [_signal_row(signal) for signal in signals]),
        (
            "Level_Capability",
            _LEVEL_HEADERS,
            _level_capability_rows(signals, levels),
        ),
        (
            "Capability_Matrix",
            _capability_matrix_headers(),
            _capability_matrix_rows(signals, levels),
        ),
        ("Session_Analysis", _SESSION_HEADERS, _session_analysis_rows(signals)),
        ("Summary", _SUMMARY_HEADERS, _summary_rows(signals, levels)),
    ]
