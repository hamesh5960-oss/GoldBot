"""Deterministic parity tapes for the known broker/execution failure modes.

Every builder returns a ScenarioTape: at least MIN_BARS M15 bars plus dense
tick bursts at the moment that matters, together with ScenarioMarkers that name
the scenario, point at the critical ticks and state the expectation the engine
must satisfy. Tapes are reproducible from fixed seeds, so a CI run and a manual
replay see byte-identical data.
"""

from __future__ import annotations

import json
import math
import random
from collections.abc import Callable, Mapping
from dataclasses import dataclass, field, replace
from datetime import datetime, timedelta, timezone
from pathlib import Path

from ..domain.model import Bar, Symbol, Tick, Timeframe, Ts
from .tape import TapeWriter

DEFAULT_SYMBOL = Symbol("XAUUSD")
TIMEFRAME: Timeframe = "M15"
MIN_BARS = 1000
DEFAULT_BARS = 1000
START = datetime(2024, 3, 4, tzinfo=timezone.utc)  # Monday session open
BAR_SECONDS = 900
POINT = 0.01

NORMAL_SPREAD = 0.20  # 20 points, matching the demo tape
GAP_PCT = 0.012  # 1.2% opening gap
SPREAD_SPIKE_MULT = 12.0
REQUOTE_POINTS = 50.0  # 50 points = 0.50 in price
DISCONNECT_SECONDS = 900.0
DISCONNECT_BARS = 8
INVALID_STOPS_POINTS = 5.0
BROKER_MIN_STOPS_POINTS = 30.0
PARTIAL_VOLUME = 0.01
SL_FAIL_SLIPPAGE_POINTS = 120.0
BURST_TICKS = 12


@dataclass(frozen=True, slots=True)
class ScenarioMarkers:
    """Machine-readable description of what a parity tape is testing."""

    scenario: str
    expected: str
    critical_bar_indexes: tuple[int, ...] = ()
    critical_tick_indexes: tuple[int, ...] = ()
    magnitudes: Mapping[str, float] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class ScenarioTape:
    """One scenario: M15 bars, replayed ticks and the markers that explain it."""

    scenario: str
    symbol: Symbol
    timeframe: Timeframe
    bars: tuple[Bar, ...]
    ticks: tuple[Tick, ...]
    markers: ScenarioMarkers

    def write_tape(self, path: str | Path, *, metadata: bool = True) -> int:
        """Write the ticks as TapeFeed JSONL; return the tick count."""
        return write_tape(self, path, metadata=metadata)


class _TapeBuilder:
    """Accumulate ticks in replay order while recording burst indexes."""

    def __init__(self, symbol: Symbol, bars: list[Bar]) -> None:
        self.symbol = symbol
        self.bars = bars
        self.ticks: list[Tick] = []

    def add(self, tick: Tick) -> int:
        index = len(self.ticks)
        self.ticks.append(tick)
        return index

    def add_burst(self, ticks: list[Tick]) -> tuple[int, ...]:
        start = len(self.ticks)
        self.ticks.extend(ticks)
        return tuple(range(start, start + len(ticks)))

    def add_regular(self, bar_index: int) -> int:
        bar = self.bars[bar_index]
        return self.add(_tick(self.symbol, bar.o, at=bar.open_time))


def _validated_bars(n_bars: int) -> int:
    if n_bars < MIN_BARS:
        raise ValueError(f"a parity tape needs at least {MIN_BARS} M15 bars, got {n_bars}")
    return n_bars


def _tick(
    symbol: Symbol,
    price: float,
    *,
    at: datetime,
    spread: float = NORMAL_SPREAD,
    volume: int = 1,
    delay_ms: float = 0.0,
) -> Tick:
    half = spread / 2.0
    return Tick(
        symbol=symbol,
        bid=round(price - half, 2),
        ask=round(price + half, 2),
        ts_event=Ts(at),
        ts_recv=Ts(at + timedelta(milliseconds=delay_ms)),
        volume=int(volume),
    )


def _base_bars(
    n_bars: int,
    *,
    symbol: Symbol,
    seed: int,
    start_price: float = 2000.0,
) -> list[Bar]:
    """Random-walk M15 bars; each open equals the previous close (no gaps)."""
    rng = random.Random(seed)
    bars: list[Bar] = []
    price = start_price
    for index in range(n_bars):
        open_price = round(price, 2)
        close = round(price * math.exp(rng.gauss(0.0, 0.0009)), 2)
        wick_up = abs(rng.gauss(0.0, 0.0004)) * close
        wick_down = abs(rng.gauss(0.0, 0.0004)) * close
        bars.append(
            Bar(
                symbol=symbol,
                timeframe=TIMEFRAME,
                open_time=START + timedelta(seconds=BAR_SECONDS * index),
                o=open_price,
                h=round(max(open_price, close) + wick_up, 2),
                l=round(min(open_price, close) - wick_down, 2),
                c=close,
                tick_volume=rng.randint(200, 1200),
                spread_avg=NORMAL_SPREAD,
            )
        )
        price = close
    return bars


def _scaled(bar: Bar, ratio: float) -> Bar:
    return replace(
        bar,
        o=round(bar.o * ratio, 2),
        h=round(bar.h * ratio, 2),
        l=round(bar.l * ratio, 2),
        c=round(bar.c * ratio, 2),
    )


def _assemble(
    scenario: str,
    *,
    symbol: Symbol,
    bars: list[Bar],
    builder: _TapeBuilder,
    expected: str,
    critical_bar_indexes: tuple[int, ...],
    critical_tick_indexes: tuple[int, ...],
    magnitudes: Mapping[str, float],
) -> ScenarioTape:
    markers = ScenarioMarkers(
        scenario=scenario,
        expected=expected,
        critical_bar_indexes=critical_bar_indexes,
        critical_tick_indexes=critical_tick_indexes,
        magnitudes=dict(magnitudes),
    )
    return ScenarioTape(
        scenario=scenario,
        symbol=symbol,
        timeframe=TIMEFRAME,
        bars=tuple(bars),
        ticks=tuple(builder.ticks),
        markers=markers,
    )


def gap_open(
    *,
    symbol: Symbol = DEFAULT_SYMBOL,
    bars: int = DEFAULT_BARS,
    seed: int = 11,
) -> ScenarioTape:
    """Weekend/open gap: price jumps GAP_PCT with ticks only at the new price."""
    n_bars = _validated_bars(bars)
    base = _base_bars(n_bars, symbol=symbol, seed=seed)
    gap_index = n_bars * 3 // 5
    ratio = 1.0 + GAP_PCT
    tape_bars = base[:gap_index] + [_scaled(bar, ratio) for bar in base[gap_index:]]
    builder = _TapeBuilder(symbol, tape_bars)

    critical_ticks: tuple[int, ...] = ()
    for index in range(n_bars):
        builder.add_regular(index)
        if index == gap_index:
            at = tape_bars[index].open_time
            burst = [
                _tick(symbol, round(tape_bars[index].o + 0.05 * offset, 2), at=at, volume=5)
                for offset in range(BURST_TICKS)
            ]
            critical_ticks = builder.add_burst(burst)

    gap_price = round(tape_bars[gap_index].o - base[gap_index - 1].c, 2)
    return _assemble(
        "gap_open",
        symbol=symbol,
        bars=tape_bars,
        builder=builder,
        expected=(
            "engine must reprice against the gap: no entry on a stale pre-gap quote and "
            "every SL/TP must be revalidated against the new price"
        ),
        critical_bar_indexes=(gap_index,),
        critical_tick_indexes=critical_ticks,
        magnitudes={"gap_pct": GAP_PCT, "gap_price": gap_price},
    )


def spread_spike(
    *,
    symbol: Symbol = DEFAULT_SYMBOL,
    bars: int = DEFAULT_BARS,
    seed: int = 12,
) -> ScenarioTape:
    """Spread widens to SPREAD_SPIKE_MULT x normal for a short burst."""
    n_bars = _validated_bars(bars)
    base = _base_bars(n_bars, symbol=symbol, seed=seed)
    spike_index = n_bars // 2
    spike_bar = replace(
        base[spike_index], spread_avg=round(NORMAL_SPREAD * SPREAD_SPIKE_MULT, 2)
    )
    tape_bars = base[:spike_index] + [spike_bar] + base[spike_index + 1 :]
    builder = _TapeBuilder(symbol, tape_bars)

    ladder = (2.0, 4.0, 6.0, 8.0, 10.0, 12.0, 12.0, 12.0, 9.0, 6.0, 4.0, 2.0)
    critical_ticks: tuple[int, ...] = ()
    for index in range(n_bars):
        builder.add_regular(index)
        if index == spike_index:
            at = tape_bars[index].open_time
            burst = [
                _tick(
                    symbol,
                    round(tape_bars[index].o + 0.03 * offset, 2),
                    at=at,
                    spread=round(NORMAL_SPREAD * mult, 2),
                    volume=2,
                )
                for offset, mult in enumerate(ladder)
            ]
            critical_ticks = builder.add_burst(burst)

    return _assemble(
        "spread_spike",
        symbol=symbol,
        bars=tape_bars,
        builder=builder,
        expected=(
            "engine must reject entries while spread exceeds the profile max_spread_points "
            "and must never widen stops or targets to compensate"
        ),
        critical_bar_indexes=(spike_index,),
        critical_tick_indexes=critical_ticks,
        magnitudes={
            "normal_spread": NORMAL_SPREAD,
            "spread_mult": SPREAD_SPIKE_MULT,
            "spike_spread": round(NORMAL_SPREAD * SPREAD_SPIKE_MULT, 2),
        },
    )


def requote(
    *,
    symbol: Symbol = DEFAULT_SYMBOL,
    bars: int = DEFAULT_BARS,
    seed: int = 13,
) -> ScenarioTape:
    """Price re-quotes REQUOTE_POINTS away between decision and send."""
    n_bars = _validated_bars(bars)
    base = _base_bars(n_bars, symbol=symbol, seed=seed)
    critical_index = n_bars * 2 // 5
    tape_bars = list(base)
    builder = _TapeBuilder(symbol, tape_bars)
    shift = REQUOTE_POINTS * POINT

    fractions = (0.0, 1.0, 1.0, 0.5, 1.0, 0.25, 1.0, 0.75, 1.0, 0.5, 0.0, 1.0)
    critical_ticks: tuple[int, ...] = ()
    for index in range(n_bars):
        builder.add_regular(index)
        if index == critical_index:
            at = tape_bars[index].open_time
            burst = [
                _tick(
                    symbol,
                    round(tape_bars[index].o + shift * fraction, 2),
                    at=at,
                    volume=3,
                    delay_ms=250.0 if offset % 2 else 0.0,
                )
                for offset, fraction in enumerate(fractions)
            ]
            critical_ticks = builder.add_burst(burst)

    return _assemble(
        "requote",
        symbol=symbol,
        bars=tape_bars,
        builder=builder,
        expected=(
            "engine must detect that price moved between signal and send (requote/slippage), "
            "re-validate SL/TP and abort an order whose price is stale"
        ),
        critical_bar_indexes=(critical_index,),
        critical_tick_indexes=critical_ticks,
        magnitudes={
            "requote_points": REQUOTE_POINTS,
            "requote_price": round(shift, 2),
        },
    )


def disconnect(
    *,
    symbol: Symbol = DEFAULT_SYMBOL,
    bars: int = DEFAULT_BARS,
    seed: int = 14,
) -> ScenarioTape:
    """The feed goes dark for longer than stale_tick_seconds, then resumes."""
    n_bars = _validated_bars(bars)
    base = _base_bars(n_bars, symbol=symbol, seed=seed)
    tape_bars = list(base)
    builder = _TapeBuilder(symbol, tape_bars)
    gap_start = n_bars // 2
    gap_end = gap_start + DISCONNECT_BARS + 1

    critical_ticks: tuple[int, ...] = ()
    for index in range(n_bars):
        if gap_start < index < gap_end:
            continue  # the feed is down: no ticks at all
        if index == gap_end:
            at = tape_bars[index].open_time
            burst = [
                _tick(
                    symbol,
                    round(tape_bars[index].o + 0.02 * offset, 2),
                    at=at + timedelta(milliseconds=100 * offset),
                    volume=4,
                )
                for offset in range(BURST_TICKS)
            ]
            critical_ticks = builder.add_burst(burst)
            continue
        builder.add_regular(index)

    return _assemble(
        "disconnect",
        symbol=symbol,
        bars=tape_bars,
        builder=builder,
        expected=(
            "engine must mark the feed stale, freeze new entries and reconcile open "
            "positions with the broker when ticks resume"
        ),
        critical_bar_indexes=(gap_start, gap_end),
        critical_tick_indexes=critical_ticks,
        magnitudes={
            "gap_seconds": DISCONNECT_SECONDS,
            "bars_without_ticks": float(DISCONNECT_BARS),
        },
    )


def invalid_stops(
    *,
    symbol: Symbol = DEFAULT_SYMBOL,
    bars: int = DEFAULT_BARS,
    seed: int = 15,
) -> ScenarioTape:
    """A stop only INVALID_STOPS_POINTS away, inside the broker stops level."""
    n_bars = _validated_bars(bars)
    base = _base_bars(n_bars, symbol=symbol, seed=seed)
    critical_index = n_bars // 2
    tape_bars = list(base)
    builder = _TapeBuilder(symbol, tape_bars)
    distance = INVALID_STOPS_POINTS * POINT

    fractions = (0.0, 0.5, 1.0, 1.0, 0.75, 0.5, 0.25, 0.5, 1.0, 0.75, 0.25, 0.0)
    critical_ticks: tuple[int, ...] = ()
    for index in range(n_bars):
        builder.add_regular(index)
        if index == critical_index:
            at = tape_bars[index].open_time
            burst = [
                _tick(
                    symbol,
                    round(tape_bars[index].o + distance * fraction, 2),
                    at=at + timedelta(milliseconds=80 * offset),
                    volume=2,
                )
                for offset, fraction in enumerate(fractions)
            ]
            critical_ticks = builder.add_burst(burst)

    return _assemble(
        "invalid_stops",
        symbol=symbol,
        bars=tape_bars,
        builder=builder,
        expected=(
            "pre-trade validation must reject the order: the SL distance is inside the "
            "broker stops_level, so the request can never be accepted"
        ),
        critical_bar_indexes=(critical_index,),
        critical_tick_indexes=critical_ticks,
        magnitudes={
            "sl_distance_points": INVALID_STOPS_POINTS,
            "broker_min_stops_points": BROKER_MIN_STOPS_POINTS,
            "sl_distance_price": round(distance, 2),
        },
    )


def partial_then_sl_fail(
    *,
    symbol: Symbol = DEFAULT_SYMBOL,
    bars: int = DEFAULT_BARS,
    seed: int = 16,
) -> ScenarioTape:
    """Partial fill, then a failed SL modify while price runs through the stop."""
    n_bars = _validated_bars(bars)
    base = _base_bars(n_bars, symbol=symbol, seed=seed)
    critical_index = n_bars // 2
    tape_bars = list(base)
    builder = _TapeBuilder(symbol, tape_bars)
    slippage = SL_FAIL_SLIPPAGE_POINTS * POINT

    fractions = (0.0, 0.0, 0.25, 0.5, 0.75, 1.0, 0.9, 1.0, 0.8, 1.0, 0.6, 0.4)
    critical_ticks: tuple[int, ...] = ()
    for index in range(n_bars):
        builder.add_regular(index)
        if index == critical_index:
            at = tape_bars[index].open_time
            burst = [
                _tick(
                    symbol,
                    round(tape_bars[index].o + slippage * fraction, 2),
                    at=at + timedelta(milliseconds=120 * offset),
                    volume=1 if offset < 4 else 5,
                )
                for offset, fraction in enumerate(fractions)
            ]
            critical_ticks = builder.add_burst(burst)

    return _assemble(
        "partial_then_sl_fail",
        symbol=symbol,
        bars=tape_bars,
        builder=builder,
        expected=(
            "a partial fill followed by a failed SL modify is UNKNOWN: the engine must "
            "keep the hedge, reconcile the position with the broker before retrying"
        ),
        critical_bar_indexes=(critical_index,),
        critical_tick_indexes=critical_ticks,
        magnitudes={
            "partial_volume": PARTIAL_VOLUME,
            "sl_slippage_points": SL_FAIL_SLIPPAGE_POINTS,
            "sl_fail_slippage_price": round(slippage, 2),
            "broker_min_stops_points": BROKER_MIN_STOPS_POINTS,
        },
    )


SCENARIOS: Mapping[str, Callable[..., ScenarioTape]] = {
    "gap_open": gap_open,
    "spread_spike": spread_spike,
    "requote": requote,
    "disconnect": disconnect,
    "invalid_stops": invalid_stops,
    "partial_then_sl_fail": partial_then_sl_fail,
}
SCENARIO_NAMES: tuple[str, ...] = tuple(SCENARIOS)


def build_scenario(name: str, **kwargs: object) -> ScenarioTape:
    """Build one named scenario; raises ValueError for an unknown name."""
    builder = SCENARIOS.get(name)
    if builder is None:
        raise ValueError(f"unknown scenario {name!r}; choose from {SCENARIO_NAMES}")
    return builder(**kwargs)  # type: ignore[arg-type]


def write_tape(tape: ScenarioTape, path: str | Path, *, metadata: bool = True) -> int:
    """Write the tape's ticks as TapeFeed JSONL; return the tick count.

    A sidecar (same path with a .meta.json suffix) records the scenario markers
    when 'metadata' is true, so a CLI run can explain what it just produced.
    """
    target = Path(path)
    count = 0
    with TapeWriter(target) as writer:
        for tick in tape.ticks:
            writer.write(tick)
            count += 1
    if metadata:
        _write_metadata(tape, target)
    return count


def _write_metadata(tape: ScenarioTape, target: Path) -> Path:
    sidecar = target.with_suffix(".meta.json")
    payload = {
        "scenario": tape.markers.scenario,
        "symbol": str(tape.symbol),
        "timeframe": tape.timeframe,
        "bars": len(tape.bars),
        "ticks": len(tape.ticks),
        "critical_bar_indexes": list(tape.markers.critical_bar_indexes),
        "critical_tick_indexes": list(tape.markers.critical_tick_indexes),
        "expected": tape.markers.expected,
        "magnitudes": dict(tape.markers.magnitudes),
    }
    sidecar.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return sidecar


def write_scenario_tape(
    name: str,
    path: str | Path,
    *,
    metadata: bool = True,
    **kwargs: object,
) -> int:
    """Build a named scenario and write it in one call (the CLI entry point)."""
    return write_tape(build_scenario(name, **kwargs), path, metadata=metadata)
