"""Typed configuration. Strict: unknown keys are a startup error, not a warning."""

from __future__ import annotations

import hashlib
import json
import tomllib
from collections.abc import Mapping
from datetime import time
from pathlib import Path
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, ValidationError, field_validator, model_validator

from ..domain.errors import ConfigError
from ..domain.model import SessionWindow, Symbol, SymbolInfo


class _Strict(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class AccountCfg(_Strict):
    login: int = 0
    server: str = "Fake-Demo"
    currency: str = "USD"
    trade_mode: Literal["hedging", "netting"] = "hedging"
    # Netting is fail-closed until the three-layer exit FSM supports it.
    allow_netting: bool = False
    initial_balance: float = Field(default=10_000.0, gt=0)
    leverage: int = Field(default=100, ge=1, le=1000)


class SymbolCfg(_Strict):
    name: str = "XAUUSD"
    broker_symbol: str = "XAUUSD.a"
    digits: int = 2
    point: float = 0.01
    contract_size: float = 100.0
    min_volume: float = 0.01
    max_volume: float = 50.0
    volume_step: float = 0.01
    stops_level_points: int = 30
    freeze_level_points: int = 0
    # 0 means "not reported by the broker"; sizing falls back to contract_size.
    tick_value: float = 0.0
    filling_mode: Literal["fok", "ioc", "return", "unknown"] = "unknown"
    margin_rate: float = 0.01
    broker_offset_hours: float = 2.0
    sessions: list[str] = Field(default_factory=lambda: ["00:00-23:59"])

    @field_validator("sessions")
    @classmethod
    def _check_sessions(cls, value: list[str]) -> list[str]:
        for item in value:
            if "-" not in item:
                raise ValueError(f"session must look like HH:MM-HH:MM, got {item!r}")
        return value


class RiskCfg(_Strict):
    profile: str = "medium"
    profiles_path: str = "config/risk_profiles.toml"
    overrides: dict[str, Any] = Field(default_factory=dict)


class ExecutionCfg(_Strict):
    magic_base: int = 7300
    slippage_points: float = 2.0
    commission_per_lot: float = 7.0
    max_slippage_points: int = 15


class CostCfg(_Strict):
    """Full cost model (spec section 6). Mirrors app.costs.CostParams exactly."""

    commission_per_lot_rt: float = Field(default=7.0, ge=0.0, le=100.0)
    point: float = Field(default=0.01, gt=0.0, le=10.0)
    contract_size: float = Field(default=100.0, gt=0.0, le=100_000.0)
    default_spread_points: float = Field(default=0.0, ge=0.0, le=500.0)
    slippage_points: float = Field(default=2.0, ge=0.0, le=500.0)
    news_slippage_points: float = Field(default=20.0, ge=0.0, le=1_000.0)
    news_window_minutes: int = Field(default=30, ge=0, le=240)
    # Signed per-lot swap per night: positive = paid, negative = credit.
    swap_long_per_lot_night: float = Field(default=12.0, ge=-100.0, le=100.0)
    swap_short_per_lot_night: float = Field(default=2.0, ge=-100.0, le=100.0)
    triple_swap_weekday: int = Field(default=2, ge=0, le=6)
    triple_swap_hour: int = Field(default=20, ge=0, le=23)


class JournalCfg(_Strict):
    path: str = "var/goldbot.db"
    json_logs: bool = False


class StrategiesCfg(_Strict):
    directory: str = "config/strategies"


class TradingCfg(_Strict):
    """Global manual controls exposed by the web panel."""

    direction: Literal["both", "long", "short"] = "both"
    # Two strategies signalling the same way within this window confirm each other.
    confluence_window_minutes: float = Field(default=30.0, ge=0.0, le=240.0)
    # An independent S/R zone of this score counts as one approval (sr_zone).
    zone_confirmation_min_score: int = Field(default=50, ge=0, le=100)
    # How far (in M15 ATR) a zone may be from the signal and still approve it.
    zone_confirmation_max_atr: float = Field(default=2.0, ge=0.2, le=5.0)
    # M15 bars kept in memory; 9600 is roughly 100 trading days.
    history_bars: int = Field(default=9600, ge=600, le=50_000)
    # Locked confirmation design (ADR-032/033): zone score is a layer-0 filter and
    # layer-3 tool votes can move the tier by one step (D is never promoted).
    zone_filter_min: float = Field(default=50.0, ge=0.0, le=100.0)
    layer3_enabled: bool = True


class GateCfg(_Strict):
    gate_a_window: int = Field(default=1, ge=0, le=11)
    burn_after_tp: int = Field(default=2, ge=0, le=96)
    burn_after_sl: int = Field(default=5, ge=0, le=96)
    burn_after_be: int = Field(default=3, ge=0, le=96)
    full_bypass_signal: float = Field(default=1.5, ge=0.0, le=2.0)
    full_bypass_zone: int = Field(default=85, ge=0, le=100)
    downgrade_min_signal: float = Field(default=1.0, ge=0.0, le=2.0)
    downgrade_min_zone: int = Field(default=70, ge=0, le=100)
    max_directional_trend: int = Field(default=2, ge=1, le=3)
    max_directional_range: int = Field(default=1, ge=1, le=2)
    profit_threshold_atr: float = Field(default=0.5, ge=0.0, le=3.0)
    hedge_size_factor: float = Field(default=0.25, ge=0.05, le=1.0)
    hedge_min_signal: float = Field(default=1.0, ge=0.0, le=2.0)
    hedge_min_zone: int = Field(default=75, ge=0, le=100)


class BudgetCfg(_Strict):
    soft_limit: int = Field(default=10, ge=1, le=40)
    hard_limit: int = Field(default=15, ge=1, le=40)
    reserve_pct: float = Field(default=0.30, ge=0.0, le=0.8)
    min_spacing_minutes: int = Field(default=10, ge=0, le=240)
    post_loss_cooldown_minutes: int = Field(default=30, ge=0, le=480)

    @field_validator("hard_limit")
    @classmethod
    def _hard_ge_soft(cls, value: int, info) -> int:
        if value < int(info.data.get("soft_limit", 10)):
            raise ValueError("hard_limit must be >= soft_limit")
        return value


class CapitalCfg(_Strict):
    risk_floor_pct: float = Field(default=0.10, ge=0.01, le=0.5)
    risk_ceiling_pct: float = Field(default=1.50, ge=0.2, le=1.5)
    portfolio_ceiling_pct: float = Field(default=3.0, ge=0.5, le=3.0)
    gate_d_max_risk_pct: float = Field(default=2.0, ge=0.5, le=3.0)
    # ADR-001: default hard line is 2% (fail-safe); config/base.toml raises it
    # to 3% explicitly. Never drift this default upward.
    gate_d_hard_pct: float = Field(default=2.0, ge=0.5, le=3.0)
    trade_risk_cap_pct: float = Field(default=1.0, ge=0.2, le=1.5)
    vol_percentile_window_days: int = Field(default=90, ge=20, le=250)

    @field_validator("gate_d_hard_pct")
    @classmethod
    def _gate_d_layers_are_ordered(cls, value: float, info) -> float:
        soft = float(info.data.get("gate_d_max_risk_pct", 2.0))
        ceiling = float(info.data.get("portfolio_ceiling_pct", 3.0))
        if value < soft:
            raise ValueError("gate_d_hard_pct must be >= gate_d_max_risk_pct")
        if value > ceiling:
            raise ValueError("gate_d_hard_pct must not exceed portfolio_ceiling_pct")
        return value


class SessionCfg(_Strict):
    friday_flat_hour_utc: int | None = Field(default=19, ge=0, le=23)
    close_all_before_weekend: bool = True


class WeekendCfg(_Strict):
    """Flat-before-the-weekly-close policy, in broker time."""

    enabled: bool = True
    close_minutes_before_session_end: int = Field(default=30, ge=20, le=60)
    max_deviation_points: int = Field(default=200, ge=1, le=2000)
    close_order: Literal["profit_first", "loss_first", "ticket"] = "profit_first"
    fallback_grace_minutes: int = Field(default=10, ge=0, le=120)



class NewsCfg(_Strict):
    enabled: bool = True
    calendar_source: Literal["csv", "none"] = "csv"
    calendar_path: str = "var/news/calendar.csv"
    refresh_interval_hours: int = Field(default=6, ge=1, le=48)
    high_impact_before_minutes: int = Field(default=30, ge=0, le=240)
    high_impact_after_minutes: int = Field(default=60, ge=0, le=240)
    medium_impact_before_minutes: int = Field(default=15, ge=0, le=240)
    medium_impact_after_minutes: int = Field(default=30, ge=0, le=240)
    fail_safe: Literal["conservative", "trading_disabled"] = "conservative"


class LevelsCfg(_Strict):
    """Opt-in capital-level controller (owner spec PART 4)."""

    enabled: bool = False
    base_enabled: bool = False
    base_armed: bool = False
    low_risk_threshold: float = Field(default=1500.0, gt=0)
    medium_risk_threshold: float = Field(default=2000.0, gt=0)
    high_risk_threshold: float = Field(default=4000.0, gt=0)
    approval_timeout_days: int = Field(default=7, ge=1, le=90)
    decline_cooldown_days: int = Field(default=30, ge=0, le=365)
    min_days_above_threshold: int = Field(default=5, ge=0, le=90)
    min_trades_in_level: int = Field(default=5, ge=0, le=1000)

    @field_validator("medium_risk_threshold")
    @classmethod
    def _thresholds_ascending(cls, value: float, info) -> float:
        low = float(info.data.get("low_risk_threshold", 1500.0))
        if value <= low:
            raise ValueError("medium_risk_threshold must exceed low_risk_threshold")
        return value

    @field_validator("high_risk_threshold")
    @classmethod
    def _high_above_medium(cls, value: float, info) -> float:
        medium = float(info.data.get("medium_risk_threshold", 2000.0))
        if value <= medium:
            raise ValueError("high_risk_threshold must exceed medium_risk_threshold")
        return value


class ZonesCfg(_Strict):
    path: str = "var/zones.json"
    # Backtests run on historical/simulated days, so reuse the newest zone set.
    fallback_to_latest: bool = False


class Settings(_Strict):
    account: AccountCfg = AccountCfg()
    symbol: SymbolCfg = SymbolCfg()
    risk: RiskCfg = RiskCfg()
    execution: ExecutionCfg = ExecutionCfg()
    costs: CostCfg = CostCfg()
    journal: JournalCfg = JournalCfg()
    strategies: StrategiesCfg = StrategiesCfg()
    trading: TradingCfg = TradingCfg()
    gates: GateCfg = GateCfg()
    capital: CapitalCfg = CapitalCfg()
    budget: BudgetCfg = BudgetCfg()
    session: SessionCfg = SessionCfg()
    weekend: WeekendCfg = WeekendCfg()
    news: NewsCfg = NewsCfg()
    levels: LevelsCfg = LevelsCfg()
    zones: ZonesCfg = ZonesCfg()

    def symbol_info(self) -> SymbolInfo:
        s = self.symbol
        windows = tuple(_parse_window(w) for w in s.sessions)
        from datetime import timedelta

        return SymbolInfo(
            symbol=Symbol(s.name),
            broker_symbol=s.broker_symbol,
            digits=s.digits,
            point=s.point,
            tick_size=s.point,
            contract_size=s.contract_size,
            min_volume=s.min_volume,
            max_volume=s.max_volume,
            volume_step=s.volume_step,
            stops_level_points=s.stops_level_points,
            freeze_level_points=s.freeze_level_points,
            tick_value=s.tick_value,
            filling_mode=s.filling_mode,
            margin_rate=s.margin_rate,
            sessions=windows,
            broker_offset=timedelta(hours=s.broker_offset_hours),
        )

    @model_validator(mode="after")
    def _duplicated_cost_sources_must_agree(self) -> "Settings":
        """Fail closed when the same instrument/cost constant is configured twice.

        ADR-019 made the cost model consume [costs].point/contract_size and
        [costs].commission_per_lot_rt while the broker/spec layer consumes
        [symbol].point/contract_size and [execution].commission_per_lot.  A silent
        divergence would misprice sizing and PnL, so the two sources are validated
        at load time instead of being reconciled at runtime.
        """
        pairs = (
            ("symbol.point", self.symbol.point, "costs.point", self.costs.point),
            (
                "symbol.contract_size",
                self.symbol.contract_size,
                "costs.contract_size",
                self.costs.contract_size,
            ),
            (
                "execution.commission_per_lot",
                self.execution.commission_per_lot,
                "costs.commission_per_lot_rt",
                self.costs.commission_per_lot_rt,
            ),
        )
        for left_name, left_value, right_name, right_value in pairs:
            if abs(float(left_value) - float(right_value)) > 1e-12:
                raise ValueError(
                    f"{left_name}={left_value:g} must equal {right_name}={right_value:g} "
                    "(duplicated instrument/cost constants, ADR-019); "
                    "align [symbol], [execution] and [costs] in config/base.toml"
                )
        return self


def _parse_window(text: str) -> SessionWindow:
    start_s, end_s = text.split("-", 1)
    sh, sm = (int(x) for x in start_s.split(":"))
    eh, em = (int(x) for x in end_s.split(":"))
    return SessionWindow(time(sh, sm), time(eh, em))


def load_settings(path: str | Path = "config/base.toml") -> Settings:
    file = Path(path)
    if not file.exists():
        raise ConfigError(f"config file not found: {file}")
    try:
        raw = tomllib.loads(file.read_text(encoding="utf-8"))
        return Settings.model_validate(raw)
    except ValidationError as exc:
        raise ConfigError(f"invalid configuration in {file}: {exc}") from exc
    except tomllib.TOMLDecodeError as exc:
        raise ConfigError(f"cannot parse {file}: {exc}") from exc


# -- config fingerprint ----------------------------------------------------
# Only *location* fields describe where the process runs; moving them must not
# change the hash.  This is an explicit allowlist (not a name heuristic): a new
# behaviour-selecting key is hashed by default instead of being silently dropped
# just because its name happens to end in "_path"/"_url"/etc.
_LOCATION_ONLY_FIELDS = frozenset(
    {
        "journal.path",
        "risk.profiles_path",
        "strategies.directory",
        "zones.path",
        "news.calendar_path",
    }
)

_PROFILE_SECTION = "profiles"


def _canonical(value: Any, prefix: str = "") -> Any:
    if isinstance(value, Mapping):
        result: dict[str, Any] = {}
        for key in sorted(value, key=lambda item: str(item)):
            name = str(key)
            dotted = f"{prefix}.{name}".lower() if prefix else name.lower()
            if dotted in _LOCATION_ONLY_FIELDS:
                continue
            result[name] = _canonical(value[key], dotted)
        return result
    if isinstance(value, (list, tuple)):
        return [_canonical(item, prefix) for item in value]
    if isinstance(value, float) and value == 0.0:
        return 0.0  # normalise -0.0 so the hash is stable
    return value


def _load_profile_document(settings: Settings) -> Mapping[str, Any]:
    """Canonical content of the selected risk profile (resolved money math).

    The profile file is behaviour-selecting but its path is only a location:
    the path string itself stays out of the hash, while the selected profile
    table is included.  Missing file/profile fails closed instead of silently
    hashing an incomplete configuration.
    """
    path = Path(settings.risk.profiles_path)
    if not path.exists():
        raise ConfigError(
            f"risk profiles file not found: {path} (risk.profiles_path); "
            "the config fingerprint must cover the effective risk profile"
        )
    try:
        document = tomllib.loads(path.read_text(encoding="utf-8"))
    except tomllib.TOMLDecodeError as exc:
        raise ConfigError(f"cannot parse risk profiles file {path}: {exc}") from exc
    profiles = document.get(_PROFILE_SECTION)
    if not isinstance(profiles, Mapping):
        raise ConfigError(f"risk profiles file {path} has no [{_PROFILE_SECTION}] table")
    selected = profiles.get(settings.risk.profile)
    if not isinstance(selected, Mapping):
        raise ConfigError(
            f"risk profile {settings.risk.profile!r} is not defined in {path}; "
            f"known profiles: {sorted(str(name) for name in profiles)}"
        )
    return {_PROFILE_SECTION: {settings.risk.profile: selected}}


def canonical_config_hash(settings: Settings) -> str:
    """SHA-256 fingerprint of the *effective* configuration.

    Inputs: the validated settings dump (location-only fields excluded), the
    selected risk-profile table from risk_profiles.toml, and the manual risk
    overrides (part of the settings dump).  Editing risk-profile money math
    therefore changes the hash, while relocating the journal/profile file does
    not.  Keys are sorted recursively and floats are normalised for stability;
    no absolute path, timestamp or host identity is hashed.
    """
    payload = _canonical(settings.model_dump(mode="json"))
    payload["risk_profile_document"] = _canonical(_load_profile_document(settings))
    text = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=True)
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def journal_config_fields(settings: Settings) -> dict[str, str]:
    """Journal payload fragment carrying the effective-config fingerprint."""
    return {"config_hash": canonical_config_hash(settings), "profile": settings.risk.profile}
