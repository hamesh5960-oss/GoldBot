"""Notifiers: make critical failures audible without waking the operator for noise.

Layering: adapters may import ports and stdlib only; nothing here raises, because a
failing alert channel must never be the reason the trading loop stops. Every
adapter returns True only when the message actually left the process.
"""

from __future__ import annotations

import json
import logging
import os
import smtplib
import time
import urllib.parse
import urllib.request
from email.message import EmailMessage
from typing import Callable, Mapping, Sequence

from ..log import get_logger, log
from ..ports.notify import INotifier, Level

_TELEGRAM_API = "https://api.telegram.org"
_LEVELS = {"info": logging.INFO, "warn": logging.WARNING, "critical": logging.CRITICAL}
_RATE_WINDOW_SECONDS = 60.0
_DEFAULT_TIMEOUT = 5.0


def _timeout(value: float) -> float:
    """Clamp to the 5s budget: an alert channel must not stall the caller."""
    try:
        seconds = float(value)
    except (TypeError, ValueError):
        return _DEFAULT_TIMEOUT
    return min(_DEFAULT_TIMEOUT, max(0.1, seconds))


class LogNotifier:
    """Always-on last resort: the alert still lands in the structured log."""

    def __init__(self, logger: logging.Logger | None = None) -> None:
        self._logger = logger if logger is not None else get_logger("notify")

    def send(self, level: Level, title: str, body: str, *, dedup_key: str = "") -> bool:
        log(self._logger, _LEVELS.get(level, logging.INFO), f"{title}: {body}", dedup_key=dedup_key)
        return True


class TelegramNotifier:
    """Telegram Bot API over stdlib urllib; failures are reported, never raised."""

    def __init__(self, token: str, chat_id: str, timeout: float = 5.0) -> None:
        self._token = str(token)
        self._chat_id = str(chat_id)
        self._timeout = _timeout(timeout)
        self._logger = get_logger("notify.telegram")

    def send(self, level: Level, title: str, body: str, *, dedup_key: str = "") -> bool:
        text = f"[GOLDBOT {level.upper()}] {title}\n\n{body}"
        data = urllib.parse.urlencode({"chat_id": self._chat_id, "text": text}).encode("utf-8")
        url = f"{_TELEGRAM_API}/bot{self._token}/sendMessage"
        request = urllib.request.Request(url, data=data, method="POST")
        try:
            with urllib.request.urlopen(request, timeout=self._timeout) as response:
                raw = response.read()
                status = int(getattr(response, "status", 200))
        except Exception as exc:  # noqa: BLE001 - an alert must never crash the caller
            log(
                self._logger,
                logging.ERROR,
                "telegram notify failed",
                error=str(exc).replace(self._token, "***"),
                dedup_key=dedup_key,
            )
            return False
        if status != 200:
            log(self._logger, logging.ERROR, "telegram notify rejected", status=status)
            return False
        # Telegram answers {"ok": false} with HTTP 200 only for API-level problems.
        try:
            payload = json.loads(raw.decode("utf-8") or "{}")
        except ValueError:
            return True
        return bool(payload.get("ok", True)) if isinstance(payload, dict) else True


class SmtpNotifier:
    """Plain SMTP/STARTTLS email; fail-safe like every other channel."""

    def __init__(
        self,
        host: str,
        port: int,
        user: str,
        password: str,
        to: str,
        use_tls: bool = True,
        timeout: float = 5.0,
    ) -> None:
        self._host = str(host)
        self._port = int(port)
        self._user = str(user)
        self._password = str(password)
        self._to = str(to)
        self._use_tls = bool(use_tls)
        self._timeout = _timeout(timeout)
        self._logger = get_logger("notify.smtp")

    def send(self, level: Level, title: str, body: str, *, dedup_key: str = "") -> bool:
        message = EmailMessage()
        message["From"] = self._user or "goldbot@localhost"
        message["To"] = self._to
        message["Subject"] = f"[GoldBot {level.upper()}] {title}"
        message.set_content(body)
        client: smtplib.SMTP | None = None
        try:
            client = smtplib.SMTP(self._host, self._port, timeout=self._timeout)
            if self._use_tls:
                client.starttls()
            if self._user:
                client.login(self._user, self._password)
            client.send_message(message)
            return True
        except Exception as exc:  # noqa: BLE001 - an alert must never crash the caller
            log(self._logger, logging.ERROR, "smtp notify failed", error=str(exc), dedup_key=dedup_key)
            return False
        finally:
            if client is not None:
                try:
                    client.quit()
                except Exception:  # noqa: BLE001 - best effort cleanup
                    pass


class DedupNotifier:
    """Suppress repeats within a TTL and cap the rolling one-minute rate.

    The dedup map records only *delivered* messages, so a transient channel
    failure can still be retried on the next call.
    """

    def __init__(
        self,
        inner: INotifier,
        ttl_seconds: float = 600.0,
        max_per_minute: int = 10,
        *,
        monotonic: Callable[[], float] = time.monotonic,
    ) -> None:
        self._inner = inner
        self._ttl = max(0.0, float(ttl_seconds))
        self._max_per_minute = max(1, int(max_per_minute))
        self._monotonic = monotonic
        self._last_sent: dict[str, float] = {}
        self._window: list[float] = []
        self._logger = get_logger("notify.dedup")

    @property
    def inner(self) -> INotifier:
        return self._inner

    def send(self, level: Level, title: str, body: str, *, dedup_key: str = "") -> bool:
        now = self._monotonic()
        self._prune(now)
        if dedup_key and self._ttl > 0.0:
            last = self._last_sent.get(dedup_key)
            if last is not None and now - last < self._ttl:
                return False
        if len(self._window) >= self._max_per_minute:
            log(self._logger, logging.WARNING, "notify rate limited", dedup_key=dedup_key)
            return False
        self._window.append(now)
        try:
            delivered = bool(self._inner.send(level, title, body, dedup_key=dedup_key))
        except Exception as exc:  # noqa: BLE001 - a broken channel is a delivery failure
            log(self._logger, logging.ERROR, "notify channel failed", error=str(exc), dedup_key=dedup_key)
            return False
        if delivered and dedup_key and self._ttl > 0.0:
            self._last_sent[dedup_key] = now
        return delivered

    def _prune(self, now: float) -> None:
        cutoff = now - _RATE_WINDOW_SECONDS
        while self._window and self._window[0] <= cutoff:
            self._window.pop(0)
        if len(self._last_sent) > 256:
            for key in [k for k, sent in self._last_sent.items() if now - sent >= self._ttl]:
                del self._last_sent[key]


class MultiNotifier:
    """Fan-out: every channel is attempted; True if at least one delivered."""

    def __init__(self, notifiers: Sequence[INotifier]) -> None:
        self._notifiers = [notifier for notifier in notifiers]
        self._logger = get_logger("notify.multi")

    def send(self, level: Level, title: str, body: str, *, dedup_key: str = "") -> bool:
        delivered = False
        for notifier in self._notifiers:
            try:
                if notifier.send(level, title, body, dedup_key=dedup_key):
                    delivered = True
            except Exception as exc:  # noqa: BLE001 - one bad channel must not hide the rest
                log(self._logger, logging.ERROR, "notify channel failed", error=str(exc))
        return delivered


def _text(environ: Mapping[str, str], *names: str) -> str:
    for name in names:
        value = environ.get(name)
        if value and value.strip():
            return value.strip()
    return ""


def _truthy(value: str | None, default: bool = True) -> bool:
    if value is None or not value.strip():
        return default
    return value.strip().lower() not in {"0", "false", "no", "off"}


def _port(value: str, default: int = 587) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def from_env(
    environ: Mapping[str, str] | None = None,
    *,
    ttl_seconds: float = 600.0,
    max_per_minute: int = 10,
) -> INotifier | None:
    """Build the configured operator channel, or None when none is configured.

    Recognised variables:
        GOLDBOT_TELEGRAM_TOKEN, GOLDBOT_TELEGRAM_CHAT_ID (alias ..._CHAT)
        GOLDBOT_SMTP_HOST, GOLDBOT_SMTP_PORT, GOLDBOT_SMTP_USER,
        GOLDBOT_SMTP_PASSWORD, GOLDBOT_SMTP_TO, GOLDBOT_SMTP_TLS
    """
    env = os.environ if environ is None else environ
    channels: list[INotifier] = []
    token = _text(env, "GOLDBOT_TELEGRAM_TOKEN")
    chat = _text(env, "GOLDBOT_TELEGRAM_CHAT_ID", "GOLDBOT_TELEGRAM_CHAT")
    if token and chat:
        channels.append(TelegramNotifier(token, chat))
    host = _text(env, "GOLDBOT_SMTP_HOST")
    if host:
        user = _text(env, "GOLDBOT_SMTP_USER")
        password = _text(env, "GOLDBOT_SMTP_PASSWORD")
        to = _text(env, "GOLDBOT_SMTP_TO") or user
        if to:
            channels.append(
                SmtpNotifier(
                    host,
                    _port(_text(env, "GOLDBOT_SMTP_PORT") or "587"),
                    user,
                    password,
                    to,
                    use_tls=_truthy(env.get("GOLDBOT_SMTP_TLS"), True),
                )
            )
    if not channels:
        return None
    inner: INotifier = channels[0] if len(channels) == 1 else MultiNotifier(channels)
    return DedupNotifier(inner, ttl_seconds=ttl_seconds, max_per_minute=max_per_minute)
