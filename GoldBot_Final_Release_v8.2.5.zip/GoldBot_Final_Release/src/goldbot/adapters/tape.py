"""Tape feed: JSONL ticks, plus a deterministic synthetic generator for demos.

Tape contract (one JSON object per line, UTF-8, blank lines skipped):

    {"ts": <float epoch seconds UTC>, "bid": <float>, "ask": <float>, "v": <int>}

"ts" must be non-decreasing, "bid"/"ask" must be finite and positive with
bid <= ask, and "v" (optional, default 0) must be a non-negative integer.
Every line is validated before a replay starts, so a broken tape can never
reach the broker: TapeFeed validates the whole file in __init__ and raises
TapeFormatError with the offending line number.

End of tape: by default a synthetic *closing tick* is appended at the next
multiple of closing_tick_seconds (3600 by default, a multiple of M1..H1). It
carries the last quote with volume 0 and exists only to close the final
incomplete bar of every configured timeframe, so the last bar is reviewed by
the engine exactly once instead of being silently dropped. Pass
close_final_bar=False for byte-for-byte historical replay of the file.
"""

from __future__ import annotations

import json
import math
import random
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Iterator

from ..domain.model import Symbol, SymbolInfo, Tick, Ts, utc
from ..ports.marketdata import MarketSnapshot

_REQUIRED_TICK_KEYS = ("ts", "bid", "ask")


class TapeFormatError(ValueError):
    """The tape file violates the replay contract; replay must not start."""


@dataclass(frozen=True, slots=True)
class TapeSummary:
    """What validation found in a tape, without keeping the ticks in memory."""

    path: Path
    ticks: int
    first_ts: datetime
    last_ts: datetime
    max_spread: float
    size_bytes: int

    @property
    def span_seconds(self) -> float:
        return (self.last_ts - self.first_ts).total_seconds()


def _parse_tick(raw: str, lineno: int, symbol: Symbol) -> tuple[Tick, float]:
    """Parse and validate one JSONL line; every failure names the line."""
    try:
        row = json.loads(raw)
    except ValueError as exc:
        raise TapeFormatError(f"line {lineno}: invalid JSON: {exc}") from None
    if not isinstance(row, dict):
        raise TapeFormatError(f"line {lineno}: expected a JSON object, got {type(row).__name__}")
    missing = [key for key in _REQUIRED_TICK_KEYS if key not in row]
    if missing:
        raise TapeFormatError(f"line {lineno}: missing required field(s) {missing}")

    def number(key: str) -> float:
        try:
            value = float(row[key])
        except (TypeError, ValueError):
            raise TapeFormatError(
                f"line {lineno}: field {key!r} is not a number: {row[key]!r}"
            ) from None
        if not math.isfinite(value):
            raise TapeFormatError(f"line {lineno}: field {key!r} is not finite: {value!r}")
        return value

    stamp = number("ts")
    bid = number("bid")
    ask = number("ask")
    if stamp <= 0.0:
        raise TapeFormatError(f"line {lineno}: ts must be a positive epoch second, got {stamp}")
    if bid <= 0.0 or ask <= 0.0:
        raise TapeFormatError(f"line {lineno}: bid/ask must be positive, got bid={bid} ask={ask}")
    if bid > ask:
        raise TapeFormatError(f"line {lineno}: bid {bid} > ask {ask}")

    volume = row.get("v", 0)
    try:
        parsed_volume = float(volume)
    except (TypeError, ValueError):
        raise TapeFormatError(f"line {lineno}: field 'v' is not a number: {volume!r}") from None
    if not math.isfinite(parsed_volume) or parsed_volume < 0.0 or parsed_volume != int(parsed_volume):
        raise TapeFormatError(f"line {lineno}: field 'v' must be a non-negative integer, got {volume!r}")

    try:
        wall = datetime.fromtimestamp(stamp, tz=timezone.utc)
    except (OverflowError, OSError, ValueError):
        raise TapeFormatError(f"line {lineno}: ts {stamp!r} is outside the representable range") from None
    tick = Tick(
        symbol=symbol,
        bid=bid,
        ask=ask,
        ts_event=Ts(wall),
        ts_recv=Ts(wall),
        volume=int(parsed_volume),
    )
    return tick, ask - bid


def validate_tape(path: str | Path) -> TapeSummary:
    """Validate a whole tape before replay; return a summary or raise TapeFormatError."""
    target = Path(path)
    try:
        size_bytes = target.stat().st_size
    except OSError as exc:
        raise TapeFormatError(f"tape is not readable: {target} ({exc.strerror or exc})") from None
    try:
        handle = target.open("r", encoding="utf-8")
    except OSError as exc:
        raise TapeFormatError(f"tape is not readable: {target} ({exc.strerror or exc})") from None

    ticks = 0
    first_ts: datetime | None = None
    last_ts: datetime | None = None
    previous_ts: datetime | None = None
    max_spread = 0.0
    with handle:
        for lineno, raw in enumerate(handle, 1):
            line = raw.strip()
            if not line:
                continue
            tick, spread = _parse_tick(line, lineno, Symbol("TAPE"))
            stamp = tick.ts_event.wall
            if previous_ts is not None and stamp < previous_ts:
                raise TapeFormatError(
                    f"line {lineno}: non-monotonic timestamp {stamp.isoformat()} "
                    f"< previous {previous_ts.isoformat()}"
                )
            ticks += 1
            if first_ts is None:
                first_ts = stamp
            last_ts = stamp
            previous_ts = stamp
            if spread > max_spread:
                max_spread = spread
    if ticks == 0 or first_ts is None or last_ts is None:
        raise TapeFormatError(f"tape is empty: {target}")
    return TapeSummary(
        path=target,
        ticks=ticks,
        first_ts=first_ts,
        last_ts=last_ts,
        max_spread=max_spread,
        size_bytes=size_bytes,
    )


class TapeFeed:
    """Replays recorded ticks. Same contract as the live feed."""

    def __init__(
        self,
        path: str | Path,
        symbol: Symbol,
        info: SymbolInfo,
        *,
        validate: bool = True,
        close_final_bar: bool = True,
        closing_tick_seconds: int = 3600,
    ) -> None:
        self.path = Path(path)
        self.symbol = symbol
        self.info = info
        self._last: Tick | None = None
        self._count = 0
        self.close_final_bar = bool(close_final_bar)
        self.closing_tick_seconds = max(1, int(closing_tick_seconds))
        self.closing_tick: Tick | None = None
        # Fail closed BEFORE the engine connects the broker: a malformed tape
        # must never reach start()/reconciliation with partial data.
        self.summary: TapeSummary | None = validate_tape(self.path) if validate else None

    def stream(self) -> Iterator[Tick]:
        with self.path.open("r", encoding="utf-8") as handle:
            for lineno, raw in enumerate(handle, 1):
                line = raw.strip()
                if not line:
                    continue
                tick, _ = _parse_tick(line, lineno, self.symbol)
                self._last = tick
                self._count += 1
                yield tick
        if self.close_final_bar and self._last is not None:
            closing = self._closing_tick(self._last)
            self.closing_tick = closing
            yield closing

    def _closing_tick(self, last: Tick) -> Tick:
        """A volume-0 tick in the next bucket that closes the final partial bar."""
        step = self.closing_tick_seconds
        boundary = (int(last.ts_event.wall.timestamp()) // step + 1) * step
        wall = datetime.fromtimestamp(boundary, tz=timezone.utc)
        return Tick(
            symbol=self.symbol,
            bid=last.bid,
            ask=last.ask,
            ts_event=Ts(wall),
            ts_recv=Ts(wall),
            volume=0,
        )

    @property
    def ticks_processed(self) -> int:
        return self._count

    def last_known(self, symbol: Symbol) -> MarketSnapshot | None:
        if self._last is None:
            return None
        return MarketSnapshot(symbol, self._last, None, self._last.spread)

    def staleness(self, symbol: Symbol, now: datetime) -> float:
        if self._last is None:
            return math.inf
        return (utc(now) - self._last.ts_event.wall).total_seconds()


class TapeWriter:
    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._handle = self.path.open("w", encoding="utf-8")

    def write(self, tick: Tick) -> None:
        self._handle.write(
            json.dumps(
                {"ts": tick.ts_event.wall.timestamp(), "bid": tick.bid, "ask": tick.ask, "v": tick.volume}
            )
            + "\n"
        )

    def close(self) -> None:
        self._handle.close()

    def __enter__(self) -> "TapeWriter":
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()


def generate_synthetic_ticks(
    *,
    symbol: Symbol,
    start: datetime,
    days: int = 10,
    ticks_per_minute: int = 4,
    start_price: float = 4000.0,
    spread_points: float = 20.0,
    point: float = 0.01,
    seed: int = 7,
    skip_weekend: bool = True,
) -> Iterator[Tick]:
    """Random-walk gold prices with intraday volatility and session gaps.

    Deterministic for a given seed, so a tape is reproducible and testable.
    """
    rng = random.Random(seed)
    price = start_price
    step = timedelta(seconds=60 / ticks_per_minute)
    current = utc(start).replace(second=0, microsecond=0)
    end = current + timedelta(days=days)
    spread = spread_points * point

    # Calibrated to gold's order of magnitude: ~1% daily vol, ~0.06% intraday drift.
    ticks_per_day = max(1, 1440 * ticks_per_minute)
    step_sigma = 0.010 / math.sqrt(ticks_per_day)
    previous_weekday = current.weekday()

    while current < end:
        weekday = current.weekday()
        if skip_weekend and weekday >= 5:
            current += step
            continue
        # Monday open gaps away from Friday's close (weekend risk, made explicit).
        if skip_weekend and weekday == 0 and previous_weekday >= 5:
            price *= math.exp(rng.gauss(0.0, 0.0035))
        previous_weekday = weekday

        hour = current.hour
        session_mult = 1.4 if 12 <= hour < 17 else (0.75 if hour < 7 else 1.0)
        drift_per_tick = 0.0006 * math.sin((hour - 6) / 24 * 2 * math.pi) / ticks_per_day
        price *= math.exp(rng.gauss(drift_per_tick, step_sigma * session_mult))
        half = spread / 2.0
        bid = round(price - half, 2)
        ask = round(price + half, 2)
        yield Tick(
            symbol=symbol,
            bid=bid,
            ask=ask,
            ts_event=Ts(current),
            ts_recv=Ts(current),
            volume=rng.randint(1, 40),
        )
        current += step


def write_synthetic_tape(path: str | Path, **kwargs: object) -> int:
    count = 0
    with TapeWriter(path) as writer:
        for tick in generate_synthetic_ticks(**kwargs):  # type: ignore[arg-type]
            writer.write(tick)
            count += 1
    return count
