"""SQLite journal: events, trade projection, signal journal and equity curve."""

from __future__ import annotations

import json
import sqlite3
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

from ..domain.events import Event, SignalLevelRecord, SignalRecord, TradeRecord
from ..domain.model import Ts, utc

SCHEMA = """
CREATE TABLE IF NOT EXISTS events (
    seq INTEGER PRIMARY KEY AUTOINCREMENT,
    type TEXT NOT NULL,
    ts TEXT NOT NULL,
    correlation_id TEXT NOT NULL DEFAULT '',
    actor TEXT NOT NULL DEFAULT 'system',
    stream TEXT NOT NULL DEFAULT 'default',
    payload TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_events_type ON events(type);
CREATE INDEX IF NOT EXISTS idx_events_corr ON events(correlation_id);

CREATE TABLE IF NOT EXISTS trades (
    trade_id TEXT PRIMARY KEY,
    slot TEXT NOT NULL,
    strategy TEXT NOT NULL,
    symbol TEXT NOT NULL,
    side TEXT NOT NULL,
    open_time TEXT NOT NULL,
    close_time TEXT,
    pnl_net REAL NOT NULL DEFAULT 0,
    volume REAL NOT NULL DEFAULT 0,
    payload TEXT NOT NULL,
    config_hash TEXT,
    entry_slippage_pts REAL,
    spread_at_signal_pts REAL,
    spread_at_fill_pts REAL,
    latency_ms REAL,
    mt5_deal_ids TEXT,
    commission_actual REAL,
    swap_actual REAL,
    estimated_cost REAL,
    actual_cost REAL
);
CREATE INDEX IF NOT EXISTS idx_trades_slot ON trades(slot);

CREATE TABLE IF NOT EXISTS equity (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts TEXT NOT NULL,
    equity REAL NOT NULL,
    balance REAL NOT NULL
);
"""

# Signal journal: every evaluated signal plus one capability row per capital
# level.  Both tables are new, so CREATE IF NOT EXISTS is the whole migration
# for a pre-signal journal (column additions use the PRAGMA/ALTER path instead).
SIGNAL_SCHEMA = """
CREATE TABLE IF NOT EXISTS signal_journal (
    signal_id TEXT PRIMARY KEY,
    ts_utc TEXT NOT NULL DEFAULT '',
    symbol TEXT NOT NULL DEFAULT '',
    side TEXT NOT NULL DEFAULT '',
    strategy TEXT NOT NULL DEFAULT '',
    session TEXT NOT NULL DEFAULT '',
    tier TEXT NOT NULL DEFAULT '',
    active_level TEXT NOT NULL DEFAULT '',
    active_decision TEXT NOT NULL DEFAULT '',
    was_missed_opportunity INTEGER NOT NULL DEFAULT 0,
    payload TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_signal_ts ON signal_journal(ts_utc);
CREATE INDEX IF NOT EXISTS idx_signal_session ON signal_journal(session);
CREATE INDEX IF NOT EXISTS idx_signal_tier ON signal_journal(tier);

CREATE TABLE IF NOT EXISTS signal_level_capability (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    signal_id TEXT NOT NULL,
    level TEXT NOT NULL,
    eligible INTEGER NOT NULL DEFAULT 0,
    reason TEXT NOT NULL DEFAULT '',
    payload TEXT NOT NULL,
    UNIQUE(signal_id, level)
);
CREATE INDEX IF NOT EXISTS idx_level_signal ON signal_level_capability(signal_id);
CREATE INDEX IF NOT EXISTS idx_level_level ON signal_level_capability(level);
"""

# Trade projection columns: the base set is the v1 schema; the audit/cost set was
# added later and stays nullable so pre-existing journals migrate in place.
_TRADE_BASE_COLUMNS = (
    "trade_id",
    "slot",
    "strategy",
    "symbol",
    "side",
    "open_time",
    "close_time",
    "pnl_net",
    "volume",
    "payload",
)
_TRADE_COST_COLUMNS = (
    "config_hash",
    "entry_slippage_pts",
    "spread_at_signal_pts",
    "spread_at_fill_pts",
    "latency_ms",
    "mt5_deal_ids",
    "commission_actual",
    "swap_actual",
    "estimated_cost",
    "actual_cost",
)
_TRADE_COST_COLUMN_TYPES = {
    "config_hash": "TEXT",
    "entry_slippage_pts": "REAL",
    "spread_at_signal_pts": "REAL",
    "spread_at_fill_pts": "REAL",
    "latency_ms": "REAL",
    "mt5_deal_ids": "TEXT",
    "commission_actual": "REAL",
    "swap_actual": "REAL",
    "estimated_cost": "REAL",
    "actual_cost": "REAL",
}


def _column_value(column: str, value: Any) -> Any:
    """SQLite projection of one optional trade field (deal ids as JSON text)."""
    if column == "mt5_deal_ids":
        if value is None:
            return None
        return value if isinstance(value, str) else json.dumps(value, separators=(",", ":"))
    return value


class SqliteJournal:
    """Single-writer store. WAL + explicit commits keep crash recovery honest."""

    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(self.path)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        # FULL: the write-ahead record is on disk before submit() is called.
        self._conn.execute("PRAGMA synchronous=FULL")
        self._conn.executescript(SCHEMA)
        self._migrate_trades()
        self._migrate_signals()
        self._conn.commit()

    def close(self) -> None:
        self._conn.close()

    # -- schema ----------------------------------------------------------
    def _migrate_trades(self) -> None:
        """Additive migration: a pre-cost journal gains the nullable columns.

        CREATE TABLE IF NOT EXISTS never alters an existing table, so new columns
        must be appended explicitly.  PRAGMA table_info is the only portable
        introspection SQLite offers for this.
        """
        existing = {row["name"] for row in self._conn.execute("PRAGMA table_info(trades)")}
        for column in _TRADE_COST_COLUMNS:
            if column not in existing:
                self._conn.execute(
                    f"ALTER TABLE trades ADD COLUMN {column} {_TRADE_COST_COLUMN_TYPES[column]}"
                )

    def _migrate_signals(self) -> None:
        """Create the signal tables on demand (idempotent, pre-signal DBs included)."""
        self._conn.executescript(SIGNAL_SCHEMA)

    # -- events ----------------------------------------------------------
    def append(self, event: Event, *, fsync: bool = True) -> int:
        payload = json.dumps(event.payload, default=str, ensure_ascii=False)
        cur = self._conn.execute(
            "INSERT INTO events(type, ts, correlation_id, actor, stream, payload) VALUES (?,?,?,?,?,?)",
            (
                event.type,
                event.ts.wall.isoformat(),
                event.correlation_id,
                event.actor,
                event.stream,
                payload,
            ),
        )
        # synchronous=FULL makes this commit durable before we return.
        self._conn.commit()
        return int(cur.lastrowid or 0)

    def read_events(
        self, *, type: str | None = None, correlation_id: str | None = None, limit: int = 1000
    ) -> Iterable[Event]:
        sql = "SELECT * FROM events"
        clauses, args = [], []
        if type:
            clauses.append("type = ?")
            args.append(type)
        if correlation_id:
            clauses.append("correlation_id = ?")
            args.append(correlation_id)
        if clauses:
            sql += " WHERE " + " AND ".join(clauses)
        sql += " ORDER BY seq ASC LIMIT ?"
        args.append(limit)
        for row in self._conn.execute(sql, args):
            yield Event(
                type=row["type"],
                payload=json.loads(row["payload"]),
                ts=Ts(datetime.fromisoformat(row["ts"])),
                correlation_id=row["correlation_id"],
                actor=row["actor"],
                stream=row["stream"],
            )

    def count(self) -> int:
        return int(self._conn.execute("SELECT COUNT(*) AS c FROM events").fetchone()["c"])

    # -- trades ----------------------------------------------------------
    def record_trade(self, record: TradeRecord) -> None:
        columns = _TRADE_BASE_COLUMNS + _TRADE_COST_COLUMNS
        values: list[Any] = [
            record.trade_id,
            record.slot,
            record.strategy,
            record.symbol,
            record.side,
            record.open_time,
            record.close_time,
            record.pnl_net,
            record.volume,
            json.dumps(asdict(record), default=str, ensure_ascii=False),
        ]
        values.extend(
            _column_value(column, getattr(record, column, None)) for column in _TRADE_COST_COLUMNS
        )
        placeholders = ",".join("?" for _ in columns)
        self._conn.execute(
            f"INSERT OR REPLACE INTO trades ({', '.join(columns)}) VALUES ({placeholders})",
            values,
        )
        self._conn.commit()

    def update_trade(self, trade_id: str, **fields: Any) -> None:
        row = self._conn.execute("SELECT payload FROM trades WHERE trade_id = ?", (trade_id,)).fetchone()
        if row is None:
            return
        payload = json.loads(row["payload"])
        payload.update(fields)
        assignments = ["close_time = ?", "pnl_net = ?", "payload = ?"]
        assignments.extend(f"{column} = ?" for column in _TRADE_COST_COLUMNS)
        values: list[Any] = [
            payload.get("close_time"),
            payload.get("pnl_net", 0.0),
            json.dumps(payload, ensure_ascii=False),
        ]
        values.extend(_column_value(column, payload.get(column)) for column in _TRADE_COST_COLUMNS)
        values.append(trade_id)
        self._conn.execute(
            f"UPDATE trades SET {', '.join(assignments)} WHERE trade_id = ?",
            values,
        )
        self._conn.commit()

    def trade(self, trade_id: str) -> TradeRecord | None:
        row = self._conn.execute("SELECT payload FROM trades WHERE trade_id = ?", (trade_id,)).fetchone()
        return None if row is None else TradeRecord(**json.loads(row["payload"]))

    def trades(self) -> Sequence[TradeRecord]:
        rows = self._conn.execute("SELECT payload FROM trades ORDER BY open_time ASC").fetchall()
        return [TradeRecord(**json.loads(r["payload"])) for r in rows]

    # -- signals ---------------------------------------------------------
    def record_signal(self, signal: SignalRecord) -> None:
        self._conn.execute(
            """INSERT OR REPLACE INTO signal_journal
               (signal_id, ts_utc, symbol, side, strategy, session, tier,
                active_level, active_decision, was_missed_opportunity, payload)
               VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
            (
                signal.signal_id,
                signal.ts_utc,
                signal.symbol,
                signal.side,
                signal.strategy,
                signal.session,
                signal.tier,
                signal.active_level,
                signal.active_decision,
                int(bool(signal.was_missed_opportunity)),
                json.dumps(asdict(signal), default=str, ensure_ascii=False),
            ),
        )
        self._conn.commit()

    def record_signal_levels(self, signal_id: str, levels: Sequence[SignalLevelRecord]) -> None:
        """Upsert one signal's capability matrix (UNIQUE(signal_id, level)).

        The explicit signal_id wins over a level row's own id, so callers can
        build level rows before the id is assigned.  Re-evaluating a level
        replaces the previous row instead of duplicating it.
        """
        for level in levels:
            payload = asdict(level)
            payload["signal_id"] = signal_id
            self._conn.execute(
                """INSERT OR REPLACE INTO signal_level_capability
                   (signal_id, level, eligible, reason, payload) VALUES (?,?,?,?,?)""",
                (
                    signal_id,
                    level.level,
                    int(bool(level.eligible)),
                    level.reason,
                    json.dumps(payload, default=str, ensure_ascii=False),
                ),
            )
        self._conn.commit()

    def signals(self, limit: int = 1000, since: str | None = None) -> Sequence[SignalRecord]:
        """Journal order (ts_utc, then insertion); since is an inclusive bound."""
        sql = "SELECT payload FROM signal_journal"
        args: list[Any] = []
        if since:
            sql += " WHERE ts_utc >= ?"
            args.append(since)
        sql += " ORDER BY ts_utc ASC, rowid ASC LIMIT ?"
        args.append(limit)
        return [SignalRecord(**json.loads(row["payload"])) for row in self._conn.execute(sql, args)]

    def signal_levels(
        self, signal_id: str | None = None, limit: int = 4000
    ) -> Sequence[SignalLevelRecord]:
        sql = "SELECT payload FROM signal_level_capability"
        args: list[Any] = []
        if signal_id:
            sql += " WHERE signal_id = ?"
            args.append(signal_id)
        sql += " ORDER BY signal_id ASC, level ASC, id ASC LIMIT ?"
        args.append(limit)
        return [
            SignalLevelRecord(**json.loads(row["payload"]))
            for row in self._conn.execute(sql, args)
        ]

    def update_signal_outcome(
        self, signal_id: str, outcome: str, pnl_dollars: float | None, at: str
    ) -> None:
        row = self._conn.execute(
            "SELECT payload FROM signal_journal WHERE signal_id = ?", (signal_id,)
        ).fetchone()
        if row is None:
            return
        payload = json.loads(row["payload"])
        payload["outcome"] = outcome
        payload["pnl_dollars"] = pnl_dollars
        payload["outcome_updated_at"] = at
        self._conn.execute(
            "UPDATE signal_journal SET payload = ? WHERE signal_id = ?",
            (json.dumps(payload, ensure_ascii=False), signal_id),
        )
        self._conn.commit()

    def _all_signals(self) -> list[SignalRecord]:
        rows = self._conn.execute(
            "SELECT payload FROM signal_journal ORDER BY ts_utc ASC, rowid ASC"
        ).fetchall()
        return [SignalRecord(**json.loads(row["payload"])) for row in rows]

    # -- equity ----------------------------------------------------------
    def record_equity(self, ts: str, equity: float, balance: float) -> None:
        self._conn.execute(
            "INSERT INTO equity(ts, equity, balance) VALUES (?,?,?)", (ts, float(equity), float(balance))
        )
        self._conn.commit()

    def equity_curve(self) -> Sequence[tuple[str, float, float]]:
        rows = self._conn.execute("SELECT ts, equity, balance FROM equity ORDER BY id ASC").fetchall()
        return [(r["ts"], r["equity"], r["balance"]) for r in rows]

    # -- analytics -------------------------------------------------------
    def stats(self) -> Mapping[str, Any]:
        trades = self.trades()
        closed = [t for t in trades if t.close_time]
        wins = [t for t in closed if t.pnl_net > 0]
        losses = [t for t in closed if t.pnl_net < 0]
        gross_profit = sum(t.pnl_net for t in wins)
        gross_loss = -sum(t.pnl_net for t in losses)
        curve = self.equity_curve()
        peak, max_dd = 0.0, 0.0
        for _, equity, _ in curve:
            peak = max(peak, equity)
            if peak > 0:
                max_dd = max(max_dd, (peak - equity) / peak * 100.0)
        r_multiples = [t.r_multiple for t in closed]
        estimated_cost = sum(t.estimated_cost or 0.0 for t in closed)
        actual_cost = sum(t.actual_cost or 0.0 for t in closed)
        latencies = [t.latency_ms for t in closed if t.latency_ms is not None]
        slippages = [t.entry_slippage_pts for t in closed if t.entry_slippage_pts is not None]
        config_hashes = sorted({t.config_hash for t in closed if t.config_hash})
        by_slot: dict[str, dict[str, float]] = {}
        for t in closed:
            row = by_slot.setdefault(t.slot, {"trades": 0, "net": 0.0, "wins": 0})
            row["trades"] += 1
            row["net"] = round(row["net"] + t.pnl_net, 2)
            row["wins"] += 1 if t.pnl_net > 0 else 0
        for row in by_slot.values():
            row["win_rate"] = round(row["wins"] / row["trades"] * 100, 1) if row["trades"] else 0.0

        single, multi = _group_by_confirmation(closed)
        by_confirmation: dict[str, dict[str, float]] = {}
        for label, bucket in (("single", single), ("multi", multi)):
            wins_b = [t for t in bucket if t.pnl_net > 0]
            gp = sum(t.pnl_net for t in wins_b)
            gl = -sum(t.pnl_net for t in bucket if t.pnl_net < 0)
            by_confirmation[label] = {
                "trades": len(bucket),
                "net": round(sum(t.pnl_net for t in bucket), 2),
                "wins": len(wins_b),
                "win_rate": round(len(wins_b) / len(bucket) * 100, 1) if bucket else 0.0,
                "profit_factor": round(gp / gl, 2) if gl > 0 else None,
                "avg_r": round(sum(t.r_multiple for t in bucket) / len(bucket), 2) if bucket else 0.0,
            }
        by_confirmation_set: dict[str, dict[str, float]] = {}
        for t in closed:
            row = by_confirmation_set.setdefault(
                t.confirmation_key, {"trades": 0, "net": 0.0, "wins": 0}
            )
            row["trades"] += 1
            row["net"] = round(row["net"] + t.pnl_net, 2)
            row["wins"] += 1 if t.pnl_net > 0 else 0
        for row in by_confirmation_set.values():
            row["win_rate"] = round(row["wins"] / row["trades"] * 100, 1) if row["trades"] else 0.0

        signal_rows = self._all_signals()
        capability_rows = int(
            self._conn.execute("SELECT COUNT(*) AS c FROM signal_level_capability").fetchone()["c"]
        )
        by_session: dict[str, dict[str, Any]] = {}
        by_tier: dict[str, dict[str, Any]] = {}
        signals_executed = 0
        signals_watch = 0
        missed_capital = 0
        missed_level = 0
        for signal in signal_rows:
            decision = _signal_decision(signal)
            watched = _signal_is_watch(signal)
            session_bucket = by_session.setdefault(signal.session or "unknown", _new_signal_bucket())
            tier_bucket = by_tier.setdefault(signal.tier or "unknown", _new_signal_bucket())
            for bucket in (session_bucket, tier_bucket):
                _note_signal(bucket, signal, decision, watched)
            if decision == "executed":
                signals_executed += 1
            if watched:
                signals_watch += 1
            if decision == "missed_capital":
                missed_capital += 1
            elif decision == "missed_level":
                missed_level += 1

        return {
            "trades": len(closed),
            "wins": len(wins),
            "losses": len(losses),
            "win_rate": round(len(wins) / len(closed) * 100, 1) if closed else 0.0,
            "gross_profit": round(gross_profit, 2),
            "gross_loss": round(gross_loss, 2),
            "net": round(gross_profit - gross_loss, 2),
            "profit_factor": round(gross_profit / gross_loss, 2) if gross_loss > 0 else float("inf"),
            "avg_r": round(sum(r_multiples) / len(r_multiples), 2) if r_multiples else 0.0,
            "estimated_cost": round(estimated_cost, 2),
            "actual_cost": round(actual_cost, 2),
            "cost_drift": round(actual_cost - estimated_cost, 2),
            "commission_actual": round(sum(t.commission_actual or 0.0 for t in closed), 2),
            "swap_actual": round(sum(t.swap_actual or 0.0 for t in closed), 2),
            "avg_latency_ms": round(sum(latencies) / len(latencies), 2) if latencies else None,
            "avg_entry_slippage_pts": round(sum(slippages) / len(slippages), 2) if slippages else None,
            "config_hashes": config_hashes,
            "max_dd_pct": round(max_dd, 2),
            "equity_points": len(curve),
            "start_equity": round(curve[0][1], 2) if curve else 0.0,
            "end_equity": round(curve[-1][1], 2) if curve else 0.0,
            "by_slot": by_slot,
            "by_confirmation": by_confirmation,
            "by_confirmation_set": by_confirmation_set,
            "signals_total": len(signal_rows),
            "signals_executed": signals_executed,
            "signals_watch": signals_watch,
            "missed_capital": missed_capital,
            "missed_level": missed_level,
            "by_session": by_session,
            "by_tier": by_tier,
            "capability_rows": capability_rows,
        }


def _signal_decision(signal: SignalRecord) -> str:
    return (signal.active_decision or "").strip().lower()


def _signal_is_watch(signal: SignalRecord) -> bool:
    """WATCH is both a decision and a tier; either one marks the row as watched."""
    return _signal_decision(signal) == "watch" or (signal.tier or "").strip().lower() == "watch"


def _new_signal_bucket() -> dict[str, Any]:
    return {
        "signals": 0,
        "executed": 0,
        "watch": 0,
        "missed": 0,
        "missed_capital": 0,
        "missed_level": 0,
        "pnl_dollars": 0.0,
        "outcomes": {},
    }


def _note_signal(
    bucket: dict[str, Any], signal: SignalRecord, decision: str, watched: bool
) -> None:
    bucket["signals"] += 1
    if decision == "executed":
        bucket["executed"] += 1
    if watched:
        bucket["watch"] += 1
    if decision in ("missed_capital", "missed_level"):
        bucket["missed"] += 1
        bucket[decision] += 1
    outcome = signal.outcome or "open"
    bucket["outcomes"][outcome] = bucket["outcomes"].get(outcome, 0) + 1
    if signal.pnl_dollars is not None:
        bucket["pnl_dollars"] = round(bucket["pnl_dollars"] + signal.pnl_dollars, 2)


def _group_by_confirmation(trades):
    single = [t for t in trades if t.confirmation_count <= 1]
    multi = [t for t in trades if t.confirmation_count >= 2]
    return single, multi


def now_iso() -> str:
    return utc(datetime.now(tz=timezone.utc)).isoformat()
