"""Structured logging without an extra dependency.

Console output is always available. A bounded, rotated file sink is opt-in:
either pass an explicit path to setup() or set GOLDBOT_LOG_PATH (the live
launcher sets it to var/live.jsonl). Rotation keeps a long-running session from
filling the disk, which would otherwise stop the engine at the next write.
"""

from __future__ import annotations

import json
import logging
import os
import sys
from logging.handlers import RotatingFileHandler
from pathlib import Path

LOG_PATH_ENV = "GOLDBOT_LOG_PATH"
LOG_MAX_BYTES_ENV = "GOLDBOT_LOG_MAX_BYTES"
LOG_BACKUPS_ENV = "GOLDBOT_LOG_BACKUPS"
DEFAULT_MAX_BYTES = 5 * 1024 * 1024
DEFAULT_BACKUPS = 5


class JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        payload = {
            "ts": self.formatTime(record, "%Y-%m-%dT%H:%M:%S"),
            "level": record.levelname,
            "logger": record.name.replace("goldbot.", ""),
            "msg": record.getMessage(),
        }
        for key, value in getattr(record, "fields", {}).items():
            payload[key] = value
        if record.exc_info:
            payload["exc"] = self.formatException(record.exc_info)
        return json.dumps(payload, default=str, ensure_ascii=False)


def _positive_int(value: str | None, default: int) -> int:
    try:
        parsed = int(str(value).strip())
    except (TypeError, ValueError):
        return default
    return parsed if parsed > 0 else default


def setup(
    level: str = "INFO",
    *,
    json_logs: bool = False,
    path: str | Path | None = None,
    max_bytes: int | None = None,
    backup_count: int | None = None,
) -> None:
    """(Re)configure the goldbot logger tree for this process.

    The file sink is enabled by an explicit path or by GOLDBOT_LOG_PATH; it is
    size-rotated (GOLDBOT_LOG_MAX_BYTES / GOLDBOT_LOG_BACKUPS, defaults 5 MiB
    and 5 files). A file that cannot be opened must never stop trading, so the
    failure is reported on stderr and console logging remains active.
    """
    root = logging.getLogger("goldbot")
    root.setLevel(level.upper())
    for handler in list(root.handlers):
        root.removeHandler(handler)
        try:
            handler.close()
        except Exception:  # noqa: BLE001 - a broken old handler must not block setup
            pass
    console = logging.StreamHandler(sys.stderr)
    console.setFormatter(
        JsonFormatter()
        if json_logs
        else logging.Formatter("%(levelname)-7s %(name)-24s %(message)s")
    )
    root.addHandler(console)

    env_path = os.environ.get(LOG_PATH_ENV, "").strip()
    target = Path(path) if path is not None else (Path(env_path) if env_path else None)
    if target is not None:
        limit = (
            max(1, int(max_bytes))
            if max_bytes is not None
            else _positive_int(os.environ.get(LOG_MAX_BYTES_ENV), DEFAULT_MAX_BYTES)
        )
        keep = (
            max(1, int(backup_count))
            if backup_count is not None
            else _positive_int(os.environ.get(LOG_BACKUPS_ENV), DEFAULT_BACKUPS)
        )
        try:
            target.parent.mkdir(parents=True, exist_ok=True)
            file_handler = RotatingFileHandler(
                str(target), maxBytes=limit, backupCount=keep, encoding="utf-8"
            )
        except OSError as exc:
            sys.stderr.write("goldbot logging: cannot open " + str(target) + ": " + str(exc) + "\n")
        else:
            file_handler.setFormatter(
                JsonFormatter()
                if json_logs
                else logging.Formatter(
                    "%(asctime)s %(levelname)-7s %(name)-24s %(message)s"
                )
            )
            root.addHandler(file_handler)
    root.propagate = False


def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(f"goldbot.{name}")


def log(logger: logging.Logger, level: int, message: str, **fields: object) -> None:
    logger.log(level, message, extra={"fields": fields})
