"""Support/resistance zones: model, deterministic detection, scoring, confluence.

Zones are the shared language between the zones strategy, the numeric strategy
and the cooldown gates. Detection is a pure function of closed H1 bars so the
backtest and live paths compute identical ids and scores.
"""

from __future__ import annotations

from dataclasses import dataclass, replace
from datetime import date
from typing import Protocol, Sequence

from goldbot.domain.model import Bar


def _clamp01(value: float) -> float:
    return max(0.0, min(1.0, value))


def zone_id_for(low: float, high: float, source: str = "auto") -> str:
    """Stable id from the price band, so every component derives the same id."""
    prefix = "M" if source == "manual" else "Z"
    mid = (low + high) / 2.0
    return f"{prefix}{int(round(mid * 100)):07d}"


@dataclass(frozen=True, slots=True)
class Zone:
    high: float
    low: float
    starred: bool = False
    note: str = ""
    zone_id: str = ""
    kind: str = "both"  # support | resistance | both
    score: int = 0
    source: str = "manual"  # manual | auto
    touches: int = 0
    last_touch_bar: int = -1

    def __post_init__(self) -> None:
        if self.high < self.low:
            raise ValueError(f"zone high {self.high} < low {self.low}")
        if not self.zone_id:
            object.__setattr__(self, "zone_id", zone_id_for(self.low, self.high, self.source))

    @property
    def width(self) -> float:
        return self.high - self.low

    @property
    def mid(self) -> float:
        return (self.high + self.low) / 2.0


class ZoneProvider(Protocol):
    """Supplies the operator-drawn zones that are valid for one day."""

    def for_day(self, day: date) -> Sequence[Zone]: ...


class EmptyZones:
    def for_day(self, day: date) -> Sequence[Zone]:
        return ()


def score_zone(zone: Zone, bars: Sequence[Bar], *, atr: float | None, ema: float | None = None) -> Zone:
    """Zone_Score in 0..100 (touches, reaction, freshness, HTF, width, volume)."""
    if atr is None or atr <= 0 or len(bars) < 20:
        return zone
    touches = max(1, zone.touches)
    if touches >= 4:
        touches_f = 1.0
    elif touches == 3:
        touches_f = 0.8
    elif touches == 2:
        touches_f = 0.5
    else:
        touches_f = 0.25

    touch_wick = 0.0
    touch_volume = 0.0
    touch_n = 0
    for bar in bars[-60:]:
        if bar.h >= zone.low and bar.l <= zone.high:
            upper = bar.h - max(bar.o, bar.c)
            lower = min(bar.o, bar.c) - bar.l
            touch_wick += max(upper, lower)
            touch_volume += bar.tick_volume
            touch_n += 1
    reaction_f = _clamp01((touch_wick / touch_n) / (0.5 * atr)) if touch_n else 0.0
    volume_f = 0.0
    if touch_n:
        avg_volume = sum(b.tick_volume for b in bars[-60:]) / max(1, len(bars[-60:]))
        if avg_volume > 0:
            volume_f = _clamp01((touch_volume / touch_n) / avg_volume)

    if zone.last_touch_bar < 0:
        freshness_f = 0.5
    else:
        freshness_f = _clamp01(1.0 - (len(bars) - 1 - zone.last_touch_bar) / 200.0)

    width_atr = zone.width / atr
    if width_atr < 0.2:
        width_f = width_atr / 0.2
    elif width_atr <= 0.6:
        width_f = 1.0
    else:
        width_f = _clamp01(1.0 - (width_atr - 0.6) / 0.6)

    round_distance = abs(zone.mid - round(zone.mid / 10.0) * 10.0)
    round_f = _clamp01(1.0 - round_distance / 5.0)
    ema_f = 0.0
    if ema is not None and ema > 0:
        ema_f = _clamp01(1.0 - abs(zone.mid - ema) / (2.0 * atr))
    htf_f = max(round_f, ema_f * 0.8)

    total = (
        20.0 * touches_f
        + 20.0 * reaction_f
        + 15.0 * freshness_f
        + 15.0 * htf_f
        + 15.0 * width_f
        + 15.0 * volume_f
    )
    return replace(zone, score=int(round(max(0.0, min(100.0, total)))))


def _swings(bars: Sequence[Bar], span: int) -> tuple[list[tuple[int, float]], list[tuple[int, float]]]:
    highs: list[tuple[int, float]] = []
    lows: list[tuple[int, float]] = []
    for i in range(span, len(bars) - span):
        window_h = [b.h for b in bars[i - span : i + span + 1]]
        window_l = [b.l for b in bars[i - span : i + span + 1]]
        if bars[i].h == max(window_h) and window_h.count(bars[i].h) == 1:
            highs.append((i, bars[i].h))
        if bars[i].l == min(window_l) and window_l.count(bars[i].l) == 1:
            lows.append((i, bars[i].l))
    return highs, lows


def detect_zones(
    bars: Sequence[Bar],
    *,
    atr: float | None,
    price: float | None = None,
    ema: float | None = None,
    span: int = 3,
    cluster_atr: float = 0.3,
    half_width_atr: float = 0.15,
    min_touches: int = 2,
    max_zones: int = 8,
) -> tuple[Zone, ...]:
    """Deterministic S/R zones from confirmed H1 fractals."""
    if len(bars) < span * 2 + 10:
        return ()
    atr_v = atr if atr and atr > 0 else (sum(b.range for b in bars[-20:]) / min(20, len(bars)))
    if atr_v <= 0:
        return ()
    reference = price if price is not None else bars[-1].c
    highs, lows = _swings(bars, span)
    levels = sorted([(level, idx) for idx, level in highs + lows])
    tolerance = max(cluster_atr * atr_v, 1e-6)
    clusters: list[list[tuple[float, int]]] = []
    for level, idx in levels:
        if clusters and abs(level - sum(l for l, _ in clusters[-1]) / len(clusters[-1])) <= tolerance:
            clusters[-1].append((level, idx))
        else:
            clusters.append([(level, idx)])

    zones: list[Zone] = []
    for cluster in clusters:
        if len(cluster) < min_touches:
            continue
        mid = sum(level for level, _ in cluster) / len(cluster)
        half = max(0.05 * atr_v, half_width_atr * atr_v)
        last_touch = max(idx for _, idx in cluster)
        kind = "resistance" if mid >= reference else "support"
        zone = Zone(
            high=mid + half,
            low=mid - half,
            zone_id=zone_id_for(mid - half, mid + half, "auto"),
            kind=kind,
            source="auto",
            touches=len(cluster),
            last_touch_bar=last_touch,
        )
        zones.append(score_zone(zone, bars, atr=atr_v, ema=ema))

    zones.sort(key=lambda z: (z.score, z.touches), reverse=True)
    kept: list[Zone] = []
    for zone in zones:
        if any(_overlap(zone, other) > 0.5 for other in kept):
            continue
        kept.append(zone)
        if len(kept) >= max_zones:
            break
    return tuple(kept)


def _overlap(a: Zone, b: Zone) -> float:
    span = min(a.high, b.high) - max(a.low, b.low)
    if span <= 0:
        return 0.0
    return span / max(1e-9, min(a.width, b.width))


def score_manual_zones(zones: Sequence[Zone], *, atr: float | None, ema: float | None = None) -> tuple[Zone, ...]:
    """Give operator zones a comparable score (starred = stronger)."""
    out: list[Zone] = []
    for zone in zones:
        base = 85 if zone.starred else 70
        width_penalty = 0
        if atr and atr > 0 and zone.width > 0.9 * atr:
            width_penalty = 10
        out.append(
            replace(
                zone,
                zone_id=zone.zone_id or zone_id_for(zone.low, zone.high, "manual"),
                kind=zone.kind if zone.kind != "both" else "both",
                score=max(zone.score, base - width_penalty),
                source="manual",
            )
        )
    return tuple(out)


def merge_zones(manual: Sequence[Zone], auto: Sequence[Zone]) -> tuple[Zone, ...]:
    merged: dict[str, Zone] = {}
    for zone in auto:
        merged[zone.zone_id] = zone
    for zone in manual:
        existing = merged.get(zone.zone_id)
        if existing is None or zone.score >= existing.score:
            merged[zone.zone_id] = zone
    return tuple(merged.values())


SOURCE_RANK: dict[str, int] = {"manual": 0, "daily": 1, "auto": 2}


def source_rank(zone: Zone) -> int:
    return SOURCE_RANK.get(zone.source, 3)


def merge_all(*groups: Sequence[Zone]) -> tuple[Zone, ...]:
    """Merge with precedence: operator zones, then daily levels, then H1 zones."""
    candidates: list[Zone] = []
    for group in groups:
        candidates.extend(group)
    candidates.sort(key=lambda zone: (source_rank(zone), -zone.score))
    kept: list[Zone] = []
    for zone in candidates:
        if any(_overlap(zone, other) > 0.5 for other in kept):
            continue
        kept.append(zone)
    return tuple(kept)


def best_zone(
    zones: Sequence[Zone],
    side: str,
    price: float,
    atr: float,
    *,
    min_score: int = 0,
    max_distance_atr: float = 1.2,
) -> Zone | None:
    """Nearest high-quality zone that is on the correct side of price."""
    if atr <= 0:
        return None
    best: Zone | None = None
    best_value = -1e9
    for zone in zones:
        if zone.score < min_score:
            continue
        if side == "buy":
            if zone.mid > price + 0.25 * atr:
                continue
            distance = max(0.0, price - zone.high)
        else:
            if zone.mid < price - 0.25 * atr:
                continue
            distance = max(0.0, zone.low - price)
        if distance > max_distance_atr * atr:
            continue
        value = zone.score - 25.0 * (distance / atr)
        if value > best_value:
            best, best_value = zone, value
    return best


def zone_confirmation(
    zones: Sequence[Zone],
    side: str,
    price: float,
    atr: float,
    *,
    min_score: int = 55,
) -> tuple[bool, int, str]:
    """(confirmed, score, zone_id) for an independent sr_zone approval."""
    zone = best_zone(zones, side, price, atr, min_score=min_score)
    if zone is None:
        return (False, 0, "")
    return (True, zone.score, zone.zone_id)
