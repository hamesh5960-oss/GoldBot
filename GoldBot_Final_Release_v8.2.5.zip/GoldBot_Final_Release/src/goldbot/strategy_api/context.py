"""Read-only views handed to strategies. No path to the broker exists from here."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any, Mapping, Protocol, Sequence

from goldbot.domain.model import Bar, SymbolInfo, Tick, Timeframe

from .zones import Zone


@dataclass(frozen=True, slots=True)
class StrategyPosition:
    ticket: int
    symbol: str
    side: str
    volume: float
    open_price: float
    sl: float | None
    tp: float | None
    open_time: datetime
    unrealized: float = 0.0


@dataclass(frozen=True, slots=True)
class AccountView:
    equity: float
    balance: float
    free_margin: float
    open_positions: int


class StrategyContext(Protocol):
    @property
    def slot(self) -> str: ...
    @property
    def symbol(self) -> str: ...
    @property
    def symbol_info(self) -> SymbolInfo: ...
    @property
    def params(self) -> Any: ...
    @property
    def risk_multiplier(self) -> float: ...

    def now(self) -> datetime: ...
    def bars(self, timeframe: Timeframe, count: int) -> Sequence[Bar]: ...
    def last_tick(self) -> Tick | None: ...
    def positions(self) -> Sequence[StrategyPosition]: ...
    def account(self) -> AccountView: ...
    def atr(self, timeframe: Timeframe, period: int) -> float | None: ...
    def zones(self) -> Sequence[Zone]: ...
    def log(self, message: str, **fields: Any) -> None: ...
    def tags(self) -> Mapping[str, Any]: ...
