"""Plugin SDK surface. A strategy may import from here and nowhere else in goldbot."""

from .base import BaseStrategy
from .context import AccountView, StrategyContext, StrategyPosition
from .signals import Signal, entry_signal, exit_signal
from .trades import TradeSummary
from .zones import (
    EmptyZones,
    Zone,
    ZoneProvider,
    best_zone,
    detect_zones,
    merge_all,
    merge_zones,
    score_manual_zones,
    score_zone,
    source_rank,
    zone_confirmation,
    zone_id_for,
)
from .levels import (
    DailyLevels,
    broker_daily_bars,
    broker_day,
    daily_levels,
    daily_zones,
)
from . import indicators

# Helpers a plugin needs that would otherwise force it to import core modules.
from goldbot.timeutil import iran_day

# Data types a strategy needs. Re-exported here so plugins never import the
# domain package directly (dependency rule D6).
from goldbot.domain.model import Bar, SymbolInfo, Tick, Timeframe

__all__ = [
    "BaseStrategy",
    "AccountView",
    "StrategyContext",
    "StrategyPosition",
    "Signal",
    "entry_signal",
    "exit_signal",
    "TradeSummary",
    "Zone",
    "ZoneProvider",
    "EmptyZones",
    "best_zone",
    "detect_zones",
    "merge_all",
    "merge_zones",
    "source_rank",
    "DailyLevels",
    "broker_daily_bars",
    "broker_day",
    "daily_levels",
    "daily_zones",
    "score_manual_zones",
    "score_zone",
    "zone_confirmation",
    "zone_id_for",
    "indicators",
    "iran_day",
    "Bar",
    "SymbolInfo",
    "Tick",
    "Timeframe",
]
