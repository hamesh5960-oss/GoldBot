"""Closed-trade summary handed to strategies (for stateful rules)."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime


@dataclass(frozen=True, slots=True)
class TradeSummary:
    slot: str
    ticket: int
    side: str
    entry_price: float
    exit_price: float
    volume: float
    pnl_net: float
    reason: str
    opened_at: datetime
    closed_at: datetime

    @property
    def is_loss(self) -> bool:
        return self.pnl_net < 0
