"""Signals are declarative: a strategy proposes, the pipeline decides, risk approves."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal, Mapping

Side = Literal["buy", "sell"]
Kind = Literal["entry", "exit", "noop"]


@dataclass(frozen=True, slots=True)
class Signal:
    kind: Kind
    slot: str
    symbol: str
    side: Side | None = None
    entry_hint: float | None = None
    stop: float | None = None
    target: float | None = None
    confidence: float = 1.0
    rationale: str = ""
    tags: Mapping[str, Any] = field(default_factory=dict)
    order_type: Literal["market", "limit"] = "market"
    limit_price: float | None = None
    exit_ticket: int | None = None
    exit_reason: str = ""


def entry_signal(
    *,
    slot: str,
    symbol: str,
    side: Side,
    stop: float,
    target: float | None = None,
    entry_hint: float | None = None,
    rationale: str = "",
    confidence: float = 1.0,
    order_type: Literal["market", "limit"] = "market",
    limit_price: float | None = None,
    tags: Mapping[str, Any] | None = None,
) -> Signal:
    return Signal(
        kind="entry",
        slot=slot,
        symbol=symbol,
        side=side,
        entry_hint=entry_hint,
        stop=stop,
        target=target,
        confidence=confidence,
        rationale=rationale,
        tags=dict(tags or {}),
        order_type=order_type,
        limit_price=limit_price,
    )


def exit_signal(*, slot: str, symbol: str, ticket: int, reason: str) -> Signal:
    return Signal(
        kind="exit",
        slot=slot,
        symbol=symbol,
        exit_ticket=ticket,
        exit_reason=reason,
    )


def noop(*, slot: str, symbol: str) -> Signal:
    return Signal(kind="noop", slot=slot, symbol=symbol)
