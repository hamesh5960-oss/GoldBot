"""Daily support/resistance levels built from completed broker-day candles.

The strategy and the engine share this module so a level has one id, one score
and one meaning from the first M15 candle of the new day to its close.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime, timedelta
from typing import Sequence

from goldbot.domain.model import Bar

from .zones import Zone


@dataclass(frozen=True, slots=True)
class DailyLevels:
    day: date
    previous_day: date
    pdh: float
    pdl: float
    pdo: float
    pdc: float
    atr: float
    pivot: float
    r1: float
    s1: float
    high_touches: int
    low_touches: int
    close_touches: int


def broker_day(moment: datetime, offset: timedelta) -> date:
    return (moment + offset).date()


def broker_daily_bars(bars: Sequence[Bar], offset: timedelta) -> list[Bar]:
    """Aggregate M15 bars into broker-day candles (offset = server - UTC)."""
    out: list[Bar] = []
    if not bars:
        return out
    current: date | None = None
    start = None
    o = h = l = c = 0.0
    volume = 0
    for bar in bars:
        day = broker_day(bar.open_time, offset)
        if current is None or day != current:
            if start is not None:
                out.append(
                    Bar(
                        symbol=bar.symbol,
                        timeframe="D1",  # type: ignore[arg-type]
                        open_time=start,
                        o=o,
                        h=h,
                        l=l,
                        c=c,
                        tick_volume=volume,
                    )
                )
            current = day
            start = bar.open_time
            o, h, l, c = bar.o, bar.h, bar.l, bar.c
            volume = bar.tick_volume
        else:
            h = max(h, bar.h)
            l = min(l, bar.l)
            c = bar.c
            volume += bar.tick_volume
    if start is not None:
        out.append(
            Bar(
                symbol=bars[0].symbol,
                timeframe="D1",  # type: ignore[arg-type]
                open_time=start,
                o=o,
                h=h,
                l=l,
                c=c,
                tick_volume=volume,
            )
        )
    return out


def daily_levels(
    daily_bars: Sequence[Bar], *, now: datetime, offset: timedelta
) -> DailyLevels | None:
    """Levels of the last *completed* broker day (never the running one)."""
    if not daily_bars:
        return None
    from . import indicators

    today = broker_day(now, offset)
    completed = [bar for bar in daily_bars if broker_day(bar.open_time, offset) < today]
    if not completed:
        return None
    previous = completed[-1]
    atr = indicators.atr(completed, 14) or max(previous.h - previous.l, 1e-6)
    pivot = (previous.h + previous.l + previous.c) / 3.0
    r1 = 2.0 * pivot - previous.l
    s1 = 2.0 * pivot - previous.h
    prior = completed[-21:-1]
    tolerance = 0.25 * atr

    def touches(level: float, use_high: bool) -> int:
        values = [bar.h for bar in prior] if use_high else [bar.l for bar in prior]
        return sum(1 for value in values if abs(value - level) <= tolerance)

    return DailyLevels(
        day=today,
        previous_day=broker_day(previous.open_time, offset),
        pdh=previous.h,
        pdl=previous.l,
        pdo=previous.o,
        pdc=previous.c,
        atr=atr,
        pivot=pivot,
        r1=r1,
        s1=s1,
        high_touches=touches(previous.h, True),
        low_touches=touches(previous.l, False),
        close_touches=touches(previous.c, True) + touches(previous.c, False),
    )


def daily_zones(levels: DailyLevels, *, price: float | None = None) -> tuple[Zone, ...]:
    """Seven scored rectangles around the previous day's key prices."""
    atr = max(levels.atr, 1e-6)
    half = 0.12 * atr
    reference = levels.pdc if price is None else price

    specs = (
        ("PDH", levels.pdh, 82, levels.high_touches),
        ("PDL", levels.pdl, 82, levels.low_touches),
        ("PDC", levels.pdc, 72, levels.close_touches),
        ("PIVOT", levels.pivot, 66, 0),
        ("PDO", levels.pdo, 58, 0),
        ("R1", levels.r1, 62, 0),
        ("S1", levels.s1, 62, 0),
    )
    zones: list[Zone] = []
    for name, level, base, touches in specs:
        score = base + min(9, 3 * int(touches))
        round_distance = abs(level - round(level / 10.0) * 10.0)
        if round_distance <= 1.0:
            score += 5
        score = int(max(40, min(95, score)))
        centers = [(zone.mid, zone) for zone in zones]
        if any(abs(level - center) < 0.35 * atr for center, _ in centers):
            continue
        zones.append(
            Zone(
                high=level + half,
                low=level - half,
                zone_id=f"D{name}{int(round(level * 100)):07d}",
                kind="resistance" if level >= reference else "support",
                score=score,
                source="daily",
                touches=int(touches),
                note=name,
            )
        )
    zones.sort(key=lambda zone: zone.score, reverse=True)
    return tuple(zones)
