"""Small, tested indicator helpers shared by every strategy."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Sequence

from goldbot.domain.model import TF_SECONDS, Bar


def sma(values: Sequence[float], period: int) -> float | None:
    if period <= 0 or len(values) < period:
        return None
    window = values[-period:]
    return sum(window) / period


def ema_series(values: Sequence[float], period: int) -> list[float | None]:
    out: list[float | None] = []
    if period <= 0:
        return out
    k = 2.0 / (period + 1.0)
    prev: float | None = None
    for i, value in enumerate(values):
        if i + 1 < period:
            out.append(None)
            continue
        if prev is None:
            prev = sum(values[i + 1 - period : i + 1]) / period
        else:
            prev = value * k + prev * (1.0 - k)
        out.append(prev)
    return out


def ema(values: Sequence[float], period: int) -> float | None:
    series = ema_series(values, period)
    if not series:
        return None
    return series[-1]


def true_range(bar: Bar, prev_close: float | None) -> float:
    if prev_close is None:
        return bar.range
    return max(bar.h - bar.l, abs(bar.h - prev_close), abs(bar.l - prev_close))


def atr(bars: Sequence[Bar], period: int) -> float | None:
    if period <= 0 or len(bars) < period + 1:
        return None
    trs: list[float] = []
    for i in range(1, len(bars)):
        trs.append(true_range(bars[i], bars[i - 1].c))
    window = trs[-period:]
    return sum(window) / len(window)


def highest(bars: Sequence[Bar], period: int) -> float | None:
    if len(bars) < period or period <= 0:
        return None
    return max(b.h for b in bars[-period:])


def lowest(bars: Sequence[Bar], period: int) -> float | None:
    if len(bars) < period or period <= 0:
        return None
    return min(b.l for b in bars[-period:])


def closes(bars: Sequence[Bar]) -> list[float]:
    return [b.c for b in bars]


def pips_to_price(pips: float, pip_size: float) -> float:
    """Gold convention used by the strategy documents: 1 pip = 0.1 USD."""
    return pips * pip_size


def bollinger(
    values: Sequence[float], period: int, deviations: float, shift: int = 0
) -> tuple[float | None, float | None, float | None]:
    """(lower, middle, upper) for the last point, honouring the indicator shift.

    ``shift`` > 0 evaluates the band ``shift`` bars back, matching MT5 semantics
    where the band is drawn that many candles earlier.
    """
    if period <= 0 or len(values) < period + max(0, shift):
        return (None, None, None)
    end = len(values) - max(0, shift)
    window = values[end - period : end]
    mean = sum(window) / period
    variance = sum((v - mean) ** 2 for v in window) / period
    sigma = variance**0.5
    band = deviations * sigma
    return (mean - band, mean, mean + band)


def outside_band(
    values: Sequence[float], period: int, deviations: float, shift: int, *, above: bool
) -> bool:
    lower, _, upper = bollinger(values[:-1], period, deviations, shift)
    if lower is None or upper is None:
        return False
    last = values[-1]
    return last > upper if above else last < lower


def resample(bars: Sequence[Bar], timeframe: str) -> list[Bar]:
    """Aggregate closed bars into a higher timeframe (M15 -> H1/D1)."""
    if not bars:
        return []
    seconds = TF_SECONDS[timeframe]  # type: ignore[index]
    out: list[Bar] = []
    start = None
    o = h = l = c = 0.0
    volume = 0
    spread_sum = 0.0
    n = 0

    def flush() -> None:
        nonlocal start
        if start is None or n == 0:
            return
        out.append(
            Bar(
                symbol=bars[0].symbol,
                timeframe=timeframe,  # type: ignore[arg-type]
                open_time=start,
                o=o,
                h=h,
                l=l,
                c=c,
                tick_volume=volume,
                spread_avg=spread_sum / n,
            )
        )

    for bar in bars:
        epoch = int(bar.open_time.timestamp())
        bucket = datetime.fromtimestamp(epoch - (epoch % seconds), tz=timezone.utc)
        if start is None or bucket > start:
            flush()
            start = bucket
            o, h, l, c = bar.o, bar.h, bar.l, bar.c
            volume, spread_sum, n = bar.tick_volume, bar.spread_avg, 1
        else:
            h = max(h, bar.h)
            l = min(l, bar.l)
            c = bar.c
            volume += bar.tick_volume
            spread_sum += bar.spread_avg
            n += 1
    flush()
    return out


def adx(bars: Sequence[Bar], period: int = 14) -> float | None:
    """Wilder ADX on closed bars; None until the average is meaningful."""
    if period <= 0 or len(bars) < period * 2 + 1:
        return None
    trs: list[float] = []
    plus_dm: list[float] = []
    minus_dm: list[float] = []
    for i in range(1, len(bars)):
        up = bars[i].h - bars[i - 1].h
        down = bars[i - 1].l - bars[i].l
        plus_dm.append(up if up > down and up > 0 else 0.0)
        minus_dm.append(down if down > up and down > 0 else 0.0)
        trs.append(true_range(bars[i], bars[i - 1].c))

    atr_v = sum(trs[:period]) / period
    plus = sum(plus_dm[:period]) / period
    minus = sum(minus_dm[:period]) / period
    dxs: list[float] = []
    for i in range(period, len(trs)):
        atr_v = (atr_v * (period - 1) + trs[i]) / period
        plus = (plus * (period - 1) + plus_dm[i]) / period
        minus = (minus * (period - 1) + minus_dm[i]) / period
        if atr_v <= 0:
            continue
        pdi = 100.0 * plus / atr_v
        ndi = 100.0 * minus / atr_v
        total = pdi + ndi
        dxs.append(100.0 * abs(pdi - ndi) / total if total > 0 else 0.0)
    if len(dxs) < period:
        return None
    value = sum(dxs[:period]) / period
    for dx in dxs[period:]:
        value = (value * (period - 1) + dx) / period
    return value


def median(values: Sequence[float]) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    mid = len(ordered) // 2
    if len(ordered) % 2:
        return ordered[mid]
    return (ordered[mid - 1] + ordered[mid]) / 2.0


def percentile_rank(values: Sequence[float], value: float) -> float | None:
    """Fraction of history at or below the value, in percent (0..100)."""
    if not values:
        return None
    hits = sum(1 for item in values if item <= value)
    return 100.0 * hits / len(values)


def rsi(values: Sequence[float], period: int = 14) -> float | None:
    """Wilder RSI on closes; None until there is enough history."""
    if period <= 0 or len(values) < period + 1:
        return None
    gains = 0.0
    losses = 0.0
    for i in range(1, len(values)):
        change = values[i] - values[i - 1]
        if i <= period:
            gains += max(change, 0.0)
            losses += max(-change, 0.0)
        else:
            gains = (gains * (period - 1) + max(change, 0.0)) / period
            losses = (losses * (period - 1) + max(-change, 0.0)) / period
    average_gain = gains / period
    average_loss = losses / period
    if average_loss <= 0:
        return 100.0 if average_gain > 0 else 50.0
    rs = average_gain / average_loss
    return 100.0 - 100.0 / (1.0 + rs)


def volume_ratio(bars: Sequence[Bar], period: int = 20) -> float | None:
    """Last bar volume divided by the prior average (1.0 = average)."""
    if period <= 0 or len(bars) < period + 1:
        return None
    window = bars[-period - 1 : -1]
    average = sum(bar.tick_volume for bar in window) / period
    if average <= 0:
        return None
    return bars[-1].tick_volume / average


def is_pin_bar(bar: Bar, direction: str) -> bool:
    """Rejection wick at least twice the body, close in the favourable third."""
    span = bar.h - bar.l
    if span <= 0:
        return False
    body = abs(bar.c - bar.o)
    if direction == "buy":
        lower = min(bar.o, bar.c) - bar.l
        return lower >= 2.0 * max(body, 1e-9) and (bar.c - bar.l) >= 0.6 * span
    upper = bar.h - max(bar.o, bar.c)
    return upper >= 2.0 * max(body, 1e-9) and (bar.h - bar.c) >= 0.6 * span


def is_engulfing(previous: Bar, bar: Bar, direction: str) -> bool:
    """The trigger body engulfs the previous opposite body."""
    if direction == "buy":
        return (
            previous.c < previous.o
            and bar.c > bar.o
            and bar.c >= previous.o
            and bar.o <= previous.c
        )
    return (
        previous.c > previous.o
        and bar.c < bar.o
        and bar.c <= previous.o
        and bar.o >= previous.c
    )

