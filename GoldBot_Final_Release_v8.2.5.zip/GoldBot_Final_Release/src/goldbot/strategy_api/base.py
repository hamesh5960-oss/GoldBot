"""Convenience base class so a new strategy only overrides what it needs."""

from __future__ import annotations

from typing import Any, Sequence

from goldbot.domain.model import Bar, Fill, Tick, Timeframe

from .context import StrategyContext
from .signals import Signal
from .trades import TradeSummary


class BaseStrategy:
    id: str = "base"
    version: str = "0.0.0"
    timeframes: Sequence[Timeframe] = ("M15",)
    warmup_bars: int = 100
    max_concurrent_positions: int = 1
    # Lower wins when several strategies signal on the same bar.
    priority: int = 100

    def __init__(self, *, params: Any, risk_multiplier: float = 1.0) -> None:
        self.params = params
        self.risk_multiplier = risk_multiplier

    # -- lifecycle -------------------------------------------------------
    def on_init(self, ctx: StrategyContext) -> None:
        """Called once before warmup."""

    def on_warmup(self, ctx: StrategyContext) -> None:
        """Called when enough history exists; precompute indicator state here."""

    def on_tick(self, ctx: StrategyContext, tick: Tick) -> Sequence[Signal]:
        return ()

    def on_bar(self, ctx: StrategyContext, bar: Bar) -> Sequence[Signal]:
        return ()

    def on_fill(self, ctx: StrategyContext, fill: Fill) -> None:
        """Informational only; must not change risk decisions."""

    def on_close(self, ctx: StrategyContext, trade: TradeSummary) -> None:
        """A position of this slot was closed; update the strategy's own state."""

    def on_stop(self, ctx: StrategyContext, reason: str) -> None:
        """Called on shutdown; release resources if any."""
