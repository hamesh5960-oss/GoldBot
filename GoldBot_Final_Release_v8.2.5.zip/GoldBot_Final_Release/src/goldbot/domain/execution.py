"""Execution value objects shared by risk, coordinator and venue."""

from __future__ import annotations

import hashlib
import hmac
from dataclasses import dataclass, field, replace
from datetime import datetime
from typing import Any, Literal, Mapping

from .model import ClosedTrade, Side, Symbol, Ts


@dataclass(frozen=True, slots=True)
class RiskSnapshot:
    """The numbers that justified (or blocked) a decision. Immutable audit trail."""

    equity: float
    balance: float
    risk_pct: float
    risk_amount: float
    stop_distance: float
    volume: float
    spread_points: float
    atr: float | None = None
    daily_pnl: float = 0.0
    open_positions: int = 0
    profile: str = ""

    def as_dict(self) -> dict[str, Any]:
        return {
            "equity": round(self.equity, 2),
            "balance": round(self.balance, 2),
            "risk_pct": self.risk_pct,
            "risk_amount": round(self.risk_amount, 2),
            "stop_distance": round(self.stop_distance, 5),
            "volume": self.volume,
            "spread_points": round(self.spread_points, 1),
            "atr": None if self.atr is None else round(self.atr, 5),
            "daily_pnl": round(self.daily_pnl, 2),
            "open_positions": self.open_positions,
            "profile": self.profile,
        }


@dataclass(frozen=True, slots=True)
class ApprovedOrder:
    """Sealed by the risk engine. The coordinator refuses anything unsealed."""

    intent_id: str
    slot: str
    strategy: str
    symbol: Symbol
    side: Side
    volume: float
    order_type: Literal["market", "limit"]
    sl: float
    tp: float | None
    magic: int
    client_ref: str
    max_slippage_points: int
    risk: RiskSnapshot
    signal: Mapping[str, Any] = field(default_factory=dict)
    limit_price: float | None = None
    expires_at: datetime | None = None
    _token: str = field(default="", repr=False, compare=False)

    def _digest(self, secret: bytes) -> str:
        payload = "|".join(
            [
                self.intent_id,
                self.slot,
                self.strategy,
                str(self.symbol),
                self.side,
                f"{self.volume:.4f}",
                f"{self.sl:.5f}",
                f"{self.tp or 0.0:.5f}",
                str(self.magic),
                self.client_ref,
            ]
        )
        return hmac.new(secret, payload.encode("utf-8"), hashlib.sha256).hexdigest()[:32]

    def seal(self, secret: str) -> "ApprovedOrder":
        return replace(self, _token=self._digest(secret.encode("utf-8")))

    def is_sealed(self, secret: str) -> bool:
        if not self._token:
            return False
        return hmac.compare_digest(self._token, self._digest(secret.encode("utf-8")))


@dataclass(frozen=True, slots=True)
class OrderAck:
    intent_id: str
    accepted: bool
    retcode: int
    retcode_name: str
    message: str
    ticket: int | None = None
    fill_price: float | None = None
    filled_volume: float = 0.0
    ts: Ts | None = None
    closed_trade: ClosedTrade | None = None


@dataclass(frozen=True, slots=True)
class EntryIntent:
    intent_id: str
    slot: str
    strategy: str
    symbol: Symbol
    side: Side
    entry_ref: float
    stop: float
    target: float | None
    risk_multiplier: float
    signal: Mapping[str, Any]
    created_at: datetime
    order_type: Literal["market", "limit"] = "market"
    limit_price: float | None = None
    expires_at: datetime | None = None


@dataclass(frozen=True, slots=True)
class ExitIntent:
    intent_id: str
    slot: str
    ticket: int
    symbol: Symbol
    reason: str
    fraction: float = 1.0


@dataclass(frozen=True, slots=True)
class ManagementAction:
    ticket: int
    action: Literal["trail", "breakeven", "close", "extend"]
    sl: float | None = None
    reason: str = ""
