"""Event catalogue: one envelope for everything that must be auditable."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping

from .model import Ts


class Ev:
    """Event type constants (stable strings; never rename, only add)."""

    SESSION_STARTED = "SessionStarted"
    CONFIG_LOADED = "ConfigLoaded"
    CONNECTION_STATE = "ConnectionStateChanged"
    RECONCILE_STARTED = "ReconcileStarted"
    RECONCILE_COMPLETED = "ReconcileCompleted"
    DIVERGENCE = "DivergenceDetected"
    STRATEGY_STARTED = "StrategyStarted"
    STRATEGY_WARMED = "StrategyWarmedUp"
    STRATEGY_FAILED = "StrategyFailed"
    SIGNAL_RAISED = "SignalRaised"
    DECISION_EVALUATED = "DecisionEvaluated"
    GATE_EVALUATED = "GateEvaluated"
    GATE_EVENT = "GateEvent"
    ZONE_BURNED = "ZoneBurned"
    DAILY_LEVELS = "DailyLevelsReady"
    INTENT_CREATED = "IntentCreated"
    RISK_EVALUATED = "RiskEvaluated"
    ORDER_APPROVED = "OrderIntentApproved"
    ORDER_SUBMITTED = "OrderSubmitted"
    ORDER_ACKED = "OrderAcked"
    ORDER_REJECTED = "OrderRejected"
    ORDER_UNCERTAIN = "OrderUncertain"
    ORDER_RESOLVED_PRESENT = "OrderResolvedPresent"
    ORDER_RESOLVED_ABSENT = "OrderResolvedAbsent"
    POSITION_OPENED = "PositionOpened"
    POSITION_MODIFIED = "PositionModified"
    POSITION_CLOSED = "PositionClosed"
    POSITION_CLOSING = "PositionClosing"
    PROTECTION_BROKEN = "ProtectionBroken"
    RISK_STATE_CHANGED = "RiskStateChanged"
    KILL_ENGAGED = "KillSwitchEngaged"
    DAILY_LOSS_BREACH = "DailyLossBreach"
    MANUAL_OVERRIDE = "ManualOverride"
    DATA_STALE = "StaleDataDetected"
    GAP_DETECTED = "GapDetected"
    HEARTBEAT_MISSED = "HeartbeatMissed"
    SESSION_FINISHED = "SessionFinished"


@dataclass(frozen=True, slots=True)
class Event:
    type: str
    payload: Mapping[str, Any]
    ts: Ts
    correlation_id: str = ""
    actor: str = "system"
    stream: str = "default"


@dataclass(frozen=True, slots=True)
class TradeRecord:
    """Journal row; carries the full decision trail for one round trip."""

    trade_id: str
    slot: str
    strategy: str
    symbol: str
    side: str
    volume: float
    open_time: str
    close_time: str | None
    open_price: float
    close_price: float | None
    sl: float | None
    tp: float | None
    pnl_gross: float
    commission: float
    swap: float
    pnl_net: float
    spread_at_entry: float
    mae: float = 0.0
    mfe: float = 0.0
    risk_amount: float = 0.0
    risk_pct: float = 0.0
    exit_reason: str = ""
    signal: Mapping[str, Any] = field(default_factory=dict)
    risk: Mapping[str, Any] = field(default_factory=dict)
    confirmations: list[str] = field(default_factory=list)
    # Cost/audit trail: nullable for rows journaled before these fields existed.
    config_hash: str = ""
    entry_slippage_pts: float | None = None
    spread_at_signal_pts: float | None = None
    spread_at_fill_pts: float | None = None
    latency_ms: float | None = None
    mt5_deal_ids: list[int] = field(default_factory=list)
    commission_actual: float | None = None
    swap_actual: float | None = None
    estimated_cost: float | None = None
    actual_cost: float | None = None

    @property
    def r_multiple(self) -> float:
        if self.risk_amount <= 0:
            return 0.0
        return round(self.pnl_net / self.risk_amount, 3)

    @property
    def confirmation_count(self) -> int:
        return len(self.confirmations) or 1

    @property
    def confirmation_key(self) -> str:
        """Stable label such as ``zones`` or ``numeric+sr_zone``."""
        return "+".join(sorted(self.confirmations)) if self.confirmations else self.strategy


# Safest-first capability levels (T3 CapitalLevel values).  The signal journal
# stores one capability row per level and the Excel matrix keeps this order.
CAPITAL_LEVEL_ORDER: tuple[str, ...] = ("base", "low_risk", "medium_risk", "high_risk")


@dataclass(frozen=True, slots=True)
class SignalRecord:
    """One evaluated signal, executed or not (the signal journal row).

    Every field has a default so callers can fill the record incrementally.
    active_decision is a small vocabulary the stats and Excel sheets pivot on:
    executed | watch | missed_capital | missed_level | rejected | skipped
    (case-insensitive; unknown values are tolerated).
    """

    signal_id: str = ""
    ts_utc: str = ""
    symbol: str = ""
    side: str = ""
    strategy: str = ""
    session: str = ""
    session_utc_offset: float = 0.0
    is_dst_active: bool = False
    minutes_into_session: int = 0
    entry: float | None = None
    sl: float | None = None
    tp1: float | None = None
    tp2: float | None = None
    sl_price: float | None = None
    rr_net: float | None = None
    atr_h1: float | None = None
    adx_h1: float | None = None
    news_flag: bool = False
    spread_at_signal: float | None = None
    zone_score_raw: float | None = None
    zone_score_adj: float | None = None
    signal_score: float | None = None
    composite_raw: float | None = None
    composite_adj: float | None = None
    tier: str = ""
    confirmations: int = 0
    # Locked confirmation design (ADR-033/034): count from the five independent
    # factors + the other strategy; D is a hard floor recorded for analysis.
    confirmation_count: float = 0.0
    confirmation_set: list[str] = field(default_factory=list)
    tier_base: str = ""
    layer3_score: float = 0.0
    layer3_delta: int = 0
    tier_final: str = ""
    d_hard_floor: bool = False
    gate_status: Mapping[str, Any] = field(default_factory=dict)
    equity_at_signal: float | None = None
    active_level: str = ""
    active_decision: str = ""
    active_reason: str = ""
    active_lot: float | None = None
    active_risk_pct: float | None = None
    active_risk_dollars: float | None = None
    best_eligible_level: str | None = None
    was_missed_opportunity: bool = False
    outcome: str | None = None
    pnl_dollars: float | None = None
    outcome_updated_at: str | None = None
    params_snapshot: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class SignalLevelRecord:
    """One capability evaluation of one signal at one capital level."""

    signal_id: str = ""
    level: str = ""
    eligible: bool = False
    reason: str = ""
    would_be_lot: float | None = None
    would_be_risk_pct: float | None = None
    would_be_risk_dollars: float | None = None
    min_capital_needed: float | None = None
    capital_gap: float | None = None
    capacity_only: bool = False
    session: str = ""
    tier: str = ""
    zone_score_adj: float | None = None
    sl_price: float | None = None
    equity_at_signal: float | None = None
    evaluated_at: str = ""
    params_snapshot: Mapping[str, Any] = field(default_factory=dict)
