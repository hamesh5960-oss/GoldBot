"""MT5 retcode classification. The gateway maps codes; the core decides the action.

Policy (ADR-011):

* DONE       — the request reached a definitive successful state (including
               partial fills and no-op changes). It is never retried.
* RETRY_PRICE / RETRY_STOPS — the venue explicitly rejected a *stale price*
               or *stop distance*; a retry with a freshly sealed order may
               succeed (ADR-011 defers the actual retry loop).
* ABORT      — a definitive refusal: nothing was executed, and retrying the same
               intent is either impossible or unsafe (e.g. a closed market must
               expire the stale signal, not replay it after the reopen).
* QUARANTINE — the outcome is unknown or the bookkeeping is ambiguous: a blind
               retry could duplicate an execution or lose a position. Fail
               closed and reconcile before trading again.

An unknown code is never retried blindly: it quarantines.
"""

from __future__ import annotations

from enum import Enum


class RetcodeAction(str, Enum):
    DONE = "done"
    RETRY_PRICE = "retry_price"
    RETRY_STOPS = "retry_stops"
    ABORT = "abort"
    QUARANTINE = "quarantine"


# Source: MT5 trade server return codes (10004..10036). Keep this table the
# single authority; gateway adapters must not invent their own interpretation.
RETCODE_TABLE: dict[int, RetcodeAction] = {
    # -- definitive success ---------------------------------------------------
    10008: RetcodeAction.DONE,           # PLACED (accepted pending order)
    10009: RetcodeAction.DONE,           # DONE
    10010: RetcodeAction.DONE,           # DONE_PARTIAL (accepted, partial volume)
    10025: RetcodeAction.DONE,           # NO_CHANGES (modify was a no-op)
    # -- fresh price / stops may resolve the rejection ------------------------
    10004: RetcodeAction.RETRY_PRICE,    # REQUOTE
    10020: RetcodeAction.RETRY_PRICE,    # PRICE_CHANGED
    10021: RetcodeAction.RETRY_PRICE,    # PRICE_OFF
    10016: RetcodeAction.RETRY_STOPS,    # INVALID_STOPS
    # -- unknown or ambiguous outcome => fail closed --------------------------
    10011: RetcodeAction.QUARANTINE,     # ERROR (generic; execution not guaranteed)
    10012: RetcodeAction.QUARANTINE,     # TIMEOUT (request outcome unknown) -- ADR-011
    10031: RetcodeAction.QUARANTINE,     # CONNECTION (unknown whether the request landed)
    # POSITION_CLOSED is ambiguous without call context (close vs open); the
    # execution owner resolves the close race under SES-02. Until then the table
    # stays fail-closed instead of retrying.
    10036: RetcodeAction.QUARANTINE,     # POSITION_CLOSED
    # -- definitive refusal: nothing executed (safe to drop, never retry) -----
    10006: RetcodeAction.ABORT,          # REJECT
    10007: RetcodeAction.ABORT,          # CANCEL (canceled by broker/user)
    10013: RetcodeAction.ABORT,          # INVALID (invalid request)
    10014: RetcodeAction.ABORT,          # INVALID_VOLUME
    10015: RetcodeAction.ABORT,          # INVALID_PRICE
    10017: RetcodeAction.ABORT,          # TRADE_DISABLED
    10018: RetcodeAction.ABORT,          # MARKET_CLOSED: expire the stale signal
    10019: RetcodeAction.ABORT,          # NO_MONEY
    10022: RetcodeAction.ABORT,          # INVALID_EXPIRATION
    10023: RetcodeAction.ABORT,          # ORDER_CHANGED
    10024: RetcodeAction.ABORT,          # TOO_MANY_REQUESTS
    10026: RetcodeAction.ABORT,          # SERVER_DISABLES_AT
    10027: RetcodeAction.ABORT,          # CLIENT_DISABLES_AT
    10028: RetcodeAction.ABORT,          # LOCKED
    10029: RetcodeAction.ABORT,          # FROZEN
    10030: RetcodeAction.ABORT,          # INVALID_FILL
    10032: RetcodeAction.ABORT,          # ONLY_REAL
    10033: RetcodeAction.ABORT,          # LIMIT_ORDERS
    10034: RetcodeAction.ABORT,          # LIMIT_VOLUME
    10035: RetcodeAction.ABORT,          # INVALID_ORDER
}

# Retryable actions require a freshly sealed order; they are never retried as-is.
RETRYABLE_ACTIONS: frozenset[RetcodeAction] = frozenset(
    {RetcodeAction.RETRY_PRICE, RetcodeAction.RETRY_STOPS}
)


def classify(retcode: int) -> RetcodeAction:
    """Classify one MT5 retcode. Unknown codes quarantine (never retry blindly)."""
    return RETCODE_TABLE.get(int(retcode), RetcodeAction.QUARANTINE)
