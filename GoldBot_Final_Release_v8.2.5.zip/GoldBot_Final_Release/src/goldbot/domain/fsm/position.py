"""Position lifecycle plus the orthogonal protection flag."""

from __future__ import annotations

from enum import Enum

from ..errors import IllegalTransition


class PositionState(str, Enum):
    NONE = "NONE"
    OPENING = "OPENING"
    OPEN = "OPEN"
    CLOSING = "CLOSING"
    CLOSED = "CLOSED"
    ORPHANED = "ORPHANED"


class Protection(str, Enum):
    PROTECTED = "PROTECTED"
    UNPROTECTED = "UNPROTECTED"


_ALLOWED: dict[PositionState, frozenset[PositionState]] = {
    PositionState.NONE: frozenset({PositionState.OPENING}),
    PositionState.OPENING: frozenset({PositionState.OPEN, PositionState.NONE}),
    PositionState.OPEN: frozenset({PositionState.CLOSING, PositionState.ORPHANED}),
    PositionState.CLOSING: frozenset({PositionState.CLOSED, PositionState.CLOSING}),
    PositionState.CLOSED: frozenset(),
    PositionState.ORPHANED: frozenset({PositionState.OPEN}),
}


def can_transition(source: PositionState, target: PositionState) -> bool:
    return target in _ALLOWED.get(source, frozenset())


def assert_transition(source: PositionState, target: PositionState) -> None:
    if not can_transition(source, target):
        raise IllegalTransition(f"illegal position transition {source.value} -> {target.value}")


class PositionPhase(str, Enum):
    """Lifecycle of the take-profit plan attached to an open position.

    Orthogonal to PositionState: the order lifecycle still runs
    OPENING -> OPEN -> CLOSING -> CLOSED while the exit plan walks through
    its own phases.  CLOSED is terminal.
    """

    OPEN = "OPEN"
    PARTIAL_1 = "PARTIAL_1"
    PARTIAL_2 = "PARTIAL_2"
    TRAILING = "TRAILING"
    CLOSED = "CLOSED"


_ALLOWED_PHASES: dict[PositionPhase, frozenset[PositionPhase]] = {
    PositionPhase.OPEN: frozenset(
        {PositionPhase.PARTIAL_1, PositionPhase.TRAILING, PositionPhase.CLOSED}
    ),
    PositionPhase.PARTIAL_1: frozenset(
        {PositionPhase.PARTIAL_2, PositionPhase.TRAILING, PositionPhase.CLOSED}
    ),
    PositionPhase.PARTIAL_2: frozenset({PositionPhase.TRAILING, PositionPhase.CLOSED}),
    PositionPhase.TRAILING: frozenset({PositionPhase.CLOSED}),
    PositionPhase.CLOSED: frozenset(),
}


def can_transition_phase(source: PositionPhase, target: PositionPhase) -> bool:
    return target in _ALLOWED_PHASES.get(source, frozenset())


def assert_phase_transition(source: PositionPhase, target: PositionPhase) -> None:
    if not can_transition_phase(source, target):
        raise IllegalTransition(
            f"illegal position phase transition {source.value} -> {target.value}"
        )
