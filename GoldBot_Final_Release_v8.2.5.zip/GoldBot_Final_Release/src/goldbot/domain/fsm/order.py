"""Order state machine. Transitions are explicit; anything else raises."""

from __future__ import annotations

from enum import Enum

from ..errors import IllegalTransition


class OrderState(str, Enum):
    CREATED = "CREATED"
    RISK_REJECTED = "RISK_REJECTED"
    APPROVED = "APPROVED"
    SUBMITTING = "SUBMITTING"
    RETRYABLE = "RETRYABLE"
    UNKNOWN = "UNKNOWN"
    ADOPTED = "ADOPTED"
    RESOLVED_ABSENT = "RESOLVED_ABSENT"
    ACKED = "ACKED"
    PARTIAL = "PARTIAL"
    FILLED = "FILLED"
    CANCELED = "CANCELED"
    REJECTED = "REJECTED"
    EXPIRED = "EXPIRED"


ORDER_TERMINAL = frozenset(
    {
        OrderState.FILLED,
        OrderState.CANCELED,
        OrderState.REJECTED,
        OrderState.EXPIRED,
        OrderState.RISK_REJECTED,
        OrderState.RESOLVED_ABSENT,
    }
)

_ALLOWED: dict[OrderState, frozenset[OrderState]] = {
    OrderState.CREATED: frozenset({OrderState.RISK_REJECTED, OrderState.APPROVED, OrderState.EXPIRED}),
    OrderState.APPROVED: frozenset({OrderState.SUBMITTING, OrderState.EXPIRED}),
    OrderState.SUBMITTING: frozenset(
        {OrderState.ACKED, OrderState.REJECTED, OrderState.RETRYABLE, OrderState.UNKNOWN}
    ),
    OrderState.RETRYABLE: frozenset({OrderState.SUBMITTING, OrderState.REJECTED}),
    OrderState.UNKNOWN: frozenset({OrderState.ADOPTED, OrderState.RESOLVED_ABSENT}),
    OrderState.ADOPTED: frozenset({OrderState.PARTIAL, OrderState.FILLED, OrderState.ACKED}),
    OrderState.ACKED: frozenset({OrderState.PARTIAL, OrderState.FILLED, OrderState.CANCELED}),
    OrderState.PARTIAL: frozenset({OrderState.FILLED, OrderState.PARTIAL, OrderState.CANCELED}),
    OrderState.RESOLVED_ABSENT: frozenset(),
    OrderState.RISK_REJECTED: frozenset(),
    OrderState.FILLED: frozenset(),
    OrderState.CANCELED: frozenset(),
    OrderState.REJECTED: frozenset(),
    OrderState.EXPIRED: frozenset(),
}


def can_transition(source: OrderState, target: OrderState) -> bool:
    return target in _ALLOWED.get(source, frozenset())


def assert_transition(source: OrderState, target: OrderState) -> None:
    if not can_transition(source, target):
        raise IllegalTransition(f"illegal order transition {source.value} -> {target.value}")
