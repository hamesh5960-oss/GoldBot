"""Connection state machine: the gate that decides whether trading may happen."""

from __future__ import annotations

from enum import Enum

from ..errors import IllegalTransition


class ConnectionState(str, Enum):
    DISCONNECTED = "DISCONNECTED"
    CONNECTING = "CONNECTING"
    SYNCING = "SYNCING"
    READY = "READY"
    DEGRADED = "DEGRADED"
    QUARANTINE = "QUARANTINE"
    LOST = "LOST"
    HALTED = "HALTED"


_ALLOWED: dict[ConnectionState, frozenset[ConnectionState]] = {
    ConnectionState.DISCONNECTED: frozenset({ConnectionState.CONNECTING}),
    ConnectionState.CONNECTING: frozenset({ConnectionState.SYNCING, ConnectionState.DISCONNECTED}),
    ConnectionState.SYNCING: frozenset(
        {ConnectionState.READY, ConnectionState.QUARANTINE, ConnectionState.DISCONNECTED}
    ),
    ConnectionState.READY: frozenset({ConnectionState.DEGRADED, ConnectionState.LOST}),
    ConnectionState.DEGRADED: frozenset({ConnectionState.READY, ConnectionState.LOST}),
    ConnectionState.QUARANTINE: frozenset({ConnectionState.SYNCING, ConnectionState.HALTED}),
    ConnectionState.LOST: frozenset({ConnectionState.CONNECTING, ConnectionState.HALTED}),
    ConnectionState.HALTED: frozenset({ConnectionState.DISCONNECTED}),
}


def can_transition(source: ConnectionState, target: ConnectionState) -> bool:
    return target in _ALLOWED.get(source, frozenset())


def assert_transition(source: ConnectionState, target: ConnectionState) -> None:
    if not can_transition(source, target):
        raise IllegalTransition(f"illegal connection transition {source.value} -> {target.value}")


def allows_new_orders(state: ConnectionState) -> bool:
    return state is ConnectionState.READY
