"""Core value objects. Pure: no I/O, no clock, no config access."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, time, timedelta, timezone
from typing import Literal, NewType

from .money import Money, money

Symbol = NewType("Symbol", str)
Ticket = NewType("Ticket", int)
SlotId = NewType("SlotId", str)
IntentId = NewType("IntentId", str)

Timeframe = Literal["M1", "M5", "M15", "M30", "H1", "H4", "D1"]
Side = Literal["buy", "sell"]

TF_SECONDS: dict[str, int] = {
    "M1": 60,
    "M5": 300,
    "M15": 900,
    "M30": 1800,
    "H1": 3600,
    "H4": 14400,
    "D1": 86400,
}


def utc(value: datetime) -> datetime:
    """Normalise to timezone-aware UTC (naive input is assumed UTC)."""
    if value.tzinfo is None:
        return value.replace(tzinfo=timezone.utc)
    return value.astimezone(timezone.utc)


@dataclass(frozen=True, slots=True, order=True)
class Ts:
    """Event time (UTC wall clock) plus a monotonic reading for latency maths."""

    wall: datetime
    mono: float = 0.0

    def __post_init__(self) -> None:
        object.__setattr__(self, "wall", utc(self.wall))

    def plus(self, seconds: float) -> "Ts":
        return Ts(self.wall + timedelta(seconds=seconds), self.mono + seconds)

    def seconds_since(self, other: "Ts") -> float:
        return (self.wall - other.wall).total_seconds()

    @staticmethod
    def epoch() -> "Ts":
        """Neutral timestamp for components built without a clock (tests)."""
        return Ts(datetime(1970, 1, 1, tzinfo=timezone.utc), 0.0)


@dataclass(frozen=True, slots=True)
class Tick:
    symbol: Symbol
    bid: float
    ask: float
    ts_event: Ts
    ts_recv: Ts
    volume: int = 0

    @property
    def mid(self) -> float:
        return (self.bid + self.ask) / 2.0

    @property
    def spread(self) -> float:
        return max(0.0, self.ask - self.bid)


@dataclass(frozen=True, slots=True)
class Bar:
    symbol: Symbol
    timeframe: Timeframe
    open_time: datetime
    o: float
    h: float
    l: float
    c: float
    tick_volume: int = 0
    spread_avg: float = 0.0
    is_closed: bool = True
    revision: int = 0
    ts_recv: float = 0.0

    def __post_init__(self) -> None:
        object.__setattr__(self, "open_time", utc(self.open_time))

    @property
    def close_time(self) -> datetime:
        return self.open_time + timedelta(seconds=TF_SECONDS[self.timeframe])

    @property
    def body(self) -> float:
        return self.c - self.o

    @property
    def range(self) -> float:
        return self.h - self.l

    @property
    def is_bullish(self) -> bool:
        return self.c > self.o


@dataclass(frozen=True, slots=True)
class SessionWindow:
    """Daily trading window expressed in broker server time."""

    start: time
    end: time

    def contains(self, at: time) -> bool:
        if self.start <= self.end:
            return self.start <= at < self.end
        return at >= self.start or at < self.end


@dataclass(frozen=True, slots=True)
class SymbolInfo:
    symbol: Symbol
    broker_symbol: str
    digits: int = 2
    point: float = 0.01
    tick_size: float = 0.01
    contract_size: float = 100.0
    min_volume: float = 0.01
    max_volume: float = 50.0
    volume_step: float = 0.01
    stops_level_points: int = 30
    freeze_level_points: int = 0
    margin_rate: float = 0.01
    currency_profit: str = "USD"
    trade_mode: Literal["full", "longonly", "shortonly", "closeonly", "disabled"] = "full"
    sessions: tuple[SessionWindow, ...] = (
        SessionWindow(time(0, 0), time(23, 59)),
    )
    broker_offset: timedelta = timedelta(hours=2)
    swap_long: float = 0.0
    swap_short: float = 0.0
    # Broker-truth extras. Defaults keep every existing constructor valid:
    # 0.0 = unknown tick value (sizing falls back to contract_size) and
    # "unknown" = the venue has not told us its filling policy yet.
    tick_value: float = 0.0
    filling_mode: Literal["fok", "ioc", "return", "unknown"] = "unknown"

    def to_points(self, price_distance: float) -> float:
        return price_distance / self.point

    def from_points(self, points: float) -> float:
        return points * self.point

    def round_price(self, price: float) -> float:
        return round(price, self.digits)

    def round_volume(self, volume: float) -> float:
        steps = int(volume / self.volume_step + 1e-9)
        return round(steps * self.volume_step, 2)


@dataclass(frozen=True, slots=True)
class AccountSnapshot:
    login: int
    server: str
    currency: str
    balance: Money
    equity: Money
    margin: Money
    free_margin: Money
    leverage: int
    trade_mode: Literal["hedging", "netting"]
    ts: Ts

    @property
    def margin_level(self) -> float | None:
        if self.margin.amount <= 0:
            return None
        return float(self.equity.amount / self.margin.amount * 100)


@dataclass(frozen=True, slots=True)
class PositionSnapshot:
    ticket: Ticket
    symbol: Symbol
    side: Side
    volume: float
    open_price: float
    sl: float | None
    tp: float | None
    magic: int
    comment: str
    open_time: datetime
    profit: Money = field(default_factory=lambda: money(0))
    swap: Money = field(default_factory=lambda: money(0))

    @property
    def has_protection(self) -> bool:
        return self.sl is not None


@dataclass(frozen=True, slots=True)
class OrderSnapshot:
    ticket: Ticket
    symbol: Symbol
    side: Side
    volume: float
    price: float
    sl: float | None
    tp: float | None
    state: Literal["placed", "partial", "filled", "canceled", "rejected", "expired"]
    magic: int
    comment: str
    created_at: datetime
    filled_volume: float = 0.0


@dataclass(frozen=True, slots=True)
class Fill:
    ticket: Ticket
    symbol: Symbol
    side: Side
    volume: float
    price: float
    commission: Money
    ts: Ts
    kind: Literal["open", "close", "partial_close"] = "open"


@dataclass(frozen=True, slots=True)
class ClosedTrade:
    ticket: Ticket
    symbol: Symbol
    side: Side
    volume: float
    open_price: float
    close_price: float
    open_time: datetime
    close_time: datetime
    pnl_gross: Money
    commission: Money
    swap: Money
    reason: Literal["sl", "tp", "manual", "strategy", "kill", "timeout"] = "manual"

    @property
    def pnl_net(self) -> Money:
        return self.pnl_gross - self.commission + self.swap


@dataclass(frozen=True, slots=True)
class ConnectionInfo:
    server: str
    login: int
    trade_mode: Literal["hedging", "netting"]
    broker_offset: timedelta
    terminal: str = "fake"


@dataclass(frozen=True, slots=True)
class DealRecord:
    ticket: Ticket
    order_ticket: Ticket
    symbol: Symbol
    side: Side
    volume: float
    price: float
    commission: Money
    swap: Money
    profit: Money
    time: datetime
    comment: str
