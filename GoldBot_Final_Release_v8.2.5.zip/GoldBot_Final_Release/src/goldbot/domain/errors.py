"""Error taxonomy and the exceptions the runtime is allowed to raise."""

from __future__ import annotations

from enum import Enum, auto


class ErrorClass(Enum):
    NETWORK = auto()
    BROKER_TRANSIENT = auto()
    BROKER_PERMANENT = auto()
    DATA = auto()
    CLOCK = auto()
    LOGIC = auto()
    RISK = auto()
    CONFIG = auto()
    SECRET = auto()
    RESOURCE = auto()
    OPERATOR = auto()


class GoldbotError(Exception):
    """Base class; every error carries a searchable ``error_id``."""

    error_class: ErrorClass = ErrorClass.LOGIC
    code: str = "generic"

    def __init__(self, message: str, **context: object) -> None:
        super().__init__(message)
        self.message = message
        self.context = context

    @property
    def error_id(self) -> str:
        cls = self.error_class.name.lower()
        return f"{cls}:{self.code}"


class ConfigError(GoldbotError):
    error_class = ErrorClass.CONFIG
    code = "invalid_config"


class SecretError(GoldbotError):
    error_class = ErrorClass.SECRET
    code = "secret_unavailable"


class InvariantError(GoldbotError):
    error_class = ErrorClass.LOGIC
    code = "invariant_violation"


class IllegalTransition(InvariantError):
    code = "illegal_fsm_transition"


class RiskRejected(GoldbotError):
    error_class = ErrorClass.RISK
    code = "risk_rejected"


class NotReady(GoldbotError):
    error_class = ErrorClass.CONFIG
    code = "not_ready"


class SubmitUncertain(GoldbotError):
    """Outcome unknown. Never means failure — means 'I do not know'."""

    error_class = ErrorClass.NETWORK
    code = "submit_uncertain"

    def __init__(self, reason: str) -> None:
        super().__init__(f"order outcome unknown: {reason}", reason=reason)
        self.reason = reason
