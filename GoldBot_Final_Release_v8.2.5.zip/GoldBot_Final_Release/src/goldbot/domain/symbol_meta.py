"""Immutable broker symbol metadata with fail-closed validation."""

from __future__ import annotations

from dataclasses import dataclass

from .errors import InvariantError

# MT5 filling policies the core can act on; "unknown" means the venue never
# told us, which is a configuration fact, not an error by itself.
FILLING_MODES: tuple[str, ...] = ("fok", "ioc", "return", "unknown")


@dataclass(frozen=True, slots=True)
class SymbolMeta:
    name: str
    digits: int
    point: float
    contract_size: float
    volume_min: float
    volume_max: float
    volume_step: float
    stops_level_points: int
    freeze_level_points: int
    margin_initial: float = 0.0
    tick_value: float = 0.0
    tick_size: float = 0.0
    filling_mode: str = "unknown"

    @classmethod
    def from_symbol_info(cls, info) -> "SymbolMeta":
        return cls(
            name=str(info.symbol),
            digits=int(info.digits),
            point=float(info.point),
            contract_size=float(info.contract_size),
            volume_min=float(info.min_volume),
            volume_max=float(info.max_volume),
            volume_step=float(info.volume_step),
            stops_level_points=int(info.stops_level_points),
            freeze_level_points=int(info.freeze_level_points),
            margin_initial=float(info.margin_rate),
            tick_value=float(getattr(info, "tick_value", 0.0) or 0.0),
            tick_size=float(info.tick_size),
            filling_mode=str(getattr(info, "filling_mode", "unknown") or "unknown"),
        )

    def validate(self) -> None:
        checks = {
            "digits": self.digits > 0,
            "point": self.point > 0,
            "contract_size": self.contract_size > 0,
            "volume_step": self.volume_step > 0,
            "volume_min": self.volume_min > 0,
            "volume_max": self.volume_max >= self.volume_min,
            "stops_level": self.stops_level_points >= 0,
            # 0 is allowed and explicit: it means the tick value is unknown and
            # sizing must fall back to contract_size, never guess a number.
            "tick_value": self.tick_value >= 0.0,
            "filling_mode": self.filling_mode in FILLING_MODES,
        }
        broken = [name for name, ok in checks.items() if not ok]
        if broken:
            raise InvariantError(f"invalid symbol metadata for {self.name}: {broken}")

    @property
    def stops_level_price(self) -> float:
        return self.stops_level_points * self.point
