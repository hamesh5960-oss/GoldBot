"""Money type: Decimal based, currency tagged, quantised to cents at the boundary."""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal, ROUND_HALF_UP
from typing import Union

Number = Union[int, float, Decimal]
CENT = Decimal("0.01")


def dec(value: Number) -> Decimal:
    """Convert to Decimal without binary float noise (``0.1`` stays ``0.1``)."""
    if isinstance(value, Decimal):
        return value
    if isinstance(value, bool):  # bool is an int; reject silently-wrong usage
        raise TypeError("bool is not a money value")
    return Decimal(str(value))


@dataclass(frozen=True, slots=True)
class Money:
    amount: Decimal = Decimal("0")
    currency: str = "USD"

    def __post_init__(self) -> None:
        if not isinstance(self.amount, Decimal):
            object.__setattr__(self, "amount", dec(self.amount))

    # -- helpers ---------------------------------------------------------
    def _guard(self, other: "Money") -> None:
        if other.currency != self.currency:
            raise ValueError(f"currency mismatch: {self.currency} vs {other.currency}")

    def quantized(self) -> "Money":
        return Money(self.amount.quantize(CENT, rounding=ROUND_HALF_UP), self.currency)

    # -- arithmetic ------------------------------------------------------
    def __add__(self, other: "Money") -> "Money":
        self._guard(other)
        return Money(self.amount + other.amount, self.currency)

    def __sub__(self, other: "Money") -> "Money":
        self._guard(other)
        return Money(self.amount - other.amount, self.currency)

    def __neg__(self) -> "Money":
        return Money(-self.amount, self.currency)

    def __mul__(self, factor: Number) -> "Money":
        return Money(self.amount * dec(factor), self.currency)

    __rmul__ = __mul__

    def __truediv__(self, divisor: Number) -> "Money":
        return Money(self.amount / dec(divisor), self.currency)

    # -- comparison ------------------------------------------------------
    def __lt__(self, other: "Money") -> bool:
        self._guard(other)
        return self.amount < other.amount

    def __le__(self, other: "Money") -> bool:
        self._guard(other)
        return self.amount <= other.amount

    def __gt__(self, other: "Money") -> bool:
        self._guard(other)
        return self.amount > other.amount

    def __ge__(self, other: "Money") -> bool:
        self._guard(other)
        return self.amount >= other.amount

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Money):
            return NotImplemented
        return self.amount == other.amount and self.currency == other.currency

    def __hash__(self) -> int:
        return hash((self.amount, self.currency))

    def __str__(self) -> str:
        return f"{self.amount:.2f} {self.currency}"

    def __repr__(self) -> str:
        return f"Money({self.amount}, {self.currency!r})"

    @property
    def is_negative(self) -> bool:
        return self.amount < 0

    def as_float(self) -> float:
        return float(self.amount)


ZERO_USD = Money(Decimal("0"), "USD")


def money(value: Number, currency: str = "USD") -> Money:
    return Money(dec(value).quantize(CENT, rounding=ROUND_HALF_UP), currency)
