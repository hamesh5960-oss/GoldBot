"""Time helpers.

Iran has not observed daylight saving since 2022, so a fixed +03:30 offset is
correct and avoids a tzdata dependency on Windows. All storage stays in UTC.
"""

from __future__ import annotations

from datetime import date, datetime, timedelta, timezone

IRAN = timezone(timedelta(hours=3, minutes=30), name="Asia/Tehran")
UTC = timezone.utc


def to_iran(value: datetime) -> datetime:
    if value.tzinfo is None:
        value = value.replace(tzinfo=UTC)
    return value.astimezone(IRAN)


def iran_day(value: datetime) -> date:
    """The trading day a timestamp belongs to, from Iran's midnight boundary."""
    return to_iran(value).date()


def iran_now() -> datetime:
    return datetime.now(tz=UTC).astimezone(IRAN)


def utc_now() -> datetime:
    return datetime.now(tz=UTC)
