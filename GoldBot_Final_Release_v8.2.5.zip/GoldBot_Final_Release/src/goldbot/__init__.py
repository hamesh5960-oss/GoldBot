"""goldbot — modular XAUUSD trading framework."""

__version__ = "8.2.5"
