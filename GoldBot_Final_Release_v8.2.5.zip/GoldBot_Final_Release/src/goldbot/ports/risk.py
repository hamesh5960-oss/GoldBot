"""Risk boundary: the only producer of sealed orders."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from typing import Any, Mapping, Protocol, Sequence

from ..domain.execution import ApprovedOrder, EntryIntent, ManagementAction, RiskSnapshot
from ..domain.model import AccountSnapshot, PositionSnapshot, SymbolInfo, Tick


class Verdict(str, Enum):
    APPROVE = "approve"
    REJECT = "reject"
    DEFER = "defer"


class RiskState(str, Enum):
    NORMAL = "NORMAL"
    SOFT_HALT = "SOFT_HALT"
    HALTED = "HALTED"
    KILLED = "KILLED"
    QUARANTINE = "QUARANTINE"


@dataclass(frozen=True, slots=True)
class CheckResult:
    name: str
    ok: bool
    detail: str = ""
    value: float | None = None
    threshold: float | None = None

    def as_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "ok": self.ok,
            "detail": self.detail,
            "value": self.value,
            "threshold": self.threshold,
        }


@dataclass(frozen=True, slots=True)
class RiskDecision:
    verdict: Verdict
    reasons: tuple[str, ...]
    checks: tuple[CheckResult, ...]
    order: ApprovedOrder | None = None
    valid_until: datetime | None = None

    @property
    def approved(self) -> bool:
        return self.verdict is Verdict.APPROVE and self.order is not None

    def as_dict(self) -> dict[str, Any]:
        return {
            "verdict": self.verdict.value,
            "reasons": list(self.reasons),
            "checks": [c.as_dict() for c in self.checks],
            "order": None if self.order is None else {
                "volume": self.order.volume,
                "sl": self.order.sl,
                "tp": self.order.tp,
                "risk": self.order.risk.as_dict(),
            },
        }


@dataclass(frozen=True, slots=True)
class RiskContext:
    account: AccountSnapshot
    positions: Sequence[PositionSnapshot]
    symbol_info: SymbolInfo
    tick: Tick
    now: datetime
    atr: float | None = None
    session_open: bool = True
    news_blackout: bool = False
    session: str = ""
    atr_percentile: float | None = None
    broker_now: datetime | None = None
    reconciled: bool = True

    @property
    def equity(self) -> float:
        return float(self.account.equity.amount)

    @property
    def balance(self) -> float:
        return float(self.account.balance.amount)

    @property
    def unrealized(self) -> float:
        return float(sum(p.profit.amount for p in self.positions))

    @property
    def open_positions(self) -> int:
        return len(self.positions)


class IRiskEngine(Protocol):
    def state(self) -> RiskState: ...
    def evaluate_entry(self, intent: EntryIntent, ctx: RiskContext) -> RiskDecision: ...
    def on_mark(self, ctx: RiskContext) -> None: ...
    def on_trade_closed(self, pnl: float, at: datetime) -> None: ...
    def manage(self, ctx: RiskContext) -> Sequence[ManagementAction]: ...
    def engage(self, level: RiskState, reason: str, *, actor: str) -> None: ...
    def acknowledge(self, *, level: RiskState, actor: str, note: str) -> None: ...
    def snapshot(self) -> RiskSnapshot: ...
    def secret(self) -> str: ...
