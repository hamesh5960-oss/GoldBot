"""Clock boundary: event time, wall time and broker offset are distinct concepts."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from enum import Enum
from typing import Protocol

from ..domain.model import Symbol, Ts


class SessionState(str, Enum):
    OPEN = "OPEN"
    PRE = "PRE"
    POST = "POST"
    CLOSED = "CLOSED"
    HOLIDAY = "HOLIDAY"


@dataclass(frozen=True, slots=True)
class ClockDrift:
    broker_offset: timedelta
    confidence: timedelta
    suspect: bool


class IClock(Protocol):
    def now(self) -> Ts: ...
    def broker_now(self) -> datetime: ...
    def drift(self) -> ClockDrift: ...
    def to_broker(self, ts: datetime) -> datetime: ...
    def to_utc(self, ts: datetime) -> datetime: ...
    def session(self, symbol: Symbol, at: datetime | None = None) -> SessionState: ...


UTC = timezone.utc
