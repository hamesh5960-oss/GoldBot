"""Persistence boundary: the risk state that must survive a restart.

The engine owns the numbers; this module is the wire format shared by the
durable adapter and the recovery tooling. A store that cannot be read is a
safety event, never a reason to start from NORMAL.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping, Protocol

from ..domain.errors import ErrorClass, GoldbotError
from .risk import RiskState

SCHEMA_VERSION = 1

# Journal event types used by the composition root when it restores a session.
# They live here (not in the Ev catalogue) until the record format is frozen.
STATE_RESTORED_EVENT = "RiskStateRestored"
STATE_RESTORE_FAILED_EVENT = "RiskStateRestoreFailed"


class StateCorruption(GoldbotError):
    """Persisted risk state exists but cannot be trusted.

    Callers must convert this into QUARANTINE; it is never a cold start.
    """

    error_class = ErrorClass.DATA
    code = "state_corruption"


@dataclass(frozen=True, slots=True)
class PersistedRiskState:
    """Everything the risk engine must remember across a process restart."""

    schema_version: int = SCHEMA_VERSION
    state: RiskState = RiskState.NORMAL
    reason: str = ""
    auto_clear: bool = False
    day: str | None = None
    day_start_equity: float | None = None
    peak_equity: float = 0.0
    initial_equity: float | None = None
    daily_pnl: float = 0.0
    drawdown_pct: float = 0.0
    consecutive_losses: int = 0
    orders_today: int = 0
    last_order_at: str | None = None
    last_loss_at: str | None = None
    ticket_meta: Mapping[int, Mapping[str, Any]] = field(default_factory=dict)
    # Opaque, namespaced snapshot of adjacent safety state (currently the
    # cooldown gates: burns, sl counts, ticket->zone mapping, bar counters).
    extras: Mapping[str, Any] = field(default_factory=dict)
    restored_at: str = ""
    updated_at: str = ""

    def to_dict(self) -> dict[str, Any]:
        """JSON-safe representation (ticket numbers become object keys)."""
        return {
            "schema_version": self.schema_version,
            "state": self.state.value,
            "reason": self.reason,
            "auto_clear": self.auto_clear,
            "day": self.day,
            "day_start_equity": self.day_start_equity,
            "peak_equity": self.peak_equity,
            "initial_equity": self.initial_equity,
            "daily_pnl": self.daily_pnl,
            "drawdown_pct": self.drawdown_pct,
            "consecutive_losses": self.consecutive_losses,
            "orders_today": self.orders_today,
            "last_order_at": self.last_order_at,
            "last_loss_at": self.last_loss_at,
            "ticket_meta": {str(ticket): dict(meta) for ticket, meta in self.ticket_meta.items()},
            "extras": dict(self.extras),
            "restored_at": self.restored_at,
            "updated_at": self.updated_at,
        }

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "PersistedRiskState":
        """Rebuild a record, raising StateCorruption on anything odd."""
        if not isinstance(data, dict):
            raise StateCorruption("risk state payload is not a JSON object")
        version = data.get("schema_version")
        if version != SCHEMA_VERSION:
            raise StateCorruption(
                f"unsupported risk state schema {version!r} (expected {SCHEMA_VERSION})"
            )
        raw_state = data.get("state")
        try:
            state = RiskState(raw_state)
        except (TypeError, ValueError) as exc:
            raise StateCorruption(f"unknown risk state {raw_state!r}") from exc
        try:
            ticket_meta = {
                int(ticket): dict(meta)
                for ticket, meta in dict(data.get("ticket_meta") or {}).items()
            }
        except (TypeError, ValueError) as exc:
            raise StateCorruption("risk state ticket_meta is not a ticket->object map") from exc
        try:
            return cls(
                schema_version=SCHEMA_VERSION,
                state=state,
                reason=str(data.get("reason") or ""),
                auto_clear=bool(data.get("auto_clear") or False),
                day=_opt_str(data.get("day")),
                day_start_equity=_opt_float(data.get("day_start_equity")),
                peak_equity=float(data.get("peak_equity") or 0.0),
                initial_equity=_opt_float(data.get("initial_equity")),
                daily_pnl=float(data.get("daily_pnl") or 0.0),
                drawdown_pct=float(data.get("drawdown_pct") or 0.0),
                consecutive_losses=int(data.get("consecutive_losses") or 0),
                orders_today=int(data.get("orders_today") or 0),
                last_order_at=_opt_str(data.get("last_order_at")),
                last_loss_at=_opt_str(data.get("last_loss_at")),
                ticket_meta=ticket_meta,
                extras=dict(data.get("extras") or {}),
                restored_at=str(data.get("restored_at") or ""),
                updated_at=str(data.get("updated_at") or ""),
            )
        except (TypeError, ValueError) as exc:
            raise StateCorruption(f"risk state payload has invalid numbers: {exc}") from exc


def _opt_str(value: object) -> str | None:
    return None if value in (None, "") else str(value)


def _opt_float(value: object) -> float | None:
    return None if value is None else float(value)


class IRiskStateStore(Protocol):
    """Durable single-record store for PersistedRiskState."""

    def load(self) -> PersistedRiskState | None: ...

    def save(self, state: PersistedRiskState) -> None: ...

    def clear(self) -> None: ...
