"""Market data boundary: one contract for live, replay and backtest."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Iterator, Protocol, Sequence

from ..domain.model import Bar, Symbol, Tick, Timeframe


@dataclass(frozen=True, slots=True)
class MarketSnapshot:
    symbol: Symbol
    last_tick: Tick | None
    last_bar: Bar | None
    spread: float


class IMarketDataFeed(Protocol):
    def stream(self) -> Iterator[Tick]: ...
    def last_known(self, symbol: Symbol) -> MarketSnapshot | None: ...
    def staleness(self, symbol: Symbol, now: datetime) -> float: ...
