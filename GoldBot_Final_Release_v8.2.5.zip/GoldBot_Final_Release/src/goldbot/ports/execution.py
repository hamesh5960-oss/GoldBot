"""Execution boundary: order coordination and derived position ownership."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping, Protocol, Sequence

from ..domain.execution import ApprovedOrder, ExitIntent, OrderAck
from ..domain.model import ClosedTrade, Fill, PositionSnapshot, Symbol, Ticket


@dataclass(frozen=True, slots=True)
class ExecutionResult:
    intent_id: str
    status: str  # acked | uncertain | rejected | expired
    ack: OrderAck | None = None
    retryable: bool = False
    action: str = ""  # RetcodeAction value from the domain table


@dataclass(frozen=True, slots=True)
class PositionView:
    ticket: int
    slot: str
    strategy: str
    symbol: str
    side: str
    volume: float
    open_price: float
    sl: float | None
    tp: float | None
    open_time: object
    risk_amount: float
    mae: float = 0.0
    mfe: float = 0.0


@dataclass(frozen=True, slots=True)
class ReconcileReport:
    clean: bool
    missing: tuple[int, ...] = ()
    orphan: tuple[int, ...] = ()
    volume_drift: tuple[int, ...] = ()
    protection_lost: tuple[int, ...] = ()
    details: tuple[str, ...] = ()


class IOrderExecutor(Protocol):
    def execute(self, approved: ApprovedOrder) -> ExecutionResult: ...
    def close_position(self, intent: ExitIntent) -> ExecutionResult: ...
    def in_flight(self) -> Sequence[str]: ...


class IPositionManager(Protocol):
    def apply_fill(self, fill: Fill) -> None: ...
    def apply_close(self, trade: ClosedTrade, *, slot: str | None = None) -> None: ...
    def mark(self, prices: Mapping[Symbol, tuple[float, float]]) -> None: ...
    def view(self) -> Sequence[PositionView]: ...
    def by_slot(self, slot: str) -> Sequence[PositionView]: ...
    def by_symbol(self, symbol: Symbol) -> Sequence[PositionView]: ...
    def slot_of(self, ticket: Ticket) -> str | None: ...
    def reconcile(self, truth: Sequence[PositionSnapshot]) -> ReconcileReport: ...
    def count(self) -> int: ...
    def net_volume(self, symbol: Symbol) -> float: ...
