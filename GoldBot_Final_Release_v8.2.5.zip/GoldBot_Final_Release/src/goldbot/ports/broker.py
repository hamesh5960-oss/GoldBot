"""Broker boundary. Reads are idempotent; writes are idempotent *by key*."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Protocol, Sequence

from ..domain.execution import ApprovedOrder, OrderAck
from ..domain.model import (
    AccountSnapshot,
    ClosedTrade,
    ConnectionInfo,
    DealRecord,
    OrderSnapshot,
    PositionSnapshot,
    Symbol,
    SymbolInfo,
    Tick,
    Ticket,
)


@dataclass(frozen=True, slots=True)
class GatewayHealth:
    alive: bool
    latency_ms: float
    last_tick_age_s: float
    queue_depth: int = 0
    message: str = ""


class IBrokerGateway(Protocol):
    """Everything the core is allowed to know about the venue."""

    # --- lifecycle ------------------------------------------------------
    def connect(self) -> ConnectionInfo: ...
    def disconnect(self) -> None: ...
    def health(self) -> GatewayHealth: ...
    def is_ready(self) -> bool: ...

    # --- reads (idempotent, retry-safe) ---------------------------------
    def symbol_info(self, symbol: Symbol) -> SymbolInfo: ...
    def account(self) -> AccountSnapshot: ...
    def positions(self) -> Sequence[PositionSnapshot]: ...
    def orders(self) -> Sequence[OrderSnapshot]: ...
    def deals(self, *, since: datetime) -> Sequence[DealRecord]: ...

    # --- writes (idempotent by key) -------------------------------------
    def submit(self, order: ApprovedOrder, *, idempotency_key: str) -> OrderAck: ...
    def modify(
        self, ticket: Ticket, *, sl: float | None, tp: float | None, idempotency_key: str
    ) -> OrderAck: ...
    def close(
        self, ticket: Ticket, *, volume: float | None, idempotency_key: str, reason: str = "manual"
    ) -> OrderAck: ...

    # --- orphan detection ------------------------------------------------
    def find_by_client_ref(self, client_ref: str, *, since: datetime) -> Sequence[OrderSnapshot]: ...

    # --- market advancement ----------------------------------------------
    def on_market_tick(self, tick: Tick) -> Sequence[ClosedTrade]:
        """Simulated venues settle SL/TP here. Live venues return ()."""
        ...
