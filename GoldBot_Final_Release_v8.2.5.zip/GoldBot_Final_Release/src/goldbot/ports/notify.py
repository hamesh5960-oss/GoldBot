"""Notification boundary: outbound only, deduplicated, rate limited."""

from __future__ import annotations

from typing import Literal, Protocol

Level = Literal["info", "warn", "critical"]


class INotifier(Protocol):
    def send(self, level: Level, title: str, body: str, *, dedup_key: str = "") -> bool: ...
