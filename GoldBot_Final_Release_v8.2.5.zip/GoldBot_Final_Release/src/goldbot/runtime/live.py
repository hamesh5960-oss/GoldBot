"""Live composition root: the same engine, wired to a MetaTrader 5 terminal.

The runtime is deliberately small. Everything that decides a trade already
lives in app/; this module only (a) connects the venue, (b) learns the server
offset before bars are built, (c) seeds the warm-up history, (d) runs the loop
and (e) reports. Safety gates here are about *the account*, not the strategy:
a real account is refused unless the caller explicitly allows it.
"""

from __future__ import annotations

import time as _time
from dataclasses import replace
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Sequence

from ..adapters.clock import SystemClock
from ..adapters.mt5_broker import (
    MT5Broker,
    MT5TickFeed,
    load_history,
    seed_builder,
    symbol_info_from_broker,
)
from ..app.market_session import SessionTableError, validate_live_session_table
from ..domain.events import Event
from ..domain.execution import ApprovedOrder, OrderAck
from ..domain.model import SymbolInfo
from ..log import get_logger
from .bootstrap import build_components, state_db_path

log = get_logger("live")

# Bars requested for the warm-up, per strategy timeframe. M15 is the core one:
# 9600 bars is roughly 100 trading days (the daily ATR percentile window).
WARMUP_COUNTS: dict[str, int] = {
    "M1": 5_000,
    "M5": 5_000,
    "M15": 9_600,
    "M30": 3_000,
    "H1": 800,
    "H4": 400,
    "D1": 150,
}


def _broker_weekly_sessions(
    broker: Any, broker_symbol: str
) -> dict[int, tuple[tuple[Any, Any], ...]] | None:
    """MT5 weekly session table (Monday..Sunday) when the venue exposes it.

    MetaTrader5 puts it on symbol_info(...).session_trade/session_quote as seven
    lists of (from, to) pairs. Anything unreadable returns None: the live guard
    still rejects the synthetic placeholder and only warns about the missing
    venue week, so a fake/limited broker cannot crash startup.
    """
    mt5 = getattr(broker, "mt5", None)
    lookup = getattr(mt5, "symbol_info", None)
    if not callable(lookup):
        return None
    try:
        raw = lookup(broker_symbol)
    except Exception:  # noqa: BLE001 - a metadata probe must never crash startup
        return None
    if raw is None:
        return None
    source = getattr(raw, "session_trade", None) or getattr(raw, "session_quote", None)
    if not source:
        return None
    weekly: dict[int, tuple[tuple[Any, Any], ...]] = {}
    try:
        for day, entries in enumerate(source):
            pairs: list[tuple[Any, Any]] = []
            for entry in entries or ():
                values = tuple(entry)
                if len(values) >= 2:
                    pairs.append((values[0], values[1]))
            weekly[int(day)] = tuple(pairs)
    except (TypeError, ValueError):
        return None
    return weekly


class DryRunBroker:
    """Read-only facade over the live venue: writes are refused, never sent."""

    def __init__(self, broker: MT5Broker) -> None:
        self._broker = broker

    def __getattr__(self, name: str) -> Any:
        return getattr(self._broker, name)

    @staticmethod
    def _refuse(intent_id: str, message: str) -> OrderAck:
        return OrderAck(
            intent_id=intent_id,
            accepted=False,
            retcode=10017,
            retcode_name="TRADE_DISABLED",
            message="dry-run: " + message,
        )

    def submit(self, order: ApprovedOrder, *, idempotency_key: str) -> OrderAck:
        return self._refuse(order.intent_id, "order not sent")

    def modify(
        self, ticket: Any, *, sl: float | None, tp: float | None, idempotency_key: str
    ) -> OrderAck:
        return self._refuse("", "modify not sent")

    def close(
        self, ticket: Any, *, volume: float | None, idempotency_key: str, reason: str = "manual"
    ) -> OrderAck:
        return self._refuse("", "close not sent")



def _wait_for_fresh_tick(broker: MT5Broker, *, timeout_s: float = 900.0, poll_s: float = 0.5) -> Any:
    """Block until the venue prints a tick that is not a pre-close leftover."""
    deadline = _time.monotonic() + timeout_s
    announced = False
    while _time.monotonic() < deadline:
        tick = broker.raw_tick()
        if tick is not None:
            age = (datetime.now(tz=timezone.utc) - tick.ts_event.wall).total_seconds()
            if 0.0 <= age <= 120.0:
                return tick
        if not announced:
            announced = True
            print("بازار بسته است؛ در انتظار اولین تیک زنده برای شروع ...")
        _time.sleep(poll_s)
    return None


def _print_banner(
    *,
    connection: Any,
    account: Any,
    info: SymbolInfo,
    profile_name: str,
    journal_path: str,
    cold_start: bool,
    dry_run: bool,
    trade_allowed: bool,
    tick: Any,
) -> None:
    print()
    print("=" * 68)
    print("  GoldBot — نشست زنده MetaTrader 5")
    print("=" * 68)
    print(f"  حساب / سرور        : {connection.login} @ {connection.server}")
    print(f"  نماد منطقی / بروکر : {info.symbol} / {info.broker_symbol}")
    print(f"  موجودی / اکوئیتی   : {float(account.balance.amount):,.2f} / {float(account.equity.amount):,.2f} {account.currency}")
    print(f"  اهرم / حالت        : 1:{account.leverage} / {account.trade_mode}")
    print(f"  پروفایل ریسک       : {profile_name}")
    print(f"  ژورنال             : {journal_path}")
    print(f"  AutoTrading        : {'فعال' if trade_allowed else 'خاموش — سفارش‌ها رد می‌شوند'}")
    print(f"  حالت امنیتی        : {'dry-run (بدون ارسال سفارش)' if dry_run else 'ارسال واقعی سفارش (حساب دمو)'}")
    if cold_start:
        print("  شروع سرد           : تأییدشده توسط اپراتور (اولین اجرا)")
    if tick is not None:
        print(f"  قیمت لحظه‌ای       : bid={tick.bid:.2f} ask={tick.ask:.2f} spread={tick.spread / info.point:.0f} point")
    else:
        print("  قیمت لحظه‌ای       : هنوز تیکی نرسیده (بازار بسته یا در حال اتصال)")
    print("-" * 68)
    print("  Ctrl+C = توقف امن؛ پوزیشن‌های باز با SL/TP خود بروکر محافظت می‌شوند.")
    print("=" * 68)
    print()


def run_live(
    settings: Any,
    *,
    login: int,
    password: str,
    server: str,
    mt5_path: str = "",
    profile_name: str | None = None,
    db_path: str | Path = "var/live.db",
    state_db: str | Path | None = None,
    cold_start: bool = False,
    allow_real: bool = False,
    dry_run: bool = False,
    broker_symbol: str | None = None,
    extra_overrides: dict[str, Any] | None = None,
    wait_open_seconds: float = 900.0,
) -> int:
    symbol_cfg = settings.symbol
    symbol_updates: dict[str, Any] = {}
    if broker_symbol:
        symbol_updates["broker_symbol"] = broker_symbol
    account_updates: dict[str, Any] = {"login": int(login), "server": server}
    settings = settings.model_copy(
        update={
            "symbol": symbol_cfg.model_copy(update=symbol_updates),
            "account": settings.account.model_copy(update=account_updates),
        }
    )
    info = settings.symbol_info()
    resolved_state_db = state_db_path(db_path, state_db)
    if not cold_start and not resolved_state_db.exists():
        print(
            "شروع رد شد: هیچ فایل state پایدار موجود نیست و --cold-start داده نشده. "
            "برای اولین اجرای عمدی، --cold-start را صریحاً بدهید (پس از تأیید نبود پوزیشن باز)؛ "
            "برای restart عادی، فایل state را بازگردانید."
        )
        return 2
    if cold_start and resolved_state_db.exists():
        print(
            f"شروع سرد رد شد: فایل state از قبل وجود دارد ({resolved_state_db}). "
            "برای restart عادی --cold-start را حذف کنید؛ برای reset ابتدا state و پوزیشن‌های بروکر را دستی تطبیق دهید."
        )
        return 2
    broker = MT5Broker(
        info,
        login=int(login),
        password=password,
        server=server,
        path=mt5_path,
    )
    print(f"در حال اتصال به MetaTrader 5 (حساب {login} @ {server}) ...")
    try:
        connection = broker.connect()
    except Exception as exc:  # noqa: BLE001 - the operator needs the reason, not a traceback
        print(f"خطا در اتصال به متاتریدر: {exc}")
        print("راهنما: مسیر terminal64.exe، لاگین/رمز/سرور و باز بودن ترمینال را بررسی کنید.")
        return 2
    if not broker.is_demo() and not allow_real:
        broker.disconnect()
        print("این حساب «واقعی» است؛ اجرای زنده فقط با --allow-real مجاز است. متوقف شد.")
        return 2
    if cold_start:
        try:
            existing_positions = tuple(broker.positions())
            existing_orders = tuple(broker.orders())
        except Exception as exc:  # noqa: BLE001 - unknown broker state must fail closed
            broker.disconnect()
            print(f"شروع سرد رد شد: وضعیت پوزیشن/سفارش بروکر قابل تأیید نیست: {exc}")
            return 2
        if existing_positions or existing_orders:
            broker.disconnect()
            print(
                "شروع سرد رد شد: بروکر پوزیشن یا سفارش باز دارد. "
                "برای جلوگیری از state نامعتبر، ابتدا همهٔ موارد را دستی تطبیق/ببندید."
            )
            return 2
    # Broker truth wins over config: sizing, stops and filling come from the venue.
    components = None
    feed = None
    components_closed = False
    try:
        fresh = _wait_for_fresh_tick(broker, timeout_s=max(0.0, float(wait_open_seconds)))
        if fresh is None:
            print("هشدار: تیک تازه‌ای نرسید؛ با offset پیکربندی ادامه می‌دهیم.")
        connection = replace(connection, broker_offset=broker.offset)
        learned: SymbolInfo = symbol_info_from_broker(
            broker.mt5,
            broker_symbol=info.broker_symbol,
            logical_name=settings.symbol.name,
            broker_offset=connection.broker_offset,
            fallback=info,
        )
        broker.bind_info(learned)
        # SES-03: a live run may never trade on the synthetic 00:00-23:59
        # placeholder session table. The venue week is authoritative when it
        # exists; fail closed before the clock/engine are built.
        broker_sessions = _broker_weekly_sessions(broker, learned.broker_symbol)
        try:
            session_warnings = validate_live_session_table(
                learned.sessions, broker_sessions=broker_sessions
            )
        except SessionTableError as exc:
            print(f"شروع رد شد: جدول سشن‌های بروکر قابل اعتماد نیست: {exc}")
            print(
                "برای اجرای زنده، [symbol].sessions در config باید تقویم واقعی بروکر باشد؛ "
                "جدول placeholder فقط برای backtest است."
            )
            return 2
        for warning in session_warnings:
            print(f"هشدار سشن: {warning}")
        clock = SystemClock(learned)
        feed = MT5TickFeed(broker, clock=clock)

        from strategies.registry import load_instances

        instances = load_instances(settings.strategies.directory)
        timeframes: Sequence[str] = sorted({str(instance.timeframe) for instance in instances}) or ["M15"]

        def seed_history(builder: Any) -> None:
            counts = {
                timeframe: (
                    settings.trading.history_bars
                    if timeframe == "M15"
                    else WARMUP_COUNTS.get(timeframe, 2_000)
                )
                for timeframe in timeframes
            }
            print(f"در حال دریافت تاریخچه {', '.join(timeframes)} برای warm-up ...")
            bars = load_history(
                broker.mt5,
                broker_symbol=learned.broker_symbol,
                info=learned,
                timeframes=timeframes,  # type: ignore[arg-type]
                offset=connection.broker_offset,
                counts=counts,
            )
            total = seed_builder(builder, bars)
            detail = ", ".join(f"{name}={len(rows)}" for name, rows in bars.items())
            print(f"warm-up: {total} کندل بسته‌شده ({detail})")
            log.warning("warm-up seeded", extra={"fields": {"bars": total, "detail": detail}})

        runtime_broker: Any = DryRunBroker(broker) if dry_run else broker
        components = build_components(
            settings,
            tape_path="",
            profile_name=profile_name,
            extra_overrides=extra_overrides,
            db_path=db_path,
            state_db=resolved_state_db,
            allow_cold_start=bool(cold_start),
            live_broker=runtime_broker,
            live_feed=feed,
            live_clock=clock,
            seed_history=seed_history,
            info_override=learned,
        )
        journal_path = str(db_path)
        account = broker.account()
        probe = broker.raw_tick()
        _print_banner(
            connection=connection,
            account=account,
            info=learned,
            profile_name=components.profile.name,
            journal_path=journal_path,
            cold_start=bool(cold_start),
            dry_run=dry_run,
            trade_allowed=broker.trade_allowed(),
            tick=probe,
        )
        if components.risk.state().value != "NORMAL":
            print(
                "هشدار: وضعیت ریسک NORMAL نیست ("
                + components.risk.state().value
                + "). سیگنال‌ها ژورنال می‌شوند ولی معامله‌ای باز نمی‌شود."
            )
            print("برای اولین اجرا، دستور را با --cold-start اجرا کنید یا ابتدا وضعیت ریسک را تأیید کنید.")
        components.journal.append(
            Event(
                type="LiveArmed",
                payload={
                    "login": connection.login,
                    "server": connection.server,
                    "symbol": learned.broker_symbol,
                    "profile": components.profile.name,
                    "dry_run": bool(dry_run),
                    "cold_start": bool(cold_start),
                    "trade_allowed": broker.trade_allowed(),
                    "broker_offset_minutes": connection.broker_offset.total_seconds() / 60.0,
                },
                ts=clock.now(),
                actor="operator",
            )
        )
        result = None
        try:
            result = components.engine.run()
        except KeyboardInterrupt:
            print("\nتوقف دستی دریافت شد؛ بستن ژورنال و ثبت پایان نشست ...")
            try:
                components.engine._finish()
            except Exception:  # noqa: BLE001 - shutdown must report, not crash
                log.exception("engine finish failed during shutdown")
            result = components.engine.result
        finally:
            feed.stop()
            try:
                components.close()
            except Exception:  # noqa: BLE001
                log.exception("component close failed")
            finally:
                components_closed = True
        if result is not None:
            from .cli import print_report

            stats = getattr(result, "stats", {}) or {}
            print_report(result, stats, components.profile, components.overrides)
            print(f"ژورنال کامل: python run_goldbot.py report --db {journal_path}")
            print(f"مقایسه سیگنال/معامله: python run_goldbot.py signals --db {journal_path}")
        return 0
    finally:
        if components is not None and not components_closed:
            try:
                components.close()
            except Exception:  # noqa: BLE001
                log.exception("component close failed during live setup")
        broker.disconnect()