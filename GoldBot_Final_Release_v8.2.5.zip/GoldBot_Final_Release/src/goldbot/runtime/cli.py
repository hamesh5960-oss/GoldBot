"""Command line interface: demo, backtest, report, profiles, selftest, ack."""

from __future__ import annotations

import argparse
import json
import os
import sys
from dataclasses import replace
from datetime import datetime, timedelta, timezone
from pathlib import Path
from types import SimpleNamespace
from typing import Any, Sequence

from ..adapters.config import load_settings
from ..adapters.sqlite_state_store import SqliteRiskStateStore
from ..adapters.sqlite_store import SqliteJournal
from ..adapters.tape import TapeFeed, generate_synthetic_ticks, write_synthetic_tape
from ..adapters.tape_library import SCENARIO_NAMES, write_scenario_tape
from ..app.health import snapshot as health_snapshot
from ..app.risk import ABSOLUTE_MAX, load_profiles
from ..domain.errors import GoldbotError
from ..domain.events import Event, Ev
from ..domain.model import Ts
from ..log import setup as setup_logging
from ..ports.risk import RiskState
from ..ports.state import StateCorruption
from .bootstrap import build_components, state_db_path

ROOT = Path.cwd()


def _parse_overrides(pairs: Sequence[str]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for pair in pairs:
        if "=" not in pair:
            raise SystemExit(f"--set expects key=value, got {pair!r}")
        key, raw = pair.split("=", 1)
        try:
            value: Any = float(raw) if "." in raw else int(raw)
        except ValueError:
            value = raw
        out[key.strip()] = value
    return out


def _fmt_money(value: float) -> str:
    return f"{value:,.2f}"


def print_report(result: Any, stats: dict[str, Any], profile: Any, overrides: Any) -> None:
    print()
    print("=" * 64)
    print("  گزارش اجرا — GoldBot XAUUSD")
    print("=" * 64)
    print(f"  پروفایل ریسک        : {profile.name}  (ریسک هر معامله {profile.risk_per_trade_pct}%)")
    if overrides:
        print("  تنظیم دستی          : " + ", ".join(f"{o.field}={o.value}" for o in overrides))
    print(f"  تیک‌های پردازش‌شده   : {result.ticks:,}")
    print(f"  کندل‌های بسته‌شده    : {result.bars:,}")
    print(f"  سیگنال / قصد سفارش  : {result.signals:,} / {result.intents:,}")
    print(f"  تأیید / رد ریسک     : {result.approved:,} / {result.rejected:,}")
    print(f"  معاملات بسته‌شده     : {result.trades_closed:,}")
    print(f"  وضعیت نهایی ریسک    : {result.final_state}")
    print("-" * 64)
    print(f"  سرمایه اولیه        : {_fmt_money(stats.get('start_equity', 0.0))} USD")
    print(f"  سرمایه پایانی       : {_fmt_money(result.final_equity)} USD")
    print(f"  سود/زیان خالص       : {_fmt_money(stats.get('net', 0.0))} USD")
    print(f"  نرخ برد             : {stats.get('win_rate', 0.0)}%")
    print(f"  ضریب سود (PF)       : {stats.get('profit_factor', 0.0)}")
    print(f"  میانگین R            : {stats.get('avg_r', 0.0)}")
    print(f"  حداکثر افت سرمایه   : {stats.get('max_dd_pct', 0.0)}%")
    if stats.get("by_slot"):
        print("-" * 64)
        print("  تفکیک استراتژی    :")
        for slot, row in stats["by_slot"].items():
            print(
                f"    {slot:<12} معاملات={int(row['trades']):<4} برد={row['win_rate']}%  "
                f"خالص={_fmt_money(row['net'])}"
            )
    if result.rejects:
        top = sorted(result.rejects.items(), key=lambda kv: kv[1], reverse=True)[:6]
        print("-" * 64)
        print("  دلایل رد ریسک       : " + ", ".join(f"{k}={v}" for k, v in top))
    if result.uncertain:
        print(f"  سفارش‌های نامعلوم    : {result.uncertain}")
    print("=" * 64)


def cmd_demo(args: argparse.Namespace) -> int:
    settings = load_settings(args.config)
    tape = Path(args.tape or f"var/demo_{args.days}d.jsonl")
    if args.regenerate or not tape.exists():
        print(f"ساخت tape دمو ({args.days} روز) → {tape}")
        count = write_synthetic_tape(
            tape,
            symbol=settings.symbol.name,
            start=datetime(2024, 3, 3, tzinfo=timezone.utc),
            days=args.days,
            ticks_per_minute=args.ticks_per_minute,
            seed=args.seed,
            start_price=args.start_price,
        )
        print(f"  {count:,} تیک نوشته شد")
    return _run(settings, tape, args)


def cmd_backtest(args: argparse.Namespace) -> int:
    settings = load_settings(args.config)
    tape = Path(args.tape)
    if not tape.exists():
        print(f"tape پیدا نشد: {tape}", file=sys.stderr)
        return 2
    return _run(settings, tape, args)


def _run(settings: Any, tape: Path, args: argparse.Namespace) -> int:
    overrides = _parse_overrides(getattr(args, "set", []) or [])
    db_path = Path(args.db or settings.journal.path)
    explicit_state = bool(
        getattr(args, "state_db", None) or os.environ.get("GOLDBOT_STATE_DB", "").strip()
    )
    state_path = state_db_path(db_path, getattr(args, "state_db", None))
    if not getattr(args, "keep", False):
        # A fresh journal per run: mixing runs would corrupt the equity curve
        # and every statistic derived from it.
        for suffix in ("", "-wal", "-shm"):
            candidate = Path(str(db_path) + suffix)
            if candidate.exists():
                candidate.unlink()
        if not explicit_state:
            # Demo/backtest are synthetic: never inherit a latch from the last
            # run. An operator-supplied state database is left untouched.
            for suffix in ("", "-wal", "-shm"):
                candidate = Path(str(state_path) + suffix)
                if candidate.exists():
                    candidate.unlink()
    components = build_components(
        settings,
        tape_path=tape,
        profile_name=args.profile,
        extra_overrides=overrides,
        db_path=db_path,
        initial_balance=getattr(args, "balance", None),
        state_db=state_path,
        allow_cold_start=True,
    )
    try:
        result = components.engine.run()
        stats = components.journal.stats()
        print_report(result, stats, components.profile, components.overrides)
        if args.dump_events:
            _dump_events(components, args.dump_events)
        return 0
    finally:
        components.close()


def _dump_events(components: Any, limit: int) -> None:
    print("\nآخرین رویدادها:")
    events = list(components.journal.read_events(limit=limit))
    for event in events[-limit:]:
        corr = f" [{event.correlation_id}]" if event.correlation_id else ""
        print(f"  {event.ts.wall:%Y-%m-%d %H:%M} {event.type:<24}{corr}")


def cmd_report(args: argparse.Namespace) -> int:
    from ..adapters.sqlite_store import SqliteJournal

    path = Path(args.db)
    if not path.exists():
        print(f"دیتابیس پیدا نشد: {path}", file=sys.stderr)
        print("اول یک اجرا انجام بده، مثلاً:", file=sys.stderr)
        print("  python run_goldbot.py demo --days 10", file=sys.stderr)
        return 2
    journal = SqliteJournal(path)
    stats = journal.stats()
    print(f"\nگزارش {path}")
    for key, value in stats.items():
        print(f"  {key:<16}: {value}")
    signals = list(journal.signals(limit=100_000))
    if signals:
        from collections import Counter

        tiers = Counter(s.tier or "?" for s in signals)
        print("\nتوزیع Tier سیگنال‌ها:")
        for tier in ("A+", "A", "B", "C", "D", "NOISE", "?"):
            count = tiers.get(tier, 0)
            if count:
                print(f"  {tier:<6}: {count:>5}  ({count / len(signals) * 100:4.1f}%)")
        d_floor = sum(1 for s in signals if s.d_hard_floor or (s.tier or "").upper() == "D")
        print(f"  D (hard floor): {d_floor}  (zone_filter/count-0, recorded only)")
        confirmations = Counter(round(float(s.confirmation_count), 1) for s in signals)
        print("  شمارش تأییدیه: " + ", ".join(f"{k}:{v}" for k, v in sorted(confirmations.items())))
    if getattr(args, "funnel", False):
        events = list(journal.read_events(limit=20_000))
        finished = [event for event in events if event.type == "SessionFinished"]
        funnel = dict(finished[-1].payload).get("funnel", {}) if finished else {}
        if not funnel:
            print("\nقیف سیگنال: در این ژورنال ثبت نشده (اجرای قدیمی).")
        else:
            received = max(1, int(funnel.get("received", 0)))
            executed = int(funnel.get("executed", 0))
            print("\nقیف سیگنال (آخرین اجرا):")
            for stage in (
                "received",
                "prefiltered",
                "tier_rejected",
                "d_hard_floor",
                "gate_rejected",
                "level_blocked",
                "capital_rejected",
                "approved",
                "executed",
            ):
                value = int(funnel.get(stage, 0))
                print(f"  {stage:<16}: {value:>6}  ({value / received * 100:5.1f}%)")
            print(f"  نرخ اجرا         : {executed / received * 100:5.1f}% (executed/received)")
    trades = journal.trades()[-10:]
    if trades:
        print("\nآخرین معاملات:")
        for t in trades:
            print(
                f"  {t.open_time[:16]} {t.side:<4} {t.symbol:<8} vol={t.volume:<5} "
                f"net={t.pnl_net:>9.2f} R={t.r_multiple:>6} {t.exit_reason}"
            )
    if getattr(args, "xlsx", None):
        _export_xlsx(journal, Path(args.xlsx))
    journal.close()
    return 0


def _export_xlsx(journal: Any, out: Path) -> None:
    from ..adapters.xlsx import build_signal_workbook, write_workbook, write_xlsx

    try:
        signals = list(journal.signals())
        levels = list(journal.signal_levels())
    except Exception:  # noqa: BLE001 - an older journal simply has no signals
        signals, levels = [], []
    if signals:
        sheets = build_signal_workbook(signals, levels)
        write_workbook(out, sheets)
        print(f"اکسل کامل (سیگنال/قابلیت) ذخیره شد: {out}")
        return
    trades = journal.trades()
    headers = [
        "ردیف", "زمان ورود", "زمان خروج", "استراتژی", "جهت", "ورود", "خروج",
        "حجم", "سود", "زیان", "خالص", "R", "دلیل خروج", "پروفایل",
    ]
    rows = []
    for i, t in enumerate(trades, start=1):
        rows.append(
            [
                i,
                t.open_time.replace("T", " ")[:16],
                (t.close_time or "").replace("T", " ")[:16],
                t.slot,
                t.side,
                t.open_price,
                t.close_price,
                t.volume,
                round(max(t.pnl_net, 0.0), 2),
                round(abs(min(t.pnl_net, 0.0)), 2),
                round(t.pnl_net, 2),
                t.r_multiple,
                t.exit_reason,
                t.risk.get("profile", "") if isinstance(t.risk, dict) else "",
            ]
        )
    write_xlsx(out, headers, rows, sheet="trades")
    print(f"اکسل ذخیره شد: {out}")


def cmd_serve(args: argparse.Namespace) -> int:
    try:
        import uvicorn
    except ImportError:
        print("fastapi/uvicorn نصب نیست. اجرا کن: python -m pip install fastapi uvicorn", file=sys.stderr)
        return 2

    host, port = args.host, args.port
    token = os.environ.get("GOLDBOT_PANEL_TOKEN", "").strip()
    loopback = host in ("127.0.0.1", "localhost", "::1")
    if not loopback and not token:
        # Binding a LAN/Internet interface without a token would expose every
        # trading control to the network; refuse instead of warning.
        print("پنل روی شبکه باز می‌شود اما GOLDBOT_PANEL_TOKEN تنظیم نشده است.", file=sys.stderr)
        print("  توکن را تنظیم کن یا با 127.0.0.1 (پیش‌فرض) اجرا کن.", file=sys.stderr)
        return 2
    if loopback:
        print(f"پنل: http://{host}:{port}")
    else:
        print(f"پنل: http://{_lan_ip()}:{port}")
    print("  احراز هویت: " + ("فعال (Bearer/Basic)" if token else "خاموش (فقط loopback)"))
    uvicorn.run("goldbot.web.app:app", host=host, port=port, log_level="info")
    return 0


def _lan_ip() -> str:
    import socket

    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.connect(("8.8.8.8", 80))
        ip = sock.getsockname()[0]
        sock.close()
        return ip
    except OSError:
        return "127.0.0.1"


def cmd_profiles(args: argparse.Namespace) -> int:
    settings = load_settings(args.config)
    profiles = load_profiles(settings.risk.profiles_path)
    print(f"\nپروفایل‌های موجود در {settings.risk.profiles_path}:")
    for name, p in profiles.items():
        print(
            f"  {name:<8} ریسک/معامله={p.risk_per_trade_pct}%  "
            f"حد ضرر روزانه={p.max_daily_loss_pct}%  "
            f"افت کل={p.max_total_dd_pct}%  "
            f"حداکثر پوزیشن={p.max_positions}  "
            f"اسپرد≤{p.max_spread_points}pt  R:R≥{p.min_rr}"
        )
    print("\nسقف مطلق (هیچ override از آن عبور نمی‌کند):")
    for key, value in ABSOLUTE_MAX.items():
        print(f"  {key:<24} {value}")
    return 0


def cmd_selftest(args: argparse.Namespace) -> int:
    settings = load_settings(args.config)
    tape = Path("var/selftest.jsonl")
    write_synthetic_tape(
        tape,
        symbol=settings.symbol.name,
        start=datetime(2024, 3, 3, tzinfo=timezone.utc),
        days=3,
        ticks_per_minute=2,
        seed=11,
    )
    state_path = state_db_path(Path("var/selftest.db"))
    for suffix in ("", "-wal", "-shm"):
        stale = Path(str(state_path) + suffix)
        if stale.exists():
            stale.unlink()
    components = build_components(
        settings,
        tape_path=tape,
        profile_name="low",
        db_path="var/selftest.db",
        state_db=state_path,
        allow_cold_start=True,
    )
    try:
        result = components.engine.run()
        assert result.ticks > 0, "no ticks processed"
        assert result.bars > 0, "no bars closed"
        assert result.approved >= 0
        assert components.risk.state().value in {"NORMAL", "SOFT_HALT", "HALTED", "KILLED", "QUARANTINE"}
        print(
            f"selftest OK: ticks={result.ticks} bars={result.bars} "
            f"signals={result.signals} approved={result.approved} trades={result.trades_closed}"
        )
        return 0
    finally:
        components.close()


_ACK_LEVELS = {
    "killed": RiskState.KILLED,
    "quarantine": RiskState.QUARANTINE,
    "halted": RiskState.HALTED,
}

_ACK_SEVERITY = {
    RiskState.NORMAL: 0,
    RiskState.SOFT_HALT: 1,
    RiskState.HALTED: 2,
    RiskState.KILLED: 3,
    RiskState.QUARANTINE: 4,
}


def _ack_state_path(args: argparse.Namespace) -> Path:
    return state_db_path(Path("var/goldbot.db"), getattr(args, "state_db", None))


def cmd_ack(args: argparse.Namespace) -> int:
    """Clear a latched risk state by hand; this is the only way out of KILLED."""
    level = _ACK_LEVELS[args.level]
    path = _ack_state_path(args)
    if not path.exists():
        print(f"دیتابیس وضعیت ریسک پیدا نشد: {path}", file=sys.stderr)
        return 2
    store = SqliteRiskStateStore(path)
    try:
        try:
            state = store.load()
        except StateCorruption as exc:
            print(f"وضعیت ریسک خراب است و قابل تأیید نیست: {exc}", file=sys.stderr)
            return 2
        if state is None:
            print(f"وضعیت ذخیره‌شده‌ای وجود ندارد: {path}", file=sys.stderr)
            return 2
        if _ACK_SEVERITY[state.state] > _ACK_SEVERITY[level]:
            print(
                f"نمی‌توان {level.value} را وقتی وضعیت {state.state.value} است تأیید کرد",
                file=sys.stderr,
            )
            return 1
        if not args.confirm:
            print("تأیید تغییر وضعیت ریسک نیاز به --confirm دارد.", file=sys.stderr)
            print(f"  حالت فعلی: {state.state.value}  دلیل: {state.reason or '-'}", file=sys.stderr)
            return 2
        now = datetime.now(tz=timezone.utc)
        store.save(
            replace(
                state,
                state=RiskState.NORMAL,
                reason="",
                auto_clear=False,
                updated_at=now.isoformat(),
            )
        )
    finally:
        store.close()

    journal_path = Path(args.db) if args.db else Path(load_settings(args.config).journal.path)
    journal = SqliteJournal(journal_path)
    try:
        journal.append(
            Event(
                type=Ev.RISK_STATE_CHANGED,
                payload={
                    "from": state.state.value,
                    "to": "NORMAL",
                    "reason": "operator acknowledge",
                    "level": level.value,
                    "actor": "operator",
                    "note": args.note,
                    "db": str(path),
                },
                ts=Ts(now),
                actor="operator",
            )
        )
    finally:
        journal.close()
    print(f"وضعیت ریسک پاک شد: {state.state.value} -> NORMAL  ({path})")
    return 0


def cmd_status(args: argparse.Namespace) -> int:
    """Print the persisted risk state, the thing a restart will adopt."""
    path = _ack_state_path(args)
    if not path.exists():
        print(f"دیتابیس وضعیت ریسک پیدا نشد: {path}", file=sys.stderr)
        return 2
    store = SqliteRiskStateStore(path)
    try:
        try:
            state = store.load()
        except StateCorruption as exc:
            print(f"وضعیت ریسک خراب است: {exc}", file=sys.stderr)
            return 2
    finally:
        store.close()
    if state is None:
        print(f"وضعیت ذخیره‌شده‌ای وجود ندارد: {path}", file=sys.stderr)
        return 2
    if args.json:
        print(json.dumps(state.to_dict(), ensure_ascii=False, indent=2, sort_keys=True))
        return 0
    print(f"وضعیت ریسک        : {state.state.value}")
    print(f"دلیل               : {state.reason or '-'}")
    print(f"روز                : {state.day or '-'}")
    print(f"سود/زیان روزانه    : {state.daily_pnl:.2f}")
    print(f"افت از سقف         : {state.drawdown_pct:.2f}%")
    print(f"سفارش‌های امروز     : {state.orders_today}   باخت پیاپی: {state.consecutive_losses}")
    print(f"پوزیشن‌های ثبت‌شده  : {len(state.ticket_meta)}")
    print(f"آخرین به‌روزرسانی   : {state.updated_at or '-'}")
    pause_until = (state.extras or {}).get("manual_pause_until")
    if pause_until:
        print(f"توقف دستی ورود تا   : {pause_until}  ({(state.extras or {}).get('manual_pause_reason', '')})")
    return 0


def cmd_override(args: argparse.Namespace) -> int:
    """Operator pause/resume of NEW entries; open positions are never touched."""
    path = _ack_state_path(args)
    if not path.exists():
        print(f"دیتابیس وضعیت ریسک پیدا نشد: {path}", file=sys.stderr)
        return 2
    store = SqliteRiskStateStore(path)
    now = datetime.now(tz=timezone.utc)
    try:
        try:
            state = store.load()
        except StateCorruption as exc:
            print(f"وضعیت ریسک خراب است: {exc}", file=sys.stderr)
            return 2
        if state is None:
            print(f"وضعیت ذخیره‌شده‌ای وجود ندارد: {path}", file=sys.stderr)
            return 2
        extras = dict(state.extras or {})
        if not args.confirm:
            current = extras.get("manual_pause_until")
            print("دستور override به --confirm نیاز دارد.", file=sys.stderr)
            print(f"  توقف فعال تا: {current or '-'}", file=sys.stderr)
            return 2
        if getattr(args, "weekend_clear", False):
            extras.pop("weekend_override_until", None)
            action, until = "weekend_clear", None
        elif getattr(args, "weekend_hours", None):
            if int(args.weekend_hours) <= 0:
                print("برای override آخر هفته، --weekend-hours مثبت لازم است.", file=sys.stderr)
                return 2
            until = now + timedelta(hours=int(args.weekend_hours))
            extras["weekend_override_until"] = until.isoformat()
            action = "weekend_override"
        elif args.resume:
            extras.pop("manual_pause_until", None)
            extras.pop("manual_pause_reason", None)
            action, until = "resume", None
        else:
            if not args.pause_minutes or args.pause_minutes <= 0:
                print("برای توقف، --pause-minutes مثبت لازم است (یا --resume).", file=sys.stderr)
                return 2
            until = now + timedelta(minutes=int(args.pause_minutes))
            extras["manual_pause_until"] = until.isoformat()
            extras["manual_pause_reason"] = args.reason
            action = "pause"
        store.save(replace(state, extras=extras, updated_at=now.isoformat()))
    finally:
        store.close()

    journal_path = Path(args.db) if args.db else Path(load_settings(args.config).journal.path)
    journal = SqliteJournal(journal_path)
    try:
        journal.append(
            Event(
                type=Ev.MANUAL_OVERRIDE,
                payload={
                    "action": action,
                    "until": None if until is None else until.isoformat(),
                    "reason": args.reason,
                    "actor": "operator",
                    "db": str(path),
                },
                ts=Ts(now),
                actor="operator",
            )
        )
    finally:
        journal.close()
    if action == "pause":
        print(f"ورود جدید تا {until.isoformat()} متوقف شد؛ پوزیشن‌های باز مدیریت می‌شوند.")
    else:
        print("توقف دستی برداشته شد.")
    return 0


def _state_db_and_journal(args: argparse.Namespace) -> tuple[Path, Path]:
    state_db = _ack_state_path(args)
    journal_path = Path(args.db) if getattr(args, "db", None) else Path(
        load_settings(getattr(args, "config", "config/base.toml")).journal.path
    )
    return state_db, journal_path


def cmd_health(args: argparse.Namespace) -> int:
    """Operator health view: risk latch, heartbeat age and journal readability."""
    state_db, journal_path = _state_db_and_journal(args)
    store = SqliteRiskStateStore(state_db) if state_db.exists() else None
    state = None
    if store is not None:
        try:
            state = store.load()
        except StateCorruption:
            state = None
        finally:
            store.close()
    journal = SqliteJournal(journal_path) if journal_path.exists() else None
    risk = SimpleNamespace(
        state=(lambda: state.state) if state is not None else (lambda: None),
        drawdown_pct=(state.drawdown_pct if state is not None else 0.0),
        orders_today=(state.orders_today if state is not None else 0),
        daily_pnl=(state.daily_pnl if state is not None else 0.0),
    )
    try:
        snap = health_snapshot(
            risk=risk,
            journal=journal,
            heartbeat_path=state_db.parent / "heartbeat.json",
            now=datetime.now(tz=timezone.utc),
        )
    finally:
        if journal is not None:
            journal.close()
    if args.json:
        print(json.dumps(snap.as_dict(), ensure_ascii=False, indent=2, sort_keys=True))
    else:
        print(f"وضعیت ریسک        : {snap.risk_state or '-'}")
        print(f"سلامت کلی          : {'OK' if snap.ok else 'DEGRADED'}")
        print(f"heartbeat          : {snap.heartbeat_age_seconds if snap.heartbeat_age_seconds is not None else 'unknown'}")
        print(f"پوزیشن‌های باز      : {snap.open_positions}")
        print(f"سود/زیان روزانه    : {snap.daily_pnl:.2f}")
        print(f"افت از سقف         : {snap.drawdown_pct:.2f}%")
        print(f"رویدادهای ژورنال   : {snap.journal_events}")
        for key, value in snap.details.items():
            print(f"  {key:<16}: {value}")
    return 0 if snap.ok else 1


def cmd_level(args: argparse.Namespace) -> int:
    """Print the persisted capital-level state and the effective policy."""
    from ..app.capital_levels import LevelState, policy_for, risk_pct_for_level

    state_db, _ = _state_db_and_journal(args)
    if not state_db.exists():
        print(f"دیتابیس وضعیت ریسک پیدا نشد: {state_db}", file=sys.stderr)
        return 2
    store = SqliteRiskStateStore(state_db)
    try:
        state = store.load()
    finally:
        store.close()
    if state is None:
        print(f"وضعیت ذخیره‌شده‌ای وجود ندارد: {state_db}", file=sys.stderr)
        return 2
    extras = dict(state.extras or {})
    payload = extras.get("level_state")
    if not payload:
        print("وضعیت سطح سرمایه ذخیره نشده (levels disabled یا هنوز اجرا نشده).")
        return 0
    level_state = LevelState.from_dict(payload)
    print(f"سطح فعال           : {level_state.active_level.value}")
    print(f"باند BASE          : {level_state.previous_band}")
    print(f"پیشنهاد در انتظار  : {level_state.pending_level.value if level_state.pending_level else '-'}")
    print(f"ددلاین پیشنهاد     : {level_state.pending_since or '-'}")
    print(f"کول‌داون رد        : {level_state.decline_until or '-'}")
    print(f"معاملات سطح        : {level_state.trades_in_level}")
    print(f"روزهای بالای آستانه: {level_state.days_above_threshold}")
    policy = policy_for(level_state.active_level)
    print(f"تیرهای مجاز        : {', '.join(sorted(policy.allowed_tiers))}")
    print(f"حداکثر معامله/روز  : {policy.max_trades_per_day}")
    print(f"حداکثر ریسک باز    : {policy.max_open_risk_pct:.2f}%")
    print(f"آمپلیفایر          : {'on' if policy.amplifier_enabled else 'off'}")
    print(f"ریسک A+ در این سطح : {risk_pct_for_level(level_state.active_level, 'A+', state.day_start_equity or 0.0, base_enabled=True):.2f}%")
    if extras.get("onboarding_ack"):
        print(f"Onboarding         : {extras.get('onboarding_ack')}")
    return 0


def _update_level_state(args: argparse.Namespace, action: str) -> int:
    from ..app.capital_levels import LevelConfig, LevelState, approve_upgrade, decline_upgrade

    state_db = _ack_state_path(args)
    if not state_db.exists():
        print(f"دیتابیس وضعیت ریسک پیدا نشد: {state_db}", file=sys.stderr)
        return 2
    store = SqliteRiskStateStore(state_db)
    now = datetime.now(tz=timezone.utc)
    try:
        try:
            state = store.load()
        except StateCorruption as exc:
            print(f"وضعیت ریسک خراب است: {exc}", file=sys.stderr)
            return 2
        if state is None:
            print(f"وضعیت ذخیره‌شده‌ای وجود ندارد: {state_db}", file=sys.stderr)
            return 2
        extras = dict(state.extras or {})
        payload = extras.get("level_state")
        if not payload:
            print("وضعیت سطح سرمایه ذخیره نشده است.", file=sys.stderr)
            return 2
        level_state = LevelState.from_dict(payload)
        if level_state.pending_level is None:
            print("پیشنهاد ارتقای در انتظار وجود ندارد.", file=sys.stderr)
            return 1
        if not getattr(args, "confirm", False):
            print(
                f"پیشنهاد: {level_state.active_level.value} -> {level_state.pending_level.value}",
                file=sys.stderr,
            )
            print("برای اعمال --confirm لازم است.", file=sys.stderr)
            return 2
        settings = load_settings(args.config)
        cfg = settings.levels
        config = LevelConfig(
            low_risk_threshold=float(cfg.low_risk_threshold),
            medium_risk_threshold=float(cfg.medium_risk_threshold),
            high_risk_threshold=float(cfg.high_risk_threshold),
            approval_timeout_days=int(cfg.approval_timeout_days),
            decline_cooldown_days=int(cfg.decline_cooldown_days),
            min_days_above_threshold=int(cfg.min_days_above_threshold),
            min_trades_in_level=int(cfg.min_trades_in_level),
            base_enabled=bool(cfg.base_enabled),
        )
        previous = level_state.active_level.value
        if action == "approve":
            approve_upgrade(level_state, now)
        else:
            decline_upgrade(level_state, now, config)
        extras["level_state"] = level_state.to_dict()
        store.save(replace(state, extras=extras, updated_at=now.isoformat()))
    finally:
        store.close()

    _, journal_path = _state_db_and_journal(args)
    journal = SqliteJournal(journal_path)
    try:
        journal.append(
            Event(
                type="CapitalLevel",
                payload={
                    "action": action,
                    "from": previous,
                    "active": level_state.active_level.value,
                    "proposed": None,
                    "actor": "operator",
                    "note": getattr(args, "note", ""),
                },
                ts=Ts(now),
                actor="operator",
            )
        )
    finally:
        journal.close()
    print(f"سطح سرمایه: {previous} -> {level_state.active_level.value} ({action})")
    return 0


def cmd_approve(args: argparse.Namespace) -> int:
    return _update_level_state(args, "approve")


def cmd_decline(args: argparse.Namespace) -> int:
    return _update_level_state(args, "decline")


def cmd_onboarding(args: argparse.Namespace) -> int:
    """Record/revoke the operator acknowledgement required before BASE can ever arm."""
    state_db = _ack_state_path(args)
    if not state_db.exists():
        print(f"دیتابیس وضعیت ریسک پیدا نشد: {state_db}", file=sys.stderr)
        return 2
    if not getattr(args, "confirm", False):
        print("Onboarding به --confirm نیاز دارد.", file=sys.stderr)
        return 2
    store = SqliteRiskStateStore(state_db)
    now = datetime.now(tz=timezone.utc)
    try:
        state = store.load()
        if state is None:
            print(f"وضعیت ذخیره‌شده‌ای وجود ندارد: {state_db}", file=sys.stderr)
            return 2
        extras = dict(state.extras or {})
        if getattr(args, "revoke", False):
            extras.pop("onboarding_ack", None)
            extras.pop("onboarding_note", None)
            action = "revoke"
        else:
            extras["onboarding_ack"] = now.isoformat()
            extras["onboarding_note"] = getattr(args, "note", "")
            action = "accept"
        store.save(replace(state, extras=extras, updated_at=now.isoformat()))
    finally:
        store.close()
    print(f"Onboarding {action}: {now.isoformat()}")
    if action == "accept":
        print("هشدار: BASE (۵٪) فقط برای حساب زیر ۲۰۰ دلار، پس از ۳۰ روز دمو، و با فعال‌سازی صریح base_armed معنا دارد.")
    return 0


SIGNALS_DECISIONS = ("executed", "d_hard_floor", "rejected", "skipped", "filtered")


def _parse_iso(text: str) -> datetime:
    try:
        return datetime.fromisoformat(str(text).replace("Z", "+00:00"))
    except ValueError:
        return datetime(1970, 1, 1, tzinfo=timezone.utc)


def _trade_signal_id(trade: Any) -> str:
    signal = trade.signal if isinstance(getattr(trade, "signal", None), dict) else {}
    tags = signal.get("tags") if isinstance(signal.get("tags"), dict) else {}
    return str(tags.get("signal_id") or "")


def cmd_signals(args: argparse.Namespace) -> int:
    """Compare the day's signals with the day's trades; audit journal gaps."""
    from collections import Counter, defaultdict
    from zoneinfo import ZoneInfo

    from ..adapters.sqlite_store import SqliteJournal

    path = Path(args.db)
    if not path.exists():
        print(f"دیتابیس پیدا نشد: {path}", file=sys.stderr)
        return 2
    journal = SqliteJournal(path)
    try:
        signals = list(journal.signals(limit=1_000_000))
        trades = list(journal.trades())
    finally:
        journal.close()
    try:
        tz = ZoneInfo("Asia/Tehran")
    except Exception:  # noqa: BLE001 - Windows Python may ship without tzdata
        # Iran has used a fixed +03:30 offset without DST since 2022.
        tz = timezone(timedelta(hours=3, minutes=30))

    def day_of(text: str) -> str:
        moment = _parse_iso(text)
        if moment.tzinfo is None:
            moment = moment.replace(tzinfo=timezone.utc)
        return moment.astimezone(tz).date().isoformat()

    executed = [s for s in signals if (s.active_decision or "").lower() == "executed"]
    by_decision = Counter((s.active_decision or "?").lower() for s in signals)
    by_reason = Counter((s.active_reason or "").strip() for s in signals)
    signal_ids = {s.signal_id for s in signals}
    trade_signal_ids = {_trade_signal_id(t) for t in trades}
    executed_without_trade = [s for s in executed if s.signal_id not in trade_signal_ids]
    trades_without_signal = [
        t for t in trades if not _trade_signal_id(t) or _trade_signal_id(t) not in signal_ids
    ]
    opened = [t for t in trades]
    closed = [t for t in trades if t.close_time]
    net = sum(t.pnl_net for t in closed)

    per_day: dict[str, dict[str, Any]] = defaultdict(
        lambda: {
            "signals": 0,
            "executed": 0,
            "filtered": 0,
            "rejected": 0,
            "skipped": 0,
            "d_floor": 0,
            "trades": 0,
            "closed": 0,
            "net": 0.0,
        }
    )
    for signal in signals:
        row = per_day[day_of(signal.ts_utc)]
        row["signals"] += 1
        decision = (signal.active_decision or "").lower()
        if decision in ("executed", "d_hard_floor", "rejected", "skipped", "filtered"):
            key = "d_floor" if decision == "d_hard_floor" else decision
            row[key] += 1
    for trade in opened:
        per_day[day_of(trade.open_time)]["trades"] += 1
    for trade in closed:
        row = per_day[day_of(trade.close_time or trade.open_time)]
        row["closed"] += 1
        row["net"] += float(trade.pnl_net)

    print()
    print("=" * 76)
    print("  مقایسه سیگنال‌های ثبت‌شده و معاملات — GoldBot")
    print("=" * 76)
    print(f"  ژورنال: {path}")
    print(f"  سیگنال‌های ثبت‌شده (همه ورودی‌ها): {len(signals)}")
    for decision in SIGNALS_DECISIONS:
        print(f"    {decision:<14}: {by_decision.get(decision, 0)}")
    if by_decision.get("?"):
        print(f"    {'?':<14}: {by_decision['?']}")
    if executed:
        print(f"  سیگنال اجراشده     : {len(executed)}")
    top_reasons = [(reason, count) for reason, count in by_reason.most_common(8) if reason]
    if top_reasons:
        print("  پرتکرارترین دلایل  : " + ", ".join(f"{reason}={count}" for reason, count in top_reasons))
    print(f"  معاملات باز/بسته    : {len(opened)} / {len(closed)}   خالص بسته‌شده: {net:,.2f} USD")
    print("-" * 76)
    print("  بازرسی ژورنال (هیچ سیگنالی نباید بی‌ردیف باشد):")
    status = "PASS" if not executed_without_trade and not trades_without_signal else "FAIL"
    print(f"    سیگنال اجراشده بدون ردیف معامله : {len(executed_without_trade)}")
    print(f"    معامله بدون سیگنال متناظر       : {len(trades_without_signal)}")
    events = []
    try:
        journal = SqliteJournal(path)
        events = [event for event in journal.read_events(limit=50_000) if event.type == "SessionFinished"]
        journal.close()
    except Exception:  # noqa: BLE001 - an old journal may not have events
        events = []
    if events:
        payload = dict(events[-1].payload)
        seen = payload.get("signals_seen")
        journaled = payload.get("signals_journaled")
        unlogged = payload.get("signals_unlogged")
        if seen is not None:
            print(
                f"    آخرین نشست: seen={seen} journaled={journaled} unlogged={unlogged}"
                + ("  (PASS)" if not unlogged else "  (FAIL)")
            )
            if unlogged:
                status = "FAIL"
    print(f"    نتیجه: {status}")
    print("-" * 76)
    print("  تفکیک روزانه (به وقت تهران):")
    print(f"  {'روز':<12}{'سیگنال':>7}{'اجرا':>6}{'فیلتر':>7}{'رد':>5}{'skip':>6}{'D':>5}{'معامله':>8}{'خالص':>10}")
    for day in sorted(per_day):
        row = per_day[day]
        print(
            f"  {day:<12}{row['signals']:>7}{row['executed']:>6}{row['filtered']:>7}"
            f"{row['rejected']:>5}{row['skipped']:>6}{row['d_floor']:>5}{row['trades']:>8}{row['net']:>10.2f}"
        )
    if executed:
        print("-" * 76)
        print("  آخرین سیگنال‌های اجراشده و نتیجه معامله:")
        trade_by_signal = { _trade_signal_id(t): t for t in trades if _trade_signal_id(t) }
        for signal in executed[-12:]:
            trade = trade_by_signal.get(signal.signal_id)
            result = "—" if trade is None else (
                f"net={trade.pnl_net:,.2f} R={trade.r_multiple}"
                if trade.close_time
                else "باز"
            )
            lot = "—" if signal.active_lot is None else f"{signal.active_lot:.2f}"
            print(
                f"    {_parse_iso(signal.ts_utc).astimezone(tz):%m-%d %H:%M} {signal.side:<4} "
                f"{signal.strategy:<10} tier={signal.tier or '?':<3} lot={lot:<5} {result}"
            )
    print("=" * 76)
    if args.json:
        print(json.dumps({"decisions": dict(by_decision), "reasons": dict(by_reason)}, ensure_ascii=False))
    return 0


def cmd_live(args: argparse.Namespace) -> int:
    from .live import run_live

    settings = load_settings(args.config)
    login_raw = args.login if args.login is not None else os.environ.get("GOLDBOT_MT5_LOGIN", "")
    try:
        login = int(str(login_raw).strip() or 0)
    except ValueError:
        login = 0
    if args.password:
        # SEC-02: an argv password is visible in the process list and Task
        # Scheduler history. Environment or a secret file only.
        print(
            "رمز عبور نباید در آرگومان خط فرمان باشد. "
            "از GOLDBOT_MT5_PASSWORD یا GOLDBOT_MT5_PASSWORD_FILE استفاده کنید.",
            file=sys.stderr,
        )
        return 2
    password = os.environ.get("GOLDBOT_MT5_PASSWORD", "")
    if not password:
        password_file = os.environ.get("GOLDBOT_MT5_PASSWORD_FILE", "").strip()
        if password_file:
            try:
                password = Path(password_file).read_text(encoding="utf-8").strip()
            except OSError as exc:
                print(f"خواندن فایل رمز ناموفق بود: {exc}", file=sys.stderr)
                return 2
    server = (args.server or os.environ.get("GOLDBOT_MT5_SERVER", "")).strip()
    mt5_path = (args.mt5_path or os.environ.get("GOLDBOT_MT5_PATH", "")).strip()
    broker_symbol = (args.broker_symbol or os.environ.get("GOLDBOT_MT5_SYMBOL", "")).strip()
    missing = [
        name
        for name, value in (("login", login), ("password", password), ("server", server))
        if not value
    ]
    if missing:
        print("برای اتصال زنده این مقادیر لازم‌اند: " + ", ".join(missing), file=sys.stderr)
        print(
            "مثال: $env:GOLDBOT_MT5_PASSWORD='...'; "
            "python run_goldbot.py live --login <MT5_LOGIN> --server ePlanet-MT5 "
            "--broker-symbol XAUUSD.st --cold-start",
            file=sys.stderr,
        )
        return 2
    overrides = _parse_overrides(args.set)
    return run_live(
        settings,
        login=login,
        password=password,
        server=server,
        mt5_path=mt5_path,
        profile_name=args.profile,
        db_path=args.db or "var/live.db",
        state_db=args.state_db,
        cold_start=bool(args.cold_start),
        allow_real=bool(args.allow_real),
        dry_run=bool(args.dry_run),
        wait_open_seconds=float(args.wait_open_seconds),
        broker_symbol=broker_symbol or None,
        extra_overrides=overrides,
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="goldbot",
        description="XAUUSD modular trading bot",
        epilog="بدون آرگومان، راهنمای سریع نمایش داده می‌شود.",
    )
    sub = parser.add_subparsers(dest="command")

    def common(p: argparse.ArgumentParser) -> None:
        p.add_argument("--config", default="config/base.toml")
        p.add_argument("--profile", default=None, choices=["low", "medium", "high"])
        p.add_argument("--db", default=None)
        p.add_argument(
            "--state-db",
            default=None,
            help="path to the durable risk state db (default: GOLDBOT_STATE_DB or sibling of --db)",
        )
        p.add_argument("--keep", action="store_true", help="keep the existing journal instead of starting fresh")
        p.add_argument("--balance", type=float, default=None, help="override the starting balance, e.g. 100")
        p.add_argument("--verbose", action="store_true")
        p.add_argument("--set", action="append", default=[], help="manual risk override, e.g. --set risk_per_trade_pct=0.4")

    demo = sub.add_parser("demo", help="generate a synthetic tape and run it")
    common(demo)
    demo.add_argument("--days", type=int, default=20)
    demo.add_argument("--seed", type=int, default=7)
    demo.add_argument("--start-price", type=float, default=4000.0)
    demo.add_argument("--ticks-per-minute", type=int, default=2)
    demo.add_argument("--tape", default=None)
    demo.add_argument("--regenerate", action="store_true")
    demo.add_argument("--dump-events", type=int, default=0)

    bt = sub.add_parser("backtest", help="run a recorded tape")
    common(bt)
    bt.add_argument("--tape", required=True)
    bt.add_argument("--dump-events", type=int, default=0)

    tapes = sub.add_parser("tapes", help="write the deterministic parity scenario tapes")
    tapes.add_argument(
        "--scenario",
        default=None,
        choices=SCENARIO_NAMES,
        help="one scenario (default: all six)",
    )
    tapes.add_argument("--out", default="var/tapes", help="output directory")
    tapes.add_argument("--overwrite", action="store_true", help="replace existing tapes")

    rep = sub.add_parser("report", help="inspect a journal")
    rep.add_argument("--db", default="var/goldbot.db")
    rep.add_argument("--xlsx", default=None, help="also export the journal to an .xlsx file")
    rep.add_argument("--funnel", action="store_true", help="show the per-stage signal funnel")

    live = sub.add_parser("live", help="run against a MetaTrader 5 account (demo by default)")
    common(live)
    live.add_argument("--login", type=int, default=None, help="MT5 account number")
    live.add_argument("--password", default=None, help="prefer GOLDBOT_MT5_PASSWORD over argv")
    live.add_argument("--server", default=None, help="MT5 server name, e.g. ePlanet-MT5")
    live.add_argument("--mt5-path", default=None, help="terminal64.exe path (or GOLDBOT_MT5_PATH)")
    live.add_argument("--broker-symbol", default=None, help="broker symbol, e.g. XAUUSD.st")
    live.add_argument(
        "--cold-start",
        action="store_true",
        help="first live run: explicitly acknowledge the empty risk-state store",
    )
    live.add_argument(
        "--allow-real",
        action="store_true",
        help="allow a non-demo account (real money; dangerous)",
    )
    live.add_argument(
        "--wait-open-seconds",
        type=int,
        default=900,
        help="wait up to N seconds for a fresh market tick before building (0 = no wait)",
    )
    live.add_argument(
        "--dry-run",
        action="store_true",
        help="read-only session: journal every signal but never send an order",
    )

    sig = sub.add_parser("signals", help="compare journaled signals with real trades")
    sig.add_argument("--db", default="var/live.db")
    sig.add_argument("--json", action="store_true", help="also print decision counters as JSON")

    health = sub.add_parser("health", help="operator health view (state, heartbeat, journal)")
    health.add_argument("--state-db", default=None)
    health.add_argument("--db", default=None)
    health.add_argument("--config", default="config/base.toml")
    health.add_argument("--json", action="store_true")

    level = sub.add_parser("level", help="print the persisted capital-level state")
    level.add_argument("--state-db", default=None)
    level.add_argument("--db", default=None)
    level.add_argument("--config", default="config/base.toml")

    approve = sub.add_parser("approve", help="approve a pending capital-level upgrade")
    approve.add_argument("--state-db", default=None)
    approve.add_argument("--db", default=None)
    approve.add_argument("--config", default="config/base.toml")
    approve.add_argument("--note", default="")
    approve.add_argument("--confirm", action="store_true")

    decline = sub.add_parser("decline", help="decline a pending capital-level upgrade")
    decline.add_argument("--state-db", default=None)
    decline.add_argument("--db", default=None)
    decline.add_argument("--config", default="config/base.toml")
    decline.add_argument("--note", default="")
    decline.add_argument("--confirm", action="store_true")

    onboard = sub.add_parser("onboarding", help="record the operator acknowledgement (BASE warning)")
    onboard.add_argument("--state-db", default=None)
    onboard.add_argument("--db", default=None)
    onboard.add_argument("--config", default="config/base.toml")
    onboard.add_argument("--accept", action="store_true")
    onboard.add_argument("--revoke", action="store_true")
    onboard.add_argument("--note", default="")
    onboard.add_argument("--confirm", action="store_true")

    prof = sub.add_parser("profiles", help="list risk profiles")
    prof.add_argument("--config", default="config/base.toml")

    srv = sub.add_parser(
        "serve",
        help="run the web panel (set GOLDBOT_PANEL_TOKEN before exposing it)",
    )
    srv.add_argument(
        "--host",
        default="127.0.0.1",
        help="127.0.0.1 (local) or 0.0.0.0 (LAN); non-loopback needs GOLDBOT_PANEL_TOKEN",
    )
    srv.add_argument("--port", type=int, default=8000)

    st = sub.add_parser("selftest", help="3-day smoke test")
    st.add_argument("--config", default="config/base.toml")

    ack = sub.add_parser("ack", help="acknowledge a latched risk state (KILLED/QUARANTINE/HALTED)")
    ack.add_argument("--level", required=True, choices=sorted(_ACK_LEVELS), help="state being acknowledged")
    ack.add_argument("--note", default="", help="operator note stored in the journal")
    ack.add_argument(
        "--state-db",
        default=None,
        help="path to the risk state db (default: GOLDBOT_STATE_DB or var/risk_state.db)",
    )
    ack.add_argument("--db", default=None, help="journal path for the audit event")
    ack.add_argument("--config", default="config/base.toml")
    ack.add_argument("--confirm", action="store_true", help="required: apply the change")

    ovr = sub.add_parser("override", help="operator pause/resume of new entries")
    ovr.add_argument("--pause-minutes", type=int, default=None, help="pause new entries for N minutes")
    ovr.add_argument("--resume", action="store_true", help="clear an active pause")
    ovr.add_argument("--weekend-hours", type=int, default=None, help="allow open positions through the weekend for N hours (explicit override)")
    ovr.add_argument("--weekend-clear", action="store_true", help="clear a weekend override")
    ovr.add_argument("--reason", default="", help="operator reason stored in the journal")
    ovr.add_argument(
        "--state-db",
        default=None,
        help="path to the risk state db (default: GOLDBOT_STATE_DB or var/risk_state.db)",
    )
    ovr.add_argument("--db", default=None, help="journal path for the audit event")
    ovr.add_argument("--config", default="config/base.toml")
    ovr.add_argument("--confirm", action="store_true", help="required: apply the change")

    status = sub.add_parser("status", help="print the persisted risk state")
    status.add_argument(
        "--state-db",
        default=None,
        help="path to the risk state db (default: GOLDBOT_STATE_DB or var/risk_state.db)",
    )
    status.add_argument("--json", action="store_true", help="print the raw record as JSON")

    return parser


def cmd_tapes(args: argparse.Namespace) -> int:
    """Materialise the six parity tapes: gap, spread, requote, disconnect, stops, partial."""
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    names = [args.scenario] if args.scenario else list(SCENARIO_NAMES)
    for name in names:
        target = out / f"{name}.jsonl"
        if target.exists() and not args.overwrite:
            print(f"skip (exists): {target}")
            continue
        count = write_scenario_tape(name, target, metadata=True)
        meta = target.with_suffix(".meta.json")
        print(f"{name:18s} ticks={count:4d}  {target}  meta={meta.exists()}")
    return 0


QUICKSTART = """
GoldBot — راهنمای سریع
============================================================

۱) اجرای یک دموی کامل (ساخت داده + بک‌تست + گزارش):

     python run_goldbot.py demo --days 10 --profile low

۲) مقایسه‌ی سه سطح ریسک:

     python run_goldbot.py demo --days 10 --profile low
     python run_goldbot.py demo --days 10 --profile medium
     python run_goldbot.py demo --days 10 --profile high

۳) تنظیم دستی ریسک (مقدار صریح، با اعتبارسنجی):

     python run_goldbot.py demo --days 10 --set risk_per_trade_pct=0.35 --set max_positions=1

۴) دیدن پروفایل‌ها و سقف‌های مجاز:

     python run_goldbot.py profiles

۵) خواندن ژورنال آخرین اجرا (پیش‌فرض: var/goldbot.db):

     python run_goldbot.py report

۶) تست دودی ۳ روزه و اجرای مجموعه تست:

     python run_goldbot.py selftest
     python -m pytest

۷) اتصال زنده به متاتریدر ۵ (حساب دمو، ژورنال کامل سیگنال‌ها):

     $env:GOLDBOT_MT5_PASSWORD='...'
     python run_goldbot.py live --login <MT5_LOGIN> --server ePlanet-MT5 --broker-symbol XAUUSD.st --cold-start --db var/live.db     python run_goldbot.py signals --db var/live.db     # مقایسه سیگنال‌های روز با معاملات

۸) پنل وب محلی (ناحیه‌های دستی، سوییچ استراتژی‌ها، ریسک، ژورنال و اکسل):

     python run_goldbot.py serve
     # سپس در مرورگر: http://127.0.0.1:8000

گزینه‌های مشترک:  --profile low|medium|high   --db مسیر دیتابیس   --set key=value   --verbose
نتیجه‌ها در پوشه‌ی var/ ذخیره می‌شوند (tape و دیتابیس).
"""


def main(argv: Sequence[str] | None = None) -> int:
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            try:
                stream.reconfigure(encoding="utf-8")  # type: ignore[union-attr]
            except Exception:  # noqa: BLE001 - best effort on legacy consoles
                pass
    parser = build_parser()
    args = parser.parse_args(argv)
    setup_logging("INFO" if getattr(args, "verbose", False) else "WARNING", json_logs=False)
    if not args.command:
        print(QUICKSTART)
        return 0
    try:
        handlers = {
            "demo": cmd_demo,
            "backtest": cmd_backtest,
            "report": cmd_report,
            "profiles": cmd_profiles,
            "selftest": cmd_selftest,
            "serve": cmd_serve,
            "ack": cmd_ack,
            "status": cmd_status,
            "tapes": cmd_tapes,
            "override": cmd_override,
            "health": cmd_health,
            "live": cmd_live,
            "signals": cmd_signals,
            "level": cmd_level,
            "approve": cmd_approve,
            "decline": cmd_decline,
            "onboarding": cmd_onboarding,
        }
        return handlers[args.command](args)
    except GoldbotError as exc:
        print(f"خطا [{exc.error_id}]: {exc.message}", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("\nمتوقف شد", file=sys.stderr)
        return 130
