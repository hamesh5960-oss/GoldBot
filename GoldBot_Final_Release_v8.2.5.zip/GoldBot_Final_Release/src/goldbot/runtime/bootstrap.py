"""Composition root: the only place where concrete adapters are wired together."""

from __future__ import annotations

import os
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Sequence

from ..adapters.clock import SimulatedClock
from ..adapters.config import Settings, canonical_config_hash
from ..adapters.fake_broker import FakeBroker
from ..adapters.news_calendar import load_calendar
from ..adapters.notifier import from_env as build_notifier
from ..adapters.sqlite_state_store import SqliteRiskStateStore
from ..adapters.sqlite_store import SqliteJournal
from ..adapters.tape import TapeFeed
from ..adapters.zones import ZoneStore
from ..app.bar_builder import BarBuilder
from ..app.costs import CostParams
from ..app.engine import TradingEngine
from ..app.gates import CooldownManager, GateParams
from ..app.heartbeat import Heartbeat, heartbeat_path_for
from ..app.level_gate import from_settings as build_level_gate
from ..app.news import NewsParams, NewsWindow
from ..app.order_budget import BudgetParams
from ..app.order_coordinator import OrderCoordinator
from ..app.position_manager import PositionManager
from ..app.reconciler import Reconciler
from ..app.risk import AppliedOverride, RiskProfile, load_profiles, resolve_profile
from ..app.risk.capital import CapitalParams
from ..app.risk_engine import RiskEngine
from ..app.signal_pipeline import SignalPipeline
from ..app.spec_guard import validate_specs
from ..app.weekend import WeekendParams
from ..app.zones_engine import ZoneEngine
from ..app.strategy_host import StrategyHost
from ..domain.errors import ConfigError
from ..domain.events import Ev, Event
from ..domain.model import Symbol
from ..domain.symbol_meta import SymbolMeta
from ..log import get_logger
from ..ports.state import STATE_RESTORE_FAILED_EVENT, STATE_RESTORED_EVENT
from ..strategy_api.context import AccountView
from ..strategy_api.signals import Signal
from strategies.registry import StrategyInstance, load_instances

log = get_logger("bootstrap")


@dataclass
class Components:
    settings: Settings
    profile: RiskProfile
    overrides: list[AppliedOverride]
    info: Any
    journal: SqliteJournal
    broker: FakeBroker
    positions: PositionManager
    risk: RiskEngine
    coordinator: OrderCoordinator
    host: StrategyHost
    builder: BarBuilder
    clock: SimulatedClock
    pipeline: SignalPipeline
    reconciler: Reconciler
    engine: TradingEngine
    instances: Sequence[StrategyInstance]
    state_store: SqliteRiskStateStore | None = None
    notifier: Any = None
    heartbeat: Heartbeat | None = None
    weekend_params: Any = None
    news_window: Any = None
    level_gate: Any = None

    def close(self) -> None:
        if self.state_store is not None:
            self.state_store.close()
        self.journal.close()


def build_components(
    settings: Settings,
    *,
    tape_path: str | Path,
    profile_name: str | None = None,
    extra_overrides: dict[str, Any] | None = None,
    instances: Sequence[StrategyInstance] | None = None,
    start: datetime | None = None,
    db_path: str | Path | None = None,
    initial_balance: float | None = None,
    state_db: str | Path | None = None,
    allow_cold_start: bool | None = None,
    # Live composition (MT5): injected instead of the synthetic tape + broker.
    live_broker: Any = None,
    live_feed: Any = None,
    live_clock: Any = None,
    seed_history: Callable[[Any], None] | None = None,
    info_override: Any = None,
) -> Components:
    info = info_override or settings.symbol_info()
    SymbolMeta.from_symbol_info(info).validate()
    symbol = Symbol(settings.symbol.name)

    profiles = load_profiles(settings.risk.profiles_path)
    overrides_in = dict(settings.risk.overrides)
    if extra_overrides:
        overrides_in.update(extra_overrides)
    chosen = profile_name or settings.risk.profile
    profile, applied = resolve_profile(chosen, profiles, overrides_in)

    journal_path = db_path or settings.journal.path
    journal = SqliteJournal(journal_path)

    if live_clock is not None:
        clock = live_clock
    else:
        clock = SimulatedClock(start or datetime(2024, 1, 1, tzinfo=timezone.utc))
        clock.bind(info)

    # One fingerprint for every journaled artefact of this run: a backtest is
    # reproducible only if we know exactly which configuration produced it.
    config_hash = canonical_config_hash(settings)
    notifier = build_notifier()
    heartbeat = Heartbeat(heartbeat_path_for(journal_path), clock, journal=journal)
    journal.append(
        Event(
            type=Ev.CONFIG_LOADED,
            payload={
                "config_hash": config_hash,
                "profile": profile.name,
                "levels_enabled": bool(settings.levels.enabled),
                "news_enabled": bool(settings.news.enabled),
                "weekend_enabled": bool(settings.weekend.enabled),
            },
            ts=clock.now(),
            actor="bootstrap",
        )
    )

    if live_broker is not None:
        broker = live_broker
    else:
        broker = FakeBroker(
            info,
            balance=settings.account.initial_balance if initial_balance is None else initial_balance,
            leverage=settings.account.leverage,
            trade_mode=settings.account.trade_mode,
            commission_per_lot=settings.execution.commission_per_lot,
            slippage_points=settings.execution.slippage_points,
        )
    report = validate_specs(
        info,
        broker.account(),
        expected_currency=settings.account.currency,
        allow_netting=settings.account.allow_netting,
    )
    if not report.ok:
        issues = ", ".join(f"{i.code}: {i.detail}" for i in report.fatal)
        raise ConfigError(f"broker/symbol spec validation failed: {issues}")
    for issue in report.warnings:
        log.warning("broker spec warning", extra={"fields": {"issue": issue.code, "detail": issue.detail}})

    weekend_params = (
        WeekendParams(
            enabled=True,
            close_minutes_before_session_end=settings.weekend.close_minutes_before_session_end,
            max_deviation_points=settings.weekend.max_deviation_points,
            close_order=settings.weekend.close_order,
            fallback_grace_minutes=settings.weekend.fallback_grace_minutes,
        )
        if settings.weekend.enabled
        else None
    )
    news_params = NewsParams(
        enabled=settings.news.enabled,
        high_before_minutes=settings.news.high_impact_before_minutes,
        high_after_minutes=settings.news.high_impact_after_minutes,
        medium_before_minutes=settings.news.medium_impact_before_minutes,
        medium_after_minutes=settings.news.medium_impact_after_minutes,
        fail_safe=settings.news.fail_safe,
    )
    news_events: list[Any] = []
    news_available = False
    if settings.news.enabled and settings.news.calendar_source == "csv":
        news_events, news_available = load_calendar(
            settings.news.calendar_path, params=news_params
        )
    else:
        news_available = False
    news_window = (
        NewsWindow(news_events, news_params, calendar_available=news_available)
        if settings.news.enabled
        else None
    )
    if settings.news.enabled and not news_available:
        log.warning(
            "news calendar unavailable; conservative fallback windows are active",
            extra={"fields": {"path": settings.news.calendar_path}},
        )
    level_gate = build_level_gate(settings, base_armed=settings.levels.base_armed)

    positions = PositionManager(mode=settings.account.trade_mode, contract_size=info.contract_size)

    capital = CapitalParams(
        risk_floor_pct=settings.capital.risk_floor_pct,
        risk_ceiling_pct=settings.capital.risk_ceiling_pct,
        portfolio_ceiling_pct=settings.capital.portfolio_ceiling_pct,
        gate_d_max_risk_pct=settings.capital.gate_d_max_risk_pct,
        gate_d_hard_pct=settings.capital.gate_d_hard_pct,
        trade_risk_cap_pct=settings.capital.trade_risk_cap_pct,
    )
    state_path = state_db_path(journal_path, state_db)
    state_store = SqliteRiskStateStore(state_path)
    risk = RiskEngine(
        profile,
        journal=journal,
        clock=clock,
        magic_base=settings.execution.magic_base,
        capital=capital,
        commission_per_lot=settings.execution.commission_per_lot,
        budget=BudgetParams(**settings.budget.model_dump()),
        costs=CostParams(**settings.costs.model_dump()),
        config_hash=config_hash,
        notifier=notifier,
        state_store=state_store,
        allow_cold_start=resolve_allow_cold_start(
            allow_cold_start,
            live_composition=(
                live_broker is not None or live_feed is not None or live_clock is not None
            ),
        ),
    )
    _journal_restore(journal, clock, state_path, risk)

    coordinator = OrderCoordinator(
        broker=broker,
        journal=journal,
        clock=clock,
        positions=positions,
        secret=risk.secret(),
        run_id=uuid.uuid4().hex[:8],
        magic_base=settings.execution.magic_base,
    )

    active = list(instances) if instances is not None else load_instances(settings.strategies.directory)
    timeframes = sorted({inst.timeframe for inst in active}) or ["M15"]
    builder = BarBuilder(symbol, timeframes, history=settings.trading.history_bars)  # type: ignore[arg-type]
    if seed_history is not None:
        seed_history(builder)

    zones = ZoneStore(settings.zones.path, fallback_latest=settings.zones.fallback_to_latest)
    zone_engine = ZoneEngine(
        zones_fn=lambda moment: zones.for_datetime(moment),
        history_fn=lambda: builder.bars("M15", 10_000),
        broker_offset=info.broker_offset,
    )
    host = StrategyHost(
        journal,
        clock,
        lambda moment: zone_engine.snapshot(builder.bars("M15", 900), now=moment),
    )

    def account_view() -> AccountView:
        account = broker.account()
        return AccountView(
            equity=float(account.equity.amount),
            balance=float(account.balance.amount),
            free_margin=float(account.free_margin.amount),
            open_positions=positions.count(),
        )

    for inst in active:
        strategy = inst.build()
        host.register(
            slot=inst.slot,
            strategy=strategy,
            symbol=symbol,
            info=info,
            builder=builder,
            positions_fn=positions.view,
            account_fn=account_view,
            now_fn=clock.now,
            tick_fn=lambda: builder.last_tick,
            risk_multiplier=inst.risk_multiplier,
            timeframes=(inst.timeframe,),  # type: ignore[arg-type]
            confirm_only=inst.confirm_only,
        )

    pipeline = SignalPipeline(magic_base=settings.execution.magic_base)
    reconciler = Reconciler(positions=positions, broker=broker, journal=journal, clock=clock)
    feed = live_feed if live_feed is not None else TapeFeed(tape_path, symbol, info)

    engine = TradingEngine(
        broker=broker,
        feed=feed,
        clock=clock,
        journal=journal,
        builder=builder,
        host=host,
        pipeline=pipeline,
        risk=risk,
        coordinator=coordinator,
        positions=positions,
        reconciler=reconciler,
        symbol=symbol,
        info=info,
        profile=profile,
        sample_every=120,
        direction=settings.trading.direction,
        confluence_window_minutes=settings.trading.confluence_window_minutes,
        gates=CooldownManager(GateParams(**settings.gates.model_dump())),
        zone_engine=zone_engine,
        zone_confirmation_min_score=settings.trading.zone_confirmation_min_score,
        zone_confirmation_max_atr=settings.trading.zone_confirmation_max_atr,
        history_bars=settings.trading.history_bars,
        notifier=notifier,
        heartbeat=heartbeat,
        config_hash=config_hash,
        weekend=weekend_params,
        news=news_window,
        level_gate=level_gate,
        profile_name=profile.name,
        session_offset_hours=0.0,
        commission_per_lot=settings.execution.commission_per_lot,
        slippage_points=settings.execution.slippage_points,
        zone_filter_min=settings.trading.zone_filter_min,
        layer3_enabled=settings.trading.layer3_enabled,
        friday_flat_hour_utc=(
            settings.session.friday_flat_hour_utc
            if settings.session.close_all_before_weekend
            else None
        ),
    )

    return Components(
        settings=settings,
        profile=profile,
        overrides=applied,
        info=info,
        journal=journal,
        broker=broker,
        positions=positions,
        risk=risk,
        coordinator=coordinator,
        host=host,
        builder=builder,
        clock=clock,
        pipeline=pipeline,
        reconciler=reconciler,
        engine=engine,
        instances=active,
        state_store=state_store,
        notifier=notifier,
        heartbeat=heartbeat,
        weekend_params=weekend_params,
        news_window=news_window,
        level_gate=level_gate,
    )


LIVE_MODES = frozenset({"live", "paper", "prod", "production"})
SYNTHETIC_MODES = frozenset({"synthetic", "backtest", "demo", "test", "dev"})
DEFAULT_MODE = "synthetic"


def resolve_allow_cold_start(
    explicit: bool | None = None,
    *,
    mode: str | None = None,
    live_composition: bool = False,
) -> bool:
    """Cold start is only for replay/synthetic runs; live and paper quarantine.

    A live composition root (MT5 broker/feed/clock injected) must pass an
    explicit True to allow a cold start; an omitted flag is fail-closed there
    even if GOLDBOT_MODE is unset. Synthetic builds keep the historical
    default of allowing a fresh start.
    """
    if explicit is not None:
        return bool(explicit)
    if live_composition:
        return False
    chosen = (mode or os.environ.get("GOLDBOT_MODE", DEFAULT_MODE)).strip().lower()
    return chosen in SYNTHETIC_MODES


def state_db_path(journal_path: str | Path, explicit: str | Path | None = None) -> Path:
    """GOLDBOT_STATE_DB > explicit argument > sibling of the journal database.

    ADR-016 item 8 pins the store via the environment first so one operator
    setting cannot be silently overridden by a stale command-line flag.
    """
    env = os.environ.get("GOLDBOT_STATE_DB", "").strip()
    if env:
        return Path(env)
    if explicit is not None:
        return Path(explicit)
    journal = Path(journal_path)
    # The canonical journal keeps the documented var/risk_state.db name; any
    # other run journal gets its own sibling so two synthetic runs in the same
    # directory cannot inherit each other's latches (deterministic replay).
    name = "risk_state.db" if journal.name == "goldbot.db" else f"{journal.stem}_risk_state.db"
    return journal.parent / name


def _journal_restore(
    journal: SqliteJournal, clock: Any, path: Path, risk: RiskEngine
) -> None:
    """Audit what the restart actually adopted (or why it refused to trust it)."""
    snapshot = risk.persistable_state()
    payload: dict[str, Any] = {
        "state": snapshot.state.value,
        "reason": snapshot.reason,
        "day": snapshot.day,
        "orders_today": snapshot.orders_today,
        "consecutive_losses": snapshot.consecutive_losses,
        "ticket_meta": len(snapshot.ticket_meta),
        "restored": risk.restarted,
        "db": str(path),
    }
    if risk.restore_error:
        payload["error"] = risk.restore_error
        journal.append(
            Event(type=STATE_RESTORE_FAILED_EVENT, payload=payload, ts=clock.now(), actor="system")
        )
        log.error(
            "persisted risk state unreadable; quarantined",
            extra={"fields": {"db": str(path), "error": risk.restore_error}},
        )
        return
    journal.append(
        Event(type=STATE_RESTORED_EVENT, payload=payload, ts=clock.now(), actor="system")
    )

