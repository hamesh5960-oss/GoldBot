"""State shared by the local web panel (persisted next to the journal)."""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class UiState:
    profile: str = "medium"
    direction: str = "both"
    overrides: dict[str, Any] = field(default_factory=dict)
    disabled_slots: list[str] = field(default_factory=list)
    last_run: dict[str, Any] | None = None

    @classmethod
    def load(cls, path: str | Path) -> "UiState":
        file = Path(path)
        if not file.exists():
            return cls()
        try:
            data = json.loads(file.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return cls()
        return cls(
            profile=str(data.get("profile", "medium")),
            direction=str(data.get("direction", "both")),
            overrides=dict(data.get("overrides", {})),
            disabled_slots=list(data.get("disabled_slots", [])),
            last_run=data.get("last_run"),
        )

    def effective_config(self) -> dict[str, Any]:
        """Only the settings the panel really controls.

        Retired keys (min_confirmations, weak_confluence_mode, dynamic_tier_margin)
        must never reappear here; the RC 8.2.5 confirmation model is fixed in
        config/base.toml and validated by the risk/decision layers.
        """
        return {
            "profile": self.profile,
            "direction": self.direction,
            "overrides": dict(self.overrides),
            "disabled_slots": list(self.disabled_slots),
        }

    def save(self, path: str | Path) -> None:
        file = Path(path)
        file.parent.mkdir(parents=True, exist_ok=True)
        file.write_text(json.dumps(asdict(self), indent=2, ensure_ascii=False), encoding="utf-8")
