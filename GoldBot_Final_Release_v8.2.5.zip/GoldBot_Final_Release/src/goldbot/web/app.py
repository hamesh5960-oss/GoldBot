"""FastAPI panel: zones, strategy switches, risk profile, runs and journal.

Binds to loopback by default. Set GOLDBOT_PANEL_TOKEN to require a bearer token
(or HTTP Basic with any username and that token as the password) on every
route, which is what makes a remote deployment safe. If the variable is unset
the local, single-operator behaviour is unchanged.
"""

from __future__ import annotations

import base64
import hmac
import os
import threading
import uuid
from dataclasses import asdict
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Any

from fastapi import Body, FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, PlainTextResponse
from pydantic import BaseModel, ConfigDict, Field, ValidationError

from ..adapters.config import load_settings
from ..adapters.sqlite_store import SqliteJournal
from ..adapters.tape import write_synthetic_tape
from ..adapters.xlsx import write_xlsx
from ..adapters.zones import MAX_ZONES_PER_DAY, ZoneStore, parse_zones_text
from ..app.heartbeat import heartbeat_path_for
from ..domain.errors import ConfigError
from ..log import get_logger
from ..runtime.bootstrap import build_components
from ..strategy_api.zones import Zone
from ..timeutil import iran_day, iran_now
from strategies.registry import REGISTRY, load_instances
from .state import UiState

log = get_logger("web")

ROOT = Path.cwd()
CONFIG = ROOT / "config" / "base.toml"
STATE_PATH = ROOT / "var" / "panel_state.json"
RUN_DIR = ROOT / "var" / "runs"
LAST_RUN_FILE = ROOT / "var" / "last_run.txt"
LEGACY_DB = ROOT / "var" / "panel_run.db"
ZONE_TEMPLATE = "\n".join(
    [
        "# سقف,کف,مهم,یادداشت",
        "4050.00,4048.00,1,ناحیه مهم",
        "4035.50,4032.00,0,",
        "4020,4015.5,0,",
    ]
)

app = FastAPI(title="GoldBot Panel", docs_url="/api/docs", redoc_url=None)
_run_lock = threading.Lock()

# Optional remote auth. The token never lives in the repo: it is read from the
# environment on every request, so an operator can rotate it in the systemd
# unit without touching code. Unset = local loopback mode, unchanged.
PANEL_TOKEN_ENV = "GOLDBOT_PANEL_TOKEN"


def panel_token() -> str:
    """Configured panel token; empty means authentication is disabled."""
    return os.environ.get(PANEL_TOKEN_ENV, "").strip()


def _authorized(authorization: str | None) -> bool:
    """Accept 'Bearer <token>' or Basic '<any user>:<token>' with timing safety."""
    token = panel_token()
    if not token:
        return True
    if not authorization:
        return False
    scheme, _, credentials = authorization.partition(" ")
    scheme = scheme.strip().lower()
    credentials = credentials.strip()
    if not credentials:
        return False
    if scheme == "bearer":
        return hmac.compare_digest(credentials.encode("utf-8"), token.encode("utf-8"))
    if scheme == "basic":
        try:
            decoded = base64.b64decode(credentials, validate=True).decode("utf-8")
        except (ValueError, UnicodeDecodeError):
            return False
        _, separator, password = decoded.partition(":")
        if not separator:
            return False
        return hmac.compare_digest(password.encode("utf-8"), token.encode("utf-8"))
    return False


@app.middleware("http")
async def require_panel_token(request: Request, call_next):
    """Fail closed: when a token is configured, every route requires credentials."""
    if not _authorized(request.headers.get("authorization")):
        return JSONResponse(
            {"detail": "unauthorized"},
            status_code=401,
            headers={"WWW-Authenticate": 'Basic realm="GoldBot Panel"'},
        )
    return await call_next(request)


# --------------------------------------------------------------------- utils
def _settings():
    return load_settings(CONFIG)


def _state() -> UiState:
    return UiState.load(STATE_PATH)


def _zones() -> ZoneStore:
    settings = _settings()
    return ZoneStore(settings.zones.path, fallback_latest=settings.zones.fallback_to_latest)


def _today() -> date:
    return iran_day(iran_now())


def _current_db() -> Path:
    """The journal of the most recent panel run."""
    if LAST_RUN_FILE.exists():
        candidate = Path(LAST_RUN_FILE.read_text(encoding="utf-8").strip())
        if candidate.exists():
            return candidate
    return LEGACY_DB


def _instances(settings, state: UiState):
    instances = load_instances(settings.strategies.directory, include_disabled=True)
    disabled = set(state.disabled_slots)
    return [i for i in instances if i.enabled and i.slot not in disabled]


def _fail(exc: Exception, status: int = 500) -> JSONResponse:
    log.exception("panel request failed")
    return JSONResponse({"detail": f"{type(exc).__name__}: {exc}"}, status_code=status)


class ZoneIn(BaseModel):
    high: float = Field(gt=0)
    low: float = Field(gt=0)
    starred: bool = False
    note: str = ""


class ZonesIn(BaseModel):
    day: str | None = None
    zones: list[ZoneIn]


class ZonesImportIn(BaseModel):
    text: str
    day: str | None = None


# Keys retired in RC 8.2.5. They are rejected on save instead of being silently
# ignored by pydantic: an operator must not believe a removed knob took effect.
RETIRED_CONFIG_KEYS: dict[str, str] = {
    "min_confirmations": "the confirmation model is fixed by the RC 8.2.5 decision tiers",
    "weak_confluence_mode": "retired in RC 8.2.5",
    "dynamic_tier_margin": "retired in RC 8.2.5",
}


class ConfigIn(BaseModel):
    model_config = ConfigDict(extra="forbid")

    profile: str | None = None
    direction: str | None = None
    overrides: dict[str, Any] | None = None
    disabled_slots: list[str] | None = None


# --------------------------------------------------------------------- pages
@app.get("/", response_class=HTMLResponse)
def index() -> str:
    return (Path(__file__).parent / "ui.html").read_text(encoding="utf-8")


@app.get("/api/health")
def api_health() -> Any:
    """Health snapshot for monitoring: risk latch, heartbeat age, journal readability."""
    from types import SimpleNamespace

    from ..adapters.sqlite_state_store import SqliteRiskStateStore
    from ..app.health import snapshot
    from ..runtime.bootstrap import state_db_path

    db = _current_db()
    state_db = state_db_path(db)
    state = None
    if state_db.exists():
        store = SqliteRiskStateStore(state_db)
        try:
            state = store.load()
        except Exception:  # noqa: BLE001 - corrupt state is reported by the snapshot
            state = None
        finally:
            store.close()
    journal = None
    if db.exists():
        try:
            journal = SqliteJournal(db)
        except Exception:  # noqa: BLE001
            journal = None
    risk = SimpleNamespace(
        state=(lambda: state.state) if state is not None else (lambda: None),
        drawdown_pct=(state.drawdown_pct if state is not None else 0.0),
        orders_today=(state.orders_today if state is not None else 0),
        daily_pnl=(state.daily_pnl if state is not None else 0.0),
    )
    try:
        snap = snapshot(
            risk=risk,
            journal=journal,
            heartbeat_path=heartbeat_path_for(db),
            now=datetime.now(tz=timezone.utc),
        )
    finally:
        if journal is not None:
            journal.close()
    payload = snap.as_dict()
    payload["ok"] = snap.ok
    return JSONResponse(payload, status_code=200 if snap.ok else 503)


@app.get("/api/zones/template")
def zones_template() -> PlainTextResponse:
    return PlainTextResponse(ZONE_TEMPLATE, media_type="text/plain; charset=utf-8")


# ---------------------------------------------------------------------- api
@app.get("/api/status")
def status() -> Any:
    try:
        settings = _settings()
        state = _state()
        journal_path = _current_db()
        equity = balance = 0.0
        trades = 0
        if journal_path.exists():
            journal = SqliteJournal(journal_path)
            try:
                curve = journal.equity_curve()
                if curve:
                    _, equity, balance = curve[-1]
                trades = len([t for t in journal.trades() if t.close_time])
            finally:
                journal.close()
        zones_today = _zones().for_day(_today())
        return {
            "today": _today().isoformat(),
            "iran_now": iran_now().strftime("%Y-%m-%d %H:%M"),
            "profile": state.profile,
            "direction": state.direction,
            "overrides": state.overrides,
            # The single source of truth for what the panel can change. Retired
            # keys are deliberately absent (see RETIRED_CONFIG_KEYS).
            "effective_config": state.effective_config(),
            "equity": round(equity, 2),
            "balance": round(balance, 2),
            "closed_trades": trades,
            "journal": str(journal_path),
            "last_run": state.last_run,
            "zones_loaded_today": bool(zones_today),
            "max_zones": MAX_ZONES_PER_DAY,
            "strategies": [
                {
                    "slot": inst.slot,
                    "strategy": inst.strategy_id,
                    "timeframe": inst.timeframe,
                    "enabled": inst.enabled and inst.slot not in state.disabled_slots,
                    "description": REGISTRY[inst.strategy_id].description,
                    "priority": REGISTRY[inst.strategy_id].factory.priority,
                }
                for inst in load_instances(settings.strategies.directory, include_disabled=True)
            ],
            "zones": [asdict(z) for z in zones_today],
        }
    except Exception as exc:  # noqa: BLE001 - never leak an HTML error page
        return _fail(exc)


@app.get("/api/zones")
def get_zones(day: str | None = None) -> Any:
    try:
        target = date.fromisoformat(day) if day else _today()
        zones = _zones().for_day(target)
        return {
            "day": target.isoformat(),
            "max": MAX_ZONES_PER_DAY,
            "loaded": bool(zones),
            "zones": [asdict(z) for z in zones],
        }
    except Exception as exc:  # noqa: BLE001
        return _fail(exc, 400)


@app.put("/api/zones")
def put_zones(payload: ZonesIn) -> Any:
    try:
        target = date.fromisoformat(payload.day) if payload.day else _today()
        zones = [Zone(high=z.high, low=z.low, starred=z.starred, note=z.note) for z in payload.zones]
        if len(zones) > MAX_ZONES_PER_DAY:
            raise HTTPException(400, f"حداکثر {MAX_ZONES_PER_DAY} ناحیه در هر روز مجاز است")
        _zones().replace_day(target, zones)
        return {"ok": True, "day": target.isoformat(), "count": len(zones)}
    except HTTPException:
        raise
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc
    except Exception as exc:  # noqa: BLE001
        return _fail(exc)


@app.post("/api/zones/import")
def import_zones(payload: ZonesImportIn) -> Any:
    """Load coordinates from a pasted/uploaded JSON or CSV file."""
    try:
        target = date.fromisoformat(payload.day) if payload.day else _today()
        zones = parse_zones_text(payload.text)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc
    if len(zones) > MAX_ZONES_PER_DAY:
        raise HTTPException(
            400, f"فایل {len(zones)} ناحیه دارد؛ حداکثر {MAX_ZONES_PER_DAY} مجاز است"
        )
    try:
        _zones().replace_day(target, zones)
        return {"ok": True, "day": target.isoformat(), "count": len(zones)}
    except Exception as exc:  # noqa: BLE001
        return _fail(exc)


@app.delete("/api/zones/{index}")
def delete_zone(index: int, day: str | None = None) -> Any:
    try:
        target = date.fromisoformat(day) if day else _today()
        if not _zones().remove(target, index):
            raise HTTPException(404, "zone not found")
        return {"ok": True}
    except HTTPException:
        raise
    except Exception as exc:  # noqa: BLE001
        return _fail(exc)


@app.put("/api/config")
def put_config(body: dict[str, Any] = Body(...)) -> Any:
    try:
        retired = sorted(set(body) & set(RETIRED_CONFIG_KEYS))
        if retired:
            details = "; ".join(
                key + " (" + RETIRED_CONFIG_KEYS[key] + ")" for key in retired
            )
            raise HTTPException(400, "کلید(های) بازنشسته پذیرفته نمی‌شود: " + details)
        unknown = sorted(set(body) - set(ConfigIn.model_fields))
        if unknown:
            raise HTTPException(400, "کلید(های) ناشناخته: " + ", ".join(unknown))
        try:
            payload = ConfigIn.model_validate(body)
        except ValidationError as exc:
            message = exc.errors()[0].get("msg", "invalid") if exc.errors() else "invalid"
            raise HTTPException(400, "تنظیمات نامعتبر است: " + str(message)) from exc
        state = _state()
        if payload.profile is not None:
            if payload.profile not in ("low", "medium", "high"):
                raise HTTPException(400, "profile must be low|medium|high")
            state.profile = payload.profile
        if payload.direction is not None:
            if payload.direction not in ("both", "long", "short"):
                raise HTTPException(400, "direction must be both|long|short")
            state.direction = payload.direction
        if payload.overrides is not None:
            state.overrides = payload.overrides
        if payload.disabled_slots is not None:
            state.disabled_slots = payload.disabled_slots

        # Validate the resulting combination before saving: an override that
        # contradicts the profile (e.g. 2% risk with a 1% daily stop) would
        # otherwise break every later run.
        from ..app.risk import load_profiles, resolve_profile

        settings = _settings()
        profiles = load_profiles(ROOT / settings.risk.profiles_path)
        try:
            resolve_profile(state.profile, profiles, state.overrides)
        except Exception as exc:  # ConfigError
            raise HTTPException(400, f"تنظیمات ناسازگار است: {exc}") from exc

        state.save(STATE_PATH)
        return {"ok": True, "state": asdict(state)}
    except HTTPException:
        raise
    except Exception as exc:  # noqa: BLE001
        return _fail(exc)


@app.post("/api/strategies/{slot}/toggle")
def toggle_strategy(slot: str) -> Any:
    try:
        state = _state()
        if slot in state.disabled_slots:
            state.disabled_slots.remove(slot)
            enabled = True
        else:
            state.disabled_slots.append(slot)
            enabled = False
        state.save(STATE_PATH)
        return {"slot": slot, "enabled": enabled}
    except Exception as exc:  # noqa: BLE001
        return _fail(exc)


@app.post("/api/run")
def run_backtest(
    days: int = 10, ticks_per_minute: int = 2, start_price: float = 4000.0, balance: float = 10000.0
) -> Any:
    """Run the engine on a fresh synthetic tape with the panel's current settings."""
    if not _run_lock.acquire(blocking=False):
        return JSONResponse({"detail": "یک اجرا در جریان است؛ چند لحظه صبر کن"}, status_code=409)
    try:
        if not 1 <= days <= 180:
            raise HTTPException(400, "days must be between 1 and 180")
        settings = _settings()
        state = _state()
        trading = settings.trading.model_copy(update={"direction": state.direction})
        settings = settings.model_copy(update={"trading": trading})

        RUN_DIR.mkdir(parents=True, exist_ok=True)
        run_id = datetime.now(tz=timezone.utc).strftime("%Y%m%d-%H%M%S") + "-" + uuid.uuid4().hex[:4]
        db_path = RUN_DIR / f"run-{run_id}.db"

        tape = ROOT / "var" / f"panel_{days}d_{int(start_price)}.jsonl"
        if not tape.exists():
            write_synthetic_tape(
                tape,
                symbol=settings.symbol.name,
                start=datetime(2024, 3, 3, tzinfo=timezone.utc),
                days=days,
                ticks_per_minute=ticks_per_minute,
                start_price=start_price,
            )

        components = build_components(
            settings,
            tape_path=tape,
            profile_name=state.profile,
            extra_overrides=state.overrides,
            instances=_instances(settings, state),
            db_path=db_path,
            initial_balance=balance,
        )
        try:
            result = components.engine.run()
            stats = components.journal.stats()
        finally:
            components.close()

        LAST_RUN_FILE.write_text(str(db_path), encoding="utf-8")
        state.last_run = {
            "at": iran_now().strftime("%Y-%m-%d %H:%M"),
            "ticks": result.ticks,
            "trades": result.trades_closed,
            "approved": result.approved,
            "rejected": result.rejected,
            "net": round(float(stats.get("net", 0.0)), 2),
            "win_rate": stats.get("win_rate", 0.0),
            "pf": stats.get("profit_factor", 0.0),
            "max_dd_pct": stats.get("max_dd_pct", 0.0),
            "final_state": result.final_state,
            "priority_skipped": result.priority_skipped,
            "rejects": result.rejects,
            "by_slot": stats.get("by_slot", {}),
            "by_confirmation": stats.get("by_confirmation", {}),
            "journal": str(db_path),
        }
        state.save(STATE_PATH)
        return JSONResponse(state.last_run)
    except HTTPException as exc:
        return JSONResponse({"detail": exc.detail}, status_code=exc.status_code)
    except ConfigError as exc:
        return JSONResponse({"detail": f"تنظیمات ناسازگار: {exc}"}, status_code=400)
    except Exception as exc:  # noqa: BLE001
        return _fail(exc)
    finally:
        _run_lock.release()


@app.get("/api/journal")
def journal(limit: int = 300) -> Any:
    try:
        db = _current_db()
        if not db.exists():
            return {"trades": [], "stats": {}, "equity": []}
        store = SqliteJournal(db)
        try:
            trades = store.trades()[-limit:]
            stats = dict(store.stats())
            equity = store.equity_curve()
        finally:
            store.close()
        step = max(1, len(equity) // 240)
        return {
            "stats": stats,
            "trades": [asdict(t) for t in trades],
            "equity": [{"ts": ts, "value": value} for ts, value, _ in equity[::step]],
        }
    except Exception as exc:  # noqa: BLE001
        return _fail(exc)


@app.get("/api/journal.xlsx")
def journal_xlsx() -> Any:
    db = _current_db()
    if not db.exists():
        raise HTTPException(404, "run the backtest first")
    try:
        store = SqliteJournal(db)
        try:
            trades = store.trades()
        finally:
            store.close()

        headers = [
            "ردیف", "زمان ورود", "زمان خروج", "استراتژی", "تاییدکننده‌ها", "تعداد تایید",
            "جهت", "ورود", "خروج", "حجم", "سود", "زیان", "خالص", "R", "دلیل خروج", "پروفایل",
        ]
        rows = []
        for i, t in enumerate(trades, start=1):
            rows.append(
                [
                    i,
                    t.open_time.replace("T", " ")[:16],
                    (t.close_time or "").replace("T", " ")[:16],
                    t.strategy,
                    " + ".join(t.confirmations) if t.confirmations else t.strategy,
                    t.confirmation_count,
                    t.side,
                    t.open_price,
                    t.close_price,
                    t.volume,
                    round(max(t.pnl_net, 0.0), 2),
                    round(abs(min(t.pnl_net, 0.0)), 2),
                    round(t.pnl_net, 2),
                    t.r_multiple,
                    t.exit_reason,
                    t.risk.get("profile", "") if isinstance(t.risk, dict) else "",
                ]
            )
        out = ROOT / "var" / "journal.xlsx"
        write_xlsx(out, headers, rows, sheet="trades")
        return FileResponse(out, filename="goldbot-journal.xlsx")
    except HTTPException:
        raise
    except Exception as exc:  # noqa: BLE001
        return _fail(exc)
