"""Local web panel (FastAPI).

``goldbot.web.app`` must stay the *module* (uvicorn imports "goldbot.web.app:app"),
so the instance is re-exported under a different name here.
"""

from .app import app as application

__all__ = ["application"]
