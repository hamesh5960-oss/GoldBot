"""Cooldown gates A, B and C.

The old 3/5/2 global time filter is replaced by independent gates:
* Gate A - one M15 bar of silence after any execution (hard, no bypass);
* Gate B - per-zone, per-direction burn with a quality bypass;
* Gate C - directional concentration with a quality bypass and a hedge exception.

Gate D (total risk cap) is enforced inside the capital pipeline, where the
proposed risk amount is actually known.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping, Sequence

from ..domain.model import PositionSnapshot
from ..ports.risk import RiskContext
from ..strategy_api.zones import Zone
from .decision import SIZE_FACTOR, SizeLevel, Tier, downgrade_size


@dataclass(frozen=True, slots=True)
class GateParams:
    gate_a_window: int = 1
    burn_after_tp: int = 2
    burn_after_sl: int = 5
    burn_after_be: int = 3
    full_bypass_signal: float = 1.5
    full_bypass_zone: int = 85
    downgrade_min_signal: float = 1.0
    downgrade_min_zone: int = 70
    max_directional_trend: int = 2
    max_directional_range: int = 1
    profit_threshold_atr: float = 0.5
    hedge_size_factor: float = 0.25
    hedge_min_signal: float = 1.0
    hedge_min_zone: int = 75
    zone_defect_sl_count: int = 2


@dataclass(frozen=True, slots=True)
class GateResult:
    verdict: str  # pass | downgrade | reject
    gate: str = ""
    reason: str = ""
    size_factor: float = 1.0
    size_level: SizeLevel = SizeLevel.FULL
    hedge: bool = False
    fields: dict[str, Any] = field(default_factory=dict)

    @property
    def rejected(self) -> bool:
        return self.verdict == "reject"


PASS = GateResult("pass")
DOWNGRADE_STEP = SizeLevel.HALF


class CooldownManager:
    def __init__(self, params: GateParams | None = None) -> None:
        self.params = params or GateParams()
        self.bar_index = 0
        self.last_exec_bar = -10_000
        self._burns: dict[tuple[str, str], dict[str, Any]] = {}
        self._sl_counts: dict[tuple[str, str], int] = {}
        self._tickets: dict[int, dict[str, Any]] = {}
        self._zone_scores: dict[str, int] = {}
        self._session = ""
        self._volatile = False
        self._events: list[dict[str, Any]] = []

    # -- lifecycle -------------------------------------------------------
    def on_bar(self, *, zones: Sequence[Zone], regime: Any) -> None:
        self.bar_index += 1
        self._zone_scores = {zone.zone_id: zone.score for zone in zones}

        if regime.structure_event:
            self._clear_burns()
            self._events.append({"event": "structure_reset", "kind": regime.structure_event})

        atr_h1 = getattr(regime, "atr_h1", None)
        median = getattr(regime, "atr_h1_median", None)
        if atr_h1 and median and atr_h1 > 2.0 * median:
            if not self._volatile:
                self._clear_burns()
                self._events.append({"event": "volatility_reset", "ratio": round(atr_h1 / median, 2)})
            self._volatile = True
        elif atr_h1 and median and atr_h1 < 1.5 * median:
            self._volatile = False

        session = getattr(regime, "session", "")
        if self._session and session and session != self._session:
            for key in list(self._burns):
                if self._zone_scores.get(key[0], 100) < 70:
                    self._burns.pop(key, None)
            self._events.append({"event": "session_reset", "from": self._session, "to": session})
        self._session = session or self._session

    def note_execution(
        self, *, ticket: int, zone_id: str | None, side: str, stop: float | None = None
    ) -> None:
        self.last_exec_bar = self.bar_index
        if zone_id:
            self._tickets[int(ticket)] = {"zone_id": zone_id, "side": side, "stop": stop}

    def note_close(
        self, *, ticket: int, reason: str, entry: float, exit_price: float, side: str
    ) -> None:
        info = self._tickets.pop(int(ticket), None)
        if info is None:
            return
        zone_id = info["zone_id"]
        stop = info.get("stop")
        key = (zone_id, side)
        risk = abs(entry - stop) if stop is not None else 0.0
        if reason == "tp":
            self._burn(key, self.params.burn_after_tp, "TP")
        elif reason == "sl":
            if risk > 0 and abs(exit_price - entry) <= 0.10 * risk:
                self._burn(key, self.params.burn_after_be, "BE")
            else:
                count = self._sl_counts.get(key, 0) + 1
                self._sl_counts[key] = count
                if count >= self.params.zone_defect_sl_count:
                    self._burn(key, 96, "DEFECT")
                else:
                    self._burn(key, self.params.burn_after_sl, "SL")
        else:
            self._burn(key, self.params.burn_after_be, reason.upper())

    def _burn(self, key: tuple[str, str], bars: int, reason: str) -> None:
        state = self._burns.get(key, {"until": 0, "reason": "", "count": 0})
        state["until"] = max(int(state["until"]), self.bar_index + int(bars))
        state["reason"] = reason
        state["count"] = int(state["count"]) + 1
        self._burns[key] = state
        self._events.append(
            {"event": "burn", "zone": key[0], "side": key[1], "bars": bars, "reason": reason}
        )

    def _clear_burns(self) -> None:
        self._burns.clear()
        self._sl_counts.clear()

    def burns(self) -> dict[tuple[str, str], dict[str, Any]]:
        return {key: dict(value) for key, value in self._burns.items()}

    def snapshot(self) -> dict[str, Any]:
        """JSON-safe gate state so burns and Gate A survive a restart.

        Bar counters are absolute, so a live restart continues the same clock;
        a replay restarted from the beginning is a different run by definition.
        """
        return {
            "bar_index": int(self.bar_index),
            "last_exec_bar": int(self.last_exec_bar),
            "burns": [
                {"zone": key[0], "side": key[1], **dict(state)}
                for key, state in self._burns.items()
            ],
            "sl_counts": [
                {"zone": key[0], "side": key[1], "count": int(count)}
                for key, count in self._sl_counts.items()
            ],
            "tickets": {
                str(ticket): dict(meta) for ticket, meta in self._tickets.items()
            },
            "session": self._session,
        }

    def restore(self, data: Mapping[str, Any]) -> bool:
        """Adopt a snapshot; a malformed record is ignored, never crashed on."""
        if not isinstance(data, Mapping):
            return False
        try:
            bar_index = max(0, int(data.get("bar_index") or 0))
            last_exec_raw = data.get("last_exec_bar")
            last_exec_bar = -10_000 if last_exec_raw is None else int(last_exec_raw)
        except (TypeError, ValueError):
            return False
        burns: dict[tuple[str, str], dict[str, Any]] = {}
        for item in data.get("burns") or []:
            try:
                key = (str(item["zone"]), str(item["side"]))
                burns[key] = {
                    "until": int(item.get("until") or 0),
                    "reason": str(item.get("reason") or ""),
                    "count": int(item.get("count") or 0),
                }
            except (TypeError, ValueError, KeyError):
                continue
        sl_counts: dict[tuple[str, str], int] = {}
        for item in data.get("sl_counts") or []:
            try:
                sl_counts[(str(item["zone"]), str(item["side"]))] = int(item["count"])
            except (TypeError, ValueError, KeyError):
                continue
        tickets: dict[int, dict[str, Any]] = {}
        for ticket, meta in dict(data.get("tickets") or {}).items():
            try:
                tickets[int(ticket)] = dict(meta)
            except (TypeError, ValueError):
                continue
        self.bar_index = bar_index
        self.last_exec_bar = last_exec_bar
        self._burns = burns
        self._sl_counts = sl_counts
        self._tickets = tickets
        self._session = str(data.get("session") or "")
        return True

    def drain_events(self) -> list[dict[str, Any]]:
        events, self._events = self._events, []
        return events

    # -- evaluation ------------------------------------------------------
    def evaluate(
        self,
        *,
        side: str,
        zone_id: str | None,
        signal_score: float,
        zone_score: int,
        setup_type: str,
        tier: Tier,
        atr: float,
        adx_h1: float | None,
        positions: Sequence[PositionSnapshot],
        ctx: RiskContext,
    ) -> GateResult:
        p = self.params

        # Gate A: hard silence window.
        if self.bar_index - self.last_exec_bar <= p.gate_a_window:
            return GateResult(
                "reject",
                gate="A",
                reason="GateA_TickNoise",
                fields={"bars_since_exec": self.bar_index - self.last_exec_bar},
            )

        level = SizeLevel.FULL
        fields: dict[str, Any] = {"gate_hit": "", "bypass_type": ""}

        # Gate B: zone burn.
        if zone_id and (zone_id, side) in self._burns:
            state = self._burns[(zone_id, side)]
            if int(state["until"]) >= self.bar_index:
                if (
                    signal_score >= p.full_bypass_signal
                    and zone_score >= p.full_bypass_zone
                    and setup_type in ("sweep", "break_retest")
                ):
                    fields.update(gate_hit="B", bypass_type="full_quality")
                elif signal_score >= p.downgrade_min_signal and zone_score >= p.downgrade_min_zone:
                    fields.update(gate_hit="B", bypass_type="downgrade")
                    level = downgrade_size(level)
                elif int(state["count"]) >= 2:
                    # A zone that already burned twice in this direction is a trap.
                    return GateResult(
                        "reject",
                        gate="B",
                        reason="Zone_Burn_Trap",
                        fields={"zone_id": zone_id, "burn_until": state["until"]},
                    )
                else:
                    # Quality failed, safety did not: the last rung is one min lot.
                    fields.update(gate_hit="B", bypass_type="smallest")
                    level = SizeLevel.SMALLEST

        # Gate C: directional concentration / hedge.
        same = [pos for pos in positions if pos.side == side]
        opposite = [pos for pos in positions if pos.side != side]
        cap = p.max_directional_trend if (adx_h1 or 0.0) > 30.0 else p.max_directional_range
        fields.update(directional_cap=cap, same_direction=len(same), opposite=len(opposite))

        if opposite:
            profitable = any(float(pos.profit.amount) > 0 for pos in opposite)
            if profitable:
                return GateResult(
                    "reject",
                    gate="C",
                    reason="Hedge_Into_Profit",
                    fields={**fields, "gate_hit": "C"},
                )
            if signal_score >= p.hedge_min_signal and zone_score >= p.hedge_min_zone:
                return GateResult(
                    "pass",
                    gate="C",
                    reason="Hedge_Allowed",
                    size_factor=p.hedge_size_factor,
                    size_level=SizeLevel.QUARTER,
                    hedge=True,
                    fields={**fields, "gate_hit": "C", "bypass_type": "hedge"},
                )
            return GateResult(
                "reject",
                gate="C",
                reason="Hedge_Weak_Signal",
                fields={**fields, "gate_hit": "C"},
            )

        if same and len(same) >= cap:
            distances = [self._distance(pos, ctx) for pos in same]
            all_profit = all(d >= p.profit_threshold_atr * atr for d in distances)
            different_zone = bool(zone_id) and all(
                self._tickets.get(int(pos.ticket), {}).get("zone_id") != zone_id for pos in same
            )
            # Spread makes the bid sit below the entry of a long; a position
            # within 10% of ATR of its entry counts as break-even.
            be_tolerance = 0.10 * atr
            at_breakeven = all(d >= -be_tolerance for d in distances)
            if all_profit and different_zone and zone_score >= 85:
                fields.update(gate_hit="C", bypass_type="profit_other_zone")
            elif tier is Tier.C and zone_score >= 85 and signal_score >= 1.2:
                fields.update(gate_hit="C", bypass_type="extra_quality_position")
            elif tier in (Tier.C, Tier.B) and at_breakeven:
                fields.update(gate_hit="C", bypass_type="downgrade")
                level = downgrade_size(level)
            else:
                # Concentration is a quality cap, not a physical block: min lot.
                fields.update(gate_hit="C", bypass_type="smallest")
                level = SizeLevel.SMALLEST

        if level is SizeLevel.NONE:
            return GateResult("reject", gate="B", reason="Downgrade_Exhausted", fields=fields)
        verdict = "pass" if level is SizeLevel.FULL else "downgrade"
        return GateResult(
            verdict,
            size_factor=SIZE_FACTOR[level],
            size_level=level,
            fields=fields,
        )

    @staticmethod
    def _distance(pos: PositionSnapshot, ctx: RiskContext) -> float:
        price = ctx.tick.bid if pos.side == "buy" else ctx.tick.ask
        direction = 1.0 if pos.side == "buy" else -1.0
        return (price - pos.open_price) * direction
