"""Derived position book. Broker is truth; this is a cache with metadata attached."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Mapping, Sequence

from ..domain.errors import InvariantError
from ..domain.model import ClosedTrade, Fill, PositionSnapshot, Symbol, Ticket
from ..log import get_logger
from ..ports.execution import PositionView, ReconcileReport
from .ids import owns_position_magic

log = get_logger("positions")

# A position adopted from the venue after a restart is deliberately parked on
# its own slot: no strategy instance answers to it, so it can never be sized
# onto, pyramided into, or reported as a strategy signal.
ADOPTED_SLOT = "adopted"
ADOPTED_STRATEGY = "adopted"


@dataclass
class ManagedPosition:
    ticket: int
    slot: str
    strategy: str
    symbol: str
    side: str
    volume: float
    open_price: float
    sl: float | None
    tp: float | None
    open_time: datetime
    risk_amount: float
    initial_stop: float
    signal: Mapping[str, Any] = field(default_factory=dict)
    risk: Mapping[str, Any] = field(default_factory=dict)
    mae: float = 0.0
    mfe: float = 0.0
    unrealized: float = 0.0
    # Three-layer TP machine, when one is armed. Kept on the position so the
    # book and the exit plan cannot drift apart; the FSM owns the SL after TP1.
    fsm: Any = None

    def to_view(self) -> PositionView:
        return PositionView(
            ticket=self.ticket,
            slot=self.slot,
            strategy=self.strategy,
            symbol=self.symbol,
            side=self.side,
            volume=self.volume,
            open_price=self.open_price,
            sl=self.sl,
            tp=self.tp,
            open_time=self.open_time,
            risk_amount=self.risk_amount,
            mae=self.mae,
            mfe=self.mfe,
        )


@dataclass(frozen=True, slots=True)
class AdoptedExitAction:
    """Close-only action for an adopted position; it never modifies SL/TP."""

    kind: str
    action_id: str
    reason: str
    sl: float | None = None
    volume: float = 0.0


class AdoptedExitPolicy:
    """Protective exit policy for a position adopted from the venue after restart.

    The broker's SL/TP stay exactly as reported; the only action this policy can
    produce is a full CLOSE when the profile time stop expires. It speaks the
    same tiny protocol as app.position_fsm.PositionFSM, because the engine's
    existing generic FSM pump executes it - no new loop code is needed.
    """

    def __init__(
        self,
        *,
        ticket: int,
        open_time: datetime,
        max_holding_hours: float,
        clock: Any,
    ) -> None:
        self._ticket = int(ticket)
        self._open_time = open_time
        self._max_hours = max(0.0, float(max_holding_hours))
        self._clock = clock
        self.closed = False
        self.pending: AdoptedExitAction | None = None

    def on_price(self, price: float, atr: float | None = None) -> AdoptedExitAction | None:
        if self.closed:
            return None
        if self.pending is not None:
            return self.pending
        if self._max_hours <= 0.0:
            return None
        now = self._clock.now().wall
        age_hours = (now - self._open_time).total_seconds() / 3600.0
        if age_hours >= self._max_hours:
            self.pending = AdoptedExitAction(
                kind="CLOSE",
                action_id=f"adopted-time-{self._ticket}",
                reason="time",
            )
            return self.pending
        return None

    def on_action_done(self, action: Any, filled_volume: float | None = None) -> None:
        self.closed = True
        self.pending = None

    def on_action_failed(self, reason: str) -> None:
        # Keep the pending close: the engine pump retries it (bounded).
        return None

    def mark_closed(self, reason: str) -> None:
        self.closed = True
        self.pending = None


class PositionManager:
    """Hedging keeps one entry per ticket; netting aggregates per symbol."""

    def __init__(self, *, mode: str = "hedging", contract_size: float = 100.0) -> None:
        self.mode = mode
        self.contract_size = contract_size
        self._book: dict[Any, ManagedPosition] = {}
        self._realized: float = 0.0

    # -- mutations -------------------------------------------------------
    def apply_fill(
        self,
        fill: Fill,
        *,
        slot: str = "",
        strategy: str = "",
        risk_amount: float = 0.0,
        initial_stop: float | None = None,
        signal: Mapping[str, Any] | None = None,
        risk: Mapping[str, Any] | None = None,
    ) -> ManagedPosition:
        if self.mode == "netting":
            return self._apply_netting(fill, slot, strategy, risk_amount, initial_stop, signal, risk)

        pos = ManagedPosition(
            ticket=int(fill.ticket),
            slot=slot,
            strategy=strategy,
            symbol=str(fill.symbol),
            side=fill.side,
            volume=fill.volume,
            open_price=fill.price,
            sl=initial_stop,
            tp=None,
            open_time=fill.ts.wall,
            risk_amount=risk_amount,
            initial_stop=initial_stop if initial_stop is not None else fill.price,
            signal=dict(signal or {}),
            risk=dict(risk or {}),
        )
        self._book[pos.ticket] = pos
        return pos

    def _apply_netting(
        self,
        fill: Fill,
        slot: str,
        strategy: str,
        risk_amount: float,
        initial_stop: float | None,
        signal: Mapping[str, Any] | None,
        risk: Mapping[str, Any] | None,
    ) -> ManagedPosition:
        key = str(fill.symbol)
        current = self._book.get(key)
        direction = 1.0 if fill.side == "buy" else -1.0
        if current is None:
            pos = ManagedPosition(
                ticket=int(fill.ticket),
                slot=slot,
                strategy=strategy,
                symbol=key,
                side=fill.side,
                volume=fill.volume,
                open_price=fill.price,
                sl=initial_stop,
                tp=None,
                open_time=fill.ts.wall,
                risk_amount=risk_amount,
                initial_stop=initial_stop or fill.price,
                signal=dict(signal or {}),
                risk=dict(risk or {}),
            )
            self._book[key] = pos
            return pos

        same_side = (current.side == "buy" and direction > 0) or (current.side == "sell" and direction < 0)
        if same_side:
            total = current.volume + fill.volume
            current.open_price = (current.open_price * current.volume + fill.price * fill.volume) / total
            current.volume = total
            current.risk_amount += risk_amount
            return current

        # Opposite fill: reduce, and flip the remainder at the fill price.
        if fill.volume < current.volume - 1e-9:
            current.volume -= fill.volume
            return current
        remainder = round(fill.volume - current.volume, 4)
        self._book.pop(key, None)
        if remainder <= 1e-9:
            return current
        flipped = ManagedPosition(
            ticket=int(fill.ticket),
            slot=slot,
            strategy=strategy,
            symbol=key,
            side=fill.side,
            volume=remainder,
            open_price=fill.price,
            sl=initial_stop,
            tp=None,
            open_time=fill.ts.wall,
            risk_amount=risk_amount,
            initial_stop=initial_stop or fill.price,
            signal=dict(signal or {}),
            risk=dict(risk or {}),
        )
        self._book[key] = flipped
        return flipped

    def apply_close(self, trade: ClosedTrade, *, slot: str | None = None) -> ManagedPosition | None:
        key: Any = str(trade.symbol) if self.mode == "netting" else int(trade.ticket)
        pos = self._book.pop(key, None)
        self._realized += float(trade.pnl_net.amount)
        if pos is not None and trade.volume < pos.volume - 1e-9:
            pos.volume = round(pos.volume - trade.volume, 4)
            self._book[key] = pos
        return pos

    def mark(self, prices: Mapping[Symbol, tuple[float, float]]) -> None:
        for pos in self._book.values():
            pair = prices.get(Symbol(pos.symbol))
            if pair is None:
                continue
            bid, ask = pair
            price = bid if pos.side == "buy" else ask
            direction = 1.0 if pos.side == "buy" else -1.0
            pnl = (price - pos.open_price) * direction * self.contract_size * pos.volume
            pos.unrealized = pnl
            pos.mfe = max(pos.mfe, pnl)
            pos.mae = min(pos.mae, pnl)

    # -- queries ---------------------------------------------------------
    def view(self) -> Sequence[PositionView]:
        return [p.to_view() for p in self._book.values()]

    def raw(self) -> Sequence[ManagedPosition]:
        return list(self._book.values())

    def get(self, ticket: int) -> ManagedPosition | None:
        """The mutable position for a ticket (hedging mode keys by ticket)."""
        return self._book.get(int(ticket))

    def get_by_symbol(self, symbol: Symbol | str) -> ManagedPosition | None:
        """First position on a symbol; netting mode keeps one aggregate."""
        key = str(symbol)
        direct = self._book.get(key)
        if direct is not None:
            return direct
        for pos in self._book.values():
            if pos.symbol == key:
                return pos
        return None

    # -- three-layer TP --------------------------------------------------
    def attach_fsm(self, ticket: int, fsm: Any) -> ManagedPosition:
        """Arm the take-profit machine for one position.

        Netting is refused on purpose: a netted aggregate has no per-ticket
        lifecycle, so partial exits cannot be attributed to a single plan.
        """
        if self.mode != "hedging":
            raise InvariantError(
                f"position FSM is disabled in {self.mode} mode: a netted aggregate "
                "has no per-ticket lifecycle for partial exits"
            )
        pos = self._book.get(int(ticket))
        if pos is None:
            raise InvariantError(f"cannot arm a position FSM for unknown ticket {ticket}")
        pos.fsm = fsm
        return pos

    def fsm_actions(
        self, prices: Mapping[Symbol, tuple[float, float]], atr: float | None = None
    ) -> list[tuple[ManagedPosition, Any]]:
        """Poll every armed FSM for its next pending action.

        Returns (position, action) pairs. The same action is returned on every
        poll until the caller acknowledges it, so callers may safely retry.
        """
        out: list[tuple[ManagedPosition, Any]] = []
        for pos in self._book.values():
            fsm = pos.fsm
            if fsm is None or getattr(fsm, "closed", False):
                continue
            pair = prices.get(Symbol(pos.symbol))
            if pair is None:
                continue
            bid, ask = pair
            price = bid if pos.side == "buy" else ask
            action = fsm.on_price(price, atr)
            if action is not None:
                out.append((pos, action))
        return out

    def by_slot(self, slot: str) -> Sequence[PositionView]:
        return [p.to_view() for p in self._book.values() if p.slot == slot]

    def by_symbol(self, symbol: Symbol) -> Sequence[PositionView]:
        return [p.to_view() for p in self._book.values() if p.symbol == str(symbol)]

    def slot_of(self, ticket: Ticket) -> str | None:
        pos = self._book.get(int(ticket))
        return None if pos is None else pos.slot

    def count(self) -> int:
        return len(self._book)

    def net_volume(self, symbol: Symbol) -> float:
        total = 0.0
        for pos in self._book.values():
            if pos.symbol == str(symbol):
                total += pos.volume if pos.side == "buy" else -pos.volume
        return round(total, 4)

    @property
    def realized(self) -> float:
        return self._realized

    # -- restart adoption ------------------------------------------------
    def adopt_positions(
        self,
        truth: Sequence[PositionSnapshot],
        *,
        max_holding_hours: float = 0.0,
        clock: Any = None,
        adopt_foreign_magic: bool = True,
        slot: str = ADOPTED_SLOT,
        strategy: str = ADOPTED_STRATEGY,
    ) -> list[ManagedPosition]:
        """Adopt venue positions that have no book entry (idempotent by ticket).

        Broker truth wins: volume/open price/SL/TP are copied verbatim. The
        adopted ticket is parked on its own slot/strategy so no strategy can
        size onto it or pyramid, and only a time-stop protective policy is
        attached (broker SL/TP are never moved by adoption). Foreign/manual
        magics are adopted by default because unmanaged exposure is the larger
        risk; with adopt_foreign_magic=False they are skipped and the caller
        must fail closed instead of calling reconciliation clean.
        """
        adopted: list[ManagedPosition] = []
        if self.mode != "hedging":
            return adopted
        for snapshot in truth:
            ticket = int(getattr(snapshot, "ticket"))
            if ticket in self._book:
                continue
            magic = int(getattr(snapshot, "magic", 0) or 0)
            owned = owns_position_magic(magic)
            if not owned and not adopt_foreign_magic:
                continue
            open_time = getattr(snapshot, "open_time")
            stop_raw = getattr(snapshot, "sl", None)
            take_raw = getattr(snapshot, "tp", None)
            open_price = float(getattr(snapshot, "open_price"))
            position = ManagedPosition(
                ticket=ticket,
                slot=slot,
                strategy=strategy,
                symbol=str(getattr(snapshot, "symbol")),
                side=str(getattr(snapshot, "side")),
                volume=float(getattr(snapshot, "volume")),
                open_price=open_price,
                sl=None if stop_raw is None else float(stop_raw),
                tp=None if take_raw is None else float(take_raw),
                open_time=open_time,
                risk_amount=0.0,
                initial_stop=open_price if stop_raw is None else float(stop_raw),
                signal={
                    "adopted": True,
                    "magic": magic,
                    "magic_owned": owned,
                    "comment": str(getattr(snapshot, "comment", "") or ""),
                },
                risk={"adopted": True},
            )
            if clock is not None:
                position.fsm = AdoptedExitPolicy(
                    ticket=ticket,
                    open_time=open_time,
                    max_holding_hours=max_holding_hours,
                    clock=clock,
                )
            self._book[ticket] = position
            adopted.append(position)
        return adopted

    # -- reconciliation --------------------------------------------------
    def reconcile(self, truth: Sequence[PositionSnapshot]) -> ReconcileReport:
        local_tickets = {p.ticket for p in self._book.values()} if self.mode == "hedging" else set()
        broker_map = {int(p.ticket): p for p in truth}

        missing = tuple(sorted(t for t in local_tickets if t not in broker_map))
        orphan = tuple(sorted(t for t in broker_map if t not in local_tickets)) if self.mode == "hedging" else ()
        volume_drift: list[int] = []
        protection_lost: list[int] = []
        details: list[str] = []

        for ticket, snapshot in broker_map.items():
            local = self._book.get(ticket)
            if local is None:
                continue
            if abs(local.volume - snapshot.volume) > 1e-6:
                volume_drift.append(ticket)
                details.append(f"ticket {ticket}: local {local.volume} vs broker {snapshot.volume}")
            if local.sl is not None and snapshot.sl is None:
                protection_lost.append(ticket)
                details.append(f"ticket {ticket}: stop loss missing at broker")
        for ticket in missing:
            details.append(f"ticket {ticket}: open locally, absent at broker")
        for ticket in orphan:
            details.append(f"ticket {ticket}: present at broker, unknown locally")

        return ReconcileReport(
            clean=not (missing or orphan or volume_drift or protection_lost),
            missing=missing,
            orphan=orphan,
            volume_drift=tuple(sorted(volume_drift)),
            protection_lost=tuple(sorted(protection_lost)),
            details=tuple(details),
        )
