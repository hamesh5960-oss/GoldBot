"""The trading engine: one loop, one contract, identical in backtest and replay."""

from __future__ import annotations

import time
from dataclasses import dataclass, field, replace
from datetime import datetime, timedelta
from typing import Any, Sequence

from ..domain.errors import InvariantError
from ..domain.events import Ev, Event
from ..domain.execution import EntryIntent
from ..domain.model import ClosedTrade, Symbol, Tick
from ..domain.money import money
from ..domain.retcodes import RetcodeAction, classify
from ..log import get_logger
from ..ports.risk import RiskContext, RiskState
from ..strategy_api import indicators
from ..strategy_api import TradeSummary
from .arbiter import SignalArbiter, has_other_strategy_confirmation
from ..domain.events import SignalLevelRecord, SignalRecord
from .capital_levels import CapitalLevel, policy_for, risk_pct_for_level
from .confirmations import ema200_h1_vote, evaluate_confirmations, layer3_score, zone_confirms_layer3
from .decision import SizeLevel, Tier, decide
from .gates import CooldownManager
from .level_eval import CapitalSpec, SignalSpec, classify_capabilities, level_capabilities
from .level_gate import PROFILE_LEVEL
from .market_session import resolve_session, us_dst_active
from .position_fsm import PositionFSM, build_tp_plan
from .regime import MarketRegime, RegimeEngine
from .risk.capital import daily_atr_percentile
from .risk.profiles import RiskProfile
from .weekend import weekend_close_plan, weekend_plan_utc
from .zones_engine import ZoneEngine
from ..strategy_api.zones import Zone, best_zone

log = get_logger("engine")

# MT5 trade retcode: the position is already gone at the venue.
RETCODE_POSITION_CLOSED = 10036



def dominant_entry_priority(signals: Any, priority_of: Any) -> int | None:
    """Highest-priority entry on the bar; lower-priority entries wait."""
    values = [
        priority_of(signal)
        for signal in signals
        if getattr(signal, "kind", None) == "entry" and getattr(signal, "side", None)
    ]
    return min(values) if values else None


@dataclass
class EngineResult:
    ticks: int = 0
    bars: int = 0
    signals: int = 0
    # Completeness of the signal journal: every generated entry signal must
    # produce exactly one row, even when it is filtered before decision.
    signals_seen: int = 0
    signals_journaled: int = 0
    signals_unlogged: int = 0
    intents: int = 0
    approved: int = 0
    rejected: int = 0
    trades_closed: int = 0
    uncertain: int = 0
    rejected_by_broker: int = 0
    bias_blocked: int = 0
    priority_skipped: int = 0
    noise_rejected: int = 0
    gate_rejected: int = 0
    gate_downgraded: int = 0
    zone_confirmed: int = 0
    amplified: int = 0
    watch: int = 0
    level_blocked: int = 0
    weekend_flattens: int = 0
    d_hard_floor: int = 0
    funnel: dict[str, int] = field(default_factory=dict)
    confluence_blocked: int = 0
    confirm_only_skipped: int = 0
    final_equity: float = 0.0
    net_pnl: float = 0.0
    stopped_reason: str = ""
    final_state: str = "NORMAL"
    stats: dict[str, Any] = field(default_factory=dict)
    rejects: dict[str, int] = field(default_factory=dict)


class TradingEngine:
    def __init__(
        self,
        *,
        broker: Any,
        feed: Any,
        clock: Any,
        journal: Any,
        builder: Any,
        host: Any,
        pipeline: Any,
        risk: Any,
        coordinator: Any,
        positions: Any,
        reconciler: Any,
        symbol: Symbol,
        info: Any,
        profile: RiskProfile,
        notifier: Any = None,
        heartbeat: Any = None,
        config_hash: str = "",
        sample_every: int = 240,
        direction: str = "both",
        friday_flat_hour_utc: int | None = 19,
        confluence_window_minutes: float = 30.0,
        gates: Any = None,
        zone_engine: Any = None,
        zone_confirmation_min_score: int = 55,
        zone_confirmation_max_atr: float = 2.0,
        history_bars: int = 9600,
        weekend: Any = None,
        news: Any = None,
        level_gate: Any = None,
        profile_name: str = "",
        session_offset_hours: float = 0.0,
        commission_per_lot: float = 7.0,
        slippage_points: float = 2.0,
        zone_filter_min: float = 50.0,
        layer3_enabled: bool = True,
    ) -> None:
        self._broker = broker
        self._feed = feed
        self._clock = clock
        self._journal = journal
        self._builder = builder
        self._host = host
        self._pipeline = pipeline
        self._risk = risk
        self._coordinator = coordinator
        self._positions = positions
        self._reconciler = reconciler
        self._symbol = symbol
        self._info = info
        self._profile = profile
        self._notifier = notifier
        self._heartbeat = heartbeat
        self._config_hash = config_hash
        self._sample_every = sample_every
        # Execution audit: latency, slippage and the real spread at fill time.
        self._exec_meta: dict[int, dict[str, Any]] = {}
        # Partial take-profits realise cash in slices; accumulate them so the
        # final journal row reports the whole trade, not just its last slice.
        self._partials: dict[int, dict[str, float]] = {}
        self._direction = direction if direction in ("both", "long", "short") else "both"
        self._friday_flat_hour = friday_flat_hour_utc
        self._arbiter = SignalArbiter(window_minutes=confluence_window_minutes)
        self._gates = gates if gates is not None else CooldownManager()
        self._zone_engine = zone_engine if zone_engine is not None else ZoneEngine()
        self._regime = RegimeEngine()
        self._min_zone_confirmation = int(zone_confirmation_min_score)
        self._zone_confirmation_max_atr = float(zone_confirmation_max_atr)
        self._weekend = weekend
        self._news = news
        self._level_gate = level_gate
        self._profile_name = profile_name or profile.name
        self._session_offset_hours = float(session_offset_hours)
        self._commission_per_lot = float(commission_per_lot)
        self._slippage_points = float(slippage_points)
        self._zone_filter_min = float(zone_filter_min)
        self._layer3_enabled = bool(layer3_enabled)
        self._signal_ids: dict[int, str] = {}
        self._watch_notified: set[str] = set()
        self._level_notified: set[str] = set()
        self._pending_signal: dict[str, Any] | None = None
        self._filtered_signal_seq = 0
        self._weekend_state: str = ""
        self._history_bars = max(600, int(history_bars))
        self._atr_percentile: float | None = None
        self._daily_key: Any = None
        self._regime_state: MarketRegime | None = None
        self._zones: tuple[Zone, ...] = ()
        self.result = EngineResult()
        self._last_equity_sample: datetime | None = None
        self._last_reconcile_ok: datetime | None = None
        self._reconcile_interval = timedelta(minutes=5)
        self._fsm_netting_notified = False
        self._last_gates_snapshot: dict[str, Any] | None = None
        # POS-02: a flatten that could not complete is retried on later bars and
        # never reported as flat until the book is empty.
        self._pending_flatten: str | None = None
        self._flatten_failures = 0

    # ------------------------------------------------------------------
    def _emit(self, event_type: str, payload: dict[str, Any], *, corr: str = "") -> None:
        if self._journal is None:
            return
        self._journal.append(
            Event(type=event_type, payload=payload, ts=self._clock.now(), correlation_id=corr)
        )

    def _notify(self, level: str, title: str, body: str, *, dedup_key: str = "") -> bool:
        """Notifications never raise and never block the trading loop."""
        notifier = getattr(self, "_notifier", None)
        if notifier is None:
            return False
        try:
            return bool(notifier.send(level, title, body, dedup_key=dedup_key))
        except Exception:  # noqa: BLE001 - an alert must not stop risk handling
            log.exception("notifier failed")
            return False

    @staticmethod
    def _reconcile_detail(report: Any) -> str:
        parts: list[str] = []
        for name in ("missing", "orphan", "volume_drift", "protection_lost"):
            values = getattr(report, name, ()) or ()
            if values:
                parts.append(f"{name}={list(values)}")
        details = getattr(report, "details", ()) or ()
        if details:
            parts.append("; ".join(str(item) for item in list(details)[:3]))
        return ", ".join(parts) or "divergence without detail"

    def _persist_gates(self) -> None:
        """Checkpoint gate burns when they move (bar boundaries and close events)."""
        update = getattr(self._risk, "update_aux", None)
        snapshot = getattr(self._gates, "snapshot", None)
        if update is None or snapshot is None:
            return
        state = snapshot()
        if self._last_gates_snapshot == state:
            return
        try:
            update("gates", state)
            self._last_gates_snapshot = state
        except Exception:  # noqa: BLE001 - a persistence failure must not trade
            log.exception("gate state persistence failed")

    def _funnel(self, stage: str) -> None:
        self.result.funnel[stage] = self.result.funnel.get(stage, 0) + 1

    def _context(
        self, tick: Tick, now: datetime, atr: float | None = None, regime: MarketRegime | None = None
    ) -> RiskContext:
        return RiskContext(
            account=self._broker.account(),
            positions=self._broker.positions(),
            symbol_info=self._info,
            tick=tick,
            now=now,
            atr=atr,
            session_open=self._clock.session(self._symbol) != "CLOSED",
            news_blackout=self._news_blackout(now),
            session=(regime.session if regime is not None else "asia"),
            atr_percentile=self._atr_percentile,
            broker_now=self._clock.broker_now(),
            reconciled=(
                self._last_reconcile_ok is not None
                and (now - self._last_reconcile_ok) <= self._reconcile_interval
            ),
        )

    def _news_blackout(self, now_utc: datetime) -> bool:
        if self._news is None:
            return False
        try:
            return bool(self._news.blackout(now_utc).blackout)
        except Exception:  # noqa: BLE001 - an alerting layer must not stop trading
            log.exception("news calendar evaluation failed")
            return False

    def _weekend_override_active(self) -> bool:
        aux = getattr(self._risk, "aux", None)
        if aux is None:
            return False
        raw = aux("weekend_override_until")
        if not raw:
            return False
        try:
            until = datetime.fromisoformat(str(raw))
        except ValueError:
            return False
        now = self._clock.now().wall
        if until.tzinfo is None and now.tzinfo is not None:
            until = until.replace(tzinfo=now.tzinfo)
        return now < until

    # ------------------------------------------------------------------
    def start(self) -> None:
        info = self._broker.connect()
        self._emit(
            Ev.SESSION_STARTED,
            {
                "server": info.server,
                "trade_mode": info.trade_mode,
                "profile": self._profile.name,
                "symbol": str(self._symbol),
                "config_hash": self._config_hash,
                "restarted": bool(getattr(self._risk, "restarted", False)),
                "restored_state": self._risk.state().value,
            },
        )
        account = self._broker.account()
        self._risk.begin(float(account.equity.amount), self._clock.now().wall)
        gate = self._level_gate
        if gate is not None:
            aux_read = getattr(self._risk, "aux", None)
            saved_level = aux_read("level_state") if aux_read is not None else None
            if not gate.restore(saved_level):
                gate.bootstrap(float(account.equity.amount), self._profile_name)
            gate.set_onboarding_ack(bool(aux_read("onboarding_ack")) if aux_read is not None else False)
        report = self._reconciler.run()
        # Restart adoption (ADR-013 P0): a venue position with no book entry is
        # real exposure. Adopt it (broker truth wins, time-stop only), journal
        # each ticket and re-run reconcile; entries stay blocked until the
        # post-adoption reconcile is clean and nothing is unmanaged.
        adopt_orphans = getattr(self._reconciler, "adopt_orphans", None)
        has_unmanaged = getattr(self._reconciler, "has_unmanaged_exposure", None)
        if adopt_orphans is not None and has_unmanaged is not None and has_unmanaged():
            adopted = adopt_orphans(
                max_holding_hours=float(getattr(self._profile, "max_holding_hours", 0.0) or 0.0)
            )
            if adopted:
                report = self._reconciler.run()
        unmanaged = bool(has_unmanaged()) if has_unmanaged is not None else False
        if not report.clean or unmanaged:
            self._risk.force_quarantine("startup reconciliation divergence")
            self._host.pause_all()
        else:
            self._last_reconcile_ok = self._clock.now().wall
        restore = getattr(self._gates, "restore", None)
        aux = getattr(self._risk, "aux", None)
        if restore is not None and aux is not None:
            saved = aux("gates")
            if saved and restore(saved):
                self._last_gates_snapshot = saved
                log.warning("cooldown gate state restored", extra={"fields": {"from": "state db"}})
        self._host.warm_up()

    def run(self) -> EngineResult:
        self.start()
        for tick in self._feed.stream():
            self._on_tick(tick)
        self._finish()
        return self.result

    # ------------------------------------------------------------------
    def _on_tick(self, tick: Tick) -> None:
        if hasattr(self._clock, "advance"):
            self._clock.advance(tick.ts_event.wall)
        self.result.ticks += 1

        # 0) reconciliation first: a stale snapshot must never approve an entry.
        now = self._clock.now().wall
        if (
            self._last_reconcile_ok is None
            or (now - self._last_reconcile_ok) >= self._reconcile_interval
        ):
            report = self._reconciler.run()
            if report.clean:
                self._last_reconcile_ok = now
            else:
                self._risk.force_quarantine("periodic reconciliation divergence")
                self._host.pause_all()
                self._notify(
                    "critical",
                    "Reconciliation drift",
                    self._reconcile_detail(report),
                    dedup_key="reconciliation-drift",
                )

        if self._heartbeat is not None:
            moment = self._clock.now()
            try:
                if self._heartbeat.should_beat(moment):
                    self._heartbeat.beat(
                        {
                            "ticks": self.result.ticks,
                            "state": self._risk.state().value,
                            "equity": float(self._broker.account().equity.amount),
                            "positions": self._positions.count(),
                        }
                    )
            except Exception:  # noqa: BLE001 - a heartbeat file is never critical path
                log.warning("heartbeat write failed", exc_info=True)

        # 1) venue settles protective orders for this tick
        for trade in self._broker.on_market_tick(tick):
            self._settle(trade)

        # 2) aggregate and act on closed bars
        for bar in self._builder.on_tick(tick):
            self.result.bars += 1
            self._on_bar(bar, tick)

        # 3) marks / excursion tracking
        self._positions.mark({self._symbol: (tick.bid, tick.ask)})
        if self.result.ticks % self._sample_every == 0:
            self._sample_equity(tick.ts_event.wall)

    def _on_bar(self, bar: Any, tick: Tick) -> None:
        now = self._clock.now().wall
        # Operator CLI writes (pause/level approval) land in the state DB; adopt
        # aux keys at bar boundaries so they take effect without a restart.
        reload_aux = getattr(self._risk, "reload_aux", None)
        if reload_aux is not None:
            reload_aux()
        regime: MarketRegime | None = self._regime_state
        if bar.timeframe == "M15":
            bars_m15 = self._builder.bars("M15", 900)
            regime = self._regime.snapshot(bars_m15)
            self._regime_state = regime
            self._zones = self._zone_engine.snapshot(bars_m15, now=now)
            daily_event = self._zone_engine.take_daily_event()
            if daily_event is not None:
                self._emit(Ev.DAILY_LEVELS, daily_event)
            self._gates.on_bar(zones=self._zones, regime=regime)
            for gate_event in self._gates.drain_events():
                self._emit(Ev.GATE_EVENT, gate_event)
            self._persist_gates()
            self._update_atr_percentile(now)
        atr = regime.atr_m15 if regime is not None else indicators.atr(self._builder.bars(bar.timeframe, 40), 14)
        ctx = self._context(tick, now, atr, regime)
        self._risk.on_mark(ctx)
        self._sync_level(ctx)

        state = self._risk.state()
        if self._weekend is not None:
            plan = weekend_plan_utc(ctx.now, self._info, self._weekend)
            state_key = plan.reason if plan.flatten else ""
            if state_key != self._weekend_state:
                self._weekend_state = state_key
                self._emit(
                    "WeekendClosePlan",
                    {
                        "flatten": bool(plan.flatten),
                        "reason": plan.reason,
                        "deadline": None if plan.deadline is None else plan.deadline.isoformat(),
                        "window_start": (
                            None if plan.window_start is None else plan.window_start.isoformat()
                        ),
                        "open_positions": ctx.open_positions,
                        "override": self._weekend_override_active(),
                    },
                )
            if plan.flatten and not self._weekend_override_active():
                self.result.weekend_flattens += 1
                self._host.pause_all()
                self._flatten("weekend", order=self._weekend_close_order())
                return
        elif self._is_weekend_close(ctx.now):
            self._host.pause_all()
            self._flatten("weekend")
            return

        # Any non-NORMAL state blocks *new* entries (fail-closed). Existing
        # positions are still managed: tightening a stop or closing is always
        # allowed, because that reduces risk.
        if state is RiskState.NORMAL:
            self._host.resume_all()
            self._apply_management(ctx)
            self._process_signals(bar, tick, ctx)
            return

        self._host.pause_all()
        self._apply_management(ctx)
        if state is RiskState.KILLED:
            # A kill switch is not advisory: exposure goes away immediately.
            self._flatten("kill")

    def _sync_level(self, ctx: RiskContext) -> None:
        """Advance the capital-level FSM and persist it; entries are gated later."""
        gate = self._level_gate
        if gate is None or not getattr(gate, "enabled", False):
            return
        aux_read = getattr(self._risk, "aux", None)
        if aux_read is not None:
            gate.set_onboarding_ack(bool(aux_read("onboarding_ack")))
            saved = aux_read("level_state")
            if saved is not None and dict(saved) != gate.snapshot():
                gate.restore(saved)
        previous = gate.state.active_level
        decision = gate.step(
            equity=ctx.equity,
            drawdown_pct=self._risk.drawdown_pct,
            consecutive_losses=int(getattr(self._risk, "consecutive_losses", 0) or 0),
            open_positions=ctx.open_positions,
            now=ctx.broker_now or ctx.now,
            trades_today=self._risk.orders_today,
        )
        if decision is None:
            return
        payload = gate.dirty()
        if payload is not None:
            update = getattr(self._risk, "update_aux", None)
            if update is not None:
                update("level_state", payload)
        changed = gate.state.active_level is not previous
        if changed or decision.action in ("propose_upgrade", "expire_proposal"):
            self._emit(
                "CapitalLevel",
                {
                    "action": decision.action,
                    "level": gate.state.active_level.value,
                    "proposed": (
                        decision.proposed_level.value
                        if decision.proposed_level is not None
                        else None
                    ),
                    "reason": decision.reason,
                },
            )
            if changed:
                self._notify(
                    "critical" if decision.action == "downgrade" else "warn",
                    "Capital level changed",
                    f"{previous.value} -> {gate.state.active_level.value} ({decision.reason})",
                    dedup_key=f"level-{gate.state.active_level.value}",
                )
            elif decision.action == "propose_upgrade":
                self._notify(
                    "warn",
                    "Capital level upgrade proposed",
                    f"{gate.state.active_level.value} -> "
                    f"{decision.proposed_level.value if decision.proposed_level else '?'} "
                    f"({decision.reason}) - awaiting operator approval",
                    dedup_key=f"level-proposal-{decision.proposed_level.value if decision.proposed_level else '?'}",
                )

    def _apply_management(self, ctx: RiskContext) -> None:
        # POS-02: a flatten that failed is retried on later bars; until it
        # succeeds, closing exposure has priority over everything else.
        pending_flatten = getattr(self, "_pending_flatten", None)
        if pending_flatten is not None:
            if not self._flatten(pending_flatten):
                return
        fsm_tickets = {
            int(pos.ticket)
            for pos in self._positions.raw()
            if getattr(pos, "fsm", None) is not None
        }
        for action in self._risk.manage(ctx):
            if action.action == "close":
                # POS-02: every close result is inspected. A risk/time close that
                # does not settle the position is a fail-closed event.
                if not self._close_with_retries(
                    int(action.ticket), action.reason or "risk", prefix="mgmt"
                ):
                    self._fail_closed(
                        "CloseFailed",
                        f"risk close failed for ticket {action.ticket}",
                        [int(action.ticket)],
                    )
                continue
            if action.ticket in fsm_tickets:
                # The FSM owns breakeven/trailing for this ticket; letting the
                # risk engine move the same stop would fight it. A risk close
                # above is always honoured (that path is handled first).
                continue
            if action.sl is not None:
                self._coordinator.modify(action.ticket, sl=action.sl)
        self._apply_fsm(ctx)

    # -- close execution (POS-01 / POS-02) ------------------------------
    def _venue_positions(self) -> dict[int, Any] | None:
        """Venue truth, or None when it cannot be read (callers fail closed)."""
        try:
            return {int(position.ticket): position for position in self._broker.positions()}
        except Exception:  # noqa: BLE001 - unknown truth must never mean flat
            log.exception("venue positions unavailable")
            return None

    def _position_for_ticket(self, ticket: int) -> Any:
        lookup = getattr(self._positions, "get", None)
        if lookup is not None:
            position = lookup(int(ticket))
            if position is not None:
                return position
        for position in self._positions.raw():
            if int(position.ticket) == int(ticket):
                return position
        return None

    def _close_with_retries(self, ticket: int, reason: str, *, prefix: str) -> bool:
        """Close one ticket, inspecting every result and retrying bounded."""
        for attempt in range(1, 4):
            outcome = self._close_once(ticket, reason, prefix=f"{prefix}-{attempt}")
            if outcome == "settled":
                return True
            if outcome != "retry":
                return False
        return False

    def _close_once(self, ticket: int, reason: str, *, prefix: str) -> str:
        """One close attempt. Returns settled | retry | uncertain | terminal."""
        from ..domain.execution import ExitIntent

        position = self._position_for_ticket(ticket)
        if position is None:
            return "settled"
        intent = ExitIntent(
            intent_id=f"{prefix}-{ticket}",
            slot=position.slot,
            ticket=ticket,
            symbol=self._symbol,
            reason=reason,
            fraction=1.0,
        )
        result = self._coordinator.close_position(intent)
        ack = result.ack
        if result.status == "acked":
            if (
                ack is not None
                and ack.closed_trade is not None
                and float(ack.closed_trade.volume) > 0.0
            ):
                self._settle(ack.closed_trade)
                return "settled"
            return self._resolve_close_from_venue(ticket, reason, ack)
        if result.status == "rejected" and ack is not None:
            action = classify(int(ack.retcode))
            if action in (RetcodeAction.RETRY_PRICE, RetcodeAction.RETRY_STOPS):
                return "retry"
            if action is RetcodeAction.DONE:
                return self._resolve_close_from_venue(ticket, reason, ack)
            if int(ack.retcode) == RETCODE_POSITION_CLOSED:
                # Venue says the position is gone: settle it, never retry.
                return self._resolve_close_from_venue(ticket, reason, ack)
            return "terminal"
        if result.status == "uncertain":
            return "uncertain"
        return "retry"

    def _resolve_close_from_venue(self, ticket: int, reason: str, ack: Any) -> str:
        """Decide what a close that produced no closed_trade actually did."""
        venue = self._venue_positions()
        if venue is None:
            return "uncertain"
        if int(ticket) not in venue:
            executed = 0.0 if ack is None else float(ack.filled_volume or 0.0)
            if executed <= 0.0:
                # Somebody else (venue SL/TP) closed it; the settlement poll owns
                # the PnL. Do not fabricate a trade here.
                return "uncertain"
            position = self._position_for_ticket(ticket)
            if position is None:
                return "settled"
            price = float(ack.fill_price or 0.0) if ack is not None else 0.0
            self._settle(
                self._fallback_closed_trade(position, reason, executed=executed, price=price)
            )
            return "settled"
        position = self._position_for_ticket(ticket)
        if position is None:
            return "settled"
        try:
            remaining = float(getattr(venue[int(ticket)], "volume", position.volume))
        except Exception:  # noqa: BLE001
            return "uncertain"
        if remaining < float(position.volume) - 1e-9:
            # A slice executed but the venue has no closing deal for it: we
            # cannot book a trustworthy PnL, so fail closed instead of guessing.
            return "terminal"
        # The position is untouched: the close did not execute. Never resend
        # blindly from here; the caller decides with that fact in hand.
        return "uncertain"

    def _fallback_closed_trade(
        self, position: Any, reason: str, *, executed: float, price: float = 0.0
    ) -> ClosedTrade:
        """Book a close the venue executed but whose deal history lagged."""
        direction = 1.0 if position.side == "buy" else -1.0
        exit_price = float(price) if float(price) > 0.0 else float(position.open_price)
        gross = (
            (exit_price - float(position.open_price))
            * direction
            * float(self._info.contract_size)
            * float(executed)
        )
        known = {"sl", "tp", "manual", "strategy", "kill", "timeout"}
        return ClosedTrade(
            ticket=int(position.ticket),
            symbol=Symbol(position.symbol),
            side=position.side,
            volume=float(executed),
            open_price=float(position.open_price),
            close_price=exit_price,
            open_time=position.open_time,
            close_time=self._clock.now().wall,
            pnl_gross=money(gross),
            commission=money(0.0),
            swap=money(0.0),
            reason=reason if reason in known else "manual",  # type: ignore[arg-type]
        )

    def _fail_closed(self, kind: str, reason: str, tickets: Sequence[int]) -> None:
        """Latch a failed close/flatten: never silently keep the exposure."""
        remaining = [int(position.ticket) for position in self._positions.raw()]
        self._emit(
            kind,
            {
                "reason": reason,
                "tickets": [int(ticket) for ticket in tickets],
                "remaining": remaining,
            },
        )
        log.error(kind, extra={"fields": {"reason": reason, "remaining": remaining}})
        self._notify(
            "critical",
            f"{kind}",
            f"{reason}; still open: {remaining}",
            dedup_key=f"{kind}-{reason}",
        )
        try:
            self._risk.engage(RiskState.HALTED, reason, actor="system")
        except Exception:  # noqa: BLE001 - the latch must not mask the failure
            log.exception("could not latch HALTED after a failed close")
        pause = getattr(self._host, "pause_all", None)
        if pause is not None:
            try:
                pause()
            except Exception:  # noqa: BLE001
                log.exception("pause_all failed after a failed close")

    # -- three-layer TP execution ---------------------------------------
    def _apply_fsm(self, ctx: RiskContext) -> None:
        """Execute the pending action of every armed exit plan."""
        if getattr(self._positions, "mode", "hedging") != "hedging":
            return
        prices = {self._symbol: (ctx.tick.bid, ctx.tick.ask)}
        for pos, action in self._positions.fsm_actions(prices, ctx.atr):
            self._advance_fsm(pos, action, prices, ctx.atr)

    @staticmethod
    def _fsm_price(pos: Any, prices: dict[Symbol, tuple[float, float]]) -> float:
        bid, ask = prices[Symbol(pos.symbol)]
        return bid if pos.side == "buy" else ask

    def _advance_fsm(
        self,
        pos: Any,
        action: Any,
        prices: dict[Symbol, tuple[float, float]],
        atr: float | None,
    ) -> None:
        """Run one position's plan forward until it is blocked or finished."""
        fsm = getattr(pos, "fsm", None)
        if fsm is None:
            return
        attempts = 0
        seen: set[str] = set()
        while action is not None and not fsm.closed and attempts < 8:
            attempts += 1
            if action.kind == "CLOSE" and action.action_id in seen:
                # MT5-05: a retry-close that keeps failing must never loop.
                self._abandon_fsm(pos, fsm, f"close action {action.action_id} kept failing")
                return
            seen.add(action.action_id)
            if not self._execute_fsm_action(pos, fsm, action):
                return
            action = fsm.on_price(self._fsm_price(pos, prices), atr)

    def _abandon_fsm(self, pos: Any, fsm: Any, reason: str) -> None:
        """Give up on one plan safely: detach it, alert and fail closed."""
        try:
            fsm.mark_closed(f"abandoned:{reason}")
        except Exception:  # noqa: BLE001
            log.exception("fsm could not be marked closed")
        self._emit("CloseAbandoned", {"ticket": int(pos.ticket), "reason": reason})
        self._fail_closed("CloseAbandoned", reason, [int(pos.ticket)])

    def _execute_fsm_action(self, pos: Any, fsm: Any, action: Any) -> bool:
        """Send one FSM action to the venue. True when the ack was applied."""
        ticket = int(pos.ticket)
        if action.kind == "MODIFY_SL":
            if action.sl is None:
                raise InvariantError("MODIFY_SL FSM action without a stop price")
            if self._coordinator.modify(ticket, sl=action.sl):
                fsm.on_action_done(action)
                return True
            fsm.on_action_failed("modify_failed")
            return self._retry_close_queued(fsm)

        if pos.volume <= 0:
            fsm.on_action_failed("no_volume")
            return False
        if action.kind == "PARTIAL":
            fraction = min(1.0, max(0.0, float(action.volume) / float(pos.volume)))
            reason = action.reason or "tp"
        elif action.kind == "CLOSE":
            fraction = 1.0
            reason = action.reason or "tp"
        else:  # pragma: no cover - defensive
            raise InvariantError(f"unknown FSM action kind {action.kind!r}")

        from ..domain.execution import ExitIntent

        intent = ExitIntent(
            intent_id=f"fsm-{ticket}-{action.action_id}",
            slot=pos.slot,
            ticket=ticket,
            symbol=self._symbol,
            reason=reason,
            fraction=fraction,
        )
        result = self._coordinator.close_position(intent)
        ack = result.ack
        closed_trade = None if ack is None else ack.closed_trade
        if (
            result.status == "acked"
            and closed_trade is not None
            and float(closed_trade.volume) > 0.0
        ):
            fsm.on_action_done(action, filled_volume=closed_trade.volume)
            self._settle(closed_trade)
            return True

        # No settleable closed_trade: read venue truth before retrying anything.
        venue = self._venue_positions()
        if venue is not None and ticket not in venue:
            executed = 0.0 if ack is None else float(ack.filled_volume or 0.0)
            if executed > 0.0:
                # POS-01: the venue executed our close but history lagged; book it.
                price = float(ack.fill_price or 0.0) if ack is not None else 0.0
                fsm.on_action_done(action, filled_volume=executed)
                self._settle(
                    self._fallback_closed_trade(pos, reason, executed=executed, price=price)
                )
                return True
            # The venue closed the position itself (SL/TP); its settlement poll
            # will deliver the real deal. Detach the plan, do not retry.
            fsm.mark_closed("venue_close")
            return True

        if result.status == "rejected" and ack is not None:
            code = classify(int(ack.retcode))
            if code in (RetcodeAction.RETRY_PRICE, RetcodeAction.RETRY_STOPS):
                fsm.on_action_failed(f"close_{ack.retcode}")
                return self._retry_close_queued(fsm)
        # MT5-05: terminal rejects / unknown outcomes quarantine, never re-queue.
        self._abandon_fsm(
            pos,
            fsm,
            f"close not executed ({result.status}, retcode="
            f"{None if ack is None else ack.retcode})",
        )
        return False

    @staticmethod
    def _retry_close_queued(fsm: Any) -> bool:
        """Continue immediately when retries are exhausted and a close is queued."""
        pending = fsm.pending
        return pending is not None and pending.kind == "CLOSE"

    # -- capital levels and the signal journal -------------------------
    @staticmethod
    def _level_value(name: str) -> str:
        return {
            "BASE": "base",
            "LOW": "low_risk",
            "MEDIUM": "medium_risk",
            "HIGH": "high_risk",
        }.get(str(name).upper(), str(name).lower())

    def _active_level_name(self) -> str:
        """Current execution level, or the profile default while the gate is off."""
        gate = self._level_gate
        if gate is not None and getattr(gate, "enabled", False):
            return gate.state.active_level.value
        return PROFILE_LEVEL.get(self._profile_name, CapitalLevel.MEDIUM_RISK).value

    def _session_info(self, now_utc: datetime) -> Any:
        try:
            return resolve_session(now_utc, dst_mode="none")
        except Exception:  # noqa: BLE001 - session metadata must never stop trading
            return None

    def _rr_net(self, intent: EntryIntent, ctx: RiskContext) -> float:
        """R:R after the round-trip cost estimate (spec PART 2.3).

        cost_price is expressed in price units: half spread + configured
        slippage + commission per ounce.
        """
        risk = abs(float(intent.entry_ref) - float(intent.stop))
        if risk <= 0 or intent.target is None:
            return 0.0
        info = self._info
        point = float(info.point) or 0.01
        cost_price = (
            float(ctx.tick.spread) / 2.0
            + float(self._slippage_points) * point
            + float(self._commission_per_lot) / max(1e-9, float(info.contract_size))
        )
        reward = abs(float(intent.target) - float(intent.entry_ref))
        return max(0.0, reward - cost_price) / (risk + cost_price)

    def _level_block_reason(self, ctx: RiskContext, tier_value: str) -> str:
        gate = self._level_gate
        if gate is None or not getattr(gate, "enabled", False):
            return ""
        if gate.active(ctx.equity) is None:
            return gate.stop_reason(ctx.equity) or "level_blocked"
        session = self._session_info(ctx.now)
        if session is not None and not gate.session_allowed(session.name):
            return "level_session"
        if not gate.tier_allowed(tier_value):
            return "level_tier"
        cap = gate.max_trades_per_day()
        if cap is not None and self._risk.orders_today >= cap:
            return "level_max_trades"
        return ""

    def _signal_capabilities(
        self,
        intent: EntryIntent,
        decision: Any,
        ctx: RiskContext,
        session_name: str,
        zone_score_adj: float = 0.0,
    ) -> tuple[SignalSpec, list[Any]]:
        info = self._info
        equity = float(ctx.equity)
        stop = abs(float(intent.entry_ref) - float(intent.stop))
        spread_ratio = float(ctx.tick.spread) / stop if stop > 0 else 0.0
        spec = SignalSpec(
            signal_id=intent.intent_id,
            tier=decision.tier.value,
            entry=float(intent.entry_ref),
            sl=float(intent.stop),
            tp=None if intent.target is None else float(intent.target),
            rr_net=self._rr_net(intent, ctx),
            zone_score_adj=zone_score_adj,
            session=session_name,
            news_blackout=bool(ctx.news_blackout),
            spread_ratio=spread_ratio,
            direction=intent.side,
        )
        capital = CapitalSpec(
            min_lot=float(info.min_volume),
            lot_step=float(info.volume_step),
            tick_value=float(getattr(info, "tick_value", 0.0) or 0.0),
            tick_size=float(getattr(info, "tick_size", info.point) or info.point),
            contract_size=float(info.contract_size),
            point=float(info.point),
            equity=equity,
        )
        policies = {level: policy_for(level) for level in CapitalLevel}
        risk_map = {
            level: risk_pct_for_level(
                level, decision.tier.value, equity, base_enabled=True
            )
            for level in CapitalLevel
        }
        rows = level_capabilities(
            spec,
            capital,
            policies,
            equity,
            risk_pct=risk_map,
            trades_today=self._risk.orders_today,
            drawdown_pct=self._risk.drawdown_pct,
            consecutive_losses=self._risk.consecutive_losses,
            gate_b_burn=False,
            gate_c_hedge=False,
            gate_d_hard=False,
        )
        return spec, rows

    def _layer3_votes(
        self, tags: dict[str, Any], ctx: RiskContext, bars_h1: Sequence[Any], side: str, entry: float
    ) -> dict[str, int]:
        """Seven independent layer-3 votes (ADR-033/035). Each is -1, 0 or +1."""
        votes: dict[str, int] = {}
        volume = tags.get("volume_ratio")
        votes["volume"] = 1 if volume is not None and float(volume) >= 1.2 else 0
        votes["pin_engulfing"] = 1 if str(tags.get("candle_pattern") or "") else 0
        if bars_h1:
            # ADR-033: a real EMA200-H1 plus a defined 3-bar slope; missing
            # history/slope is neutral (CONF-05), never an accidental +1.
            closes = [float(bar.c) for bar in bars_h1]
            votes["ema200_h1"] = ema200_h1_vote(entry, closes, side=side)
        adx = self._regime_state.adx_h1 if self._regime_state is not None else None
        votes["adx"] = 1 if adx is not None and adx >= 25 else 0
        session = self._session_info(ctx.now)
        name = session.name if session is not None else "closed"
        votes["session"] = 1 if name in ("london", "overlap", "ny") else (
            -1 if name in ("asia", "late_ny") else 0
        )
        votes["daily_level"] = 1 if str(tags.get("zone_source") or "") == "daily" else 0
        votes["sr_zone"] = 1 if tags.get("zone_confirmed") else 0
        return votes

    def _confirmation_reading(
        self, intent: EntryIntent, tags: dict[str, Any], ctx: RiskContext, atr: float
    ) -> tuple[float, tuple[str, ...], Any]:
        """Five independent factors plus the other-strategy approval (ADR-031/033)."""
        bars_m15 = list(self._builder.bars("M15", 160))
        zone = None
        zone_id = str(tags.get("zone_id") or "")
        if zone_id:
            zone = next((item for item in self._zones if item.zone_id == zone_id), None)
        rsi = indicators.rsi([bar.c for bar in bars_m15], 14) if bars_m15 else None
        report = evaluate_confirmations(
            bars_m15,
            side=intent.side,
            zone=zone,
            entry=float(intent.entry_ref),
            atr=float(atr or 0.0),
            rsi_m15=rsi,
            bars_h1=list(self._builder.bars("H1", 320)),
        )
        confirmations = tuple(
            name for name, value in report.factors.items() if value > 0
        )
        return report.total, confirmations, report

    def _prepare_signal_journal(
        self,
        intent: EntryIntent,
        decision: Any,
        ctx: RiskContext,
        confirmations: Sequence[Any],
        tags: dict[str, Any],
    ) -> None:
        session = self._session_info(ctx.now)
        session_name = session.name if session is not None else "closed"
        zone_score_adj = float(tags.get("zone_score", 0.0) or 0.0)
        spec, rows = self._signal_capabilities(
            intent, decision, ctx, session_name, zone_score_adj=zone_score_adj
        )
        levels = [
            SignalLevelRecord(
                signal_id=spec.signal_id,
                level=self._level_value(row.level),
                eligible=bool(row.eligible),
                reason=row.reason,
                would_be_lot=row.would_be_lot,
                would_be_risk_pct=row.would_be_risk_pct,
                would_be_risk_dollars=row.would_be_risk_dollars,
                min_capital_needed=None
                if row.min_capital_needed == float("inf")
                else row.min_capital_needed,
                capital_gap=None if row.capital_gap == float("inf") else row.capital_gap,
                capacity_only=bool(row.capacity_only),
                session=session_name,
                tier=decision.tier.value,
                zone_score_adj=zone_score_adj,
                sl_price=float(intent.stop),
                equity_at_signal=float(ctx.equity),
                evaluated_at=ctx.now.isoformat(),
                params_snapshot={"config_hash": self._config_hash},
            )
            for row in rows
        ]
        best: str | None = None
        for row in rows:
            if row.eligible:
                best = self._level_value(row.level)
                break
        record = SignalRecord(
            signal_id=spec.signal_id,
            ts_utc=ctx.now.isoformat(),
            symbol=str(intent.symbol),
            side=intent.side,
            strategy=intent.strategy,
            session=session_name,
            session_utc_offset=float(getattr(self, "_session_offset_hours", 0.0)),
            is_dst_active=bool(us_dst_active(ctx.now)),
            minutes_into_session=int(session.minutes_into_session) if session is not None else 0,
            entry=float(intent.entry_ref),
            sl=float(intent.stop),
            tp1=None if intent.target is None else float(intent.target),
            tp2=None,
            sl_price=float(intent.stop),
            rr_net=spec.rr_net,
            atr_h1=None,
            adx_h1=None,
            news_flag=bool(ctx.news_blackout),
            spread_at_signal=float(ctx.tick.spread),
            zone_score_raw=float(tags.get("zone_score", 0.0) or 0.0),
            zone_score_adj=float(tags.get("zone_score", 0.0) or 0.0),
            signal_score=float(tags.get("signal_score", 0.0) or 0.0),
            composite_raw=None,
            composite_adj=None,
            tier=decision.tier.value,
            confirmations=int(decision.confirmation_count),
            confirmation_count=float(decision.confirmation_count),
            confirmation_set=list(decision.confirmation_set),
            tier_base=decision.tier_base.value,
            layer3_score=float(decision.layer3_score),
            layer3_delta=int(decision.layer3_delta),
            tier_final=decision.tier.value,
            d_hard_floor=bool(decision.d_hard_floor),
            gate_status={},
            equity_at_signal=float(ctx.equity),
            params_snapshot={
                "config_hash": self._config_hash,
                "profile": self._profile_name,
            },
        )
        self._pending_signal = {"record": record, "levels": levels, "best": best}

    def _record_filtered_signal(
        self,
        signal: Any,
        tick: Tick,
        ctx: RiskContext,
        reason: str,
        strategy_id: str,
    ) -> None:
        """Journal a signal that is filtered before the decision pipeline.

        Direction bias, entry priority and confirm-only filters never reach the
        decision pipeline; the user needs every generated entry signal in the
        journal to compare generated versus traded signals, so each becomes an
        active_decision=filtered row with its filter reason.
        """
        if self._journal is None or signal.side not in ("buy", "sell"):
            return
        session = self._session_info(ctx.now)
        session_name = session.name if session is not None else "closed"
        entry = signal.entry_hint
        if entry is None:
            entry = tick.ask if signal.side == "buy" else tick.bid
        digits = int(self._info.digits)
        self._filtered_signal_seq += 1
        stop = None if signal.stop is None else round(float(signal.stop), digits)
        target = None if signal.target is None else round(float(signal.target), digits)
        record = SignalRecord(
            signal_id=f"{str(signal.slot)[:8]}-filtered-{self._filtered_signal_seq:06d}",
            ts_utc=ctx.now.isoformat(),
            symbol=str(signal.symbol),
            side=signal.side,
            strategy=strategy_id or str(signal.slot),
            session=session_name,
            session_utc_offset=float(getattr(self, "_session_offset_hours", 0.0)),
            is_dst_active=bool(us_dst_active(ctx.now)),
            minutes_into_session=int(session.minutes_into_session) if session is not None else 0,
            entry=round(float(entry), digits),
            sl=stop,
            tp1=target,
            sl_price=stop,
            news_flag=bool(ctx.news_blackout),
            spread_at_signal=float(ctx.tick.spread),
            tier="",
            active_level=self._active_level_name(),
            active_decision="filtered",
            active_reason=reason,
            was_missed_opportunity=False,
            params_snapshot={
                "config_hash": self._config_hash,
                "profile": self._profile_name,
            },
        )
        try:
            self._journal.record_signal(record)
            self.result.signals_journaled += 1
        except Exception:  # noqa: BLE001 - analytics must not stop the trading loop
            log.exception("signal journal write failed")

    def _record_signal(
        self,
        outcome: str,
        reason: str = "",
        *,
        order: Any = None,
    ) -> None:
        pending = getattr(self, "_pending_signal", None)
        if pending is None:
            return
        self._pending_signal = None
        if self._journal is None:
            return
        record = pending["record"]
        level_name = self._active_level_name()
        lot = risk_pct = risk_dollars = None
        if order is not None:
            lot = float(order.volume)
            risk_pct = float(order.risk.risk_pct)
            risk_dollars = float(order.risk.risk_amount)
        missed = bool(outcome != "executed" and pending["best"] is not None)
        updated = replace(
            record,
            active_level=level_name,
            active_decision=outcome,
            active_reason=reason,
            active_lot=lot,
            active_risk_pct=risk_pct,
            active_risk_dollars=risk_dollars,
            best_eligible_level=pending["best"],
            was_missed_opportunity=missed,
        )
        try:
            self._journal.record_signal(updated)
            self.result.signals_journaled += 1
            if pending["levels"]:
                self._journal.record_signal_levels(updated.signal_id, pending["levels"])
        except Exception:  # noqa: BLE001 - analytics must not stop the loop
            log.exception("signal journal write failed")

    def _process_signals(self, bar: Any, tick: Tick, ctx: RiskContext) -> None:
        signals = list(self._host.on_bar(bar))
        self.result.signals += len(signals)

        def priority(signal: Any) -> int:
            binding = self._host.bindings.get(signal.slot)
            return binding.strategy.priority if binding is not None else 100

        signals.sort(key=priority)
        seen_before = self.result.signals_seen
        journaled_before_run = self.result.signals_journaled
        atr = (self._regime_state.atr_m15 if self._regime_state else None) or 0.0
        adx_h1 = self._regime_state.adx_h1 if self._regime_state else None
        def direction_allowed(signal: Any) -> bool:
            if signal.kind != "entry" or signal.side is None:
                return False
            if self._direction == "long" and signal.side == "sell":
                return False
            if self._direction == "short" and signal.side == "buy":
                return False
            return True

        dominant = dominant_entry_priority(
            [signal for signal in signals if direction_allowed(signal)], priority
        )

        for signal in signals:
            self._pending_signal = None
            journaled_before = self.result.signals_journaled
            is_entry = signal.kind == "entry" and signal.side is not None
            binding = self._host.bindings.get(signal.slot)
            strategy_id = binding.strategy_id if binding is not None else ""
            if is_entry:
                self.result.signals_seen += 1
                self._funnel("received")
                if self._direction == "long" and signal.side == "sell":
                    # The reason names the filtered signal's direction: a short
                    # signal is excluded by the long-only bias (and vice versa).
                    self.result.bias_blocked += 1
                    self._funnel("prefiltered")
                    self._record_filtered_signal(
                        signal, tick, ctx, "direction_short_only", strategy_id
                    )
                    continue
                if self._direction == "short" and signal.side == "buy":
                    self.result.bias_blocked += 1
                    self._funnel("prefiltered")
                    self._record_filtered_signal(
                        signal, tick, ctx, "direction_long_only", strategy_id
                    )
                    continue
                if dominant is not None and priority(signal) > dominant:
                    # A higher-priority entry exists on this bar: the S/R plan wins.
                    self.result.priority_skipped += 1
                    self._funnel("prefiltered")
                    self._record_filtered_signal(
                        signal, tick, ctx, "priority_skipped", strategy_id
                    )
                    continue
            confirmations: tuple[str, ...] = ()
            tags: dict[str, Any] = dict(signal.tags)
            other_strategy = False
            if signal.kind == "entry" and signal.side is not None and strategy_id:
                signal, tags = self._enrich_signal(signal, strategy_id, tick, atr)
                confirmations = self._arbiter.confirmations(
                    ts=ctx.now,
                    strategy=strategy_id,
                    symbol=str(signal.symbol),
                    side=signal.side,
                )
                # ADR-031: the other strategy's same-direction signal is the +1
                # confirmation; sr_zone moved to layer 3 (ADR-035).
                other_strategy = has_other_strategy_confirmation(confirmations, strategy_id)
                if tags.get("zone_confirmed"):
                    self.result.zone_confirmed += 1
                if binding is not None and binding.confirm_only:
                    self.result.confirm_only_skipped += 1
                    self._funnel("prefiltered")
                    self._record_filtered_signal(
                        signal, tick, ctx, "confirm_only", strategy_id
                    )
                    continue

            intent = self._pipeline.to_intent(
                signal,
                strategy_id=strategy_id,
                info=self._info,
                tick=tick,
                now=ctx.now,
                confirmations=confirmations,
            )
            if intent is None:
                self._funnel("prefiltered")
                self._record_filtered_signal(signal, tick, ctx, "invalid_intent", strategy_id)
                continue

            if not isinstance(intent, EntryIntent):
                self.result.intents += 1
                result = self._coordinator.close_position(intent)
                if result.ack and result.ack.closed_trade:
                    self._settle(result.ack.closed_trade)
                continue

            rr_net = self._rr_net(intent, ctx)
            factor_total, factor_names, _report = self._confirmation_reading(
                intent, tags, ctx, atr
            )
            confirmation_count = factor_total + (1.0 if other_strategy else 0.0)
            confirmation_set = factor_names + (("other_strategy",) if other_strategy else ())
            votes = self._layer3_votes(
                tags,
                ctx,
                list(self._builder.bars("H1", 320)),
                intent.side,
                float(intent.entry_ref),
            )
            layer3 = layer3_score(votes) if self._layer3_enabled else layer3_score({})
            decision = decide(
                confirmation_count=confirmation_count,
                layer3_score=layer3.score,
                zone_score=float(tags.get("zone_score", 0.0) or 0.0),
                rr_net=rr_net,
                rr_absolute_floor=1.0,
                min_zone=self._zone_filter_min,
                confirmation_set=confirmation_set,
            )
            self._prepare_signal_journal(intent, decision, ctx, confirmations, tags)
            self._emit(
                Ev.DECISION_EVALUATED,
                {
                    "intent_id": intent.intent_id,
                    "slot": intent.slot,
                    "strategy": intent.strategy,
                    "side": intent.side,
                    "signal_score": round(float(tags.get("signal_score", 0.0) or 0.0), 3),
                    "zone_score": int(tags.get("zone_score", 0) or 0),
                    "rr_net": round(rr_net, 3),
                    "confirmation_count": round(confirmation_count, 2),
                    "confirmation_set": list(confirmation_set),
                    "tier_base": decision.tier_base.value,
                    "tier": decision.tier.value,
                    "layer3_score": round(decision.layer3_score, 2),
                    "layer3_delta": decision.layer3_delta,
                    "d_hard_floor": decision.d_hard_floor,
                    "reasons": list(decision.reasons),
                    "confirmations": list(confirmations),
                },
            )
            if decision.hard_floor:
                self.result.d_hard_floor += 1
                self._funnel("d_hard_floor")
                reason = ";".join(decision.reasons) or "d_hard_floor"
                self.result.rejects[reason] = self.result.rejects.get(reason, 0) + 1
                self._record_signal("d_hard_floor", reason)
                continue
            blocked = self._level_block_reason(ctx, decision.tier.value)
            if blocked:
                self.result.level_blocked += 1
                self._funnel("level_blocked")
                self.result.rejects[blocked] = self.result.rejects.get(blocked, 0) + 1
                self._record_signal("skipped", blocked)
                continue
            if decision.rejected:
                self.result.noise_rejected += 1
                self._funnel("tier_rejected")
                for reason in decision.reasons or ("noise",):
                    self.result.rejects[reason] = self.result.rejects.get(reason, 0) + 1
                self._record_signal("rejected", ";".join(decision.reasons) or "noise")
                continue

            gate = self._gates.evaluate(
                side=intent.side,
                zone_id=str(tags.get("zone_id") or ""),
                signal_score=float(tags.get("signal_score", 0.0) or 0.0),
                zone_score=int(tags.get("zone_score", 0) or 0),
                setup_type=str(tags.get("setup_type", "")),
                tier=decision.tier,
                atr=atr,
                adx_h1=adx_h1,
                positions=ctx.positions,
                ctx=ctx,
            )
            self._emit(
                Ev.GATE_EVALUATED,
                {
                    "gate": gate.gate,
                    "verdict": gate.verdict,
                    "reason": gate.reason,
                    "bypass": gate.fields.get("bypass_type", ""),
                    "hedge": gate.hedge,
                    "size_factor": gate.size_factor,
                    "tier": decision.tier.value,
                    "zone_id": tags.get("zone_id"),
                },
            )
            if gate.rejected:
                self.result.gate_rejected += 1
                self._funnel("gate_rejected")
                key = gate.reason or "gate"
                self.result.rejects[key] = self.result.rejects.get(key, 0) + 1
                self._record_signal("rejected", key)
                continue
            if gate.size_factor < 1.0:
                self.result.gate_downgraded += 1

            # ADR-034: the old confluence amplifier is retired. The other-strategy
            # approval is already counted in the tier, so it must not also
            # multiply size (double-counting was the v5 defect).
            amplifier = 1.0
            smallest = gate.size_level is SizeLevel.SMALLEST
            tags["size_level"] = gate.size_level.value
            tags["amplifier"] = 1.0
            if smallest:
                tags["force_min_lot"] = True
            intent = self._stamp_intent(intent, decision, gate, tags)
            base_multiplier = binding.risk_multiplier if binding is not None else 1.0
            multiplier = (
                base_multiplier
                if smallest
                else float(intent.risk_multiplier) * base_multiplier * gate.size_factor
            )
            intent = replace(intent, risk_multiplier=max(0.0, min(1.5, multiplier)))

            self.result.intents += 1
            decision_result = self._risk.evaluate_entry(intent, ctx)
            if not decision_result.approved or decision_result.order is None:
                self.result.rejected += 1
                self._funnel("capital_rejected")
                for reason in decision_result.reasons:
                    self.result.rejects[reason] = self.result.rejects.get(reason, 0) + 1
                self._record_signal(
                    "skipped", ";".join(decision_result.reasons) or "capital_rejected"
                )
                continue

            self.result.approved += 1
            # CONF-01: only a signal admitted to execution may confirm a later
            # same-direction signal. D/NOISE/level/gate/capital rejects are
            # never registered, so they cannot inflate the next tier.
            self._arbiter.register(
                ts=ctx.now,
                slot=intent.slot,
                strategy=strategy_id,
                symbol=str(intent.symbol),
                side=str(intent.side),
            )
            self._funnel("approved")
            sent_at = time.monotonic()
            execution = self._coordinator.execute(decision_result.order)
            latency_ms = (time.monotonic() - sent_at) * 1000.0
            if execution.status == "acked" and execution.ack is not None and execution.ack.ticket:
                ticket = int(execution.ack.ticket)
                point = float(self._info.point) or 1.0
                fill = execution.ack.fill_price
                self._exec_meta[ticket] = {
                    "config_hash": self._config_hash,
                    "latency_ms": round(latency_ms, 2),
                    "spread_at_signal_pts": round(float(ctx.tick.spread) / point, 1),
                    "spread_at_fill_pts": round(float(ctx.tick.spread) / point, 1),
                    "entry_slippage_pts": (
                        None
                        if fill is None
                        else round(abs(float(fill) - float(intent.entry_ref)) / point, 1)
                    ),
                    "estimated_cost": dict(
                        decision_result.order.signal.get("_estimated_cost") or {}
                    ),
                    "signal_id": intent.intent_id,
                }
                self._record_signal("executed", "executed", order=decision_result.order)
                self._funnel("executed")
                self._risk.register_position(
                    ticket,
                    risk_amount=decision_result.order.risk.risk_amount,
                    initial_stop=decision_result.order.sl,
                    slot=decision_result.order.slot,
                )
                self._gates.note_execution(
                    ticket=int(execution.ack.ticket),
                    zone_id=str(tags.get("zone_id") or "") or None,
                    side=intent.side,
                    stop=intent.stop,
                )
                self._persist_gates()
                self._arm_position_fsm(int(execution.ack.ticket), decision_result.order, atr)
            elif execution.status == "uncertain":
                self.result.uncertain += 1
                self._record_signal("skipped", "execution_uncertain")
                self._risk.engage(
                    RiskState.SOFT_HALT, "order outcome unknown", actor="system"
                )
                self._notify(
                    "warn",
                    "Order outcome unknown",
                    f"{intent.slot} {intent.side}: broker did not confirm",
                    dedup_key="exec-uncertain",
                )
            elif execution.status == "rejected":
                self.result.rejected_by_broker += 1
                action = str(execution.action or "unknown")
                self._record_signal("rejected", f"broker_{action}")
                self._notify(
                    "critical" if action == "quarantine" else "warn",
                    "Order rejected by venue",
                    f"{intent.slot} {intent.side} action={action}",
                    dedup_key=f"exec-reject-{action}",
                )
                if action == "quarantine":
                    self._risk.force_quarantine("execution retcode quarantine")
            if is_entry and self.result.signals_journaled == journaled_before:
                # Last-resort net: an unforeseen fall-through path still leaves a
                # row, so no generated entry signal can silently disappear.
                self._record_filtered_signal(
                    signal, tick, ctx, "unrecorded_path", strategy_id
                )

        seen = self.result.signals_seen - seen_before
        journaled = self.result.signals_journaled - journaled_before_run
        gap = max(0, seen - journaled)
        if gap:
            self.result.signals_unlogged += gap
            self._emit(
                "JournalGap",
                {
                    "seen": self.result.signals_seen,
                    "journaled": self.result.signals_journaled,
                    "unlogged": self.result.signals_unlogged,
                },
            )
            log.error(
                "signal journal gap",
                extra={"fields": {"seen": seen, "journaled": journaled, "gap": gap}},
            )

    def _arm_position_fsm(self, ticket: int, order: Any, atr: float | None) -> None:
        """Derive the 1R/2R/target ladder and arm the exit machine."""
        if getattr(self._positions, "mode", "hedging") != "hedging":
            if self._fsm_netting_notified:
                return
            self._fsm_netting_notified = True
            self._emit(
                Ev.POSITION_MODIFIED,
                {"ticket": ticket, "action": "fsm_disabled", "reason": "netting_mode"},
            )
            if self._notifier is not None:
                try:
                    self._notifier.send(
                        "warn",
                        "Partial TP disabled",
                        "netting mode has no per-ticket lifecycle; exits stay single-target",
                        dedup_key="position-fsm-netting",
                    )
                except Exception:  # noqa: BLE001 - notification must never block trading
                    log.exception("notifier failed while disabling the position FSM")
            return
        lookup = getattr(self._positions, "get", None)
        pos = lookup(ticket) if lookup is not None else None
        if pos is None:
            return
        entry = float(pos.open_price)
        stop = float(order.sl)
        target = None if order.tp is None else float(order.tp)
        try:
            plan = build_tp_plan(
                entry=entry,
                side=pos.side,
                stop=stop,
                target=target,
                digits=self._info.digits,
            )
            fsm = PositionFSM(
                plan,
                entry=entry,
                side=pos.side,
                volume=pos.volume,
                volume_min=self._info.min_volume,
                initial_stop=stop,
                atr=atr if atr and atr > 0 else None,
                volume_step=self._info.volume_step,
            )
        except InvariantError as exc:
            # A malformed ladder must never kill the loop: fall back to the
            # risk engine's single-target management for this ticket.
            self._emit(
                Ev.POSITION_MODIFIED,
                {"ticket": ticket, "action": "fsm_disabled", "reason": str(exc)},
            )
            log.error(
                "position FSM could not be armed",
                extra={"fields": {"ticket": ticket, "err": str(exc)}},
            )
            return
        self._positions.attach_fsm(ticket, fsm)

    # ------------------------------------------------------------------
    def _enrich_signal(self, signal: Any, strategy_id: str, tick: Tick, atr: float) -> tuple[Any, dict[str, Any]]:
        tags: dict[str, Any] = dict(signal.tags)
        price = tick.ask if signal.side == "buy" else tick.bid
        if strategy_id != "zones" or "signal_score" not in tags:
            zone = (
                best_zone(
                    self._zones,
                    str(signal.side),
                    price,
                    atr,
                    max_distance_atr=self._zone_confirmation_max_atr,
                )
                if atr > 0
                else None
            )
            if zone is not None:
                tags["zone_id"] = zone.zone_id
                tags["zone_score"] = int(zone.score)
                tags["zone_kind"] = zone.kind
                tags["zone_source"] = zone.source
                tags["zone_name"] = zone.note
            else:
                tags.setdefault("zone_id", "")
                # Layer-0 filter (ADR-032): no real nearby zone means no signal;
                # the zero score becomes tier D/zone_filter, never a neutral pass.
                tags.setdefault("zone_score", 0)
            tags.setdefault("signal_score", 0.8)
            tags.setdefault("setup_type", "numeric_grid")
            tags.setdefault("quality_source", "numeric")
        zone_score = int(tags.get("zone_score", 0) or 0)
        zone_id = str(tags.get("zone_id") or "")
        zone = (
            next((item for item in self._zones if item.zone_id == zone_id), None)
            if zone_id
            else None
        )
        distance = float("inf")
        if zone is not None:
            zone_low = float(zone.low)
            zone_high = float(zone.high)
            if price < zone_low:
                distance = zone_low - price
            elif price > zone_high:
                distance = price - zone_high
            else:
                distance = 0.0
        # ADR-035: the sr_zone layer-3 vote needs score AND distance <= 2xATR,
        # for the zones strategy exactly like the numeric best_zone path.
        tags["zone_confirmed"] = zone_confirms_layer3(
            zone_score=float(zone_score),
            distance=distance,
            atr=float(atr),
            min_score=float(self._min_zone_confirmation),
            max_distance_atr=float(self._zone_confirmation_max_atr),
        )
        return replace(signal, tags=tags), tags

    @staticmethod
    def _rr(intent: EntryIntent) -> float:
        risk = abs(intent.entry_ref - intent.stop)
        if risk <= 0 or intent.target is None:
            return 0.0
        return abs(intent.target - intent.entry_ref) / risk

    @staticmethod
    def _stamp_intent(intent: EntryIntent, decision: Any, gate: Any, tags: dict[str, Any]) -> EntryIntent:
        payload = dict(intent.signal)
        merged = dict(tags)
        merged.update(
            {
                # Join key: the journal row of the signal this trade came from.
                "signal_id": intent.intent_id,
                "tier": decision.tier.value,
                "tier_base": decision.tier_base.value,
                "tier_final": decision.tier.value,
                "confirmation_count": round(decision.confirmation_count, 2),
                "confirmation_set": list(decision.confirmation_set),
                "layer3_score": round(decision.layer3_score, 3),
                "layer3_delta": decision.layer3_delta,
                "d_hard_floor": decision.d_hard_floor,
                "risk_base_pct": decision.risk_base_pct,
                # ADR-034: only the absolute R:R floor is stamped; the profile's
                # min_rr remains the RiskEngine floor.
                "min_rr": 1.0,
                "gate_hit": gate.gate,
                "bypass_type": gate.fields.get("bypass_type", ""),
                "gate_reason": gate.reason,
                "size_factor": gate.size_factor,
            }
        )
        payload["tags"] = merged
        return replace(intent, signal=payload)

    def _update_atr_percentile(self, now: datetime) -> None:
        key = now.date()
        if key == self._daily_key:
            return
        self._daily_key = key
        daily = indicators.resample(self._builder.bars("M15", 10_000), "D1")
        if len(daily) < 16:
            return
        trs = [indicators.true_range(daily[i], daily[i - 1].c) for i in range(1, len(daily))]
        atrs = [sum(trs[i - 14 : i]) / 14.0 for i in range(14, len(trs) + 1)]
        if not atrs:
            return
        self._atr_percentile = daily_atr_percentile(atrs, atrs[-1])

    # ------------------------------------------------------------------
    def _position_for(self, trade: ClosedTrade) -> Any:
        """The position an incoming closed trade belongs to, if still open."""
        if getattr(self._positions, "mode", "hedging") == "netting":
            find = getattr(self._positions, "get_by_symbol", None)
            return find(str(trade.symbol)) if find is not None else None
        lookup = getattr(self._positions, "get", None)
        return lookup(int(trade.ticket)) if lookup is not None else None

    def _settle(self, trade: ClosedTrade) -> None:
        if getattr(self, "_partials", None) is None:
            self._partials = {}
        if getattr(self, "_exec_meta", None) is None:
            self._exec_meta = {}
        before = self._position_for(trade)
        pos = self._positions.apply_close(trade)
        remaining = self._position_for(trade)
        pnl = float(trade.pnl_net.amount)
        self._risk.on_trade_closed(pnl, self._clock.now().wall)
        partial = remaining is not None and remaining.volume > 1e-9
        if partial:
            agg = self._partials.setdefault(
                int(trade.ticket),
                {"volume": 0.0, "pnl_net": 0.0, "pnl_gross": 0.0, "commission": 0.0, "swap": 0.0},
            )
            agg["volume"] += float(trade.volume)
            agg["pnl_net"] += pnl
            agg["pnl_gross"] += float(trade.pnl_gross.amount)
            agg["commission"] += float(trade.commission.amount)
            agg["swap"] += float(trade.swap.amount)
        if partial:
            # Partial take-profit: the ticket is still open. The journal row stays
            # open until the remainder closes; only the realised cash moves now.
            self._emit(
                Ev.POSITION_MODIFIED,
                {
                    "ticket": int(trade.ticket),
                    "action": "partial_close",
                    "volume": float(trade.volume),
                    "remaining": round(remaining.volume, 4),
                    "pnl_net": round(pnl, 2),
                    "reason": trade.reason,
                },
            )
            log.info(
                "partial exit settled",
                extra={
                    "fields": {
                        "ticket": int(trade.ticket),
                        "volume": float(trade.volume),
                        "remaining": round(remaining.volume, 4),
                        "pnl": pnl,
                    }
                },
            )
            return
        aggregate = self._partials.pop(int(trade.ticket), None) or {
            "volume": 0.0,
            "pnl_net": 0.0,
            "pnl_gross": 0.0,
            "commission": 0.0,
            "swap": 0.0,
        }
        total_pnl = aggregate["pnl_net"] + pnl
        total_gross = aggregate["pnl_gross"] + float(trade.pnl_gross.amount)
        total_commission = aggregate["commission"] + float(trade.commission.amount)
        total_swap = aggregate["swap"] + float(trade.swap.amount)
        audit = self._exec_meta.pop(int(trade.ticket), {})
        actual_cost = total_commission - total_swap
        estimated_cost = float(
            (audit.get("estimated_cost") or {}).get("total", 0.0) or 0.0
        )
        drift_pct = (
            abs(actual_cost - estimated_cost) / abs(estimated_cost) * 100.0
            if estimated_cost
            else 0.0
        )
        if estimated_cost > 0 and drift_pct > 15.0:
            self._emit(
                "CostDrift",
                {
                    "ticket": int(trade.ticket),
                    "estimated_cost": round(estimated_cost, 2),
                    "actual_cost": round(actual_cost, 2),
                    "drift_pct": round(drift_pct, 1),
                },
            )
            self._notify(
                "warn",
                "Cost estimate drift",
                f"ticket {int(trade.ticket)}: estimated {estimated_cost:.2f} "
                f"actual {actual_cost:.2f} ({drift_pct:.0f}%)",
                dedup_key="cost-drift",
            )
        fsm = getattr(before, "fsm", None)
        if fsm is not None:
            fsm.mark_closed(trade.reason)
        self.result.trades_closed += 1
        if pos is not None:
            self._gates.note_close(
                ticket=int(trade.ticket),
                reason=trade.reason,
                entry=pos.open_price,
                exit_price=trade.close_price,
                side=trade.side,
            )
            self._persist_gates()
            self._host.on_trade_closed(
                pos.slot,
                TradeSummary(
                    slot=pos.slot,
                    ticket=int(trade.ticket),
                    side=trade.side,
                    entry_price=pos.open_price,
                    exit_price=trade.close_price,
                    volume=trade.volume,
                    pnl_net=pnl,
                    reason=trade.reason,
                    opened_at=pos.open_time,
                    closed_at=trade.close_time,
                ),
            )
        if pos is not None and self._journal is not None:
            self._journal.update_trade(
                f"{pos.slot}-{trade.ticket}",
                close_time=trade.close_time.isoformat(),
                close_price=trade.close_price,
                pnl_gross=total_gross,
                commission=total_commission,
                swap=total_swap,
                pnl_net=total_pnl,
                mae=pos.mae,
                mfe=pos.mfe,
                exit_reason=trade.reason,
                config_hash=str(audit.get("config_hash") or getattr(self, "_config_hash", "")),
                entry_slippage_pts=audit.get("entry_slippage_pts"),
                spread_at_signal_pts=audit.get("spread_at_signal_pts"),
                spread_at_fill_pts=audit.get("spread_at_fill_pts"),
                latency_ms=audit.get("latency_ms"),
                commission_actual=round(total_commission, 2),
                swap_actual=round(total_swap, 2),
                estimated_cost=round(estimated_cost, 2) if estimated_cost else None,
                actual_cost=round(actual_cost, 2),
            )
        signal_id = audit.get("signal_id")
        if signal_id and self._journal is not None:
            outcome = "win" if total_pnl > 0 else ("loss" if total_pnl < 0 else "be")
            try:
                self._journal.update_signal_outcome(
                    str(signal_id),
                    outcome,
                    round(total_pnl, 2),
                    trade.close_time.isoformat()
                    if trade.close_time is not None
                    else self._clock.now().wall.isoformat(),
                )
            except Exception:  # noqa: BLE001 - analytics must not stop settlement
                log.exception("signal outcome write failed")
        self._emit(
            Ev.POSITION_CLOSED,
            {
                "ticket": int(trade.ticket),
                "pnl_net": total_pnl,
                "volume": round(aggregate["volume"] + float(trade.volume), 4),
                "reason": trade.reason,
                "slot": None if pos is None else pos.slot,
            },
        )
        log.info(
            "position closed",
            extra={"fields": {"ticket": int(trade.ticket), "pnl": pnl, "reason": trade.reason}},
        )

    def _is_weekend_close(self, now: datetime) -> bool:
        """Friday after the configured hour (and the weekend itself) is flat-only."""
        if self._friday_flat_hour is None:
            return False
        weekday = now.weekday()  # Monday=0 ... Friday=4, Saturday=5, Sunday=6
        if weekday > 4:
            return True
        return weekday == 4 and now.hour >= self._friday_flat_hour

    def _weekend_close_order(self) -> tuple[int, ...] | None:
        """ADR-022 / SES-05: deterministic weekend flatten order from the venue.

        Returns None when no weekend policy is configured (callers then keep the
        book order); an empty tuple means there is nothing to flatten.
        """
        params = getattr(self, "_weekend", None)
        if params is None:
            return None
        positions = list(self._positions.raw())
        if not positions:
            return ()
        venue = self._venue_positions() or {}
        profits: dict[int, float] = {}
        for pos in positions:
            ticket = int(pos.ticket)
            snapshot = venue.get(ticket)
            profit: Any = getattr(snapshot, "profit", None) if snapshot is not None else None
            amount = getattr(profit, "amount", profit)
            try:
                value = float(amount) if amount is not None else None
            except (TypeError, ValueError):
                value = None
            profits[ticket] = (
                value if value is not None else float(getattr(pos, "unrealized", 0.0) or 0.0)
            )
        return weekend_close_plan(profits, params)

    def _flatten(self, reason: str, *, order: Sequence[int] | None = None) -> bool:
        """Close every position and prove it; never report flat on a failure."""
        positions = list(self._positions.raw())
        by_ticket = {int(pos.ticket): pos for pos in positions}
        if order is None and reason == "weekend":
            order = self._weekend_close_order()
        if order is not None:
            ordered = [by_ticket[ticket] for ticket in order if ticket in by_ticket]
            ordered += [pos for pos in positions if int(pos.ticket) not in order]
        else:
            ordered = positions
        closed = 0
        failed: list[int] = []
        for pos in ordered:
            ticket = int(pos.ticket)
            if self._close_with_retries(ticket, reason, prefix=f"flat-{reason}"):
                closed += 1
            else:
                failed.append(ticket)
        remaining = [int(pos.ticket) for pos in self._positions.raw()]
        if failed or remaining:
            self._pending_flatten = reason
            self._flatten_failures = getattr(self, "_flatten_failures", 0) + 1
            self._fail_closed(
                "FlattenFailed",
                f"flatten '{reason}' incomplete (attempt {self._flatten_failures})",
                sorted(set(failed) | set(remaining)),
            )
            return False
        self._pending_flatten = None
        self._flatten_failures = 0
        self._emit(
            "FlattenCompleted",
            {"reason": reason, "closed": closed, "remaining": 0},
        )
        return True

    def _sample_equity(self, at: datetime) -> None:
        if self._journal is None:
            return
        account = self._broker.account()
        self._journal.record_equity(at.isoformat(), float(account.equity.amount), float(account.balance.amount))
        self._last_equity_sample = at

    def _finish(self) -> None:
        cash = self._broker.account()
        self._sample_equity(self._clock.now().wall)
        self.result.final_state = self._risk.state().value
        self.result.final_equity = float(cash.equity.amount)
        self.result.net_pnl = float(cash.balance.amount - self.result.stats.get("start_equity", cash.balance.amount))
        if self._journal is not None:
            self.result.stats = dict(self._journal.stats())
            self._journal.append(
                Event(
                    type=Ev.SESSION_FINISHED,
                    payload={
                        "ticks": self.result.ticks,
                        "bars": self.result.bars,
                        "approved": self.result.approved,
                        "rejected": self.result.rejected,
                        "trades": self.result.trades_closed,
                        "equity": self.result.final_equity,
                        "rejects": self.result.rejects,
                        "priority_skipped": self.result.priority_skipped,
                        "zone_confirmed": self.result.zone_confirmed,
                        "gate_rejected": self.result.gate_rejected,
                        "amplified": self.result.amplified,
                        "signals_seen": self.result.signals_seen,
                        "signals_journaled": self.result.signals_journaled,
                        "signals_unlogged": self.result.signals_unlogged,
                        "funnel": dict(self.result.funnel),
                    },
                    ts=self._clock.now(),
                    actor="system",
                )
            )
        self.result.net_pnl = self.result.final_equity - self.result.stats.get("start_equity", self.result.final_equity)
        self._host.stop("run finished")
        self._broker.disconnect()
