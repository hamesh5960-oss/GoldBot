"""Market session resolution: UTC window buckets plus DST-aware offsets.

Pure application module: no adapters, no runtime, no wall-clock reads. The
caller supplies the instant; this module only answers "which session is this
and how far into it are we?".

Window convention
-----------------
SessionWindows holds *session-clock* hour ranges. A window (start, end) covers
[start, end) and wraps past midnight when start > end (for example 23 -> 7).
Hours are floats in [0, 24); start == end is rejected as ambiguous, windows may
not overlap and together they must cover at least 23 of the 24 hours.

resolve_session() converts the UTC instant onto the session clock by adding the
UTC offset of the requested DST mode, then matches the resulting local hour
against the windows:

* dst_mode="none"  -> offset 0.0; the windows are literal UTC ranges and
  is_dst_active is always False.
* dst_mode="fixed" -> offset fixed_offset_hours from the caller; is_dst_active
  is False (the caller owns the clock).
* dst_mode="us"    -> US Eastern: -5 in winter, -4 during US DST, which runs
  from 07:00 UTC (02:00 EST) on the second Sunday of March to 06:00 UTC
  (02:00 EDT) on the first Sunday of November.  The boundary is pure calendar
  arithmetic (no tzdata): the *dates* are the second Sunday of March and the
  first Sunday of November, and the UTC instants are the real local 02:00
  transitions.
* dst_mode="eu"    -> Central European: +1 in winter, +2 during EU DST, which
  runs from 01:00 UTC on the last Sunday of March to 01:00 UTC on the last
  Sunday of October.

Minutes into a session are counted from the window start on the session clock,
including the wrap across midnight; when no window matches the name is
"closed", is_open is False and minutes_into_session is 0.
"""

from __future__ import annotations

import calendar
from dataclasses import dataclass
from datetime import date, datetime, time, timedelta, timezone
from typing import Iterable, Mapping, Sequence

from ..domain.model import SessionWindow

__all__ = [
    "DEFAULT_SESSION_WINDOWS",
    "HOURS_PER_DAY",
    "PLACEHOLDER_SESSIONS",
    "SESSION_NAMES",
    "SessionInfo",
    "SessionTableError",
    "SessionWindows",
    "eu_dst_active",
    "is_placeholder_session_table",
    "resolve_session",
    "us_dst_active",
    "validate_live_session_table",
]

HOURS_PER_DAY = 24.0
SESSION_NAMES: tuple[str, ...] = ("asia", "london", "overlap", "ny", "late_ny")

# Window endpoints may be ints or floats; comparisons use this tolerance so
# 7 and 7.0 are the same boundary.
_EPS = 1e-9


def _split_window(start: float, end: float) -> tuple[tuple[float, float], ...]:
    """Split one circular window into linear intervals on [0, 24)."""
    if start < end:
        return ((start, end),)
    return ((start, HOURS_PER_DAY), (0.0, end))


def _floor_hours(value: object, field: str) -> float:
    try:
        hours = float(value)  # type: ignore[arg-type]
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{field} must be a number, got {value!r}") from exc
    return hours


@dataclass(frozen=True, slots=True)
class SessionWindows:
    """Named session windows on the session clock (see module docstring)."""

    asia: tuple[tuple[float, float], ...] = ((23.0, 7.0),)
    london: tuple[tuple[float, float], ...] = ((7.0, 12.0),)
    overlap: tuple[tuple[float, float], ...] = ((12.0, 16.0),)
    ny: tuple[tuple[float, float], ...] = ((16.0, 21.0),)
    late_ny: tuple[tuple[float, float], ...] = ((21.0, 23.0),)

    def __post_init__(self) -> None:
        self.validate()

    @classmethod
    def from_mapping(
        cls, mapping: Mapping[str, Iterable[Sequence[float]]]
    ) -> "SessionWindows":
        """Build windows from {name: [(start, end), ...]}; missing names are empty."""
        unknown = sorted(set(mapping) - set(SESSION_NAMES))
        if unknown:
            raise ValueError(f"unknown session window name(s): {', '.join(unknown)}")
        built: dict[str, tuple[tuple[float, float], ...]] = {}
        for name in SESSION_NAMES:
            raw = mapping.get(name)
            if raw is None:
                built[name] = ()
                continue
            windows: list[tuple[float, float]] = []
            for pair in raw:
                values = tuple(pair)
                if len(values) != 2:
                    raise ValueError(f"{name} window {values!r} must be (start, end)")
                windows.append(
                    (
                        _floor_hours(values[0], f"{name} start"),
                        _floor_hours(values[1], f"{name} end"),
                    )
                )
            built[name] = tuple(windows)
        return cls(**built)

    def validate(self) -> None:
        """Reject ambiguous, overlapping or under-covered window sets."""
        intervals: list[tuple[float, float, str]] = []
        for name in SESSION_NAMES:
            windows = tuple(getattr(self, name))
            starts = [float(start) for start, _ in windows]
            if starts != sorted(starts):
                raise ValueError(f"{name} windows must be in ascending start order")
            if len(set(starts)) != len(starts):
                raise ValueError(f"{name} has duplicate window starts")
            for start_value, end_value in windows:
                start = _floor_hours(start_value, f"{name} start")
                end = _floor_hours(end_value, f"{name} end")
                if not (0.0 <= start < HOURS_PER_DAY):
                    raise ValueError(f"{name} window start {start} outside [0, 24)")
                if not (0.0 < end <= HOURS_PER_DAY):
                    raise ValueError(f"{name} window end {end} outside (0, 24]")
                if abs(start - end) <= _EPS:
                    raise ValueError(f"{name} window ({start}, {end}) has zero length")
                for low, high in _split_window(start, end):
                    intervals.append((low, high, name))
        for first in range(len(intervals)):
            for second in range(first + 1, len(intervals)):
                low_a, high_a, name_a = intervals[first]
                low_b, high_b, name_b = intervals[second]
                if low_a < high_b - _EPS and low_b < high_a - _EPS:
                    raise ValueError(f"session windows overlap: {name_a} and {name_b}")
        covered = sum(high - low for low, high, _ in intervals)
        if covered < HOURS_PER_DAY - 1.0 - _EPS:
            raise ValueError(
                f"session windows cover only {covered:.2f}h; at least 23h is required"
            )


DEFAULT_SESSION_WINDOWS = SessionWindows()


# -- live session-table guard -------------------------------------------------
#
# The config table is a daily template (Monday..Friday) of SessionWindow in
# broker server time. On a live account the venue's real week is authoritative:
# the synthetic placeholder (one 00:00-23:59 window) must never be accepted for
# a real account, and when the broker weekly sessions are supplied the template
# must match them exactly. The live composition root (runtime/live.py) must call
# validate_live_session_table(learned.sessions, broker_sessions=...) after the
# broker metadata is learned and before the engine is built.

PLACEHOLDER_SESSIONS: tuple[SessionWindow, ...] = (SessionWindow(time(0, 0), time(23, 59)),)
TRADING_WEEKDAYS: tuple[int, ...] = (0, 1, 2, 3, 4)  # Monday=0 ... Friday=4
_WEEKDAY_NAMES = ("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday")


class SessionTableError(ValueError):
    """Live session table cannot be trusted; fail closed at startup."""


def is_placeholder_session_table(sessions: Sequence[SessionWindow]) -> bool:
    """True for the synthetic single-window 00:00-23:59 placeholder."""
    table = tuple(sessions)
    if len(table) != 1:
        return False
    window = table[0]
    return window.start == time(0, 0) and window.end in (time(23, 59), time(0, 0))


def _window_pairs(sessions: Iterable[object], label: str) -> tuple[tuple[time, time], ...]:
    pairs: list[tuple[time, time]] = []
    for item in sessions:
        if isinstance(item, SessionWindow):
            start, end = item.start, item.end
        else:
            try:
                values = tuple(item)  # type: ignore[arg-type]
            except TypeError as exc:
                raise SessionTableError(
                    f"{label}: expected (start, end) pairs, got {item!r}"
                ) from exc
            if len(values) != 2:
                raise SessionTableError(f"{label}: expected (start, end) pairs, got {item!r}")
            start, end = values
        if not isinstance(start, time) or not isinstance(end, time):
            raise SessionTableError(
                f"{label}: session bounds must be datetime.time, got {(start, end)!r}"
            )
        if start == end:
            raise SessionTableError(f"{label}: zero-length session {start}-{end}")
        pairs.append((start, end))
    return tuple(sorted(pairs))


def validate_live_session_table(
    sessions: Sequence[SessionWindow],
    *,
    broker_sessions: Mapping[int, Iterable[object]] | None = None,
    allow_placeholder: bool = False,
    trading_days: Sequence[int] = TRADING_WEEKDAYS,
) -> tuple[str, ...]:
    """Fail-closed guard for the config session table on a live account.

    sessions are the SymbolInfo.sessions daily template (broker server time).
    broker_sessions maps a weekday (Monday=0 ... Sunday=6) to the venue's session
    list for that weekday; each item is either a SessionWindow or a
    (start, end) pair of datetime.time.

    Returns human-readable warnings (empty on a clean, fully verified match) and
    raises SessionTableError when the table cannot be trusted.
    """
    table = tuple(sessions)
    if not table:
        raise SessionTableError("empty session table: live requires the broker weekly sessions")
    expected = _window_pairs(table, "config sessions")
    allowed_days = tuple(int(day) for day in trading_days)
    if any(day < 0 or day > 6 for day in allowed_days):
        raise SessionTableError(f"trading_days must be weekday numbers 0..6, got {trading_days!r}")
    if len(set(allowed_days)) != len(allowed_days):
        raise SessionTableError(f"trading_days contains duplicates: {trading_days!r}")
    warnings: list[str] = []
    if is_placeholder_session_table(table):
        if not allow_placeholder:
            raise SessionTableError(
                "synthetic placeholder session table (single 00:00-23:59 window) is not allowed "
                "for live: configure the broker's real weekly sessions"
            )
        warnings.append(
            "synthetic placeholder session table explicitly allowed (allow_placeholder=True)"
        )
    if broker_sessions is None:
        warnings.append(
            "broker weekly sessions were not supplied; the config session table is unverified "
            "against the venue"
        )
        return tuple(warnings)
    unknown = sorted(set(int(day) for day in broker_sessions) - set(range(7)))
    if unknown:
        raise SessionTableError(
            f"broker_sessions has invalid weekday key(s) {unknown}; expected 0..6"
        )
    for day in range(7):
        label = _WEEKDAY_NAMES[day]
        raw = broker_sessions.get(day, ())
        actual = _window_pairs(raw, f"broker {label} sessions")
        if day in allowed_days:
            if not actual:
                raise SessionTableError(f"broker reports no {label} session but it is a trading day")
            if actual != expected:
                raise SessionTableError(
                    f"{label} broker sessions {actual} do not match the config template "
                    f"{expected}; the daily session model cannot represent the venue week"
                )
        elif actual:
            raise SessionTableError(
                f"broker reports {label} sessions {actual}; weekend trading is not supported "
                "by the daily session model (ADR-022)"
            )
    return tuple(warnings)


def _as_utc(value: datetime) -> datetime:
    """Naive values are treated as UTC; aware values are converted to UTC."""
    if not isinstance(value, datetime):
        raise TypeError("at_utc must be a datetime")
    if value.tzinfo is None:
        return value.replace(tzinfo=timezone.utc)
    return value.astimezone(timezone.utc)


def _nth_sunday(year: int, month: int, nth: int) -> date:
    first = date(year, month, 1)
    offset = (6 - first.weekday()) % 7  # 6 == Sunday
    return first + timedelta(days=offset + 7 * (nth - 1))


def _last_sunday(year: int, month: int) -> date:
    last = date(year, month, calendar.monthrange(year, month)[1])
    return last - timedelta(days=(last.weekday() - 6) % 7)


def us_dst_active(at_utc: datetime) -> bool:
    """True inside US daylight-saving time.

    Rule: second Sunday of March at 07:00 UTC (02:00 EST) to first Sunday of
    November at 06:00 UTC (02:00 EDT).  Pure calendar arithmetic, no tzdata.
    """
    moment = _as_utc(at_utc)
    start = datetime(
        moment.year, 3, _nth_sunday(moment.year, 3, 2).day, 7, 0, tzinfo=timezone.utc
    )
    end = datetime(
        moment.year, 11, _nth_sunday(moment.year, 11, 1).day, 6, 0, tzinfo=timezone.utc
    )
    return start <= moment < end


def eu_dst_active(at_utc: datetime) -> bool:
    """True inside EU daylight-saving time (01:00 UTC last Sun Mar -> last Sun Oct)."""
    moment = _as_utc(at_utc)
    start = datetime(
        moment.year, 3, _last_sunday(moment.year, 3).day, 1, 0, tzinfo=timezone.utc
    )
    end = datetime(
        moment.year, 10, _last_sunday(moment.year, 10).day, 1, 0, tzinfo=timezone.utc
    )
    return start <= moment < end


@dataclass(frozen=True, slots=True)
class SessionInfo:
    """Resolution result for one instant."""

    name: str
    utc_offset_hours: float
    is_dst_active: bool
    minutes_into_session: float
    is_open: bool


def _dst_offset(
    dst_mode: str, moment: datetime, fixed_offset_hours: float
) -> tuple[float, bool]:
    mode = str(dst_mode).strip().lower()
    if mode == "none":
        return (0.0, False)
    if mode == "fixed":
        return (float(fixed_offset_hours), False)
    if mode == "us":
        if us_dst_active(moment):
            return (-4.0, True)
        return (-5.0, False)
    if mode == "eu":
        if eu_dst_active(moment):
            return (2.0, True)
        return (1.0, False)
    raise ValueError(
        f"unknown dst_mode {dst_mode!r}; expected one of none/fixed/us/eu"
    )


def _in_window(hour: float, start: float, end: float) -> bool:
    if start < end:
        return start - _EPS <= hour < end
    return hour >= start - _EPS or hour < end


def resolve_session(
    at_utc: datetime,
    windows: SessionWindows | None = None,
    *,
    dst_mode: str = "us",
    fixed_offset_hours: float = 0.0,
) -> SessionInfo:
    """Resolve the session bucket for one instant.

    dst_mode selects the UTC offset applied to the session clock (see module
    docstring). The offset shifts the window interpretation: the window hours
    are local session-clock hours, the instant is the only UTC input.
    """
    moment = _as_utc(at_utc)
    offset, is_dst = _dst_offset(dst_mode, moment, fixed_offset_hours)
    table = windows if windows is not None else DEFAULT_SESSION_WINDOWS
    if not isinstance(table, SessionWindows):
        raise TypeError("windows must be SessionWindows")
    local = moment + timedelta(hours=offset)
    hour = (
        local.hour
        + local.minute / 60.0
        + local.second / 3600.0
        + local.microsecond / 3_600_000_000.0
    )
    for name in SESSION_NAMES:
        for start_value, end_value in getattr(table, name):
            start = float(start_value)
            end = float(end_value)
            if _in_window(hour, start, end):
                elapsed = (hour - start) % HOURS_PER_DAY
                return SessionInfo(
                    name=name,
                    utc_offset_hours=offset,
                    is_dst_active=is_dst,
                    minutes_into_session=round(elapsed * 60.0, 6),
                    is_open=True,
                )
    return SessionInfo(
        name="closed",
        utc_offset_hours=offset,
        is_dst_active=is_dst,
        minutes_into_session=0.0,
        is_open=False,
    )
