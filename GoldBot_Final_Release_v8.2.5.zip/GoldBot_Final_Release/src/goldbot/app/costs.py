"""Full transaction-cost model: commission, spread, slippage and swap.

Pure (stdlib only, no clocks): the sizing pipeline and the journal need the same
numbers and neither may reach into the adapter layer.  Every money field here is
*cost positive*: the amount the account pays.  A swap credit is therefore
negative.  Domain PnL keeps the opposite broker convention
(pnl_net = pnl_gross - commission + swap); the adapter converts at the edge.

Spec: docs/SPEC-MERGED-v1.0.md section 6, steps 8-9 (lot sizing and the real-risk
check).  The effective loss is what lot sizing must divide by, so a zero-spread
backtest and a real-spread backtest differ only through this module.

Broker-day convention (CJ-06): every weekday here is broker time with
Monday=0..Sunday=6, so triple_swap_weekday = 2 means Wednesday.  Live ePlanet
MT5 metadata for XAUUSD.st reports swap_rollover3days=3 (MT5 ENUM_DAY_OF_WEEK:
0=Sunday, so 3=Wednesday), matching ADR-040 "triple Wednesday" and
config/base.toml.  The triple multiplier is applied to the rollover of that
broker weekday's night: a position opened Wednesday and held overnight is
charged 3x.  Whether MT5 charges at 00:00 entering that day or 00:00 leaving it
is NOT proven by metadata; settling it needs broker deal history (swap_actual
for a Tuesday->Wednesday hold vs a Wednesday->Thursday hold).  Until that
evidence exists the current behaviour is kept explicit and covered by tests.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

Side = Literal["buy", "sell"]


@dataclass(frozen=True, slots=True)
class CostParams:
    """Cost assumptions, normally built from the [costs] config table."""

    commission_per_lot_rt: float = 7.0
    point: float = 0.01
    contract_size: float = 100.0
    default_spread_points: float = 0.0
    slippage_points: float = 2.0
    news_slippage_points: float = 20.0
    # How far around a news timestamp is_news stays true; the caller evaluates
    # the window, this module only applies the widened slippage.
    news_window_minutes: int = 30
    # Signed swap per lot per night: positive = paid, negative = credit.
    # Conservative XAUUSD: pay the long carry and do not bank the usual short
    # credit.  Calibrate from broker history before trusting a backtest.
    swap_long_per_lot_night: float = 12.0
    swap_short_per_lot_night: float = 2.0
    # Broker time, Monday=0.  Wednesday=2 because MT5 reports
    # swap_rollover3days=3 for XAUUSD.st on ePlanet (0=Sunday) and ADR-040 names
    # triple Wednesday.  The charge instant within the day remains UNRESOLVED
    # until broker swap_actual history proves it (CJ-06).
    triple_swap_weekday: int = 2  # Wednesday, the MT5 triple-swap charging day
    triple_swap_hour: int = 20  # broker blackout start; mirrors CapitalParams


DEFAULT_COSTS = CostParams()


@dataclass(frozen=True, slots=True)
class CostBreakdown:
    """Round-trip costs in account currency (cost positive, credits negative)."""

    commission: float = 0.0
    slippage: float = 0.0
    spread: float = 0.0
    swap: float = 0.0

    @property
    def total(self) -> float:
        return self.commission + self.slippage + self.spread + self.swap

    def as_dict(self) -> dict[str, float]:
        """Flat projection for journal payloads (total included)."""
        return {
            "total": self.total,
            "commission": self.commission,
            "slippage": self.slippage,
            "spread": self.spread,
            "swap": self.swap,
        }


def _params(params: CostParams | None) -> CostParams:
    return DEFAULT_COSTS if params is None else params


def _swap_rate(side: Side, params: CostParams) -> float:
    if side == "buy":
        return params.swap_long_per_lot_night
    if side == "sell":
        return params.swap_short_per_lot_night
    raise ValueError(f"side must be 'buy' or 'sell', got {side!r}")


def _charge_days(broker_day: int, nights: int) -> list[int]:
    """Weekdays of the nights charged rollovers; weekends are skipped.

    There is no Saturday/Sunday rollover, so Friday->Monday is one charged
    night (the Friday one), not three calendar nights.
    """
    if nights < 0:
        raise ValueError(f"nights must be >= 0, got {nights!r}")
    if not 0 <= broker_day <= 6:
        raise ValueError(f"broker_day must be 0..6 (Monday=0), got {broker_day!r}")
    if nights and broker_day >= 5:
        raise ValueError("broker_day must be a trading day (Mon-Fri) when nights > 0")
    days: list[int] = []
    day = broker_day
    while len(days) < nights:
        days.append(day % 7)
        day += 1
        while day % 7 in (5, 6):
            day += 1
    return days


def nights_charged(nights: int, broker_day: int, *, params: CostParams | None = None) -> int:
    """Number of swap charges, including the Wednesday triple charge.

    nights counts broker rollovers (Friday->Monday is one) and broker_day is the
    weekday (Monday=0) of the first charged trading day, i.e. the day the
    position is opened when it survives the overnight.  Wednesday->Thursday is
    charged three times: a one-night Wednesday hold is 3 charges; Tuesday->Friday
    is 1 + 3 + 1 = 5 charges.

    Explicit assumption (CJ-06): "Wednesday" uses the broker-day convention
    above, backed by MT5 swap_rollover3days=3 (0=Sunday) for XAUUSD.st and
    ADR-040.  The exact charge instant (00:00 entering vs leaving the day) is
    UNRESOLVED and must be confirmed from broker swap_actual history before
    trusting backtest swap numbers.
    """
    p = _params(params)
    return sum(3 if day == p.triple_swap_weekday else 1 for day in _charge_days(broker_day, nights))


def swap_for_nights(
    side: Side,
    nights: int,
    broker_day: int,
    *,
    is_news: bool = False,
    params: CostParams | None = None,
) -> float:
    """Signed swap for one lot held nights rollovers (cost positive).

    is_news is accepted for call-site symmetry but never changes the swap: news
    widens slippage (estimated_round_trip) while the triple-swap rule only
    multiplies the swap leg.  The components are disjoint, so a news event on a
    triple-swap Wednesday stacks two different costs, never a double count.
    """
    del is_news  # documented no-op: precedence lives in estimated_round_trip
    p = _params(params)
    return _swap_rate(side, p) * nights_charged(nights, broker_day, params=p)


def estimated_round_trip(
    volume: float,
    *,
    spread_points: float | None = None,
    nights: int = 0,
    is_news: bool = False,
    side: Side = "buy",
    broker_day: int | None = None,
    params: CostParams | None = None,
) -> CostBreakdown:
    """Estimate entry-plus-exit costs for volume lots.

    spread_points=None falls back to default_spread_points so a neutral
    assumption is always explicit at the call site.  nights is taken as an
    already charged-night count when broker_day is omitted; pass broker_day to
    let swap_for_nights apply the triple-swap rule.
    """
    p = _params(params)
    if volume < 0:
        raise ValueError(f"volume must be >= 0, got {volume!r}")
    points = p.default_spread_points if spread_points is None else float(spread_points)
    if points < 0:
        raise ValueError(f"spread_points must be >= 0, got {points!r}")
    money_per_point = p.point * p.contract_size * volume
    slip_points = p.news_slippage_points if is_news else p.slippage_points
    if broker_day is None:
        swap = _swap_rate(side, p) * nights * volume
    else:
        swap = swap_for_nights(side, nights, broker_day, is_news=is_news, params=p) * volume
    return CostBreakdown(
        commission=p.commission_per_lot_rt * volume,
        slippage=slip_points * money_per_point,
        spread=points * money_per_point,
        swap=swap,
    )


def effective_loss_per_lot(
    sl_distance: float,
    volume: float,
    *,
    nights: int = 0,
    is_news: bool = False,
    spread_points: float | None = None,
    side: Side = "buy",
    broker_day: int | None = None,
    params: CostParams | None = None,
) -> float:
    """Money lost at the stop plus every transaction cost (spec step 9).

    abs(sl_distance) * contract_size * volume + commission + slippage + spread
    + abs(swap).  The swap leg is added as a cost even when it is a credit, so
    sizing never banks a carry subsidy it may not receive.
    """
    p = _params(params)
    costs = estimated_round_trip(
        volume,
        spread_points=spread_points,
        nights=nights,
        is_news=is_news,
        side=side,
        broker_day=broker_day,
        params=p,
    )
    return (
        abs(sl_distance) * p.contract_size * volume
        + costs.commission
        + costs.slippage
        + costs.spread
        + abs(costs.swap)
    )
