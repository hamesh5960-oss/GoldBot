"""News blackout policy: keep entries out of high/medium impact news windows.

Pure: no I/O, no wall clock, no config access.  The calendar adapter produces
NewsEvent rows; this module only decides whether a given UTC instant is inside
a blackout and why.  Malformed rows must never arm or disarm the policy
accidentally, so the event snapshot is sanitised, sorted and capped on
construction and evaluation itself never raises.

Fail-safe: when the calendar is unavailable the policy does not silently trade.
NewsParams.fail_safe == 'conservative' blocks a deterministic set of windows on
weekdays, where US data releases cluster: the configured centres are the winter
(standard-time) UTC values (14:30 and 18:00 UTC), shifted one hour earlier while
US DST is active (13:30 and 17:00 UTC), so the fallback tracks the real release
clock instead of missing it for half the year. 'trading_disabled' blocks
everything until the calendar returns.

Impact precedence: HIGH wins over MEDIUM when windows overlap; LOW never
blackouts.  The before/after minutes are inclusive on both ends.
"""

from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass
from datetime import datetime, timedelta
from enum import Enum
from typing import Literal

from ..domain.model import utc
from .market_session import us_dst_active


class Impact(str, Enum):
    """Event importance as published by the calendar."""

    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


_IMPACT_RANK: dict[Impact, int] = {Impact.HIGH: 0, Impact.MEDIUM: 1, Impact.LOW: 2}

FailSafe = Literal["conservative", "trading_disabled"]

REASON_HIGH = "high_impact"
REASON_MEDIUM = "medium_impact"
REASON_CONSERVATIVE = "conservative_fallback"
REASON_UNAVAILABLE = "calendar_unavailable"


def _as_text(value: object, default: str = "") -> str:
    if value is None:
        return default
    if isinstance(value, str):
        return value
    return str(value)


def _coerce_impact(value: object) -> Impact:
    """Map any calendar token to an Impact; unknown values become MEDIUM (conservative)."""
    if isinstance(value, Impact):
        return value
    if isinstance(value, str):
        token = value.strip().lower()
        if token in ("high", "h", "3"):
            return Impact.HIGH
        if token in ("medium", "med", "m", "2", "moderate", "mid"):
            return Impact.MEDIUM
        if token in ("low", "l", "1"):
            return Impact.LOW
    return Impact.MEDIUM


def _impact_window(impact: Impact, params: "NewsParams") -> tuple[int, int]:
    if impact is Impact.HIGH:
        return (params.high_before_minutes, params.high_after_minutes)
    if impact is Impact.MEDIUM:
        return (params.medium_before_minutes, params.medium_after_minutes)
    return (0, 0)


def _validate_params(params: "NewsParams") -> None:
    for name in (
        "high_before_minutes",
        "high_after_minutes",
        "medium_before_minutes",
        "medium_after_minutes",
    ):
        value = getattr(params, name)
        if isinstance(value, bool) or not isinstance(value, int) or value < 0:
            raise ValueError(f"{name} must be a non-negative int, got {value!r}")
    if params.fail_safe not in ("conservative", "trading_disabled"):
        raise ValueError(
            f"fail_safe must be 'conservative' or 'trading_disabled', got {params.fail_safe!r}"
        )
    if params.max_events < 1:
        raise ValueError(f"max_events must be >= 1, got {params.max_events!r}")
    for window in params.conservative_windows:
        if len(window) != 3:
            raise ValueError(f"conservative_windows entries need 3 ints, got {window!r}")
        hour, minute, half_width = (int(item) for item in window)
        if not (0 <= hour <= 23 and 0 <= minute <= 59 and half_width >= 0):
            raise ValueError(f"invalid conservative window {window!r}")


@dataclass(frozen=True, slots=True)
class NewsEvent:
    """One calendar row; when_utc is normalised to timezone-aware UTC."""

    when_utc: datetime
    impact: Impact
    title: str = ""
    currency: str = "USD"

    def __post_init__(self) -> None:
        object.__setattr__(self, "when_utc", utc(self.when_utc))
        object.__setattr__(self, "impact", _coerce_impact(self.impact))


@dataclass(frozen=True, slots=True)
class NewsParams:
    """News-blackout assumptions, normally built from the [news] config table."""

    enabled: bool = True
    high_before_minutes: int = 30
    high_after_minutes: int = 60
    medium_before_minutes: int = 15
    medium_after_minutes: int = 30
    fail_safe: FailSafe = "conservative"
    # (hour, minute, half_width_minutes) fallback windows used when the calendar
    # is down. The centre is the US standard-time (winter) UTC value; while US
    # DST is active it moves one hour earlier. Defaults: 14:30/18:00 UTC in
    # winter and 13:30/17:00 UTC in summer (ADR-023 amendment).
    conservative_windows: tuple[tuple[int, int, int], ...] = ((14, 30, 15), (18, 0, 15))
    max_events: int = 500


@dataclass(frozen=True, slots=True)
class NewsState:
    """Blackout decision for one instant; an empty reason means trading is clear."""

    blackout: bool
    reason: str
    event: NewsEvent | None = None
    until_utc: datetime | None = None


def _coerce_event(raw: object) -> NewsEvent | None:
    """Return a clean NewsEvent, or None when the entry must be dropped."""
    if not isinstance(raw, NewsEvent):
        return None
    when = getattr(raw, "when_utc", None)
    if not isinstance(when, datetime):
        return None
    try:
        when_utc = utc(when)
    except (AttributeError, TypeError, ValueError):
        return None
    try:
        return NewsEvent(
            when_utc=when_utc,
            impact=_coerce_impact(getattr(raw, "impact", Impact.MEDIUM)),
            title=_as_text(getattr(raw, "title", "")),
            currency=_as_text(getattr(raw, "currency", "USD"), "USD") or "USD",
        )
    except (AttributeError, TypeError, ValueError):
        return None


def classify_events(events: Iterable[NewsEvent], params: NewsParams) -> tuple[NewsEvent, ...]:
    """Sanitise, sort and cap a calendar snapshot.

    Entries that cannot be interpreted are dropped instead of raised.  The cap
    keeps the *newest* rows: a long historical calendar must not push upcoming
    releases out of the window (fail-safe trimming).
    """
    _validate_params(params)
    valid: list[NewsEvent] = []
    for raw in events:
        event = _coerce_event(raw)
        if event is not None:
            valid.append(event)
    valid.sort(key=lambda item: (item.when_utc, _IMPACT_RANK.get(item.impact, 9), item.title, item.currency))
    if len(valid) > params.max_events:
        valid = valid[-params.max_events :]
    return tuple(valid)


class NewsWindow:
    """Evaluates the news blackout for one symbol/currency at a given UTC instant."""

    def __init__(
        self,
        events: Iterable[NewsEvent] | None,
        params: NewsParams | None = None,
        *,
        calendar_available: bool = True,
    ) -> None:
        self._params = params or NewsParams()
        _validate_params(self._params)
        self._calendar_available = bool(calendar_available)
        self._events = classify_events(events or (), self._params)

    @property
    def params(self) -> NewsParams:
        return self._params

    @property
    def calendar_available(self) -> bool:
        return self._calendar_available

    @property
    def events(self) -> tuple[NewsEvent, ...]:
        return self._events

    def blackout(self, now_utc: datetime) -> NewsState:
        """Current blackout state; never raises on malformed calendar rows."""
        try:
            now = utc(now_utc)
        except (AttributeError, TypeError, ValueError):
            # A broken clock must not look like a clear calendar.
            return NewsState(True, REASON_UNAVAILABLE, None, None)
        params = self._params
        if not params.enabled:
            return NewsState(False, "", None, None)
        if not self._calendar_available:
            if params.fail_safe == "trading_disabled":
                return NewsState(True, REASON_UNAVAILABLE, None, None)
            return self._conservative_state(now)
        return self._event_state(now)

    def _event_state(self, now: datetime) -> NewsState:
        params = self._params
        candidates: list[NewsEvent] = []
        for event in self._events:
            if event.impact is Impact.LOW:
                continue
            before, after = _impact_window(event.impact, params)
            starts = event.when_utc - timedelta(minutes=before)
            ends = event.when_utc + timedelta(minutes=after)
            if starts <= now <= ends:
                candidates.append(event)
        if not candidates:
            return NewsState(False, "", None, None)
        winner = min(
            candidates,
            key=lambda item: (
                _IMPACT_RANK.get(item.impact, 9),
                item.when_utc,
                item.title,
                item.currency,
            ),
        )
        _, after = _impact_window(winner.impact, params)
        reason = REASON_HIGH if winner.impact is Impact.HIGH else REASON_MEDIUM
        return NewsState(True, reason, winner, winner.when_utc + timedelta(minutes=after))

    def _conservative_state(self, now: datetime) -> NewsState:
        """Calendar-unavailable fallback; centres follow the US release clock.

        Configured centres are the US standard-time (winter) UTC values. While US
        DST is active (second Sunday of March to first Sunday of November) the
        release clock moves one hour earlier, so the effective centre moves too.
        """
        if now.weekday() >= 5:
            return NewsState(False, "", None, None)
        shift = timedelta(minutes=60) if us_dst_active(now) else timedelta(0)
        for hour, minute, half_width in self._params.conservative_windows:
            center = (
                now.replace(hour=int(hour), minute=int(minute), second=0, microsecond=0)
                - shift
            )
            ends = center + timedelta(minutes=half_width)
            if center - timedelta(minutes=half_width) <= now <= ends:
                return NewsState(True, REASON_CONSERVATIVE, None, ends)
        return NewsState(False, "", None, None)
