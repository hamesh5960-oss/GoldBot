"""Capital-level controller: BASE bands, level policy and the approval protocol.

The static risk profile is the floor. This module is the opt-in layer that can
replace profile limits with capital-level policy. It can only *tighten* them,
with one deliberate exception: the BASE level may exceed the 1.5% envelope only
through its own 5% band, and only while explicitly armed (base_enabled +
base_armed + onboarding ack + equity below $200). The 5% number never leaks to
another level or to a tier-based risk source.

Pure application module: no adapters, no runtime, no wall-clock reads.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from datetime import datetime, timedelta
from enum import Enum
from typing import Any, Mapping

from .decision import TIER_RISK_PCT, Tier

__all__ = [
    "ACTION_DOWNGRADE",
    "ACTION_EXPIRE_PROPOSAL",
    "ACTION_KEEP",
    "ACTION_PROPOSE_UPGRADE",
    "ALL_SESSIONS",
    "BASE_BANDS",
    "BASE_MAX_EQUITY",
    "CORE_SESSIONS",
    "CapitalLevel",
    "LEVEL_POLICIES",
    "LevelConfig",
    "LevelDecision",
    "LevelPolicy",
    "LevelState",
    "RISK_SOURCE_BANDS",
    "RISK_SOURCE_TIER",
    "BaseBand",
    "active_level_for_execution",
    "approve_upgrade",
    "band_risk_pct",
    "decline_upgrade",
    "determine_level",
    "enforce_level",
    "policy_for",
    "risk_pct_for_level",
    "start_level",
    "update_counters",
]


# The four capital levels, ordered from smallest account to largest.
class CapitalLevel(str, Enum):
    BASE = "base"
    LOW_RISK = "low_risk"
    MEDIUM_RISK = "medium_risk"
    HIGH_RISK = "high_risk"


_LEVEL_ORDER: tuple[CapitalLevel, ...] = (
    CapitalLevel.BASE,
    CapitalLevel.LOW_RISK,
    CapitalLevel.MEDIUM_RISK,
    CapitalLevel.HIGH_RISK,
)

# Hard ceiling of the BASE band ladder. Never a generic risk ceiling.
MAX_BASE_RISK_PCT = 5.0
MAX_LEVEL_RISK_PCT = 1.0
# BASE may only ever run below this equity; at/above it the band ladder ends.
BASE_MAX_EQUITY = 200.0
# A level change (or a fresh BASE start) is not reviewed for an upgrade sooner
# than this, so a hot streak cannot ratchet the account overnight.
MIN_DAYS_BETWEEN_LEVEL_CHANGES = 7


@dataclass(frozen=True, slots=True)
class BaseBand:
    """One rung of the BASE risk ladder.

    hysteresis_enter is the equity at which a *safer* band may be entered from
    a riskier one; leaving for a riskier band happens immediately at min_eq.
    This removes the 199 <-> 201 chattering around a boundary.
    """

    min_eq: float
    max_eq: float
    risk_pct: float
    hysteresis_enter: float

    def contains(self, equity: float) -> bool:
        return self.min_eq <= equity < self.max_eq


BASE_BANDS: tuple[BaseBand, ...] = (
    BaseBand(0.0, 200.0, 5.0, 0.0),
    BaseBand(200.0, 300.0, 4.0, 220.0),
    BaseBand(300.0, 400.0, 3.0, 330.0),
    BaseBand(400.0, 500.0, 2.0, 440.0),
    BaseBand(500.0, math.inf, 1.5, 550.0),
)


def _band_index(equity: float) -> int:
    """Natural BASE band for the current equity (no hysteresis)."""
    for index, band in enumerate(BASE_BANDS):
        if equity < band.max_eq:
            return index
    return len(BASE_BANDS) - 1


def band_risk_pct(equity: float, previous_band: int | None = None) -> tuple[float, int]:
    """Risk percent and band index for BASE, with asymmetric hysteresis.

    * A smaller account is always moved to the riskier band immediately.
    * A larger account only enters a safer band once the target band's
      hysteresis_enter is reached; no unmet band is ever skipped.
    * The returned risk never exceeds 5% (that value is band 0 only).
    """
    raw = _band_index(equity)
    if previous_band is None:
        index = raw
    else:
        previous = max(0, min(int(previous_band), len(BASE_BANDS) - 1))
        if raw <= previous:
            # Same band, or equity fell below the previous band's floor:
            # moving to a riskier band is immediate.
            index = raw
        else:
            # Equity rose into safer territory: honour the entry trigger of
            # every band on the way up, and never skip an unmet one.
            index = previous
            for candidate in range(previous + 1, raw + 1):
                if equity >= BASE_BANDS[candidate].hysteresis_enter:
                    index = candidate
                else:
                    break
    return (min(BASE_BANDS[index].risk_pct, MAX_BASE_RISK_PCT), index)


def _as_level(value: CapitalLevel | str) -> CapitalLevel:
    if isinstance(value, CapitalLevel):
        return value
    return CapitalLevel(str(value))


def _tier_key(tier: Tier | str | None) -> Tier | None:
    if isinstance(tier, Tier):
        return tier
    if isinstance(tier, str):
        try:
            return Tier(tier)
        except ValueError:
            return None
    return None


def risk_pct_for_level(
    level: CapitalLevel | str,
    tier: Tier | str | None,
    equity: float,
    *,
    previous_band: int | None = None,
    base_enabled: bool = False,
) -> float:
    """Per-trade risk percent for a capital level.

    BASE is the only source allowed above 1.0%, and only when explicitly
    enabled; otherwise BASE is 0% (the caller must gate execution instead of
    trading it). Tier-sourced levels never leave the tier table and are
    hard-capped at 1.0%.
    """
    try:
        level_value = _as_level(level)
    except ValueError:
        return 0.0
    if level_value is CapitalLevel.BASE:
        if not base_enabled:
            return 0.0
        return band_risk_pct(equity, previous_band)[0]
    tier_value = _tier_key(tier)
    if tier_value is None:
        return 0.0
    return min(max(TIER_RISK_PCT.get(tier_value, 0.0), 0.0), MAX_LEVEL_RISK_PCT)


# Session labels used by the level policy. 'overlap' is the London/NY overlap;
# 'all' policies also allow the quiet Asia window.
CORE_SESSIONS: tuple[str, ...] = ("london", "overlap", "ny")
ALL_SESSIONS: tuple[str, ...] = ("asia", "london", "overlap", "ny", "late_ny")

RISK_SOURCE_BANDS = "base_bands"
RISK_SOURCE_TIER = "tier"


@dataclass(frozen=True, slots=True)
class LevelPolicy:
    """Per-level limits. Anything numeric is a cap: smaller is stricter."""

    allowed_tiers: frozenset[str]
    zone_floors: Mapping[str, int]
    max_trades_per_day: int
    max_open_risk_pct: float
    max_daily_loss_pct: float
    max_consecutive_losses: int
    amplifier_enabled: bool
    gates_enabled: bool
    sessions: tuple[str, ...]
    news_before_minutes: int
    spread_ratio: float
    kill_switch_dd_pct: float
    min_equity: float
    risk_source: str


LEVEL_POLICIES: Mapping[CapitalLevel, LevelPolicy] = {
    CapitalLevel.BASE: LevelPolicy(
        allowed_tiers=frozenset({Tier.A_PLUS.value}),
        zone_floors={},
        max_trades_per_day=1,
        max_open_risk_pct=5.0,
        max_daily_loss_pct=3.0,
        max_consecutive_losses=2,
        amplifier_enabled=False,
        gates_enabled=False,
        sessions=CORE_SESSIONS,
        news_before_minutes=30,
        spread_ratio=0.08,
        kill_switch_dd_pct=10.0,
        min_equity=0.0,
        risk_source=RISK_SOURCE_BANDS,
    ),
    CapitalLevel.LOW_RISK: LevelPolicy(
        allowed_tiers=frozenset({Tier.A_PLUS.value, Tier.A.value}),
        zone_floors={},
        max_trades_per_day=2,
        max_open_risk_pct=2.0,
        max_daily_loss_pct=3.0,
        max_consecutive_losses=3,
        amplifier_enabled=False,
        gates_enabled=True,
        sessions=CORE_SESSIONS,
        news_before_minutes=15,
        spread_ratio=0.10,
        kill_switch_dd_pct=15.0,
        min_equity=0.0,
        risk_source=RISK_SOURCE_TIER,
    ),
    CapitalLevel.MEDIUM_RISK: LevelPolicy(
        allowed_tiers=frozenset({Tier.A_PLUS.value, Tier.A.value, Tier.B.value}),
        zone_floors={},
        max_trades_per_day=3,
        max_open_risk_pct=3.0,
        max_daily_loss_pct=3.0,
        max_consecutive_losses=4,
        amplifier_enabled=True,
        gates_enabled=True,
        sessions=ALL_SESSIONS,
        news_before_minutes=15,
        spread_ratio=0.15,
        kill_switch_dd_pct=20.0,
        min_equity=0.0,
        risk_source=RISK_SOURCE_TIER,
    ),
    CapitalLevel.HIGH_RISK: LevelPolicy(
        allowed_tiers=frozenset(
            {Tier.A_PLUS.value, Tier.A.value, Tier.B.value, Tier.C.value}
        ),
        zone_floors={},
        max_trades_per_day=3,
        max_open_risk_pct=3.0,
        max_daily_loss_pct=3.0,
        max_consecutive_losses=4,
        amplifier_enabled=True,
        gates_enabled=True,
        sessions=ALL_SESSIONS,
        news_before_minutes=15,
        spread_ratio=0.15,
        kill_switch_dd_pct=20.0,
        min_equity=0.0,
        risk_source=RISK_SOURCE_TIER,
    ),
}


def policy_for(level: CapitalLevel | str) -> LevelPolicy:
    """Policy lookup. Execution gating is separate (see active_level_for_execution)."""
    return LEVEL_POLICIES[_as_level(level)]


def _iso(value: datetime | None) -> str | None:
    return value.isoformat() if value is not None else None


def _dt(value: object) -> datetime | None:
    if value in (None, ""):
        return None
    if isinstance(value, datetime):
        return value
    return datetime.fromisoformat(str(value))


@dataclass(slots=True)
class LevelState:
    """Mutable controller state; the only part that must survive a restart."""

    active_level: CapitalLevel = CapitalLevel.BASE
    previous_band: int | None = None
    pending_level: CapitalLevel | None = None
    pending_since: datetime | None = None
    decline_until: datetime | None = None
    days_above_threshold: int = 0
    trades_in_level: int = 0
    last_level_change: datetime | None = None
    base_started_at: datetime | None = None

    def to_dict(self) -> dict[str, Any]:
        """JSON-safe representation (dates are ISO-8601 strings)."""
        return {
            "active_level": self.active_level.value,
            "previous_band": self.previous_band,
            "pending_level": (
                self.pending_level.value if self.pending_level is not None else None
            ),
            "pending_since": _iso(self.pending_since),
            "decline_until": _iso(self.decline_until),
            "days_above_threshold": int(self.days_above_threshold),
            "trades_in_level": int(self.trades_in_level),
            "last_level_change": _iso(self.last_level_change),
            "base_started_at": _iso(self.base_started_at),
        }

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "LevelState":
        """Rebuild state from to_dict()/JSON; raises ValueError on bad levels."""
        if not isinstance(data, Mapping):
            raise TypeError("level state payload must be a mapping")
        active = CapitalLevel(str(data.get("active_level", CapitalLevel.BASE.value)))
        pending_raw = data.get("pending_level")
        previous_raw = data.get("previous_band")
        return cls(
            active_level=active,
            previous_band=None if previous_raw is None else int(previous_raw),
            pending_level=(
                CapitalLevel(str(pending_raw)) if pending_raw not in (None, "") else None
            ),
            pending_since=_dt(data.get("pending_since")),
            decline_until=_dt(data.get("decline_until")),
            days_above_threshold=int(data.get("days_above_threshold") or 0),
            trades_in_level=int(data.get("trades_in_level") or 0),
            last_level_change=_dt(data.get("last_level_change")),
            base_started_at=_dt(data.get("base_started_at")),
        )


@dataclass(frozen=True, slots=True)
class LevelConfig:
    """Operator configuration for the controller (config/base.toml [levels])."""

    low_risk_threshold: float = 1500.0
    medium_risk_threshold: float = 2000.0
    high_risk_threshold: float = 4000.0
    approval_timeout_days: int = 7
    decline_cooldown_days: int = 30
    min_days_above_threshold: int = 5
    min_trades_in_level: int = 5
    base_enabled: bool = False
    auto_downgrade: bool = True

    def __post_init__(self) -> None:
        if not self.low_risk_threshold > 0:
            raise ValueError("low_risk_threshold must be positive")
        if not (
            self.low_risk_threshold
            < self.medium_risk_threshold
            < self.high_risk_threshold
        ):
            raise ValueError(
                "risk thresholds must be strictly ascending: low < medium < high"
            )
        for name in (
            "approval_timeout_days",
            "decline_cooldown_days",
            "min_days_above_threshold",
            "min_trades_in_level",
        ):
            if getattr(self, name) < 0:
                raise ValueError(f"{name} must be non-negative")


# Decision actions. Kept as plain strings so journals and JSON stay readable.
ACTION_KEEP = "keep"
ACTION_DOWNGRADE = "downgrade"
ACTION_PROPOSE_UPGRADE = "propose_upgrade"
ACTION_EXPIRE_PROPOSAL = "expire_proposal"


@dataclass(frozen=True, slots=True)
class LevelDecision:
    """Outcome of one determine_level() evaluation."""

    action: str
    active_level: CapitalLevel
    proposed_level: CapitalLevel | None
    reason: str
    state: LevelState


def _next_threshold(level: CapitalLevel, config: LevelConfig) -> float | None:
    if level is CapitalLevel.BASE:
        return config.low_risk_threshold
    if level is CapitalLevel.LOW_RISK:
        return config.medium_risk_threshold
    if level is CapitalLevel.MEDIUM_RISK:
        return config.high_risk_threshold
    return None


def _downgrade_target(
    level: CapitalLevel,
    equity: float,
    drawdown_pct: float,
    consecutive_losses: int,
    config: LevelConfig,
) -> tuple[CapitalLevel | None, str]:
    """Immediate, approval-free safety downgrade (or None)."""
    if level is CapitalLevel.HIGH_RISK:
        if equity < 0.8 * config.medium_risk_threshold:
            return CapitalLevel.MEDIUM_RISK, "equity_below_floor"
        if drawdown_pct > 20.0:
            return CapitalLevel.MEDIUM_RISK, "drawdown"
        if consecutive_losses >= 4:
            return CapitalLevel.MEDIUM_RISK, "consecutive_losses"
    elif level is CapitalLevel.MEDIUM_RISK:
        if equity < 0.8 * config.low_risk_threshold:
            return CapitalLevel.LOW_RISK, "equity_below_floor"
        if drawdown_pct > 15.0:
            return CapitalLevel.LOW_RISK, "drawdown"
        if consecutive_losses >= 3:
            return CapitalLevel.LOW_RISK, "consecutive_losses"
    elif level is CapitalLevel.LOW_RISK:
        if equity < 0.8 * config.low_risk_threshold:
            return CapitalLevel.BASE, "equity_below_floor"
        if drawdown_pct > 10.0:
            return CapitalLevel.BASE, "drawdown"
        if consecutive_losses >= 3:
            return CapitalLevel.BASE, "consecutive_losses"
    return None, "no_change"


def _upgrade_target(
    level: CapitalLevel, equity: float, config: LevelConfig
) -> CapitalLevel | None:
    threshold = _next_threshold(level, config)
    if threshold is None or equity < threshold:
        return None
    return _LEVEL_ORDER[_LEVEL_ORDER.index(level) + 1]


def _proposal_blocker(
    level: CapitalLevel,
    equity: float,
    open_positions: int,
    now: datetime,
    state: LevelState,
    config: LevelConfig,
    trades_in_level: int,
    days_above_threshold: int,
) -> str | None:
    """First unmet upgrade gate, or None when a proposal is allowed."""
    if level is CapitalLevel.BASE and not config.base_enabled:
        # BASE is OFF by default and never proposed while disabled.
        return "base_disabled"
    target = _upgrade_target(level, equity, config)
    if target is None:
        if _next_threshold(level, config) is None:
            return "no_upgrade_path"
        return "below_threshold"
    if state.decline_until is not None and now < state.decline_until:
        return "decline_cooldown"
    if level is CapitalLevel.BASE:
        if days_above_threshold < config.min_days_above_threshold:
            return "days_below_min"
        if trades_in_level < config.min_trades_in_level:
            return "trades_below_min"
        if open_positions != 0:
            return "open_positions"
        if state.last_level_change is not None and (
            now - state.last_level_change
            < timedelta(days=MIN_DAYS_BETWEEN_LEVEL_CHANGES)
        ):
            return "min_interval"
    return None


def determine_level(
    equity: float,
    drawdown_pct: float,
    consecutive_losses: int,
    open_positions: int,
    now: datetime,
    state: LevelState,
    config: LevelConfig,
    trades_in_level: int | None = None,
    days_above_threshold: int | None = None,
) -> LevelDecision:
    """Evaluate one bar/day of the level FSM and mutate the supplied state.

    Order of precedence: safety downgrade -> proposal expiry -> keep -> new
    proposal. The supplied state is updated in place and returned on the
    decision, so the caller always has the resulting state.
    """
    if trades_in_level is not None:
        state.trades_in_level = int(trades_in_level)
    if days_above_threshold is not None:
        state.days_above_threshold = int(days_above_threshold)

    # Advance the BASE hysteresis cursor on every evaluation, even when the
    # active level is tier-based, so re-entering BASE is consistent.
    state.previous_band = band_risk_pct(equity, state.previous_band)[1]

    target, reason = _downgrade_target(
        state.active_level, equity, drawdown_pct, consecutive_losses, config
    )
    if target is not None and config.auto_downgrade:
        state.active_level = target
        state.pending_level = None
        state.pending_since = None
        state.days_above_threshold = 0
        state.trades_in_level = 0
        state.last_level_change = now
        state.base_started_at = now if target is CapitalLevel.BASE else None
        return LevelDecision(
            action=ACTION_DOWNGRADE,
            active_level=state.active_level,
            proposed_level=None,
            reason=reason,
            state=state,
        )

    if state.pending_level is not None:
        pending = state.pending_level
        timeout = timedelta(days=config.approval_timeout_days)
        if state.pending_since is not None and now - state.pending_since > timeout:
            state.pending_level = None
            state.pending_since = None
            state.decline_until = now + timedelta(days=config.decline_cooldown_days)
            state.days_above_threshold = 0
            return LevelDecision(
                action=ACTION_EXPIRE_PROPOSAL,
                active_level=state.active_level,
                proposed_level=pending,
                reason="approval_timeout",
                state=state,
            )
        return LevelDecision(
            action=ACTION_KEEP,
            active_level=state.active_level,
            proposed_level=pending,
            reason="awaiting_approval",
            state=state,
        )

    blocker = _proposal_blocker(
        state.active_level,
        equity,
        open_positions,
        now,
        state,
        config,
        state.trades_in_level,
        state.days_above_threshold,
    )
    if blocker is not None:
        return LevelDecision(
            action=ACTION_KEEP,
            active_level=state.active_level,
            proposed_level=None,
            reason=blocker,
            state=state,
        )

    proposal = _upgrade_target(state.active_level, equity, config)
    state.pending_level = proposal
    state.pending_since = now
    return LevelDecision(
        action=ACTION_PROPOSE_UPGRADE,
        active_level=state.active_level,
        proposed_level=proposal,
        reason="upgrade_conditions_met",
        state=state,
    )


def start_level(equity: float, config: LevelConfig) -> LevelState:
    """Initial state for an account.

    BASE is returned for equity below the low threshold; callers that gate
    execution must still pass it through active_level_for_execution().
    """
    if equity < config.low_risk_threshold:
        level = CapitalLevel.BASE
    elif equity < config.medium_risk_threshold:
        level = CapitalLevel.LOW_RISK
    elif equity < config.high_risk_threshold:
        level = CapitalLevel.MEDIUM_RISK
    else:
        level = CapitalLevel.HIGH_RISK
    _, band = band_risk_pct(equity, None)
    return LevelState(active_level=level, previous_band=band)


def active_level_for_execution(
    level: CapitalLevel | str,
    base_enabled: bool,
    base_armed: bool,
    onboarding_ack: bool,
    equity: float,
) -> CapitalLevel | None:
    """Level the engine may actually trade, or None when BASE is not permitted.

    BASE requires every interlock: feature enable, explicit arming, the
    onboarding acknowledgement and equity still inside the band ladder.
    Other levels pass through unchanged.
    """
    level_value = _as_level(level)
    if level_value is not CapitalLevel.BASE:
        return level_value
    if not (base_enabled and base_armed and onboarding_ack):
        return None
    if equity >= BASE_MAX_EQUITY:
        return None
    return CapitalLevel.BASE


def approve_upgrade(state: LevelState, now: datetime) -> LevelState:
    """Activate a pending proposal (operator approval). Mutates and returns state."""
    if state.pending_level is None:
        return state
    state.active_level = state.pending_level
    state.pending_level = None
    state.pending_since = None
    state.days_above_threshold = 0
    state.trades_in_level = 0
    state.last_level_change = now
    state.base_started_at = None
    return state


def decline_upgrade(state: LevelState, now: datetime, config: LevelConfig) -> LevelState:
    """Reject a pending proposal and start a re-proposal cooldown."""
    if state.pending_level is None:
        return state
    state.pending_level = None
    state.pending_since = None
    state.decline_until = now + timedelta(days=config.decline_cooldown_days)
    state.days_above_threshold = 0
    return state


def update_counters(
    state: LevelState,
    *,
    trade_closed: bool = False,
    day_passed: bool = False,
    equity: float | None = None,
    threshold: float | None = None,
    config: LevelConfig | None = None,
) -> LevelState:
    """Advance the proposal counters; mutates and returns state.

    trade_closed counts a trade at the current level. day_passed counts a day
    with equity at/above the next upgrade threshold, and resets the streak
    when it is not. The threshold is derived from config when it is not
    supplied explicitly.
    """
    if trade_closed:
        state.trades_in_level += 1
    if day_passed:
        if threshold is None and config is not None:
            threshold = _next_threshold(state.active_level, config)
        if threshold is not None and equity is not None:
            if equity >= threshold:
                state.days_above_threshold += 1
            else:
                state.days_above_threshold = 0
    return state


# Keys whose *smaller* value is stricter.
_TIGHTEN_MIN_KEYS = (
    "max_trades_per_day",
    "max_open_risk_pct",
    "max_daily_loss_pct",
    "max_consecutive_losses",
    "spread_ratio",
    "kill_switch_dd_pct",
)
# Keys whose *larger* value is stricter.
_TIGHTEN_MAX_KEYS = ("news_before_minutes", "min_equity")
_INT_KEYS = ("max_trades_per_day", "max_consecutive_losses")
_BOOL_KEYS = ("amplifier_enabled", "gates_enabled")


def _number(value: object) -> float | None:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    return float(value)


def _token(item: object) -> str:
    value = getattr(item, "value", None)
    if isinstance(value, str):
        return value
    return str(item)


def _string_tuple(value: object) -> tuple[str, ...] | None:
    if isinstance(value, str):
        return tuple(part.strip() for part in value.split(",") if part.strip())
    if isinstance(value, (list, tuple, set, frozenset)):
        return tuple(_token(item) for item in value)
    return None


def enforce_level(
    level_policy: LevelPolicy, profile_limits: Mapping[str, Any]
) -> dict[str, Any]:
    """Merge level policy with profile limits, tightening only.

    The profile may shrink every cap, intersect tiers/sessions and raise
    floors; it can never loosen a level value. BASE remains the only loosening
    path in the system, and that path requires explicit arming (see
    active_level_for_execution) -- never this helper.
    """
    effective: dict[str, Any] = {
        "allowed_tiers": frozenset(level_policy.allowed_tiers),
        "zone_floors": dict(level_policy.zone_floors),
        "max_trades_per_day": level_policy.max_trades_per_day,
        "max_open_risk_pct": level_policy.max_open_risk_pct,
        "max_daily_loss_pct": level_policy.max_daily_loss_pct,
        "max_consecutive_losses": level_policy.max_consecutive_losses,
        "amplifier_enabled": level_policy.amplifier_enabled,
        "gates_enabled": level_policy.gates_enabled,
        "sessions": tuple(level_policy.sessions),
        "news_before_minutes": level_policy.news_before_minutes,
        "spread_ratio": level_policy.spread_ratio,
        "kill_switch_dd_pct": level_policy.kill_switch_dd_pct,
        "min_equity": level_policy.min_equity,
        "risk_source": level_policy.risk_source,
    }
    profile: Mapping[str, Any] = profile_limits or {}

    tiers = _string_tuple(profile.get("allowed_tiers"))
    if tiers is not None:
        allowed = frozenset(tiers)
        effective["allowed_tiers"] = frozenset(
            tier for tier in level_policy.allowed_tiers if tier in allowed
        )

    sessions = _string_tuple(profile.get("sessions"))
    if sessions is not None:
        allowed_sessions = frozenset(sessions)
        effective["sessions"] = tuple(
            session for session in level_policy.sessions if session in allowed_sessions
        )

    for key in _TIGHTEN_MIN_KEYS:
        candidate = _number(profile.get(key))
        if candidate is not None and candidate < effective[key]:
            effective[key] = candidate
    for key in _TIGHTEN_MAX_KEYS:
        candidate = _number(profile.get(key))
        if candidate is not None and candidate > effective[key]:
            effective[key] = candidate
    for key in _INT_KEYS:
        effective[key] = int(effective[key])
    for key in _BOOL_KEYS:
        candidate = profile.get(key)
        if isinstance(candidate, bool):
            effective[key] = effective[key] and candidate

    floors = profile.get("zone_floors")
    if isinstance(floors, Mapping):
        merged = dict(effective["zone_floors"])
        for zone, floor in floors.items():
            value = _number(floor)
            if value is None:
                continue
            current = _number(merged.get(str(zone)))
            if current is None or value > current:
                merged[str(zone)] = value
        effective["zone_floors"] = merged

    return effective
