"""Pure multi-level capability evaluator.

For one signal and one market/capital snapshot this module answers, for every
capital level, "would this level be allowed to take the trade, and if not, why
not?" It owns no state, reads no clock, writes no journal and never imports the
capital-level controller: the level policy is duck-typed, so the controller (or
the effective limits produced by enforce_level) can be passed directly.

Levels are ordered from safest/smallest to riskiest/largest:
BASE < LOW < MEDIUM < HIGH. The canonical names are exported as LEVEL_ORDER;
LEVEL_POLICIES enums may be used as keys because level names are normalised
(manager-style names such as LOW_RISK are accepted too).

Evaluation order (first failure wins):
    allowed tier -> zone floor -> session -> news -> spread -> rr floor ->
    gates (if the level enables them) -> trades/day -> open risk -> drawdown ->
    consecutive losses -> risk percent -> minimum-lot risk -> minimum capital.

Reason strings:
    eligible, tier_floor, zone_floor, session, news, spread, rr_floor,
    gate_b_burn, gate_c_hedge, gate_d_hard, max_trades_reached,
    max_open_risk, kill_switch_active, max_consecutive_losses,
    absolute_cap_5pct, band_risk_exceeded, min_lot_exceeds_risk,
    capital_below_threshold.

capacity_only is True when the only thing standing between the signal and this
level is account capacity (minimum-lot risk or the level's minimum equity), not
policy or market state.

The evaluator deliberately does not judge daily loss or amplifier sizing: they
need inputs (daily PnL, amplitude) that belong to the risk engine, so the level
envelope here is a capability gate, not an order approval.
"""

from __future__ import annotations

import math
from collections.abc import Mapping as MappingABC
from dataclasses import dataclass
from typing import Any, Mapping, Protocol, Sequence

from .decision import Tier

__all__ = [
    "CAPACITY_REASONS",
    "LEVEL_ORDER",
    "CapitalSpec",
    "LevelEvaluation",
    "LevelPolicyLike",
    "SignalSpec",
    "capability_summary",
    "classify_capabilities",
    "eval_for_level",
    "level_capabilities",
    "min_capital_for_base",
    "min_capital_for_level",
]

# Safest/smallest first. Rows and capability classification follow this order.
LEVEL_ORDER: tuple[str, ...] = ("BASE", "LOW", "MEDIUM", "HIGH")

# The only risk source allowed to exceed the normal 1% level envelope.
RISK_SOURCE_BANDS = "base_bands"

# Level-envelope ceiling for tier-sourced levels.
MAX_LEVEL_RISK_PCT = 1.0
# Absolute ceiling of the whole system (BASE band 0 only, never inherited).
MAX_ABSOLUTE_RISK_PCT = 5.0

# Absolute net R:R floor (ADR-034). The locked confirmation design removed the
# per-tier minimum, so an S/R-level capability check only needs this one floor.
DEFAULT_MIN_RR = 1.0

# Reasons that mean "eligible in principle, but the account is too small".
CAPACITY_REASONS: frozenset[str] = frozenset(
    {"min_lot_exceeds_risk", "capital_below_threshold"}
)

_LEVEL_ALIASES: dict[str, str] = {
    "BASE": "BASE",
    "LOW": "LOW",
    "LOW_RISK": "LOW",
    "LOWRISK": "LOW",
    "MEDIUM": "MEDIUM",
    "MEDIUM_RISK": "MEDIUM",
    "MEDIUMRISK": "MEDIUM",
    "HIGH": "HIGH",
    "HIGH_RISK": "HIGH",
    "HIGHRISK": "HIGH",
}

_EPS = 1e-9


def _level_name(level: object) -> str:
    """Normalise any level-ish value (string or enum) to LEVEL_ORDER spelling."""
    for candidate in (
        getattr(level, "name", None),
        getattr(level, "value", None),
        level,
    ):
        if isinstance(candidate, str):
            key = candidate.strip().upper().replace("-", "_").replace(" ", "_")
            if key in _LEVEL_ALIASES:
                return _LEVEL_ALIASES[key]
    raise ValueError(f"unknown capital level {level!r}")


def _policy_value(policy: object, key: str, default: Any = None) -> Any:
    """Read a duck-typed policy field from either an object or an effective dict."""
    if isinstance(policy, MappingABC):
        return policy.get(key, default)
    return getattr(policy, key, default)


def _as_float(value: object, field: str) -> float:
    try:
        return float(value)  # type: ignore[arg-type]
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{field} must be a number, got {value!r}") from exc


def _tier_text(tier: object) -> str:
    if isinstance(tier, Tier):
        return tier.value
    if isinstance(tier, str):
        return tier
    value = getattr(tier, "value", tier)
    return str(value)


def _floor_to_step(value: float, step: float) -> float:
    """Floor a lot size to the broker step; never round up."""
    if step <= 0.0 or value <= 0.0:
        return 0.0
    steps = math.floor(value / step + _EPS)
    return round(steps * step, 10)


@dataclass(frozen=True, slots=True)
class CapitalSpec:
    """Broker/account numbers the evaluator needs to size a minimum lot."""

    min_lot: float
    lot_step: float
    tick_value: float
    tick_size: float
    contract_size: float
    point: float
    equity: float
    max_lot: float = 1e9

    def __post_init__(self) -> None:
        if not math.isfinite(float(self.min_lot)) or self.min_lot <= 0.0:
            raise ValueError("min_lot must be a positive finite number")
        if not math.isfinite(float(self.lot_step)) or self.lot_step <= 0.0:
            raise ValueError("lot_step must be a positive finite number")
        if not math.isfinite(float(self.max_lot)) or self.max_lot < self.min_lot:
            raise ValueError("max_lot must be finite and at least min_lot")

    def risk_per_min_lot(self, sl_price: float) -> float:
        """Dollar risk of one lot for a stop this many price units away.

        Uses tick_value/tick_size when both are positive (the honest MT5
        path); otherwise falls back to contract_size, which is the only
        contract information a simple broker model offers.
        """
        distance = abs(float(sl_price))
        if distance <= 0.0:
            return 0.0
        if self.tick_size > 0.0 and self.tick_value > 0.0:
            return distance / self.tick_size * self.tick_value
        return distance * self.contract_size


@dataclass(frozen=True, slots=True)
class SignalSpec:
    """The signal facts the evaluator is allowed to see."""

    signal_id: str
    tier: str
    entry: float
    sl: float
    tp: float | None = None
    rr_net: float = 0.0
    zone_score_adj: float = 0.0
    session: str = ""
    news_blackout: bool = False
    spread_ratio: float = 0.0
    direction: str = "buy"


class LevelPolicyLike(Protocol):
    """Duck type of the capital-level policy (see app.capital_levels)."""

    allowed_tiers: Any
    zone_floors: Mapping[str, float]
    max_trades_per_day: int
    max_open_risk_pct: float
    max_daily_loss_pct: float
    max_consecutive_losses: int
    sessions: Sequence[str]
    news_before_minutes: int
    spread_ratio: float
    kill_switch_dd_pct: float
    min_equity: float
    risk_source: str


@dataclass(frozen=True, slots=True)
class LevelEvaluation:
    """Capability verdict for one capital level."""

    level: str
    eligible: bool
    reason: str
    would_be_lot: float
    would_be_risk_pct: float
    would_be_risk_dollars: float
    min_capital_needed: float
    capital_gap: float
    capacity_only: bool


def _stop_distance(signal: SignalSpec) -> float:
    return abs(float(signal.entry) - float(signal.sl))


def _min_rr_floor(signal: SignalSpec, policy: object) -> float:
    """Absolute R:R floor: policy.min_rr when provided, else DEFAULT_MIN_RR.

    signal is kept in the signature for callers/back-compat; the locked design
    has no tier-dependent R:R minimum (ADR-034), so it is not consulted.
    """
    explicit = _policy_value(policy, "min_rr", None)
    if explicit is not None:
        return _as_float(explicit, "policy.min_rr")
    return DEFAULT_MIN_RR


def _sizing(
    signal: SignalSpec,
    capital: CapitalSpec,
    policy: object,
    equity: float,
    candidate_risk_pct: float,
) -> tuple[float, float, float, float, float]:
    """Return (lot, risk_dollars, risk_pct, min_capital_needed, capital_gap)."""
    risk_per_lot = capital.risk_per_min_lot(_stop_distance(signal))
    if risk_per_lot <= 0.0 or equity <= 0.0 or candidate_risk_pct <= 0.0:
        return (0.0, 0.0, 0.0, math.inf, math.inf)
    budget = equity * candidate_risk_pct / 100.0
    raw_lots = budget / risk_per_lot
    lot = 0.0
    if raw_lots + _EPS >= capital.min_lot:
        lot = min(_floor_to_step(raw_lots, capital.lot_step), capital.max_lot)
    risk_dollars = lot * risk_per_lot
    risk_pct = risk_dollars / equity * 100.0
    needed = risk_per_lot * capital.min_lot / (candidate_risk_pct / 100.0)
    needed = max(needed, _as_float(_policy_value(policy, "min_equity", 0.0), "min_equity"))
    gap = max(0.0, needed - equity)
    return (lot, risk_dollars, risk_pct, needed, gap)


def eval_for_level(
    level: object,
    signal: SignalSpec,
    policy: LevelPolicyLike | Mapping[str, Any],
    capital: CapitalSpec,
    *,
    equity: float,
    open_risk_pct: float = 0.0,
    trades_today: int = 0,
    drawdown_pct: float = 0.0,
    consecutive_losses: int = 0,
    risk_pct: float | None = None,
    gate_b_burn: bool = False,
    gate_c_hedge: bool = False,
    gate_d_hard: bool = False,
) -> LevelEvaluation:
    """Evaluate one capital level against one signal and one account snapshot.

    risk_pct is the candidate per-trade risk for this level (normally the value
    returned by capital_levels.risk_pct_for_level). None means "the level grants
    no risk budget"; the row then reports a capacity shortfall rather than
    claiming eligibility. All checks are pure: neither signal nor policy is
    mutated and the result depends only on the arguments.
    """
    name = _level_name(level)
    equity = _as_float(equity, "equity")
    candidate = 0.0 if risk_pct is None else _as_float(risk_pct, "risk_pct")
    if not math.isfinite(candidate) or candidate < 0.0:
        raise ValueError(f"risk_pct must be a finite non-negative number, got {risk_pct!r}")

    lot, risk_dollars, actual_pct, needed, gap = _sizing(
        signal, capital, policy, equity, candidate
    )

    def verdict(reason: str) -> LevelEvaluation:
        return LevelEvaluation(
            level=name,
            eligible=reason == "eligible",
            reason=reason,
            would_be_lot=lot,
            would_be_risk_pct=actual_pct,
            would_be_risk_dollars=risk_dollars,
            min_capital_needed=needed,
            capital_gap=gap,
            capacity_only=reason in CAPACITY_REASONS,
        )

    tier_value = _tier_text(signal.tier)
    allowed = _policy_value(policy, "allowed_tiers", ())
    allowed_tiers = {_tier_text(tier) for tier in allowed}
    if tier_value not in allowed_tiers:
        return verdict("tier_floor")

    zone_floors = _policy_value(policy, "zone_floors", {}) or {}
    zone_floor = _as_float(
        (zone_floors.get(tier_value) if isinstance(zone_floors, MappingABC) else None)
        or 0.0,
        "zone floor",
    )
    if _as_float(signal.zone_score_adj, "signal.zone_score_adj") < zone_floor - _EPS:
        return verdict("zone_floor")

    sessions = tuple(str(item).strip().lower() for item in _policy_value(policy, "sessions", ()))
    session = str(signal.session).strip().lower()
    if sessions and "all" not in sessions and session not in sessions:
        return verdict("session")

    news_before = int(_policy_value(policy, "news_before_minutes", 0) or 0)
    if news_before > 0 and bool(signal.news_blackout):
        return verdict("news")

    spread = _as_float(_policy_value(policy, "spread_ratio", math.inf), "policy.spread_ratio")
    if _as_float(signal.spread_ratio, "signal.spread_ratio") > spread:
        return verdict("spread")

    rr_floor = _min_rr_floor(signal, policy)
    if rr_floor > 0.0 and _as_float(signal.rr_net, "signal.rr_net") < rr_floor - _EPS:
        return verdict("rr_floor")

    gates_enabled = bool(_policy_value(policy, "gates_enabled", True))
    if gates_enabled:
        if gate_b_burn:
            return verdict("gate_b_burn")
        if gate_c_hedge:
            return verdict("gate_c_hedge")
        if gate_d_hard:
            return verdict("gate_d_hard")

    if int(trades_today) >= int(_policy_value(policy, "max_trades_per_day", 2**31 - 1)):
        return verdict("max_trades_reached")
    if _as_float(open_risk_pct, "open_risk_pct") >= _as_float(
        _policy_value(policy, "max_open_risk_pct", math.inf), "max_open_risk_pct"
    ):
        return verdict("max_open_risk")
    if _as_float(drawdown_pct, "drawdown_pct") >= _as_float(
        _policy_value(policy, "kill_switch_dd_pct", math.inf), "kill_switch_dd_pct"
    ):
        return verdict("kill_switch_active")
    if int(consecutive_losses) >= int(
        _policy_value(policy, "max_consecutive_losses", 2**31 - 1)
    ):
        return verdict("max_consecutive_losses")

    source = str(_policy_value(policy, "risk_source", "tier")).strip().lower()
    if candidate > MAX_ABSOLUTE_RISK_PCT + _EPS:
        return verdict("absolute_cap_5pct")
    if source != RISK_SOURCE_BANDS and candidate > MAX_LEVEL_RISK_PCT + _EPS:
        return verdict("band_risk_exceeded")

    risk_per_lot = capital.risk_per_min_lot(_stop_distance(signal))
    if risk_per_lot <= 0.0 or candidate <= 0.0 or lot <= 0.0:
        return verdict("min_lot_exceeds_risk")
    if risk_dollars + _EPS < risk_per_lot * capital.min_lot:
        return verdict("min_lot_exceeds_risk")

    min_equity = _as_float(_policy_value(policy, "min_equity", 0.0), "min_equity")
    if equity < min_equity - _EPS:
        return verdict("capital_below_threshold")

    return verdict("eligible")


def min_capital_for_level(
    signal: SignalSpec,
    capital: CapitalSpec,
    risk_pct: float,
    min_equity: float = 0.0,
) -> float:
    """Equity needed for one minimum lot under this risk percent.

    Returns inf when the level grants no risk budget (for example a tier that is
    not allowed, which risk_pct_for_level reports as 0.0) or when the stop
    distance cannot be priced.
    """
    pct = _as_float(risk_pct, "risk_pct")
    if not math.isfinite(pct) or pct <= 0.0:
        return math.inf
    risk_per_lot = capital.risk_per_min_lot(_stop_distance(signal))
    if risk_per_lot <= 0.0 or capital.min_lot <= 0.0:
        return math.inf
    needed = risk_per_lot * capital.min_lot / (pct / 100.0)
    return max(needed, _as_float(min_equity, "min_equity"))


def min_capital_for_base(
    signal: SignalSpec,
    capital: CapitalSpec,
    bands: Sequence[object],
) -> float:
    """Equity needed to run BASE, using the band ranges (min_eq <= needed < max_eq).

    BASE risk is not a single number: each band pays a different risk percent.
    The first band whose equity range contains the resulting requirement wins;
    the band floors are therefore part of the answer, not just a floor on it.
    """
    risk_per_lot = capital.risk_per_min_lot(_stop_distance(signal))
    if risk_per_lot <= 0.0 or capital.min_lot <= 0.0:
        return math.inf
    cost = risk_per_lot * capital.min_lot
    for band in bands:
        risk_pct = _as_float(getattr(band, "risk_pct", 0.0), "band.risk_pct")
        if risk_pct <= 0.0:
            continue
        needed = cost / (risk_pct / 100.0)
        low = _as_float(getattr(band, "min_eq", 0.0), "band.min_eq")
        high = _as_float(getattr(band, "max_eq", math.inf), "band.max_eq")
        if low - _EPS <= needed < high:
            return needed
    return math.inf


def level_capabilities(
    signal: SignalSpec,
    capital: CapitalSpec,
    policies: Mapping[object, LevelPolicyLike | Mapping[str, Any]],
    equity: float,
    **state: Any,
) -> list[LevelEvaluation]:
    """Evaluate every supplied policy in BASE/LOW/MEDIUM/HIGH order.

    state is forwarded to eval_for_level. risk_pct may be one number for all
    levels or a mapping keyed by level when each level has its own risk source.
    Levels missing from policies are simply absent from the result.
    """
    by_level: dict[str, tuple[object, LevelPolicyLike | Mapping[str, Any]]] = {}
    for key, policy in policies.items():
        by_level.setdefault(_level_name(key), (key, policy))
    risk_source = state.get("risk_pct")
    rows: list[LevelEvaluation] = []
    for name in LEVEL_ORDER:
        found = by_level.get(name)
        if found is None:
            continue
        key, policy = found
        forwarded = dict(state)
        if isinstance(risk_source, MappingABC):
            forwarded["risk_pct"] = risk_source.get(name, risk_source.get(key))
        rows.append(
            eval_for_level(key, signal, policy, capital, equity=equity, **forwarded)
        )
    return rows


def classify_capabilities(
    rows: Sequence[LevelEvaluation],
) -> tuple[str | None, bool]:
    """Return (safest eligible level, missed opportunity flag).

    The best level is the safest eligible one (BASE before LOW before MEDIUM
    before HIGH), because that is the level an account of this size should use.
    missed is True when no level is eligible but at least one level failed only
    on capacity: the trade was real and only the account was too small.
    """
    def rank(row: LevelEvaluation) -> int:
        name = _level_name(row.level)
        return LEVEL_ORDER.index(name) if name in LEVEL_ORDER else len(LEVEL_ORDER)

    ordered = sorted(rows, key=rank)
    best: str | None = None
    for row in ordered:
        if row.eligible:
            best = row.level
            break
    missed = best is None and any(row.capacity_only for row in ordered)
    return (best, missed)


def capability_summary(rows: Sequence[LevelEvaluation]) -> dict[str, Any]:
    """Compact monitoring view: eligible count, gap reasons and the capital floor."""
    gaps: dict[str, int] = {}
    eligible = 0
    for row in rows:
        if row.eligible:
            eligible += 1
            continue
        gaps[row.reason] = gaps.get(row.reason, 0) + 1
    floor = math.inf
    for row in rows:
        if row.min_capital_needed < floor:
            floor = row.min_capital_needed
    return {
        "count_eligible": eligible,
        "gaps_by_reason": gaps,
        "min_capital_needed": floor if rows else math.inf,
    }
