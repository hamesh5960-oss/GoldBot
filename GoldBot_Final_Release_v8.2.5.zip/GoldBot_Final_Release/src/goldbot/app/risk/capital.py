"""Capital manager: the eleven-step sizing pipeline (spec section 6).

Order is not negotiable: tier -> R:R -> drawdown -> volatility -> event ->
clamp -> portfolio budget -> lot -> physical minimum -> execution guard.
"""

from __future__ import annotations

import math
from collections.abc import Collection, Mapping
from dataclasses import dataclass
from datetime import datetime

from ...domain.model import SymbolInfo
from ..costs import CostParams, effective_loss_per_lot
from ..decision import TIER_RISK_PCT, Tier, clamp
from .sizing import floor_to_step


@dataclass(frozen=True, slots=True)
class CapitalParams:
    risk_floor_pct: float = 0.10
    risk_ceiling_pct: float = 1.50
    portfolio_ceiling_pct: float = 3.0
    # Soft comfort line; the hard line is what actually rejects.
    gate_d_max_risk_pct: float = 2.0
    # ADR-001: the default hard line is the safer 2%; an operator may raise it
    # to 3% explicitly (config/base.toml does). Never drift this default upward.
    gate_d_hard_pct: float = 2.0
    # Absolute per-trade risk cap after Tier/profile constraints.
    trade_risk_cap_pct: float = 1.0
    vol_mid_pct: float = 80.0
    vol_high_pct: float = 95.0
    asia_factor: float = 0.75
    news_factor: float = 0.50
    vol_mid_factor: float = 0.75
    vol_high_factor: float = 0.50
    triple_swap_weekday: int = 2  # Wednesday
    triple_swap_hour: int = 20


@dataclass(frozen=True, slots=True)
class CapitalPlan:
    volume: float
    risk_pct: float
    risk_amount: float
    intended_pct: float
    raw_volume: float
    loss_per_lot: float
    reason: str = ""
    dd_factor: float = 1.0
    vol_factor: float = 1.0
    event_factor: float = 1.0
    remaining_budget_pct: float = 0.0

    @property
    def tradable(self) -> bool:
        return self.volume > 0 and not self.reason


def drawdown_factor(drawdown_pct: float) -> float:
    if drawdown_pct < 5.0:
        return 1.00
    if drawdown_pct < 10.0:
        return 0.75
    if drawdown_pct < 15.0:
        return 0.50
    return 0.25


def volatility_factor(percentile: float | None, params: CapitalParams) -> float:
    if percentile is None:
        return 1.0
    if percentile > params.vol_high_pct:
        return params.vol_high_factor
    if percentile >= params.vol_mid_pct:
        return params.vol_mid_factor
    return 1.0


def event_factor(
    now: datetime,
    session: str,
    news_blackout: bool,
    params: CapitalParams,
    broker_now: datetime | None = None,
) -> tuple[float, bool]:
    moment = broker_now or now
    minutes = moment.hour * 60 + moment.minute
    # Rollover is a broker-server event, never a UTC one.
    if minutes >= 23 * 60 + 55 or minutes <= 5:
        return (0.0, True)
    if (
        moment.weekday() == params.triple_swap_weekday
        and minutes >= params.triple_swap_hour * 60
    ):
        return (0.0, True)
    if news_blackout:
        return (params.news_factor, False)
    if session == "asia":
        return (params.asia_factor, False)
    return (1.0, False)


def daily_atr_percentile(daily_atr: list[float], current: float | None, *, minimum: int = 20) -> float | None:
    if current is None or len(daily_atr) < minimum:
        return None
    window = daily_atr[-90:]
    hits = sum(1 for value in window if value <= current)
    return 100.0 * hits / len(window)


def expected_nights_for(max_holding_hours: float | None) -> int:
    """Broker rollovers a trade may survive inside the allowed holding window.

    Sizing and the journaled cost estimate both call this helper, so the swap
    leg can never be under-counted: any fraction of a day is charged as a full
    rollover and the Wednesday triple-swap rule is then applied by
    costs.nights_charged(). A missing/zero horizon ("no limit") falls back to
    the conservative one-night assumption.
    """
    if max_holding_hours is None or max_holding_hours <= 0.0:
        return 1
    return max(1, math.ceil(max_holding_hours / 24.0))


def plan_entry(
    *,
    tier: Tier | None,
    risk_multiplier: float,
    equity: float,
    stop_distance: float,
    info: SymbolInfo,
    commission_per_lot: float,
    open_risk_pct: float,
    profile_cap_pct: float,
    drawdown_pct: float,
    atr_percentile: float | None,
    session: str,
    news_blackout: bool,
    now: datetime,
    params: CapitalParams,
    manual_lot: float = 0.0,
    force_min_lot: bool = False,
    broker_now: datetime | None = None,
    # Full cost model: when supplied it replaces the commission-only estimate,
    # so a zero-spread backtest and a live run size differently by design.
    costs: CostParams | None = None,
    # Explicit override for tests/legacy callers; None derives from the profile
    # holding window below (CL-05: one night under-counted multi-day holds).
    expected_nights: int | None = None,
    max_holding_hours: float | None = None,
    side: str = "buy",
    spread_points: float | None = None,
    profile_open_risk_cap_pct: float | None = None,
    # Tier matrix (ADR-036), passed from the profile. None keeps the legacy
    # behaviour: every tier is allowed and the profile cap is the only ceiling.
    tier_risk_caps: Mapping[str, float] | None = None,
    allowed_tiers: Collection[str] | None = None,
) -> CapitalPlan:
    if tier is not None:
        tier_value = tier.value
        if allowed_tiers is not None and tier_value not in allowed_tiers:
            # The profile does not trade this tier at all (e.g. low rejects B/C).
            return CapitalPlan(0.0, 0.0, 0.0, 0.0, 0.0, 0.0, "tier_not_allowed")
        tier_base = TIER_RISK_PCT.get(tier, 0.0)
        caps = tier_risk_caps if tier_risk_caps is not None else {}
        tier_cap = float(caps.get(tier_value, profile_cap_pct))
        # Base risk = tier base, clamped by the tier cap and the profile envelope.
        base = min(tier_base, max(0.0, tier_cap), profile_cap_pct)
        if base <= 0.0:
            # D and NOISE carry no risk: never lifted to the risk floor.
            return CapitalPlan(0.0, 0.0, 0.0, 0.0, 0.0, 0.0, "tier_no_risk")
    else:
        base = profile_cap_pct
    multiplier = max(0.0, min(1.5, risk_multiplier))
    raw_pct = base * multiplier

    dd_f = drawdown_factor(drawdown_pct)
    vol_f = volatility_factor(atr_percentile, params)
    ev_f, blocked = event_factor(now, session, news_blackout, params, broker_now=broker_now)
    if blocked:
        return CapitalPlan(0.0, 0.0, 0.0, raw_pct, 0.0, 0.0, "rollover_block", dd_f, vol_f, ev_f)

    trade_cap = min(params.risk_ceiling_pct, params.trade_risk_cap_pct)
    intended = clamp(raw_pct * dd_f * vol_f * ev_f, params.risk_floor_pct, trade_cap)

    soft = params.gate_d_max_risk_pct
    hard = max(soft, params.gate_d_hard_pct)
    aggregate_cap = min(params.portfolio_ceiling_pct, hard)
    if profile_open_risk_cap_pct is not None:
        # A profile cap may only tighten the Gate D envelope; raising it is a
        # deliberate profile edit (ADR-025), never a silent default change.
        aggregate_cap = min(aggregate_cap, max(0.0, float(profile_open_risk_cap_pct)))
    hard_remaining = aggregate_cap - open_risk_pct
    if hard_remaining <= 0:
        return CapitalPlan(0.0, 0.0, 0.0, intended, 0.0, 0.0, "gate_d_total_risk", dd_f, vol_f, ev_f)

    risk_pct = min(intended, hard_remaining)
    # Soft band: between the comfort line and the hard line the size is halved,
    # never rejected; the hard line above still caps the total.
    if open_risk_pct + risk_pct > soft + 1e-9 and open_risk_pct + risk_pct <= hard + 1e-9:
        risk_pct = min(risk_pct * 0.5, hard_remaining)

    if costs is None:
        loss_per_lot = stop_distance * info.contract_size + commission_per_lot
    else:
        # Swap horizon: never assume fewer rollovers than the profile allows the
        # position to survive (CL-05). An explicit expected_nights still wins.
        sizing_nights = (
            expected_nights
            if expected_nights is not None
            else expected_nights_for(max_holding_hours)
        )
        loss_per_lot = effective_loss_per_lot(
            stop_distance,
            1.0,
            nights=sizing_nights,
            is_news=news_blackout,
            spread_points=spread_points,
            side="sell" if side == "sell" else "buy",
            broker_day=(broker_now or now).weekday(),
            params=costs,
        )
    if loss_per_lot <= 0 or equity <= 0:
        return CapitalPlan(0.0, 0.0, 0.0, intended, 0.0, loss_per_lot, "invalid_stop", dd_f, vol_f, ev_f)

    ceiling_amount = params.risk_ceiling_pct / 100.0 * equity
    hard_amount = hard_remaining / 100.0 * equity

    if force_min_lot:
        min_loss = loss_per_lot * info.min_volume
        if min_loss > ceiling_amount + 1e-9 or min_loss > hard_amount + 1e-9:
            reason = "gate_d_total_risk" if min_loss > hard_amount else "below_min_lot"
            return CapitalPlan(
                0.0, 0.0, 0.0, intended, info.min_volume, loss_per_lot, reason, dd_f, vol_f, ev_f, hard_remaining
            )
        return CapitalPlan(
            volume=info.min_volume,
            risk_pct=min_loss / equity * 100.0,
            risk_amount=min_loss,
            intended_pct=intended,
            raw_volume=info.min_volume,
            loss_per_lot=loss_per_lot,
            dd_factor=dd_f,
            vol_factor=vol_f,
            event_factor=ev_f,
            remaining_budget_pct=hard_remaining,
        )

    raw_volume = (risk_pct / 100.0 * equity) / loss_per_lot
    volume = floor_to_step(raw_volume, info.volume_step)
    if manual_lot > 0:
        volume = floor_to_step(min(manual_lot, raw_volume), info.volume_step)
    if volume > info.max_volume:
        volume = floor_to_step(info.max_volume, info.volume_step)

    while volume >= info.min_volume and loss_per_lot * volume > ceiling_amount + 1e-9:
        volume = floor_to_step(volume - info.volume_step, info.volume_step)

    if volume < info.min_volume:
        return CapitalPlan(
            0.0, 0.0, 0.0, intended, raw_volume, loss_per_lot, "below_min_lot", dd_f, vol_f, ev_f, hard_remaining
        )

    risk_amount = loss_per_lot * volume
    return CapitalPlan(
        volume=volume,
        risk_pct=risk_amount / equity * 100.0,
        risk_amount=risk_amount,
        intended_pct=intended,
        raw_volume=raw_volume,
        loss_per_lot=loss_per_lot,
        dd_factor=dd_f,
        vol_factor=vol_f,
        event_factor=ev_f,
        remaining_budget_pct=hard_remaining,
    )
