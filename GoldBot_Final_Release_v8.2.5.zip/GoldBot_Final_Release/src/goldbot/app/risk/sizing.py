"""Position sizing.

Two rules decide the lot:
* capital rule — 0.01 lot per 100 USD of equity (or a manual lot from the panel);
* risk cap — the loss at the stop may not exceed the profile's % of equity.

The smaller of the two wins. If even the minimum lot would breach the cap, the
trade is rejected instead of being inflated.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

from ...domain.model import SymbolInfo


@dataclass(frozen=True, slots=True)
class SizingResult:
    volume: float
    risk_amount: float
    loss_per_lot: float
    raw_volume: float
    capped_by: str | None = None

    @property
    def tradable(self) -> bool:
        return self.volume > 0 and self.capped_by is None


def floor_to_step(value: float, step: float) -> float:
    if step <= 0:
        return 0.0
    return round(math.floor(value / step + 1e-9) * step, 2)


def compute_volume(
    *,
    equity: float,
    risk_pct: float,
    stop_distance: float,
    info: SymbolInfo,
    price: float,
    max_leverage: float,
    free_margin: float,
) -> SizingResult:
    """Risk-first sizing (kept for reference and unit tests)."""
    risk_amount = equity * risk_pct / 100.0
    if stop_distance <= 0:
        return SizingResult(0.0, risk_amount, 0.0, 0.0, "invalid_stop")

    loss_per_lot = stop_distance * info.contract_size
    if loss_per_lot <= 0:
        return SizingResult(0.0, risk_amount, 0.0, 0.0, "invalid_stop")

    raw = risk_amount / loss_per_lot
    steps = math.floor(raw / info.volume_step + 1e-9)
    volume = round(steps * info.volume_step, 2)

    capped: str | None = None
    if volume < info.min_volume:
        # Never round *up*: that would silently break the risk budget.
        return SizingResult(0.0, risk_amount, loss_per_lot, raw, "below_min_volume")

    if volume > info.max_volume:
        volume = info.max_volume
        capped = "broker_max_volume"

    # Leverage envelope: notional exposure must stay within equity * max_leverage.
    notional = volume * info.contract_size * price
    allowed_notional = equity * max_leverage
    if notional > allowed_notional:
        steps = math.floor((allowed_notional / (info.contract_size * price)) / info.volume_step)
        volume = round(steps * info.volume_step, 2)
        capped = "max_leverage"

    if volume < info.min_volume:
        return SizingResult(0.0, risk_amount, loss_per_lot, raw, capped or "below_min_volume")

    return SizingResult(volume, risk_amount, loss_per_lot, raw, capped)


def compute_capital_volume(
    *,
    equity: float,
    lot_per_100: float,
    risk_cap_pct: float,
    stop_distance: float,
    info: SymbolInfo,
    price: float,
    max_leverage: float,
    free_margin: float,
    manual_lot: float = 0.0,
) -> SizingResult:
    """Legacy sizing helper; not used by the current Tier-based capital pipeline.

    Kept for compatibility with historical callers only. New execution paths must
    use ``app.risk.capital.plan_entry`` so Tier, DD/volatility/event factors, Gate D
    and the full cost model are applied consistently.
    """
    if equity <= 0 or stop_distance <= 0:
        return SizingResult(0.0, 0.0, 0.0, 0.0, "invalid_stop")

    loss_per_lot = stop_distance * info.contract_size
    if loss_per_lot <= 0:
        return SizingResult(0.0, 0.0, 0.0, 0.0, "invalid_stop")

    capital_target = manual_lot if manual_lot > 0 else (equity / 100.0) * lot_per_100
    target = floor_to_step(capital_target, info.volume_step)

    risk_amount_cap = risk_cap_pct / 100.0 * equity
    cap_volume_raw = risk_amount_cap / loss_per_lot
    cap_volume = floor_to_step(cap_volume_raw, info.volume_step)

    if cap_volume < target:
        volume = cap_volume
        capped: str = "risk_cap"
    else:
        volume = target
        capped = "manual_lot" if manual_lot > 0 else "capital_rule"

    if volume < info.min_volume:
        return SizingResult(0.0, risk_amount_cap, loss_per_lot, cap_volume_raw, "risk_cap_below_min_lot")

    if volume > info.max_volume:
        volume = info.max_volume
        capped = "broker_max_volume"

    # Margin/leverage envelope still applies on top of the two rules.
    notional = volume * info.contract_size * price
    allowed_notional = equity * max_leverage
    if notional > allowed_notional:
        volume = floor_to_step(allowed_notional / (info.contract_size * price), info.volume_step)
        capped = "max_leverage"

    if volume <= 0 or volume < info.min_volume:
        return SizingResult(0.0, risk_amount_cap, loss_per_lot, cap_volume_raw, capped or "below_min_volume")

    return SizingResult(
        volume=volume,
        risk_amount=loss_per_lot * volume,
        loss_per_lot=loss_per_lot,
        raw_volume=cap_volume_raw,
        capped_by=capped,
    )
