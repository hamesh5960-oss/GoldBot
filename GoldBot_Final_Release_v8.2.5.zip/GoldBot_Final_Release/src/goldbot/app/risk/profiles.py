"""Risk profiles: three calibrated presets plus bounded manual overrides.

Design rules:
* a profile is a *complete* set of limits — no inherited surprises;
* manual overrides are validated against hard bounds, never silently clamped;
* cross-field consistency is checked at load time (fail closed).
"""

from __future__ import annotations

import tomllib
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

from pydantic import BaseModel, ConfigDict, Field, ValidationError, model_validator

from ...domain.errors import ConfigError

# Locked tier vocabulary (ADR-036). WATCH/NOISE are legacy non-traded tiers and
# are intentionally not valid profile keys: a profile may only allow tiers that
# can actually carry risk. Tier.D exists as the confirmation hard floor, but a
# profile must opt in to trade it and its risk is always zero.
TRADABLE_TIER_KEYS: tuple[str, ...] = ("A+", "A", "B", "C", "D")
VALID_TIER_KEYS: frozenset[str] = frozenset(TRADABLE_TIER_KEYS)
DEFAULT_ALLOWED_TIERS: tuple[str, ...] = TRADABLE_TIER_KEYS
# Per-tier caps are per-trade percentages; 1.5% is the absolute envelope.
MAX_TIER_RISK_CAP_PCT: float = 1.5

# Absolute ceilings: no configuration can exceed these, ever.
ABSOLUTE_MAX = {
    "risk_per_trade_pct": 3.0,
    "max_daily_loss_pct": 10.0,
    "max_total_dd_pct": 25.0,
    "max_positions": 10,
    "max_positions_per_symbol": 5,
    "max_positions_per_slot": 3,
    "max_orders_per_day": 40,
    "max_open_risk_pct": 3.0,
    "max_spread_points": 150.0,
    "max_leverage": 100.0,
    "max_consecutive_losses": 10,
    "news_blackout_minutes": 120,
    "stale_tick_seconds": 300.0,
    "max_sl_points": 20000.0,
    "max_holding_hours": 720.0,
}

FIELD_BOUNDS: dict[str, tuple[float, float]] = {
    "risk_per_trade_pct": (0.01, 3.0),
    "max_daily_loss_pct": (0.1, 10.0),
    "max_total_dd_pct": (1.0, 25.0),
    "max_positions": (1, 10),
    "max_positions_per_symbol": (1, 5),
    "max_positions_per_slot": (1, 3),
    "max_orders_per_day": (1, 40),
    "max_open_risk_pct": (0.5, 3.0),
    "max_spread_points": (5.0, 150.0),
    "min_rr": (0.5, 10.0),
    "max_leverage": (1.0, 100.0),
    "min_sl_points": (5.0, 500.0),
    "max_sl_points": (100.0, 20000.0),
    "stale_tick_seconds": (2.0, 300.0),
    "max_consecutive_losses": (1, 10),
    "news_blackout_minutes": (0, 120),
    "breakeven_after_r": (0.2, 5.0),
    "trail_after_r": (0.2, 10.0),
    "trail_atr_mult": (0.5, 5.0),
    "max_holding_hours": (0.0, 720.0),
    "manual_lot": (0.0, 1.0),
}


class RiskProfile(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    name: str = "custom"
    risk_per_trade_pct: float = Field(gt=0, le=3.0)
    max_daily_loss_pct: float = Field(gt=0, le=10.0)
    max_total_dd_pct: float = Field(gt=0, le=25.0)
    max_positions: int = Field(ge=1, le=10)
    max_positions_per_symbol: int = Field(ge=1, le=5)
    max_positions_per_slot: int = Field(ge=1, le=3)
    max_orders_per_day: int = Field(ge=1, le=40)
    # Aggregate open risk allowed at once. Gate D hard is min(this, capital config).
    # Current ADR-036/037 values: Low 1.5%, Medium/High 3.0%.
    max_open_risk_pct: float = Field(default=2.0, ge=0.5, le=3.0)
    # Tier matrix (ADR-036): which tiers this profile may trade at all, and the
    # per-tier cap that clamps the tier base risk. A tier missing from the caps
    # falls back to risk_per_trade_pct (the profile envelope).
    allowed_tiers: tuple[str, ...] = DEFAULT_ALLOWED_TIERS
    tier_risk_caps: dict[str, float] = Field(default_factory=dict)
    max_spread_points: float = Field(gt=0)
    min_rr: float = Field(ge=0.5)
    max_leverage: float = Field(ge=1.0, le=100.0)
    min_sl_points: float = Field(ge=5.0)
    max_sl_points: float = Field(le=20000.0)
    stale_tick_seconds: float = Field(gt=0)
    max_consecutive_losses: int = Field(ge=1)
    news_blackout_minutes: int = Field(ge=0)
    breakeven_after_r: float = Field(ge=0.2)
    trail_after_r: float = Field(ge=0.2)
    trail_atr_mult: float = Field(ge=0.5)
    max_holding_hours: float = Field(ge=0.0)
    # Manual lot size from the panel; 0 means "let the capital rule decide".
    manual_lot: float = Field(default=0.0, ge=0.0, le=1.0)
    flatten_on_kill: bool = False
    session_filter: bool = True
    news_filter: bool = True
    daily_reset_utc_hour: int = Field(default=0, ge=0, le=23)

    @model_validator(mode="after")
    def _validate_tier_matrix(self) -> "RiskProfile":
        """Fail closed on an unknown tier, a duplicate, or an out-of-range cap."""
        if len(set(self.allowed_tiers)) != len(self.allowed_tiers):
            raise ValueError("allowed_tiers contains duplicate entries")
        unknown_allowed = sorted(set(self.allowed_tiers) - VALID_TIER_KEYS)
        if unknown_allowed:
            raise ValueError(
                f"allowed_tiers contains unknown tier(s) {unknown_allowed}; "
                f"expected a subset of {sorted(VALID_TIER_KEYS)}"
            )
        for tier_key, cap in self.tier_risk_caps.items():
            if tier_key not in VALID_TIER_KEYS:
                raise ValueError(
                    f"tier_risk_caps key {tier_key!r} is not a tradable tier; "
                    f"expected a subset of {sorted(VALID_TIER_KEYS)}"
                )
            if cap < 0.0:
                raise ValueError(
                    f"tier_risk_caps[{tier_key!r}]={cap} must be >= 0"
                )
            if cap > MAX_TIER_RISK_CAP_PCT:
                raise ValueError(
                    f"tier_risk_caps[{tier_key!r}]={cap} exceeds the "
                    f"{MAX_TIER_RISK_CAP_PCT}% absolute envelope"
                )
        return self


@dataclass(frozen=True, slots=True)
class AppliedOverride:
    field: str
    profile_value: Any
    value: Any


def load_profiles(path: str | Path) -> dict[str, RiskProfile]:
    raw = tomllib.loads(Path(path).read_text(encoding="utf-8"))
    profiles: dict[str, RiskProfile] = {}
    for name, data in raw.get("profiles", {}).items():
        try:
            profiles[name] = RiskProfile(name=name, **data)
        except ValidationError as exc:  # noqa: PERF203
            raise ConfigError(f"invalid risk profile '{name}': {exc}") from exc
        validate_consistency(profiles[name])
    if not profiles:
        raise ConfigError(f"no profiles found in {path}")
    return profiles


def validate_consistency(profile: RiskProfile) -> None:
    """Reject profiles that are internally contradictory, at load time."""
    worst_case = profile.risk_per_trade_pct * profile.max_positions
    if worst_case > profile.max_daily_loss_pct + 1e-9:
        raise ConfigError(
            f"profile '{profile.name}': {profile.max_positions} positions x "
            f"{profile.risk_per_trade_pct}% risk exceeds daily loss limit "
            f"{profile.max_daily_loss_pct}%"
        )
    if profile.max_total_dd_pct < profile.max_daily_loss_pct:
        raise ConfigError(
            f"profile '{profile.name}': total drawdown limit must be >= daily loss limit"
        )
    if profile.max_open_risk_pct > profile.max_total_dd_pct + 1e-9:
        raise ConfigError(
            f"profile '{profile.name}': open-risk cap exceeds the total drawdown limit"
        )
    if profile.min_sl_points * 2 > profile.max_sl_points:
        raise ConfigError(f"profile '{profile.name}': min_sl_points is inconsistent with max_sl_points")
    if profile.trail_after_r < profile.breakeven_after_r:
        raise ConfigError(
            f"profile '{profile.name}': trailing must not start before breakeven"
        )


def resolve_profile(
    name: str, profiles: Mapping[str, RiskProfile], overrides: Mapping[str, Any] | None = None
) -> tuple[RiskProfile, list[AppliedOverride]]:
    if name not in profiles:
        raise ConfigError(f"unknown risk profile '{name}'; available: {sorted(profiles)}")
    base = profiles[name]
    if not overrides:
        return base, []

    applied: list[AppliedOverride] = []
    updates: dict[str, Any] = {}
    fields = set(RiskProfile.model_fields)
    for key, value in overrides.items():
        if key not in fields:
            raise ConfigError(f"manual override for unknown field '{key}'")
        low, high = FIELD_BOUNDS.get(key, (None, None))
        if low is not None and high is not None:
            if not (low <= float(value) <= high):
                raise ConfigError(
                    f"manual override {key}={value} outside hard bounds [{low}, {high}]"
                )
        ceiling = ABSOLUTE_MAX.get(key)
        if ceiling is not None and float(value) > ceiling:
            raise ConfigError(f"manual override {key}={value} exceeds absolute ceiling {ceiling}")
        updates[key] = value
        applied.append(AppliedOverride(key, getattr(base, key), value))

    try:
        merged = base.model_copy(update=updates)
        merged = RiskProfile(name=f"{name}+manual", **merged.model_dump(exclude={"name"}))
    except ValidationError as exc:
        raise ConfigError(f"manual override produced an invalid profile: {exc}") from exc
    validate_consistency(merged)
    return merged, applied
