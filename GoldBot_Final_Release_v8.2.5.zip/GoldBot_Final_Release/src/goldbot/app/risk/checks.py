"""Pure risk checks. Each returns a CheckResult and never mutates state."""

from __future__ import annotations

from datetime import datetime

from ...domain.model import SymbolInfo
from ...ports.risk import CheckResult, RiskContext


def check_state(state: str) -> CheckResult:
    ok = state == "NORMAL"
    return CheckResult("risk_state", ok, f"state={state}")


def check_session(ctx: RiskContext, enabled: bool) -> CheckResult:
    if not enabled:
        return CheckResult("session", True, "session filter disabled")
    return CheckResult("session", ctx.session_open, "market closed" if not ctx.session_open else "open")


def check_stale(ctx: RiskContext, max_age: float) -> CheckResult:
    age = (ctx.now - ctx.tick.ts_event.wall).total_seconds()
    return CheckResult(
        "stale_tick", age <= max_age, f"tick age {age:.0f}s", value=age, threshold=max_age
    )


def check_spread(ctx: RiskContext, info: SymbolInfo, max_points: float) -> CheckResult:
    points = ctx.tick.spread / info.point if info.point else 0.0
    return CheckResult(
        "spread", points <= max_points, f"spread {points:.0f} points", value=points, threshold=max_points
    )


def check_news(ctx: RiskContext, enabled: bool) -> CheckResult:
    if not enabled:
        return CheckResult("news_window", True, "news filter disabled")
    return CheckResult("news_window", not ctx.news_blackout, "inside news blackout")


def check_positions(ctx: RiskContext, max_total: int, max_per_symbol: int) -> CheckResult:
    total = ctx.open_positions
    per_symbol = sum(1 for p in ctx.positions if p.symbol == ctx.tick.symbol)
    ok = total < max_total and per_symbol < max_per_symbol
    return CheckResult(
        "max_positions",
        ok,
        f"open={total}/{max_total} symbol={per_symbol}/{max_per_symbol}",
        value=float(total),
        threshold=float(max_total),
    )


def check_daily_loss(daily_pnl: float, equity: float, limit_pct: float) -> CheckResult:
    if equity <= 0:
        return CheckResult("daily_loss", False, "non-positive equity")
    loss_pct = -daily_pnl / equity * 100.0 if daily_pnl < 0 else 0.0
    return CheckResult(
        "daily_loss",
        loss_pct < limit_pct,
        f"daily loss {loss_pct:.2f}% of {limit_pct:.2f}%",
        value=loss_pct,
        threshold=limit_pct,
    )


def check_total_dd(dd_pct: float, limit_pct: float) -> CheckResult:
    return CheckResult(
        "total_drawdown", dd_pct < limit_pct, f"drawdown {dd_pct:.2f}%", value=dd_pct, threshold=limit_pct
    )


def check_consecutive(losses: int, limit: int) -> CheckResult:
    return CheckResult(
        "consecutive_losses", losses < limit, f"{losses} consecutive losses", value=float(losses), threshold=float(limit)
    )


def check_orders_per_day(count: int, limit: int) -> CheckResult:
    return CheckResult(
        "orders_per_day", count < limit, f"{count}/{limit} orders today", value=float(count), threshold=float(limit)
    )


def check_rr(entry: float, stop: float, target: float | None, min_rr: float) -> CheckResult:
    if target is None:
        return CheckResult("risk_reward", True, "no target set", value=None, threshold=min_rr)
    risk = abs(entry - stop)
    reward = abs(target - entry)
    rr = reward / risk if risk > 0 else 0.0
    return CheckResult(
        "risk_reward",
        rr >= min_rr - 1e-9,  # tolerate float noise on exact 1:1 systems
        f"R:R {rr:.2f} (min {min_rr})",
        value=rr,
        threshold=min_rr,
    )


def check_stop_distance(
    stop_distance: float, info: SymbolInfo, min_points: float, max_points: float
) -> CheckResult:
    points = stop_distance / info.point if info.point else 0.0
    ok = min_points <= points <= max_points
    return CheckResult(
        "stop_distance",
        ok,
        f"stop {points:.0f} points (allowed {min_points:.0f}-{max_points:.0f})",
        value=points,
        threshold=min_points,
    )


def check_margin(notional: float, free_margin: float, leverage: int) -> CheckResult:
    required = notional / max(1, leverage)
    ok = required <= free_margin * 0.8  # keep a 20% buffer at all times
    return CheckResult(
        "margin",
        ok,
        f"margin {required:.2f} vs free {free_margin:.2f}",
        value=required,
        threshold=free_margin * 0.8,
    )


def check_leverage(notional: float, equity: float, max_leverage: float) -> CheckResult:
    used = notional / equity if equity > 0 else float("inf")
    return CheckResult(
        "leverage", used <= max_leverage, f"leverage {used:.2f}x", value=used, threshold=max_leverage
    )


def check_broker_stops(
    stop_distance: float, target_distance: float | None, info: SymbolInfo
) -> CheckResult:
    """The venue's own minimum distance, independent of the profile limits."""
    required = float(info.stops_level_points) * info.point
    ok = stop_distance + 1e-9 >= required
    if target_distance is not None:
        ok = ok and target_distance + 1e-9 >= required
    return CheckResult(
        "broker_stops",
        ok,
        f"stop {stop_distance:.5f} target {target_distance} min {required:.5f}",
        value=stop_distance,
        threshold=required,
    )


def check_reconciliation(ctx: RiskContext) -> CheckResult:
    return CheckResult(
        "reconciliation",
        ctx.reconciled,
        "reconciliation stale" if not ctx.reconciled else "reconciled",
    )


def check_manual_pause(
    pause_until: datetime | None, now: datetime, reason: str = ""
) -> CheckResult:
    """An operator pause blocks new entries; it never touches open positions."""
    if pause_until is None:
        return CheckResult("manual_pause", True, "not paused")
    remaining = (pause_until - now).total_seconds() / 60.0
    if remaining <= 0:
        return CheckResult("manual_pause", True, "pause expired")
    return CheckResult(
        "manual_pause",
        False,
        f"operator pause {remaining:.0f}m remaining" + (f": {reason}" if reason else ""),
        value=remaining,
        threshold=0.0,
    )

