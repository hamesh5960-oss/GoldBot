"""Reconciliation: compare derived state with the venue and report divergence.

Restart safety (ADR-013 P0): broker positions with no local book entry are
orphans. They are adopted into PositionManager (broker truth wins, protective
time-stop only) instead of leaving real exposure unmanaged; if the venue cannot
be read, or an orphan cannot be adopted, the report stays unclean so the engine
quarantines and blocks new entries.
"""

from __future__ import annotations

from typing import Any, Sequence

from ..domain.events import Ev, Event
from ..log import get_logger
from ..ports.execution import ReconcileReport

log = get_logger("reconciler")

# Stable event names (domain/events.py has no catalogue entries yet).
POSITION_ADOPTED_EVENT = "PositionAdopted"
POSITION_ADOPTION_FAILED_EVENT = "PositionAdoptionFailed"


class Reconciler:
    def __init__(self, *, positions: Any, broker: Any, journal: Any, clock: Any) -> None:
        self._positions = positions
        self._broker = broker
        self._journal = journal
        self._clock = clock
        self.last_report: ReconcileReport | None = None
        self._last_truth: tuple[Any, ...] | None = None
        self._last_read_error: str | None = None

    def _emit(self, event_type: str, payload: dict[str, Any]) -> None:
        if self._journal is None:
            return
        self._journal.append(Event(type=event_type, payload=payload, ts=self._clock.now(), actor="reconciler"))

    def run(self) -> ReconcileReport:
        self._emit(Ev.RECONCILE_STARTED, {})
        try:
            truth = tuple(self._broker.positions())
        except Exception as exc:  # noqa: BLE001 - unknown venue truth must fail closed
            self._last_truth = None
            self._last_read_error = str(exc)
            report = ReconcileReport(
                clean=False,
                details=(f"broker positions unreadable: {exc}",),
            )
            self.last_report = report
            self._emit(
                Ev.DIVERGENCE,
                {"details": [f"broker positions unreadable: {exc}"]},
            )
            log.error("broker positions unreadable", extra={"fields": {"error": str(exc)}})
            return report
        self._last_truth = truth
        self._last_read_error = None
        report = self._positions.reconcile(truth)
        self.last_report = report

        if not report.clean:
            self._emit(
                Ev.DIVERGENCE,
                {
                    "missing": list(report.missing),
                    "orphan": list(report.orphan),
                    "volume_drift": list(report.volume_drift),
                    "protection_lost": list(report.protection_lost),
                    "details": list(report.details),
                },
            )
            log.error("reconciliation divergence", extra={"fields": {"details": list(report.details)}})
        else:
            self._emit(Ev.RECONCILE_COMPLETED, {"positions": len(truth)})
        return report

    # -- restart adoption -------------------------------------------------
    def has_unmanaged_exposure(self) -> bool:
        """True when a venue position would still be missing from the book.

        Uses the last successful snapshot. An unreadable snapshot is reported by
        run() as unclean; this helper then answers False because there is no
        truth to adopt or verify (the quarantine comes from the report).
        """
        truth = self._last_truth
        if not truth:
            return False
        if getattr(self._positions, "mode", "hedging") != "hedging":
            # Netting aggregates per symbol; per-ticket adoption is not defined.
            return True
        known = {int(position.ticket) for position in self._positions.raw()}
        return any(int(getattr(snapshot, "ticket")) not in known for snapshot in truth)

    def adopt_orphans(
        self,
        *,
        max_holding_hours: float = 0.0,
        adopt_foreign_magic: bool = True,
    ) -> tuple[Any, ...]:
        """Adopt every unmanaged venue position once and journal each adoption.

        Adoption is idempotent by ticket (PositionManager skips known tickets),
        so repeated reconcile/adopt cycles never duplicate a book entry or an
        order. If anything remains unmanaged the caller must keep entries
        blocked: has_unmanaged_exposure() will still be True.
        """
        truth = self._last_truth
        if truth is None:
            return ()
        try:
            adopted = self._positions.adopt_positions(
                truth,
                max_holding_hours=max_holding_hours,
                clock=self._clock,
                adopt_foreign_magic=adopt_foreign_magic,
            )
        except Exception as exc:  # noqa: BLE001 - adoption failure must fail closed
            self._emit(POSITION_ADOPTION_FAILED_EVENT, {"error": str(exc)})
            log.error("position adoption failed", extra={"fields": {"error": str(exc)}})
            return ()

        for position in adopted:
            signal = dict(getattr(position, "signal", {}) or {})
            payload = {
                "ticket": int(position.ticket),
                "symbol": str(position.symbol),
                "side": str(position.side),
                "volume": float(position.volume),
                "open_price": float(position.open_price),
                "sl": None if position.sl is None else float(position.sl),
                "tp": None if position.tp is None else float(position.tp),
                "magic": int(signal.get("magic", 0) or 0),
                "magic_owned": bool(signal.get("magic_owned", False)),
                "comment": str(signal.get("comment", "")),
                "slot": str(position.slot),
                "strategy": str(position.strategy),
                "open_time": position.open_time.isoformat(),
                "max_holding_hours": float(max_holding_hours),
                "adopted_at": self._clock.now().wall.isoformat(),
            }
            self._emit(POSITION_ADOPTED_EVENT, payload)
            log.warning(
                "position adopted from broker",
                extra={"fields": {"ticket": payload["ticket"], "slot": payload["slot"]}},
            )

        if not adopted and truth and self.has_unmanaged_exposure():
            self._emit(
                POSITION_ADOPTION_FAILED_EVENT,
                {
                    "reason": "unmanaged_exposure_remains",
                    "positions": len(truth),
                    "mode": getattr(self._positions, "mode", "hedging"),
                },
            )
        return tuple(adopted)
