"""Capital-level controller used by the engine.

Composition layer between the pure controller (app.capital_levels) and the
trading loop: owns the persisted LevelState, decides when a level change must
be journaled, and turns the level policy into entry gates.

Everything here only TIGHTENS the static profile limits, except BASE which is
never executable without explicit arming + onboarding (ADR-030).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, datetime
from typing import Any, Mapping

from .capital_levels import (
    CapitalLevel,
    LevelConfig,
    LevelDecision,
    LevelPolicy,
    LevelState,
    active_level_for_execution,
    approve_upgrade,
    band_risk_pct,
    decline_upgrade,
    determine_level,
    policy_for,
    start_level,
)

PROFILE_LEVEL: dict[str, CapitalLevel] = {
    "low": CapitalLevel.LOW_RISK,
    "medium": CapitalLevel.MEDIUM_RISK,
    "high": CapitalLevel.HIGH_RISK,
}

AUX_KEY = "level_state"
ONBOARDING_KEY = "onboarding_ack"


@dataclass
class LevelGate:
    """Stateful gate around one account/profile."""

    config: LevelConfig
    enabled: bool = False
    base_armed: bool = False
    onboarding_ack: bool = False
    state: LevelState = field(default_factory=LevelState)
    decision: LevelDecision | None = None
    last_reason: str = ""
    _last_day: date | None = None
    _persisted: dict[str, Any] | None = None

    # -- persistence ---------------------------------------------------
    def restore(self, payload: Mapping[str, Any] | None) -> bool:
        if not payload:
            return False
        try:
            self.state = LevelState.from_dict(payload)
        except (TypeError, ValueError):
            return False
        self._persisted = self.state.to_dict()
        return True

    def snapshot(self) -> dict[str, Any]:
        return self.state.to_dict()

    def bootstrap(self, equity: float, profile_name: str) -> None:
        """Fresh state: map the static profile to a level when disabled."""
        if self._persisted is None:
            self.state = start_level(equity, self.config)
            if not self.enabled:
                # Analytics-only mapping: the static profile implies a level for
                # reporting, but it must never override the controller when enabled.
                profile_level = PROFILE_LEVEL.get(profile_name)
                if profile_level is not None:
                    self.state.active_level = profile_level
            _, band = band_risk_pct(equity, None)
            self.state.previous_band = band
            self._persisted = self.state.to_dict()

    # -- state machine -------------------------------------------------
    def step(
        self,
        *,
        equity: float,
        drawdown_pct: float,
        consecutive_losses: int,
        open_positions: int,
        now: datetime,
        trades_today: int = 0,
    ) -> LevelDecision | None:
        """Advance the level FSM once per bar when the controller is enabled."""
        if not self.enabled:
            return None
        day = now.date()
        if self._last_day != day:
            self._last_day = day
            threshold = self._next_threshold()
            if threshold is not None and equity >= threshold:
                self.state.days_above_threshold += 1
            elif threshold is not None:
                self.state.days_above_threshold = 0
        if trades_today > 0:
            self.state.trades_in_level = max(self.state.trades_in_level, int(trades_today))
        self.decision = determine_level(
            equity,
            drawdown_pct,
            consecutive_losses,
            open_positions,
            now,
            self.state,
            self.config,
        )
        self.last_reason = self.decision.reason
        return self.decision

    def _next_threshold(self) -> float | None:
        mapping = {
            CapitalLevel.BASE: self.config.low_risk_threshold,
            CapitalLevel.LOW_RISK: self.config.medium_risk_threshold,
            CapitalLevel.MEDIUM_RISK: self.config.high_risk_threshold,
        }
        return mapping.get(self.state.active_level)

    def dirty(self) -> dict[str, Any] | None:
        """Payload to persist when the state moved since the last write."""
        payload = self.state.to_dict()
        if payload == self._persisted:
            return None
        self._persisted = payload
        return payload

    # -- gates ---------------------------------------------------------
    def active(self, equity: float) -> CapitalLevel | None:
        """Executable level, or None when BASE is locked (or controller off)."""
        if not self.enabled:
            return None
        return active_level_for_execution(
            self.state.active_level,
            self.config.base_enabled,
            self.base_armed,
            self.onboarding_ack,
            equity,
        )

    def policy(self) -> LevelPolicy | None:
        if not self.enabled:
            return None
        return policy_for(self.state.active_level)

    def tier_allowed(self, tier_value: str) -> bool:
        policy = self.policy()
        if policy is None:
            return True
        return tier_value in policy.allowed_tiers

    def amplifier_allowed(self) -> bool:
        policy = self.policy()
        return True if policy is None else bool(policy.amplifier_enabled)

    def max_trades_per_day(self) -> int | None:
        policy = self.policy()
        return None if policy is None else int(policy.max_trades_per_day)

    def session_allowed(self, session_name: str) -> bool:
        policy = self.policy()
        if policy is None:
            return True
        if session_name == "closed":
            return False
        return session_name in policy.sessions

    def stop_reason(self, equity: float) -> str:
        if not self.enabled:
            return ""
        if self.active(equity) is not None:
            return ""
        if self.state.active_level is CapitalLevel.BASE:
            return "base_locked"
        return "level_blocked"

    # -- operator actions ----------------------------------------------
    def approve(self, now: datetime) -> bool:
        if self.state.pending_level is None:
            return False
        approve_upgrade(self.state, now)
        self._persisted = None
        return True

    def decline(self, now: datetime) -> bool:
        if self.state.pending_level is None:
            return False
        decline_upgrade(self.state, now, self.config)
        self._persisted = None
        return True

    def set_onboarding_ack(self, acknowledged: bool) -> None:
        self.onboarding_ack = bool(acknowledged)


def from_settings(settings: Any, *, base_armed: bool = False) -> LevelGate:
    """Build a gate from [levels] config (never enables anything implicitly)."""
    cfg = settings.levels
    config = LevelConfig(
        low_risk_threshold=float(cfg.low_risk_threshold),
        medium_risk_threshold=float(cfg.medium_risk_threshold),
        high_risk_threshold=float(cfg.high_risk_threshold),
        approval_timeout_days=int(cfg.approval_timeout_days),
        decline_cooldown_days=int(cfg.decline_cooldown_days),
        min_days_above_threshold=int(cfg.min_days_above_threshold),
        min_trades_in_level=int(cfg.min_trades_in_level),
        base_enabled=bool(cfg.base_enabled),
    )
    return LevelGate(config=config, enabled=bool(cfg.enabled), base_armed=bool(base_armed))

