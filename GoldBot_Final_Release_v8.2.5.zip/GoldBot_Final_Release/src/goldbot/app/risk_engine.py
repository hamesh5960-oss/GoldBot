"""Risk engine: the only component allowed to create a sealed order.

Everything is checked on every entry; the decision is journalled with the numbers
that produced it. State is a latch: only a human (or the next trading day, for
soft halts) can clear a hard halt.
"""

from __future__ import annotations

import os
import secrets
from datetime import date, datetime
from typing import Any, Sequence

from ..domain.errors import InvariantError
from ..domain.events import Ev, Event
from ..domain.execution import ApprovedOrder, EntryIntent, ManagementAction, RiskSnapshot
from ..domain.model import Ts
from ..log import get_logger
from ..ports.risk import CheckResult, RiskContext, RiskDecision, RiskState, Verdict
from ..ports.state import IRiskStateStore, PersistedRiskState, StateCorruption
from .costs import CostParams, estimated_round_trip
from .decision import Tier
from .ids import MAGIC_SCHEME, client_ref, magic_for_slot
from .order_budget import BudgetParams, evaluate_budget
from .risk.capital import CapitalParams, expected_nights_for, plan_entry
from .risk import (
    ABSOLUTE_MAX,
    RiskProfile,
    check_broker_stops,
    check_consecutive,
    check_daily_loss,
    check_leverage,
    check_margin,
    check_manual_pause,
    check_news,
    check_orders_per_day,
    check_positions,
    check_reconciliation,
    check_rr,
    check_session,
    check_spread,
    check_stale,
    check_state,
    check_stop_distance,
    check_total_dd,
)

log = get_logger("risk")


def _parse_dt(value: str | None) -> datetime | None:
    if not value:
        return None
    return datetime.fromisoformat(value)


def _tier_from(value: object) -> Tier | None:
    if not isinstance(value, str):
        return None
    for tier in Tier:
        if tier.value == value:
            return tier
    return None

_SEVERITY = {
    RiskState.NORMAL: 0,
    RiskState.SOFT_HALT: 1,
    RiskState.HALTED: 2,
    RiskState.KILLED: 3,
    RiskState.QUARANTINE: 4,
}


class RiskEngine:
    def __init__(
        self,
        profile: RiskProfile,
        *,
        journal: Any,
        clock: Any,
        notifier: Any = None,
        secret: str | None = None,
        magic_base: int = 7300,
        capital: CapitalParams | None = None,
        commission_per_lot: float = 7.0,
        budget: BudgetParams | None = None,
        costs: CostParams | None = None,
        config_hash: str = "",
        state_store: IRiskStateStore | None = None,
        allow_cold_start: bool = False,
    ) -> None:
        self.profile = profile
        self._capital = capital or CapitalParams()
        self._budget = budget or BudgetParams()
        # Optional full cost model; without it sizing falls back to the
        # commission-only estimate (kept for unit tests and older callers).
        self._costs = costs
        self._config_hash = config_hash
        self._commission = float(commission_per_lot)
        self._journal = journal
        self._clock = clock
        self._notifier = notifier
        env_secret = os.environ.get("GOLDBOT_HMAC_SECRET", "").strip()
        require_secret = os.environ.get("GOLDBOT_REQUIRE_SECRET", "") == "1"
        if secret:
            self._secret = secret
        elif env_secret:
            self._secret = env_secret
        elif require_secret:
            raise InvariantError(
                "GOLDBOT_REQUIRE_SECRET=1 but GOLDBOT_HMAC_SECRET is missing; refusing to start"
            )
        else:
            self._secret = secrets.token_hex(16)
        self._secret_source = "argument" if secret else ("env" if env_secret else "ephemeral")
        self._magic_base = magic_base

        self._state = RiskState.NORMAL
        self._reason = ""
        self._auto_clear = False
        self._day: Any = None
        self._day_start_equity: float | None = None
        self._peak_equity = 0.0
        self._initial_equity: float | None = None
        self._daily_pnl = 0.0
        self._drawdown_pct = 0.0
        self._consecutive_losses = 0
        self._orders_today = 0
        self._last_order_at: datetime | None = None
        self._last_loss_at: datetime | None = None
        self._ticket_meta: dict[int, dict[str, Any]] = {}
        # Tickets already reported as untracked in the journal (warn once each).
        self._untracked_warned: set[int] = set()
        self._extras: dict[str, Any] = {}
        self._last_snapshot = RiskSnapshot(0, 0, 0, 0, 0, 0, 0, profile=profile.name)

        self._state_store = state_store
        self._restore_error: str | None = None
        self._restored_at: str | None = None
        self._restored = False
        self._persisted_mark: tuple[float, float] | None = None
        if state_store is not None:
            self._restore(allow_cold_start=allow_cold_start)

    # ------------------------------------------------------------------
    # state
    # ------------------------------------------------------------------
    def state(self) -> RiskState:
        return self._state

    def secret(self) -> str:
        return self._secret

    @property
    def profile_name(self) -> str:
        return self.profile.name

    def _emit(self, event_type: str, payload: dict[str, Any], *, actor: str = "risk") -> None:
        if self._journal is None:
            return
        self._journal.append(Event(type=event_type, payload=payload, ts=self._clock.now(), actor=actor))

    def engage(self, level: RiskState, reason: str, *, actor: str, auto_clear: bool = False) -> None:
        if _SEVERITY[level] <= _SEVERITY[self._state] and self._state is not RiskState.QUARANTINE:
            return
        previous = self._state
        self._state = level
        self._reason = reason
        self._auto_clear = auto_clear
        self._emit(
            Ev.RISK_STATE_CHANGED,
            {"from": previous.value, "to": level.value, "reason": reason, "actor": actor},
        )
        # A soft/ daily halt is not an exchange-style kill switch: journal it
        # distinctly so operators can tell "stopped for today" from "flatten now".
        if level in (RiskState.HALTED, RiskState.KILLED, RiskState.QUARANTINE):
            self._emit(Ev.KILL_ENGAGED, {"level": level.value, "reason": reason, "actor": actor})
            log.error("risk state engaged", extra={"fields": {"to": level.value, "reason": reason}})
        else:
            log.warning("risk state engaged", extra={"fields": {"to": level.value, "reason": reason}})
        if self._notifier is not None:
            self._notifier.send(
                "critical" if level in (RiskState.HALTED, RiskState.KILLED) else "warn",
                f"Risk {level.value}",
                reason,
                dedup_key=f"risk-{level.value}-{reason}",
            )
        self._write_state()

    def acknowledge(self, *, level: RiskState, actor: str, note: str) -> None:
        if _SEVERITY[self._state] > _SEVERITY[level]:
            raise InvariantError(f"cannot acknowledge {level.value} while in {self._state.value}")
        previous = self._state
        self._state = RiskState.NORMAL
        self._reason = ""
        self._auto_clear = False
        self._emit(
            Ev.MANUAL_OVERRIDE,
            {"action": "acknowledge", "from": previous.value, "actor": actor, "note": note},
            actor="operator",
        )
        self._write_state()

    # ------------------------------------------------------------------
    # day / marks
    # ------------------------------------------------------------------
    def begin(self, equity: float, at: datetime) -> None:
        broker_now = getattr(self._clock, "broker_now", None)
        moment = broker_now() if broker_now is not None else at
        day = moment.date()
        if self._day is None:
            self._day = day
            self._day_start_equity = equity
            self._peak_equity = max(self._peak_equity, equity)
            if self._initial_equity is None:
                self._initial_equity = equity
            self._orders_today = 0
        elif day != self._day:
            # A process that restarts on a later broker day rolls over exactly
            # like a live one (soft/daily brakes clear, hard latches do not).
            self._peak_equity = max(self._peak_equity, equity)
            self._rollover(equity, moment)
            return
        else:
            # Same broker day: keep the persisted day start and the order
            # counter. Re-initialising them would silently reset Gate B and
            # the daily loss guard after a restart.
            if self._day_start_equity is None:
                self._day_start_equity = equity
            self._peak_equity = max(self._peak_equity, equity)
            if self._initial_equity is None:
                self._initial_equity = equity
        self._write_state()

    def _rollover(self, equity: float, at: datetime) -> None:
        self._day = at.date()
        self._day_start_equity = equity
        self._orders_today = 0
        self._last_order_at = None
        self._consecutive_losses = 0
        # Daily-loss and consecutive-loss halts are *daily* brakes: they clear
        # at the next trading day. KILLED (total drawdown) and QUARANTINE are
        # latched and require a human.
        if self._auto_clear and self._state in (RiskState.SOFT_HALT, RiskState.HALTED):
            previous = self._state
            self._state = RiskState.NORMAL
            self._reason = ""
            self._auto_clear = False
            self._emit(
                Ev.RISK_STATE_CHANGED,
                {"from": previous.value, "to": "NORMAL", "reason": "new trading day"},
            )
        self._write_state()

    def on_mark(self, ctx: RiskContext) -> None:
        equity = ctx.equity
        at = ctx.now
        day_at = ctx.broker_now or at
        if self._day is None:
            self.begin(equity, day_at)
        elif day_at.date() != self._day:
            self._rollover(equity, day_at)

        if self._day_start_equity is None:
            self._day_start_equity = equity
        self._daily_pnl = equity - self._day_start_equity
        self._peak_equity = max(self._peak_equity, equity)
        if self._peak_equity > 0:
            self._drawdown_pct = (self._peak_equity - equity) / self._peak_equity * 100.0
        # A crash must not rewind the peak (that would erase drawdown) or the
        # day's PnL, so checkpoint them when they materially move.
        self._persist_if_material(equity)

        self._last_snapshot = RiskSnapshot(
            equity=equity,
            balance=ctx.balance,
            risk_pct=self.profile.risk_per_trade_pct,
            risk_amount=0.0,
            stop_distance=0.0,
            volume=0.0,
            spread_points=ctx.tick.spread / ctx.symbol_info.point if ctx.symbol_info.point else 0.0,
            daily_pnl=self._daily_pnl,
            open_positions=ctx.open_positions,
            profile=self.profile.name,
        )

        if self._state is RiskState.QUARANTINE:
            return
        # Second, absolute floor: no recovery logic can justify losing half the
        # starting equity. This is independent of the rolling-peak drawdown.
        if self._initial_equity and equity < 0.5 * self._initial_equity:
            self.engage(
                RiskState.KILLED,
                f"catastrophic equity floor {equity:.2f} < 50% of {self._initial_equity:.2f}",
                actor="system",
                auto_clear=False,
            )
            return
        if self._drawdown_pct >= self.profile.max_total_dd_pct:
            self.engage(
                RiskState.KILLED,
                f"total drawdown {self._drawdown_pct:.2f}% >= {self.profile.max_total_dd_pct}%",
                actor="system",
                auto_clear=True,
            )
            return
        loss_pct = -self._daily_pnl / equity * 100.0 if (self._daily_pnl < 0 and equity > 0) else 0.0
        if loss_pct >= self.profile.max_daily_loss_pct:
            self._emit(
                Ev.DAILY_LOSS_BREACH,
                {"limit_pct": self.profile.max_daily_loss_pct, "loss_pct": loss_pct, "equity": equity},
            )
            self.engage(RiskState.HALTED, f"daily loss {loss_pct:.2f}%", actor="system", auto_clear=True)

    def on_trade_closed(self, pnl: float, at: datetime) -> None:
        if pnl < 0:
            self._last_loss_at = at
            self._consecutive_losses += 1
        else:
            self._consecutive_losses = 0
        if self._consecutive_losses >= self.profile.max_consecutive_losses:
            self.engage(
                RiskState.SOFT_HALT,
                f"{self._consecutive_losses} consecutive losses",
                actor="system",
                auto_clear=True,
            )
        self._write_state()

    # ------------------------------------------------------------------
    # entry evaluation
    # ------------------------------------------------------------------
    def evaluate_entry(self, intent: EntryIntent, ctx: RiskContext) -> RiskDecision:
        checks: list[CheckResult] = []
        p = self.profile
        info = ctx.symbol_info
        equity = ctx.equity

        checks.append(check_state(self._state.value))
        checks.append(
            check_manual_pause(self.manual_pause_until(), ctx.now, self.manual_pause_reason())
        )
        checks.append(check_session(ctx, p.session_filter))
        checks.append(check_stale(ctx, p.stale_tick_seconds))
        checks.append(check_spread(ctx, info, p.max_spread_points))
        checks.append(check_news(ctx, p.news_filter))
        checks.append(check_positions(ctx, p.max_positions, p.max_positions_per_symbol))
        checks.append(check_daily_loss(self._daily_pnl, equity, p.max_daily_loss_pct))
        checks.append(check_total_dd(self._drawdown_pct, p.max_total_dd_pct))
        checks.append(check_consecutive(self._consecutive_losses, p.max_consecutive_losses))
        checks.append(check_orders_per_day(self._orders_today, p.max_orders_per_day))
        tags = intent.signal.get("tags", {}) if isinstance(intent.signal, dict) else {}
        tier = _tier_from(tags.get("tier"))
        # The budget may never advertise more orders than the profile allows.
        budget_params = self._budget.for_profile(p.max_orders_per_day)
        budget = evaluate_budget(
            tier=tier.value if tier is not None else None,
            orders_today=self._orders_today,
            now=ctx.now,
            last_order_at=self._last_order_at,
            last_loss_at=self._last_loss_at,
            params=budget_params,
        )
        checks.append(
            CheckResult(
                "order_budget",
                not budget.rejected,
                f"{budget.outcome}: {budget.reason}",
                value=float(self._orders_today),
                threshold=float(budget_params.soft_limit),
            )
        )
        effective_min_rr = max(p.min_rr, float(tags.get("min_rr") or 0.0))
        checks.append(check_rr(intent.entry_ref, intent.stop, intent.target, effective_min_rr))

        stop_distance = abs(intent.entry_ref - intent.stop)
        checks.append(check_stop_distance(stop_distance, info, p.min_sl_points, p.max_sl_points))
        target_distance = (
            None if intent.target is None else abs(intent.target - intent.entry_ref)
        )
        checks.append(check_broker_stops(stop_distance, target_distance, info))
        checks.append(check_reconciliation(ctx))

        plan = plan_entry(
            tier=tier,
            risk_multiplier=max(0.0, min(1.5, intent.risk_multiplier)) * budget.factor,
            equity=equity,
            stop_distance=stop_distance,
            info=info,
            commission_per_lot=self._commission,
            open_risk_pct=self._open_risk_pct(ctx),
            profile_cap_pct=p.risk_per_trade_pct,
            drawdown_pct=self._drawdown_pct,
            atr_percentile=ctx.atr_percentile,
            session=ctx.session,
            news_blackout=ctx.news_blackout,
            now=ctx.now,
            params=self._capital,
            manual_lot=p.manual_lot,
            force_min_lot=bool(tags.get("force_min_lot")),
            broker_now=ctx.broker_now,
            costs=self._costs,
            side=intent.side,
            spread_points=ctx.tick.spread / info.point if info.point else None,
            profile_open_risk_cap_pct=p.max_open_risk_pct,
            tier_risk_caps=p.tier_risk_caps,
            allowed_tiers=p.allowed_tiers,
            # CL-05: derive the swap horizon from the profile holding window.
            max_holding_hours=p.max_holding_hours,
        )
        reason_name = {
            "below_min_lot": "volume",
            "gate_d_total_risk": "gate_d_total_risk",
            "rollover_block": "rollover",
            "invalid_stop": "stop_distance",
            "tier_not_allowed": "tier",
            "tier_no_risk": "tier",
        }.get(plan.reason, "volume")
        checks.append(
            CheckResult(
                reason_name,
                plan.volume > 0 and not plan.reason,
                f"tier={tier.value if tier else 'legacy'} risk={plan.risk_pct:.3f}% "
                f"intended={plan.intended_pct:.3f}% lot={plan.volume} "
                f"dd={plan.dd_factor:.2f} vol={plan.vol_factor:.2f} event={plan.event_factor:.2f}"
                + (f" ({plan.reason})" if plan.reason else ""),
                value=plan.risk_pct,
                threshold=self._capital.risk_ceiling_pct,
            )
        )
        if plan.volume > 0:
            notional = plan.volume * info.contract_size * intent.entry_ref
            checks.append(check_margin(notional, float(ctx.account.free_margin.amount), ctx.account.leverage))
            checks.append(check_leverage(notional, equity, p.max_leverage))
        estimated_cost = self._estimate_cost(intent, plan.volume, ctx)

        failed = [c for c in checks if not c.ok]
        if failed:
            decision = RiskDecision(
                verdict=Verdict.REJECT,
                reasons=tuple(c.name for c in failed),
                checks=tuple(checks),
            )
            self._journal_decision(
                intent, decision, plan.risk_pct, plan.risk_amount, stop_distance, ctx,
                estimated_cost=estimated_cost,
            )
            return decision

        snapshot = RiskSnapshot(
            equity=equity,
            balance=ctx.balance,
            risk_pct=round(plan.risk_pct, 4),
            risk_amount=round(plan.risk_amount, 2),
            stop_distance=round(stop_distance, 5),
            volume=plan.volume,
            spread_points=round(ctx.tick.spread / info.point, 1) if info.point else 0.0,
            atr=None if ctx.atr is None else round(ctx.atr, 5),
            daily_pnl=round(self._daily_pnl, 2),
            open_positions=ctx.open_positions,
            profile=p.name,
        )

        order = ApprovedOrder(
            intent_id=intent.intent_id,
            slot=intent.slot,
            strategy=intent.strategy,
            symbol=intent.symbol,
            side=intent.side,
            volume=plan.volume,
            order_type=intent.order_type,
            sl=intent.stop,
            tp=intent.target,
            magic=magic_for_slot(intent.slot, self._magic_base),
            client_ref=client_ref(intent.intent_id),
            max_slippage_points=15,
            risk=snapshot,
            signal={**dict(intent.signal), "_estimated_cost": estimated_cost or {}},
            limit_price=intent.limit_price,
            expires_at=intent.expires_at,
        ).seal(self._secret)

        self._orders_today += 1
        self._last_order_at = ctx.now
        self._write_state()
        decision = RiskDecision(verdict=Verdict.APPROVE, reasons=(), checks=tuple(checks), order=order)
        self._journal_decision(
            intent, decision, plan.risk_pct, plan.risk_amount, stop_distance, ctx,
            estimated_cost=estimated_cost,
        )
        return decision

    def _worst_case_trade_risk_pct(self) -> float:
        """Largest per-trade risk the pipeline can assign after all clamps.

        Used for positions whose stop/risk is unknown (CL-04). Counting them at
        0.0 would silently enlarge the Gate D budget; counting them at this cap
        can only tighten sizing.
        """
        return max(
            0.0,
            min(self._capital.risk_ceiling_pct, self._capital.trade_risk_cap_pct),
        )

    def _journal_untracked_open_risk(
        self, tickets: list[int], count: int, worst_pct: float, total_pct: float, equity: float
    ) -> None:
        """Warn once per untracked ticket: foreign/manual/adopted positions exist."""
        new = sorted(ticket for ticket in tickets if ticket not in self._untracked_warned)
        if not new:
            return
        self._untracked_warned.update(new)
        log.warning(
            "untracked open position(s) counted at worst-case risk",
            extra={"fields": {"tickets": new, "worst_case_pct": worst_pct}},
        )
        self._emit(
            Ev.DIVERGENCE,
            {
                "kind": "untracked_open_positions",
                "tickets": new,
                "untracked_count": count,
                "worst_case_pct": round(worst_pct, 4),
                "open_risk_pct": round(total_pct, 4),
                "equity": round(equity, 2),
            },
        )

    def _open_risk_pct(self, ctx: RiskContext) -> float:
        """Aggregate open risk in percent of equity, fail-closed (CL-04).

        RiskContext.positions is the unfiltered broker snapshot (engine._context
        passes broker.positions()), while _ticket_meta only covers fills that
        this engine registered. Manual, foreign-magic or restart-adopted orphan
        positions therefore have no meta: they are counted at the worst-case
        per-trade cap instead of 0.0, so they can only shrink or reject the new
        size, never enlarge it.
        """
        if ctx.equity <= 0:
            return 0.0
        worst_pct = self._worst_case_trade_risk_pct()
        worst_amount = worst_pct / 100.0 * ctx.equity
        total = 0.0
        untracked: list[int] = []
        for pos in ctx.positions:
            ticket = int(pos.ticket)
            meta = self._ticket_meta.get(ticket)
            if meta is None:
                untracked.append(ticket)
                total += worst_amount
                continue
            risk_amount = meta.get("risk_amount")
            if risk_amount is None:
                # Corrupt/partial meta is not evidence of zero risk.
                untracked.append(ticket)
                total += worst_amount
                continue
            total += float(risk_amount)
        total_pct = total / ctx.equity * 100.0
        if untracked:
            self._journal_untracked_open_risk(
                untracked, len(untracked), worst_pct, total_pct, ctx.equity
            )
        return total_pct

    def _estimate_cost(
        self, intent: EntryIntent, volume: float, ctx: RiskContext
    ) -> dict[str, float] | None:
        """Expected round-trip cost for the intended volume (cost positive)."""
        if volume <= 0:
            return None
        info = ctx.symbol_info
        params = self._costs or CostParams(commission_per_lot_rt=self._commission)
        # CL-05: the journaled estimate uses the same holding-horizon rule as
        # sizing, so swap is not under-counted for 36/48/72h profiles.
        breakdown = estimated_round_trip(
            volume,
            spread_points=ctx.tick.spread / info.point if info.point else None,
            nights=expected_nights_for(self.profile.max_holding_hours),
            is_news=ctx.news_blackout,
            side=intent.side,
            broker_day=(ctx.broker_now or ctx.now).weekday(),
            params=params,
        )
        return breakdown.as_dict()

    def _journal_decision(
        self,
        intent: EntryIntent,
        decision: RiskDecision,
        risk_pct: float,
        risk_amount: float,
        stop_distance: float,
        ctx: RiskContext,
        *,
        estimated_cost: dict[str, float] | None = None,
    ) -> None:
        self._emit(
            Ev.RISK_EVALUATED,
            {
                "intent_id": intent.intent_id,
                "slot": intent.slot,
                "symbol": str(intent.symbol),
                "side": intent.side,
                "verdict": decision.verdict.value,
                "reasons": list(decision.reasons),
                "risk_pct": round(risk_pct, 4),
                "risk_amount": round(risk_amount, 2),
                "stop_distance": round(stop_distance, 5),
                "entry_ref": intent.entry_ref,
                "spread": round(ctx.tick.spread, 3),
                "spread_points": (
                    round(ctx.tick.spread / ctx.symbol_info.point, 1)
                    if ctx.symbol_info.point
                    else 0.0
                ),
                "config_hash": self._config_hash,
                "estimated_cost": estimated_cost,
                "checks": [c.as_dict() for c in decision.checks],
            },
        )
        if decision.approved and decision.order is not None:
            self._emit(
                Ev.ORDER_APPROVED,
                {
                    "intent_id": intent.intent_id,
                    # CONF-02 migration trail: journal the deterministic slot
                    # magic and the scheme tag alongside every sealed order.
                    "magic": decision.order.magic,
                    "magic_scheme": MAGIC_SCHEME,
                    "slot": decision.order.slot,
                    "volume": decision.order.volume,
                    "sl": decision.order.sl,
                    "tp": decision.order.tp,
                    "risk": decision.order.risk.as_dict(),
                },
            )

    # ------------------------------------------------------------------
    # position management (in-trade)
    # ------------------------------------------------------------------
    def register_position(self, ticket: int, *, risk_amount: float, initial_stop: float, slot: str) -> None:
        self._ticket_meta[int(ticket)] = {
            "risk_amount": risk_amount,
            "initial_stop": initial_stop,
            "slot": slot,
        }
        # Open positions must stay watched by slot/trail logic after a restart.
        self._write_state()

    def manage(self, ctx: RiskContext) -> Sequence[ManagementAction]:
        actions: list[ManagementAction] = []
        p = self.profile
        for pos in ctx.positions:
            meta = self._ticket_meta.get(int(pos.ticket))
            if meta is None:
                continue
            entry = pos.open_price
            risk = abs(entry - meta["initial_stop"])
            if risk <= 0:
                continue
            price = ctx.tick.bid if pos.side == "buy" else ctx.tick.ask
            direction = 1.0 if pos.side == "buy" else -1.0
            r_multiple = (price - entry) * direction / risk

            if p.max_holding_hours > 0:
                age_hours = (ctx.now - pos.open_time).total_seconds() / 3600.0
                if age_hours >= p.max_holding_hours:
                    actions.append(ManagementAction(int(pos.ticket), "close", reason="time"))
                    continue

            if r_multiple >= p.trail_after_r and ctx.atr:
                new_sl = price - direction * ctx.atr * p.trail_atr_mult
                current = pos.sl
                better = current is None or (new_sl > current if pos.side == "buy" else new_sl < current)
                if better:
                    actions.append(
                        ManagementAction(
                            int(pos.ticket), "trail", sl=round(new_sl, ctx.symbol_info.digits), reason=f"trail@{r_multiple:.2f}R"
                        )
                    )
                    continue

            if r_multiple >= p.breakeven_after_r:
                if pos.sl is None or (pos.side == "buy" and pos.sl < entry) or (pos.side == "sell" and pos.sl > entry):
                    actions.append(
                        ManagementAction(
                            int(pos.ticket), "breakeven", sl=round(entry, ctx.symbol_info.digits), reason="breakeven"
                        )
                    )
        return actions

    # ------------------------------------------------------------------
    def snapshot(self) -> RiskSnapshot:
        return self._last_snapshot

    def force_quarantine(self, reason: str) -> None:
        self._state = RiskState.QUARANTINE
        self._reason = reason
        self._emit(Ev.RISK_STATE_CHANGED, {"to": "QUARANTINE", "reason": reason})
        self._write_state()

    @property
    def restore_error(self) -> str | None:
        """Set when a persisted record was found but could not be trusted."""
        return self._restore_error

    @property
    def restarted(self) -> bool:
        """True when this engine adopted state written by an earlier process."""
        return self._restored

    def persistable_state(self) -> PersistedRiskState:
        """The exact record the next durability checkpoint would write."""
        return PersistedRiskState(
            state=self._state,
            reason=self._reason,
            auto_clear=self._auto_clear,
            day=None if self._day is None else self._day.isoformat(),
            day_start_equity=self._day_start_equity,
            peak_equity=self._peak_equity,
            initial_equity=self._initial_equity,
            daily_pnl=self._daily_pnl,
            drawdown_pct=self._drawdown_pct,
            consecutive_losses=self._consecutive_losses,
            orders_today=self._orders_today,
            last_order_at=(
                None if self._last_order_at is None else self._last_order_at.isoformat()
            ),
            last_loss_at=(
                None if self._last_loss_at is None else self._last_loss_at.isoformat()
            ),
            ticket_meta={
                int(ticket): dict(meta) for ticket, meta in self._ticket_meta.items()
            },
            extras=dict(self._extras),
            restored_at=self._restored_at or self._stamp(),
            updated_at=self._stamp(),
        )

    # ------------------------------------------------------------------
    # durability
    # ------------------------------------------------------------------
    def _stamp(self) -> str:
        return self._clock.now().wall.isoformat()

    def _write_state(self) -> None:
        """Write-through: a safety transition is never buffered in memory."""
        if self._state_store is None:
            return
        self._state_store.save(self.persistable_state())
        self._persisted_mark = (self._peak_equity, self._daily_pnl)

    def _persist_if_material(self, equity: float) -> None:
        """Checkpoint marks only when the persisted risk numbers actually moved."""
        if self._state_store is None or self._persisted_mark is None:
            return
        peak, daily = self._persisted_mark
        tolerance = max(1.0, abs(equity) * 0.001)
        if self._peak_equity != peak or abs(self._daily_pnl - daily) >= tolerance:
            self._write_state()

    def _restore(self, *, allow_cold_start: bool) -> None:
        """Adopt the previous process's state; an unreadable store means quarantine."""
        assert self._state_store is not None
        stamp = self._stamp()
        error: str | None = None
        loaded: PersistedRiskState | None = None
        try:
            loaded = self._state_store.load()
            if loaded is not None:
                self._apply_restored(loaded)
        except StateCorruption as exc:
            error = str(exc)
            loaded = None
        except (TypeError, ValueError) as exc:  # bad timestamps inside the record
            error = f"invalid persisted state: {exc}"
            loaded = None
        self._restore_error = error
        self._restored_at = stamp
        if loaded is not None:
            self._restored = True
            self._persisted_mark = (self._peak_equity, self._daily_pnl)
            return
        if allow_cold_start and error is None:
            return
        # An empty store in live/paper mode, or a corrupt record, must never
        # become NORMAL: the safest state is one a human looks at first.
        reason = (
            f"corrupt persisted risk state: {error}"
            if error is not None
            else "no persisted risk state (first run)"
        )
        self._state = RiskState.QUARANTINE
        self._reason = reason
        self._auto_clear = False
        self._emit(
            Ev.RISK_STATE_CHANGED,
            {"from": "NORMAL", "to": "QUARANTINE", "reason": reason, "actor": "system"},
        )
        # Latch it durably so the next process does not see an empty store.
        self._write_state()

    def _apply_restored(self, loaded: PersistedRiskState) -> None:
        self._state = loaded.state
        self._reason = loaded.reason
        self._auto_clear = loaded.auto_clear
        self._day = None if loaded.day is None else date.fromisoformat(loaded.day)
        self._day_start_equity = loaded.day_start_equity
        self._peak_equity = loaded.peak_equity
        self._initial_equity = loaded.initial_equity
        self._daily_pnl = loaded.daily_pnl
        self._drawdown_pct = loaded.drawdown_pct
        self._consecutive_losses = loaded.consecutive_losses
        self._orders_today = loaded.orders_today
        self._last_order_at = _parse_dt(loaded.last_order_at)
        self._last_loss_at = _parse_dt(loaded.last_loss_at)
        self._ticket_meta = {
            int(ticket): dict(meta) for ticket, meta in loaded.ticket_meta.items()
        }
        self._extras = dict(loaded.extras)

    def aux(self, key: str, default: Any = None) -> Any:
        """Adjacent safety state (gates) stored alongside the risk record."""
        return self._extras.get(key, default)

    def update_aux(self, key: str, value: Any) -> None:
        """Persist an adjacent-state snapshot; called on bar boundaries."""
        self._extras[str(key)] = value
        self._write_state()

    def reload_aux(self) -> bool:
        """Adopt aux keys written by another process (CLI override/approval).

        Only the adjacent state is refreshed; the authoritative risk numbers
        stay owned by this process so a stale external row cannot reset a latch.
        """
        if self._state_store is None:
            return False
        try:
            loaded = self._state_store.load()
        except Exception:  # noqa: BLE001 - a bad row must not change live state
            return False
        if loaded is None:
            return False
        adjacent = dict(loaded.extras)
        if adjacent == self._extras:
            return False
        self._extras = adjacent
        return True

    # -- operator override ----------------------------------------------
    def manual_pause_until(self) -> datetime | None:
        return _parse_dt(self._extras.get("manual_pause_until"))

    def manual_pause_reason(self) -> str:
        return str(self._extras.get("manual_pause_reason") or "")

    def set_manual_pause(
        self, until: datetime | None, *, reason: str = "", actor: str = "operator"
    ) -> None:
        """Pause new entries until `until` (None clears). Open positions untouched."""
        if until is None:
            self._extras.pop("manual_pause_until", None)
            self._extras.pop("manual_pause_reason", None)
            action = "resume"
        else:
            self._extras["manual_pause_until"] = until.isoformat()
            self._extras["manual_pause_reason"] = reason
            action = "pause"
        self._emit(
            Ev.MANUAL_OVERRIDE,
            {
                "action": action,
                "until": None if until is None else until.isoformat(),
                "reason": reason,
                "actor": actor,
            },
            actor=actor,
        )
        self._write_state()

    @property
    def daily_pnl(self) -> float:
        return self._daily_pnl

    @property
    def drawdown_pct(self) -> float:
        return self._drawdown_pct

    @property
    def orders_today(self) -> int:
        return self._orders_today

    @property
    def consecutive_losses(self) -> int:
        return self._consecutive_losses
