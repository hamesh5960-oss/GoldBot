"""Health snapshot: one JSON-safe view of safety state for /health and ops.

A health probe must never raise: it runs from the web panel, from the watchdog
and from the terminal, often exactly when something else is broken. Every
field is therefore extracted best-effort and a failure is reported as a
degraded snapshot instead of an exception.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping

from ..domain.model import Ts, utc
from .heartbeat import Heartbeat

HEARTBEAT_MAX_AGE_SECONDS = 900.0
RECONCILE_FRESH_SECONDS = 900.0
NORMAL_STATE = "NORMAL"


@dataclass(frozen=True, slots=True)
class HealthSnapshot:
    """Immutable, JSON-safe health view. degraded is the only field to gate on."""

    ts: str
    risk_state: str
    reason: str
    heartbeat_age_seconds: float | None
    heartbeat_stale: bool
    open_positions: int
    orders_today: int
    daily_pnl: float
    drawdown_pct: float
    journal_events: int
    last_reconcile_ok: bool
    degraded: bool
    details: Mapping[str, Any] = field(default_factory=dict)

    @property
    def ok(self) -> bool:
        return not self.degraded

    def as_dict(self) -> dict[str, Any]:
        return {
            "ts": self.ts,
            "risk_state": self.risk_state,
            "reason": self.reason,
            "heartbeat_age_seconds": self.heartbeat_age_seconds,
            "heartbeat_stale": self.heartbeat_stale,
            "open_positions": self.open_positions,
            "orders_today": self.orders_today,
            "daily_pnl": self.daily_pnl,
            "drawdown_pct": self.drawdown_pct,
            "journal_events": self.journal_events,
            "last_reconcile_ok": self.last_reconcile_ok,
            "degraded": self.degraded,
            "details": dict(self.details),
        }


def _resolve(value: Any) -> Any:
    """Call a zero-argument accessor; tolerate a broken one."""
    if callable(value):
        try:
            return value()
        except Exception:  # noqa: BLE001 - a health probe never raises
            return None
    return value


def _field(source: Any, names: tuple[str, ...], default: Any = None) -> Any:
    if source is None:
        return default
    for name in names:
        try:
            attribute = getattr(source, name)
        except Exception:  # noqa: BLE001 - tolerate objects with broken properties
            continue
        resolved = _resolve(attribute)
        if resolved is not None:
            return resolved
    return default


def _as_float(value: Any, default: float = 0.0) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return default
    return number if math.isfinite(number) else default


def _as_int(value: Any, default: int = 0) -> int:
    try:
        return int(value)
    except (TypeError, ValueError, OverflowError):
        return default


def _wall(now: Any) -> tuple[datetime, bool]:
    if isinstance(now, Ts):
        return now.wall, True
    if isinstance(now, datetime):
        return utc(now), True
    # A missing clock must not crash the probe; the epoch is an explicit,
    # obviously-wrong timestamp that details["now_ok"] flags.
    return datetime(1970, 1, 1, tzinfo=timezone.utc), False


def snapshot(
    *,
    risk: Any,
    journal: Any,
    heartbeat_path: str | Path | None = None,
    now: Any,
) -> HealthSnapshot:
    """Build a HealthSnapshot; never raises, whatever the inputs look like.

    degraded is true when the risk state is not NORMAL, when the heartbeat file
    is stale/unreadable/not configured, or when the event journal cannot be
    read. Missing attributes degrade the fields, not the caller.
    """
    moment, now_ok = _wall(now)
    details: dict[str, Any] = {}
    problems: list[str] = []
    if not now_ok:
        problems.append("now missing")

    raw_state = _field(risk, ("state", "risk_state"))
    if raw_state is None and isinstance(risk, str):
        raw_state = risk
    state_value = getattr(raw_state, "value", raw_state)
    risk_state = str(state_value) if state_value not in (None, "") else "UNKNOWN"

    reason_value = _field(risk, ("reason",), default="")
    reason = reason_value if isinstance(reason_value, str) else str(reason_value or "")

    daily_pnl = _as_float(_field(risk, ("daily_pnl",), default=0.0))
    drawdown_pct = _as_float(_field(risk, ("drawdown_pct",), default=0.0))
    orders_today = _as_int(_field(risk, ("orders_today",), default=0))

    open_positions = 0
    positions_raw = _field(risk, ("open_positions", "position_count"))
    if positions_raw is not None:
        open_positions = _as_int(positions_raw)
    else:
        positions = _field(risk, ("positions",))
        if positions is not None:
            try:
                open_positions = len(positions)
            except TypeError:
                open_positions = 0
    open_positions = max(0, open_positions)

    journal_events = -1
    journal_reachable = False
    if journal is None:
        details["journal"] = "missing"
    else:
        try:
            journal_events = _as_int(journal.count())
            journal_reachable = True
            details["journal"] = "reachable"
        except Exception as exc:  # noqa: BLE001 - an unreadable journal is a health fact
            details["journal"] = f"unreachable:{type(exc).__name__}"
    if not journal_reachable:
        problems.append("journal unreachable")

    heartbeat_stale = True
    heartbeat_age: float | None = None
    heartbeat_payload: dict[str, Any] = {}
    if heartbeat_path is None:
        details["heartbeat"] = "not_configured"
        problems.append("heartbeat unknown")
    else:
        try:
            stale, age, data = Heartbeat.is_stale(
                heartbeat_path, moment, HEARTBEAT_MAX_AGE_SECONDS
            )
        except Exception:  # noqa: BLE001 - the probe never raises
            stale, age, data = True, None, {}
        heartbeat_stale = bool(stale)
        heartbeat_age = None if age is None else _as_float(age, 0.0)
        if isinstance(data, Mapping):
            payload = data.get("payload")
            heartbeat_payload = dict(payload) if isinstance(payload, Mapping) else {}
        if heartbeat_stale:
            details["heartbeat"] = "stale" if heartbeat_age is not None else "unknown"
            problems.append("heartbeat stale")
        else:
            details["heartbeat"] = "fresh"
    if heartbeat_payload:
        details["heartbeat_payload"] = heartbeat_payload

    reconcile_raw = _field(risk, ("last_reconcile_ok", "reconciled"))
    last_reconcile_ok = False
    if isinstance(reconcile_raw, bool):
        last_reconcile_ok = reconcile_raw
    elif isinstance(reconcile_raw, datetime):
        last_reconcile_ok = (
            moment - utc(reconcile_raw)
        ).total_seconds() <= RECONCILE_FRESH_SECONDS
    elif reconcile_raw is not None:
        last_reconcile_ok = bool(reconcile_raw)
    details["last_reconcile_ok"] = last_reconcile_ok

    if risk_state != NORMAL_STATE and risk_state != "UNKNOWN":
        problems.append(f"risk state {risk_state}")
    elif risk_state == "UNKNOWN":
        problems.append("risk state unknown")
    details["problems"] = problems
    details["now_ok"] = now_ok

    degraded = (
        risk_state != NORMAL_STATE
        or heartbeat_stale
        or not journal_reachable
        or not now_ok
    )
    return HealthSnapshot(
        ts=moment.isoformat(),
        risk_state=risk_state,
        reason=reason,
        heartbeat_age_seconds=heartbeat_age,
        heartbeat_stale=heartbeat_stale,
        open_positions=open_positions,
        orders_today=orders_today,
        daily_pnl=daily_pnl,
        drawdown_pct=drawdown_pct,
        journal_events=journal_events,
        last_reconcile_ok=last_reconcile_ok,
        degraded=degraded,
        details=details,
    )
