"""Market regime: H1 trend, ADX, ATR and structure breaks (BOS/CHoCH)."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Sequence

from ..domain.model import Bar
from ..strategy_api import indicators


@dataclass(frozen=True, slots=True)
class MarketRegime:
    atr_m15: float | None
    atr_h1: float | None
    atr_h1_median: float | None
    adx_h1: float | None
    ema_h1: float | None
    trend: str  # up | down | flat
    session: str  # asia | london | ny
    structure_event: str | None = None
    structure_direction: str | None = None


class StructureTracker:
    """Fires BOS/CHoCH once per crossing of the confirmed H1 range."""

    def __init__(self, span: int = 3, cooldown_bars: int = 8) -> None:
        self.span = span
        self.cooldown_bars = cooldown_bars
        self._bars = 0
        self._last_event_bar = -10_000
        self._direction: str | None = None

    def reset(self) -> None:
        self._bars = 0
        self._last_event_bar = -10_000
        self._direction = None

    def update(self, h1: Sequence[Bar]) -> tuple[str | None, str | None]:
        self._bars += 1
        if len(h1) < self.span * 2 + 5:
            return (None, None)
        window = h1[: -self.span]
        highest = max(bar.h for bar in window)
        lowest = min(bar.l for bar in window)
        previous = h1[-2].c
        close = h1[-1].c
        if self._bars - self._last_event_bar < self.cooldown_bars:
            return (None, None)

        event: str | None = None
        direction: str | None = None
        if previous <= highest < close:
            event = "CHoCH" if self._direction == "down" else "BOS"
            direction = "up"
        elif previous >= lowest > close:
            event = "CHoCH" if self._direction == "up" else "BOS"
            direction = "down"
        if event is None:
            return (None, None)
        self._last_event_bar = self._bars
        self._direction = direction
        return (event, direction)


class RegimeEngine:
    def __init__(self, *, atr_period: int = 14, adx_period: int = 14, ema_period: int = 200) -> None:
        self.atr_period = atr_period
        self.adx_period = adx_period
        self.ema_period = ema_period
        self.structure = StructureTracker()

    @staticmethod
    def session(moment: datetime) -> str:
        hour = moment.hour
        if 7 <= hour <= 11:
            return "london"
        if 12 <= hour <= 21:
            return "ny"
        return "asia"

    def snapshot(self, bars_m15: Sequence[Bar]) -> MarketRegime:
        h1 = indicators.resample(bars_m15, "H1")
        atr_m15 = indicators.atr(bars_m15, self.atr_period)
        atr_h1 = indicators.atr(h1, self.atr_period)
        atr_median = indicators.median([bar.range for bar in h1[-20:]]) if len(h1) >= 20 else None
        adx_h1 = indicators.adx(h1, self.adx_period)
        closes = [bar.c for bar in h1]
        period = self.ema_period if len(closes) >= self.ema_period else max(20, len(closes) // 2)
        series = indicators.ema_series(closes, period)
        ema_h1 = series[-1] if series else None
        trend = "flat"
        if ema_h1 is not None and closes:
            distance = (closes[-1] - ema_h1) / atr_h1 if atr_h1 else 0.0
            if distance > 0.5:
                trend = "up"
            elif distance < -0.5:
                trend = "down"
        event, direction = self.structure.update(h1) if h1 else (None, None)
        session = self.session(bars_m15[-1].open_time) if bars_m15 else "asia"
        return MarketRegime(
            atr_m15=atr_m15,
            atr_h1=atr_h1,
            atr_h1_median=atr_median,
            adx_h1=adx_h1,
            ema_h1=ema_h1,
            trend=trend,
            session=session,
            structure_event=event,
            structure_direction=direction,
        )
