"""Quality-aware daily order budget: reserve, spacing and post-loss cooldown."""

from __future__ import annotations

from dataclasses import dataclass, replace
from datetime import datetime


@dataclass(frozen=True, slots=True)
class BudgetParams:
    soft_limit: int = 10
    hard_limit: int = 15
    reserve_pct: float = 0.30
    min_spacing_minutes: int = 10
    post_loss_cooldown_minutes: int = 30
    high_quality_tiers: tuple[str, ...] = ("A+", "A")
    extended_only_tiers: tuple[str, ...] = ("A+",)

    def for_profile(self, max_orders_per_day: int) -> "BudgetParams":
        """The budget can never promise more orders than the profile allows.

        The profile cap is the final authority (check_orders_per_day), so a
        budget with soft=10/hard=15 on a 10-order profile would otherwise
        describe a dead zone where the budget grants HALF but the engine
        rejects. Clamp both limits to the profile cap.
        """
        cap = max(1, int(max_orders_per_day))
        hard = max(1, min(int(self.hard_limit), cap))
        soft = max(1, min(int(self.soft_limit), hard))
        if soft == self.soft_limit and hard == self.hard_limit:
            return self
        return replace(self, soft_limit=soft, hard_limit=hard)


@dataclass(frozen=True, slots=True)
class BudgetResult:
    outcome: str  # full | half | reject
    reason: str
    factor: float = 1.0

    @property
    def rejected(self) -> bool:
        return self.outcome == "reject"


def evaluate_budget(
    *,
    tier: str | None,
    orders_today: int,
    now: datetime,
    last_order_at: datetime | None,
    last_loss_at: datetime | None,
    params: BudgetParams,
) -> BudgetResult:
    general_pool = max(1, int(params.soft_limit * (1.0 - params.reserve_pct)))
    high_quality = tier in params.high_quality_tiers
    extended = tier in params.extended_only_tiers

    if last_order_at is not None:
        spacing = (now - last_order_at).total_seconds() / 60.0
        if spacing < params.min_spacing_minutes:
            return BudgetResult("reject", "min_spacing_not_met")
    if last_loss_at is not None:
        cooldown = (now - last_loss_at).total_seconds() / 60.0
        if cooldown < params.post_loss_cooldown_minutes:
            return BudgetResult("reject", "post_loss_cooldown")

    if orders_today < general_pool:
        return BudgetResult("full", "within_general_pool")
    if orders_today < params.soft_limit:
        if high_quality:
            return BudgetResult("full", "within_reserve_pool")
        return BudgetResult("reject", "reserve_for_high_quality_only")
    if orders_today < params.hard_limit:
        if extended:
            return BudgetResult("half", "extended_quality_only", 0.5)
        return BudgetResult("reject", "extended_reserve")
    return BudgetResult("reject", "hard_limit")
