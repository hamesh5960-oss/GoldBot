"""Fail-closed broker/account spec validation before a session starts.

The engine must never trade a symbol whose contract facts are wrong: a bad
point, contract size or stops level silently corrupts every risk number that
follows. This module is pure (domain + stdlib only) so startup, the web panel
and tests all evaluate the exact same rules.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal

from ..domain.symbol_meta import FILLING_MODES

Severity = Literal["fatal", "warn"]

SYMBOL_TRADE_MODES: tuple[str, ...] = ("full", "longonly", "shortonly", "closeonly", "disabled")

# Default expected currency: a USD account is the only supported setup today.
DEFAULT_CURRENCY = "USD"

FATAL = "fatal"
WARN = "warn"


@dataclass(frozen=True, slots=True)
class SpecIssue:
    """One rule violation; severity fatal blocks the session, warn does not."""

    code: str
    detail: str
    severity: Severity


@dataclass(frozen=True, slots=True)
class SpecReport:
    """Outcome of validate_specs: a gate plus the numbers that were judged."""

    ok: bool
    issues: tuple[SpecIssue, ...]
    effective: dict[str, Any] = field(default_factory=dict)

    @property
    def fatal(self) -> tuple[SpecIssue, ...]:
        return tuple(issue for issue in self.issues if issue.severity == FATAL)

    @property
    def warnings(self) -> tuple[SpecIssue, ...]:
        return tuple(issue for issue in self.issues if issue.severity == WARN)

    @property
    def codes(self) -> tuple[str, ...]:
        return tuple(issue.code for issue in self.issues)

    def as_dict(self) -> dict[str, Any]:
        return {
            "ok": self.ok,
            "issues": [
                {"code": issue.code, "detail": issue.detail, "severity": issue.severity}
                for issue in self.issues
            ],
            "effective": dict(self.effective),
        }


def _number(source: Any, name: str, default: float = 0.0) -> float:
    """Best-effort float read; a missing or non-numeric attribute uses default."""
    try:
        value = getattr(source, name, default)
    except Exception:  # noqa: BLE001 - validation must never raise
        return default
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def validate_specs(
    info: Any,
    account: Any,
    *,
    expected_currency: str = DEFAULT_CURRENCY,
    allow_netting: bool = False,
    expected_contract_size: float | None = None,
    require_filling_mode: bool = False,
) -> SpecReport:
    """Validate one symbol + account pair; fatal rules make the session unsafe.

    Every check is fail-closed: missing numbers are treated as zero, and an
    invalid symbol mode is fatal rather than guessed. Warnings (unknown tick
    value, restricted symbol mode) are reported but do not block.
    """
    issues: list[SpecIssue] = []

    def fatal(code: str, detail: str) -> None:
        issues.append(SpecIssue(code=code, detail=detail, severity=FATAL))

    def warn(code: str, detail: str) -> None:
        issues.append(SpecIssue(code=code, detail=detail, severity=WARN))

    if info is None:
        fatal("symbol_missing", "no SymbolInfo supplied")
        return SpecReport(ok=False, issues=tuple(issues), effective={})

    digits = int(_number(info, "digits", 0.0))
    point = _number(info, "point", 0.0)
    tick_size = _number(info, "tick_size", 0.0)
    contract_size = _number(info, "contract_size", 0.0)
    min_volume = _number(info, "min_volume", 0.0)
    max_volume = _number(info, "max_volume", 0.0)
    volume_step = _number(info, "volume_step", 0.0)
    stops_level = int(_number(info, "stops_level_points", 0.0))
    freeze_level = int(_number(info, "freeze_level_points", 0.0))
    tick_value = _number(info, "tick_value", 0.0)
    symbol_mode = str(getattr(info, "trade_mode", "") or "")
    filling_mode = str(getattr(info, "filling_mode", "unknown") or "unknown")
    currency_profit = str(getattr(info, "currency_profit", "") or "")

    if contract_size <= 0.0:
        fatal("contract_size_invalid", f"contract_size {contract_size} <= 0")
    if point <= 0.0:
        fatal("point_invalid", f"point {point} <= 0")
    if tick_size <= 0.0:
        fatal("tick_size_invalid", f"tick_size {tick_size} <= 0")
    if min_volume <= 0.0:
        fatal("min_lot_invalid", f"min_volume {min_volume} <= 0")
    if max_volume < min_volume:
        fatal("max_lot_below_min", f"max_volume {max_volume} < min_volume {min_volume}")
    if volume_step <= 0.0:
        fatal("volume_step_invalid", f"volume_step {volume_step} <= 0")
    if stops_level < 0:
        fatal("stops_level_negative", f"stops_level_points {stops_level} < 0")
    if freeze_level < 0:
        fatal("freeze_level_negative", f"freeze_level_points {freeze_level} < 0")
    if symbol_mode not in SYMBOL_TRADE_MODES:
        fatal("symbol_trade_mode_invalid", f"symbol trade_mode {symbol_mode!r} is not a known mode")
    elif symbol_mode != "full":
        warn("symbol_trade_mode_not_full", f"symbol trade_mode is {symbol_mode!r}, not 'full'")
    if tick_value < 0.0:
        fatal("tick_value_invalid", f"tick_value {tick_value} < 0")
    elif tick_value == 0.0:
        warn("tick_value_unknown", "tick_value is 0; sizing falls back to contract_size")
    if filling_mode not in FILLING_MODES:
        fatal("filling_mode_invalid", f"filling_mode {filling_mode!r} is not a known policy")
    elif filling_mode == "unknown" and require_filling_mode:
        fatal("filling_mode_unknown", "filling_mode is required but the venue reported 'unknown'")
    if expected_contract_size is not None:
        tolerance = max(1e-9, abs(float(expected_contract_size)) * 1e-6)
        if abs(contract_size - float(expected_contract_size)) > tolerance:
            fatal(
                "contract_size_mismatch",
                f"contract_size {contract_size} != expected {float(expected_contract_size)}",
            )

    account_currency = ""
    account_mode = ""
    leverage = 0.0
    if account is None:
        fatal("account_missing", "no AccountSnapshot supplied")
    else:
        account_currency = str(getattr(account, "currency", "") or "")
        account_mode = str(getattr(account, "trade_mode", "") or "")
        leverage = _number(account, "leverage", 0.0)
        if account_mode not in ("hedging", "netting"):
            fatal("account_trade_mode_invalid", f"account trade_mode {account_mode!r} is not valid")
        if account_mode == "netting" and not allow_netting:
            fatal("netting_not_allowed", "account is netting but this build requires hedging")
        if account_currency != expected_currency:
            fatal(
                "currency_mismatch",
                f"account currency {account_currency!r} != expected {expected_currency!r}",
            )
        if leverage < 1.0:
            fatal("leverage_invalid", f"leverage {leverage} < 1")

    effective: dict[str, Any] = {
        "symbol": str(getattr(info, "symbol", "") or ""),
        "broker_symbol": str(getattr(info, "broker_symbol", "") or ""),
        "digits": digits,
        "point": point,
        "tick_size": tick_size,
        "contract_size": contract_size,
        "min_volume": min_volume,
        "max_volume": max_volume,
        "volume_step": volume_step,
        "stops_level_points": stops_level,
        "freeze_level_points": freeze_level,
        "tick_value": tick_value,
        "filling_mode": filling_mode,
        "currency_profit": currency_profit,
        "symbol_trade_mode": symbol_mode,
        "account_currency": account_currency,
        "account_trade_mode": account_mode,
        "leverage": leverage,
        "expected_currency": expected_currency,
        "expected_contract_size": expected_contract_size,
        "allow_netting": bool(allow_netting),
        "require_filling_mode": bool(require_filling_mode),
    }
    ok = not any(issue.severity == FATAL for issue in issues)
    return SpecReport(ok=ok, issues=tuple(issues), effective=effective)


def risk_per_lot(
    info: Any,
    stop_distance: float,
    volume: float = 1.0,
    slippage_points: float = 0.0,
    commission_per_lot: float = 0.0,
) -> float:
    """Dollar risk of one position at a stop this far away, costs included.

    Uses tick_value/tick_size when the venue gave both (the honest MT5 path);
    otherwise falls back to contract_size. Value is returned for the requested
    volume, so risk_per_lot(info, 2.0, 0.1) is the risk of a 0.10-lot trade.
    """
    stop = float(stop_distance)
    lots = float(volume)
    slippage = float(slippage_points)
    commission = float(commission_per_lot)
    if stop <= 0.0:
        raise ValueError(f"stop_distance must be > 0, got {stop_distance}")
    if lots <= 0.0:
        raise ValueError(f"volume must be > 0, got {volume}")
    if slippage < 0.0:
        raise ValueError(f"slippage_points must be >= 0, got {slippage_points}")
    if commission < 0.0:
        raise ValueError(f"commission_per_lot must be >= 0, got {commission_per_lot}")

    tick_value = _number(info, "tick_value", 0.0)
    tick_size = _number(info, "tick_size", 0.0)
    contract_size = _number(info, "contract_size", 0.0)
    if tick_value > 0.0:
        if tick_size <= 0.0:
            raise ValueError("tick_size must be > 0 when tick_value is provided")
        value_per_price_unit = tick_value / tick_size
    else:
        if contract_size <= 0.0:
            raise ValueError("contract_size must be > 0 when tick_value is unknown")
        value_per_price_unit = contract_size

    point = _number(info, "point", 0.0)
    if slippage > 0.0 and point <= 0.0:
        raise ValueError("point must be > 0 when slippage_points is non-zero")
    price_risk = (stop + slippage * point) * value_per_price_unit
    return (price_risk + commission) * lots
