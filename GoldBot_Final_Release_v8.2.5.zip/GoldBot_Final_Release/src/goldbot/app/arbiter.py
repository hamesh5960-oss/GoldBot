"""Attach trailing-window, same-direction confirmations to incoming signals.

A signal can see a previously registered signal from another strategy within
the lookback window. Earlier decisions are not retroactively upgraded: the
arbiter only exposes STRICTLY earlier signals, so there is no look-ahead and
no same-timestamp self-confirmation. Only signals the engine has qualified for
execution are registered (see TradingEngine), so rejected signals never confirm.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Sequence


@dataclass(frozen=True, slots=True)
class SignalMemory:
    ts: datetime
    slot: str
    strategy: str
    symbol: str
    side: str


class SignalArbiter:
    def __init__(self, *, window_minutes: float = 30.0) -> None:
        self.window = timedelta(minutes=window_minutes)
        self._items: list[SignalMemory] = []

    def _prune(self, now: datetime) -> None:
        cutoff = now - self.window
        self._items = [item for item in self._items if item.ts >= cutoff]

    def confirmations(
        self, *, ts: datetime, strategy: str, symbol: str, side: str
    ) -> tuple[str, ...]:
        """Strategies confirming a signal at ts (read-only, strictly earlier).

        Same-timestamp signals never confirm each other: an earlier signal on
        the same bar is not "earlier" in any causal sense for this bar's entry.
        """
        self._prune(ts)
        current = str(strategy)
        return tuple(
            sorted(
                {
                    item.strategy
                    for item in self._items
                    if item.ts < ts
                    and item.symbol == symbol
                    and item.side == side
                    and item.strategy != current
                }
            )
        )

    def register(
        self, *, ts: datetime, slot: str, strategy: str, symbol: str, side: str
    ) -> tuple[str, ...]:
        """Record a qualified signal and return its earlier confirmations.

        Callers that need confirmations before deciding must use
        confirmations(); register() is the write step and is only called once
        the signal has qualified for execution.
        """
        earlier = self.confirmations(ts=ts, strategy=strategy, symbol=symbol, side=side)
        self._items.append(SignalMemory(ts=ts, slot=slot, strategy=strategy, symbol=symbol, side=side))
        return tuple([strategy, *earlier])

    def recent(self, *, symbol: str | None = None, side: str | None = None) -> Sequence[SignalMemory]:
        items = self._items
        if symbol is not None:
            items = [i for i in items if i.symbol == symbol]
        if side is not None:
            items = [i for i in items if i.side == side]
        return tuple(items)


def has_other_strategy_confirmation(
    confirmations: Sequence[str], current_strategy: str
) -> bool:
    """Return True only when a *different strategy id* confirmed this signal.

    Strategy slot ids (for example zones_m15) are deliberately not used here:
    a slot is an instance identifier, not a strategy identity.
    """
    current = str(current_strategy)
    return any(str(item) != current for item in confirmations)
