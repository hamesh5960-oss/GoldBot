"""Five independent confirmation scorers plus the layer-3 vote combiner.

Every factor is a pure function of closed bars (plus a few values the caller
already computed) and returns exactly 0.0, 0.5 or 1.0. The aggregate report is
the sum of the five factors, i.e. a 0..5 confirmation count that the decision
matrix turns into a base tier. Layer 3 is deliberately separate: it is a small
directional bonus/penalty built from independent votes, capped so no single
confirmation set can jump more than one tier on its own.

Factor contract
---------------
* score_fvg_ob  - is there a fair-value gap or order block at the zone?
* score_maxlines- is price at a Murrey -2/8 (buy) or +2/8 (sell) reversal line?
* score_ema50   - is price on the signal side of an aligned EMA50?
* score_rsi     - is RSI at an extreme, turning out of one, or diverging?
* score_bollinger - is price returning from the opposite band while it expands?

All scorers are defensive: empty, short or malformed input returns 0.0 and never
raises. They never mutate their arguments and have no clock, journal or I/O.

Layer 3 votes are clamped to [-1, 1] each, summed, multiplied by
LAYER3_WEIGHT and clamped to +/-LAYER3_CAP. A result of at least +0.6 is one
tier up, at most -0.6 one tier down, anything else no change.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Mapping, Sequence

from ..domain.model import Bar
from ..strategy_api import indicators

__all__ = [
    "FACTOR_NAMES",
    "LAYER3_CAP",
    "LAYER3_WEIGHT",
    "ConfirmationReport",
    "Layer3Report",
    "ema200_h1_vote",
    "evaluate_confirmations",
    "layer3_score",
    "score_bollinger",
    "score_ema50",
    "score_fvg_ob",
    "score_maxlines",
    "score_rsi",
    "zone_confirms_layer3",
]

FACTOR_NAMES: tuple[str, ...] = ("fvg_ob", "maxlines", "ema50", "rsi", "bollinger")

LAYER3_WEIGHT = 0.2
LAYER3_CAP = 1.2
# A layer-3 result must be strong enough to move a tier on its own.
LAYER3_DELTA_THRESHOLD = 0.6

_EPS = 1e-9
_FVG_LOOKBACK = 30
_MAXLINES_LOOKBACK = 64
_EMA_LOOKBACK = 200
_EMA200_PERIOD = 200
_BOLLINGER_PERIOD = 20
_BOLLINGER_DEVIATIONS = 2.0
_BAND_TOUCH_BARS = 5

_MALFORMED = (TypeError, ValueError, AttributeError, IndexError, ZeroDivisionError, OverflowError)


@dataclass(frozen=True, slots=True)
class ConfirmationReport:
    """The five factor scores and their sum (0..5)."""

    total: float
    factors: Mapping[str, float]
    names: tuple[str, ...] = FACTOR_NAMES


@dataclass(frozen=True, slots=True)
class Layer3Report:
    """Layer-3 vote result: weighted score, tier delta and the clamped votes."""

    score: float
    delta: int
    votes: Mapping[str, int]


# -- small helpers -------------------------------------------------------
def _tail(bars: object, count: int) -> list:
    """Last count bars as a list; non-sequences become an empty list."""
    if bars is None:
        return []
    try:
        seq = list(bars)  # type: ignore[arg-type]
    except TypeError:
        return []
    if count <= 0:
        return []
    return seq[-count:]


def _num(value: object) -> float:
    number = float(value)  # type: ignore[arg-type]
    if not math.isfinite(number):
        raise ValueError(f"non-finite number {value!r}")
    return number


def _valid_atr(atr: object) -> float | None:
    try:
        value = float(atr)  # type: ignore[arg-type]
    except (TypeError, ValueError):
        return None
    if not math.isfinite(value) or value <= 0.0:
        return None
    return value


def _valid_side(side: object) -> bool:
    return side in ("buy", "sell")


def _interval_distance(low: float, high: float, other_low: float, other_high: float) -> float:
    if high < other_low:
        return other_low - high
    if low > other_high:
        return low - other_high
    return 0.0


def _zone_bounds(zone: object) -> tuple[float | None, float | None]:
    """(low, high) for a Zone-like object; (None, None) when there is no zone."""
    if zone is None:
        return (None, None)
    return (_num(getattr(zone, "low")), _num(getattr(zone, "high")))


def _gap_candidates(bars: list, side: str) -> list[tuple[float, float]]:
    """Three-bar fair-value gaps in the signal direction, as (low, high)."""
    candidates: list[tuple[float, float]] = []
    for index in range(2, len(bars)):
        two_back = bars[index - 2]
        current = bars[index]
        if side == "buy":
            low = _num(getattr(two_back, "h"))
            high = _num(getattr(current, "l"))
        else:
            low = _num(getattr(current, "h"))
            high = _num(getattr(two_back, "l"))
        if high - low > _EPS:
            candidates.append((low, high))
    return candidates


def _order_block_candidates(bars: list, side: str) -> list[tuple[float, float]]:
    """Opposite candle followed by an impulse in the signal direction."""
    candidates: list[tuple[float, float]] = []
    for index in range(len(bars) - 1):
        bar = bars[index]
        nxt = bars[index + 1]
        open_price = _num(getattr(bar, "o"))
        close = _num(getattr(bar, "c"))
        nxt_close = _num(getattr(nxt, "c"))
        low = _num(getattr(bar, "l"))
        high = _num(getattr(bar, "h"))
        if side == "buy":
            if close < open_price and nxt_close > high:
                candidates.append((low, high))
        else:
            if close > open_price and nxt_close < low:
                candidates.append((low, high))
    return candidates


# -- the five factors ----------------------------------------------------
def score_fvg_ob(
    bars: Sequence[Bar],
    *,
    side: str,
    zone: object,
    entry: float,
    atr: float,
) -> float:
    """Fair-value gap / order-block confluence at the zone (last 30 bars).

    +1 when a same-direction FVG or order block overlaps the zone (or contains
    the entry when zone is None) and is at least half an ATR tall; +0.5 when it
    is within half an ATR of the zone/entry; 0 otherwise.
    """
    try:
        if not _valid_side(side):
            return 0.0
        atr_value = _valid_atr(atr)
        if atr_value is None:
            return 0.0
        window = _tail(bars, _FVG_LOOKBACK)
        if len(window) < 3:
            return 0.0
        price = _num(entry)
        half_atr = 0.5 * atr_value
        zone_low, zone_high = _zone_bounds(zone)
        candidates = _gap_candidates(window, side) + _order_block_candidates(window, side)
        best = 0.0
        for low, high in candidates:
            size = high - low
            if size <= _EPS:
                continue
            if zone_low is None or zone_high is None:
                distance = 0.0
                if price < low:
                    distance = low - price
                elif price > high:
                    distance = price - high
            else:
                distance = _interval_distance(low, high, zone_low, zone_high)
            if distance <= _EPS and size + _EPS >= half_atr:
                return 1.0
            if distance <= half_atr + _EPS:
                best = 0.5
        return best
    except _MALFORMED:
        return 0.0


def score_maxlines(
    bars: Sequence[Bar],
    *,
    side: str,
    entry: float,
    atr: float,
) -> float:
    """Murrey-style 8/8 range over the last 64 bars (high/low).

    Buy looks at the -2/8 reversal line (low - 2 steps), sell at +2/8
    (high + 2 steps). +1 when price is at/through the line, +0.5 within a
    quarter ATR of it, 0 otherwise. A flat range scores 0.
    """
    try:
        if not _valid_side(side):
            return 0.0
        window = _tail(bars, _MAXLINES_LOOKBACK)
        if not window:
            return 0.0
        highs = [_num(getattr(bar, "h")) for bar in window]
        lows = [_num(getattr(bar, "l")) for bar in window]
        high = max(highs)
        low = min(lows)
        span = high - low
        if span <= _EPS:
            return 0.0
        step = span / 8.0
        price = _num(entry)
        atr_value = _valid_atr(atr)
        if side == "buy":
            line = low - 2.0 * step
            if price <= line + _EPS:
                return 1.0
            if atr_value is not None and price <= line + 0.25 * atr_value + _EPS:
                return 0.5
            return 0.0
        line = high + 2.0 * step
        if price >= line - _EPS:
            return 1.0
        if atr_value is not None and price >= line - 0.25 * atr_value - _EPS:
            return 0.5
        return 0.0
    except _MALFORMED:
        return 0.0


def score_ema50(
    bars: Sequence[Bar],
    *,
    side: str,
    entry: float,
    atr: float,
) -> float:
    """Price versus an aligned EMA50.

    +1 when price is on the signal side and the EMA slope over the last three
    bars points the same way; +0.5 when price is on the signal side but the
    slope is flat; 0 when price is on/against the EMA or the slope opposes.
    """
    try:
        if not _valid_side(side):
            return 0.0
        window = _tail(bars, _EMA_LOOKBACK)
        closes = [_num(getattr(bar, "c")) for bar in window]
        if len(closes) < 53:
            return 0.0
        series = indicators.ema_series(closes, 50)
        if len(series) < 4:
            return 0.0
        ema_now = series[-1]
        ema_prev = series[-4]
        if ema_now is None or ema_prev is None:
            return 0.0
        price = _num(entry)
        slope = ema_now - ema_prev
        if side == "buy":
            if price <= ema_now:
                return 0.0
            if abs(slope) <= _EPS:
                return 0.5
            return 1.0 if slope > 0.0 else 0.0
        if price >= ema_now:
            return 0.0
        if abs(slope) <= _EPS:
            return 0.5
        return 1.0 if slope < 0.0 else 0.0
    except _MALFORMED:
        return 0.0


def score_rsi(
    rsi: float | None,
    *,
    side: str,
    prev_rsi: float | None = None,
    bars: Sequence[Bar] | None = None,
) -> float:
    """RSI extreme / reversal / simple divergence score.

    +1 when RSI is at an extreme (<=30 buy, >=70 sell), is turning back out of
    one, or shows the simple documented divergence: with bars supplied, the last
    two price swing lows/highs are compared and the RSI leg must move the
    opposite way (lower price low + higher RSI low for buy, higher price high +
    lower RSI high for sell). +0.5 when RSI is merely on the signal side of 50,
    0 near 50 or on the wrong side.
    """
    try:
        if not _valid_side(side) or rsi is None:
            return 0.0
        value = _num(rsi)
        if bars is not None and _divergence_score(bars, side) >= 1.0:
            return 1.0
        previous = None
        if prev_rsi is not None:
            previous = _num(prev_rsi)
        if side == "buy":
            if value <= 30.0:
                return 1.0
            if previous is not None and previous <= 30.0 and value > previous:
                return 1.0
            if value > 50.0:
                return 0.5
            return 0.0
        if value >= 70.0:
            return 1.0
        if previous is not None and previous >= 70.0 and value < previous:
            return 1.0
        if value < 50.0:
            return 0.5
        return 0.0
    except _MALFORMED:
        return 0.0


def score_bollinger(
    bars: Sequence[Bar],
    *,
    side: str,
    entry: float,
    atr: float,
) -> float:
    """Bollinger(20, 2) band-return score.

    +1 when the last five bars touched the opposite band, the band is widening
    in the signal direction and price has returned to the correct half; +0.5
    when price is simply in the correct half of the band; 0 at the mid line or
    on the wrong side. Needs at least 22 closes to compare the band width.
    """
    try:
        if not _valid_side(side):
            return 0.0
        if _valid_atr(atr) is None:
            return 0.0
        window = _tail(bars, _EMA_LOOKBACK)
        closes = [_num(getattr(bar, "c")) for bar in window]
        if len(closes) < _BOLLINGER_PERIOD + 2:
            return 0.0
        lower, mid, upper = indicators.bollinger(
            closes, _BOLLINGER_PERIOD, _BOLLINGER_DEVIATIONS
        )
        lower_prev, _, upper_prev = indicators.bollinger(
            closes[:-1], _BOLLINGER_PERIOD, _BOLLINGER_DEVIATIONS
        )
        if lower is None or mid is None or upper is None:
            return 0.0
        if lower_prev is None or upper_prev is None:
            return 0.5 if _correct_half(side, _num(entry), mid) else 0.0
        width = upper - lower
        width_prev = upper_prev - lower_prev
        expanding = width > width_prev + _EPS
        price = _num(entry)
        if side == "buy":
            recent_lows = [_num(getattr(bar, "l")) for bar in window[-_BAND_TOUCH_BARS:]]
            touched = min(recent_lows) <= lower + _EPS
            widening_up = upper > upper_prev + _EPS
            if touched and expanding and widening_up and price > mid:
                return 1.0
        else:
            recent_highs = [_num(getattr(bar, "h")) for bar in window[-_BAND_TOUCH_BARS:]]
            touched = max(recent_highs) >= upper - _EPS
            widening_down = lower < lower_prev - _EPS
            if touched and expanding and widening_down and price < mid:
                return 1.0
        return 0.5 if _correct_half(side, price, mid) else 0.0
    except _MALFORMED:
        return 0.0


def _correct_half(side: str, price: float, mid: float) -> bool:
    return price > mid if side == "buy" else price < mid


def _swing_indices(bars: list, *, low: bool) -> list[int]:
    """Indices of local swing lows/highs inside the window (simple, documented)."""
    out: list[int] = []
    for index in range(1, len(bars) - 1):
        previous = bars[index - 1]
        current = bars[index]
        following = bars[index + 1]
        if low:
            value = _num(getattr(current, "l"))
            if value <= _num(getattr(previous, "l")) + _EPS and value <= _num(
                getattr(following, "l")
            ) + _EPS:
                out.append(index)
        else:
            value = _num(getattr(current, "h"))
            if value >= _num(getattr(previous, "h")) - _EPS and value >= _num(
                getattr(following, "h")
            ) - _EPS:
                out.append(index)
    return out


def _divergence_score(bars: object, side: str) -> float:
    """Simple two-swing divergence: price leg and RSI leg move opposite ways."""
    window = _tail(bars, 40)
    if len(window) < 17:
        return 0.0
    closes = [_num(getattr(bar, "c")) for bar in window]
    rsi_values = [indicators.rsi(closes[: index + 1], 14) for index in range(len(closes))]
    if side == "buy":
        points = _swing_indices(window, low=True)
        if len(points) < 2:
            return 0.0
        first, second = points[-2], points[-1]
        first_rsi = rsi_values[first]
        second_rsi = rsi_values[second]
        if first_rsi is None or second_rsi is None:
            return 0.0
        first_price = _num(getattr(window[first], "l"))
        second_price = _num(getattr(window[second], "l"))
        if second_price < first_price - _EPS and second_rsi > first_rsi + _EPS:
            return 1.0
        return 0.0
    points = _swing_indices(window, low=False)
    if len(points) < 2:
        return 0.0
    first, second = points[-2], points[-1]
    first_rsi = rsi_values[first]
    second_rsi = rsi_values[second]
    if first_rsi is None or second_rsi is None:
        return 0.0
    first_price = _num(getattr(window[first], "h"))
    second_price = _num(getattr(window[second], "h"))
    if second_price > first_price + _EPS and second_rsi < first_rsi - _EPS:
        return 1.0
    return 0.0


def _previous_rsi(bars: object) -> float | None:
    """RSI of all but the last M15 bar, so score_rsi can see a turn."""
    try:
        window = _tail(bars, _EMA_LOOKBACK)
        closes = [_num(getattr(bar, "c")) for bar in window]
        if len(closes) < 16:
            return None
        return indicators.rsi(closes[:-1], 14)
    except _MALFORMED:
        return None


# -- layer-0 / layer-3 contract helpers ---------------------------------
def zone_confirms_layer3(
    *,
    zone_score: float,
    distance: float,
    atr: float,
    min_score: float = 50.0,
    max_distance_atr: float = 2.0,
) -> bool:
    """ADR-035 sr_zone vote condition: score >= min_score AND distance <= N*ATR.

    Applied to both strategy paths (numeric via best_zone and zones via its own
    tagged zone), so a far-away zone can never cast the layer-3 vote. Invalid
    inputs (zero/NaN ATR, negative/infinite distance) return False (no vote).
    """
    try:
        score = _num(zone_score)
        gap = _num(distance)
        atr_value = _valid_atr(atr)
        if atr_value is None or gap < 0.0:
            return False
        limit = _num(max_distance_atr) * atr_value
        return score >= _num(min_score) - _EPS and gap <= limit + _EPS
    except _MALFORMED:
        return False


def ema200_h1_vote(entry: float, closes: Sequence[float], *, side: str) -> int:
    """ADR-033 EMA200-H1 layer-3 vote: +1 aligned, -1 against, 0 neutral.

    Requires a real 200-bar history and a defined 3-bar EMA slope. Missing
    history or a missing slope is neutral (0), never an accidental vote.
    """
    try:
        if not _valid_side(side):
            return 0
        # Do NOT clamp to _EMA_LOOKBACK: an EMA200 needs 200 samples *plus* a
        # defined 3-bar slope, so trailing-window truncation would kill the vote.
        values = [_num(value) for value in closes]
        if len(values) < _EMA200_PERIOD + 3:
            return 0
        series = indicators.ema_series(values, 200)
        if len(series) < 4:
            return 0
        ema_now = series[-1]
        ema_prev = series[-4]
        if ema_now is None or ema_prev is None:
            return 0
        price = _num(entry)
        slope = ema_now - ema_prev
        if side == "buy":
            if price > ema_now + _EPS and slope > _EPS:
                return 1
            if price < ema_now - _EPS and slope < -_EPS:
                return -1
            return 0
        if price < ema_now - _EPS and slope < -_EPS:
            return 1
        if price > ema_now + _EPS and slope > _EPS:
            return -1
        return 0
    except _MALFORMED:
        return 0


# -- aggregate / layer 3 -------------------------------------------------
def evaluate_confirmations(
    bars_m15: Sequence[Bar],
    *,
    side: str,
    zone: object,
    entry: float,
    atr: float,
    rsi_m15: float | None,
    bars_h1: Sequence[Bar] | None = None,
) -> ConfirmationReport:
    """Score all five factors and sum them into a 0..5 confirmation count.

    bars_h1 is accepted for forward compatibility with the engine call site and
    is currently unused: every factor is defined on M15 bars. Passing empty or
    malformed bars yields an all-zero report instead of raising.
    """
    factors: dict[str, float] = {
        "fvg_ob": score_fvg_ob(bars_m15, side=side, zone=zone, entry=entry, atr=atr),
        "maxlines": score_maxlines(bars_m15, side=side, entry=entry, atr=atr),
        "ema50": score_ema50(bars_m15, side=side, entry=entry, atr=atr),
        "rsi": score_rsi(
            rsi_m15,
            side=side,
            prev_rsi=_previous_rsi(bars_m15),
            bars=bars_m15,
        ),
        "bollinger": score_bollinger(bars_m15, side=side, entry=entry, atr=atr),
    }
    return ConfirmationReport(
        total=sum(factors.values()),
        factors=factors,
        names=FACTOR_NAMES,
    )


def layer3_score(votes: Mapping[str, int]) -> Layer3Report:
    """Combine independent layer-3 votes into a capped score and a tier delta.

    Each vote is clamped to [-1, 1]; the sum is scaled by LAYER3_WEIGHT and
    clamped to +/-LAYER3_CAP. The returned votes mapping is the clamped copy,
    so the journal can record exactly what was counted.
    """
    cleaned: dict[str, int] = {}
    items: object = getattr(votes, "items", None)
    if callable(items):
        try:
            pairs = list(items())  # type: ignore[operator]
        except TypeError:
            pairs = []
        for name, raw in pairs:
            try:
                value = int(raw)  # type: ignore[arg-type]
            except (TypeError, ValueError):
                value = 0
            cleaned[str(name)] = max(-1, min(1, value))
    total = sum(cleaned.values()) * LAYER3_WEIGHT
    score = max(-LAYER3_CAP, min(LAYER3_CAP, total))
    if score >= LAYER3_DELTA_THRESHOLD:
        delta = 1
    elif score <= -LAYER3_DELTA_THRESHOLD:
        delta = -1
    else:
        delta = 0
    return Layer3Report(score=score, delta=delta, votes=cleaned)
