"""Stable identifiers shared by risk and execution."""

from __future__ import annotations

import uuid
import zlib

# Every order GoldBot sends carries a magic derived from this base. Ownership
# checks (never close somebody else's manual position) compare against it.
GOLDBOT_MAGIC_BASE = 7300
MAGIC_BUCKETS = 9_000
# Bucket 0 is reserved: a magic must never equal the bare ownership base.
MAGIC_USABLE_BUCKETS = MAGIC_BUCKETS - 1
# Journal tag for the deterministic slot-magic scheme (CONF-02). A live DB
# written before this scheme can be identified from the ORDER_APPROVED events.
MAGIC_SCHEME = "crc32-slot-v1"


def magic_for_slot(slot: str, base: int = GOLDBOT_MAGIC_BASE) -> int:
    """Stable slot magic: base * 10_000 + crc32 bucket in 1..8_999.

    The identity must survive a process restart, so it must never come from
    Python's per-process-salted hash(): restart reconciliation and ownership
    (owns_position_magic) depend on the same number being produced again. This
    function is the single source of truth; app.signal_pipeline.stable_magic
    and RiskEngine's order sealing both delegate here. Every value stays inside
    the documented 1..8_999 ownership suffix (never bucket 0).
    """
    canonical = str(slot).strip()
    bucket = zlib.crc32(canonical.encode("utf-8")) % MAGIC_USABLE_BUCKETS + 1
    return (int(base) % 2_000) * 10_000 + bucket


def owns_position_magic(magic: int, base: int = GOLDBOT_MAGIC_BASE) -> bool:
    """True only for magics this bot can have produced.

    Reconciliation must never auto-close an orphan it does not own: that could
    be the operator's manual trade. Unknown magics are warned about, not closed.
    """
    low = (int(base) % 2_000) * 10_000
    return low <= int(magic) < low + MAGIC_BUCKETS


def client_ref(intent_id: str) -> str:
    """<= 31 chars because MT5 truncates the comment field."""
    suffix = intent_id.replace("-", "")[-18:]
    return f"gb{suffix}"


def new_intent_id(slot: str, seq: int) -> str:
    return f"{slot[:8]}-{seq:06d}-{uuid.uuid4().hex[:6]}"
