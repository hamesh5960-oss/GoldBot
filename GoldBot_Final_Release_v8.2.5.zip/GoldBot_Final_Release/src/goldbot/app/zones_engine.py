"""Zone engine: one deterministic zone snapshot shared by gates and confluence.

Three sources, with explicit precedence:
* operator zones from the panel (manual);
* daily levels of the last completed broker day (daily);
* H1 swing zones (auto).

The daily snapshot is rebuilt exactly once per broker day, at the first M15 bar
of the new day, and then kept immutable for the rest of that day.
"""

from __future__ import annotations

from datetime import datetime, timedelta
from typing import Any, Sequence

from ..domain.model import Bar
from ..strategy_api import indicators
from ..strategy_api.levels import (
    DailyLevels,
    broker_daily_bars,
    broker_day,
    daily_levels,
    daily_zones,
)
from ..strategy_api.zones import (
    Zone,
    detect_zones,
    merge_all,
    score_manual_zones,
)


class ZoneEngine:
    def __init__(
        self,
        *,
        zones_fn: Any = None,
        history_fn: Any = None,
        broker_offset: timedelta = timedelta(0),
        enable_daily: bool = True,
        h1_window: int = 200,
        span: int = 3,
        cluster_atr: float = 0.3,
        half_width_atr: float = 0.15,
        min_touches: int = 2,
        max_zones: int = 8,
    ) -> None:
        self._zones_fn = zones_fn
        self._history_fn = history_fn
        self._offset = broker_offset
        self._enable_daily = enable_daily
        self.h1_window = h1_window
        self.span = span
        self.cluster_atr = cluster_atr
        self.half_width_atr = half_width_atr
        self.min_touches = min_touches
        self.max_zones = max_zones
        self._cache_key: tuple[Any, ...] | None = None
        self._cache: tuple[Zone, ...] = ()
        self._daily_day = None
        self._daily: tuple[Zone, ...] = ()
        self.levels: DailyLevels | None = None
        self._daily_event: dict[str, Any] | None = None

    def _refresh_daily(self, bars_m15: Sequence[Bar], now: datetime) -> None:
        day = broker_day(now, self._offset)
        if day == self._daily_day:
            return
        self._daily_day = day
        source = self._history_fn() if self._history_fn is not None else bars_m15
        daily_bars = broker_daily_bars(source, self._offset)
        levels = daily_levels(daily_bars, now=now, offset=self._offset)
        self.levels = levels
        if levels is None:
            self._daily = ()
            self._daily_event = None
            return
        price = bars_m15[-1].c if bars_m15 else levels.pdc
        self._daily = daily_zones(levels, price=price)
        self._daily_event = {
            "date": day.isoformat(),
            "previous_day": levels.previous_day.isoformat(),
            "pdh": round(levels.pdh, 2),
            "pdl": round(levels.pdl, 2),
            "pdo": round(levels.pdo, 2),
            "pdc": round(levels.pdc, 2),
            "pivot": round(levels.pivot, 2),
            "r1": round(levels.r1, 2),
            "s1": round(levels.s1, 2),
            "atr": round(levels.atr, 2),
            "zones": [zone.zone_id for zone in self._daily],
        }

    def take_daily_event(self) -> dict[str, Any] | None:
        event, self._daily_event = self._daily_event, None
        return event

    def snapshot(self, bars_m15: Sequence[Bar], *, now: datetime) -> tuple[Zone, ...]:
        if not bars_m15:
            return ()
        if self._enable_daily:
            self._refresh_daily(bars_m15, now)

        key = (len(bars_m15), bars_m15[-1].open_time, self._daily_day)
        if key == self._cache_key:
            return self._cache

        h1 = indicators.resample(bars_m15, "H1")[-self.h1_window :]
        atr_h1 = indicators.atr(h1, 14)
        price = bars_m15[-1].c
        closes = [bar.c for bar in h1]
        ema = indicators.ema(closes, min(200, max(20, len(closes) // 2))) if closes else None
        auto = detect_zones(
            h1,
            atr=atr_h1,
            price=price,
            ema=ema,
            span=self.span,
            cluster_atr=self.cluster_atr,
            half_width_atr=self.half_width_atr,
            min_touches=self.min_touches,
            max_zones=self.max_zones,
        )
        manual: Sequence[Zone] = ()
        if self._zones_fn is not None:
            try:
                manual = score_manual_zones(self._zones_fn(now), atr=atr_h1, ema=ema)
            except Exception:  # noqa: BLE001 - a broken zone file must not stop trading
                manual = ()
        self._cache_key = key
        self._cache = merge_all(manual, self._daily, auto)
        return self._cache
