"""Deterministic OHLC aggregation from ticks. A bar is closed exactly once.

Two tape-edge behaviours are explicit here (Phase 7, D01/D02):

* flush() closes every still-open partial bar exactly once, so a caller that
  knows the feed ended (or the replay feed's synthetic closing tick that lands
  in the next bucket) never loses the final bar.
* Gaps: when the next tick lands more than one bucket later (weekend, broker
  break, disconnect), the missing buckets are recorded as BarGap entries in
  order. They are deliberately NOT back-filled with synthetic flat bars: bar
  history stays exactly the observed data, so strategy inputs do not change;
  diagnostics/monitoring can surface the gaps explicitly via gaps/take_gaps.
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Sequence

from ..domain.model import Bar, Symbol, TF_SECONDS, Tick, Timeframe


@dataclass(frozen=True, slots=True)
class BarGap:
    """Whole buckets with no tick between two closed bars of one timeframe."""

    timeframe: Timeframe
    missing_from: datetime
    missing_until: datetime
    missing_bars: int


@dataclass
class _Partial:
    start: datetime
    o: float
    h: float
    l: float
    c: float
    volume: int
    spread_sum: float
    n: int


class BarBuilder:
    def __init__(self, symbol: Symbol, timeframes: Sequence[Timeframe], *, history: int = 600) -> None:
        self.symbol = symbol
        self.timeframes = tuple(timeframes)
        self._history: dict[str, deque[Bar]] = {tf: deque(maxlen=history) for tf in self.timeframes}
        self._partial: dict[str, _Partial] = {}
        self._gaps: list[BarGap] = []
        self.last_tick: Tick | None = None

    def seed(self, bars: Sequence[Bar]) -> None:
        """Load historical bars (warmup) without emitting them as events."""
        for bar in bars:
            if bar.timeframe in self._history:
                self._history[bar.timeframe].append(bar)

    def bars(self, timeframe: Timeframe, count: int) -> list[Bar]:
        series = self._history.get(timeframe)
        if not series:
            return []
        return list(series)[-count:]

    def last_bar(self, timeframe: Timeframe) -> Bar | None:
        series = self._history.get(timeframe)
        return series[-1] if series else None

    @property
    def gaps(self) -> tuple[BarGap, ...]:
        """Every bucket gap discovered so far, oldest first."""
        return tuple(self._gaps)

    def take_gaps(self) -> tuple[BarGap, ...]:
        """Return and clear the pending gap records (for journaling/monitoring)."""
        gaps = tuple(self._gaps)
        self._gaps.clear()
        return gaps

    def on_tick(self, tick: Tick) -> list[Bar]:
        self.last_tick = tick
        closed: list[Bar] = []
        mid = tick.mid
        for tf in self.timeframes:
            seconds = TF_SECONDS[tf]
            bucket = self._bucket(tick.ts_event.wall, tf)
            partial = self._partial.get(tf)
            if partial is None:
                self._partial[tf] = _Partial(bucket, mid, mid, mid, mid, tick.volume, tick.spread, 1)
                continue
            if bucket > partial.start:
                closed.append(self._close_partial(tf, partial))
                skipped = int((bucket - partial.start).total_seconds() // seconds)
                if skipped > 1:
                    # Whole empty buckets: record them explicitly, never invent bars.
                    self._gaps.append(
                        BarGap(
                            timeframe=tf,
                            missing_from=partial.start + timedelta(seconds=seconds),
                            missing_until=bucket,
                            missing_bars=skipped - 1,
                        )
                    )
                self._partial[tf] = _Partial(bucket, mid, mid, mid, mid, tick.volume, tick.spread, 1)
            else:
                partial.h = max(partial.h, mid)
                partial.l = min(partial.l, mid)
                partial.c = mid
                partial.volume += tick.volume
                partial.spread_sum += tick.spread
                partial.n += 1
        return closed

    def flush(self) -> list[Bar]:
        """Close every still-open partial bar at end-of-tape; idempotent.

        The engine cannot call this from inside its own run loop in this phase,
        so the replay feed's synthetic closing tick lands in the next bucket and
        triggers the same close through on_tick. Direct hosts/tests use flush().
        """
        closed: list[Bar] = []
        for tf in self.timeframes:
            partial = self._partial.pop(tf, None)
            if partial is not None:
                closed.append(self._close_partial(tf, partial))
        return closed

    def _close_partial(self, timeframe: Timeframe, partial: _Partial) -> Bar:
        bar = Bar(
            symbol=self.symbol,
            timeframe=timeframe,
            open_time=partial.start,
            o=partial.o,
            h=partial.h,
            l=partial.l,
            c=partial.c,
            tick_volume=partial.volume,
            spread_avg=partial.spread_sum / max(1, partial.n),
            is_closed=True,
        )
        self._history[timeframe].append(bar)
        return bar

    @staticmethod
    def _bucket(ts: datetime, tf: Timeframe) -> datetime:
        seconds = TF_SECONDS[tf]
        epoch = int(ts.timestamp())
        start = epoch - (epoch % seconds)
        return datetime.fromtimestamp(start, tz=timezone.utc)
