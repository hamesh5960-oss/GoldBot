"""Strategy host: lifecycle, event routing and context construction.

The host knows nothing about orders. It produces signals and hands them on.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping, Sequence

from ..domain.events import Ev, Event
from ..domain.model import Bar, Fill, Symbol, SymbolInfo, Tick, Timeframe, Ts
from ..log import get_logger
from ..strategy_api import BaseStrategy, StrategyContext, StrategyPosition
from ..strategy_api.context import AccountView
from .bar_builder import BarBuilder

log = get_logger("strategy_host")


@dataclass
class Binding:
    slot: str
    strategy: BaseStrategy
    symbol: Symbol
    timeframes: tuple[Timeframe, ...]
    risk_multiplier: float = 1.0
    confirm_only: bool = False
    state: str = "CREATED"
    signals: int = 0
    errors: int = 0

    @property
    def strategy_id(self) -> str:
        return self.strategy.id


class StrategyContextImpl:
    """Read-only view. There is deliberately no submit/modify method here."""

    __slots__ = (
        "_binding",
        "_builder",
        "_positions_fn",
        "_account_fn",
        "_now_fn",
        "_info",
        "_tick_fn",
        "_zones_fn",
    )

    def __init__(
        self,
        binding: Binding,
        builder: BarBuilder,
        info: SymbolInfo,
        positions_fn: Any,
        account_fn: Any,
        now_fn: Any,
        tick_fn: Any,
        zones_fn: Any = None,
    ) -> None:
        self._binding = binding
        self._builder = builder
        self._info = info
        self._positions_fn = positions_fn
        self._account_fn = account_fn
        self._now_fn = now_fn
        self._tick_fn = tick_fn
        self._zones_fn = zones_fn

    # -- identity --------------------------------------------------------
    @property
    def slot(self) -> str:
        return self._binding.slot

    @property
    def symbol(self) -> str:
        return str(self._binding.symbol)

    @property
    def symbol_info(self) -> SymbolInfo:
        return self._info

    @property
    def params(self) -> Any:
        return self._binding.strategy.params

    @property
    def risk_multiplier(self) -> float:
        return self._binding.risk_multiplier

    # -- data ------------------------------------------------------------
    def now(self) -> Any:
        return self._now_fn().wall

    def bars(self, timeframe: Timeframe, count: int) -> Sequence[Bar]:
        return self._builder.bars(timeframe, count)

    def last_tick(self) -> Tick | None:
        return self._tick_fn()

    def positions(self) -> Sequence[StrategyPosition]:
        return [p for p in self._positions_fn() if p.slot == self._binding.slot]

    def account(self) -> AccountView:
        return self._account_fn()

    def atr(self, timeframe: Timeframe, period: int) -> float | None:
        from ..strategy_api import indicators

        return indicators.atr(self.bars(timeframe, period + 2), period)

    def zones(self) -> Sequence[Any]:
        if self._zones_fn is None:
            return ()
        return self._zones_fn(self._now_fn().wall)

    def log(self, message: str, **fields: Any) -> None:
        log.info(message, extra={"fields": {"slot": self.slot, **fields}})

    def tags(self) -> Mapping[str, Any]:
        return {"slot": self.slot, "strategy": self._binding.strategy_id}


class StrategyHost:
    def __init__(self, journal: Any, clock: Any = None, zones: Any = None) -> None:
        self._journal = journal
        self._clock = clock
        self._zones = zones
        self._buildings: dict[str, Binding] = {}
        self._contexts: dict[str, StrategyContextImpl] = {}

    def register(
        self,
        *,
        slot: str,
        strategy: BaseStrategy,
        symbol: Symbol,
        info: SymbolInfo,
        builder: BarBuilder,
        positions_fn: Any,
        account_fn: Any,
        now_fn: Any,
        tick_fn: Any,
        risk_multiplier: float,
        timeframes: Sequence[Timeframe] | None = None,
        confirm_only: bool = False,
    ) -> None:
        tfs = tuple(timeframes or strategy.timeframes)
        binding = Binding(
            slot=slot,
            strategy=strategy,
            symbol=symbol,
            timeframes=tfs,
            risk_multiplier=max(0.0, min(1.0, risk_multiplier)),
            confirm_only=confirm_only,
        )
        self._buildings[slot] = binding
        if self._zones is None:
            zones_fn = None
        elif callable(self._zones):
            zones_fn = self._zones
        else:
            zones_fn = lambda moment: self._zones.for_datetime(moment)  # noqa: E731
        self._contexts[slot] = StrategyContextImpl(
            binding, builder, info, positions_fn, account_fn, now_fn, tick_fn, zones_fn
        )
        self._emit(Ev.STRATEGY_STARTED, {"slot": slot, "strategy": strategy.id, "version": strategy.version})

    @property
    def bindings(self) -> Mapping[str, Binding]:
        return self._buildings

    def warm_up(self) -> None:
        for slot, binding in self._buildings.items():
            ctx = self._contexts[slot]
            try:
                binding.strategy.on_init(ctx)
                binding.strategy.on_warmup(ctx)
                binding.state = "READY"
                self._emit(
                    Ev.STRATEGY_WARMED,
                    {"slot": slot, "bars_available": len(ctx.bars(binding.timeframes[0], 10_000))},
                )
            except Exception as exc:  # noqa: BLE001 - isolation is the point
                binding.state = "FAILED"
                binding.errors += 1
                log.exception("strategy warmup failed", extra={"fields": {"slot": slot}})
                self._emit(Ev.STRATEGY_FAILED, {"slot": slot, "error": repr(exc)})

    def on_bar(self, bar: Bar) -> list[Any]:
        out: list[Any] = []
        for slot, binding in self._buildings.items():
            if binding.state != "READY" or bar.timeframe not in binding.timeframes:
                continue
            if bar.symbol != binding.symbol:
                continue
            try:
                signals = binding.strategy.on_bar(self._contexts[slot], bar) or ()
            except Exception as exc:  # noqa: BLE001
                binding.state = "FAILED"
                binding.errors += 1
                self._emit(Ev.STRATEGY_FAILED, {"slot": slot, "error": repr(exc), "where": "on_bar"})
                continue
            for signal in signals:
                binding.signals += 1
                out.append(signal)
                self._emit(
                    Ev.SIGNAL_RAISED,
                    {
                        "slot": slot,
                        "kind": getattr(signal, "kind", "?"),
                        "side": getattr(signal, "side", None),
                        "rationale": getattr(signal, "rationale", ""),
                        "tags": dict(getattr(signal, "tags", {}) or {}),
                    },
                )
        return out

    def on_tick(self, tick: Tick) -> list[Any]:
        out: list[Any] = []
        for slot, binding in self._buildings.items():
            if binding.state != "READY":
                continue
            try:
                signals = binding.strategy.on_tick(self._contexts[slot], tick) or ()
            except Exception:  # noqa: BLE001
                binding.state = "FAILED"
                binding.errors += 1
                self._emit(Ev.STRATEGY_FAILED, {"slot": slot, "where": "on_tick"})
                continue
            out.extend(signals)
        return out

    def on_fill(self, fill: Fill) -> None:
        for slot, binding in self._buildings.items():
            if binding.state in ("READY", "FAILED"):
                try:
                    binding.strategy.on_fill(self._contexts[slot], fill)
                except Exception:  # noqa: BLE001
                    log.exception("on_fill failed", extra={"fields": {"slot": slot}})

    def on_trade_closed(self, slot: str, trade: Any) -> None:
        binding = self._buildings.get(slot)
        if binding is None or binding.state not in ("READY", "PAUSED", "FAILED"):
            return
        try:
            binding.strategy.on_close(self._contexts[slot], trade)
        except Exception:  # noqa: BLE001 - a plugin bug must not stop the loop
            log.exception("on_close failed", extra={"fields": {"slot": slot}})

    def stop(self, reason: str) -> None:
        for slot, binding in self._buildings.items():
            try:
                binding.strategy.on_stop(self._contexts[slot], reason)
            except Exception:  # noqa: BLE001
                pass
            binding.state = "STOPPED"

    def pause_all(self) -> None:
        for binding in self._buildings.values():
            if binding.state == "READY":
                binding.state = "PAUSED"

    def resume_all(self) -> None:
        for binding in self._buildings.values():
            if binding.state == "PAUSED":
                binding.state = "READY"

    def _emit(self, event_type: str, payload: Mapping[str, Any]) -> None:
        if self._journal is None:
            return
        ts = self._clock.now() if self._clock is not None else Ts.epoch()
        self._journal.append(Event(type=event_type, payload=dict(payload), ts=ts, actor="strategy"))

