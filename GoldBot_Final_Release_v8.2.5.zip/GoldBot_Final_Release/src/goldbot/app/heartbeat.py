"""Heartbeat file: the process writes it, an external watchdog checks it.

The file is the contract between the trading process and everything outside it
(Task Scheduler, cron, an operator script). It must be written atomically so a
watchdog never reads a half-written JSON document, and the age of its timestamp
must be measured against the same clock the engine already trusts.
"""

from __future__ import annotations

import json
import os
from datetime import datetime
from pathlib import Path
from typing import Any, Mapping

from ..domain.events import Event
from ..domain.model import Ts, utc
from ..log import get_logger
from ..ports.clock import IClock
from ..ports.journal import IEventStore

log = get_logger("heartbeat")

# Stable event name for the journal; domain/events.py has no constant for a
# successful beat yet (it only catalogues HeartbeatMissed).
EV_HEARTBEAT = "Heartbeat"


def heartbeat_path_for(journal_path: str | Path) -> Path:
    """Dead-process marker path for one run journal.

    Derived from the journal file itself: a demo/backtest run and the live
    session have different journals, so neither can overwrite the other's
    heartbeat (an external watchdog would otherwise see a fresh beat that no
    trading process produced).
    """
    return Path(str(journal_path) + ".heartbeat.json")


def _wall(value: Ts | datetime) -> datetime:
    if isinstance(value, Ts):
        return value.wall
    return utc(value)


class Heartbeat:
    """Write the ts/pid/payload record atomically and answer "am I due?"."""

    def __init__(
        self,
        path: str | Path,
        clock: IClock,
        interval_seconds: float = 300.0,
        max_age_seconds: float = 900.0,
        *,
        journal: IEventStore | None = None,
    ) -> None:
        self._path = Path(path)
        self._clock = clock
        self._interval = max(0.0, float(interval_seconds))
        self._max_age = max(0.0, float(max_age_seconds))
        self._journal = journal
        self._last_beat: datetime | None = None

    @property
    def path(self) -> Path:
        return self._path

    @property
    def max_age_seconds(self) -> float:
        return self._max_age

    def should_beat(self, now: Ts | datetime | None = None) -> bool:
        """True when the throttle interval elapsed (or nothing was written yet)."""
        moment = _wall(now) if now is not None else self._clock.now().wall
        if self._last_beat is None:
            return True
        return (moment - self._last_beat).total_seconds() >= self._interval

    def beat(self, payload: Mapping[str, Any] | None = None) -> dict[str, Any]:
        """Write the heartbeat and return the exact record that hit the disk."""
        now = self._clock.now()
        record: dict[str, Any] = {
            "ts": now.wall.isoformat(),
            "pid": os.getpid(),
            "payload": dict(payload or {}),
        }
        self._write(record)
        self._last_beat = now.wall
        if self._journal is not None:
            event = Event(
                type=EV_HEARTBEAT,
                payload={"pid": record["pid"], "payload": record["payload"]},
                ts=now,
            )
            try:
                self._journal.append(event)
            except Exception as exc:  # noqa: BLE001 - monitoring must not kill the process
                log.warning("heartbeat journal append failed", extra={"fields": {"error": str(exc)}})
        return record

    def is_stale_now(self, now: Ts | datetime | None = None) -> tuple[bool, float | None, dict[str, Any]]:
        """Staleness of *this* heartbeat file against the current clock."""
        moment: Ts | datetime = now if now is not None else self._clock.now()
        return self.is_stale(self._path, moment, self._max_age)

    @staticmethod
    def is_stale(
        path: str | Path,
        now: Ts | datetime,
        max_age_seconds: float = 900.0,
    ) -> tuple[bool, float | None, dict[str, Any]]:
        """Return (stale, age_seconds, data); missing or corrupt files are stale.

        age_seconds is None when the file could not be read or carried no valid
        ISO timestamp, so callers can still distinguish "old" from "gone".
        """
        try:
            raw = Path(path).read_text(encoding="utf-8")
        except OSError:
            return True, None, {}
        try:
            data: Any = json.loads(raw)
        except ValueError:
            return True, None, {}
        if not isinstance(data, dict):
            return True, None, {}
        stamp = data.get("ts")
        if not isinstance(stamp, str):
            return True, None, {}
        try:
            last = utc(datetime.fromisoformat(stamp))
        except ValueError:
            return True, None, {}
        age = (_wall(now) - last).total_seconds()
        return age > float(max_age_seconds), age, data

    def _write(self, record: Mapping[str, Any]) -> None:
        """tmp file + os.replace: a reader sees the old or the new file, never half."""
        self._path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self._path.with_name(f".{self._path.name}.{os.getpid()}.tmp")
        try:
            with open(tmp, "w", encoding="utf-8") as handle:
                json.dump(record, handle, ensure_ascii=False)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(tmp, self._path)
        finally:
            try:
                tmp.unlink()
            except FileNotFoundError:
                pass
