"""Decision matrix: confirmation count -> tier, with hard floors.

The tier is set by the number of independent confirmations. Five scorers vote;
layer 3 is the last vote and may move the result one step:

    confirmation count   [0,1)  [1,2)  [2,3)  [3,4)  [4,6]
    base tier             D      C      B      A      A+

Two rules are absolute:
  * A confirmation count of zero is D. Layer 3 can never lift it (A1 floor).
  * Layer 3 can never push the tier below C or above A+.

Hard gates replace the old composite and the per-tier R:R ladder:
  * An S/R zone below min_zone (when a zone is supplied) is D: zone_filter.
  * Net R:R below rr_absolute_floor (when supplied) is noise: rr_absolute_floor.

There is no composite score, no continuous R:R penalty and no per-tier zone
floor anymore. tier_base_from_confirmations, layer3_delta and adjust_tier are
the whole ladder. SizeLevel/SIZE_FACTOR stay because the gates own the size
ladder.
"""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from enum import Enum


class Tier(str, Enum):
    D = "D"
    C = "C"
    B = "B"
    A = "A"
    A_PLUS = "A+"
    NOISE = "noise"


# Best to worst. Tier.D is the confirmation hard floor; Tier.NOISE is a reject.
TIER_ORDER: tuple[Tier, ...] = (
    Tier.A_PLUS,
    Tier.A,
    Tier.B,
    Tier.C,
    Tier.D,
    Tier.NOISE,
)

# ADR-036: A+ is back to 1.0. D and NOISE are never traded.
TIER_RISK_PCT: dict[Tier, float] = {
    Tier.A_PLUS: 1.0,
    Tier.A: 0.75,
    Tier.B: 0.50,
    Tier.C: 0.25,
    Tier.D: 0.0,
    Tier.NOISE: 0.0,
}


class SizeLevel(str, Enum):
    FULL = "FULL"
    HALF = "HALF"
    QUARTER = "QUARTER"
    # The last rung before a hard reject: one broker minimum lot.
    SMALLEST = "SMALLEST"
    NONE = "NONE"


SIZE_FACTOR: dict[SizeLevel, float] = {
    SizeLevel.FULL: 1.0,
    SizeLevel.HALF: 0.5,
    SizeLevel.QUARTER: 0.25,
    SizeLevel.SMALLEST: 0.10,
    SizeLevel.NONE: 0.0,
}

_SIZE_ORDER: tuple[SizeLevel, ...] = (
    SizeLevel.FULL,
    SizeLevel.HALF,
    SizeLevel.QUARTER,
    SizeLevel.SMALLEST,
    SizeLevel.NONE,
)


def clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def tier_base_from_confirmations(count: float) -> Tier:
    """Base tier from the confirmation count (0..6, clamped).

    [0,1) -> D, [1,2) -> C, [2,3) -> B, [3,4) -> A, [4,6] -> A+.
    Negative counts clamp to the D floor; counts above 6 clamp to A+.
    """
    if count != count:  # NaN: no usable confirmations
        return Tier.D
    if count < 0.0:
        count = 0.0
    elif count > 6.0:
        count = 6.0
    if count < 1.0:
        return Tier.D
    if count < 2.0:
        return Tier.C
    if count < 3.0:
        return Tier.B
    if count < 4.0:
        return Tier.A
    return Tier.A_PLUS


def layer3_delta(score: float) -> int:
    """Layer-3 vote: +1 at or above 0.6, -1 at or below -0.6, else 0."""
    if score >= 0.6:
        return 1
    if score <= -0.6:
        return -1
    return 0


def adjust_tier(base: Tier, delta: int) -> Tier:
    """Move a base tier by the layer-3 vote, inside the hard floors.

    D is a hard floor for zero confirmations (layer 3 has no effect there).
    Otherwise the result is clamped to the C floor and the A+ cap, so layer 3
    can never create a D or a NOISE tier.
    """
    if base is Tier.D:
        return Tier.D
    if base is Tier.NOISE:
        return Tier.NOISE
    worst = TIER_ORDER.index(Tier.C)
    index = TIER_ORDER.index(base) - int(delta)
    return TIER_ORDER[max(0, min(worst, index))]


def downgrade_tier(tier: Tier) -> Tier:
    """One step worse on TIER_ORDER (legacy helper; decide() does not use it)."""
    index = TIER_ORDER.index(tier)
    return TIER_ORDER[min(index + 1, len(TIER_ORDER) - 1)]


def downgrade_size(level: SizeLevel) -> SizeLevel:
    index = _SIZE_ORDER.index(level)
    return _SIZE_ORDER[min(index + 1, len(_SIZE_ORDER) - 1)]


@dataclass(frozen=True, slots=True)
class TierDecision:
    tier: Tier
    tier_base: Tier
    confirmation_count: float
    confirmation_set: tuple[str, ...]
    layer3_score: float
    layer3_delta: int
    d_hard_floor: bool
    risk_base_pct: float
    reasons: tuple[str, ...] = ()

    @property
    def rejected(self) -> bool:
        return self.tier is Tier.NOISE

    @property
    def hard_floor(self) -> bool:
        return self.tier is Tier.D

    @property
    def upgraded(self) -> bool:
        return TIER_ORDER.index(self.tier) < TIER_ORDER.index(self.tier_base)

    @property
    def downgraded(self) -> bool:
        return TIER_ORDER.index(self.tier) > TIER_ORDER.index(self.tier_base)

    def as_dict(self) -> dict[str, object]:
        return {
            "tier": self.tier.value,
            "tier_base": self.tier_base.value,
            "confirmation_count": round(self.confirmation_count, 3),
            "confirmation_set": list(self.confirmation_set),
            "layer3_score": round(self.layer3_score, 3),
            "layer3_delta": self.layer3_delta,
            "d_hard_floor": self.d_hard_floor,
            "risk_base_pct": round(self.risk_base_pct, 3),
            "reasons": list(self.reasons),
        }


def decide(
    *,
    confirmation_count: float,
    layer3_score: float = 0.0,
    zone_score: float | None = None,
    rr_net: float | None = None,
    rr_absolute_floor: float = 1.0,
    min_zone: float = 50.0,
    confirmation_set: Sequence[str] = (),
) -> TierDecision:
    """Confirmation count -> final tier, after the two hard gates.

    Flow:
      1. zone supplied and below min_zone -> D, reason 'zone_filter'.
      2. net R:R supplied and below rr_absolute_floor -> NOISE,
         reason 'rr_absolute_floor'.
      3. base tier from the confirmation count (tier_base).
      4. final tier = adjust_tier(tier_base, layer3_delta(layer3_score)).
      5. reason 'tier_layer3_up' / 'tier_layer3_down' only when the vote
         actually moved the tier; 'd_hard_floor' for a zero-confirmation D.

    The zone filter runs before the R:R floor when both would fire. When a
    hard gate decides the tier, tier_base still records the confirmation tier
    for journaling (upgraded/downgraded compare against it).
    """
    delta = layer3_delta(layer3_score)
    tier_base = tier_base_from_confirmations(confirmation_count)
    reasons: list[str] = []

    if zone_score is not None and zone_score < min_zone:
        tier = Tier.D
        reasons.append("zone_filter")
    elif rr_net is not None and rr_net < rr_absolute_floor:
        tier = Tier.NOISE
        reasons.append("rr_absolute_floor")
    else:
        tier = adjust_tier(tier_base, delta)
        if tier is not tier_base:
            reasons.append("tier_layer3_up" if delta > 0 else "tier_layer3_down")
        if tier is Tier.D:
            reasons.append("d_hard_floor")

    return TierDecision(
        tier=tier,
        tier_base=tier_base,
        confirmation_count=float(confirmation_count),
        confirmation_set=tuple(confirmation_set),
        layer3_score=float(layer3_score),
        layer3_delta=delta,
        d_hard_floor=tier is Tier.D,
        risk_base_pct=TIER_RISK_PCT[tier],
        reasons=tuple(reasons),
    )
