"""Weekend close policy: be flat before the weekly broker session close.

Pure: no I/O, no wall clock, no config access.  The caller passes *broker*
wall-clock time (a UTC instant plus SymbolInfo.broker_offset) and the broker
session table from SymbolInfo.sessions; every boundary computed here is broker
time.

This replaces the v4 'friday_flat_hour_utc' rule, which hardcoded 19:00 UTC and
was wrong twice: the broker closes at the end of its own session (usually later)
and the broker's UTC offset changes with DST.  The close moment now comes from
the session table, so the same UTC instant can produce a different plan in
summer and winter.

Split of duties
---------------
* 'session_end_broker' / 'next_session_open' resolve the broker calendar
  (weekends are closed; an overnight Friday session may still close on Saturday).
* 'in_weekend_close_window' answers "should we be flat now?" and reports why,
  the hard deadline and the moment the proactive window opened.
* 'weekend_close_plan' orders the tickets deterministically for the flatten.
  The caller applies 'max_deviation_points' and the gateway fallback grace when
  it builds the actual close intents.
* 'weekend_override_allowed' is the only way a manual override may suppress the
  flatten: the config must opt in *and* the operator must confirm.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from datetime import date, datetime, time, timedelta
from typing import Literal

from ..domain.model import SessionWindow, SymbolInfo, utc

CloseOrder = Literal["profit_first", "loss_first", "ticket"]

CLOSE_ORDERS: tuple[str, ...] = ("profit_first", "loss_first", "ticket")

REASON_WINDOW = "weekend_close_window"
REASON_SESSION_END = "friday_session_end"

# Session tables describe a trading day; Saturday and Sunday open no session.
_TRADING_WEEKDAYS: tuple[int, ...] = (0, 1, 2, 3, 4)
_DAYS_IN_WEEK = 7
# Enough calendar days to find Monday from a Saturday and back again.
_LOOKAHEAD_DAYS = 9


@dataclass(frozen=True, slots=True)
class WeekendParams:
    """Weekend-close assumptions, normally built from the [weekend] config table."""

    enabled: bool = True
    close_minutes_before_session_end: int = 30
    max_deviation_points: int = 200
    close_order: CloseOrder = "profit_first"
    fallback_grace_minutes: int = 10
    # Opt-in for a manual override; the operator must also confirm it.
    override: bool = False


@dataclass(frozen=True, slots=True)
class WeekendPlan:
    """What the weekend policy wants right now (now is broker wall-clock time).

    deadline and window_start carry the same tzinfo as the evaluated now.
    """

    flatten: bool
    reason: str
    deadline: datetime | None = None
    window_start: datetime | None = None


def _validate_params(params: WeekendParams) -> None:
    minutes = params.close_minutes_before_session_end
    if not 20 <= minutes <= 60:
        raise ValueError(f"close_minutes_before_session_end must be 20..60, got {minutes!r}")
    if params.max_deviation_points < 1:
        raise ValueError(f"max_deviation_points must be >= 1, got {params.max_deviation_points!r}")
    if params.close_order not in CLOSE_ORDERS:
        raise ValueError(f"close_order must be one of {CLOSE_ORDERS}, got {params.close_order!r}")
    if params.fallback_grace_minutes < 0:
        raise ValueError(
            f"fallback_grace_minutes must be >= 0, got {params.fallback_grace_minutes!r}"
        )


def _stamp(day: date, at: time, template: datetime) -> datetime:
    """Wall-clock day/at with the same tzinfo as template (broker time)."""
    return datetime.combine(day, at, tzinfo=template.tzinfo)


def _session_close(window: SessionWindow, day: date, template: datetime) -> datetime:
    """Close of the session that opens on day (overnight windows close next day)."""
    if window.start <= window.end:
        return _stamp(day, window.end, template)
    return _stamp(day + timedelta(days=1), window.end, template)


def _weekend_close(friday: date, sessions: Sequence[SessionWindow], template: datetime) -> datetime:
    """Latest close of any session that opens on Friday: the weekly close."""
    return max(_session_close(window, friday, template) for window in sessions)


def _require_sessions(sessions: Sequence[SessionWindow]) -> None:
    if not sessions:
        raise ValueError("sessions must not be empty: cannot resolve the broker calendar")


def session_end_broker(now_broker: datetime, sessions: Sequence[SessionWindow]) -> datetime:
    """Next session close at or after now_broker (broker wall-clock time).

    Overnight windows (end <= start) close on the following calendar day, so a
    session that opened the previous evening can still be the next close.
    Saturday and Sunday open no new session, so a Friday overnight session is
    the last one before Monday.
    """
    _require_sessions(sessions)
    best: datetime | None = None
    start_day = now_broker.date() - timedelta(days=1)
    for offset in range(_LOOKAHEAD_DAYS + 1):
        day = start_day + timedelta(days=offset)
        if day.weekday() not in _TRADING_WEEKDAYS:
            continue
        for window in sessions:
            close = _session_close(window, day, now_broker)
            if close >= now_broker and (best is None or close < best):
                best = close
    if best is None:
        raise ValueError("no session close found within the look-ahead window; check sessions")
    return best


def next_session_open(now_broker: datetime, sessions: Sequence[SessionWindow]) -> datetime:
    """First session start strictly after now_broker (weekends skipped)."""
    _require_sessions(sessions)
    best: datetime | None = None
    for offset in range(_LOOKAHEAD_DAYS):
        day = now_broker.date() + timedelta(days=offset)
        if day.weekday() not in _TRADING_WEEKDAYS:
            continue
        for window in sessions:
            opened = _stamp(day, window.start, now_broker)
            if opened > now_broker and (best is None or opened < best):
                best = opened
    if best is None:
        raise ValueError("no session open found within the look-ahead window; check sessions")
    return best


def in_weekend_close_window(
    now_broker: datetime,
    sessions: Sequence[SessionWindow],
    params: WeekendParams,
) -> WeekendPlan:
    """Flat-now decision for the weekly close, in broker wall-clock time.

    The window opens close_minutes_before_session_end before the Friday session
    close (reason weekend_close_window) and stays armed after that close until
    the next session re-opens on Monday (reason friday_session_end), so nothing
    survives the weekend gap.  deadline is the broker session close and
    window_start is where flattening starts.
    """
    _validate_params(params)
    _require_sessions(sessions)
    if not params.enabled:
        return WeekendPlan(False, "", None, None)

    running_friday = now_broker.date() + timedelta(days=4 - now_broker.weekday())
    for shift in (-_DAYS_IN_WEEK, 0, _DAYS_IN_WEEK):
        friday = running_friday + timedelta(days=shift)
        close = _weekend_close(friday, sessions, now_broker)
        reopen = next_session_open(close, sessions)
        window_start = close - timedelta(minutes=params.close_minutes_before_session_end)
        if window_start <= now_broker < reopen:
            reason = REASON_WINDOW if now_broker < close else REASON_SESSION_END
            return WeekendPlan(True, reason, close, window_start)
    return WeekendPlan(False, "", None, None)


def close_order_key(profit: float, ticket: int, params: WeekendParams) -> tuple[float, int]:
    """Deterministic sort key for the flatten order.

    profit_first closes the most profitable position first, loss_first the
    deepest loser first, ticket ignores profit.  The ticket is always the final
    tie-break, so the order is total and independent of mapping iteration order.
    """
    order = params.close_order
    if order == "profit_first":
        primary = -float(profit)
    elif order == "loss_first":
        primary = float(profit)
    elif order == "ticket":
        primary = 0.0
    else:
        raise ValueError(f"close_order must be one of {CLOSE_ORDERS}, got {order!r}")
    return (primary, int(ticket))


def weekend_close_plan(
    positions_profit: Mapping[int, float], params: WeekendParams
) -> tuple[int, ...]:
    """Engine-facing ordered ticket list for the weekend flatten.

    Input is the engine's ticket -> profit mapping (PositionSnapshot.ticket and
    PositionSnapshot.profit); output is the deterministic close sequence for the
    configured close_order (profit_first / loss_first / ticket, ticket as the
    final tie-break).  The engine's weekend branch (engine.py:407-429) and
    _flatten (engine.py:1624-1643) must iterate THIS sequence instead of the
    position book order; until that wiring lands this helper is the source of
    truth and the book order is a known deviation (ADR-022, SES-05).

    Only orders the flatten; it never decides whether the flatten is needed.
    Parameters are validated here so a bad config fails before any order is sent.
    """
    _validate_params(params)
    items = [(int(ticket), float(profit)) for ticket, profit in positions_profit.items()]
    items.sort(key=lambda item: close_order_key(item[1], item[0], params))
    return tuple(ticket for ticket, _ in items)


def fallback_close_deadline(plan: WeekendPlan, params: WeekendParams) -> datetime | None:
    """Last moment for a retried/fallback close: the session end plus grace.

    plan.deadline is the broker session close; the MT5-phase gateway may use
    fallback_grace_minutes on top of it before a hard local flatten.
    """
    if plan.deadline is None:
        return None
    return plan.deadline + timedelta(minutes=max(0, params.fallback_grace_minutes))


def weekend_override_allowed(params: WeekendParams, operator: bool) -> bool:
    """True only when the config permits an override and the operator confirmed it."""
    return bool(params.override and operator)


def broker_time(now_utc: datetime, info: SymbolInfo) -> datetime:
    """Convert a UTC instant to broker wall-clock time (sessions use broker time)."""
    return utc(now_utc) + info.broker_offset


def weekend_plan_utc(
    now_utc: datetime, info: SymbolInfo, params: WeekendParams | None = None
) -> WeekendPlan:
    """in_weekend_close_window from a UTC instant, using info.broker_offset.

    A DST change moves the same UTC instant relative to the broker session end,
    so the plan changes even though the session table does not.
    """
    return in_weekend_close_window(broker_time(now_utc, info), info.sessions, params or WeekendParams())
