"""Order coordination: journal first, then network, then a definite state."""

from __future__ import annotations

import math
from typing import Any

from ..domain.errors import InvariantError, SubmitUncertain
from ..domain.events import Ev, Event, TradeRecord
from ..domain.execution import ApprovedOrder, ExitIntent
from ..domain.fsm.order import OrderState, assert_transition
from ..domain.retcodes import RetcodeAction, classify
from ..domain.model import Fill, Ticket
from ..domain.money import money
from ..log import get_logger
from ..ports.execution import ExecutionResult

log = get_logger("executor")


class OrderCoordinator:
    def __init__(
        self,
        *,
        broker: Any,
        journal: Any,
        clock: Any,
        positions: Any,
        secret: str,
        run_id: str,
        magic_base: int = 7300,
    ) -> None:
        self._broker = broker
        self._journal = journal
        self._clock = clock
        self._positions = positions
        self._secret = secret
        self._run_id = run_id
        self._magic_base = magic_base
        self._states: dict[str, OrderState] = {}
        self._uncertain: dict[str, ApprovedOrder] = {}

    # ------------------------------------------------------------------
    def _emit(self, event_type: str, payload: dict[str, Any], *, corr: str = "") -> None:
        if self._journal is None:
            return
        self._journal.append(
            Event(type=event_type, payload=payload, ts=self._clock.now(), correlation_id=corr, actor="executor")
        )

    def _transition(self, intent_id: str, target: OrderState) -> None:
        current = self._states.get(intent_id, OrderState.CREATED)
        assert_transition(current, target)
        self._states[intent_id] = target

    def in_flight(self) -> list[str]:
        return [i for i, s in self._states.items() if s not in (OrderState.FILLED, OrderState.REJECTED, OrderState.CANCELED, OrderState.EXPIRED, OrderState.RESOLVED_ABSENT, OrderState.RISK_REJECTED)]

    @property
    def uncertain(self) -> dict[str, ApprovedOrder]:
        return dict(self._uncertain)

    # ------------------------------------------------------------------
    def execute(self, approved: ApprovedOrder) -> ExecutionResult:
        if not approved.is_sealed(self._secret):
            self._emit(
                Ev.ORDER_REJECTED,
                {"intent_id": approved.intent_id, "reason": "unsealed_order"},
                corr=approved.intent_id,
            )
            raise InvariantError("order is not sealed by this risk engine")

        self._transition(approved.intent_id, OrderState.APPROVED)
        self._transition(approved.intent_id, OrderState.SUBMITTING)
        idem = f"{self._run_id}:{approved.intent_id}"

        # Write-ahead: we must be able to answer "did we send this?" after a crash.
        if self._journal is not None:
            self._journal.append(
                Event(
                    type=Ev.ORDER_SUBMITTED,
                    payload={
                        "intent_id": approved.intent_id,
                        "idempotency_key": idem,
                        "client_ref": approved.client_ref,
                        "volume": approved.volume,
                        "side": approved.side,
                        "sl": approved.sl,
                        "tp": approved.tp,
                    },
                    ts=self._clock.now(),
                    correlation_id=approved.intent_id,
                    actor="executor",
                ),
                fsync=True,
            )

        try:
            ack = self._broker.submit(approved, idempotency_key=idem)
        except SubmitUncertain as exc:
            self._transition(approved.intent_id, OrderState.UNKNOWN)
            self._uncertain[approved.intent_id] = approved
            self._emit(
                Ev.ORDER_UNCERTAIN,
                {"intent_id": approved.intent_id, "reason": exc.reason},
                corr=approved.intent_id,
            )
            log.error("order outcome unknown", extra={"fields": {"intent_id": approved.intent_id}})
            return ExecutionResult(approved.intent_id, "uncertain")
        except Exception as exc:  # noqa: BLE001 - unknown => fail closed
            self._transition(approved.intent_id, OrderState.UNKNOWN)
            self._uncertain[approved.intent_id] = approved
            self._emit(
                Ev.ORDER_UNCERTAIN,
                {"intent_id": approved.intent_id, "reason": repr(exc)},
                corr=approved.intent_id,
            )
            return ExecutionResult(approved.intent_id, "uncertain")

        if not ack.accepted:
            self._transition(approved.intent_id, OrderState.REJECTED)
            action = classify(ack.retcode)
            self._emit(
                Ev.ORDER_REJECTED,
                {
                    "intent_id": approved.intent_id,
                    "retcode": ack.retcode,
                    "retcode_name": ack.retcode_name,
                    "message": ack.message,
                    "action": action.value,
                },
                corr=approved.intent_id,
            )
            return ExecutionResult(
                approved.intent_id,
                "rejected",
                ack=ack,
                retryable=action in (RetcodeAction.RETRY_PRICE, RetcodeAction.RETRY_STOPS),
                action=action.value,
            )

        filled_volume = float(ack.filled_volume or 0.0)
        ticket = int(ack.ticket or 0)
        fill_price = float(ack.fill_price or 0.0)
        if filled_volume <= 0.0 or ticket <= 0 or fill_price <= 0.0:
            # MT5-01: acceptance is not execution. Without a real ticket, volume
            # and price the order never became a position worth risking capital.
            self._transition(approved.intent_id, OrderState.UNKNOWN)
            self._uncertain[approved.intent_id] = approved
            self._emit(
                Ev.ORDER_UNCERTAIN,
                {
                    "intent_id": approved.intent_id,
                    "reason": "accepted_without_fill",
                    "retcode": ack.retcode,
                    "ticket": ack.ticket,
                    "volume": ack.filled_volume,
                },
                corr=approved.intent_id,
            )
            log.error(
                "order accepted without an execution proof",
                extra={"fields": {"intent_id": approved.intent_id, "retcode": ack.retcode}},
            )
            return ExecutionResult(
                approved.intent_id, "uncertain", ack=ack, action="quarantine"
            )

        self._transition(approved.intent_id, OrderState.ACKED)
        self._emit(
            Ev.ORDER_ACKED,
            {
                "intent_id": approved.intent_id,
                "ticket": ack.ticket,
                "fill_price": ack.fill_price,
                "volume": ack.filled_volume,
            },
            corr=approved.intent_id,
        )

        fill = Fill(
            ticket=Ticket(int(ack.ticket or 0)),
            symbol=approved.symbol,
            side=approved.side,
            volume=ack.filled_volume,
            price=float(ack.fill_price or 0.0),
            commission=money(0),
            ts=ack.ts or self._clock.now(),
            kind="open",
        )
        pos = self._positions.apply_fill(
            fill,
            slot=approved.slot,
            strategy=approved.strategy,
            risk_amount=approved.risk.risk_amount,
            initial_stop=approved.sl,
            signal=approved.signal,
            risk=approved.risk.as_dict(),
        )
        self._emit(
            Ev.POSITION_OPENED,
            {
                "ticket": pos.ticket,
                "slot": pos.slot,
                "symbol": pos.symbol,
                "side": pos.side,
                "volume": pos.volume,
                "open_price": pos.open_price,
                "sl": pos.sl,
                "tp": pos.tp,
                "risk_amount": pos.risk_amount,
            },
            corr=approved.intent_id,
        )
        self._journal_open_trade(approved, pos)
        return ExecutionResult(approved.intent_id, "acked", ack=ack)

    def _journal_open_trade(self, approved: ApprovedOrder, pos: Any) -> None:
        if self._journal is None:
            return
        record = TradeRecord(
            trade_id=f"{approved.slot}-{pos.ticket}",
            slot=approved.slot,
            strategy=approved.strategy,
            symbol=str(approved.symbol),
            side=approved.side,
            volume=pos.volume,
            open_time=pos.open_time.isoformat(),
            close_time=None,
            open_price=pos.open_price,
            close_price=None,
            sl=pos.sl,
            tp=pos.tp,
            pnl_gross=0.0,
            commission=0.0,
            swap=0.0,
            pnl_net=0.0,
            spread_at_entry=approved.risk.spread_points,
            risk_amount=approved.risk.risk_amount,
            risk_pct=approved.risk.risk_pct,
            signal=dict(approved.signal),
            risk=approved.risk.as_dict(),
            confirmations=list(approved.signal.get("confirmations", [])),
        )
        self._journal.record_trade(record)

    # ------------------------------------------------------------------
    def _close_volume(self, intent: ExitIntent) -> float | None:
        """Map an exit fraction onto a broker volume for the live position.

        None means "close everything". A partial fraction is floored to the
        symbol volume step so rounding can never over-close; a slice below the
        minimum lot flattens the remainder instead of leaving dust.
        """
        if intent.fraction >= 1.0 - 1e-9:
            return None
        lookup = getattr(self._positions, "get", None)
        if lookup is None:
            return None
        pos = lookup(int(intent.ticket))
        if pos is None:
            return None
        try:
            info = self._broker.symbol_info(pos.symbol)
        except Exception:  # noqa: BLE001 - no metadata means fall back to a full close
            return None
        raw = float(pos.volume) * float(intent.fraction)
        steps = math.floor(raw / info.volume_step + 1e-9)
        volume = round(steps * info.volume_step, 8)
        if volume < info.min_volume - 1e-9:
            return None
        if volume >= float(pos.volume) - 1e-9:
            return None
        return volume

    def close_position(self, intent: ExitIntent) -> ExecutionResult:
        idem = f"{self._run_id}:close:{intent.intent_id}"
        volume = self._close_volume(intent)
        try:
            ack = self._broker.close(
                Ticket(int(intent.ticket)),
                volume=volume,
                idempotency_key=idem,
                reason=intent.reason,
            )
        except SubmitUncertain as exc:
            # A close whose outcome is unknown must never be resent blindly; the
            # caller inspects venue truth and fails closed.
            self._emit(
                Ev.ORDER_UNCERTAIN,
                {"intent_id": intent.intent_id, "ticket": intent.ticket, "reason": exc.reason},
                corr=intent.intent_id,
            )
            log.error(
                "close outcome unknown",
                extra={"fields": {"ticket": intent.ticket, "err": exc.reason}},
            )
            return ExecutionResult(intent.intent_id, "uncertain", action="quarantine")
        except Exception as exc:  # noqa: BLE001
            self._emit(
                Ev.ORDER_UNCERTAIN,
                {"intent_id": intent.intent_id, "ticket": intent.ticket, "reason": repr(exc)},
                corr=intent.intent_id,
            )
            log.error("close failed", extra={"fields": {"ticket": intent.ticket, "err": repr(exc)}})
            return ExecutionResult(intent.intent_id, "uncertain", action="quarantine")
        if not ack.accepted:
            action = classify(ack.retcode)
            self._emit(
                Ev.ORDER_REJECTED,
                {
                    "intent_id": intent.intent_id,
                    "ticket": intent.ticket,
                    "retcode": ack.retcode,
                    "retcode_name": ack.retcode_name,
                    "message": ack.message,
                    "action": action.value,
                    "kind": "close",
                },
                corr=intent.intent_id,
            )
            return ExecutionResult(intent.intent_id, "rejected", ack=ack, action=action.value)
        closed = ack.closed_trade
        remaining: float | None = None
        if closed is not None:
            lookup = getattr(self._positions, "get", None)
            pos = lookup(int(intent.ticket)) if lookup is not None else None
            if pos is not None:
                remaining = max(0.0, round(float(pos.volume) - float(closed.volume), 8))
            # A partial ack leaves the rest of the ticket open; the caller settles
            # the closed_trade and the position book keeps the remainder.
            log.info(
                "position close acked",
                extra={
                    "fields": {
                        "ticket": intent.ticket,
                        "volume": float(closed.volume),
                        "remaining": remaining,
                        "reason": intent.reason,
                    }
                },
            )
        self._emit(
            Ev.POSITION_CLOSING,
            {
                "ticket": intent.ticket,
                "reason": intent.reason,
                "volume": None if closed is None else float(closed.volume),
                "remaining": remaining,
                "partial": bool(closed is not None and remaining),
            },
            corr=intent.intent_id,
        )
        return ExecutionResult(intent.intent_id, "acked", ack=ack)

    def modify(self, ticket: int, *, sl: float | None = None, tp: float | None = None) -> bool:
        idem = f"{self._run_id}:mod:{ticket}:{sl}:{tp}"
        try:
            ack = self._broker.modify(Ticket(int(ticket)), sl=sl, tp=tp, idempotency_key=idem)
        except Exception:  # noqa: BLE001
            return False
        if ack.accepted:
            self._emit(Ev.POSITION_MODIFIED, {"ticket": ticket, "sl": sl, "tp": tp})
        return bool(ack.accepted)

    # ------------------------------------------------------------------
    def resolve_uncertain(self, since: Any) -> list[int]:
        """After reconnect: adopt orders that actually reached the venue."""
        adopted: list[int] = []
        for intent_id, order in list(self._uncertain.items()):
            found = self._broker.find_by_client_ref(order.client_ref, since=since)
            if found:
                ticket = int(found[-1].ticket)
                self._states[intent_id] = OrderState.ADOPTED
                self._emit(
                    Ev.ORDER_RESOLVED_PRESENT,
                    {"intent_id": intent_id, "ticket": ticket, "matched_by": "client_ref"},
                    corr=intent_id,
                )
                adopted.append(ticket)
            else:
                self._states[intent_id] = OrderState.RESOLVED_ABSENT
                self._emit(Ev.ORDER_RESOLVED_ABSENT, {"intent_id": intent_id}, corr=intent_id)
            self._uncertain.pop(intent_id, None)
        return adopted
