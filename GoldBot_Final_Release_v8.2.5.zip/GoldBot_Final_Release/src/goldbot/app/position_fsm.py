"""Three-layer take-profit as a deterministic, idempotent position state machine.

Phases: OPEN -> PARTIAL_1 -> PARTIAL_2 -> TRAILING -> CLOSED.

The machine is pure: it owns no clock, broker or journal.  on_price returns at
most one pending action (PARTIAL, MODIFY_SL or CLOSE); the same action object is
returned until the caller reports it done or failed.  That makes a lost ack safe:
retrying can never close the same slice twice.  After retry_limit consecutive
failures the machine flattens the remainder.

Netting mode is deliberately unsupported: a netted aggregate has no per-ticket
lifecycle, so a partial exit cannot be attributed to one plan.  PositionManager
refuses to attach a machine in netting mode and the engine notifies once instead
of silently arming a plan.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Literal

from ..domain.errors import InvariantError
from ..domain.fsm.position import PositionPhase, assert_phase_transition

ActionKind = Literal["PARTIAL", "MODIFY_SL", "CLOSE"]

TP1_PARTIAL = "tp1-partial"
TP2_PARTIAL = "tp2-partial"
TP3_CLOSE = "tp3-close"
RETRY_CLOSE = "retry-close"
FORCE_CLOSE = "force-close"
SL_BEFORE = "sl-be"
SL_AFTER_TP1 = "sl-tp1"


@dataclass(frozen=True, slots=True)
class TPPlan:
    """Three take-profit levels plus the fraction taken at each.

    Fractions are of the *initial* position volume; the third slice is always
    the remainder.  Prices are absolute levels on the correct side of the entry.
    """

    tp1: float
    tp2: float
    tp3: float
    frac1: float = 0.5
    frac2: float = 0.3
    frac3: float = 0.2
    be_after_tp1: bool = True
    trail_atr_mult: float = 1.5
    digits: int = 2

    def __post_init__(self) -> None:
        for name in ("frac1", "frac2", "frac3"):
            value = float(getattr(self, name))
            if not 0.0 < value <= 1.0:
                raise InvariantError(f"TPPlan.{name} must be in (0, 1], got {value}")
        if self.frac1 + self.frac2 + self.frac3 > 1.0 + 1e-9:
            raise InvariantError("TPPlan fractions must not exceed the position volume")


@dataclass(frozen=True, slots=True)
class FSMAction:
    """One instruction for the executor.

    action_id is stable, so a repeated delivery can be recognised and ignored
    instead of being applied twice.
    """

    kind: ActionKind
    action_id: str
    volume: float = 0.0
    sl: float | None = None
    reason: str = ""


def build_tp_plan(
    entry: float,
    side: str,
    stop: float,
    target: float | None,
    digits: int = 2,
) -> TPPlan:
    """Derive 1R/2R/target levels from an approved entry.

    tp1 = entry + 1R, tp2 = entry + 2R, tp3 = the intent target clamped up to
    2R.  When the target is closer than 2R the target becomes tp3 and tp2 sits
    at 0.75 of that distance; a pathologically close target is re-laddered so
    the three levels stay strictly ordered.
    """
    if side not in ("buy", "sell"):
        raise InvariantError(f"unknown position side {side!r}")
    the_entry = float(entry)
    risk = abs(the_entry - float(stop))
    if risk <= 0.0:
        raise InvariantError("cannot build a TP plan without a non-zero stop distance")
    sign = 1.0 if side == "buy" else -1.0
    target_distance = None if target is None else abs(float(target) - the_entry)
    if target_distance is None:
        # No target at all: use the upper end of the documented [2R, 3R] band so
        # tp3 remains strictly above tp2.
        d1 = risk
        d2 = 2.0 * risk
        d3 = 3.0 * risk
    elif target_distance >= 2.0 * risk:
        d1 = risk
        d2 = 2.0 * risk
        d3 = target_distance
    else:
        d3 = target_distance
        d2 = 0.75 * d3
        if d3 <= risk:
            d1 = 0.33 * d3
            d2 = 0.66 * d3
        else:
            d1 = risk
            if d2 <= d1:
                d2 = (d1 + d3) / 2.0
    digits = int(digits)
    point = 10.0 ** (-digits)
    tp1 = round(the_entry + sign * d1, digits)
    tp2 = round(the_entry + sign * d2, digits)
    tp3 = round(the_entry + sign * d3, digits)
    # Rounding must never invert or collapse the ladder.
    if sign > 0:
        tp2 = max(tp2, round(tp1 + point, digits))
        tp3 = max(tp3, round(tp2 + point, digits))
    else:
        tp2 = min(tp2, round(tp1 - point, digits))
        tp3 = min(tp3, round(tp2 - point, digits))
    return TPPlan(tp1=tp1, tp2=tp2, tp3=tp3, digits=digits)


class PositionFSM:
    """Pure three-layer exit plan for one open ticket."""

    def __init__(
        self,
        plan: TPPlan,
        entry: float,
        side: str,
        volume: float,
        volume_min: float,
        initial_stop: float,
        atr: float | None = None,
        volume_step: float | None = None,
        retry_limit: int = 3,
    ) -> None:
        if side not in ("buy", "sell"):
            raise InvariantError(f"unknown position side {side!r}")
        the_volume = float(volume)
        the_min = float(volume_min)
        if the_volume <= 0.0:
            raise InvariantError("position FSM requires a positive volume")
        if the_min <= 0.0:
            raise InvariantError("position FSM requires a positive minimum volume")
        self._initial_stop = float(initial_stop)
        self._sl = float(initial_stop)
        self.entry = float(entry)
        self.side: str = side
        self.plan = plan
        self._direction = 1.0 if side == "buy" else -1.0
        self._validate_levels(plan)
        self._initial_volume = the_volume
        self._volume_min = the_min
        self._volume_step = float(volume_step) if volume_step is not None else the_min
        if self._volume_step <= 0.0:
            raise InvariantError("position FSM requires a positive volume step")
        self.atr = None if atr is None else float(atr)
        self.retry_limit = int(retry_limit)
        if self.retry_limit < 1:
            raise InvariantError("retry_limit must be at least one")
        self.phase = PositionPhase.OPEN
        self.close_reason = ""
        self._remaining = the_volume
        self._realized = 0.0
        self._pending: FSMAction | None = None
        self._done: set[str] = set()
        self._failures = 0
        self._last_failure = ""
        self._trail_seq = 0
        self._last_price = self.entry
        # A single min lot cannot be split into two dust slices: use one target.
        self.single_target_path = the_volume < 2.0 * the_min - 1e-9
        self._be_done = False

    # -- read-only state -------------------------------------------------
    @property
    def pending(self) -> FSMAction | None:
        return self._pending

    @property
    def closed(self) -> bool:
        return self.phase is PositionPhase.CLOSED

    @property
    def remaining(self) -> float:
        return round(self._remaining, 8)

    @property
    def realized_volume(self) -> float:
        return round(self._realized, 8)

    @property
    def realized_fraction(self) -> float:
        return round(self._realized / self._initial_volume, 6)

    @property
    def current_sl(self) -> float:
        return self._sl

    @property
    def initial_volume(self) -> float:
        return self._initial_volume

    @property
    def last_failure(self) -> str:
        return self._last_failure

    # -- driving the machine ---------------------------------------------
    def on_price(self, price: float, atr: float | None = None) -> FSMAction | None:
        """Return the next pending action for this price, or None."""
        if self.closed:
            return None
        if atr is not None:
            self.atr = float(atr)
        self._last_price = float(price)
        if self._pending is not None:
            return self._pending
        price_now = float(price)
        if self.phase is PositionPhase.OPEN:
            if self.single_target_path:
                if (
                    self.plan.be_after_tp1
                    and not self._be_done
                    and self._beyond(price_now, self.plan.tp1)
                ):
                    return self._set_pending(
                        self._modify(self.entry, SL_BEFORE, "breakeven")
                    )
                if self._beyond(price_now, self.plan.tp3):
                    return self._set_pending(self._close(TP3_CLOSE, "tp3"))
                return None
            if self._beyond(price_now, self.plan.tp1):
                return self._set_pending(
                    self._partial(self._planned_volume(self.plan.frac1), TP1_PARTIAL, "tp1")
                )
            return None
        if self.phase is PositionPhase.PARTIAL_1:
            if self._beyond(price_now, self.plan.tp2):
                return self._set_pending(
                    self._partial(self._planned_volume(self.plan.frac2), TP2_PARTIAL, "tp2")
                )
            return None
        if self.phase is PositionPhase.PARTIAL_2:
            return None
        # TRAILING
        if self._beyond(price_now, self.plan.tp3):
            return self._set_pending(self._close(TP3_CLOSE, "tp3"))
        return self._pending_trail()

    def on_action_done(
        self, action: FSMAction | None, *, filled_volume: float | None = None
    ) -> None:
        """Apply an acknowledged action exactly once (replays are ignored)."""
        if action is None:
            return
        if action.action_id in self._done:
            return
        if self._pending is not None and self._pending.action_id != action.action_id:
            raise InvariantError(
                f"action {action.action_id} is not pending "
                f"(pending: {self._pending.action_id})"
            )
        self._pending = None
        self._failures = 0
        if action.kind == "PARTIAL":
            self._apply_partial(action, filled_volume)
        elif action.kind == "MODIFY_SL":
            self._apply_sl(action)
        elif action.kind == "CLOSE":
            filled = self._remaining if filled_volume is None else float(filled_volume)
            if filled > self._remaining + 1e-9:
                raise InvariantError(
                    f"over-close rejected: filled {filled} > remaining {self._remaining}"
                )
            self._realized = round(self._realized + min(filled, self._remaining), 8)
            self._remaining = 0.0
            self.close_reason = action.reason
            self._advance(PositionPhase.CLOSED)
        self._done.add(action.action_id)

    def on_action_failed(self, reason: str = "") -> FSMAction | None:
        """Record a failed delivery; the pending action stays queued for retry.

        After retry_limit consecutive failures the pending action becomes a full
        close so the position is flattened instead of being left unprotected.
        """
        if self.closed:
            return None
        self._failures += 1
        self._last_failure = reason or self._last_failure
        if self._failures >= self.retry_limit:
            self._pending = FSMAction(
                "CLOSE", RETRY_CLOSE, volume=round(self._remaining, 8),
                reason="retry_exhausted",
            )
        return self._pending

    def mark_closed(self, reason: str = "external") -> None:
        """Settle the plan after the venue closed the position (SL/TP/kill)."""
        if self.closed:
            return
        assert_phase_transition(self.phase, PositionPhase.CLOSED)
        self.phase = PositionPhase.CLOSED
        self.close_reason = reason
        self._remaining = 0.0
        self._pending = None

    def request_close(self, reason: str = "manual") -> FSMAction | None:
        """Queue a full close of the remainder (used by forced flattening)."""
        if self.closed:
            return None
        return self._set_pending(self._close(FORCE_CLOSE, reason))

    # -- internals -------------------------------------------------------
    def _validate_levels(self, plan: TPPlan) -> None:
        if self.side == "buy":
            if not (self._initial_stop < self.entry):
                raise InvariantError("a buy plan needs its stop below the entry")
            if not (self.entry < plan.tp1 < plan.tp2 < plan.tp3):
                raise InvariantError(
                    f"buy TP levels must ascend from the entry: {plan.tp1}, {plan.tp2}, {plan.tp3}"
                )
        else:
            if not (self._initial_stop > self.entry):
                raise InvariantError("a sell plan needs its stop above the entry")
            if not (self.entry > plan.tp1 > plan.tp2 > plan.tp3):
                raise InvariantError(
                    f"sell TP levels must descend from the entry: {plan.tp1}, {plan.tp2}, {plan.tp3}"
                )

    def _beyond(self, price: float, level: float) -> bool:
        if self._direction > 0:
            return price >= level - 1e-12
        return price <= level + 1e-12

    def _better(self, sl: float, current: float) -> bool:
        if self._direction > 0:
            return sl > current + 1e-12
        return sl < current - 1e-12

    def _advance(self, target: PositionPhase) -> None:
        if self.phase is target:
            return
        assert_phase_transition(self.phase, target)
        self.phase = target

    def _planned_volume(self, fraction: float) -> float:
        wanted = self._initial_volume * float(fraction)
        if wanted >= self._remaining - 1e-9:
            return round(self._remaining, 8)
        steps = math.floor(wanted / self._volume_step + 1e-9)
        volume = round(steps * self._volume_step, 8)
        if volume < self._volume_min - 1e-9:
            volume = round(self._volume_min, 8)
        return round(min(volume, self._remaining), 8)

    def _set_pending(self, action: FSMAction) -> FSMAction:
        if self._pending is not None and self._pending.action_id == action.action_id:
            return self._pending
        self._pending = action
        return action

    def _partial(self, volume: float, action_id: str, reason: str) -> FSMAction:
        if volume > self._remaining + 1e-9:
            raise InvariantError(
                f"over-close rejected: {volume} > remaining {self._remaining}"
            )
        return FSMAction("PARTIAL", action_id, volume=round(volume, 8), reason=reason)

    def _modify(self, sl: float, action_id: str, reason: str) -> FSMAction:
        return FSMAction("MODIFY_SL", action_id, sl=round(float(sl), self.plan.digits), reason=reason)

    def _close(self, action_id: str, reason: str) -> FSMAction:
        return FSMAction("CLOSE", action_id, volume=round(self._remaining, 8), reason=reason)

    def _pending_trail(self) -> FSMAction | None:
        atr = self.atr
        if atr is None or atr <= 0.0:
            return None
        candidate = round(
            self._last_price - self._direction * atr * self.plan.trail_atr_mult,
            self.plan.digits,
        )
        if not self._better(candidate, self._sl):
            return None
        self._trail_seq += 1
        return self._set_pending(
            FSMAction("MODIFY_SL", f"trail-{self._trail_seq}", sl=candidate, reason="trail")
        )

    def _apply_partial(self, action: FSMAction, filled_volume: float | None) -> None:
        filled = action.volume if filled_volume is None else float(filled_volume)
        if filled <= 0.0:
            raise InvariantError("partial close reported zero volume")
        if filled > self._remaining + 1e-9:
            raise InvariantError(
                f"over-close rejected: filled {filled} > remaining {self._remaining}"
            )
        filled = round(min(filled, self._remaining), 8)
        self._remaining = round(self._remaining - filled, 8)
        self._realized = round(self._realized + filled, 8)
        if action.action_id == TP1_PARTIAL:
            self._advance(PositionPhase.PARTIAL_1)
            if self.plan.be_after_tp1:
                self._pending = self._modify(self.entry, SL_BEFORE, "breakeven")
        elif action.action_id == TP2_PARTIAL:
            self._advance(PositionPhase.PARTIAL_2)
            self._pending = self._modify(self.plan.tp1, SL_AFTER_TP1, "tp1-stop")
        else:
            raise InvariantError(f"unknown partial action {action.action_id}")

    def _apply_sl(self, action: FSMAction) -> None:
        if action.sl is None:
            raise InvariantError("MODIFY_SL action without a stop price")
        candidate = round(float(action.sl), self.plan.digits)
        # Monotonic: a stop may tighten, never widen.
        if self._better(candidate, self._sl):
            self._sl = candidate
        if action.action_id == SL_BEFORE:
            self._be_done = True
            if self.single_target_path:
                self._advance(PositionPhase.TRAILING)
        elif action.action_id == SL_AFTER_TP1:
            self._advance(PositionPhase.TRAILING)
