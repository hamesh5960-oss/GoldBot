"""Retry re-seal guard.

A transient venue rejection may be retried, but only on a *fresh* risk
evaluation: the HMAC seal on an ApprovedOrder covers the price/SL/volume that
were approved, so replaying the old order at a new tick would execute something
the risk engine never approved.

This module is the single decision point for "may this retry even be
attempted?". It is deliberately pure so the safety rule can be tested today,
before the MT5 retry loop exists. The future retry loop must:

    tick -> revalidate_for_retry(...) -> allowed ?
        yes -> RiskEngine.evaluate_entry(...) again -> new seal -> send
        no  -> abort, journal retry_aborted, notify
"""

from __future__ import annotations

from dataclasses import dataclass

from ..domain.execution import ApprovedOrder
from ..ports.risk import RiskContext


@dataclass(frozen=True, slots=True)
class RetryDecision:
    allowed: bool
    reason: str
    requires_reseal: bool = True

    @property
    def aborted(self) -> bool:
        return not self.allowed


def _entry_ref(order: ApprovedOrder) -> float:
    """Reconstruct the approved entry reference from the sealed stop and distance."""
    distance = float(order.risk.stop_distance)
    if order.side == "buy":
        return float(order.sl) + distance
    return float(order.sl) - distance


def revalidate_for_retry(
    order: ApprovedOrder,
    ctx: RiskContext,
    *,
    max_spread_points: float,
    price: float | None = None,
    sl: float | None = None,
    tp: float | None = None,
    max_risk_amount: float | None = None,
) -> RetryDecision:
    """Cheap, fail-closed pre-check before asking the risk engine to re-approve.

    Order of checks mirrors evaluate_entry: a widened spread or an invalid stop
    is enough to abort; nothing here may *approve* a trade on its own.
    """
    info = ctx.symbol_info
    point = float(info.point)

    spread_points = float(ctx.tick.spread) / point if point > 0 else float("inf")
    if spread_points > float(max_spread_points):
        return RetryDecision(False, "spread_widened")

    new_price = float(price if price is not None else _entry_ref(order))
    new_sl = float(sl if sl is not None else order.sl)
    if new_sl <= 0:
        return RetryDecision(False, "invalid_stop")

    stop_distance = abs(new_price - new_sl)
    required = float(info.stops_level_points) * point
    if stop_distance + 1e-9 < required:
        return RetryDecision(False, "broker_stops_invalid")

    if tp is not None or order.tp is not None:
        new_tp = float(tp if tp is not None else order.tp)
        if abs(new_tp - new_price) + 1e-9 < required:
            return RetryDecision(False, "broker_stops_invalid_target")

    drift_points = abs(new_price - _entry_ref(order)) / point if point > 0 else 0.0
    if drift_points > float(order.max_slippage_points):
        return RetryDecision(False, "price_drift_exceeds_slippage")

    if new_price <= 0 or not ctx.account.equity.amount > 0:
        return RetryDecision(False, "non_positive_price_or_equity")

    if max_risk_amount is not None:
        loss = stop_distance * float(info.contract_size) * float(order.volume)
        if loss > float(max_risk_amount) + 1e-6:
            return RetryDecision(False, "retry_risk_above_cap")

    return RetryDecision(True, "revalidate_ok", requires_reseal=True)
