"""Turn a strategy signal into an intent, then ask risk. Never sends orders."""

from __future__ import annotations

import uuid
from dataclasses import replace
from datetime import datetime
from typing import Any, Sequence

from ..domain.execution import EntryIntent, ExitIntent
from ..domain.model import Symbol, SymbolInfo, Tick
from ..strategy_api.signals import Signal
from .ids import GOLDBOT_MAGIC_BASE, magic_for_slot


def stable_magic(slot: str, base: int = GOLDBOT_MAGIC_BASE) -> int:
    """Backwards-compatible alias; the identity lives in app.ids.magic_for_slot.

    Kept because tests and older call sites import this name. There must be one
    implementation only: execution (RiskEngine sealing) and the pipeline must
    never derive two different magics for the same slot.
    """
    return magic_for_slot(slot, base)


class SignalPipeline:
    def __init__(self, *, magic_base: int = GOLDBOT_MAGIC_BASE) -> None:
        self.magic_base = magic_base
        self._seq = 0

    def _next_id(self, slot: str) -> str:
        self._seq += 1
        return f"{slot[:8]}-{self._seq:06d}-{uuid.uuid4().hex[:6]}"

    def magic_for(self, slot: str) -> int:
        return stable_magic(slot, self.magic_base)

    def to_intent(
        self,
        signal: Signal,
        *,
        strategy_id: str,
        info: SymbolInfo,
        tick: Tick,
        now: datetime,
        confirmations: tuple[str, ...] = (),
    ) -> EntryIntent | ExitIntent | None:
        if signal.kind == "noop":
            return None
        if signal.kind == "exit":
            if signal.exit_ticket is None:
                return None
            return ExitIntent(
                intent_id=self._next_id(signal.slot),
                slot=signal.slot,
                ticket=signal.exit_ticket,
                symbol=Symbol(signal.symbol),
                reason=signal.exit_reason or "strategy",
            )

        if signal.kind != "entry" or signal.side is None or signal.stop is None:
            return None

        entry_ref = tick.ask if signal.side == "buy" else tick.bid
        if signal.order_type == "limit" and signal.limit_price is not None:
            entry_ref = signal.limit_price

        # Structural validation: a stop on the wrong side is a bug, not a trade.
        if signal.side == "buy" and signal.stop >= entry_ref:
            return None
        if signal.side == "sell" and signal.stop <= entry_ref:
            return None

        if signal.target is not None:
            if signal.side == "buy" and signal.target <= entry_ref:
                return None
            if signal.side == "sell" and signal.target >= entry_ref:
                return None

        return EntryIntent(
            intent_id=self._next_id(signal.slot),
            slot=signal.slot,
            strategy=strategy_id,
            symbol=Symbol(signal.symbol),
            side=signal.side,
            entry_ref=round(entry_ref, info.digits),
            stop=round(signal.stop, info.digits),
            target=None if signal.target is None else round(signal.target, info.digits),
            risk_multiplier=signal.confidence if signal.kind == "entry" else 1.0,
            signal={
                "kind": signal.kind,
                "side": signal.side,
                "rationale": signal.rationale,
                "tags": dict(signal.tags),
                "entry_hint": signal.entry_hint,
                "stop": signal.stop,
                "target": signal.target,
                "confidence": signal.confidence,
                "confirmations": list(confirmations),
            },
            created_at=now,
            order_type=signal.order_type,
            limit_price=signal.limit_price,
            expires_at=None,
        )
