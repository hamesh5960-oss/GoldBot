# Security Report — GoldBot 8.2.5 Final Engineering Release

## ۱. مدیریت اعتبارنامه‌ها

| موضوع | وضعیت | شاهد |
|---|---|---|
| رمز MT5 در سورس/فایل تحویلی | هیچ رمزی در بسته نیست؛ `var/live.env` در `.gitignore` است | بازرسی بسته و git |
| رمز در argv | **رد می‌شود** (exit 2)؛ فقط `GOLDBOT_MT5_PASSWORD` یا `GOLDBOT_MT5_PASSWORD_FILE` | `cli.py` cmd_live + `start_live.ps1` |
| توکن پنل | از env/فایل، به‌صورت shlex.quote در دستورات SSH، و در لاگ redact می‌شود | `scripts/deploy_vps.py` |
| لاگ‌ها | هشدارها/خطاها بدون مقادیر حساس؛ لاگ چرخشی محدود | `src/goldbot/log.py` |
| Test hooks | `GOLDBOT_LAUNCHER_SELFTEST` و `GOLDBOT_LOG_ROTATE_SELFTEST` فقط با env صریح فعال می‌شوند | scripts |

## ۲. پنل وب

- احراز هویت: Bearer/Basic با compare_digest، توکن اجباری برای همهٔ مسیرهای API.
- مسیرهای حساس: `PUT /api/config` کلیدهای بازنشسته/ناشناس را با ۴۰۰ رد می‌کند و مقدار قابل‌اعمال برمی‌گرداند.
- `/api/status` فقط `effective_config` را برمی‌گرداند؛ هیچ عددی که موتور استفاده نمی‌کند نمایش داده نمی‌شود.
- **ریسک باقی‌مانده (SEC-01):** سرویس systemd پنل روی VPS با کاربر root و HTTP ساده مستند شده است. توصیه: bind به localhost + reverse proxy با TLS، یا کاربر غیر root. اقدام اپراتور لازم است.

## ۳. SSH و استقرار VPS

- `RejectPolicy` روی host key ناشناس؛ `known_hosts` سیستم بارگذاری می‌شود (ADR-046).
- هر مسیر احراز هویت دقیقاً یک بار `connect()` (ADR-044) و keepalive فعال.
- توکن panel با `shlex.quote` نوشته می‌شود؛ CR/LF/NUL رد می‌شود؛ فرمان حاوی توکن با redact اجرا می‌شود.

## ۴. جداسازی و دسترسی

- تک‌نمونهٔ زنده: قفل انحصاری `var/live.lock` (exit 3) + اسکن هر سه شکل فراخوانی.
- نصب‌شونده: هیچ سرویس/فایلی خارج از پوشهٔ پروژه نوشته نمی‌شود؛ `var/` برای state/journal.
- `--allow-real` پیش‌فرض خاموش و حساب real بدون آن رد می‌شود.

## ۵. بازرسی‌های انجام‌شده

- جست‌وجوی الگوهای secret در بسته (password/token/private key): هیچ مقدار واقعی یافت نشد؛ فقط نام متغیرها.
- بررسی مسیرهای لاگ برای نشت: `deploy_vps.py` با تست‌های redact و newline-injection پوشش دارد.
- بررسی argv: تست‌های `test_live_launcher.py` رد شدن رمز در argv را اثبات می‌کنند.

## ۶. ریسک باقی‌مانده

1. پنل root/HTTP روی VPS (SEC-01) — اقدام اپراتور.
2. `GOLDBOT_MT5_PASSWORD` در environment فرآیند قابل خواندن توسط کاربر همان ماشین است؛ برای VPS تک‌کاربره قابل قبول، برای اشتراکی نه.
3. فایل `var/demo_pw.txt` فقط برای اعتبارسنجی محلی ساخته شد و در بسته نیست؛ باید حذف شود.
