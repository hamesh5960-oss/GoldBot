"""Repository launcher for GoldBot.

Always resolve paths relative to this checkout so commands work even when the
operator invokes this file from another working directory.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))
os.chdir(ROOT)

from goldbot.runtime.cli import main  # noqa: E402

if __name__ == "__main__":
    raise SystemExit(main())
