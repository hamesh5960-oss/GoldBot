"""Harvest real M15 XAUUSD bars from MT5 into a deterministic tape (Phase 7, A).

Why this exists: the RC shipped only synthetic tapes. A real-data 100-day run is
a hard release requirement, and MT5 on this Windows host already has the ePlanet
demo XAUUSD.st history.

What it does
------------
1. Connects to the MetaTrader5 terminal (login/server/terminal from environment
   variables or a local env file; the password is NEVER printed or written here).
2. Pulls M15 bars with copy_rates_range for the requested calendar window
   (default 120 days) and fails closed when history is insufficient, contains
   duplicate timestamps, illegal OHLC, or non-weekend gaps.
3. Expands each M15 OHLC bar into a deterministic intrabar tick path with a
   fixed seed and writes a tape JSONL that the replay reader accepts exactly:
       {"ts": <float epoch seconds UTC>, "bid": <float>, "ask": <float>, "v": <int>}
4. Validates the finished tape with goldbot.adapters.tape.validate_tape before
   publishing it atomically.

Deterministic intrabar model and its bias (READ BEFORE TRUSTING RESULTS)
------------------------------------------------------------------------
OHLC data does not contain the real intrabar path. We therefore assume:
    bullish bar (close >= open): open -> LOW -> HIGH -> close   (dip, then rally)
    bearish bar (close <  open): open -> HIGH -> LOW -> close   (pop, then drop)
Each bar is split into N ticks (default 10; N-1 must be divisible by 3 so the
open/extremes/close are hit exactly). Prices are rounded to 2 decimals, the
spread is a whole number of points taken from the bar (fallback 20 points),
bid/ask are symmetric around the path price, and tick volume is split
deterministically with the seed.

Bias introduced by that assumption:
 * Whether SL or TP was hit first inside a bar is assumption-driven. Bullish
   bars are conservative for longs (low before high) and optimistic for shorts;
   bearish bars are conservative for shorts (high before low) and optimistic for
   longs. A strategy that is long-biased will therefore look slightly worse than
   an "always favourable" path model but better than a "always adverse" one.
 * Fills at exact bar extremes/close are optimistic: no slippage, no requotes,
   no latency and no spread widening appear inside the tape.
 * MT5 M15 OHLC is broker-side; treating the levels as the mid with a fixed
   spread shifts fills by at most half the spread per side.
 * Real tick history is not available for 100 days, so intrabar microstructure
   is synthetic by construction. This is a path-assumption sensitivity test, NOT
   independent evidence of live fill quality.

Credential handling
-------------------
Resolved from env vars first (GOLDBOT_MT5_LOGIN/PASSWORD/SERVER/TERMINAL), then
from an env file: GOLDBOT_LIVE_ENV, ./var/live.env, or the dev checkout's
var/live.env. Only the file path/source is printed, never values.

Example commands
----------------
    python scripts/harvest_mt5_tape.py --days 120 --out var/xauusd_st_m15_120d.jsonl
    python run_goldbot.py backtest --tape var/xauusd_st_m15_120d.jsonl \
        --profile medium --db var/real100.db

Exit codes: 0 ok, 2 usage/config, 3 MT5 connection/history error, 4 data validation.
"""

from __future__ import annotations

import argparse
import json
import math
import os
import random
import sys
import tomllib
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from goldbot.adapters.tape import validate_tape  # noqa: E402

DEFAULT_SYMBOL = "XAUUSD.st"
DEFAULT_LOGIN = "80180927"
DEFAULT_SERVER = "ePlanet-MT5"
DEFAULT_TERMINAL = r"C:\Program Files\ePlanet MetaTrader 5 Terminal\terminal64.exe"
DEFAULT_DAYS = 120
MIN_REQUIRED_DAYS = 100
DEFAULT_TICKS_PER_BAR = 10
DEFAULT_SEED = 20261121
DEFAULT_SPREAD_POINTS = 20
POINT = 0.01
BAR_SECONDS = 900
MAX_INTRADAY_GAP_HOURS = 6.0
MAX_WEEKEND_GAP_HOURS = 80.0
MIN_COVERAGE = 0.80
DEV_ENV_FILE = Path(r"C:\Users\Dehkade Computer\Desktop\GoldBot\var\live.env")


class HarvesterError(RuntimeError):
    """Operational failure with a clear operator-facing message."""


@dataclass(frozen=True, slots=True)
class BarRow:
    server_epoch: int
    utc_epoch: float
    o: float
    h: float
    l: float
    c: float
    tick_volume: int
    spread_points: int


def _log(message: str) -> None:
    print(message, flush=True)


def _read_env_file(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    try:
        text = path.read_text(encoding="utf-8")
    except OSError:
        return values
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        key = key.strip()
        value = value.strip().strip("'\"")
        if key:
            values[key] = value
    return values


def _password(args: argparse.Namespace) -> tuple[str, str]:
    """Return (password, source description); the value is never printed."""
    from_env = os.environ.get("GOLDBOT_MT5_PASSWORD", "").strip()
    if from_env:
        return from_env, "environment"
    candidates: list[Path] = []
    if args.env_file:
        candidates.append(Path(args.env_file))
    env_path = os.environ.get("GOLDBOT_LIVE_ENV", "").strip()
    if env_path:
        candidates.append(Path(env_path))
    candidates.extend([ROOT / "var" / "live.env", DEV_ENV_FILE])
    for path in candidates:
        values = _read_env_file(path)
        password = values.get("GOLDBOT_MT5_PASSWORD", "").strip()
        if password:
            return password, f"env file {path}"
    raise HarvesterError(
        "MT5 password not found. Set GOLDBOT_MT5_PASSWORD, or GOLDBOT_LIVE_ENV, "
        "or keep var/live.env with GOLDBOT_MT5_PASSWORD (never echoed)."
    )


def _broker_offset_hours(explicit: float | None) -> float:
    if explicit is not None:
        return float(explicit)
    try:
        with (ROOT / "config" / "base.toml").open("rb") as handle:
            config = tomllib.load(handle)
        return float(config.get("symbol", {}).get("broker_offset_hours", 2))
    except (OSError, ValueError, tomllib.TOMLDecodeError):
        return 2.0


def _connect(args: argparse.Namespace):
    try:
        import MetaTrader5 as mt5
    except ImportError as exc:  # pragma: no cover - Windows-only dependency
        raise HarvesterError("MetaTrader5 package is not installed for this Python") from exc
    if not Path(args.terminal).exists():
        raise HarvesterError(f"MT5 terminal not found: {args.terminal}")

    password, source = _password(args)
    _log(f"connecting to MT5 terminal={args.terminal} server={args.server} (password from {source})")
    ok = mt5.initialize(
        path=args.terminal,
        login=int(args.login),
        password=password,
        server=args.server,
        timeout=60000,
        portable=False,
    )
    if not ok:
        last = mt5.last_error()
        mt5.shutdown()
        # A terminal may already be running/logged-in: attach and login explicitly.
        ok = mt5.initialize(path=args.terminal, timeout=60000, portable=False)
        if ok:
            ok = mt5.login(login=int(args.login), password=password, server=args.server, timeout=60000)
        if not ok:
            raise HarvesterError(f"MT5 initialize/login failed: {mt5.last_error()} (first error {last})")
    account = mt5.account_info()
    if account is None:
        mt5.shutdown()
        raise HarvesterError("MT5 connected but account_info() is unavailable")
    _log(f"connected: login={account.login} server={account.server} balance={account.balance:.2f}")
    return mt5, account


def _select_symbol(mt5, symbol: str) -> None:
    info = mt5.symbol_info(symbol)
    if info is None:
        raise HarvesterError(f"symbol not found at this broker: {symbol}")
    if not mt5.symbol_select(symbol, True):
        raise HarvesterError(f"symbol could not be selected in Market Watch: {symbol}")
    if not info.visible:
        info = mt5.symbol_info(symbol)
    _log(f"symbol ready: {symbol} digits={info.digits} point={info.point} spread={info.spread}")


def _fetch_bars(mt5, symbol: str, days: int) -> list[BarRow]:
    now = datetime.now(tz=timezone.utc)
    utc_from = now - timedelta(days=int(days))
    raw = mt5.copy_rates_range(symbol, mt5.TIMEFRAME_M15, utc_from, now)
    if raw is None:
        raise HarvesterError(f"copy_rates_range failed: {mt5.last_error()}")
    if len(raw) == 0:
        raise HarvesterError(
            f"no M15 bars returned for {symbol} between {utc_from.isoformat()} and {now.isoformat()}"
        )
    return [
        BarRow(
            server_epoch=int(bar["time"]),
            utc_epoch=float(int(bar["time"])),
            o=float(bar["open"]),
            h=float(bar["high"]),
            l=float(bar["low"]),
            c=float(bar["close"]),
            tick_volume=int(bar["tick_volume"]),
            spread_points=int(bar["spread"]),
        )
        for bar in raw
    ]


def _server_dt(epoch: int) -> datetime:
    return datetime.fromtimestamp(epoch, tz=timezone.utc)


def _validate_bars(
    bars: list[BarRow],
    *,
    symbol: str,
    requested_days: int,
    min_days: int,
    offset_hours: float,
) -> list[BarRow]:
    bars = sorted(bars, key=lambda bar: bar.server_epoch)
    if len(bars) < 2:
        raise HarvesterError(f"insufficient bars: {len(bars)}")
    first, last = bars[0].server_epoch, bars[-1].server_epoch
    span_days = (last - first) / 86400.0
    if span_days < float(min_days):
        raise HarvesterError(
            f"insufficient history: span {span_days:.1f} days < required {min_days} days "
            f"(requested {requested_days}); first={_server_dt(first).isoformat()} "
            f"last={_server_dt(last).isoformat()}"
        )

    previous: BarRow | None = None
    for index, bar in enumerate(bars):
        if previous is not None and bar.server_epoch == previous.server_epoch:
            raise HarvesterError(f"duplicate M15 timestamp at {_server_dt(bar.server_epoch).isoformat()}")
        if previous is not None:
            gap_hours = (bar.server_epoch - previous.server_epoch) / 3600.0
            if gap_hours > MAX_INTRADAY_GAP_HOURS:
                weekday = _server_dt(previous.server_epoch).weekday()
                weekend_gap = weekday in (4, 5, 6) and gap_hours <= MAX_WEEKEND_GAP_HOURS
                if not weekend_gap:
                    raise HarvesterError(
                        "non-weekend feed gap: "
                        f"{gap_hours:.1f}h after {_server_dt(previous.server_epoch).isoformat()} "
                        f"(weekday {weekday})"
                    )
        for name, value in (("open", bar.o), ("high", bar.h), ("low", bar.l), ("close", bar.c)):
            if not math.isfinite(value) or value <= 0.0:
                raise HarvesterError(f"bar {index}: invalid {name}={value}")
        if not (bar.l <= min(bar.o, bar.c) + 1e-9 and bar.h >= max(bar.o, bar.c) - 1e-9 and bar.h >= bar.l - 1e-9):
            raise HarvesterError(
                f"bar {index}: illegal OHLC at {_server_dt(bar.server_epoch).isoformat()}: "
                f"o={bar.o} h={bar.h} l={bar.l} c={bar.c}"
            )
        previous = bar

    # Coverage: sum expected weekday sessions inside the span. Holidays/late
    # openings reduce coverage symmetrically; below MIN_COVERAGE we fail closed.
    expected = 0
    cursor = _server_dt(first)
    end = _server_dt(last)
    while cursor.date() <= end.date():
        if cursor.weekday() < 5:
            expected += 96
        cursor += timedelta(days=1)
    coverage = len(bars) / max(1, expected)
    if coverage < MIN_COVERAGE:
        raise HarvesterError(
            f"insufficient bar coverage: {len(bars)} bars vs {expected} expected "
            f"({coverage * 100:.1f}% < {MIN_COVERAGE * 100:.0f}%)"
        )
    _log(
        f"bars={len(bars)} span={span_days:.1f}d coverage={coverage * 100:.1f}% "
        f"first_utc={_server_dt(first - int(offset_hours * 3600)).isoformat()} "
        f"last_utc={_server_dt(last - int(offset_hours * 3600)).isoformat()}"
    )
    return bars


def _expand_bar(
    bar: BarRow,
    *,
    ticks_per_bar: int,
    seed: int,
    fallback_spread_points: int,
    offset_hours: float,
) -> list[tuple[float, float, float, int]]:
    """Deterministic OHLC -> ticks; returns (utc_epoch, bid, ask, volume)."""
    o, h, l, c = bar.o, bar.h, bar.l, bar.c
    if h == l:
        vertices = (o, o, o, o)
    elif c >= o:
        vertices = (o, l, h, c)  # dip then rally (documented bias)
    else:
        vertices = (o, h, l, c)  # pop then drop (documented bias)
    steps = ticks_per_bar - 1
    spread_points = int(bar.spread_points)
    if spread_points <= 0:
        spread_points = int(fallback_spread_points)
    spread_points = max(1, min(spread_points, 500))
    spread_price = spread_points * POINT
    base_volume, remainder = divmod(max(0, bar.tick_volume), ticks_per_bar)
    rng = random.Random((seed * 1_000_003 + bar.server_epoch) & 0x7FFFFFFF)
    extra_ticks = set(rng.sample(range(ticks_per_bar), remainder)) if remainder else set()
    utc_start = float(bar.utc_epoch - int(offset_hours * 3600))
    ticks: list[tuple[float, float, float, int]] = []
    for index in range(ticks_per_bar):
        position = index * 3.0 / steps
        segment = min(int(position), 2)
        fraction = position - segment
        start_price = vertices[segment]
        end_price = vertices[segment + 1]
        price = round(start_price + (end_price - start_price) * fraction, 2)
        bid = round(price - spread_price / 2.0, 2)
        ask = round(price + spread_price / 2.0, 2)
        volume = base_volume + (1 if index in extra_ticks else 0)
        ticks.append((round(utc_start + index * (BAR_SECONDS / ticks_per_bar), 3), bid, ask, volume))
    return ticks


def _write_tape(path: Path, rows: list[BarRow], args: argparse.Namespace, offset_hours: float) -> tuple[int, int]:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    ticks_written = 0
    try:
        with temporary.open("w", encoding="utf-8") as handle:
            for bar in rows:
                for stamp, bid, ask, volume in _expand_bar(
                    bar,
                    ticks_per_bar=args.ticks_per_bar,
                    seed=args.seed,
                    fallback_spread_points=args.spread_points,
                    offset_hours=offset_hours,
                ):
                    handle.write(
                        json.dumps({"ts": stamp, "bid": bid, "ask": ask, "v": volume}, separators=(",", ":"))
                        + "\n"
                    )
                    ticks_written += 1
        summary = validate_tape(temporary)
        os.replace(temporary, path)
    except BaseException:
        try:
            temporary.unlink()
        except FileNotFoundError:
            pass
        raise
    return ticks_written, summary.ticks


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Harvest MT5 M15 bars into a deterministic GoldBot tape (no trading)."
    )
    parser.add_argument("--symbol", default=os.environ.get("GOLDBOT_MT5_SYMBOL", DEFAULT_SYMBOL))
    parser.add_argument("--days", type=int, default=DEFAULT_DAYS, help="calendar days to request")
    parser.add_argument("--min-days", type=int, default=MIN_REQUIRED_DAYS)
    parser.add_argument("--ticks-per-bar", type=int, default=DEFAULT_TICKS_PER_BAR)
    parser.add_argument("--seed", type=int, default=DEFAULT_SEED)
    parser.add_argument("--spread-points", type=int, default=DEFAULT_SPREAD_POINTS)
    parser.add_argument("--out", default="")
    parser.add_argument("--terminal", default=os.environ.get("GOLDBOT_MT5_TERMINAL", DEFAULT_TERMINAL))
    parser.add_argument("--login", default=os.environ.get("GOLDBOT_MT5_LOGIN", DEFAULT_LOGIN))
    parser.add_argument("--server", default=os.environ.get("GOLDBOT_MT5_SERVER", DEFAULT_SERVER))
    parser.add_argument("--env-file", default="")
    parser.add_argument("--broker-offset-hours", type=float, default=None)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.days < args.min_days:
        _log(f"--days ({args.days}) must be >= --min-days ({args.min_days})")
        return 2
    if args.ticks_per_bar < 4 or (args.ticks_per_bar - 1) % 3 != 0:
        _log("--ticks-per-bar must be >= 4 and (ticks_per_bar - 1) divisible by 3")
        return 2
    offset_hours = _broker_offset_hours(args.broker_offset_hours)
    out = Path(args.out) if args.out else ROOT / "var" / f"xauusd_st_m15_{args.days}d.jsonl"
    if not out.is_absolute():
        out = (ROOT / out) if str(out).startswith("var") else (Path.cwd() / out)
    _log(f"harvest target: {out}")
    mt5 = None
    try:
        mt5, _account = _connect(args)
        _select_symbol(mt5, args.symbol)
        rows = _fetch_bars(mt5, args.symbol, args.days)
        rows = _validate_bars(
            rows,
            symbol=args.symbol,
            requested_days=args.days,
            min_days=args.min_days,
            offset_hours=offset_hours,
        )
        ticks, validated = _write_tape(out, rows, args, offset_hours)
        summary = validate_tape(out)
        _log("")
        _log("=" * 64)
        _log("harvest complete")
        _log(f"  symbol      : {args.symbol}")
        _log(f"  bars        : {len(rows)} M15")
        _log(f"  ticks       : {ticks} (validated {validated})")
        _log(f"  UTC range   : {summary.first_ts.isoformat()} .. {summary.last_ts.isoformat()}")
        _log(f"  span        : {summary.span_seconds / 86400.0:.2f} calendar days")
        _log(f"  max spread  : {summary.max_spread:.2f}")
        _log(f"  tape        : {out} ({out.stat().st_size / 1024:.0f} KiB)")
        _log(f"  offset used : {offset_hours:+.1f}h (server -> UTC)")
        _log("  bias        : deterministic OHLC path expansion; intrabar order is assumed,")
        _log("                no true ticks/latency/requotes. Path-dependent results.")
        _log("=" * 64)
        return 0
    except HarvesterError as exc:
        _log(f"HARVEST FAILED: {exc}")
        return 3
    except Exception as exc:  # noqa: BLE001 - operator-facing failure, no traceback spam
        _log(f"HARVEST FAILED ({type(exc).__name__}): {exc}")
        return 4
    finally:
        if mt5 is not None:
            try:
                mt5.shutdown()
            except Exception:  # noqa: BLE001
                pass


if __name__ == "__main__":
    raise SystemExit(main())
