import json
import sqlite3
import sys

path = sys.argv[1] if len(sys.argv) > 1 else "var/demo_medium.db"
c = sqlite3.connect(path)
c.row_factory = sqlite3.Row

print("risk events:")
for r in c.execute(
    "select ts,type,payload from events where type in ('RiskStateChanged','KillSwitchEngaged','DailyLossBreach')"
):
    print(" ", r["ts"][:19], r["type"], r["payload"][:180])

rows = list(c.execute("select ts,equity from equity order by id"))
peak = 0.0
mdd = 0.0
at = None
for ts, e in rows:
    peak = max(peak, e)
    dd = (peak - e) / peak * 100 if peak else 0
    if dd > mdd:
        mdd = dd
        at = (ts, e, peak)
print(f"\nequity points={len(rows)} start={rows[0][1]:.2f} end={rows[-1][1]:.2f}")
print(f"max dd {mdd:.2f}% at {at[0][:19]} equity={at[1]:.2f} peak={at[2]:.2f}")

counts = {}
for r in c.execute("select payload from events where type='SignalRaised'"):
    slot = json.loads(r["payload"]).get("slot")
    counts[slot] = counts.get(slot, 0) + 1
print("signals by slot:", counts)

counts = {}
for r in c.execute("select payload from events where type='RiskEvaluated'"):
    p = json.loads(r["payload"])
    key = (p.get("slot"), p.get("verdict"), ",".join(p.get("reasons") or []))
    counts[key] = counts.get(key, 0) + 1
for k, v in sorted(counts.items(), key=lambda kv: -kv[1])[:12]:
    print(f"  {k}: {v}")
