"""Dump a minimal xlsx (written by goldbot.adapters.xlsx) as text."""

from __future__ import annotations

import html
import re
import sys
import zipfile


def sheet_rows(xml: str):
    for row in re.findall(r'<row r="(\d+)">(.*?)</row>', xml):
        cells = []
        for cell in re.findall(r"<c [^>]*>(.*?)</c>", row[1]):
            text = re.search(r"<t[^>]*>(.*?)</t>", cell)
            value = re.search(r"<v>(.*?)</v>", cell)
            cells.append(html.unescape(text.group(1)) if text else (value.group(1) if value else ""))
        yield row[0], cells


def main(path: str, sheets: list[str]) -> None:
    with zipfile.ZipFile(path) as zf:
        for index in sheets:
            name = f"xl/worksheets/sheet{index}.xml"
            print(f"=== sheet{index} ===")
            for number, cells in sheet_rows(zf.read(name).decode("utf-8")):
                print(number, " | ".join(cells))


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2:] or ["1"])
