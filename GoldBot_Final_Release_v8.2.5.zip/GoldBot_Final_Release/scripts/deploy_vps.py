"""Deploy the authenticated GoldBot panel to an Ubuntu VPS (idempotent).

Usage (PowerShell):
    $env:GOLDBOT_VPS_HOST = "<VPS_HOST>"
    $env:GOLDBOT_VPS_PASSWORD = "<ssh password>"
    python scripts/deploy_vps.py

Optional environment:
    GOLDBOT_VPS_USER      SSH user, default "root"
    GOLDBOT_VPS_KEY       private-key path (instead of a password)
    GOLDBOT_PANEL_PORT    panel TCP port, default 8199
    GOLDBOT_PANEL_TOKEN   reuse this token instead of the one already on the VPS

What it does, in order:
  1. packs src/, config/ and run_goldbot.py (no var/, .git/, __pycache__, *.db)
  2. uploads the tarball and refreshes /opt/goldbot
  3. creates /opt/goldbot/.venv (once) and installs fastapi + uvicorn + pydantic
  4. keeps the existing panel token or generates a new one, writes
     /etc/goldbot/panel.env (root-only, 0600)
  5. renders and installs scripts/systemd/goldbot-panel.service, enables+starts it
  6. verifies authenticated /api/health and that anonymous access returns 401
  7. allows the port through ufw only when ufw is already active

It never enables ufw, never edits nginx, never touches trading and never stores
the SSH password. The token is printed once at the end: treat it as a secret.

Exit status: 0 when the panel is live and authenticated, 1 otherwise (a failed
unit is stopped and disabled so the VPS is left clean).
"""

from __future__ import annotations

import argparse
import io
import os
import re
import secrets
import shlex
import sys
import tarfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
UNIT_SOURCE = ROOT / "scripts" / "systemd" / "goldbot-panel.service"

REMOTE_APP = "/opt/goldbot"
REMOTE_ENV_DIR = "/etc/goldbot"
REMOTE_ENV = "/etc/goldbot/panel.env"
REMOTE_UNIT = "/etc/systemd/system/goldbot-panel.service"
SERVICE = "goldbot-panel"
DEFAULT_PORT = 8199

PACK_PATHS = ("src", "config", "run_goldbot.py", "docs/DEPLOY-VPS.md")
SKIP_PARTS = {"__pycache__", ".git", ".venv", "var", "tests", "reports", "node_modules"}
SKIP_SUFFIXES = {".pyc", ".pyo", ".db", ".xlsx", ".jsonl"}
TOKEN_ENV = "GOLDBOT_PANEL_TOKEN"


class DeployError(RuntimeError):
    """A deployment step failed; the caller cleans up the remote unit."""


def _log(message: str) -> None:
    print(message, flush=True)


def _pack_repo() -> bytes:
    """Build an in-memory tar.gz of just the files the panel needs."""
    buffer = io.BytesIO()
    packed = 0
    with tarfile.open(fileobj=buffer, mode="w:gz") as archive:
        for name in PACK_PATHS:
            path = ROOT / name
            if not path.exists():
                raise DeployError(f"missing deploy input: {path}")
            candidates = [path] if path.is_file() else sorted(path.rglob("*"))
            for candidate in candidates:
                relative = candidate.relative_to(ROOT)
                parts = set(relative.parts)
                if parts & SKIP_PARTS:
                    continue
                if any(part.startswith("pytest-cache-files") for part in relative.parts):
                    continue
                if candidate.is_file() and candidate.suffix in SKIP_SUFFIXES:
                    continue
                if not candidate.is_file():
                    continue
                archive.add(candidate, arcname=str(relative).replace(os.sep, "/"))
                packed += 1
    if packed == 0:
        raise DeployError("deploy tarball is empty")
    _log(f"  packed {packed} files ({len(buffer.getvalue()) / 1024:.0f} KiB)")
    return buffer.getvalue()


def _run(ssh, command: str, *, check: bool = True, quiet: bool = False, redact: bool = False, timeout: int = 900):
    """Run one remote command and return (status, stdout, stderr)."""
    _, stdout, stderr = ssh.exec_command(command, timeout=timeout)
    out = stdout.read().decode("utf-8", "replace").strip()
    err = stderr.read().decode("utf-8", "replace").strip()
    status = stdout.channel.recv_exit_status()
    if not quiet:
        shown_command = "<redacted command>" if redact else command
        _log(f"  $ {shown_command}")
        if out:
            shown_out = "<redacted output>" if redact else out.replace("\n", "\n    ")[:4000]
            _log("    " + shown_out)
        if err:
            shown_err = "<redacted stderr>" if redact else err.replace("\n", "\n    ")[:2000]
            _log("    stderr: " + shown_err)
    if check and status != 0:
        shown_command = "<redacted command>" if redact else command
        shown_err = "<redacted stderr>" if redact else err[:800]
        raise DeployError(f"remote command failed ({status}): {shown_command}\n{shown_err}")
    return status, out, err


def _connect(host: str, user: str, password: str, key_path: str):
    try:
        import paramiko
    except ImportError as exc:  # pragma: no cover - ops machine dependency
        raise DeployError("paramiko is not installed: python -m pip install paramiko") from exc

    client = paramiko.SSHClient()
    # Never trust an unknown VPS host key on first contact. The operator must
    # verify and preload it in the local known_hosts file.
    client.load_system_host_keys()
    client.set_missing_host_key_policy(paramiko.RejectPolicy())
    kwargs = dict(
        username=user,
        timeout=20,
        banner_timeout=30,
        auth_timeout=30,
        allow_agent=False,
        look_for_keys=False,
    )
    if key_path:
        client.connect(host, key_filename=key_path, **kwargs)
    else:
        client.connect(host, password=password, **kwargs)
    transport = client.get_transport()
    if transport is not None:
        transport.set_keepalive(30)
    return client


def _preflight(ssh) -> None:
    _log("[1/7] preflight")
    status, python_version, _ = _run(
        ssh, "python3 -c 'import sys; print(\"%d.%d\" % sys.version_info[:2])'", quiet=True
    )
    major, minor = (int(part) for part in python_version.split(".", 1))
    if (major, minor) < (3, 12):
        raise DeployError(f"python3 {python_version} is too old (need >= 3.12)")
    _log(f"  python3 {python_version}")

    _, mem, _ = _run(ssh, "free -m | awk 'NR==2{print $7}'", quiet=True)
    available_mb = int(mem or "0")
    if available_mb < 100:
        _log(f"  warning: only {available_mb} MB RAM available; the panel needs ~100 MB")
    _, disk, _ = _run(ssh, "df -Pm / | awk 'NR==2{print $4}'", quiet=True)
    free_mb = int(disk or "0")
    if free_mb < 400:
        raise DeployError(f"only {free_mb} MB free on /; a venv needs more")
    _log(f"  free RAM {available_mb} MB, free disk {free_mb} MB")
    _run(ssh, "command -v curl >/dev/null && command -v tar >/dev/null", quiet=True)


def _upload(ssh, payload: bytes, port: int) -> str:
    _log("[2/7] upload + refresh tree")
    remote_tar = f"/tmp/goldbot-panel-{port}.tar.gz"
    sftp = ssh.open_sftp()
    try:
        sftp.putfo(io.BytesIO(payload), remote_tar)
    finally:
        sftp.close()
    _log(f"  uploaded {len(payload) / 1024:.0f} KiB to {remote_tar}")
    _run(
        ssh,
        f"mkdir -p {REMOTE_APP} /opt/goldbot/var && "
        f"rm -rf {REMOTE_APP}/src {REMOTE_APP}/config && "
        f"tar -xzf {remote_tar} -C {REMOTE_APP} && rm -f {remote_tar}",
    )
    _run(ssh, f"chmod 755 {REMOTE_APP} && ls -1 {REMOTE_APP}")
    return remote_tar


def _install_venv(ssh) -> None:
    _log("[3/7] virtualenv + dependencies")
    _run(
        ssh,
        f"test -x {REMOTE_APP}/.venv/bin/python || python3 -m venv {REMOTE_APP}/.venv",
        timeout=600,
    )
    _run(
        ssh,
        f"{REMOTE_APP}/.venv/bin/pip install --no-cache-dir --disable-pip-version-check "
        "fastapi>=0.110,<1 uvicorn>=0.29,<1 pydantic>=2.7,<3",
        timeout=900,
    )
    _run(
        ssh,
        f"{REMOTE_APP}/.venv/bin/python -c 'import fastapi, uvicorn, pydantic; print(\"deps ok\")'",
        quiet=True,
    )


def _ensure_token(ssh, cli_token: str) -> str:
    _log("[4/7] panel token")
    token = (cli_token or os.environ.get(TOKEN_ENV, "")).strip()
    if token:
        _log("  using token from the deployment environment")
    else:
        status, existing, _ = _run(
            ssh,
            f"test -f {REMOTE_ENV} && sed -n 's/^GOLDBOT_PANEL_TOKEN=//p' {REMOTE_ENV} | tail -1",
            check=False,
            quiet=True,
        )
        token = existing.strip() if status == 0 else ""
        if token:
            _log("  keeping the token already stored on the VPS")
        else:
            _, generated, _ = _run(
                ssh,
                "python3 -c 'import secrets; print(secrets.token_urlsafe(32))'",
                quiet=True,
            )
            token = generated.strip()
            _log("  generated a new 256-bit token")
    if len(token) < 24:
        raise DeployError("panel token is too short (need at least 24 characters)")
    if any(char in token for char in ("\r", "\n", "\x00")):
        raise DeployError("panel token must be a single-line value")
    _run(ssh, f"mkdir -p {REMOTE_ENV_DIR} && chmod 700 {REMOTE_ENV_DIR}")
    # Shell-quote the complete assignment and suppress command logging: the
    # token must never appear in local stdout/stderr or deployment logs.
    assignment = shlex.quote(f"{TOKEN_ENV}={token}")
    _run(
        ssh,
        f"printf '%s\\n' {assignment} > {REMOTE_ENV} && "
        f"chmod 600 {REMOTE_ENV} && chown root:root {REMOTE_ENV}",
        quiet=True,
        redact=True,
    )
    _, mode, _ = _run(ssh, f"stat -c '%a %U' {REMOTE_ENV}", quiet=True)
    _log(f"  {REMOTE_ENV} mode/owner: {mode}")
    return token


def _install_unit(ssh, port: int) -> None:
    _log("[5/7] systemd unit")
    template = UNIT_SOURCE.read_text(encoding="utf-8")
    rendered, replacements = re.subn(r"--port \d+", f"--port {int(port)}", template)
    if replacements != 1:
        raise DeployError("systemd template must contain exactly one --port <number>")
    sftp = ssh.open_sftp()
    try:
        with sftp.file(REMOTE_UNIT, "w") as handle:
            handle.write(rendered)
    finally:
        sftp.close()
    _run(ssh, "chmod 644 " + REMOTE_UNIT)
    _run(ssh, "systemctl daemon-reload && systemctl enable " + SERVICE)


def _health(ssh, port: int, *, authenticated: bool) -> str:
    header = (
        'set -a; . ' + REMOTE_ENV + '; set +a; '
        'curl -s -m 5 -o /dev/null -w "%{http_code}" '
        '-H "Authorization: Bearer $' + TOKEN_ENV + '" '
    ) if authenticated else 'curl -s -m 5 -o /dev/null -w "%{http_code}" '
    status, out, _ = _run(
        ssh, f"{header}http://127.0.0.1:{int(port)}/api/health", check=False, quiet=True
    )
    return out.strip() if status == 0 else f"curl-exit-{status}"


def _verify(ssh, port: int) -> None:
    _log("[6/7] verify")
    last = "n/a"
    for attempt in range(1, 21):
        last = _health(ssh, port, authenticated=True)
        if last in ("200", "503"):
            _log(f"  authenticated /api/health -> HTTP {last} (503 = degraded, still serving)")
            break
        time.sleep(3)
    else:
        raise DeployError(f"panel did not answer authenticated health (last: {last})")

    anonymous = _health(ssh, port, authenticated=False)
    if anonymous != "401":
        raise DeployError(f"anonymous /api/health returned {anonymous}, expected 401")
    _log("  anonymous /api/health -> HTTP 401 (token gate is enforced)")

    _, active, _ = _run(ssh, f"systemctl is-active {SERVICE}", quiet=True)
    if active.strip() != "active":
        raise DeployError(f"{SERVICE} is not active: {active!r}")
    _run(ssh, f"systemctl status {SERVICE} --no-pager --lines=0", check=False)
    _run(ssh, f"journalctl -u {SERVICE} --no-pager -n 12", check=False)


def _open_firewall(ssh, port: int) -> None:
    _log("[7/7] firewall")
    _, status, _ = _run(ssh, "ufw status | head -1", quiet=True)
    if "Status: active" not in status:
        _log("  ufw is inactive; not enabling it (could cut SSH)")
        return
    rule = f"{int(port)}/tcp"
    _, listing, _ = _run(ssh, "ufw status", quiet=True)
    if any(line.strip().startswith(rule) for line in listing.splitlines()):
        _log(f"  ufw already allows {rule}")
        return
    _run(ssh, f"ufw allow {rule}")
    _log(f"  ufw allowed {rule}")


def _summary(host: str, port: int, token: str) -> None:
    _log("")
    _log("=" * 64)
    _log("GoldBot panel is deployed and authenticated")
    _log(f"  URL          : http://{host}:{int(port)}/")
    _log(f"  Health       : http://{host}:{int(port)}/api/health")
    _log("  Auth         : HTTP Basic (any username, password = token) or Bearer token")
    _log(f"  Token        : {token}")
    _log(f"  SSH tunnel   : ssh -L {int(port)}:127.0.0.1:{int(port)} root@{host}")
    _log(f"  Logs         : journalctl -u {SERVICE} -f")
    _log(f"  Unit         : {REMOTE_UNIT}")
    _log(f"  Env (secret) : {REMOTE_ENV} (root 0600)")
    _log("  If the public URL times out, allow the port in the cloud security group.")
    _log("=" * 64)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Deploy the GoldBot panel to a VPS.")
    parser.add_argument("--host", default=os.environ.get("GOLDBOT_VPS_HOST", ""))
    parser.add_argument("--user", default=os.environ.get("GOLDBOT_VPS_USER", "root"))
    parser.add_argument(
        "--port", type=int, default=int(os.environ.get("GOLDBOT_PANEL_PORT", str(DEFAULT_PORT)))
    )
    parser.add_argument("--key", default=os.environ.get("GOLDBOT_VPS_KEY", ""))
    return parser


def main(argv: list[str] | None = None) -> int:
    # Remote output can carry UTF-8 (and Windows consoles default to cp1252):
    # never let an encoding error abort a deployment.
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            try:
                stream.reconfigure(encoding="utf-8", errors="replace")
            except Exception:  # noqa: BLE001 - best effort on legacy consoles
                pass
    args = build_parser().parse_args(argv)
    host = args.host.strip()
    password = os.environ.get("GOLDBOT_VPS_PASSWORD", "")
    if not host:
        print("GOLDBOT_VPS_HOST (or --host) is required", file=sys.stderr)
        return 2
    if not password and not args.key:
        print("GOLDBOT_VPS_PASSWORD (or --key) is required", file=sys.stderr)
        return 2
    if not UNIT_SOURCE.exists():
        print(f"missing unit template: {UNIT_SOURCE}", file=sys.stderr)
        return 2

    ssh = None
    try:
        _log(f"deploying GoldBot panel to {host} as {args.user} (port {args.port})")
        ssh = _connect(host, args.user, password, args.key)
        _preflight(ssh)
        payload = _pack_repo()
        _upload(ssh, payload, args.port)
        _install_venv(ssh)
        token = _ensure_token(ssh, os.environ.get(TOKEN_ENV, ""))
        _install_unit(ssh, args.port)
        _run(ssh, f"systemctl restart {SERVICE}")
        _verify(ssh, args.port)
        _open_firewall(ssh, args.port)
        _summary(host, args.port, token)
        return 0
    except DeployError as exc:
        print(f"\nDEPLOY FAILED: {exc}", file=sys.stderr)
        if ssh is not None:
            for cleanup in (
                f"systemctl stop {SERVICE}",
                f"systemctl disable {SERVICE}",
                f"rm -f /tmp/goldbot-panel-{int(args.port)}.tar.gz",
            ):
                try:
                    _run(ssh, cleanup, check=False, quiet=True, timeout=60)
                except Exception:  # noqa: BLE001 - cleanup is best effort
                    pass
            print(f"left the VPS clean: {SERVICE} stopped/disabled", file=sys.stderr)
        return 1
    except Exception as exc:  # noqa: BLE001 - report, never traceback secrets
        print(f"\nDEPLOY FAILED ({type(exc).__name__}): {exc}", file=sys.stderr)
        if ssh is not None:
            try:
                _run(ssh, f"systemctl stop {SERVICE}", check=False, quiet=True, timeout=60)
            except Exception:  # noqa: BLE001
                pass
        return 1
    finally:
        if ssh is not None:
            ssh.close()


if __name__ == "__main__":
    raise SystemExit(main())
