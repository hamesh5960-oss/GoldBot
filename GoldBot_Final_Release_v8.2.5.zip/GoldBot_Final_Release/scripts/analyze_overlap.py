"""How often do different strategies signal the same way at the same time?"""

from __future__ import annotations

import json
import sqlite3
import sys
from datetime import datetime


def main(db: str) -> None:
    conn = sqlite3.connect(db)
    conn.row_factory = sqlite3.Row
    rows = []
    for r in conn.execute("select ts,payload from events where type='SignalRaised'"):
        payload = json.loads(r["payload"])
        if payload.get("kind") != "entry":
            continue
        rows.append((datetime.fromisoformat(r["ts"]), payload.get("slot"), payload.get("side")))
    print("entry signals:", len(rows), "slots:", sorted({x[1] for x in rows}))
    for window in (30, 60, 120, 240, 1440):
        multi = 0
        for ts, slot, side in rows:
            others = {
                s
                for (t, s, sd) in rows
                if s != slot and sd == side and abs((t - ts).total_seconds()) <= window * 60
            }
            if others:
                multi += 1
        print(f"window {window}m -> signals with confirmation: {multi}")


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "var/report_medium_loose.db")
