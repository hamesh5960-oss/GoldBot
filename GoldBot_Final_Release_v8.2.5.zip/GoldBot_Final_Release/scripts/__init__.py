"""Deployment and operator scripts (importable for tests)."""
