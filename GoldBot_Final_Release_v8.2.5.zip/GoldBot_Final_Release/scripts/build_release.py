"""Build the GoldBot final release package.

Stages the source tree (without runtime state, VCS data and caches), writes
SHA256SUMS, and creates a deterministic-ish ZIP. Intended to be run from the
repository root:  python scripts/build_release.py
"""
from __future__ import annotations

import hashlib
import os
import shutil
import subprocess
import sys
import zipfile
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
NAME = "GoldBot_Final_Release"
VERSION = "8.2.5"
DIST = ROOT.parent / "dist"

SKIP_DIRS = {".git", "__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache",
             "node_modules", ".venv", "venv", "dist"}
SKIP_PATHS = {Path("var/live.db"), Path("var/live.db-wal"), Path("var/live.db-shm"),
              Path("var/live.state.db"), Path("var/live.state.db-wal"), Path("var/live.state.db-shm"),
              Path("var/live_risk_state.db")}
SKIP_SUFFIXES = {".pyc", ".pyo", ".log", ".jsonl", ".db", ".db-wal", ".db-shm"}
KEEP_EMPTY = {Path("var")}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def iter_files(root: Path):
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = sorted(d for d in dirnames if d not in SKIP_DIRS)
        base = Path(dirpath)
        rel_dir = base.relative_to(root)
        if rel_dir.parts and rel_dir.parts[0] == "var" and rel_dir != Path("var"):
            continue
        if rel_dir.parts and rel_dir.parts[0] == "reports" and "audit" not in rel_dir.parts:
            # keep audit/review evidence and the small journal exports only
            for name in sorted(filenames):
                rel = (rel_dir / name).as_posix()
                if rel.startswith("reports/") and Path(rel).suffix in {".md", ".csv", ".xlsx", ".json"}:
                    yield base / name
            continue
        for name in sorted(filenames):
            path = base / name
            rel = path.relative_to(root)
            if rel in SKIP_PATHS:
                continue
            if path.suffix in SKIP_SUFFIXES and rel.parts[0] == "var":
                continue
            if path.name.endswith((".pyc", ".pyo")):
                continue
            yield path


def stage() -> Path:
    target = DIST / NAME
    if target.exists():
        shutil.rmtree(target)
    target.mkdir(parents=True)
    count = 0
    for source in iter_files(ROOT):
        rel = source.relative_to(ROOT)
        destination = target / rel
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)
        count += 1
    for rel in KEEP_EMPTY:
        (target / rel).mkdir(parents=True, exist_ok=True)
    (target / "var" / ".gitkeep").write_text("", encoding="utf-8")
    try:
        commit = subprocess.run(["git", "rev-parse", "--short", "HEAD"], cwd=ROOT,
                                capture_output=True, text=True, check=False).stdout.strip()
    except Exception:  # noqa: BLE001
        commit = "unknown"
    info = (
        "GoldBot Final Release " + VERSION + "\n"
        "built_utc: " + datetime.now(tz=timezone.utc).isoformat(timespec="seconds") + "\n"
        "git_commit: " + (commit or "unknown") + "\n"
        "python: " + sys.version.split()[0] + "\n"
        "files: " + str(count) + "\n"
    )
    (target / "BUILD-INFO.txt").write_text(info, encoding="utf-8")
    return target


def write_sums(target: Path) -> int:
    lines = []
    for path in sorted(target.rglob("*")):
        if path.is_file() and path.name != "SHA256SUMS":
            lines.append(sha256(path) + "  " + path.relative_to(target).as_posix())
    (target / "SHA256SUMS").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return len(lines)


def make_zip(target: Path) -> Path:
    zip_path = DIST / (NAME + "_v" + VERSION + ".zip")
    if zip_path.exists():
        zip_path.unlink()
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(target.rglob("*")):
            if path.is_file():
                archive.write(path, (NAME + "/" + path.relative_to(target).as_posix()))
    return zip_path


def main() -> int:
    DIST.mkdir(parents=True, exist_ok=True)
    target = stage()
    count = write_sums(target)
    zip_path = make_zip(target)
    print("staged:", target)
    print("files:", count)
    print("sha256sums:", count)
    print("zip:", zip_path, "bytes:", zip_path.stat().st_size)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
