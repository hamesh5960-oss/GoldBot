import json
import sqlite3
import sys

path = sys.argv[1] if len(sys.argv) > 1 else "var/demo_medium.db"
c = sqlite3.connect(path)
c.row_factory = sqlite3.Row
for r in c.execute("select payload from events where type='RiskEvaluated'"):
    p = json.loads(r["payload"])
    if p.get("slot") == "ma_h1":
        print(
            "stop_distance=", p.get("stop_distance"),
            "entry=", p.get("entry_ref"),
            "spread=", p.get("spread"),
            "verdict=", p.get("verdict"),
            "reasons=", p.get("reasons"),
        )
        print("  checks:", [(x["name"], x["ok"], x["detail"]) for x in p["checks"] if not x["ok"]])
