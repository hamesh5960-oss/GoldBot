"""External dead-man switch for the GoldBot heartbeat file.

The process under test writes var/heartbeat.json every few minutes. This script
runs *outside* the process (Task Scheduler, cron, a second terminal) so a hung or
crashed engine is noticed even when it stops logging. It never trades, never
restarts the engine and never touches the database.

Usage:
    python scripts/watchdog.py --heartbeat var/heartbeat.json --max-age 900
    python scripts/watchdog.py --heartbeat var/heartbeat.json --json
    python scripts/watchdog.py --heartbeat var/heartbeat.json --no-notify

Exit status: 0 when the heartbeat is fresh, 1 when it is stale, missing or
unreadable (an alert is attempted before exiting).

Optional alert channels come from the environment, exactly like the engine:
    GOLDBOT_TELEGRAM_TOKEN, GOLDBOT_TELEGRAM_CHAT_ID (alias GOLDBOT_TELEGRAM_CHAT)
    GOLDBOT_SMTP_HOST, GOLDBOT_SMTP_PORT, GOLDBOT_SMTP_USER,
    GOLDBOT_SMTP_PASSWORD, GOLDBOT_SMTP_TO, GOLDBOT_SMTP_TLS

Windows Task Scheduler (every 5 minutes, absolute paths):
    schtasks /Create /TN "GoldBot watchdog" /SC MINUTE /MO 5 /TR ^
        "C:/Python/python.exe C:/GoldBot/scripts/watchdog.py --heartbeat C:/GoldBot/var/heartbeat.json"
cron:
    */5 * * * * cd /opt/goldbot && python scripts/watchdog.py --heartbeat var/heartbeat.json --max-age 900
"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping, Sequence

_SRC = Path(__file__).resolve().parents[1] / "src"
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

# A dead-man switch must survive a broken deployment: if the engine package no
# longer imports, fall back to a minimal local check instead of dying silently.
try:  # noqa: SIM105 - explicit fallback names matter for tests and operators
    from goldbot.adapters.notifier import from_env  # noqa: E402
except Exception as exc:  # noqa: BLE001 - any import failure disables alerts only
    from_env = None  # type: ignore[assignment]
    _NOTIFIER_IMPORT_ERROR: Exception | None = exc
else:
    _NOTIFIER_IMPORT_ERROR = None

try:  # noqa: SIM105
    from goldbot.app.heartbeat import Heartbeat  # noqa: E402
except Exception as exc:  # noqa: BLE001 - the local parser below is the fallback
    Heartbeat = None  # type: ignore[assignment]
    _HEARTBEAT_IMPORT_ERROR: Exception | None = exc
else:
    _HEARTBEAT_IMPORT_ERROR = None


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="watchdog.py",
        description="Alert and exit 1 when the GoldBot heartbeat file is stale.",
    )
    parser.add_argument("--heartbeat", required=True, help="path to the heartbeat JSON file")
    parser.add_argument(
        "--max-age",
        type=float,
        default=900.0,
        help="maximum accepted heartbeat age in seconds (default: 900)",
    )
    parser.add_argument("--json", action="store_true", help="print a machine-readable result")
    parser.add_argument(
        "--no-notify",
        action="store_true",
        help="do not attempt Telegram/SMTP alerts (exit status still reflects reality)",
    )
    return parser


def _local_check(
    heartbeat: str | Path,
    moment: datetime,
    max_age_seconds: float,
) -> tuple[bool, float | None, dict[str, Any]]:
    """Independent, stdlib-only staleness check used when goldbot cannot import."""
    try:
        data = json.loads(Path(heartbeat).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return True, None, {}
    if not isinstance(data, dict) or not isinstance(data.get("ts"), str):
        return True, None, {}
    try:
        last = datetime.fromisoformat(data["ts"])
    except ValueError:
        return True, None, {}
    if last.tzinfo is None:
        last = last.replace(tzinfo=timezone.utc)
    age = (moment - last).total_seconds()
    return age > float(max_age_seconds), age, data


def check(
    heartbeat: str | Path,
    max_age_seconds: float,
    now: datetime | None = None,
) -> tuple[bool, float | None, dict[str, Any]]:
    """Staleness check with a wall-clock fallback for use outside the engine."""
    moment = now if now is not None else datetime.now(timezone.utc)
    if moment.tzinfo is None:
        moment = moment.replace(tzinfo=timezone.utc)
    if Heartbeat is not None:
        return Heartbeat.is_stale(heartbeat, moment, max_age_seconds)
    return _local_check(heartbeat, moment, max_age_seconds)


def describe(
    heartbeat: str | Path,
    stale: bool,
    age_seconds: float | None,
    data: Mapping[str, Any],
    max_age_seconds: float,
) -> str:
    target = Path(heartbeat)
    if not stale:
        age = 0.0 if age_seconds is None else age_seconds
        return f"heartbeat fresh: {target} (age {age:.0f}s, limit {max_age_seconds:.0f}s)"
    if not target.exists():
        return f"heartbeat missing: {target}"
    if age_seconds is None:
        return f"heartbeat unreadable or has no valid timestamp: {target}"
    return (
        f"heartbeat stale: {target} age {age_seconds:.0f}s exceeds "
        f"{max_age_seconds:.0f}s (last ts {data.get('ts')}, pid {data.get('pid')})"
    )


def notify_stale(reason: str, environ: Mapping[str, str] | None = None) -> bool:
    """Alert the operator through whatever channel the environment configures."""
    if from_env is None:
        return False
    notifier = from_env(environ)
    if notifier is None:
        return False
    return bool(notifier.send("critical", "GoldBot heartbeat stale", reason))


def main(
    argv: Sequence[str] | None = None,
    *,
    now: datetime | None = None,
    environ: Mapping[str, str] | None = None,
) -> int:
    args = build_parser().parse_args(argv)
    stale, age_seconds, data = check(args.heartbeat, args.max_age, now)
    reason = describe(args.heartbeat, stale, age_seconds, data, args.max_age)
    notified = False
    if stale and not args.no_notify:
        notified = notify_stale(reason, environ)
    if args.json:
        print(
            json.dumps(
                {
                    "status": "stale" if stale else "fresh",
                    "path": str(args.heartbeat),
                    "max_age_seconds": args.max_age,
                    "age_seconds": age_seconds,
                    "ts": data.get("ts"),
                    "pid": data.get("pid"),
                    "reason": reason,
                    "notified": notified,
                },
                ensure_ascii=False,
            )
        )
    else:
        print(reason)
        if stale:
            if args.no_notify:
                print("alert: disabled by --no-notify")
            elif notified:
                print("alert: sent")
            else:
                print("alert: not sent (no channel configured or delivery failed)")
    return 1 if stale else 0


if __name__ == "__main__":
    raise SystemExit(main())
