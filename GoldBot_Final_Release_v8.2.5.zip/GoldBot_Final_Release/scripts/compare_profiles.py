import re
import subprocess
import sys
from pathlib import Path

profiles = ["low", "medium", "high"]
rows = []
for p in profiles:
    out = subprocess.run(
        [sys.executable, "run_goldbot.py", "demo", "--days", "20", "--profile", p, "--db", f"var/cmp_{p}.db"],
        capture_output=True,
        text=True,
        encoding="utf-8",
    )
    text = out.stdout
    def grab(label):
        m = re.search(re.escape(label) + r"[^:]*:\s*(.+)", text)
        return m.group(1).strip() if m else "-"
    rows.append(
        {
            "profile": p,
            "trades": grab("معاملات بسته‌شده"),
            "approve": grab("تأیید / رد ریسک"),
            "net": grab("سود/زیان خالص"),
            "win": grab("نرخ برد"),
            "pf": grab("ضریب سود"),
            "dd": grab("حداکثر افت سرمایه"),
            "state": grab("وضعیت نهایی ریسک"),
        }
    )

print(f"{'profile':<8}{'trades':<8}{'approve/reject':<16}{'net':<14}{'win%':<8}{'PF':<7}{'DD%':<8}{'state'}")
for r in rows:
    print(
        f"{r['profile']:<8}{r['trades']:<8}{r['approve']:<16}{r['net']:<14}{r['win']:<8}{r['pf']:<7}{r['dd']:<8}{r['state']}"
    )
Path("var/cmp_summary.txt").write_text(str(rows), encoding="utf-8")
