# چهارچوب معماری بات معاملاتی XAUUSD — مرحله ۰

> **یادداشت وضعیت:** این سند مرجع معماری تاریخی/زمینه‌ای است. در تعارض با کد جاری یا ADRهای 031 تا 046، ADR جدیدتر و `docs/HANDOFF-PROMPT.md` حاکم‌اند.

> نسخه سند: `0.1.0` · وضعیت: پیش‌نویس برای تأیید · مخاطب: یک مهندس/اپراتور (تیم یک‌نفره)
> این سند فقط **معماری** است. هیچ پیاده‌سازی‌ای در آن نیست؛ کد تنها در قالب `Protocol` / `dataclass` / `type alias` و صرفاً امضا.

---

## ۰. برداشت من از مسئله و سه ریسک اصلی

۱. مسئله «نوشتن بات» نیست؛ ساختن یک **ماشین حالت توزیع‌شده‌ی کوچک و قابل بازیابی** است که یک لایه‌ی استراتژی قابل‌تعویض دارد و مرزش با بروکر تا حد امکان تنگ و قابل حسابرسی است.
۲. بروکر **منبع حقیقت** است؛ هر چیزی که در حافظه داریم (پوزیشن، موجودی، حتی SL/TP) یک **کش مشتق‌شده و ابطال‌پذیر** است و باید بتواند هر لحظه بازسازی شود.
۳. واریانس اصلی نتیجه در XAUUSD از **اسپرد، گپ آخر هفته، اخبار و واگرایی وضعیت** می‌آید، نه از تأخیر. پس سرمایه‌گذاری مهندسی روی «صحت و بازیابی» است، نه روی «سرعت».
۴. با تیم یک‌نفره، «سادگی عملیاتی» یک **قید معماری** است: حداقل تعداد فرآیند در حال اجرا (۲)، حداقل فروشگاه داده (SQLite + Parquet)، استقرار تک‌دستوری، بدون Kubernetes/Redis/Kafka.
۵. برابری بک‌تست/لایو فقط با **یک قرارداد داده و یک کلاس استراتژی** ممکن است؛ هر شاخه‌ی `if backtest:` داخل استراتژی، شکست برابری است و در بازبینی کد رد می‌شود.

**سه ریسک اصلی (به ترتیب شدت):**

| # | ریسک | چرا خطرناک است | ستون دفاعی |
|---|---|---|---|
| R1 | **سفارش یتیم** (پنجره‌ی بین `order_send` و دریافت پاسخ) | یا سفارش گم می‌شود و پوزیشن بی‌محافظ می‌ماند، یا دوباره ارسال می‌شود و پوزیشن دوتایی می‌سازد | ژورنال قبل از ارسال + `idempotency_key` + حالت `UNKNOWN` + تطبیق با `magic`/`comment` (§۷، §۳.۴) |
| R2 | **واگرایی وضعیت** (ری‌استارت، reconnect، حساب netting) | سیستم فکر می‌کند فلت است در حالی که پوزیشن باز است؛ یا برعکس | reconcile اجباری در هر گذار اتصال + ممنوعیت ورود جدید تا پایان تطبیق (§۳.۳، §۶) |
| R3 | **اعتبار بک‌تست** (look-ahead، هزینه‌های غیرواقعی) | پارامترها روی داده‌ی آلوده به آینده بهینه می‌شوند؛ ریسک روی اعداد غلط کالیبره می‌شود | یک قرارداد داده، اجرا روی تیک ضبط‌شده، مدل هزینه‌ی اجباری، تست ضد look-ahead (§۱۱ مرحله B1) |

---

## ۰.۱. جدول مفروضات (Assumptions)

هر جا ابهام بود، مقدار زیر را مبنا گرفتم و ادامه دادم. اگر موردی را رد می‌کنی، بگو تا فقط همان بخش تغییر کند.

| # | موضوع | مفروضه | اثر معماری اگر تغییر کند |
|---|---|---|---|
| A1 | بروکر | ریتیل، MT5، نماد با پسوند (`XAUUSD.a` / `XAUUSD.m`) | نام نماد در کانفیگ و `symbol_map` در گیت‌وی؛ هسته هرگز نام خام نمی‌بیند |
| A2 | نوع حساب | **Hedging** (پیش‌فرض طراحی) | در §۱.۳ اثر netting جدا توضیح داده شده؛ `IPositionManager` دو پیاده‌سازی دارد |
| A3 | ارز حساب | USD، طلا با مظنه‌ی USD | تبدیل ارز فقط در لایه‌ی `Money`/`PnL`، نه در استراتژی |
| A4 | قرارداد | Contract size = 100 oz، tick = 0.01، min lot = 0.01، step = 0.01 | از `SymbolInfo` خوانده می‌شود، هرگز hard-code نمی‌شود |
| A5 | اهرم | 1:100 تا 1:500 (متغیر، قابل تغییر توسط بروکر) | `margin_rate` هر ساعت snapshot و در risk به‌روز می‌شود؛ تغییر ناگهانی رویداد است |
| A6 | هزینه | اسپرد شناور ۱۵–۳۵ point + کمیسیون/سواپ بر حسب بروکر | `CostModel` در بک‌تست و `SymbolInfo` در لایو؛ هر دو یک قرارداد |
| A7 | افق | Intraday تا swing، تصمیم روی کندل بسته (M5–M15) + چک‌های درون‌کندلی | تایم‌فریم در `IStrategy.timeframes` اعلامی است، نه در هسته |
| A8 | فرکانس | ۱ تا ۲۰ سفارش در روز، حداکثر ۵ استراتژی فعال | صف رویداد درون‌فرآیندی کافی است؛ نیازی به صف پیام‌رسان نیست |
| A9 | اتصال | VPS ویندوز برای ترمینال MT5 + هسته روی همان ماشین یا کانتینر لینوکس | معماری دو فرآیندی (§۱.۲) در هر دو حالت یکی است |
| A10 | زمان بروکر | معمولاً UTC+2/+3 با DST آمریکا، اما **قابل استنتاج است، نه فرض** | `IClock` آفست را از مقایسه‌ی `tick.time` و `ts_recv` تخمین و پایش می‌کند (§۴ قرارداد `IClock`) |
| A11 | ساعات طلا | یکشنبه شب تا جمعه شب UTC + وقفه‌ی روزانه (بر حسب بروکر) | تقویم در کانفیگ + `symbol_info.session_*`؛ منبع حقیقت تقویم بروکر است |
| A12 | سرمایه | کوچک/متوسط؛ ریسک هر معامله ۰.۲۵٪–۱٪ R | سقف‌های absolute در کانفیگ و `IRiskEngine` |
| A13 | خبر | تقویم اقتصادی از فایل CSV/API رایگان، اختیاری و قابل تنزل | نبودِ تقویم ⇒ `NewsFilter = UNKNOWN` ⇒ فیلتر محافظه‌کارانه در پنجره‌های پرخطر |
| A14 | هشدار | تلگرام (فقط خروجی، بدون دستور کنترلی) + ایمیل به‌عنوان fallback | توکن با `ISecretProvider`؛ ربات هیچ دستوری نمی‌پذیرد (§۱۰، ADR-15) |
| A15 | ML | در فاز اول نه | قرارداد `IStrategy` هر مدلی را جا می‌دهد، بدون تغییر هسته |
| A16 | مستندسازی | اسناد فارسی، کد/کامنت/نام‌ها انگلیسی | — |

---

## ۰.۲. دو انتخاب که واقعاً به شرایط تو بستگی دارد

**۱) FIX یا cTrader یا MT5؟**

| گزینه | چه زمانی درست است | هزینه |
|---|---|---|
| **MT5 Python API** (انتخاب من) | بروکر ریتیل MT5 می‌دهد؛ به SL/TP سمت بروکر، hedging، history و symbol_info نیاز داری | پکیج فقط ویندوز، همگام (blocking)، غیر thread-safe، بدون client-order-id بومی |
| **cTrader Open API** (REST + WebSocket) | حساب cTrader داری؛ می‌خواهی هسته روی لینوکس و بدون ترمینال اجرا شود | OAuth و مدیریت توکن؛ پوشش بروکرهای فارسی‌زبان کمتر |
| **FIX 4.4** | بروکر institutional/FIX ارائه می‌دهد؛ netting؛ حجم بالا؛ نیاز به `ClOrdID` واقعی و `ExecReport` | پیچیدگی پروتکل، session-level sequencing، هزینه‌ی پیاده‌سازی برای یک نفر توجیه ندارد |

معیار انتخاب: **اگر بروکرت FIX بومی با `ClOrdID` می‌دهد، FIX را انتخاب کن** چون مسئله‌ی «سفارش یتیم» را در سطح پروتکل حل می‌کند (نه با heuristic). در غیر این صورت MT5 + لایه‌ی idempotency محلی، که در §۴ طراحی شده. معماری به‌گونه‌ای است که تعویض این سه، فقط تعویض **آداپتور گیت‌وی** است.

**۲) یک فرآیند یا دو فرآیند؟**

| گزینه | معیار انتخاب |
|---|---|
| تک‌فرآیند ویندوزی (همه در یک پروسه) | فقط وقتی می‌خواهی در ۲ روز چیزی بالا بیاید؛ ساده‌ترین استقرار، اما هر کرش = از دست رفتن هسته و ترمینال با هم |
| **دو فرآیند: `core` + `broker_gateway`** (انتخاب من) | مرز شبکه‌ای، تست‌پذیری بدون MT5، امکان اجرای هسته روی لینوکس، بازسازی گیت‌وی بدون توقف هسته |

هزینه‌ی گزینه‌ی دوم: یک قرارداد IPC و یک سرویس اضافه برای مانیتور کردن. با یک نفر، این هزینه با «قابلیت تست بدون بروکر واقعی» (الزام ۷) و «کاهش دامنه‌ی خرابی» جبران می‌شود.

---

## ۱. نقشه‌ی ماژول‌ها

### ۱.۱. لایه‌ها

| لایه | پکیج | نقش در یک جمله |
|---|---|---|
| L0 دامنه | `goldbot.domain` | مدل بی‌طرف و خالصِ مفاهیم معاملاتی (سفارش، پوزیشن، پول، زمان، قواعد ریسک) بدون هیچ I/O |
| L1 کاربرد | `goldbot.app` | هم‌آهنگی use-caseها: چرخه‌ی معامله، اجرا، تطبیق، ریسک، میزبان استراتژی |
| L2 پورت | `goldbot.ports` | قراردادهای انتزاعی (Protocol) که L1 به آن‌ها تکیه می‌کند و L3 آن‌ها را پیاده می‌کند |
| L3 آداپتور | `goldbot.adapters` | پیاده‌سازی‌های فنی: MT5، تلگرام، SQLite، ساعت سیستم، فایل کانفیگ |
| L4 ترکیب | `goldbot.runtime` | تنها جایی که اشیای واقعی ساخته و به هم وصل می‌شوند (Composition Root) و چرخه‌ی عمر |
| SDK استراتژی | `goldbot.strategy_api` | تنها پکیجی که یک استراتژی مجاز است import کند |
| سرویس مرزی | `goldbot_gateway` | سرویس ویندوزی که تنها مصرف‌کننده‌ی `MetaTrader5` است |
| پژوهش | `goldbot.research` | بک‌تست، replay، بهینه‌سازی، تحلیل عملکرد؛ بیرون از مسیر لایو |

### ۱.۲. جدول ماژول‌ها: مسئولیت، مالکیت، و «چه چیزی اینجا نباید باشد»

| ماژول | مسئولیت (یک جمله) | مالک چیست | چه چیزی اینجا **نباید** باشد |
|---|---|---|---|
| `domain.model` | تعریف انواع تغییرناپذیر: `Price`، `Qty`، `Money`، `Ticket`، `Symbol`، `Tick`، `Bar` | معنا و اعتبارسنجی مقادیر (مثلاً `Qty` مضرب `volume_step`) | فراخوانی بروکر، خواندن کانفیگ، `datetime.now()` |
| `domain.events` | تعریف پاکت رویداد و کاتالوگ نوع‌ها با نسخه‌ی اسکیما | سازگاری رویدادها (schema evolution) | منطق تصمیم، I/O، سریال‌سازی مخصوص یک فروشگاه |
| `domain.fsm` | ماشین‌های وضعیت سفارش/پوزیشن/استراتژی/اتصال با گذارهای مجاز | «چه گذاری قانونی است» و «رویداد محرک چیست» | فراخوانی شبکه، تایمر، sleep |
| `domain.risk_policies` | قواعد خالص ریسک: sizing، سقف‌ها، drawdown، همبستگی، فیلترها | فرمول‌ها و آستانه‌ها به‌صورت تابع خالص | دسترسی به پوزیشن‌های واقعی، ارسال هشدار، نوشتن در DB |
| `domain.money` | تبدیل‌ها: point↔price، price↔PnL، حجم↔ریسک، ارز | ریاضیات پول و تبدیل واحد | نرخ ارز زنده، خواندن از بروکر |
| `app.strategy_host` | میزبانی چرخه‌ی حیات استراتژی‌ها، مسیریابی رویداد بازار، جمع‌آوری سیگنال | ترتیب و زمان‌بندی فراخوانی استراتژی | تفسیر سیگنال، سایزینگ، ارسال سفارش |
| `app.signal_pipeline` | تبدیل `Signal` به `Intent` و غنی‌سازی با context (اسپرد، سشن، پوزیشن) | ساخت intent قابل ارزیابی | تصمیم تأیید/رد (آن مال risk است) |
| `app.risk_engine` | ترکیب سیاست‌های ریسک، نگه‌داشتن latchها (HALTED/KILLED)، صدور `ApprovedOrder` | **تنها** صادرکننده‌ی مجوز ارسال سفارش | محاسبه‌ی fill، ارسال سفارش، دسترسی مستقیم به DB |
| `app.order_coordinator` | راندن FSM سفارش از intent تا ack/fill، تضمین idempotency، مدیریت timeout | وضعیت در حال پروازِ سفارش‌ها (in-flight) | تصمیم ریسک، محاسبه‌ی SL/TP استراتژیک |
| `app.position_manager` | نگه‌داشتن نمای مشتق‌شده‌ی پوزیشن‌ها و نگاشت `slot` استراتژی ↔ `ticket` بروکر | نگاشت و وضعیت مشتق‌شده | تماس با بروکر، تصمیم بستن (آن مال risk/strategy) |
| `app.reconciler` | مقایسه‌ی وضعیت داخلی با حقیقت بروکر و ترمیم/قرنطینه | الگوریتم تطبیق و تشخیص یتیم | ارسال سفارش جدید در حین تطبیق (ممنوع) |
| `app.session_supervisor` | FSM اتصال، heartbeat، backoff، gate ساعات معاملاتی | سلامت اتصال و مجوز «آماده بودن» | ساخت کلاینت، reconnect سطح سوکت (آن در گیت‌وی) |
| `app.snapshot_service` | ساخت و ذخیره‌ی snapshot وضعیت برای راه‌اندازی سریع و بازیابی | نقطه‌ی بازیابی (recovery point) | منطق معاملاتی |
| `ports.*` | اعلان قراردادها به‌صورت `Protocol` + تایپ‌های داده‌ای مشترک | شکل قرارداد | هیچ import از `adapters` یا `app` |
| `adapters.broker.client` | کلاینت RPC گیت‌وی (timeout، retry، circuit) | ترجمه‌ی پورت به پروتکل شبکه | منطق معاملاتی، تصمیم ریسک |
| `adapters.marketdata.live` | اشتراک تیک/کندل از گیت‌وی و نرمال‌سازی به `MarketEvent` | ترتیب و یکتاسازی رویدادها | ساخت کندل از تیک (آن در `bar_builder`) |
| `adapters.marketdata.tape` | پخش دوباره‌ی تیک ضبط‌شده با سرعت کنترل‌شده (replay) | وفاداری زمانی tape | هیچ تغییری در قرارداد داده |
| `adapters.journal.sqlite` | پیاده‌سازی `IEventStore` و `IJournal` روی SQLite با fsync | دوام نوشتن | محاسبه‌ی متریک، تصمیم |
| `adapters.notify.telegram` | ارسال هشدار با نرخ‌محدود و dedupe | تحویل پیام | پذیرش دستور از تلگرام (ممنوع) |
| `adapters.clock.system` | ساعت UTC + مونوتونیک + آفست بروکر | زمان | تغییر ساعت سیستم، fake progress |
| `adapters.config.loader` | بارگذاری TOML + overlay محیطی + اعتبارسنجی سختگیرانه | اعتبار پیکربندی در استارتاپ | ذخیره‌ی راز به‌صورت plaintext |
| `adapters.secrets.keyring` | واکشی راز از Windows DPAPI / keyring | محرمانگی | لاگ کردن مقدار، `repr` نشت‌دهنده |
| `runtime.bootstrap` | ساخت گراف اشیا و اجرای migration/بازیابی | سیم‌کشی | منطق دامنه |
| `runtime.supervisor` | چرخه‌ی عمر فرآیند، سیگنال‌های توقف، shutdown تمیز | ترتیب خاموش‌شدن | تصمیم معاملاتی |
| `goldbot_gateway.session` | نگه‌داشتن یک اتصال MT5 در یک ترد اختصاصی | انحصار تماس MT5 | تصمیم معاملاتی |
| `goldbot_gateway.router` | ترجمه‌ی درخواست‌ها به `order_send` و برگرداندن نتیجه‌ی خام + نرمال‌شده | ترجمه‌ی کدهای بازگشتی بروکر | ریسک، استراتژی |
| `goldbot_gateway.idempotency` | جدول پایدار `idempotency_key → ticket/result` | تضمین «حداکثر یک‌بار ارسال» | منطق دامنه |
| `goldbot_gateway.ratelimit` | محدودسازی نرخ فراخوانی بروکر (token bucket) | نرخ | — |
| `research.backtest` | موتور بک‌تست با همان پورت‌ها و پیاده‌سازی fake broker | مدل اجرا و هزینه | کد استراتژی مخصوص بک‌تست |
| `research.analysis` | متریک‌ها، MAE/MFE، walk-forward، گزارش | تحلیل | تصمیم لحظه‌ای |

### ۱.۳. مدل حساب: Hedging در برابر Netting

این تفاوت، معماری `IPositionManager` را تعیین می‌کند و نباید در زمان اجرا «کشف» شود.

| موضوع | Hedging (طراحی پیش‌فرض) | Netting (اثر روی معماری) |
|---|---|---|
| هویت پوزیشن | `(symbol, ticket)` — چند پوزیشن هم‌زمان روی یک نماد | `(symbol)` — فقط یک پوزیشن خالص |
| نگاشت استراتژی | هر پوزیشن با `magic` به یک `slot` استراتژی تعلق دارد؛ جداسازی کامل | جداسازی ممکن نیست؛ دو استراتژی مخالف همدیگر را حذف می‌کنند |
| SL/TP | روی هر ticket جداگانه | فقط روی پوزیشن خالص؛ SL/TP دو استراتژی قابل جمع نیست |
| بستن جزئی | `close(ticket, volume)` ساده | کاهش حجم پوزیشن خالص؛ اثرش به همه‌ی استراتژی‌های شریک نسبت داده می‌شود |
| ریسک | ریسک هر slot مستقل محاسبه می‌شود | ریسک باید در سطح پوزیشن خالص تجمیع شود؛ سقف‌های per-strategy بی‌معنا می‌شوند |
| تطبیق | تطبیق per-ticket با تشخیص «تخصیص‌نیافته» | تطبیق در سطح نماد؛ orphan معنا ندارد اما drift حجمی خطرناک است |

**نتیجه‌ی معماری:** `AccountModel` یک پورت است (`IHedgingModel` / `INettingModel`). در حالت netting، `RiskEngine` به‌صورت خودکار به «حالت تجمیعی» می‌رود: سقف‌های per-slot غیرفعال و سقف‌های per-symbol فعال می‌شوند، و در استارتاپ اگر `netting` تشخیص داده شد ولی کانفیگ multi-strategy دارد، سیستم **fail-closed** بالا نمی‌آید و خطای پیکربندی می‌دهد.

### ۱.۴. جریان داده در یک نگاه (سطح کانتینر)

```mermaid
flowchart LR
    MT5["MT5 Terminal (Windows)"] -->|"Python API (in-proc)"| GW["Broker Gateway<br/>single thread · idempotency · rate limit"]
    GW -->|"HTTP/JSON + WS (localhost)"| CL["Broker Client adapter"]
    CL --> CORE["Trading Core<br/>strategy · risk · execution · journal"]
    CORE --> DB[("SQLite WAL<br/>event store + journal")]
    CORE --> PQ[("Parquet<br/>ticks / bars / trades")]
    CORE --> TG["Telegram alerts"]
    CORE --> MET["Metrics /health endpoint"]
    TAPE["Recorded tapes"] --> CORE
    CORE --> BT["Backtest / Replay<br/>same ports, fake broker"]
```


---

## ۲. نمودار وابستگی و قواعد

### ۲.۱. نمودار وابستگی لایه‌ها

```mermaid
flowchart TD
    subgraph L4["L4 · Composition Root"]
        RT["runtime.bootstrap<br/>runtime.supervisor"]
    end

    subgraph L3["L3 · Adapters (فنی)"]
        AB["broker.client"]
        AM["marketdata.live / tape"]
        AJ["journal.sqlite"]
        AN["notify.telegram"]
        AC["clock.system"]
        ACG["config.loader / secrets"]
    end

    subgraph L1["L1 · Application"]
        SH["strategy_host"]
        SP["signal_pipeline"]
        RE["risk_engine"]
        OC["order_coordinator"]
        PM["position_manager"]
        RC["reconciler"]
        SS["session_supervisor"]
        SN["snapshot_service"]
    end

    subgraph L0["L0 · Domain (خالص)"]
        DM["model / money"]
        EV["events"]
        FS["fsm"]
        RP["risk_policies"]
    end

    P["L2 · ports (Protocol فقط)"]

    subgraph SB["مرز فرآیند"]
        GWY["goldbot_gateway<br/>(تنها مصرف‌کننده MetaTrader5)"]
    end

    subgraph PL["SDK پلاگین"]
        SA["strategy_api"]
        ST["strategies/*"]
    end

    RT --> L3
    RT --> L1
    L1 --> P
    L1 --> L0
    L3 --> P
    L3 --> L0
    AB -->|"HTTP/WS"| GWY
    ST --> SA
    SA --> L0

    style GWY fill:#ffe5e5,stroke:#c00
```

### ۲.۲. قواعد وابستگی (قابل اجرا، نه توصیه‌ای)

| # | قاعده | مرز ممنوعه |
|---|---|---|
| D1 | `domain` فقط به کتابخانه‌ی استاندارد و `typing` وابسته است | `domain → ports/adapters/app` ممنوع |
| D2 | `app` فقط به `domain` و `ports` وابسته است | `app → adapters` ممنوع (حتی برای تایپ) |
| D3 | `adapters` به `ports` و تایپ‌های `domain` وابسته است | `adapters → app` ممنوع |
| D4 | `ports` به هیچ چیز وابسته نیست؛ فقط `domain` برای تایپ | `ports → adapters` ممنوع |
| D5 | فقط `runtime` اجازه دارد همه‌جا را import کند | هر جای دیگر → `runtime` ممنوع |
| D6 | استراتژی فقط `goldbot.strategy_api` را می‌بیند | `strategy → adapters/app/domain.events` ممنوع؛ حتی `import MetaTrader5` |
| D7 | `MetaTrader5` فقط در `goldbot_gateway` | هر import دیگر = خطای CI |
| D8 | `research` می‌تواند `app`/`domain`/`ports` را ببیند | `research → adapters` فقط برای tape؛ `app → research` ممنوع |
| D9 | هیچ ماژولی `datetime.now()`، `time.time()`، `random` بدون seed، یا `os.environ` مستقیم صدا نمی‌زند | فقط `IClock`، `IRandomSource`، `ISettings` |
| D10 | هیچ ماژولی `print`/`logging.getLogger` مستقیم ندارد | فقط `ILogger` ساخت‌یافته با `correlation_id` |

**اجرای قواعد (۳ لایه‌ی دفاعی):**
1. **فیزیکی:** ساختار پکیج + `__init__.py` که فقط نام‌های مجاز را re-export می‌کند.
2. **CI:** `import-linter` با قراردادهای `forbidden` و `layers` (مثلاً `layers = domain | ports | app | adapters | runtime`)، به‌همراه یک تست که AST تمام فایل‌های `strategies/` را می‌پیماید و هر import خارج از `strategy_api` را رد می‌کند.
3. **بازبینی:** چک‌لیست PR سه سؤال دارد: آیا به سمت دامنه وابسته شدی؟ آیا `now()` مستقیم زدی؟ آیا راز یا مقدار حساسی لاگ شد؟

### ۲.۳. قاعده‌ی «هسته از زیرساخت خبر ندارد» در عمل

- `RiskEngine` نمی‌داند بروکر MT5 است یا FIX؛ فقط `PortfolioSnapshot` می‌بیند.
- `OrderCoordinator` نمی‌داند HTTP است یا ZMQ؛ فقط `IBrokerGateway.submit(...)` را صدا می‌زند.
- `IStrategy` نمی‌داند بک‌تست است یا لایو؛ فقط `MarketEvent` و `StrategyContext` می‌بیند.
- نتیجه: هر سه‌ی این‌ها با یک `FakeBroker` + `TapeFeed` تست می‌شوند، بدون نصب MT5 (الزام ۷).

---

## ۳. جریان داده و کنترل

### ۳.۱. راه‌اندازی سرد و بازیابی وضعیت (Cold Start / Recovery)

```mermaid
sequenceDiagram
    autonumber
    participant SV as Supervisor
    participant CFG as Config+Secrets
    participant DB as EventStore
    participant G as Gateway
    participant RC as Reconciler
    participant PM as PositionManager
    participant RK as RiskEngine
    participant SH as StrategyHost

    SV->>CFG: load + validate (strict)
    alt config invalid
        CFG-->>SV: ConfigError
        SV-->>SV: exit non-zero (no trading)
    end
    SV->>DB: migrate + last_seq
    SV->>G: connect()
    G-->>SV: ConnectionInfo(server, account, mode, offset)
    SV->>SV: assert account_id/hedging matches config
    SV->>G: account() + positions() + orders()
    G-->>RC: BrokerTruth snapshot
    RC->>DB: read open intents (status in-flight)
    RC->>PM: reconcile(truth, intents)
    alt divergence found
        PM-->>RC: ReconcileReport(missing / orphan / volume_drift)
        RC->>DB: append(DivergenceDetected)
        RC->>RK: request_state(QUARANTINE)
        RK-->>SV: trading disabled
        SV->>SV: alert human (fail-closed, no auto-fix beyond policy)
    else clean
        RC->>DB: append(ReconcileCompleted)
        RC->>RK: request_state(NORMAL)
    end
    SV->>SH: start(strategies)
    SH->>SH: warmup(history) → READY
    SH-->>SV: all READY or FAILED
    SV->>SV: subscribe market data → ACTIVE
```

**قواعد این سناریو:**
- ترتیب اجباری: `config → store → connect → snapshot → reconcile → risk → strategy → subscribe`. هیچ مرحله‌ای قابل جابه‌جایی نیست.
- اگر `reconcile` تمیز نبود، سیستم در `QUARANTINE` می‌ماند؛ استراتژی‌ها لود می‌شوند ولی سیگنال‌هایشان فقط ژورنال می‌شود و ارسال نمی‌شود.
- مقایسه‌ی `account_id` و `trade_mode` با کانفیگ اجباری است (جلوگیری از اجرا روی حساب اشتباه — خطای اپراتور).

### ۳.۲. مسیر داغ: تیک/کندل → استراتژی → سیگنال → ریسک → سفارش → فیل → ژورنال

```mermaid
sequenceDiagram
    autonumber
    participant FD as MarketDataFeed
    participant BB as BarBuilder
    participant SH as StrategyHost
    participant ST as IStrategy
    participant SP as SignalPipeline
    participant RK as RiskEngine
    participant OC as OrderCoordinator
    participant G as BrokerGateway
    participant PM as PositionManager
    participant J as EventStore/Journal

    FD->>BB: Tick(bid, ask, ts_event)
    BB->>SH: BarUpdated (فقط برای استراتژی‌های همان TF)
    Note over BB: کندل ناقص هرگز «بسته» اعلام نمی‌شود
    BB->>SH: BarClosed(bar, is_closed=true)
    SH->>ST: on_market(ctx, event)
    ST-->>SH: Signal[] (Entry / Exit / Adjust / Noop)
    SH->>J: append(SignalRaised) [با correlation_id]
    SH->>SP: to_intent(signal, ctx)
    SP->>SP: غنی‌سازی: spread, session, atr, equity
    SP->>RK: evaluate_entry(intent, risk_ctx)
    RK->>RK: sizing + caps + drawdown + filters + correlation
    alt rejected
        RK-->>SP: Rejected(reason_codes)
        SP->>J: append(RiskRejected) [کامل با اعداد]
    else approved
        RK-->>OC: ApprovedOrder(unforgeable token)
        OC->>J: append(OrderIntentApproved) [fsync قبل از هر I/O]
        OC->>G: submit(approved, idempotency_key)
        G->>G: dedupe table check
        G-->>OC: ack(order_ticket, retcode)
        OC->>J: append(OrderAcked)
        G-->>FD: Fill / Deal event
        G->>PM: apply(Fill)
        PM->>J: append(PositionOpened/Modified)
        PM->>RK: on_portfolio_update(snapshot)
        OC->>J: append(OrderFilled)
    end
```

**سه تضمین در این مسیر:**
1. **ژورنال قبل از شبکه:** `OrderIntentApproved` با `fsync` نوشته می‌شود، بعد `submit` صدا زده می‌شود. اگر فرآیند همان‌جا بمیرد، بازیابی می‌داند «یک intent در حال پرواز» داشته و باید تطبیق کند.
2. **`ApprovedOrder` جعل‌ناپذیر است:** فقط `RiskEngine` می‌تواند آن را بسازد (سازنده‌ی خصوصی + توکن داخلی). `OrderCoordinator` هر چیز دیگری را رد می‌کند. هیچ مسیر میان‌بری برای ارسال سفارش بدون ریسک وجود ندارد.
3. **`BarClosed` تنها محرک تصمیم ورودی است.** `BarUpdated` فقط برای مدیریت پوزیشن (trailing) مصرف می‌شود. این قاعده، look-ahead را در سطح معماری حذف می‌کند، نه با نظم‌دهی کد.

**ترتیب ثابت decision timestamps:** `ts_event` (بروکر) → `ts_recv` (دریافت) → `ts_decision` (پایان ریسک) → `ts_send` (خروج از فرآیند). هر چهار در ژورنال ثبت می‌شوند تا تأخیر هر مرحله قابل اندازه‌گیری باشد.

### ۳.۳. قطع اتصال در وسط ارسال سفارش → Reconnect → Reconcile

این سناریو، مهم‌ترین سناریوی سیستم است و باید صریح طراحی شود.

```mermaid
sequenceDiagram
    autonumber
    participant OC as OrderCoordinator
    participant J as EventStore
    participant G as Gateway
    participant B as MT5 Terminal

    OC->>J: append(OrderIntentApproved) [fsync]
    OC->>G: submit(approved, idem_key)
    G->>B: order_send(...)
    Note over G,B: قطع ارتباط / timeout بدون پاسخ
    G-->>OC: SubmitUncertain(reason=timeout|disconnect)
    OC->>OC: FSM: SUBMITTING → UNKNOWN
    OC->>J: append(OrderUnknown) [shutdown of new entries]
    Note over OC,RK: RiskEngine → HALTED_NEW_ENTRIES (fail-closed)
    OC->>G: health()
    G-->>OC: DISCONNECTED
    loop backoff نمایی با jitter، سقف محدود
        OC->>G: connect()
    end
    G-->>OC: RESTORED
    OC->>G: positions() + orders() + deals(since=ts_send)
    G-->>OC: BrokerTruth
    alt سفارش با magic/comment/idem_key در بروکر یافت شد
        OC->>OC: UNKNOWN → ADOPTED (ticket معلوم شد)
        OC->>J: append(Order ResolvedPresent)
        OC->>OC: ادامه‌ی عادی: ack/fill
    else یافت نشد
        OC->>OC: UNKNOWN → RESOLVED_ABSENT
        OC->>J: append(OrderResolvedAbsent)
    end
    OC->>OC: reconcile کامل پرتفوی (بدون استثنا)
    OC->>J: append(ReconcileCompleted)
    OC->>OC: رفع قفل ورود جدید فقط پس از clean reconcile
```

**سیاست‌های قطعی این سناریو:**
- **هیچ ارسال مجدد کورکورانه‌ای وجود ندارد.** تلاش دوباره فقط پس از «جست‌وجوی قطعی» در بروکر مجاز است؛ جست‌وجو با `magic` + بازه‌ی زمانی + `comment` حاوی `client_ref` انجام می‌شود.
- **`idempotency_key` پایدار است** و در گیت‌وی نگه‌داری می‌شود؛ حتی اگر هسته ری‌استارت شود، همان کلید دوباره ارسال شود، گیت‌وی همان نتیجه‌ی قبلی را برمی‌گرداند (نه سفارش دوم).
- **قفل ورود جدید (`HALTED_NEW_ENTRIES`) تا پایان تطبیق باز نمی‌شود.**
- **حداکثر یک `UNKNOWN` در هر لحظه مجاز است**؛ اگر سفارش دوم هم به `UNKNOWN` برود، سیستم به `KILLED` می‌رود (نشانه‌ی خرابی سیستمی، نه شبکه‌ای).

### ۳.۴. فعال‌شدن Kill Switch یا عبور از حد ضرر روزانه

```mermaid
sequenceDiagram
    autonumber
    participant R as RiskEngine
    participant K as KillSwitch
    participant OC as OrderCoordinator
    participant G as Gateway
    participant PM as PositionManager
    participant J as EventStore
    participant N as Notifier

    R->>R: daily_pnl reaches -daily_loss_limit
    R->>K: engage(reason=DAILY_LOSS, actor=system)
    K->>K: state = HALTED (latch، فقط ack انسانی رفع می‌کند)
    K->>J: append(KillSwitchEngaged) [fsync]
    K->>OC: cancel_all(pending_orders)
    OC->>G: cancel(ticket...) for each
    K->>PM: policy: flatten? (config: flatten_on_kill=true/false)
    alt flatten_on_kill
        PM->>G: close(each position, reason=KILL)
    end
    G-->>PM: ExecutionReport
    K->>J: append(FlattenCompleted)
    K->>N: alert(critical, dedup_key=kill-YYYYMMDD)
    N-->>K: delivered
    Note over K: تا ack انسانی هیچ سفارش جدیدی صادر نمی‌شود
```

**سطوح kill switch (هر کدام latch جدا و علت جدا):**

| سطح | محرک | اثر | رفع |
|---|---|---|---|
| `SOFT` | اسپرد غیرعادی، داده‌ی کهنه، drift ساعت | توقف ورود جدید؛ مدیریت پوزیشن ادامه دارد | خودکار پس از پاک‌شدن شرط (با هیسترزیس) |
| `HARD` | حد ضرر روزانه، خطای منطقی، دو `UNKNOWN` | توقف همه‌ی سفارش‌ها؛ بستن سفارش‌های معلق | **فقط ack انسانی** |
| `KILL` | نقض سقف کلی drawdown، خطای امنیتی، فرمان اپراتور | بستن فوری همه‌ی پوزیشن‌ها + قطع استراتژی‌ها | **فقط ack انسانی + بازبینی** |

**منابع فعال‌سازی:** (۱) موتور ریسک، (۲) اپراتور از طریق CLI محلی روی VPS، (۳) دِد-من‌سوییچ بیرونی (اگر heartbeat نرسید، هشدار؛ اما هرگز به‌صورت خودکار معامله نمی‌کند)، (۴) تایمر «پوزیشن بدون SL بیش از N ثانیه».
**ممنوع:** دستور kill از تلگرام. تلگرام فقط خروجی است (سطح حمله‌ی کمتر، بدون نیاز به احراز هویت دوطرفه).


---

## ۴. قراردادهای بین لایه‌ها (فقط امضا)

قراردادها در `goldbot.ports` و `goldbot.domain` تعریف می‌شوند. همه‌ی تایپ‌ها `frozen=True` و تغییرناپذیرند؛ هیچ دیکشنری بی‌ساختار از مرزها عبور نمی‌کند.

### ۴.۱. تایپ‌های پایه

```python
# goldbot/domain/model.py
from typing import NewType, Literal, TypeAlias
from datetime import datetime

Symbol      = NewType("Symbol", str)        # نام منطقی، مثلاً "XAUUSD"
Ticket      = NewType("Ticket", int)        # شناسه‌ی بروکر
OrderId     = NewType("OrderId", int)
DealId      = NewType("DealId", int)
Price       = NewType("Price", float)       # همیشه در واحد قیمت نماد
Volume      = NewType("Volume", float)      # لات
StrategyId  = NewType("StrategyId", str)
SlotId      = NewType("SlotId", str)        # نمونه‌ی فعال یک استراتژی
IntentId    = NewType("IntentId", str)      # ULID؛ کلید correlation سراسری

class Money(NamedTuple):
    amount: Decimal
    currency: str                            # "USD"

class Ts(NamedTuple):
    utc: datetime                            # آگاه به timezone، همیشه UTC
    mono: float                              # monotonic، برای اندازه‌گیری تأخیر

Timeframe: TypeAlias = Literal["M1", "M5", "M15", "H1", "H4", "D1"]

class Tick(NamedTuple):
    symbol: Symbol
    bid: Decimal
    ask: Decimal
    ts_event: Ts                            # زمان بروکر/منبع
    ts_recv: Ts                             # زمان دریافت محلی
    volume: int | None

class Bar(NamedTuple):
    symbol: Symbol
    timeframe: Timeframe
    open_time: datetime                      # UTC، شروع بازه
    o: Decimal; h: Decimal; l: Decimal; c: Decimal
    tick_volume: int
    spread_avg: Decimal | None
    is_closed: bool                          # تنها کندل بسته مجاز به تولید ورود است
    ts_recv: Ts
    revision: int                            # شماره‌ی بازنگری برای کندل در حال ساخت

class SymbolInfo(NamedTuple):
    symbol: Symbol
    broker_symbol: str                       # "XAUUSD.a"
    digits: int
    point: Decimal                           # 0.01
    tick_size: Decimal
    contract_size: Decimal                   # 100
    min_volume: Decimal
    max_volume: Decimal
    volume_step: Decimal
    stops_level_points: int                  # حداقل فاصله SL/TP
    freeze_level_points: int
    margin_rate: Decimal                     # نرخ مارجین جاری (تغییرپذیر)
    currency_base: str
    currency_profit: str
    swap_long: Decimal; swap_short: Decimal
    trade_mode: Literal["full", "longonly", "shortonly", "closeonly", "disabled"]
    session_quotes: tuple[SessionWindow, ...] # به وقت سرور
    broker_time_offset: timedelta             # استنتاج‌شده، همراه با عدم‌قطعیت

class AccountSnapshot(NamedTuple):
    login: int
    server: str
    currency: str
    balance: Money
    equity: Money
    margin: Money
    free_margin: Money
    margin_level: Decimal | None
    leverage: int
    trade_mode: Literal["hedging", "netting"]
    ts: Ts

class PositionSnapshot(NamedTuple):
    ticket: Ticket
    symbol: Symbol
    side: Literal["buy", "sell"]
    volume: Decimal
    open_price: Decimal
    sl: Decimal | None
    tp: Decimal | None
    magic: int
    comment: str
    open_time: datetime
    profit: Money
    swap: Money
    commission: Money

class OrderSnapshot(NamedTuple):
    ticket: Ticket
    symbol: Symbol
    type: Literal["market", "limit", "stop", "stop_limit"]
    side: Literal["buy", "sell"]
    volume: Decimal
    price: Decimal
    sl: Decimal | None
    tp: Decimal | None
    state: Literal["placed", "partial", "filled", "canceled", "rejected", "expired"]
    magic: int
    comment: str
    created_at: datetime
    filled_volume: Decimal
```

### ۴.۲. `IBrokerGateway`

```python
# goldbot/ports/broker.py
from typing import Protocol, Sequence, Iterator, Literal

class ConnectionInfo(NamedTuple):
    server: str
    login: int
    trade_mode: Literal["hedging", "netting"]
    broker_time_offset: timedelta
    terminal_build: int

class BrokerEvent(Protocol): ...             # union tag: OrderEvent | DealEvent | PositionEvent | AccountEvent

class SubmitUncertain(Exception):
    """نتیجه نامعلوم است. به‌معنای شکست نیست؛ به‌معنای «نمی‌دانم»."""
    reason: Literal["timeout", "disconnected", "ambiguous_retcode"]

class IBrokerGateway(Protocol):
    # --- چرخه‌ی اتصال ---
    def connect(self) -> ConnectionInfo: ...
    def disconnect(self) -> None: ...
    def health(self) -> "GatewayHealth": ...          # alive / latency_ms / last_tick_age / queue_depth
    def is_ready(self) -> bool: ...

    # --- خواندن (idempotent، قابل retry) ---
    def symbol_info(self, symbol: Symbol) -> SymbolInfo: ...
    def account(self) -> AccountSnapshot: ...
    def positions(self, *, symbol: Symbol | None = None) -> Sequence[PositionSnapshot]: ...
    def orders(self, *, symbol: Symbol | None = None) -> Sequence[OrderSnapshot]: ...
    def deals(self, *, since: datetime, until: datetime | None = None) -> Sequence["DealRecord"]: ...
    def history_bars(self, symbol: Symbol, tf: Timeframe, count: int) -> Sequence[Bar]: ...

    # --- نوشتن (idempotent با کلید) ---
    def submit(self, order: "ApprovedOrder", *, idempotency_key: str) -> "OrderAck": ...
    def modify(self, ticket: Ticket, *, sl: Decimal | None, tp: Decimal | None,
               idempotency_key: str) -> "OrderAck": ...
    def cancel(self, ticket: Ticket, *, idempotency_key: str) -> "OrderAck": ...
    def close(self, ticket: Ticket, *, volume: Decimal | None,
              idempotency_key: str) -> "OrderAck": ...

    # --- کشف سفارش یتیم ---
    def find_by_client_ref(self, client_ref: str, *, since: datetime) -> Sequence[OrderSnapshot]: ...

    # --- جریان ---
    def events(self) -> Iterator[BrokerEvent]: ...    # بلاک‌کننده؛ توسط runtime در ترد/تسک جدا
```

```python
# goldbot/domain/execution.py
class OrderAck(NamedTuple):
    intent_id: IntentId
    accepted: bool
    ticket: Ticket | None
    retcode: int
    retcode_name: str                          # "DONE" | "REQUOTE" | "INVALID_STOPS" | ...
    broker_message: str                        # فقط برای لاگ؛ هرگز شامل راز نیست
    fill_price: Decimal | None
    filled_volume: Decimal
    ts_ack: Ts

class ApprovedOrder(NamedTuple):
    """فقط RiskEngine می‌تواند بسازد. OrderCoordinator هر چیز دیگری را رد می‌کند."""
    intent_id: IntentId
    slot: SlotId
    symbol: Symbol
    side: Literal["buy", "sell"]
    volume: Decimal
    order_type: Literal["market", "limit"]
    limit_price: Decimal | None
    sl: Decimal | None                         # اجباری برای ورود (config: require_sl)
    tp: Decimal | None
    magic: int                                 # (strategy_version_id << 16) | slot_no
    client_ref: str                            # در comment بروکر؛ ≤ 31 کاراکتر
    max_slippage_points: int
    deviation_policy: Literal["reject", "fill"]
    expires_at: datetime | None
    risk_snapshot: "RiskSnapshot"              # عکس فوری اعدادی که مجوز را توجیه می‌کنند
    _token: "ApprovalToken"                    # سازنده‌ی خصوصی؛ در risk_engine مهر می‌شود
```

`ApprovalToken` یک `Final` کلاس بدون سازنده‌ی عمومی است که فقط `risk_engine` نمونه‌سازی می‌کند؛ `OrderCoordinator` صحت توکن را بررسی می‌کند. این «زیردریایی» نیست، اما مسیر میان‌بر را در سطح API حذف می‌کند.

### ۴.۳. `IMarketDataFeed` + مدل داده

```python
# goldbot/ports/marketdata.py
MarketEvent: TypeAlias = Tick | Bar | "SessionEvent" | "NewsEvent" | "Heartbeat"

class MarketSnapshot(NamedTuple):
    symbol: Symbol
    last_tick: Tick | None
    last_bar: dict[Timeframe, Bar]
    spread: Decimal
    ts: Ts

class IMarketDataFeed(Protocol):
    def subscribe(self, symbol: Symbol, *, ticks: bool,
                  bars: Sequence[Timeframe]) -> None: ...
    def unsubscribe(self, symbol: Symbol) -> None: ...
    def events(self) -> Iterator[MarketEvent]: ...     # ترتیب‌دار، تک‌مصرف
    def last_known(self, symbol: Symbol) -> MarketSnapshot | None: ...
    def staleness(self, symbol: Symbol) -> timedelta: ...
    def replay(self, *, from_ts: datetime, to_ts: datetime,
               speed: float) -> Iterator[MarketEvent]: ...   # فقط tape
```

**قرارداد «یک داده برای سه حالت»:** لایو و replay هر دو `MarketEvent` تولید می‌کنند و `BarBuilder` یکی است. موتور بک‌تست هم با `TapeFeed` + `FakeBroker` کار می‌کند. هیچ `is_backtest` در قرارداد وجود ندارد.

### ۴.۴. `IStrategy` و `StrategyContext`

```python
# goldbot/strategy_api/__init__.py  ← تنها سطح مجاز برای استراتژی
from typing import Protocol, Sequence, Type
from pydantic import BaseModel

class Signal(NamedTuple):
    kind: Literal["entry", "exit", "adjust", "noop"]
    slot: SlotId
    symbol: Symbol
    side: Literal["buy", "sell"] | None
    entry_hint: Decimal | None
    stop_hint: Decimal | None
    target_hint: Decimal | None
    confidence: float                          # 0..1؛ برای تخصیص ریسک، نه برای تأیید
    rationale: str                             # متن کوتاه و قابل‌جست‌وجو در ژورنال
    tags: Mapping[str, str]                    # پارامترهای مؤثر در تصمیم

class HistoryView(Protocol):
    def bars(self, tf: Timeframe, count: int) -> Sequence[Bar]: ...
    def ticks(self, from_ts: datetime, count: int) -> Sequence[Tick]: ...

class StrategyContext(Protocol):
    """نمای فقط‌خواندنی. هیچ مسیری به بروکر ندارد."""
    @property
    def now(self) -> Ts: ...
    @property
    def slot(self) -> SlotId: ...
    @property
    def symbol_info(self) -> SymbolInfo: ...
    @property
    def params(self) -> BaseModel: ...
    def bars(self, tf: Timeframe, count: int) -> Sequence[Bar]: ...
    def last_tick(self) -> Tick | None: ...
    def position(self) -> "StrategyPositionView | None": ...   # فقط پوزیشن‌های همین slot
    def portfolio(self) -> "PortfolioView": ...                # فقط‌خواندنی، برای فیلتر همبستگی
    def log(self) -> "Logger": ...

class IStrategy(Protocol):
    id: str
    version: str
    timeframes: Sequence[Timeframe]
    warmup_bars: int
    params_schema: Type[BaseModel]
    max_concurrent_positions: int

    def on_init(self, ctx: StrategyContext) -> None: ...
    def on_warmup(self, ctx: StrategyContext, history: HistoryView) -> None: ...
    def on_market(self, ctx: StrategyContext, ev: MarketEvent) -> Sequence[Signal]: ...
    def on_fill(self, ctx: StrategyContext, fill: "Fill") -> None: ...
    def on_timer(self, ctx: StrategyContext) -> Sequence[Signal]: ...
    def on_stop(self, ctx: StrategyContext, reason: "StopReason") -> None: ...
```

**قاعده‌ی طلایی:** استراتژی **فقط سیگنال** تولید می‌کند، نه سفارش. تبدیل سیگنال به تصمیم (سایز، SL نهایی، عبور از فیلترها) در `signal_pipeline` + `risk_engine` است. این تفکیک، هم تست استراتژی را ساده می‌کند و هم اجازه می‌دهد سقف‌های ریسک بدون دست‌زدن به استراتژی تغییر کنند.

### ۴.۵. `IRiskEngine`

```python
# goldbot/ports/risk.py
class RiskState(Enum):
    NORMAL = auto(); SOFT_HALT = auto(); HALTED = auto(); KILLED = auto(); QUARANTINE = auto()

class ReasonCode(Enum):
    SPREAD_TOO_WIDE = auto(); STALE_DATA = auto(); SESSION_CLOSED = auto()
    NEWS_WINDOW = auto(); DAILY_LOSS_LIMIT = auto(); TOTAL_DD_LIMIT = auto()
    MAX_POSITIONS = auto(); MAX_LEVERAGE = auto(); CORRELATION_LIMIT = auto()
    INSUFFICIENT_MARGIN = auto(); SL_TOO_TIGHT = auto(); SL_TOO_WIDE = auto()
    VOLUME_BELOW_MIN = auto(); VOLUME_ABOVE_MAX = auto(); CLOCK_DRIFT = auto()
    RISK_STATE_BLOCKED = auto(); UNKNOWN_STATE = auto()

class RiskDecision(NamedTuple):
    verdict: Literal["approve", "reject", "defer"]
    order: ApprovedOrder | None
    reasons: tuple[ReasonCode, ...]
    checks: tuple["CheckResult", ...]          # هر چک: نام، ورودی، آستانه، نتیجه
    valid_until: datetime | None               # برای defer

class IRiskEngine(Protocol):
    # pre-trade
    def evaluate_entry(self, intent: "EntryIntent", ctx: "RiskContext") -> RiskDecision: ...
    def evaluate_exit(self, intent: "ExitIntent", ctx: "RiskContext") -> RiskDecision: ...
    def evaluate_adjust(self, intent: "AdjustIntent", ctx: "RiskContext") -> RiskDecision: ...
    # in-trade
    def evaluate_management(self, portfolio: "PortfolioSnapshot") -> Sequence["ManagementAction"]: ...
    # portfolio / global
    def on_portfolio_update(self, snap: "PortfolioSnapshot") -> Sequence["RiskAlert"]: ...
    def on_account_update(self, acc: AccountSnapshot) -> Sequence["RiskAlert"]: ...
    # کنترل
    def state(self) -> RiskState: ...
    def engage(self, level: KillLevel, reason: str, *, actor: str) -> None: ...
    def acknowledge(self, level: KillLevel, *, actor: str, note: str) -> None: ...  # فقط انسان
    def snapshot(self) -> "RiskSnapshot": ...
```

`RiskContext` شامل `AccountSnapshot`، `PortfolioSnapshot`، `SymbolInfo`، `Tick` فعلی، `MarketSnapshot`، `SessionState`، `NewsWindow`، و `RecentDecisions` است — یعنی همه‌ی چیزی که یک چک نیاز دارد، بدون هیچ I/O.

### ۴.۶. `IOrderExecutor` / `IPositionManager`

```python
# goldbot/ports/execution.py
class ExecutionResult(NamedTuple):
    intent_id: IntentId
    status: Literal["acked", "uncertain", "rejected", "expired"]
    ack: OrderAck | None
    retryable: bool

class IOrderExecutor(Protocol):
    def execute(self, approved: ApprovedOrder) -> ExecutionResult: ...
    def cancel_pending(self, *, scope: "CancelScope") -> "CancelReport": ...
    def flatten(self, *, scope: "CancelScope", reason: str) -> "FlattenReport": ...
    def in_flight(self) -> Sequence["InFlightOrder"]: ...

class IAccountModel(Protocol):
    """رفتار مخصوص hedging یا netting."""
    def can_open(self, symbol: Symbol, positions: Sequence[PositionSnapshot]) -> bool: ...
    def ticket_for(self, slot: SlotId, ticket: Ticket) -> SlotId | None: ...
    def protection_is_per_ticket(self) -> bool: ...

class IPositionManager(Protocol):
    def apply(self, ev: BrokerEvent) -> None: ...
    def view(self) -> "PortfolioSnapshot": ...
    def slots(self) -> Mapping[SlotId, Sequence[Ticket]]: ...
    def slot_of(self, ticket: Ticket) -> SlotId | None: ...
    def unresolved(self) -> Sequence["UnresolvedPosition"]: ...
    def reconcile(self, truth: "BrokerTruth") -> "ReconcileReport": ...
    def protection(self, ticket: Ticket) -> "ProtectionState": ...
    def mark_to_market(self, ticks: Mapping[Symbol, Tick]) -> None: ...
```

### ۴.۷. `IJournal` / `IEventStore`

```python
# goldbot/ports/journal.py
class EventEnvelope(NamedTuple):
    event_id: str               # UUIDv7؛ مرتب بر اساس زمان
    stream_id: str              # "order:<intent>", "position:<ticket>", "risk", "conn"
    seq: int                    # monotonically increasing per stream
    type: str                   # "OrderAcked" ...
    version: int                # نسخه‌ی اسکیما
    ts_event: Ts
    ts_recv: Ts
    correlation_id: IntentId
    causation_id: str | None
    actor: Literal["strategy", "risk", "executor", "gateway", "operator", "system"]
    payload: Mapping[str, Any]  # سریال‌شده بر اساس schema همان نوع

class IEventStore(Protocol):
    def append(self, events: Sequence[EventEnvelope], *, fsync: bool = True) -> "AppendResult": ...
    def read_stream(self, stream_id: str, *, from_seq: int = 0) -> Iterable[EventEnvelope]: ...
    def read_all(self, *, from_seq: int = 0, limit: int = 1000) -> Iterable[EventEnvelope]: ...
    def last_seq(self) -> int: ...
    def snapshot(self) -> "StateSnapshot | None": ...
    def write_snapshot(self, snap: "StateSnapshot") -> None: ...

class TradeRecord(NamedTuple):
    trade_id: str
    slot: SlotId
    strategy_version: str
    symbol: Symbol
    side: Literal["buy", "sell"]
    opened_at: datetime; closed_at: datetime | None
    entry_price: Decimal; exit_price: Decimal | None
    volume: Decimal
    sl: Decimal | None; tp: Decimal | None
    pnl_gross: Money; pnl_net: Money
    commission: Money; swap: Money; spread_at_entry: Decimal
    mae: Decimal | None; mfe: Decimal | None
    signal_snapshot: Mapping[str, Any]       # ورودی‌های استراتژی در لحظه‌ی سیگنال
    risk_snapshot: "RiskSnapshot"            # همه‌ی چک‌ها و اعداد
    exit_reason: Literal["tp", "sl", "strategy", "risk", "kill", "manual", "timeout"]

class IJournal(Protocol):
    def record_trade(self, rec: TradeRecord) -> None: ...
    def update_trade(self, trade_id: str, **fields: Any) -> None: ...
    def trade(self, trade_id: str) -> TradeRecord | None: ...
    def query(self, q: "JournalQuery") -> Sequence[TradeRecord]: ...
    def record_equity_point(self, ts: datetime, equity: Money, balance: Money) -> None: ...
```

### ۴.۸. `IClock`

```python
# goldbot/ports/clock.py
class ClockDrift(NamedTuple):
    broker_offset: timedelta          # به‌دست‌آمده از tick.time - ts_recv
    confidence: timedelta             # پهنای بازه‌ی اطمینان
    is_suspect: bool

class IClock(Protocol):
    def now(self) -> Ts: ...                       # UTC + monotonic
    def broker_now(self) -> datetime: ...          # برای محاسبه‌ی session و expiry
    def drift(self) -> ClockDrift: ...
    def to_broker(self, ts: datetime) -> datetime: ...
    def to_utc(self, ts: datetime) -> datetime: ...
    def session(self, symbol: Symbol, at: datetime) -> "SessionState": ...   # OPEN/PRE/POST/CLOSED/HOLIDAY
    def next_open(self, symbol: Symbol, after: datetime) -> datetime: ...
```

چهار مهر زمانی مجزا (`ts_event`, `ts_recv`, `ts_decision`, `ts_send`) به‌علاوه‌ی `broker_offset` در ژورنال، تنها راه بازسازی «چه زمانی چه چیزی می‌دانستیم» است. `is_suspect=True` (drift بیش از آستانه یا واریانس زیاد) ⇒ `RiskState.SOFT_HALT`.

### ۴.۹. پورت‌های کمکی

```python
class INotifier(Protocol):
    def send(self, level: Literal["info","warn","critical"], title: str,
             body: str, *, dedup_key: str, correlation_id: str | None = None) -> bool: ...

class ISecretProvider(Protocol):
    def get(self, name: str) -> "SecretStr": ...      # __repr__ = "***"؛ هرگز serialize نمی‌شود
    def rotate(self, name: str, new_value: "SecretStr") -> None: ...

class ISettings(Protocol):
    def get(self) -> "Settings": ...                  # pydantic Settings، frozen، اعتبارسنجی‌شده
    def reload(self) -> "ConfigDiff": ...             # فقط فیلدهای hot-reloadable
```

---

## ۵. کاتالوگ رویدادها

همه‌ی رویدادها در `IEventStore` پایدار می‌شوند مگر آن‌که «نه» علامت خورده باشد. ستون `corr` یعنی `correlation_id` حمل می‌شود.

| # | رویداد | payload (خلاصه) | ناشر | مصرف‌کننده | پایدار؟ |
|---|---|---|---|---|---|
| E01 | `SessionStarted` | run_id, config_hash, git_sha, account, mode | bootstrap | journal, notifier | ✅ |
| E02 | `ConfigLoaded` | hash, sources, diff | config | journal | ✅ |
| E03 | `ConnectionStateChanged` | from, to, reason, latency_ms | session_supervisor | risk, notifier, metrics | ✅ |
| E04 | `ClockDriftDetected` | offset, confidence, sample_n | clock | risk, notifier | ✅ |
| E05 | `MarketTick` | bid, ask, ts_event | feed | bar_builder, risk | ❌ (فقط tape) |
| E06 | `BarClosed` | bar کامل, revision | bar_builder | strategy_host | ❌ (فقط tape) |
| E07 | `StaleDataDetected` | symbol, age_ms, threshold | feed health | risk | ✅ |
| E08 | `GapDetected` | symbol, from, to, expected_bars | bar_builder | strategy_host, risk | ✅ |
| E09 | `StrategyStarted` | slot, id, version, params_hash | strategy_host | journal | ✅ |
| E10 | `StrategyWarmedUp` | slot, bars_used, first_ts, last_ts | strategy_host | journal | ✅ |
| E11 | `SignalRaised` | kind, side, hints, confidence, rationale, tags | strategy_host | pipeline, journal | ✅ |
| E12 | `IntentCreated` | resolved volume, sl, tp, rr, risk_amount | signal_pipeline | risk | ✅ |
| E13 | `RiskEvaluated` | verdict, reasons[], checks[], snapshot | risk_engine | journal, notifier | ✅ |
| E14 | `OrderIntentApproved` | ApprovedOrder (بدون token), risk_snapshot | risk_engine | journal | ✅ (fsync) |
| E15 | `OrderSubmitted` | intent_id, idem_key, ts_send | order_coordinator | journal | ✅ |
| E16 | `OrderAcked` | ticket, retcode, fill_price | order_coordinator | position_manager, journal | ✅ |
| E17 | `OrderRejected` | retcode, retcode_name, message | order_coordinator | journal, notifier | ✅ |
| E18 | `OrderUncertain` | reason, ts_deadline | order_coordinator | risk (قفل), journal | ✅ |
| E19 | `OrderResolvedPresent` | ticket, matched_by (`magic`/`client_ref`) | reconciler | journal | ✅ |
| E20 | `OrderResolvedAbsent` | intent_id, search_window | reconciler | journal | ✅ |
| E21 | `FillReceived` | deal, price, volume, commission, swap, slippage | gateway → position_manager | journal, strategy (`on_fill`) | ✅ |
| E22 | `PositionOpened` | ticket, slot, volume, sl, tp | position_manager | risk, journal | ✅ |
| E23 | `PositionModified` | ticket, sl, tp, reason | position_manager | journal | ✅ |
| E24 | `PositionClosed` | ticket, pnl_net, exit_reason, mae/mfe | position_manager | journal, risk | ✅ |
| E25 | `ProtectionBroken` | ticket, expected_sl, actual | reconciler | risk (HARD), notifier | ✅ |
| E26 | `ReconcileStarted/Completed` | counts, drift list, duration | reconciler | journal, metrics | ✅ |
| E27 | `DivergenceDetected` | kind (missing/orphan/volume/price), detail | reconciler | risk, notifier | ✅ |
| E28 | `RiskStateChanged` | from, to, reasons, actor | risk_engine | executor, notifier, metrics | ✅ |
| E29 | `KillSwitchEngaged` | level, reason, actor, positions_closed | kill_switch | journal, notifier | ✅ |
| E30 | `DailyLossBreach` | limit, realized, unrealized, equity | risk_engine | kill_switch | ✅ |
| E31 | `MarginChanged` | old_rate, new_rate, leverage, source | gateway poll | risk | ✅ |
| E32 | `NewsWindowEntered/Exited` | event, currency, impact, window | news_calendar | risk | ✅ |
| E33 | `SessionWindowChanged` | symbol, open, close, dst_shift | clock/symbol_info | risk, strategy_host | ✅ |
| E34 | `HeartbeatMissed` | component, last_seen, threshold | supervisor | notifier, kill (soft) | ✅ |
| E35 | `ManualOverride` | actor, action, scope, note | operator CLI | risk, journal | ✅ |
| E36 | `OrderExpired` | intent_id, valid_until | order_coordinator | journal | ✅ |

**قواعد پاکت رویداد:**
- `type` + `version` هرگز تغییر نمی‌کنند؛ تغییر شکل = نسخه‌ی جدید + upcaster در لایه‌ی خواندن.
- `payload` هرگز راز، شماره‌ی حساب کامل، یا توکن ندارد. شماره‌ی حساب در `SessionStarted` هش می‌شود.
- `correlation_id` از `IntentId` شروع می‌شود و تا `PositionClosed` ادامه دارد؛ بنابراین «چرا این معامله باز شد» با یک کوئری پاسخ می‌گیرد.

---

## ۶. ماشین‌های وضعیت

هر ماشین وضعیت در `domain/fsm.py` تعریف می‌شود: حالت‌ها `Enum`، گذارها تابع خالص `(state, event) -> state | Rejection`، و هر گذار «مجاز» یا «غیرمجاز» است (نه «بهترین تلاش»).

### ۶.۱. سفارش (Order)

```mermaid
stateDiagram-v2
    [*] --> CREATED
    CREATED --> RISK_REJECTED: RiskRejected
    CREATED --> APPROVED: RiskApproved
    APPROVED --> SUBMITTING: submit()
    SUBMITTING --> ACKED: retcode=DONE
    SUBMITTING --> REJECTED: retcode in PERMANENT
    SUBMITTING --> RETRYABLE: requote / price_changed
    RETRYABLE --> SUBMITTING: reprice + retry(≤N)
    RETRYABLE --> REJECTED: retry exhausted
    SUBMITTING --> UNKNOWN: timeout / disconnect
    ACKED --> PARTIAL: partial fill
    PARTIAL --> FILLED: filled volume == requested
    PARTIAL --> CANCELED: cancel remainder
    ACKED --> FILLED: full fill
    ACKED --> CANCELED: cancel before fill
    APPROVED --> EXPIRED: valid_until passed
    UNKNOWN --> ADOPTED: found in broker
    UNKNOWN --> RESOLVED_ABSENT: not found in broker
    ADOPTED --> PARTIAL
    ADOPTED --> FILLED
    FILLED --> [*]
    REJECTED --> [*]
    CANCELED --> [*]
    EXPIRED --> [*]
    RISK_REJECTED --> [*]
```

| گذار | محرک | اقدام جانبی اجباری |
|---|---|---|
| `APPROVED → SUBMITTING` | ارسال | نوشتن `OrderSubmitted` **قبل از** I/O |
| `SUBMITTING → UNKNOWN` | timeout/disconnect | قفل ورود جدید + هشدار critical |
| `UNKNOWN → ADOPTED` | تطبیق موفق | ثبت `matched_by` و ادامه‌ی چرخه |
| `UNKNOWN → RESOLVED_ABSENT` | تطبیق قطعی منفی | باز کردن قفل پس از reconcile کامل |
| `RETRYABLE → SUBMITTING` | reprice | سقف ۲ تلاش؛ بار سوم ⇒ `REJECTED` |
| `ACKED → PARTIAL → FILLED` | fill جزئی | به‌روزرسانی حجم مؤثر ریسک |

**قاعده‌ی سخت:** هیچ گذار از `UNKNOWN` به `REJECTED`/`CANCELED` بدون تطبیق وجود ندارد. «نمی‌دانم» هرگز به «انجام نشد» تبدیل نمی‌شود.

### ۶.۲. پوزیشن (Position)

```mermaid
stateDiagram-v2
    [*] --> NONE
    NONE --> OPENING: order sent
    OPENING --> OPEN: fill confirmed
    OPENING --> NONE: rejected/absent
    OPEN --> PROTECTED: SL verified at broker
    OPEN --> UNPROTECTED: no SL / SL rejected
    PROTECTED --> UNPROTECTED: ProtectionBroken
    UNPROTECTED --> PROTECTED: SL restored
    PROTECTED --> CLOSING: exit intent / kill / SL hit
    UNPROTECTED --> CLOSING: force close
    CLOSING --> CLOSED: fill confirmed
    CLOSING --> CLOSING: uncertain (retry after reconcile)
    CLOSED --> [*]
    OPEN --> ORPHANED: present at broker, unknown locally
    ORPHANED --> ADOPTED: operator/reconciler adopts
    ADOPTED --> PROTECTED
```

`PROTECTED/UNPROTECTED` یک **پرچم متعامد** (orthogonal flag) است، نه وضعیت موازی: پوزیشن می‌تواند `OPEN` و هم‌زمان `UNPROTECTED` باشد. تایمر `unprotected_seconds > threshold` ⇒ `RiskState.HARD` و بستن اجباری.

### ۶.۳. استراتژی (Strategy / Slot)

| حالت | معنا | گذارهای مجاز | محرک |
|---|---|---|---|
| `CREATED` | ثبت شده، وابستگی‌ها آماده | `→ WARMING`, `→ FAILED` | start |
| `WARMING` | دریافت history و گرم‌کردن ایندیکاتور | `→ READY`, `→ FAILED` | warmup complete / timeout |
| `READY` | آماده، ولی بازار بسته یا اتصال ناقص | `→ ACTIVE`, `→ STOPPED` | session open / stop |
| `ACTIVE` | سیگنال تولید می‌کند | `→ PAUSED`, `→ DRAINING`, `→ FAILED` | risk halt / stop / exception |
| `PAUSED` | سیگنال تولید نمی‌کند، پوزیشن‌ها مدیریت می‌شوند | `→ ACTIVE`, `→ DRAINING` | risk clear / stop |
| `DRAINING` | ورود ممنوع، فقط مدیریت خروج | `→ STOPPED` | positions closed |
| `FAILED` | استثنا یا نقض قرارداد | `→ STOPPED` فقط با مداخله‌ی انسان | operator ack |
| `STOPPED` | توقف نهایی | `→ CREATED` (restart) | start جدید |

**قاعده:** استثنای مهارنشده در `on_market` ⇒ همان slot به `FAILED`، بقیه‌ی استراتژی‌ها ادامه می‌دهند، و در حالت single-strategy کل سیستم به `HARD` می‌رود. این «انزوای خطا» تفاوت بین یک باگ و یک فاجعه است.

### ۶.۴. اتصال (Connection)

```mermaid
stateDiagram-v2
    [*] --> DISCONNECTED
    DISCONNECTED --> CONNECTING: connect()
    CONNECTING --> SYNCING: socket up
    CONNECTING --> BACKOFF: fail
    SYNCING --> READY: snapshot + reconcile ok
    SYNCING --> QUARANTINE: reconcile divergence
    READY --> DEGRADED: heartbeat late / tick stale
    DEGRADED --> READY: recovered
    DEGRADED --> LOST: threshold exceeded
    READY --> LOST: socket drop
    QUARANTINE --> SYNCING: human ack + retry
    BACKOFF --> CONNECTING: after delay
    LOST --> BACKOFF: auto
    LOST --> HALTED: max attempts / human
    HALTED --> DISCONNECTED: human reset
```

| حالت | آیا سفارش جدید مجاز است؟ | آیا مدیریت پوزیشن مجاز است؟ |
|---|---|---|
| `READY` | ✅ | ✅ |
| `DEGRADED` | ❌ (فقط کاهش ریسک) | ✅ (بستن/SL مجاز، باز کردن نه) |
| `QUARANTINE` | ❌ | ❌ (همه‌چیز متوقف تا تطبیق) |
| `LOST` / `BACKOFF` / `HALTED` | ❌ | ❌ |

`DEGRADED` یک حالت عمدی است: وقتی داده کهنه می‌شود، «بستن پوزیشن» باید ممکن بماند، اما «باز کردن» نه. این تفکیک، تفاوت بین محافظه‌کاری و فلج کامل است.

### ۶.۵. جدول تطبیق حالت‌ها با الزامات

| الزام | کجای مدل تضمین می‌شود |
|---|---|
| Fail-closed | `UNKNOWN` در سفارش + `QUARANTINE` در اتصال + `Rejected` پیش‌فرض در ریسک |
| بروکر منبع حقیقت | هر گذار پوزیشن فقط از رویداد بروکر (نه از حدس) مشتق می‌شود |
| بدون ارسال کورکورانه | تنها گذار مجاز از `RETRYABLE` است، با reprice و سقف ۲ |

---

## ۷. مدل خطا و سیاست شکست

### ۷.۱. دسته‌بندی خطا

```python
# goldbot/domain/errors.py
class ErrorClass(Enum):
    NETWORK        = auto()   # قطع سوکت، timeout، DNS
    BROKER_TRANSIENT = auto() # requote، price_changed، trade_context_busy
    BROKER_PERMANENT = auto() # invalid_stops، no_money، market_closed، trade_disabled
    DATA           = auto()   # gap، stale، tick خارج از ترتیب، کندل ناقص
    CLOCK          = auto()   # drift، DST mismatch
    LOGIC          = auto()   # نقض invariant، حالت غیرمنتظره در FSM
    RISK           = auto()   # نقض سقف، drawdown
    CONFIG         = auto()   # اعتبارسنجی، ناسازگاری حساب
    SECRET         = auto()   # نبود/انقضای راز، خطای دسترسی
    RESOURCE       = auto()   # دیسک پر، حافظه، تعداد فایل باز
    OPERATOR       = auto()   # kill دستی، override
```

### ۷.۲. سیاست پیش‌فرض هر دسته

| دسته | مثال | Retry؟ | Backoff | Circuit Breaker | سفارش جدید؟ | هشدار |
|---|---|---|---|---|---|---|
| `NETWORK` (خواندن) | `positions()` timeout | ✅ | نمایی + jitter، ۵ تلاش، سقف ۳۰s | بعد از ۵ خطای متوالی | ❌ تا reconnect | warn |
| `NETWORK` (نوشتن) | `order_send` timeout | ⚠️ **فقط پس از تطبیق** | — | — | ❌ | critical |
| `BROKER_TRANSIENT` | requote، price_changed | ✅ حداکثر ۲ بار با reprice | فوری (۰–۲۰۰ms) | بعد از ۳ بار | ✅ مشروط | info |
| `BROKER_PERMANENT` | invalid_stops، no_money | ❌ | — | — | ✅ (سفارش بعدی مجاز) | warn |
| `DATA` | stale > ۳۰s، gap > ۲ کندل | ❌ (خودش برمی‌گردد) | — | — | ❌ (`SOFT_HALT`) | warn |
| `CLOCK` | drift > ۱۰s یا confidence پهن | ❌ | — | — | ❌ (`SOFT_HALT`) | critical |
| `LOGIC` | FSM invalid transition | ❌ | — | — | ❌ (`HARD`) | critical |
| `RISK` | daily loss، max positions | ❌ | — | — | ❌ (latch) | critical |
| `CONFIG` | حساب اشتباه، hedging/netting mismatch | ❌ | — | — | ❌ (خروج از فرآیند) | critical |
| `SECRET` | توکن نامعتبر | ❌ | — | — | ❌ (خروج) | critical |
| `RESOURCE` | دیسک < ۱GB | ❌ | — | — | ❌ (`SOFT_HALT`) | critical |
| `OPERATOR` | kill switch | ❌ | — | — | ❌ تا ack | critical |

### ۷.۳. قواعد حاکم بر خطا

1. **«تلاش دوباره» فقط برای عملیات idempotent.** خواندن idempotent است؛ نوشتن فقط با `idempotency_key` و به‌شرط «نتیجه نامعلوم نیست، خطای مشخص transient بود». اگر نتیجه نامعلوم است، مسیر `UNKNOWN → reconcile` است، نه retry.
2. **Circuit breaker در سطح گیت‌وی، نه در سطح استراتژی.** سه خطای متوالی شبکه ⇒ باز شدن مدار برای ۳۰s ⇒ `DEGRADED`. استراتژی هرگز از خرابی زیرساخت خبردار نمی‌شود.
3. **هیچ `except Exception: pass`.** هر `except` باید یا خطا را به `ErrorClass` نگاشت کند یا دوباره raise کند. در CI یک تست AST این را بررسی می‌کند.
4. **خطاهای `LOGIC`/`CONFIG`/`SECRET` فرآیند را متوقف می‌کنند** (exit non-zero) تا supervisor بیرونی آن را restart کند؛ ادامه‌ی کار با حالت ناسازگار خطرناک‌تر از توقف است.
5. **همه‌ی خطاها یک شناسه‌ی قابل جست‌وجو دارند:** `error_id = f"{ErrorClass}:{component}:{code}"`. هشدار تلگرام همین شناسه را در تیتر دارد تا dedupe و جست‌وجو ساده باشد.
6. **بودجه‌ی زمان برای هر تصمیم:** `decision_timeout = 2s`. اگر ریسک یا اجرا از بودجه عبور کند، نتیجه `Defer` و سپس `Reject` است — تأخیر زیاد خودش یک دلیل رد است.

### ۷.۴. جدول «نقطه‌ی شکست → کجا پوشش داده می‌شود»

| نقطه‌ی شکست | کجا پوشش داده می‌شود | مکانیزم |
|---|---|---|
| قطع اتصال بین ارسال و تأیید | §۳.۳، §۶.۱ | `UNKNOWN` + `find_by_client_ref` + idempotency |
| ری‌استارت با پوزیشن باز | §۳.۱، §۶.۲ | snapshot + reconcile + `ORPHANED/ADOPTED` |
| اختلاف ساعت و DST | §۴.۸، §۷.۲ | `IClock.drift()` + `zoneinfo` + soft halt |
| اسپرد/کمیسیون/سواپ/قیمت واقعی | §۴.۱ (`SymbolInfo`)، `CostModel` در بک‌تست | همان `SymbolInfo` در هر سه حالت |
| گپ آخر هفته و اخبار | §۴.۸ (`SessionState`)، §۴.۵ (`NewsWindow`) | فیلتر سشن/خبر + `SL` اجباری + `flatten` اختیاری |
| تغییر leverage/margin توسط بروکر | E31 `MarginChanged` | poll دوره‌ای + محاسبه‌ی مجدد margin نیاز |
| تفاوت netting/hedging | §۱.۳ | `IAccountModel` + تجمیع ریسک |
| محدودیت تعداد سفارش/پوزیشن | §۴.۵، کانفیگ | `MAX_POSITIONS`, `MAX_ORDERS_PER_DAY`, rate limit |
| stale tick و کندل ناقص | §۴.۳ (`staleness`), §۳.۲ | `SOFT_HALT` + `is_closed` اجباری |
| look-ahead و overfitting | §۳.۲، §۱۱-B | فقط `BarClosed` + تست AST + walk-forward |
| خطای اپراتور | §۳.۴، E35 | kill switch + override با ثبت اجباری + تأیید حساب در استارتاپ |

---

## ۸. ساختار پوشه‌ها و مرز پکیج‌ها

```
goldbot/
├── pyproject.toml                  # uv / hatchling؛ workspace برای gateway
├── README.md
├── docs/
│   ├── adr/                        # ADR-0001..N (هر تصمیم یک فایل)
│   ├── runbooks/                   # بازیابی، چرخش کلید، kill switch
│   └── architecture/               # همین سند
├── config/
│   ├── base.toml                   # پیش‌فرض‌های امن
│   ├── symbols.toml                # نگاشت نماد، contract size، سشن‌ها
│   ├── strategies/
│   │   └── <name>.toml             # پارامترهای هر نمونه‌ی استراتژی
│   └── env/                        # overlay محیطی (dev/demo/live)
├── src/
│   ├── goldbot/
│   │   ├── domain/                 # L0 — بدون I/O
│   │   │   ├── model.py
│   │   │   ├── money.py
│   │   │   ├── events.py
│   │   │   ├── fsm/
│   │   │   │   ├── order.py
│   │   │   │   ├── position.py
│   │   │   │   ├── strategy.py
│   │   │   │   └── connection.py
│   │   │   ├── risk_policies/
│   │   │   │   ├── sizing.py
│   │   │   │   ├── limits.py
│   │   │   │   ├── drawdown.py
│   │   │   │   ├── correlation.py
│   │   │   │   └── filters.py
│   │   │   └── errors.py
│   │   ├── ports/                  # L2 — Protocol فقط
│   │   │   ├── broker.py
│   │   │   ├── marketdata.py
│   │   │   ├── risk.py
│   │   │   ├── execution.py
│   │   │   ├── journal.py
│   │   │   ├── clock.py
│   │   │   ├── notify.py
│   │   │   ├── secrets.py
│   │   │   └── settings.py
│   │   ├── app/                    # L1
│   │   │   ├── strategy_host.py
│   │   │   ├── signal_pipeline.py
│   │   │   ├── risk_engine.py
│   │   │   ├── order_coordinator.py
│   │   │   ├── position_manager.py
│   │   │   ├── reconciler.py
│   │   │   ├── session_supervisor.py
│   │   │   ├── kill_switch.py
│   │   │   ├── bar_builder.py
│   │   │   └── snapshot_service.py
│   │   ├── adapters/               # L3
│   │   │   ├── broker/
│   │   │   │   ├── gateway_client.py
│   │   │   │   └── fake_broker.py          # برای تست و بک‌تست
│   │   │   ├── marketdata/
│   │   │   │   ├── live_feed.py
│   │   │   │   ├── tape_feed.py
│   │   │   │   └── tape_writer.py
│   │   │   ├── journal/
│   │   │   │   ├── sqlite_store.py
│   │   │   │   ├── projections.py
│   │   │   │   └── migrations/
│   │   │   ├── notify/telegram.py
│   │   │   ├── clock/system.py
│   │   │   ├── config/loader.py
│   │   │   └── secrets/keyring_dpapi.py
│   │   ├── runtime/                # L4 — تنها Composition Root
│   │   │   ├── bootstrap.py
│   │   │   ├── supervisor.py
│   │   │   ├── cli.py
│   │   │   └── health_server.py
│   │   └── strategy_api/           # SDK پلاگین (تنها import مجاز استراتژی)
│   │       ├── __init__.py
│   │       ├── context.py
│   │       ├── signals.py
│   │       └── indicators.py       # کتابخانه‌ی مشترک و تست‌شده
│   ├── goldbot_gateway/            # فرآیند مرزی ویندوز
│   │   ├── mt5_session.py          # تنها import مجاز MetaTrader5
│   │   ├── router.py               # ترجمه‌ی درخواست‌ها
│   │   ├── idempotency.py
│   │   ├── ratelimit.py
│   │   ├── symbol_map.py
│   │   ├── server.py               # HTTP/WS روی localhost
│   │   └── service.py              # نصب به‌عنوان Windows Service
│   ├── strategies/                 # پلاگین‌ها؛ بیرون از هسته
│   │   ├── registry.toml
│   │   └── <name>/
│   │       ├── strategy.py
│   │       ├── params.py
│   │       └── tests/
│   └── goldbot_research/           # پژوهش، بیرون از مسیر لایو
│       ├── backtest/
│       │   ├── engine.py
│       │   ├── fill_model.py
│       │   ├── cost_model.py
│       │   └── metrics.py
│       ├── walkforward.py
│       └── notebooks/
├── tests/
│   ├── unit/                       # دامنه: سریع، بدون I/O
│   ├── contract/                   # هر آداپتور باید پورت را پاس کند
│   ├── integration/                # SQLite + gateway fake + eventually real demo
│   ├── replay/                     # tape های واقعی، تست رگرسیون
│   └── parity/                     # یک استراتژی، دو مسیر، نتیجه یکسان
├── ops/
│   ├── docker/                     # core روی لینوکس
│   ├── windows/                    # سرویس گیت‌وی، Task Scheduler
│   ├── grafana/                    # داشبورد JSON
│   └── scripts/                    # backup, rotate, kill
└── .github/workflows/ci.yml        # lint, mypy, import-linter, tests, secret scan
```

**قواعد ساختاری:**
- `src/strategies/` هیچ‌وقت داخل `goldbot` نیست؛ جدا بودنش، مرز پلاگین را فیزیکی می‌کند.
- `tests/contract/` برای هر پورت یک مجموعه‌ی مشترک دارد که هر آداپتور (real/fake/tape) باید پاس کند. این‌گونه `FakeBroker` واقعاً جانشین است، نه اسباب‌بازی.
- `docs/adr/` اجباری است: PR بدون ADR برای تصمیم‌های معماری merge نمی‌شود.

---

## ۹. جدول ADR (Architecture Decision Records)

هر تصمیم یک فایل جدا در `docs/adr/` دارد؛ این جدول فهرست فشرده است.

| # | تصمیم | گزینه‌های رد‌شده | انتخاب | دلیل | هزینه |
|---|---|---|---|---|---|
| ADR-01 | زبان هسته | Rust، Go، C#/.NET، Node | **Python 3.12** | اکوسیستم پژوهش (pandas/polars/numpy)، سرعت توسعه برای یک نفر، کتابخانه‌ی MT5 پایتون بومی | GIL، تایپ‌های ضعیف‌تر (با mypy strict جبران می‌شود)، نیاز به انزوای فرآیند برای کد بلاک‌کننده |
| ADR-02 | دسترسی به بروکر | FIX، cTrader Open API، REST بروکر | **MT5 Python API در گیت‌وی** | تنها گزینه‌ی ریتیل با SL/TP سمت بروکر و hedging؛ بدون هزینه‌ی زیرساخت اضافه | فقط ویندوز، بدون `ClOrdID` بومی ⇒ idempotency محلی |
| ADR-03 | توپولوژی فرآیند | تک‌فرآیند، میکروسرویس کامل | **دو فرآیند: core + gateway** | قابلیت تست بدون MT5، بازسازی مستقل، مرز خطا | یک سرویس اضافه برای مانیتور، قرارداد IPC |
| ADR-04 | پروتکل core↔gateway | ZMQ، gRPC، نام‌پایپ ویندوز، REST خالص | **HTTP/JSON + WebSocket روی 127.0.0.1** | بدون codegen، قابل دیباگ با curl، کافی برای < ۱۰۰ رویداد/ثانیه | سربار سریال‌سازی؛ در صورت نیاز به تأخیر کمتر، ZMQ قابل تعویض است (پورت تغییر نمی‌کند) |
| ADR-05 | ذخیره‌سازی رویداد | Postgres، Kafka، فایل JSONL | **SQLite در حالت WAL** | استقرار صفر-کانفیگ، پشتیبان‌گیری با یک فایل، کافی برای یک اپراتور | قفل نوشتن تک‌نویسنده؛ نیاز به fsync آگاهانه |
| ADR-06 | ذخیره‌سازی داده بازار | SQLite، InfluxDB، پارکت | **Parquet (روزانه) + DuckDB برای کوئری** | فشرده، ستونی، مناسب تحلیل؛ بدون سرور | نیاز به مدیریت فایل و پارتیشن‌بندی |
| ADR-07 | مدل داده معاملات | CRUD روی جداول، event sourcing سراسری | **Event sourcing فقط برای order/position/risk** | قابلیت بازپخش و حسابرسی؛ بدون پیچیدگی برای بقیه | نیاز به snapshot و upcaster |
| ADR-08 | قرارداد استراتژی | ارث‌بری از کلاس پایه، entry points، اسکریپت جدای کاربر | **Protocol + رجیستری TOML** | بدون وابستگی به مکانیزم نصب، قابل تست، صریح | استراتژی نمی‌تواند خودش را «نصب» کند (که خوب است) |
| ADR-09 | برابری بک‌تست | فریم‌ورک برداری جداگانه، دو کدبیس | **همان پورت‌ها + FakeBroker + TapeFeed** | تنها راه تضمین parity؛ باگ فقط یک‌جا | بک‌تست کندتر از راه‌حل برداری (برای این فرکانس قابل قبول) |
| ADR-10 | کانفیگ | YAML، env-only، پایتون خام | **TOML + overlay env + pydantic (strict, extra=forbid)** | تایپ‌دار، اعتبارسنجی در استارتاپ، خطای زودهنگام | نیاز به بازتولید کانفیگ در تست‌ها |
| ADR-11 | رازها | `.env`، Vault، فایل رمزنگاری‌شده | **Windows DPAPI / OS keyring** | بدون سرور اضافه، رمزنگاری در سطح کاربر، جداشده از ریپو | وابسته به ویندوز؛ برای لینوکس از `keyring` + `systemd-creds` |
| ADR-12 | زمان | همه‌جا وقت بروکر، همه‌جا UTC | **UTC در ذخیره، آفست بروکر ثبت‌شده** | DST و تغییر آفست بروکر دو منبع باگ‌اند؛ ثبت هر دو، بازسازی را ممکن می‌کند | تبدیل‌های اضافه در مرزها |
| ADR-13 | Sizing | لات ثابت، Kelly، بهینه‌سازی سود | **Fixed-fractional بر پایه‌ی R و ATR** | قابل فهم، قابل حسابرسی، مقاوم به تخمین نادرست edge | رشد کندتر سرمایه |
| ADR-14 | مدل حساب | فقط hedging، فقط netting، پشتیبانی دینامیک | **پورت `IAccountModel` با دو پیاده‌سازی** | جلوگیری از کشف دیرهنگام تفاوت‌ها | کد بیشتر و تست دوگانه |
| ADR-15 | کانال هشدار | ایمیل، SMS، Slack، تلگرام | **تلگرام (فقط خروجی) + ایمیل fallback** | سرعت، هزینه‌ی صفر، موبایل | سطح حمله تلگرام؛ با «فقط خروجی» و بدون دستور، کاهش می‌یابد |
| ADR-16 | نوع سفارش ورود | فقط market، فقط limit، ترکیبی | **market با SL/TP اتمیک + limit اختیاری per-strategy** | سادگی، کاهش حالت‌های شکست | slippage در market؛ با `max_slippage` و فیلتر اسپرد مدیریت می‌شود |
| ADR-17 | چند استراتژی | حساب جدا برای هر استراتژی، یک حساب با slot | **یک حساب + `magic` به‌ازای slot** | سرمایه‌ی کم، هزینه‌ی کمتر، مدیریت یکجا | عدم جداسازی کامل ریسک؛ با سقف‌های per-slot و per-symbol مدیریت می‌شود |
| ADR-18 | استقرار | Kubernetes، bare-metal، Docker | **Docker برای core + Windows Service برای gateway** | بازتولیدپذیری، ارتقای ساده، بکاپ ساده | نیاز به دو مسیر استقرار و مستندسازی |

---

## ۱۰. ریسک‌های معماری و نقاط شکست

| # | ریسک | احتمال | اثر | راهکار طراحی | چگونه تشخیص می‌دهیم |
|---|---|---|---|---|---|
| AR-1 | واگرایی وضعیت پس از ری‌استارت | متوسط | بالا | snapshot + reconcile اجباری؛ `QUARANTINE` تا تطبیق | `DivergenceDetected`، مقایسه‌ی شمارش پوزیشن |
| AR-2 | سفارش یتیم | متوسط | بالا | `UNKNOWN` + جست‌وجوی `client_ref`/`magic` | `OrderUncertain`، هشدار critical |
| AR-3 | وابستگی به یک ترمینال MT5 (نقطه‌ی شکست واحد) | بالا | بالا | گیت‌وی مستقل + restart خودکار + هشدار heartbeat | `HeartbeatMissed` |
| AR-4 | نشت راز در لاگ/هشدار | پایین | بسیار بالا | `SecretStr`، لاگ redaction، تست AST، secret scan در CI | اسکن هفتگی، بازبینی لاگ |
| AR-5 | تغییر رفتار بروکر (margin، stops level، سشن) | متوسط | متوسط | poll دوره‌ای `symbol_info`/`account`، رویداد `MarginChanged` | انحراف از snapshot |
| AR-6 | کندی بک‌تست دلسردکننده ⇒ فشار برای «بهینه‌سازی سریع» | متوسط | متوسط | مسیر برداری اختیاری **فقط برای پژوهش**، با تست parity اجباری | شکست تست parity |
| AR-7 | پیچیدگی بیش‌ازحد برای یک نفر (over-engineering) | متوسط | متوسط | Walking Skeleton اول؛ هر قابلیت فقط با تست و ADR | زمان بین commit تا deploy |
| AR-8 | همبستگی پنهان استراتژی‌ها روی یک نماد | بالا | متوسط | سقف ریسک تجمیعی per-symbol، نه فقط per-slot | `CORRELATION_LIMIT` |
| AR-9 | خطای DST/سشن در روز تغییر ساعت | متوسط | بالا | `zoneinfo` + تست‌های تاریخ‌محور + عدم فرض آفست ثابت | تست‌های تقویمی، `ClockDrift` |
| AR-10 | پر شدن دیسک با tape و لاگ | متوسط | بالا | چرخش، سهمیه‌بندی، هشدار در ۸۰٪ | `RESOURCE` alert |
| AR-11 | قفل شدن SQLite در نوشتن هم‌زمان | پایین | متوسط | تک‌نویسنده، `busy_timeout`, WAL | متریک `db_busy_ms` |
| AR-12 | از دست رفتن کلید/رمز در VPS | پایین | بالا | runbook بازیابی، بکاپ رمزنگاری‌شده‌ی خارج از ماشین | تمرین بازیابی فصلی |

**نقاط شکست تک (SPOF) و پاسخ:**
1. ترمینال MT5 → restart خودکار + هشدار؛ هسته بدون آن هم بالا می‌آید (فقط معامله نمی‌کند).
2. VPS → بکاپ روزانه‌ی SQLite + Parquet به فضای ابری؛ RTO هدف: ۳۰ دقیقه؛ RPO: صفر برای رویدادها (fsync)، تا ۱ روز برای tape.
3. اینترنت → `DEGRADED`، مدیریت پوزیشن با SL سمت بروکر ادامه می‌یابد (به همین دلیل SL سمت بروکر اجباری است).

---

## ۱۱. نقشه راه ساخت (Build Order)

اصل حاکم: **هر مرحله یک سیستم قابل اجرا و قابل تست تولید می‌کند**، نه یک لایه‌ی نیمه‌کاره.

### مرحله A — Walking Skeleton (هفته ۱–۲)

هدف: یک معامله‌ی ساختگی از ابتدا تا انتها در ژورنال ثبت شود، بدون بروکر واقعی.

| گام | خروجی | تست پذیرش |
|---|---|---|
| A1 | `domain` + `ports` + `FakeBroker` + `TapeFeed` + `SQLiteEventStore` | تست‌های واحد دامنه؛ تست contract برای `FakeBroker` |
| A2 | `strategy_host` + یک استراتژی ساده (مثلاً «ورود در بازگشایی سشن با ATR stop») | یک روز tape ⇒ سیگنال‌های مورد انتظار |
| A3 | `risk_engine` با ۳ چک (spread، max positions، daily loss) + `signal_pipeline` | تست: سیگنال مسموم ⇒ `Rejected` با دلیل درست |
| A4 | `order_coordinator` + `ApprovedOrder` + idempotency + `UNKNOWN` | تست تزریق قطعی: هیچ سفارش دوتایی، هیچ بی‌ژورنال |
| A5 | `position_manager` + `reconciler` | تست: پوزیشن یتیم در FakeBroker ⇒ `ORPHANED` + `QUARANTINE` |
| **معیار خروج** | `goldbot backtest --tape day.jsonl` و `goldbot run --fake` هر دو کار می‌کنند و ژورنال کامل تولید می‌شود | — |

### مرحله B — برابری و اعتبار (هفته ۳–۴)

| گام | خروجی | تست |
|---|---|---|
| B1 | `CostModel` (اسپرد، کمیسیون، سواپ، slippage) + `FillModel` | تست: با اسپرد صفر و اسپرد واقعی، تفاوت PnL قابل توضیح باشد |
| B2 | `parity harness`: همان استراتژی، همان tape، دو مسیر (backtest / replay-live) | اختلاف PnL < ۱٪ و صفر اختلاف در تعداد معاملات |
| B3 | تست ضد look-ahead: تغییر آینده‌ی tape نباید گذشته را تغییر دهد | property-based test |
| B4 | `walkforward.py` + گزارش overfitting (تعداد پارامتر / طول داده) | — |

### مرحله C — اتصال واقعی، فقط خواندن (هفته ۵)

| گام | خروجی | تست |
|---|---|---|
| C1 | `goldbot_gateway` با `mt5_session`، login، snapshot، stream | تست روی حساب **demo**: مقایسه‌ی پوزیشن‌ها با ترمینال |
| C2 | `live_feed` + `bar_builder` با داده‌ی واقعی | مقایسه‌ی کندل ساخته‌شده با کندل ترمینال (اختلاف < ۱ tick) |
| C3 | تشخیص drift ساعت و آفست بروکر | ثبت آفست در ۲۴ ساعت، پایداری آن |
| **معیار خروج** | ۷۲ ساعت اجرا بدون خطا، صفر ارسال سفارش | — |

### مرحله D — مسیر سفارش روی demo (هفته ۶–۷)

| گام | خروجی | تست |
|---|---|---|
| D1 | `submit` واقعی با SL/TP اتمیک و `max_slippage` | ۱۰ معامله‌ی دستی روی demo؛ بررسی ticket/magic/comment |
| D2 | تزریق قطعی در وسط ارسال (قطع شبکه‌ی عمدی) | تطبیق موفق، صفر سفارش تکراری |
| D3 | `cancel`/`close`/`modify` + مدیریت requote | سناریوی requote اجباری |
| D4 | kill switch کامل (سه سطح) | تزریق `DailyLossBreach` ⇒ توقف فوری |

### مرحله E — عملیات و رصدپذیری (هفته ۸)

| گام | خروجی | تست |
|---|---|---|
| E1 | لاگ ساخت‌یافته + correlation_id سراسری | یک معامله را از سیگنال تا سود، با یک شناسه ردیابی کن |
| E2 | متریک‌ها + `/health` + داشبورد | — |
| E3 | هشدار تلگرام با dedupe و نرخ‌محدود | طوفان خطا ⇒ حداکثر N پیام |
| E4 | بکاپ خودکار + runbook بازیابی | تمرین بازیابی از بکاپ روی ماشین تمیز |

### مرحله F — اثبات مرز پلاگین (هفته ۹)

| گام | خروجی | تست |
|---|---|---|
| F1 | استراتژی دوم با تایم‌فریم و پارامترهای متفاوت، **بدون تغییر در هسته** | دیف `src/goldbot/**` باید صفر باشد |
| F2 | حذف استراتژی اول و اجرای دوباره | بدون خطا، بدون باقی‌مانده در کد |
| **معیار خروج (اثبات معماری)** | افزودن استراتژی دوم = فقط افزودن یک پوشه + یک خط در `registry.toml` | — |

### مرحله G — لایو با سرمایه‌ی حداقلی (هفته ۱۰+)

پیش‌نیازها: ۳۰ روز demo بدون حادثه‌ی `UNKNOWN`، بک‌تست walk-forward با هزینه‌های واقعی، سقف ریسک ۰.۲۵٪، `flatten_on_kill=true`.

---

## ۱۲. پیشنهاد زبان و استک

### ۱۲.۱. انتخاب

**Python 3.12** برای هسته و پژوهش، به‌شرط رعایت سه قید:
1. کد بلاک‌کننده‌ی MT5 هرگز در فرآیند هسته نیست (گیت‌وی جدا).
2. `asyncio` برای هسته، اما هیچ عملیات CPU-bound در event loop نیست (بک‌تست در فرآیند جدا).
3. `mypy --strict` روی `domain` و `ports` اجباری است.

| لایه | انتخاب | چرا |
|---|---|---|
| زبان | Python 3.12 | اکوسیستم پژوهش، سرعت توسعه، کتابخانه‌ی MT5 رسمی |
| مدیریت وابستگی | `uv` | سرعت، قفل‌کردن قابل‌تکرار، سازگار با CI |
| اعتبارسنجی/کانفیگ | `pydantic` v2 + `pydantic-settings` | تایپ‌دار، اعتبارسنجی در استارتاپ، JSON Schema برای پارامتر استراتژی |
| HTTP/WS گیت‌وی | `FastAPI` + `uvicorn` | ساده، مستند خودکار، کافی برای بار کم |
| لاگ | `structlog` (JSON) | فیلدهای ساخت‌یافته، اتصال به correlation_id |
| متریک | `prometheus_client` | بدون سرور، endpoint ساده |
| ذخیره‌سازی | `sqlite3` (stdlib) + `duckdb` + `pyarrow` | بدون سرویس اضافه |
| تست | `pytest` + `hypothesis` + `freezegun`(محدود) + `pytest-asyncio` | پوشش property-based برای دامنه |
| کیفیت | `ruff` + `mypy` + `import-linter` + `gitleaks` | قواعد §۲ به‌صورت خودکار |
| کانتینر | Docker (core) + Windows Service (gateway) | بازتولیدپذیری |

### ۱۲.۲. چرا نه گزینه‌های دیگر

| گزینه | مزیت | چرا رد شد |
|---|---|---|
| **C# / .NET** | بهترین یکپارچگی بومی MT5، تایپ قوی، عملکرد خوب | اکوسیستم پژوهش و تحلیل داده ضعیف‌تر؛ برای یک نفر، هزینه‌ی یادگیری/نگهداری بالاتر از سود |
| **Rust / Go** | ایمنی حافظه، عملکرد، باینری تک‌فایل | برای ۲۰ سفارش در روز، بهینه‌سازی زودهنگام؛ زمان توسعه ۳–۵ برابر |
| **Node/TypeScript** | اکوسیستم وب، async طبیعی | کتابخانه‌ی MT5 بالغ ندارد؛ تحلیل داده ضعیف |

### ۱۲.۳. وابستگی‌های بیرونی و توجیه (الزام ۱۰)

فقط ۸ وابستگی اصلی: `pydantic`, `fastapi`+`uvicorn`, `structlog`, `prometheus_client`, `pyarrow`, `duckdb`, `MetaTrader5`, `httpx`. هر افزودن جدید باید در ADR توجیه شود؛ معیار: «بدون آن، یک قابلیت هسته‌ای قابل پیاده‌سازی نیست یا پیاده‌سازی خانگی‌اش ریسک بیشتری دارد».

---

## ۱۳. مراحل بعدی (فقط فهرست)

پس از تأیید این چهارچوب، هر لایه جدا و عمیق طراحی می‌شود. قالب ثابت هر لایه:
**مسئولیت → اجزای داخلی → قراردادها → سناریوهای خطا → پارامترهای پیکربندی → استراتژی تست → معیار پذیرش.**

| # | لایه | تمرکز طراحی |
|---|---|---|
| ۱ | اتصال بروکر (Broker Gateway) | احراز هویت، reconnect، heartbeat، ترجمه‌ی نماد، idempotency، rate limit |
| ۲ | داده و وضعیت | استریم تیک، ساخت کندل، شکاف داده، منطقه‌ی زمانی و DST، تعطیلات طلا، snapshot |
| ۳ | موتور استراتژی | قرارداد پلاگین، رجیستری، schema پارامتر، چند استراتژی/چند تایم‌فریم، warmup، جداسازی سیگنال از تصمیم |
| ۴ | هسته‌ی مدیریت ریسک | sizing، سقف‌ها، drawdown، همبستگی، فیلتر اسپرد/خبر/سشن، circuit breaker، kill switch |
| ۵ | اجرای سفارش | چرخه‌ی عمر، SL/TP اتمیک، partial fill، slippage، requote، تطبیق پوزیشن |
| ۶ | ژورنال و ذخیره‌سازی | event sourcing، ژورنال معاملات با snapshot سیگنال و ریسک، MAE/MFE، تحلیل عملکرد، داده‌ی تاریخی |
| ۷ | پیکربندی و راز | کانفیگ تایپ‌دار، overlay محیطی، مدیریت راز، چرخش کلید |
| ۸ | رصدپذیری و هشدار | لاگ، متریک، trace، هشدار، داشبورد |
| ۹ | بک‌تست و برابری | مدل اجرا، هزینه‌ها، walk-forward، ضد overfitting، replay |
| ۱۰ | عملیات | استقرار، ارتقای بدون توقف، بازیابی فاجعه، امنیت حساب، دسترسی، بکاپ |

**پیشنهاد ترتیب:** ۱ → ۲ → ۳ → ۴ → ۵ → ۶ → ۸ → ۷ → ۹ → ۱۰ (لایه‌ی ۷ هم‌زمان با ۱ و ۲ به‌صورت حداقلی ساخته می‌شود، ولی طراحی کاملش بعد از تثبیت قراردادها می‌آید).

---

## پیوست الف — چک‌لیست پذیرش مرحله ۰

| معیار | کجای این سند |
|---|---|
| یک مهندس دیگر لایه‌ها و مرزها را می‌فهمد | §۱، §۲ |
| می‌تواند استراتژی جدید را بدون تغییر هسته اضافه کند | §۴.۴، §۸ (`src/strategies/`)، §۱۱-F |
| می‌داند در هر خطا چه اتفاقی می‌افتد | §۶، §۷ |
| می‌داند از کجا شروع کند | §۱۱ (A1 → A5) |
| می‌فهمد چرا هر تصمیم گرفته شده | §۹ (ADR)، §۰.۲ |
| برابری بک‌تست/شبیه‌سازی/لایو تضمین شده | §۳.۲، §۴.۳، ADR-09 |
| بدون بروکر واقعی قابل تست است | §۱.۲ (`FakeBroker`, `TapeFeed`)، §۸ (`tests/contract`) |

