# ADR 043 — آزادسازی اتصال MT5 در تمام مسیرهای خروج از live

**Status:** Accepted — implementation fix in RC 8.2.5

## زمینه

پس از اتصال موفق MT5، آماده‌سازی feed، metadata، history یا ساخت composition root ممکن بود exception بدهد. مسیر قبلی disconnect را فقط برای شکست connect یا حساب real غیرمجاز انجام می‌داد؛ در خطاهای setup ممکن بود اتصال ترمینال در همان process باز بماند.

## تصمیم

- تمام مراحل پس از اتصال و تأیید demo در `try/finally` قرار می‌گیرند.
- اگر Components ساخته شده باشد، در مسیر setup failure بسته می‌شود.
- `broker.disconnect()` در outer `finally` اجرا می‌شود؛ پس از توقف engine نیز اتصال حتماً آزاد می‌شود.

## آزمون پذیرش

تست `test_live_setup_failure_still_disconnects_broker` خطای metadata پس از connect را تزریق می‌کند و assert می‌کند `disconnect()` فراخوانی شده است.
