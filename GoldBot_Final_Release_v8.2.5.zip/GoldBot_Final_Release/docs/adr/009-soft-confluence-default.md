# ADR 009 — Soft confluence is opt-in; reject stays the default

> **وضعیت:** مسیر weak_confluence/smallest با ADR-031/034 بازنشسته شده است؛ این فایل فقط سابقهٔ تصمیم قدیمی است.

## زمینه
پرامپت v2.0 می‌خواست سیگنال تک‌تأیید به‌جای رد، با SMALLEST اجرا شود. این با «سیگنال را نکش» هم‌راستاست،
اما باید با معیار خود پرامپت (DD نه‌بیشتر از baseline، PF نه‌بدتر) سنجیده شود.

## اندازه‌گیری (tape یکسان، medium، ۱۰۰ روز، random walk)
| حالت | معاملات | numeric | خالص | PF | MaxDD |
|---|---:|---:|---:|---:|---:|
| hard (reject) | ۱۵۹ | ۴۶ | +۷.۳۶٪ | ۱.۲۵ | ۴.۲۳٪ |
| soft (smallest) | ۱۷۹ | ۶۷ | +۳.۲۹٪ | ۱.۱۱ | ۴.۴۵٪ |

## تصمیم
پیش‌فرض `weak_confluence_mode = "reject"` می‌ماند. حالت `"smallest"` پیاده‌شده و قابل انتخاب است،
ولی به‌عنوان پیش‌فرض رد می‌شود.

## دلیل
۲۱ معاملهٔ اضافی numeric با برد ۳۴٪ و خالص ‎−۲۱۲$، PF را از ۱.۲۵ به ۱.۱۱ و DD را از ۴.۲۳ به ۴.۴۵ برد؛
یعنی معیار «DD نه‌بیشتر» و «PF نه‌بدتر» نقض شد. روی random walk این تفاوت قطعی نیست، اما شاهد کافی برای
تغییر پیش‌فرض وجود ندارد. اصل «Rule of Last Resort» فقط اجازه می‌دهد قبل از رد، SMALLEST *امتحان* شود؛
اجباری نمی‌کند که SMALLEST پیش‌فرض باشد.

## تست
`test_weak_confluence_defaults_to_reject` و `test_weak_confluence_only_allows_minimum_lot` (حالت soft).
