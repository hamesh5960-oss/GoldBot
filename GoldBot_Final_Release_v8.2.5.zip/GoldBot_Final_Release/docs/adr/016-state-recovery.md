# ADR 016 — وضعیت ریسک باید از ری‌استارت جان سالم ببرد

## زمینه
`RiskState`, `daily_pnl`, `day_start_equity`, `peak_equity`, `orders_today`, `last_order_at`,
`last_loss_at`, `consecutive_losses` و `ticket_meta` فقط در حافظه بودند. یک کرش/آپدیت/ریبوت:
- `KILLED` را به `NORMAL` برمی‌گرداند (قفل ایمنی پاک)،
- سقف ضرر روزانه را صفر می‌کرد،
- `peak_equity` را برابر سرمایهٔ فعلی می‌کرد (drawdown صفر)،
- پوزیشن‌های باز را ناشناس می‌کرد،
- burnهای Gate B را آزاد می‌کرد.

## تصمیم
1. **مرز پورت**: `ports/state.py` با `PersistedRiskState` (نسخه‌دار)، `StateCorruption` و
   `IRiskStateStore`.
2. **آداپتر SQLite**: `adapters/sqlite_state_store.py`؛ یک رکورد کلیددار، UPSERT در یک تراکنش،
   WAL + `synchronous=FULL`. داده‌ٔ خراب یا نسخهٔ ناشناخته هرگز «شروع تازه» نیست: `StateCorruption`.
3. **Write-through واقعی**: هر transition ایمنی (engage/acknowledge/rollover/begin/register_position/
   on_trade_closed/force_quarantine/افزایش orders_today) فوراً نوشته می‌شود؛ markها فقط وقتی
   peak/daily به‌طور مادی تغییر کنند. هیچ بافری بالای آداپتر نیست.
4. **بازیابی دقیق**: همان state/reason/day/peak/orders/ticket_meta برمی‌گردد. `begin()` در همان
   روز معاملاتی، `orders_today` و روز ذخیره‌شده را بازنویسی نمی‌کند؛ مرز روز از DB می‌آید نه از لحظهٔ اجرا.
5. **Cold start fail-safe**: در حالت live/paper اگر رکوردی نباشد ⇒ `QUARANTINE` تا ack انسانی؛
   فقط backtest/demo/synthetic با `allow_cold_start=True` اجازهٔ شروع تازه دارند.
   حالت جاری از `GOLDBOT_MODE` (پیش‌فرض synthetic) یا آرگومان صریح می‌آید.
6. **خروج از قفل فقط با انسان**: `goldbot ack --level killed|quarantine|halted --note ... --confirm`
   + `goldbot status` برای دیدن رکورد. ack در ژورنال با actor=operator ثبت می‌شود.
7. **حالت مجاور (Gate A/B/C)**: فیلد `extras` در همان رکورد؛ `CooldownManager.snapshot/restore`
   شامل `bar_index`, `last_exec_bar`, burnها، `sl_counts` و نقشهٔ ticket→zone.
   ذخیره فقط وقتی snapshot تغییر کند (نه هر تیک).
8. **مسیر DB**: `GOLDBOT_STATE_DB` > آرگومان صریح > `var/risk_state.db` برای ژورنال متعارف؛
   هر ژورنال دیگر فایل کنار خودش را می‌گیرد تا یک backtest قفل یک اجرای دیگر را به ارث نبرد.
   اجرای تازهٔ demo/backtest (بدون `--keep`) فقط state db مشتق‌شده را پاک می‌کند، نه state db دستی.

## تست
`tests/test_state_recovery.py` (۲۲ تست): cold-restart برای NORMAL/HALTED/KILLED/QUARANTINE،
پایداری ticket_meta و orders_today، روز جدید پس از halt، state خراب ⇒ QUARANTINE،
cold start در live/paper، ack/status CLI، bootstrap واقعی، و ماندگاری burnهای Gate B.
`tests/test_gates.py` یک round-trip snapshot/restore دارد.

## محدودیت
- payload خراب آرشیو نمی‌شود؛ با QUARANTINE بازنویسی می‌شود (خود رکورد خام از دست می‌رود).
- رکورد در یک ردیف است؛ برای چند اکانت/چند نماد هم‌زمان باید `key` جدا ساخت.
- وضعیت داخلی استراتژی‌ها (نه Gateها) عمداً ذخیره نمی‌شود: از تاریخ/کندل بازساخته می‌شود.
- اگر کرش بین fill بروکر و نوشتن ژورنال رخ دهد، ردیف باز ممکن است ناقص بماند (reconcile آن را می‌بیند).
