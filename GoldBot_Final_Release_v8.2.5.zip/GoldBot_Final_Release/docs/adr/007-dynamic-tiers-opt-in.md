# ADR 007 — Dynamic tier/invalidation are opt-in, default off

> **وضعیت:** بخش‌های مربوط به dynamic tier bands با ADR-032/034 بازنشسته شده‌اند؛ این فایل فقط سابقهٔ تصمیم قدیمی است.

## زمینه
پرامپت پیشنهاد می‌کند آستانهٔ Tier و فاصلهٔ invalidation با ATR جابه‌جا شوند. این تغییر در بازار پرنوسان ریسک را بالا می‌برد و هیچ شاهد بیرون‌نمونه‌ای ندارد.

## تصمیم
- `[trading] dynamic_tier_margin = 0.0` (خاموش).
- `invalidate_mode = "fixed"` (پیش‌فرض)؛ `"dynamic"` فقط با انتخاب اپراتور.
- پیاده‌سازی و تست هست، ولی رفتار پیش‌فرض v1.1 تغییر نمی‌کند.

## دلیل
«ابزار حذف نشده» ولی «تغییر بدون داده» هم انجام نشده. فعال‌سازی باید بعد از بک‌تست واقعی و با ADR جدید باشد.

## تست
`test_dynamic_invalidation_scales_with_atr` و `test_dynamic_tier_shift_lowers_bands_in_volatility`.
