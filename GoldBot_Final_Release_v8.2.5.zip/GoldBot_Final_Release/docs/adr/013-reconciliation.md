# ADR 013 — Reconciliation is periodic and gates new entries

## زمینه
Reconcile فقط در startup اجرا می‌شد. یک disconnect می‌توانست وضعیت محلی را کهنه کند و ورود جدید با
پوزیشن یتیم/بدون محافظ ترکیب شود.

## تصمیم
- هر ۵ دقیقه یک reconcile در `_on_tick` **قبل از** پردازش کندل.
- اختلاف ⇒ `QUARANTINE` + توقف ورود.
- `RiskContext.reconciled` و `check_reconciliation` ورود با snapshot کهنه را رد می‌کنند.
- پوزیشن orphan به‌صورت خودکار بسته **نمی‌شود**؛ بستن خودکار می‌تواند معاملهٔ دستی اپراتور را ببندد. قرنطینه + هشدار.

## تست
`test_reconciliation_check_is_fail_closed` و تست‌های قبلی reconcile.

## محدودیت
بازیابی پس از ری‌استارت و adoption پوزیشن هنوز پیاده نشده (P0 باقی‌مانده).