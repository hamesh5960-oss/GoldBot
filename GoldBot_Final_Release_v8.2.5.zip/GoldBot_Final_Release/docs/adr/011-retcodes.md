# ADR 011 — Retcodes are classified in the domain; retry loop waits for the gateway

## زمینه
`FakeBroker` چند retcode برمی‌گرداند و coordinator فقط `retryable` را از نام رشته می‌ساخت.
بدون جدول واحد، requote/price_changed در live می‌تواند به معاملهٔ نامعلوم تبدیل شود.

## تصمیم
`domain/retcodes.py` با `RetcodeAction` و جدول ۲۰ کد؛ کد ناشناخته ⇒ `QUARANTINE` (هرگز retry کور).
`OrderCoordinator` اکشن را در event و `ExecutionResult.action` ثبت می‌کند.

## چرا retry loop اعمال نشد
Retry واقعی نیازمند قیمت تازه و **مهر مجدد ریسک** است؛ با اوردر sealشده و بدون gateway قابل پیاده‌سازی امن نیست.
در فاز MT5 یک حلقهٔ ۳ مرحله‌ای با بازمحاسبهٔ SL/volume و order_check اضافه می‌شود.

## تست
`test_retcode_table_is_fail_closed`.