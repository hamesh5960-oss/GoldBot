# ADR 026 — ژورنال دو جدولی سیگنال، ماتریس قابلیت و سشن/DST

## زمینه
ژورنال فقط معامله‌های بسته را داشت؛ معلوم نبود چند سیگنال به‌خاطر Tier/gate/capital رد شد،
آیا سطح بالاتر می‌توانست آن را بگیرد، یا سیگنال در کدام سشن/DST بود.

## تصمیم
- SignalRecord (۴۰ فیلد) و SignalLevelRecord (۱۷ فیلد) در domain/events؛ جدول‌های
  signal_journal و signal_level_capability با migration افزودنی و index.
- Engine برای هر intent بعد از decide یک رکورد و چهار ردیف قابلیت (BASE/LOW/MEDIUM/HIGH)
  می‌نویسد؛ outcome هنگام بستهٔ معامله به‌روزرسانی می‌شود.
- app/market_session.py: سشن‌ها، آفست، DST US/EU، minutes_into_session؛
  app/level_eval.py: eval_for_level خالص + min_capital_needed و capital_gap.
- build_signal_workbook: شیت‌های Signals, Level_Capability, Capability_Matrix,
  Session_Analysis, Summary؛ report --xlsx در صورت وجود سیگنال همین را می‌نویسد.
- stats(): signals_total/executed/watch، missed_capital/level، by_session، by_tier.

## تست
test_signal_journal (۱۵)، test_excel_signals (۱۲)، test_market_session (۳۲)،
test_level_eval (۳۱)، test_engine_signal_journal (۵ تست یکپارچه).

## محدودیت
- فقط intentهای بعد از prefilter ثبت می‌شوند (عمدی).
- params_snapshot فعلاً خلاصه است (config_hash/profile/scoring)؛ snapshot کامل فاز بعد.
- missed باید در گزارش‌ها به دو دستهٔ کمبود سرمایه و سطح انتخابی تفکیک شود.
