# ADR 003 — Composite: penalty layer instead of clamp-to-zero

## زمینه
`composite_score` مقدار منفی Signal را صفر می‌کرد؛ Signal=-2 و Signal=0 یکسان می‌شدند.

## تصمیم
`bonus = clamp(S/2,0,1)×50` و `penalty = clamp(-S/2,0,1)×30`؛
`Composite = 0.5×Zone + bonus − penalty`، سپس clamp(0,100).

## دلیل
سیگنال منفی Tier را پایین می‌آورد ولی «نامرئی» نمی‌شود. برای سیگنال‌های فعلی (S≥0.3) رفتار عوض نمی‌شود، پس ریسک بدون داده بالا نمی‌رود.

## تست
`test_composite_penalises_negative_signal_without_zeroing`.
