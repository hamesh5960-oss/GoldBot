# ADR 010 — Symbol metadata is validated and broker stops are a hard check

## زمینه
تنظیمات نماد در TOML بود و هیچ اعتبارسنجی زمان‌اجرا نداشت؛ حداقل فاصلهٔ SL بروکر
(`stops_level`) با حد پروفایل قاطی می‌شد. اگر metadata اشتباه باشد، SL رد می‌شود یا پوزیشن بی‌محافظ می‌ماند.

## تصمیم
- `domain/symbol_meta.SymbolMeta.from_symbol_info` + `validate()` (digits/point/contract/volume/step/stops) در startup.
- `checks.check_broker_stops`: فاصلهٔ SL و TP باید ≥ `stops_level×point` باشد، مستقل از `min_sl_points` پروفایل.
- Provider واقعی MT5 در فاز gateway اضافه می‌شود؛ این کلاس همان قرارداد را دارد.

## تست
`test_symbol_meta_roundtrip_and_validation`، `test_broker_stops_are_independent_of_profile`.

## محدودیت
filling_mode و freeze_level در اجرای FakeBroker قابل تست نیستند؛ به gateway موکول شد.