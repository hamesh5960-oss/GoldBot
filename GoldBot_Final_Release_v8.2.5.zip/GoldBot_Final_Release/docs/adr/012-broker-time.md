# ADR 012 — Rollover and the trading day use broker time

## زمینه
`event_factor` و `RiskEngine._rollover` از UTC استفاده می‌کردند. با `broker_offset=2h`، بلاک rollover
دو ساعت دیر بود و حد ضرر روزانه بین ۰۰:۰۰ UTC و ۰۰:۰۰ بروکر جابه‌جا می‌شد.

## تصمیم
- `RiskContext.broker_now` از `clock.broker_now()`; `plan_entry` و `event_factor` آن را برای rollover استفاده می‌کنند.
- `begin/_rollover` تاریخ روز را از broker می‌گیرند.
- سه‌شنبه‌سوآپ (چهارشنبه ۲۰:۰۰ بروکر) بلاک می‌شود.
- `adapters/time_service.TimeService` نمای UTC/broker/local (Iran +03:30 ثابت) می‌دهد.

## تست
`test_rollover_uses_broker_time_not_utc`، `test_triple_swap_blackout`، `test_time_service_exposes_three_clocks`.

## محدودیت
سشن‌های استراتژی هنوز از ساعت کندل UTC می‌آیند؛ یکسان‌سازی کامل در فاز بعد.