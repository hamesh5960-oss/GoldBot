# ADR 020 — بودجهٔ سفارش نمی‌تواند از سقف پروفایل بزرگ‌تر باشد

## زمینه
`[budget]` در config/base.toml سراسری بود: `soft_limit=10` و `hard_limit=15`.
سقف واقعی در RiskEngine از `profile.max_orders_per_day` می‌آمد (low=۵، medium=۱۰، high=۲۰).
نتیجه:
- روی medium، بودجه تا ۱۵ HALF را «مجاز» می‌دانست ولی `check_orders_per_day` در ۱۰ رد می‌کرد؛
  ناحیهٔ ۱۰–۱۵ مرده بود و Tier A+ در جایگاه ۱۱ رد می‌شد در حالی که بودجه می‌گفت HALF بده.
- روی low، تمام منطق reserve/extended عملاً بی‌اثر بود چون سقف ۵ قبل از soft_limit=۱۰ فعال می‌شد.
- ژورنال `threshold=10` را ثبت می‌کرد، پس گزارش هم عدد اشتباه نشان می‌داد.

## تصمیم
- `BudgetParams.for_profile(max_orders_per_day)` هر دو سقف را به سقف پروفایل clamp می‌کند:
  `hard = min(hard_limit, cap)`, `soft = min(soft_limit, hard)`.
- این clamp در `RiskEngine.evaluate_entry` اعمال می‌شود؛ config سراسری دست‌نخورده می‌ماند،
  ولی بودجهٔ اعلام‌شده و بودجهٔ اجراشده یکی می‌شوند.
- سقف مطلق `check_orders_per_day` همچنان آخرین مرجع است (fail-closed).

## تست
`tests/test_budget.py`:
- پروفایل ۱۰: `(10, 10)`؛ در جایگاه ۱۰ هیچ HALF صادر نمی‌شود.
- پروفایل ۶: `(6, 6)`.
- پروفایل ۴۰: پیش‌فرض `(10, 15)` حفظ می‌شود.

## محدودیت
ناحیهٔ extended (A+ با HALF) فقط روی پروفایل‌هایی معنا دارد که سقف روزانه‌شان > soft_limit باشد
(مثلاً high=۲۰)؛ برای low/medium عملاً حذف می‌شود. این عمدی است: HALF اضافه‌تر از سقف پروفایل
یک ریسک بدون پشتوانه است.
