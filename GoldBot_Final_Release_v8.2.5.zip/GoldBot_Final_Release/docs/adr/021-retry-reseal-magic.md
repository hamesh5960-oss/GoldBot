# ADR 021 — retry فقط با مهر جدید، و مالکیت پوزیشن یتیم با magic

## زمینه
`ApprovedOrder` با HMAC روی `(intent_id, slot, strategy, symbol, side, volume, sl, tp, magic, client_ref)`
مهر می‌شود. retry با tick جدید یعنی قیمت/SL تازه، پس مهر قبلی معتبر نیست. اگر retry بدون
`RiskEngine.evaluate_entry` دوباره انجام شود، سفارشی اجرا می‌شود که ریسک تأییدش نکرده است
(مثلاً spread پهن‌شده یا SL کمتر از `stops_level`).
همچنین نقشهٔ راه گفته بود orphan را ببندد؛ ولی orphan می‌تواند معاملهٔ دستی اپراتور باشد.

## تصمیم
- `app/retry_guard.py` تنها نقطهٔ تصمیم «آیا اصلاً retry مجاز است؟» است؛ pure و fail-closed:
  spread widened، broker stops invalid، price drift > max_slippage_points و ریسک بالاتر از سقف
  ⇒ `RetryDecision(False, reason)`. در حالت سالم `requires_reseal=True` برمی‌گرداند؛
  یعنی retry باید از `evaluate_entry` رد شود، مهر تازه بگیرد و بعد ارسال شود.
- retry loop واقعی در فاز MT5 ساخته می‌شود (بدون gateway نمی‌شود ریسک را دوباره تأیید کرد)؛
  قاعده و تست هم‌اکنون وجود دارد و loop بعداً فقط این تابع را صدا می‌زند.
- `app/ids.py`: `GOLDBOT_MAGIC_BASE=7300` و `owns_position_magic(magic)`. reconciliation فقط
  پوزیشن‌های با magic متعلق به ربات را می‌تواند ببندد؛ magic ناشناخته ⇒ هشدار، نه بستن.
  (بستن خودکار در فاز MT5 فعال می‌شود؛ ADR-013 هنوز قرنطینه را ترجیح می‌دهد.)

## تست
`tests/test_retry_reseal.py`: spread widened ⇒ abort؛ stops_level نقض‌شده ⇒ abort؛ drift بیش از
slippage ⇒ abort؛ ریسک بالای سقف ⇒ abort؛ retry سالم ⇒ allowed + requires_reseal؛
مهر قدیمی برای قیمت جدید invalid است؛ magic غریبه owned نیست.

## محدودیت
- تشخیص drift به `risk.stop_distance` مهرشده تکیه دارد (entry تقریبی بازسازی می‌شود)؛
  در MT5 باید `order.request.price` واقعی هم ذخیره و مقایسه شود.
- تا نبودن gateway، این guard فقط در تست و مسیرهای آینده استفاده می‌شود.
