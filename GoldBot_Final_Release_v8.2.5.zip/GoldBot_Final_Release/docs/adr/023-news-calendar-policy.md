# ADR 023 — سیاست خبر: تقویم CSV + fallback محافظه‌کارانه

## زمینه
RiskContext.news_blackout عملاً همیشه False بود؛ FOMC/NFP/CPI هیچ گیتی نداشت.

## تصمیم
- app/news.py خالص: NewsEvent, NewsParams, NewsWindow.blackout(now_utc). high: ۳۰ دقیقه قبل /
  ۶۰ بعد؛ medium: ۱۵/۳۰. HIGH بر MEDIUM مقدم، مرزها شامل، رویداد منقضی نادیده، ورودی خراب
  بدون exception.
- adapters/news_calendar.py: CSV با ستون‌های منعطف (date/timestamp/time، impact/importance،
  title/event، currency)؛ فایل گم‌شده/خراب یعنی ([], False) بدون کرش؛ unknown impact یعنی MEDIUM.
- fail_safe=conservative: پنجره‌های قطعی ۱۴:۳۰ و ۱۸:۰۰ UTC با عرض ۱۵ دقیقه؛ trading_disabled
  یعنی همیشه بسته.
- Engine مقدار news_blackout را از NewsWindow.blackout(ctx.now) در RiskContext می‌گذارد؛
  capital.event_factor و check_news مثل قبل واکنش می‌دهند.
- کانفیگ [news]: enabled, calendar_source=csv, calendar_path, پنجره‌ها, fail_safe.

## تست
۳۵ تست tests/test_news.py: مرزهای دقیق، تداخل high/medium، LOW بی‌اثر، رویداد منقضی/خراب،
پنجرهٔ conservative، حالت trading_disabled، پارس CSV در حالت‌های مختلف.

## محدودیت
- تازگی تقویم CSV کنترل خودکار نمی‌شود (refresh فاز بعد).
- زمان‌ها UTC فرض شده و فیلتر ارز/تأثیر ندارد؛ برای چند نماد باید اضافه شود.

## اصلاح RC 8.2.5 — پنجرهٔ fallback و ساعت تابستانی آمریکا (SES-04)
- مشکل: پنجره‌های قطعی ۱۴:۳۰ و ۱۸:۰۰ UTC ثابت بودند. در نیمهٔ سال که US DST فعال است،
  انتشارهای مهم آمریکا (NFP/CPI) ساعت ۱۳:۳۰/۱۷:۰۰ UTC رخ می‌دهند؛ پس fallback تا ۶۰ دقیقه
  دیر می‌شد و ممکن بود ورود در پنجرهٔ واقعی خبر رد نشود.
- تصمیم: مقادیر conservative_windows مرکزِ «زمان استاندارد (زمستان)» به UTC هستند. هنگام
  فعالیت US DST، مرکز مؤثر یک ساعت عقب‌تر تفسیر می‌شود (پیش‌فرض: ۱۳:۳۰/۱۷:۰۰ UTC).
  قاعدهٔ DST فقط با محاسبهٔ تقویمی و بدون tzdata: از ۰۷:۰۰ UTC دومین یکشنبهٔ مارس
  (۰۲:۰۰ EST) تا ۰۶:۰۰ UTC اولین یکشنبهٔ نوامبر (۰۲:۰۰ EDT)؛ همان تابع
  market_session.us_dst_active که app/news.py استفاده می‌کند.
- اثر روی پیش‌فرض: زمستان ۱۴:۱۵–۱۴:۴۵ و ۱۷:۴۵–۱۸:۱۵ UTC؛ تابستان ۱۳:۱۵–۱۳:۴۵ و
  ۱۶:۴۵–۱۷:۱۵ UTC. پنجره‌های سفارشی هم با همین قاعده جابه‌جا می‌شوند.
- تست: tests/test_news.py — زمستان/تابستان و روزهای معاملاتی مجاور مرزهای مارس و نوامبر.
- محدودیت: این قاعده تقویم تقریبی انتشار آمریکا را دنبال می‌کند؛ ساعت دقیق انتشار ممکن است
  تغییر کند و تقویم تازه همچنان منبع ترجیحی است.
