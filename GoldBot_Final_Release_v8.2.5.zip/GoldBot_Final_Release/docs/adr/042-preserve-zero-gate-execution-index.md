# ADR 042 — حفظ مقدار صفر در بازیابی Gate A

**Status:** Accepted — implementation fix in RC 8.2.5

## زمینه

در `CooldownManager.restore()` مقدار `last_exec_bar` با الگوی `value or -10000` بازیابی می‌شد. مقدار معتبر صفر در Python falsy است؛ بنابراین اگر آخرین اجرا در bar index صفر رخ می‌داد، پس از restart به sentinel `-10000` تبدیل می‌شد و Gate A می‌توانست تصور کند اجرای قبلی وجود نداشته است.

## تصمیم

- فقط `None` به sentinel `-10000` تبدیل می‌شود؛ صفر یک bar index معتبر است و باید عیناً حفظ شود.
- تست round-trip باید snapshot با `last_exec_bar=0` را بدون تغییر بازیابی کند.

## اثر ایمنی

این اصلاح مانع از دور زدن ناخواستهٔ پنجرهٔ سکوت Gate A پس از restart در مرز bar index صفر می‌شود.
