# ADR 017 — TP سه‌لایه با FSM ایدمپوتنت و partial اتمی

## زمینه
خروج فاز ۱ یک TP + BE + trail ساده بود. در نوسان XAUUSD retrace بعد از حرکت بزرگ ۳۰–۴۰٪ است و
یک تک‌تارگت بخش زیادی از سود را برمی‌گرداند. `partial_close` در FakeBroker وجود داشت اما
هیچ state machine چندمرحله‌ای و هیچ retry ایدمپوتنتی نبود.

## تصمیم
- `domain/fsm/position.py`: `PositionPhase`: OPEN → PARTIAL_1 → PARTIAL_2 → TRAILING → CLOSED
  با transition guard (بدون دست‌زدن به `PositionState` قدیمی).
- `app/position_fsm.py`: `TPPlan(tp1,tp2,tp3, 50/30/20, be_after_tp1, trail_atr_mult=1.5)` و
  `PositionFSM`. هر action یک شیء ثابت است تا وقتی ack نیامده تکرار شود (idempotent);
  `on_action_done` ایدمپوتنت است و over-close را رد می‌کند.
- ساخت نردبان: R = |entry-stop|؛ TP1=1R، TP2=2R، TP3=target (اگر target<2R، TP2=75٪ مسیر و TP3=target).
  اگر حجم < `2 × volume_min` باشد partial ممنوع و مسیر تک‌تارگت با BE/trail فعال می‌شود.
- SL هرگز عقب نمی‌رود: BUY فقط بالاتر، SELL فقط پایین‌تر. TP1→BE، TP2→TP1، بعد TRAILING با ATR.
- اجرا: `order_coordinator.close_position` کسر را به حجم بروکر (floor به volume_step) تبدیل می‌کند؛
  کسر < min lot یا ≥ کل پوزیشن به close کامل تبدیل می‌شود. هر action حداکثر ۳ بار retry؛
  پس از آن CLOSE اجباری.
- `FakeBroker` تزریق خرابی دارد (`fail_next_modify/close`, `scenario="partial_then_sl_fail"`).
- RiskEngine فقط closeهای زمانی/سخت را برای پوزیشن‌های دارای FSM اجرا می‌کند؛ trail/BE آن برای
  این تیکت‌ها غیرفعال است تا با FSM نجنگد.

## تست
`tests/test_position_fsm.py` (۲۴ تست): پیشرفت فازها، برش ۵۰/۳۰/۲۰، ایدمپوتنسی، BE→TP1،
monotonic trail (buy/sell)، مسیر تک‌تارگت زیر 2×min، دقیقاً 2×min، over-close، retry پس از
شکست modify، خستگی retry ⇒ flatten، حالت sell، netting (رد صریح + هشدار)، و اجرای واقعی
سه‌لایه در `_apply_management`.

## محدودیت
- FSM روی مرز کندل اجرا می‌شود؛ گپ از TP3 همهٔ پله‌ها را در یک کندل به ترتیب پر می‌کند.
- برش‌ها با floor volume_step ممکن است کمی از ۵۰/۳۰/۲۰ فاصله بگیرند.
- در netting حالت partial غیرفعال است (هشدار یک‌باره)؛ برای live باید تصمیم جدا گرفته شود.
- ژورنال یک ردیف به‌ازای پوزیشن دارد؛ PnL برش‌ها در همان ردیف تجمیع می‌شود.
