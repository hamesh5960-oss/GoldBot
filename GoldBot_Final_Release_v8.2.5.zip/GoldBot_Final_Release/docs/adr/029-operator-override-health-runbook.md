# ADR 029 — Override اپراتور، health و runbook عملیاتی

## زمینه
اپراتور نمی‌توانست بدون restart ربات را متوقف کند؛ health/الرت یکپارچه و رویهٔ rollback مکتوب نبود.

## تصمیم
- Override: goldbot override --pause-minutes N --reason --confirm فیلد manual_pause_until
  را در extras می‌نویسد؛ RiskEngine.check_manual_pause ورود جدید را رد می‌کند و پوزیشن باز
  دست نمی‌خورد. --resume پاک می‌کند. --weekend-hours مجوز صریح عبور از آخر هفته است
  (actor=operator). Engine هر کندل reload_aux می‌کند.
- Health: app/health.py (بدون exception) + CLI goldbot health --json + GET /api/health
  (503 اگر degraded). heartbeat کهنه/گم‌شده یعنی degraded.
- RUNBOOK: docs/RUNBOOK.md شامل kill switch + ack، شکست آخر هفته، reconciliation، state خراب،
  بکاپ، rollback، ژورنال، flatten اضطراری و چک‌لیست on-call.

## تست
test_manual_pause (۲)، test_chaos (۱۳ شامل health)، test_engine_signal_journal::health، و
smoke CLI override/health/status.

## محدودیت
- flatten اضطراری از CLI وقتی engine زنده نیست معنا ندارد؛ در فاز gateway/پنل زنده اضافه می‌شود.
- pause با wall-clock است، پس روی replay با tape قدیمی منقضی به نظر می‌رسد.
