# ADR 025 — سقف ریسک باز هر پروفایل و رفع عدد ۳٪ مرده

## زمینه
portfolio_ceiling_pct=3.0 و gate_d_hard_pct=2.0 هم‌زمان بودند و کد min می‌گرفت؛ پس ۳٪
هرگز اثر نداشت. سقف ریسک باز مستقل per-profile هم وجود نداشت.

## تصمیم
- RiskProfile.max_open_risk_pct (پیش‌فرض ۲.۰، مجاز ۰.۵..۳.۰) اضافه شد و در
  capital.plan_entry با min(portfolio_ceiling, gate_d_hard, profile cap) اعمال می‌شود.
- پیش‌فرض‌ها پاکت v1.1 را حفظ می‌کنند؛ رسیدن به ۳٪ نیازمند ویرایش صریح profile است
  (config hash در ژورنال تغییر می‌کند).
- validate_consistency: سقف باز نمی‌تواند از max_total_dd_pct بیشتر باشد.

## تست
tests/test_capital.py و test_profiles: سقف باز لات را کم می‌کند، مقدار بالاتر پذیرفته نمی‌شود،
رفتار پیش‌فرض حفظ می‌شود، Gate D hard با ceiling سازگار است.

## محدودیت
- spec برای MEDIUM/HIGH عدد ۳٪ می‌خواست؛ چون شل‌کردن باید صریح باشد پیش‌فرض ۲٪ ماند.
