# ADR 008 — HMAC secret source: env first, fail-closed on request

## زمینه
کلید HMAC هر فرایند تصادفی بود؛ با ری‌استارت، سفارش‌های sealشدهٔ قبلی قابل تأیید نبودند.

## تصمیم
`GOLDBOT_HMAC_SECRET` اگر ست باشد استفاده می‌شود؛ `GOLDBOT_REQUIRE_SECRET=1` و نبود کلید ⇒ استارت با `InvariantError` متوقف می‌شود. در غیر این صورت رفتار قبلی (کلید موقت) حفظ می‌شود.

## دلیل
fail-closed اختیاری است تا demo فعلی نشکند؛ برای live باید حتماً روشن باشد.

## تست
`test_hmac_secret_can_come_from_env` و `test_hmac_required_fails_closed`.
