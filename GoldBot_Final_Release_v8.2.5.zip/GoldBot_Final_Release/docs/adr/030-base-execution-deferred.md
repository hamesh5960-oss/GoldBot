# ADR 030 — مسیر اجرای BASE (۵٪) عمداً مسلح نشده است

## زمینه
spec مالک BASE band با ریسک ۵٪ برای حساب زیر ۲۰۰ دلار می‌خواهد. اجرای ۵٪ نیازمند یک مسیر
سرمایهٔ جداگانه (CapitalParams با ceiling/trade-cap=5، profile clone مخصوص، شواهد ۳۰ روزه
دمو) است. فعال‌کردن پیش‌فرض آن با پاکت ۱.۵٪ در تناقض است و می‌تواند حساب کوچک را در چند
معامله صفر کند.

## تصمیم
- کنترلر، باندها، هیسترزیس، قفل ساختاری ۵٪، تست نشت و onboarding کامل پیاده شد (ADR-027).
- اما execution سایز BASE فعال نیست: active_level_for_execution با نبود هر interlock
  (enabled/base_enabled/base_armed/onboarding_ack/equity<200) مقدار None می‌دهد و engine
  reason=base_locked را ژورنال و رد می‌کند. هیچ ۵٪ بی‌صدایی وجود ندارد.
- [levels] base_armed=false پیش‌فرض؛ CLI onboarding هشدار متنی می‌دهد.
- فعال‌سازی آینده: CapitalParams.for_base + profile مخصوص + شواهد ۳۰ روزه + ADR جدا.

## تست
test_capital_levels قفل ۵٪ (فقط باند۰، هرگز >۵، نشت صفر) + level_gate base locked +
اجرای واقعی equity=150 با صفر intent و reason=base_locked.

## محدودیت
- حساب زیر ۲۰۰ دلار با کانفیگ پیش‌فرض معامله نمی‌کند (امن‌ترین رفتار)؛ باید مسیر BASE یا
  حساب micro/cent فعال شود.
