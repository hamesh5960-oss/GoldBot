# ADR 019 — بدون هزینهٔ کامل، هیچ عدد بک‌تستی معتبر نیست

## زمینه
فقط کمیسیون ۷$/lot در محاسبه بود. swap (به‌ویژه triple swap چهارشنبه)، slippage خبری و
spread در سایز/ژورنال غایب بودند؛ پس سایز ریسک کمتر از واقع و آمار بک‌تست خوش‌بینانه بود.
همچنین هیچ fingerprint از config در ژورنال نبود و بک‌تست بازتولیدپذیر نبود.

## تصمیم
- `app/costs.py`: `CostParams` + `CostBreakdown` + `swap_for_nights` + `nights_charged` +
  `estimated_round_trip` + `effective_loss_per_lot`. همهٔ مبالغ cost-positive‌اند (credit منفی).
  swap سه‌شنبهٔ شبانه (چهارشنبه بروکر) سه‌برابر؛ Friday→Monday یک شب؛ آخر هفته‌ها rollover ندارند.
- **سایز بر اساس ضرر مؤثر**: `capital.plan_entry` در صورت وجود `CostParams` به‌جای
  `stop*contract + commission` از `effective_loss_per_lot` استفاده می‌کند (کمیسیون + slippage +
  spread + `abs(swap)`). یعنی در live/با اسپرد واقعی، لات کوچک‌تر از بک‌تست بدون هزینه است.
- **ژورنال**: `config_hash` (SHA-256 canonical از settings، بدون path/host/port)،
  `entry_slippage_pts`, `spread_at_signal_pts`, `spread_at_fill_pts`, `latency_ms`,
  `commission_actual`, `swap_actual`, `estimated_cost`, `actual_cost`.
  مهاجرت additive با `PRAGMA table_info` + `ALTER TABLE` برای ژورنال‌های قدیمی.
- `RiskEngine` تخمین هزینه را در `RiskEvaluated` و `OrderApproved` journal می‌کند؛
  هنگام بستن، `actual_cost = commission - swap` و اگر drift > ۱۵٪ باشد `CostDrift` + alert.
- triple swap و rollover در `event_factor` قبلاً سخت‌بلاک بودند و دست‌نخورده ماندند.

## تست
`tests/test_costs.py` (۱۵): سه‌برابر شدن swap، پرش آخر هفته، credit، news، فرمول ضرر مؤثر،
round-trip ژورنال و migration. `tests/test_config_hash.py` (۹): پایداری/حساسیت hash و نادیده‌گرفتن path.
`tests/test_capital.py` دو تست جدید: مدل هزینهٔ صفر = فرمول قبلی؛ هزینهٔ کامل ⇒ لات نه‌بزرگ‌تر.

## نتیجهٔ ۱۰۰ روزه (همان tape، medium، random walk)
۱۵۲ معامله، +۱۱.۶۳٪، PF ۱.۴۳، MaxDD ۳.۰۴٪، NORMAL (v3: ۱۴۹/+۷.۳۰٪/۱.۲۶/۳.۷۹٪).
هزینهٔ واقعی FakeBroker فقط کمیسیون است (swap/slippage صفر) پس drift در synthetic طبیعی است؛
مقایسهٔ واقعی باید با deal commission/swap بروکر انجام شود.

## محدودیت
- swap/slippage پیش‌فرض‌ها محافظه‌کارانه‌اند و باید از تاریخ بروکر کالیبره شوند.
- لازم‌الاجرا: بروکر swap را در deal history برمی‌گرداند؛ بدون آن drift فقط هشدار است.
- config_hash فقط settings را پوشش می‌دهد، نه فایل‌های استراتژی/ناحیه‌ها (باید فاز ۲ اضافه شود).
