# ADR 005 — Quality rejects become SMALLEST, traps stay rejected

## زمینه
Gate B (بدون bypass) و Gate C (تراکم جهت) سیگنال را کامل رد می‌کردند؛ این با «سیگنال را نکش» در تضاد بود، ولی اجرای min-lot برای هر کیفیت بدی هم خطرناک است.

## تصمیم
- Gate B: اگر ناحیه یک بار سوخته ⇒ SMALLEST؛ اگر دو بار ⇒ `Zone_Burn_Trap` رد.
- Gate C: تراکم جهت ⇒ SMALLEST؛ Hedge روی پوزیشن سودده / سیگنال ضعیف ⇒ رد (قواعد ایمنی).
- Gate A، Gate D، Rollover، Margin، Spread، min-lot غیرقابل‌تأمین ⇒ رد.

## دلیل
یک لات حداقل ریسک کوچکی دارد و سیگنال را زنده نگه می‌دارد؛ ناحیهٔ معیوب و Hedge خطرناک رد می‌شوند. REJECT فقط در حالت‌های ایمنی/فیزیکی می‌ماند.

## تست
`test_gate_b_twice_burned_zone_is_a_trap`، `test_gate_c_range_allows_one_direction`، `test_force_min_lot_is_one_step`.
