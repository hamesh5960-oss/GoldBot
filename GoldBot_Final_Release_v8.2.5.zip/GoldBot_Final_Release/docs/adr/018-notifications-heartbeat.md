# ADR 018 — رویدادهای بحرانی باید بیرون از ربات شنیده شوند

## زمینه
هیچ alert و هیچ heartbeat نبود. اگر ربات در live بی‌صدا می‌مرد، فقط با باز کردن پنل معلوم می‌شد؛
یک پوزیشن باز می‌توانست ساعت‌ها بدون محافظ بماند.

## تصمیم
- آداپترهای `adapters/notifier.py`: `LogNotifier`, `TelegramNotifier`, `SmtpNotifier`,
  `MultiNotifier`, `DedupNotifier(ttl=600s, max_per_minute=10)` و `from_env()`.
  هیچ کانالی exception بیرون نمی‌دهد و هر ارسال حداکثر ۵ ثانیه است.
- پیام‌ها از `RiskEngine.engage` (HALTED/KILLED/QUARANTINE) و `TradingEngine`:
  reconciliation drift، order outcome unknown، رد سفارش (به‌ویژه `quarantine`)،
  و drift هزینهٔ تخمینی vs واقعی. dedup واقعی است تا یک رویداد تکرارشونده اسپم نشود.
- `app/heartbeat.py`: نوشتن اتمیک JSON (tmp + `os.replace`) هر ۵ دقیقه با ts/pid/ticks/state/
  equity/positions؛ `is_stale` تحمل فایل گم‌شده/خراب را دارد.
- **Watchdog بیرونی** `scripts/watchdog.py` (Task Scheduler/cron هر ۵ دقیقه): اگر heartbeat از
  `--max-age` قدیمی‌تر بود exit 1 + تلاش برای alert. watchdog داخل خود ربات نیست: ربات مرده
  نمی‌تواند مرگ خودش را اعلام کند.
- env: `GOLDBOT_TELEGRAM_TOKEN`, `GOLDBOT_TELEGRAM_CHAT_ID`, `GOLDBOT_SMTP_*`.

## تست
`tests/test_notifier.py` (۲۴) و `tests/test_heartbeat.py` (۲۷): dedup/rate-limit، شکست بی‌صدا،
تلگرام mock، heartbeat اتمیک/throttle/stale، watchdog روی فایل کهنه exit 1.

## محدودیت
- Dedup در حافظه است؛ بعد از restart ممکن است یک alert تکراری برود.
- ارسال‌ها همگام‌اند (حداکثر ۵ ثانیه)؛ در transition نادر می‌تواند loop را کوتاه کند.
- `os.replace` روی Windows اگر فایل باز باشد می‌تواند موقتاً شکست بخورد (پنجرهٔ خواندن watchdog کوچک است).
- watchdog در scheduler بیرونی باید اجرا شود؛ این ریپو آن را نصب نمی‌کند.
