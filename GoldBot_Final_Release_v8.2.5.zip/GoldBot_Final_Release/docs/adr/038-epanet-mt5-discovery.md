# ADR 038 — کشف محیط واقعی ePlanet MT5 و الزامات gateway

> **وضعیت:** یافته‌های discovery تاریخی‌اند؛ مسیر اجرایی gateway/live در ADR-040 تعریف شده و این ADR به‌تنهایی مشخصات اجرایی نیست.

## زمینه
تا v6 همه‌چیز روی FakeBroker بود. برای فاز بعد باید مشخصات واقعی بروکر خوانده می‌شد.

## تصمیم / یافته‌ها
- سرور دمو: ePlanet-MT5 (نه MetaQuotes-Demo). حساب <MT5_LOGIN> با هجینگ و دمو؛
  AutoTrading عمداً خاموش ماند.
- اتصال Python فقط با path به terminal64.exe کار می‌کند (نه پوشه)؛ نسخهٔ 5.0.6231 با
  build 6238 سازگار است. login فقط پس از یک‌بار ورود از دیالوگ خود ترمینال ممکن شد؛
  سپس accounts.dat ساخته و cold start با initialize(login,password,server) کار می‌کند.
- نماد واقعی XAUUSD.st است: contract 100، tick_value 1.0، tick_size 0.01،
  min/step 0.01، max 10، filling_mode IOC (FOK رد می‌شود)، stops/freeze 0،
  swap_long منفی، swap_short مثبت، triple Wednesday.
- gateway باید broker_symbol، filling_mode، tick_value، stops/freeze و swap را از
  AccountInfo/SymbolInfo بخواند و config را با spec_guard اعتبارسنجی کند.

## تست
اتصال خواندنی: account_info، symbol_info، positions_get/orders_get خالی، و order_check
خواندنی (بدون order_send) موفق. هیچ معامله‌ای انجام نشد؛ AutoTrading خاموش است.

## محدودیت
- این ADR فقط discovery است؛ gateway واقعی MT5 (read-only + order path) هنوز پیاده نشده.
- ترتیب بازار/سشن‌ها و اسپرد باید در ساعات باز بازار دوباره خوانده شوند.
- MCP محلی MT5 با توکن assistant.ini قابل استفاده نشد (401)؛ IPC پایتون مسیر انتخابی است.
