# ADR 022 — بستن اجباری آخر هفته از جدول جلسهٔ بروکر

## زمینه
نسخهٔ قبل یک ساعت UTC هاردکد (19) داشت و به جلسهٔ واقعی بروکر و DST توجه نمی‌کرد؛ اگر Core
کرش می‌کرد هیچ fallback هم نبود. گپ جمعه به دوشنبه در XAUUSD می‌تواند SL را رد کند.

## تصمیم
- منبع زمان: SymbolInfo.sessions به وقت بروکر + broker_offset، نه ساعت UTC ثابت. ماژول خالص
  app/weekend.py: session_end_broker, next_session_open, in_weekend_close_window,
  weekend_plan_utc, close_order_key, weekend_close_plan.
- پنجره: از ۲۰..۶۰ دقیقه (پیش‌فرض ۳۰) قبل از بستهٔ جمعه تا باز شدن دوشنبه flatten=True؛
  reasonها weekend_close_window و friday_session_end.
- ترتیب: profit_first (پیش‌فرض) / loss_first / ticket با tie-break تیکت؛ deterministic.
- Engine هر کندل پلن را می‌سنجد؛ در پنجره pause_all + flatten همه و امتناع از ورود تا reopen.
  تغییر وضعیت با WeekendClosePlan و FlattenCompleted در ژورنال ثبت می‌شود.
- Override فقط با weekend_override_until در state db (CLI override --weekend-hours) و
  actor=operator؛ خاموش‌کردن سیاست یک تصمیم صریح کانفیگ است.
- fallback_close_deadline (deadline + grace) آماده است؛ اجرای مستقل در فاز MT5.

## تست
۳۱ تست tests/test_weekend.py: مرز ۲۹/۳۰/۳۱ دقیقه، جلسهٔ overnight، گپ جمعه به دوشنبه، DST با
آفست ۲h/۳h، ترتیب close، override، پارامتر نامعتبر. تست یکپارچهٔ test_engine_signal_journal
وجود WeekendClosePlan و FlattenCompleted را در یک tape هشت‌روزه تضمین می‌کند.

## محدودیت
- جدول session فقط ساعت روزانه دارد؛ مدل دوشنبه تا جمعه فرض شده است.
- FakeBroker سفارش معلق ندارد؛ cancel_all_pending در فاز MT5 باید به همین پنجره وصل شود.
- بستن با deviation واقعی (پیش‌فرض ۲۰۰ point) فقط در gateway معنا دارد.

## وضعیت wiring در RC 8.2.5 (SES-05)
- weekend_close_plan(positions_profit, params) ترتیب قطعی تیکت‌ها را برمی‌گرداند
  (profit_first / loss_first / ticket با tie-break تیکت) و تست شده است؛ این تابع قرارداد
  engine-facing برای ترتیب flatten است.
- اما engine در branch آخر هفته (engine.py:407-429) و _flatten (engine.py:1624-1643) هنوز
  ترتیب دفتر پوزیشن را می‌بندد و weekend_close_plan را صدا نمی‌زند؛ یعنی close_order کانفیگ
  در عمل بی‌اثر است. این انحراف شناخته‌شده است تا Lead wiring را زمان‌بندی کند: در engine
  mapping {int(pos.ticket): float(pos.profit.amount)} ساخته شود و بستن‌ها به ترتیب خروجی
  weekend_close_plan انجام شوند.
- max_deviation_points (پیش‌فرض ۲۰۰) نیز به gateway منتقل نمی‌شود؛ mt5_broker.close مقدار
  deviation=30 را hardcode می‌کند (SES-06، خارج از scope این اصلاح).
- fallback_close_deadline (deadline + grace) هم هنوز در engine/live صدا زده نمی‌شود.
