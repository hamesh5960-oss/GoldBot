# ADR 039 — استقرار پنل روی VPS با احراز هویت

## زمینه
نیاز به دسترسی از راه دور به پنل بود، ولی پنل هیچ احراز هویتی نداشت و VPS موجود سرورهای
دیگری هم دارد.

## تصمیم
- middleware اختیاری توکن در web/app.py: اگر GOLDBOT_PANEL_TOKEN ست باشد، همهٔ مسیرها
  Bearer یا Basic (هر username، password=token) می‌خواهند؛ بدون توکن رفتار local قبلی حفظ می‌شود.
- CLI serve در bind غیر-loopback بدون توکن fail-closed می‌شود (exit 2).
- استقرار idempotent با scripts/deploy_vps.py: /opt/goldbot، venv، /etc/goldbot/panel.env
  (600)، systemd goldbot-panel با Restart=always، پورت 8199، ufw allow 8199.
- جزئیات عملیاتی/چرخش توکن/تونل SSH: docs/DEPLOY-VPS.md.

## تست
tests/test_web_auth.py (۱۲ تست): 401 بدون توکن، Bearer/Basic، چرخش توکن، open mode محلی.
در VPS: systemctl active، /api/health با توکن پاسخ می‌دهد، دسترسی عمومی از Windows تأیید شد.

## محدودیت
- HTTP ساده است؛ توکن روی سیم خوانده می‌شود. توصیه: تونل SSH یا HTTPS در فاز بعد.
- پنل VPS فقط state/journal همان VPS را می‌خواند و به موتور ویندوز/MT5 وصل نیست؛
  MT5 روی Linux اجرا نمی‌شود. برای کنترل واقعی، gateway ویندوز باید state را با VPS sync کند.
- پنل با root اجرا می‌شود چون کاربر deploy root است؛ در فاز بعد user جدا.
