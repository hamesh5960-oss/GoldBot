# ADR 002 — Kill switch: rolling peak + absolute initial floor

## زمینه
KILLED فقط از سقف rolling محاسبه می‌شد. اگر حساب از ابتدا ۵۰٪ از دست می‌داد ولی peak پایین بود، منطق قبلی می‌توانست دیر عمل کند.

## تصمیم
دو شرط مستقل:
- `drawdown_pct >= max_total_dd_pct` (نسبت به peak) ⇒ KILLED
- `equity < 0.5 × initial_equity` ⇒ KILLED (auto_clear=False)

## دلیل
اولی سود را از دست نمی‌دهد، دومی فاجعهٔ مطلق را می‌گیرد. هر دو فقط سخت‌گیرانه‌تر از قبل‌اند؛ هیچ مسیر جدیدی برای معامله باز نمی‌کنند.

## تست
`test_catastrophic_floor_kills` (و تست‌های قبلی KILLED).
