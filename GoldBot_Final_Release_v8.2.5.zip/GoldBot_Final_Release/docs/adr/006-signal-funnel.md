# ADR 006 — Signal funnel: explicit counting and the 80% rule

## زمینه
نرخ «سیگنال دریافتی → اجراشده» اندازه‌گیری نمی‌شد؛ معلوم نبود کدام لایه چند سیگنال را می‌بلعد.

## تصمیم
`EngineResult.funnel` با مراحل received / prefiltered / tier_rejected / gate_rejected / capital_rejected / approved / executed؛ در `SessionFinished` ذخیره و با `report --funnel` چاپ می‌شود.
معیار: نرخ اجرا نباید >۲۰٪ کمتر از baseline باشد.

## نتیجه (tape یکسان، medium، ۱۰۰ روز)
- v1.1: ۱۵۶ از ۲۵۸ ورودی = ۶۰.۵٪
- v2: ۱۵۹ از ۲۵۱ ورودی = ۶۳.۳٪ (+۲.۸pp)؛ DD ۴.۲۳٪ در برابر ۴.۴٪؛ حداکثر ریسک ۰.۷۴٪ در برابر ۰.۹۸٪.
این اعداد روی random walk هستند و فقط «کمتر نشدن سیگنال» را می‌سنجند، نه سودآوری.

## تست
`tests/test_priority.py` و خروجی `report --funnel`.
