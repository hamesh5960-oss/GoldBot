# ADR 014 — KILLED always flattens

## زمینه
`flatten_on_kill` در پروفایل high خاموش بود؛ یعنی قفل KILLED می‌توانست پوزیشن‌ها را باز نگه دارد.

## تصمیم
هنگام `RiskState.KILLED` موتور **همیشه** `_flatten("kill")` را اجرا می‌کند. فیلد پروفایل برای سازگاری می‌ماند
ولی رفتار را تغییر نمی‌دهد. بستن پوزیشن ریسک را کاهش می‌دهد و هرگز با «سیگنال را نکش» در تضاد نیست.

## تست
`test_flatten_closes_every_position` (engine kill).