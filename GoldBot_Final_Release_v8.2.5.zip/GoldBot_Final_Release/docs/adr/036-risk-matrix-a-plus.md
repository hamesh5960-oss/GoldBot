# ADR 036 — A+ پایه ۱.۰٪، ماتریس Low، Gate D و نصف‌شدن پوزیشن سوم

## زمینه
ADR-024 برای اثرگذاری آمپلیفایر، A+ را به ۰.۸۵٪ کاهش داده بود. با حذف آمپلیفایر و حذف
جریمهٔ R:R (ADR-034) این کاهش دیگر لازم نیست و ماتریس ریسک باید با Gate D جدید هم‌خوان
شود. High با risk_per_trade ۱.۵٪ عملاً بالاتر از سقف ریسک باز Gate D بود و اجازهٔ
هم‌زمانی سه‌گانه نمی‌داد.

## تصمیم
- ریسک پایهٔ Tier: A+=۱.۰٪، A=۰.۷۵٪، B=۰.۵٪، C=۰.۲۵٪، D و NOISE صفر.
- Medium و High برای A+ سقف ۱.۰٪ دارند؛ High دیگر ۱.۵٪ را اجرا نمی‌کند. مقدار
  risk_per_trade_pct=۱.۵ برای High فقط به‌عنوان envelope اعتبارسنجی می‌ماند.
- Low دو سطح: A=۰.۵٪، A+=۰.۷۵٪؛ B/C/D در Low مجاز نیستند (tier_not_allowed، حجم ۰).
- ریسک باز هر پروفایل (max_open_risk_pct): Low=۱.۵٪، Medium=۳.۰٪، High=۳.۰٪. Gate D
  soft/hard و portfolio ceiling همان قواعد tighten را دارند و می‌توانند سقف را پایین بیاورند.
- پذیرش تصمیم C: در ترکیب همهٔ A+ روی Medium/High، پس از دو پوزیشن (۲.۰٪) پوزیشن سوم
  از خط soft عبور می‌کند و Gate D آن را HALF می‌کند (۰.۵٪)؛ رد کامل نمی‌شود.

## تست
tests/test_capital.py و tests/test_profiles.py: ماتریس Low/Medium/High، سقف tier_risk_caps،
tier_not_allowed، عدم عبور از سقف، و نصف‌شدن پوزیشن سوم در Gate D. تست‌های قدیمی capital
که A+=۰.۸۵ فرض می‌کردند به‌روزرسانی شدند (approved by Lead).

## محدودیت
- High با envelope ۱.۵٪ فقط از طریق پروفایل قابل tighten است؛ هر تغییر سقف باید صریح باشد.
- اعداد روی backtest و paper هستند؛ برای حساب واقعی باید با slippage و swap واقعی بازبینی
  شوند.
