# ADR 041 — استفاده از Strategy ID برای تشخیص تأیید استراتژی دیگر

**Status:** Accepted — implementation fix in RC 8.2.5

## زمینه

در `TradingEngine._process_signals`، خروجی `SignalArbiter.register()` شامل strategy IDهاست (برای مثال `zones`)، اما تشخیص وجود تأییدیهٔ دیگر با `signal.slot` (برای مثال `zones_m15`) مقایسه می‌شد. این دو شناسه در قراردادهای پروژه متفاوت‌اند. در نتیجه strategy ID خود سیگنال با slot مقایسه می‌شد و تقریباً همیشه به‌اشتباه «استراتژی دیگر» تشخیص داده می‌شد؛ یک امتیاز اضافه به `confirmation_count` وارد می‌شد حتی وقتی فقط همان استراتژی سیگنال داده بود.

## تصمیم

- تشخیص تأییدیهٔ دیگر باید strategy ID فعلی را با strategy IDهای خروجی Arbiter مقایسه کند.
- slot فقط شناسهٔ instance/زمان‌فریم است و برای تشخیص هویت استراتژی استفاده نمی‌شود.
- منطق در تابع خالص `has_other_strategy_confirmation(confirmations, current_strategy)` متمرکز و تست‌پذیر شده است.

## آزمون پذیرش

- `("zones",)` با current strategy=`zones` باید False باشد.
- `("numeric", "zones")` با current strategy=`zones` باید True باشد.
- نام slot مانند `zones_m15` نباید باعث مثبت کاذب شود.

## قرارداد زمانی Arbiter

Arbiter فقط سیگنال‌های قبلی در پنجرهٔ trailing را می‌بیند؛ سیگنال زودتر retroactive ارتقا نمی‌یابد و برای جلوگیری از look-ahead هیچ تأخیری روی تصمیم ورود اعمال نمی‌شود.

## اثر مورد انتظار

Tierهای تاریخی که از positive false confirmation استفاده کرده‌اند ممکن است در اجرای مجدد تغییر کنند. مقایسهٔ نتایج قبل/بعد باید با tape ثابت، config hash ثابت به‌جز این اصلاح، و گزارش قیف سیگنال انجام شود. هیچ ادعای سودآوری از این اصلاح نتیجه نمی‌شود.
