# ADR 046 — اعتبارسنجی host key و محرمانگی توکن در استقرار VPS

**Status:** Accepted — implementation fix in RC 8.2.5

## زمینه

اسکریپت deploy از `AutoAddPolicy` استفاده می‌کرد و کلید میزبان ناشناس را بدون تأیید می‌پذیرفت. همچنین فرمان shell حاوی توکن پنل از مسیر log معمولی عبور می‌کرد و ممکن بود در خروجی محلی چاپ شود. حذف apostrophe از توکن نیز به‌جای quoting امن، مقدار توکن را تغییر می‌داد.

## تصمیم

- `known_hosts` سیستم بارگذاری و `RejectPolicy` اعمال می‌شود؛ کلید ناشناس باید پس از تطبیق fingerprint خارج از کانال ثبت شود.
- assignment کامل با `shlex.quote` escape می‌شود.
- توکن تک‌خطی است؛ CR/LF/NUL رد می‌شوند.
- فرمانی که حاوی توکن است با `quiet=True, redact=True` اجرا می‌شود؛ هم لاگ عادی و هم پیام خطای فرمان، مقدار توکن را پنهان می‌کنند. توکن فقط در خروجی نهایی مورد انتظار deploy چاپ می‌شود.
- `paramiko` به‌عنوان extra اختیاری `deploy` تعریف شده است.

## آزمون پذیرش

`test_deploy_vps.py` یک اتصال key/password و RejectPolicy را کنترل می‌کند، عدم نشت توکن به خروجی را assert می‌کند و newline injection را رد می‌کند.
