# ADR 028 — گارد مشخصات بروکر و قفل netting

## زمینه
فرض‌های SymbolInfo (tick_value، filling_mode، freeze_level)، ارز حساب و حالت hedging/netting
از بروکر واقعی خوانده و validate نمی‌شدند؛ اگر بروکر netting بدهد FSM سه‌لایه از کار می‌افتد.

## تصمیم
- SymbolInfo افزودنی: tick_value و filling_mode (fok/ioc/return/unknown)؛
  SymbolMeta آن‌ها را map و validate می‌کند.
- app/spec_guard.py خالص: validate_specs با کدهای fatal (contract/point/tick_size/min_lot/
  max<min/step/stops/freeze/trade_mode/netting_not_allowed/currency_mismatch/leverage) و
  warn (tick_value_unknown، symbol trade_mode). risk_per_lot از tick_value/tick_size وقتی >0
  باشد وگرنه contract_size استفاده می‌کند.
- Bootstrap بعد از ساخت broker: fatal یعنی ConfigError و توقف (fail-closed)؛ warnها لاگ می‌شوند.
- [account] allow_netting=false پیش‌فرض؛ netting در bootstrap رد می‌شود مگر صریحاً اجازه داده شود.

## تست
۲۷ تست test_spec_guard (هر کد fatal، netting allow/reject، currency، tick_value fallback،
determinism) + contract tests پورت‌ها (۱۳) + chaos (۱۳) + property (۱۱).

## محدودیت
- gateway واقعی MT5 هنوز وصل نیست؛ گارد با همان SymbolInfo کار می‌کند.
- risk_per_lot در spec_guard و CapitalSpec.risk_per_min_lot هم‌پوشانی دارند؛ فاز MT5 یکی شوند.
