# ADR 040 — Live MT5 demo session on ePlanet (XAUUSD.st)

**Status:** Accepted
**Date:** 2026-11-16

## Context

Through v6 the engine always ran on `FakeBroker`; the real venue was only inspected
read-only (ADR-038). The operator now has a working ePlanet MetaTrader 5 demo account
(server `ePlanet-MT5`, hedging, leverage 100; account login is supplied by the operator at runtime) and wants
the same bot to run live on that demo. The engine, strategies, risk pipeline and journal
must stay exactly the same code path as backtest/simulation; only the venue and the
runtime composition may change.

Facts that this ADR is built on:

- MT5 terminal: `C:\Program Files\ePlanet MetaTrader 5 Terminal\terminal64.exe`, build 6238.
- Python package `MetaTrader5 5.0.6231` is installed on the Windows box.
- Broker symbol is `XAUUSD.st` (contract 100, tick_value 1.0, tick_size/point 0.01,
  min/step 0.01, stops/freeze 0, filling IOC, swap_long negative, triple Wednesday).
- The logical engine symbol stays `XAUUSD`; `XAUUSD.st` is the broker symbol.
- AutoTrading is currently ON in the terminal. It is still an operator switch, not a
  guarantee: the adapter must refuse orders when it is off.
- Server wall-clock time is not UTC; the adapter must learn the offset from ticks.

The operator requirement that motivated this release is the *daily comparison of generated
signals with traded signals*: every entry signal the engine produces must appear in the
journal, including the ones filtered before the decision stage.

## Decision

### 1. One engine, one live composition root

`runtime/live.py` wires the existing components to the venue and runs the existing
`TradingEngine.run()`; no strategy, risk or decision code is forked for live. The new CLI
command is:

```bash
python run_goldbot.py live --profile medium --login <MT5_LOGIN> --server ePlanet-MT5 \
    --broker-symbol XAUUSD.st --cold-start --db var/live.db
```

- `--profile` defaults to the configured profile; the release uses `medium`.
- `--db` is the journal path (documented default `var/live.db`).
- The login/server/broker-symbol are *runtime overrides* of `[account]` and
  `[symbol]`; nothing is written back to config files.
- Secrets are never stored in the repo: password comes from `--password` (discouraged) or
  `GOLDBOT_MT5_PASSWORD`; path/login/server/symbol may come from the `GOLDBOT_MT5_*`
  environment variables. The command fails closed (exit 2) when login/password/server are
  missing.

### 2. MT5 adapter boundary

- New `adapters/mt5_broker.py` is the broker gateway and the only module that speaks the
  MT5 terminal API. The actual `import MetaTrader5` sits behind the CI-allowlisted SDK
  boundary `adapters/goldbot_gateway/terminal.py` and is loaded lazily (Windows-only).
  `MT5Broker` implements `IBrokerGateway` (`ports/broker.py`) plus `MT5TickFeed` and
  `load_history`/`seed_builder` for warm-up; the module is injected with the MT5 module
  so tests run against a fake terminal.
- `MT5Broker` connects with `initialize(path=<terminal64.exe>, login, password, server)`
  and then treats the venue as the source of truth for account and symbol data:
  currency/leverage/trade_mode and digits, point, contract, volume limits, stops/freeze,
  filling mode, tick_value and swap are read from MT5 into a rebuilt `SymbolInfo`; the
  startup spec validation (`SymbolMeta` + `spec_guard.validate_specs`) then runs on that
  live metadata before any order. A mismatch at connect time is a hard error, not a
  warning. The weekly session table stays the config `[symbol].sessions` value: MetaTrader 5
  does not expose a reliable weekly session schedule through the Python API in this release,
  so the weekend policy keeps using config (ADR-022) and the operator must keep it correct.
- The adapter re-learns the server clock offset from ticks and hands the engine one UTC
  time base; the actual trading session is therefore DST-safe without config edits.

### 3. Server time, fills and settlement

- MT5 timestamps are naive server-wall-clock seconds. Every value crossing the adapter is
  converted: `utc = server_timestamp - learned_offset`; history requests convert the
  engine's UTC window back to naive server time. The engine's bars, clocks and risk checks
  keep a single time base.
- Order acks come from `order_send` retcodes; an accepted market/pending order is journaled
  immediately. A closed position is reconstructed from the venue's deal history
  (`DEAL_ENTRY_OUT`), including price, volume, commission and swap; the close reason is
  inferred from the adapter comment, and from SL/TP distance as a fallback. Polling
  `on_market_tick` also detects positions closed by the broker (SL/TP) and emits exactly one
  `ClosedTrade` per deal.
- Idempotency is by `client_ref`: every intent carries a client reference, which is sent as
  the MT5 order comment (truncated to the MT5 limit of 31 chars). Retries reuse the same
  `client_ref`; `find_by_client_ref` checks orders and open positions before a retry, and
  adopts a position instead of doubling it. A submit that returns `None`/unknown is
  `SubmitUncertain` (fail-closed), never optimistically treated as filled.

### 4. Safety gates

- **Demo-only by default:** the adapter reports `is_demo()` from the account's
  `trade_mode`; a non-demo account is refused unless the operator passes
  `--allow-real` (explicit, dangerous, not used for this release).
- **AutoTrading required:** `submit` refuses with `CLIENT_DISABLES_AT (10027)` when
  terminal/account `trade_allowed` is false. The banner prints AutoTrading status; a session
  with it off journals signals but cannot trade.
- **Cold start is explicit:** `--cold-start` is required for a fresh state DB; without it a
  live run with missing/corrupt risk state quarantines instead of inventing risk numbers.
- **Fail-closed reconciliation/quarantine:** a venue/journal divergence or an unreadable
  state record sets `QUARANTINE`; the engine journals signals but opens no trades until a
  human acknowledges with `ack --level quarantine --confirm`. Broker truth wins over local
  state.
- **Spread and specs from the profile:** entries are blocked when the spread exceeds the
  profile `max_spread_points` (medium = 35 points) in addition to Gate A/D, lot, rollover,
  margin and news/weekend policies. The limits are not loosened for live.
- **No order without protection:** the existing rule that every order is a sealed
  `ApprovedOrder` with a stop loss stays unchanged; the adapter also enforces broker
  volume/step limits and uses the configured deviation (slippage) on sends.

### 5. Full signal journal guarantee

Every generated entry signal gets exactly one `signal_journal` row, independent of whether
it is executed, skipped, rejected or filtered before the decision stage:

- **executed** — order was sent/accepted;
- **skipped** — Tier D hard floor (journal-only, never reaches gates/capital);
- **rejected** — gate, risk, budget, spread, news, weekend or execution refusal;
- **filtered** — blocked before the decision pipeline: direction bias
  (`direction_long_only`/`direction_short_only`), entry priority (`priority_skipped`),
  confirm-only binding (`confirm_only`), structural intent validation (`invalid_intent`).

`EngineResult` and the `SessionFinished` event carry `signals_seen`,
`signals_journaled` and `signals_unlogged`; any gap emits a `JournalGap` event and an
error log. Executed rows can be matched to trades through the `signal_id` tag. The
`signals` CLI command reports decision counts, top reasons, per-day signal/trade rows and
PASS/FAIL for the gap counters — this is the daily signals-vs-trades workflow.

### 6. Operator surface

- `docs/LIVE-MT5.md` is the runbook: prerequisites, environment variables, the exact start
  command, stop/restart rules, journal reading, daily comparison workflow, spread/liquidity
  note and the safety checklist before unattended running.
- `python run_goldbot.py report --db var/live.db` prints the trade/equity report;
  `python run_goldbot.py signals --db var/live.db` prints the signal journal comparison
  (`signals` defaults to `var/live.db`; `report` defaults to the configured journal, so
  pass `--db` explicitly for live).
- The web panel reads whatever journal/state path it is configured with; for a live session
  the canonical record is the CLI on the Windows box, and the VPS panel is not connected to
  this engine (see Limitations).

## Tests

- `tests/test_mt5_broker.py` (fake-terminal tests): connect maps account and learns the
  server offset; refuses a different login or a symbol-metadata mismatch; builds an IOC
  market deal with protection; refuses when AutoTrading is off and when the market is
  closed; close returns a `ClosedTrade` with positive costs; settlement is detected once
  from venue history; `find_by_client_ref` adopts an open position; history converts to UTC
  and drops the forming bar; the tick feed yields UTC ticks and updates the clock; venue
  truth overrides config metadata.
- `tests/test_signal_journal_completeness.py` (new with this release): a deterministic
  short tape asserts `signals_seen == journaled`, `signals_unlogged == 0`, every entry
  signal has a row, a forced `direction=long` run produces `direction_short_only` filtered
  rows, and executed rows match a trade via `signal_id`.
- Existing suites stay green: `test_architecture`, `test_signal_journal`,
  `test_engine_signal_journal`, `test_end_to_end`, `test_risk_engine`.
- Manual live acceptance is the demo session itself: the banner shows login/server, broker
  symbol, balance/equity, AutoTrading and server offset; the journal records the
  `LiveArmed` event with `dry_run`, `trade_allowed` and `broker_offset_minutes`.

## Limitations

- **No panel/engine sync:** the VPS web panel deployed in ADR-039 reads only its own state
  and journal; it is not connected to the Windows engine/MT5 process. Live monitoring is the
  local CLI/journal (or `serve` on the Windows box); remote control needs a future gateway
  sync.
- **Restart with open positions needs manual ack:** durable risk state lets a normal restart
  adopt existing tickets, but after a cold start, a corrupted state record, or a
  venue/journal divergence the engine quarantines and does not auto-adopt live positions.
  The operator must reconcile with MT5 and `ack --level quarantine`, or flatten in the
  terminal before restarting.
- **Monday-open spread:** XAUUSD spread is ~70 points at the Monday open, above the medium
  profile `max_spread_points=35`; entries are correctly blocked until the spread normalises.
  Do not raise the profile limit to force an open.
- **Windows-only package:** `MetaTrader5` is a Windows-only package; the live engine runs on
  the operator's Windows machine. It cannot run on the Linux VPS, and there is no cloud
  failover in this release.
- **Demo is not live-quality evidence:** demo fills, slippage and execution latency differ
  from a funded account; this release is for plumbing and daily signal/trade comparison, not
  for profitability claims.
- **Single session per account:** one engine/terminal per account; two concurrent runs on the
  same demo account can double-submit and are not supported.
- **Offset learning at start:** the server offset is learned from ticks; if the terminal has
  no feed at startup, warm-up may be empty and the offset falls back to the configured
  `broker_offset_hours` until ticks arrive.
