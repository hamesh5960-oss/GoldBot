# ADR 027 — کنترلر سطح سرمایه: opt-in، فقط سخت‌گیرانه، BASE قفل

## زمینه
مدل چهار سطحی و باندهای ۵/۴/۳/۲/۱.۵٪ در spec مالک آمده است، اما فعال‌کردن پیش‌فرض آن
یعنی ۵٪ ریسک و سقف‌های شل‌تر (daily-loss ۳٪ برای LOW در برابر ۱٪ فعلی) که نقض اصل
«هیچ سقفی بی‌صدا شل نمی‌شود» است.

## تصمیم
- app/capital_levels.py خالص: CapitalLevel, BASE_BANDS, band_risk_pct با هیسترزیس نامتقارن،
  LevelPolicy چهار سطح، LevelState, determine_level (تنزل خودکار، پیشنهاد ارتقا با تأیید)،
  approve/decline_upgrade, enforce_level (فقط tighten).
- app/level_gate.py: active(), tier_allowed, session_allowed, max_trades_per_day,
  amplifier_allowed, stop_reason, snapshot/restore در extras همان رکورد ریسک.
- پیش‌فرض خاموش ([levels] enabled=false). وقتی روشن شد سیاست فقط تنگ‌تر می‌کند؛
  آمپلیفایر LOW خاموش می‌شود.
- BASE: ۵٪ فقط باند۰ و فقط با هم‌زمانی enabled + base_enabled + base_armed +
  onboarding_ack + equity<200. onboarding با CLI در state db ثبت می‌شود.
  اجرای سایز ۵٪ عمداً مسلح نشده است (ADR-030).
- CLI: level, approve, decline, onboarding؛ engine هر کندل reload_aux می‌کند تا تصمیم
  اپراتور بدون restart اثر کند؛ تغییر سطح در ژورنال و notifier ثبت می‌شود.

## تست
۸۷ کیس test_capital_levels (قفل ۵٪، نشت صفر، هیسترزیس، تنزل/ارتقا/انقضا/کول‌داون، enforce)
+ ۸ تست test_level_gate + اجرای واقعی BASE-locked با equity=150 (صفر intent، base_locked).

## محدودیت
- شمارش روزهای بالای آستانه تقریبی است.
- سیاست سطح هرگز profile را شل نمی‌کند؛ HIGH/MEDIUM فقط داخل پاکت profile معنا دارند.
