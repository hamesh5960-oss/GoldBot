# GoldBot — Current Engineering Handoff (RC 8.2.5)

> این فایل وضعیت همین سورس تحویلی را توصیف می‌کند. ادعاهای تعداد تست، نتایج تاریخی یا وضعیت اجرای زنده فقط وقتی معتبرند که در همین checkout قابل بازتولید باشند. در تعارض اسناد، ADR پذیرفته‌شدهٔ جدیدتر بر سند قدیمی‌تر مقدم است؛ ADRهای 031 تا 046 تصمیم‌های جدیدتر از SPEC-MERGED-v1.1 هستند.

## 1. دامنه و وضعیت

- زبان/محیط: Python 3.12+، Pydantic v2.
- نماد هدف در این انتشار: XAUUSD.
- استراتژی‌های فعال: `zones` و `numeric`.
- معماری: `domain → ports → app → adapters → runtime`؛ پنل وب در `goldbot.web`.
- اجرای synthetic/backtest با FakeBroker؛ اجرای MT5 فقط روی Windows و نیازمند پکیج رسمی MetaTrader5 و ترمینال نصب‌شده.
- وضعیت این checkout: **Engineering RC**. این ZIP ورودی فاقد تست‌های تاریخی ادعاشده و فاقد فایل بسته‌بندی/لانچر بود؛ این اقلام در RC افزوده شده‌اند، اما تعداد و پوشش تست این نسخه با عدد تاریخی 837 یکسان نیست.

## 2. قراردادهای غیرقابل‌مذاکره

1. هیچ سفارش جدیدی در وضعیت نامطمئن، state خراب، واگرایی بروکر/ژورنال یا quarantine ارسال نمی‌شود.
2. بروکر منبع حقیقت پوزیشن و سفارش live است.
3. هر سفارش ورودی باید SL معتبر و `ApprovedOrder` مورد تأیید Risk/Execution داشته باشد.
4. بک‌تست و live از همان `TradingEngine` و استراتژی‌ها استفاده می‌کنند؛ تفاوت فقط در feed/broker adapter و composition root است.
5. رمزها و توکن‌ها در سورس، تنظیمات versioned، گزارش یا لاگ ذخیره نمی‌شوند.
6. تمام سیگنال‌های ورودی باید در ژورنال ثبت شوند؛ شمارنده‌های `signals_seen`, `signals_journaled`, `signals_unlogged` باید با هم تطبیق داده شوند.
7. هر تغییر رفتاری باید با تست و به‌روزرسانی ADR/مستندات همراه باشد.

## 3. خط لولهٔ تصمیم جاری

```text
Strategy Signal
  → shared ZoneEngine enrichment
  → Layer 0: Zone_Score >= 50 (otherwise D / zone_filter)
  → Layer 2: five independent factors (0, 0.5, 1) + other strategy same-side in 30m (+1)
  → Layer 3: seven directional votes, each -1/0/+1, weighted by 0.2
  → Tier D/C/B/A/A+; D is a hard floor and never reaches gates/capital
  → net R:R absolute floor 1.0 (below it = NOISE)
  → Gates A/B/C
  → capital pipeline + Gate D + risk checks
  → sealed order coordination and broker
```

- پنج فاکتور لایه ۲: FVG/OB، MaxLines، EMA50، RSI و Bollinger؛ جمع در بازهٔ 0..5.
- تأیید استراتژی دیگر فقط وقتی اضافه می‌شود که یک سیگنال قبلی از strategy ID متفاوت، در همان نماد/جهت و در پنجرهٔ trailing ۳۰ دقیقه‌ای ثبت شده باشد. تصمیم سیگنال قبلی retroactive ارتقا نمی‌یابد و look-ahead/delay مصنوعی وجود ندارد. شناسهٔ slot مانند `zones_m15` نباید به‌جای strategy ID مانند `zones` استفاده شود (ADR-041).
- باند Tier پایه: `[0,1)=D`، `[1,2)=C`، `[2,3)=B`، `[3,4)=A`، `[4,6]=A+`.
- لایه ۳: هفت رأی volume، pin/engulfing، EMA200 H1، ADX، session، daily level و sr_zone؛ امتیاز نهایی clamp در ±1.2؛ آستانهٔ ±0.6 برای تغییر یک Tier. D ارتقا نمی‌یابد؛ Tier نهایی از C پایین‌تر و از A+ بالاتر نمی‌رود.
- `rr_net < 1.0` به NOISE تبدیل می‌شود؛ R:R دیگر Tier را بالا/پایین نمی‌برد.
- `min_confirmations`، `weak_confluence_mode`، `dynamic_tier_margin` و وزن‌های Composite قدیمی از تنظیمات جاری حذف شده‌اند.
- اولویت استراتژی در یک کندل حفظ شده است: در صورت وجود سیگنال ورود معتبر از استراتژی با اولویت بالاتر، ورودی اولویت پایین‌تر همان کندل `priority_skipped` می‌شود و در ژورنال ثبت می‌شود (ADR-040).

## 4. Gates

- Gate A: سکوت سخت پس از اجرا؛ بدون bypass.
- Gate B: burn per zone/direction، با full-quality bypass، downgrade یا smallest lot؛ دو شکست SL برای همان zone/direction می‌تواند آن را به trap تبدیل کند.
- Gate C: محدودیت تمرکز جهت‌دار و hedge فقط در صورت زیان‌بودن پوزیشن مخالف و عبور از حداقل کیفیت.
- Gate D: در لایهٔ سرمایه اعمال می‌شود، نه در `CooldownManager`؛ soft line = 2.0%، hard line = 3.0%، portfolio ceiling = 3.0%. بین soft و hard سایز نصف می‌شود؛ بالاتر از hard ورود رد می‌شود.

## 5. ماتریس پروفایل ریسک

| Tier | Base | Low | Medium | High |
|---|---:|---:|---:|---:|
| A+ | 1.00% | 0.75% | 1.00% | 1.00% |
| A | 0.75% | 0.50% | 0.75% | 0.75% |
| B | 0.50% | غیرمجاز | 0.50% | 0.50% |
| C | 0.25% | غیرمجاز | 0.25% | 0.25% |
| D | 0% | غیرمجاز | غیرمجاز | غیرمجاز |

- سقف open-risk: Low=1.5%، Medium=3.0%، High=3.0%.
- هم‌زمانی فعلی: Low=1، Medium=2، High=2 (ADR-037). درخواست 2/3/3 هنوز اجرا نشده و نیازمند ADR و شواهد walk-forward است.
- حجم از Tier، equity، فاصلهٔ SL، هزینه‌ها و مشخصات بروکر محاسبه می‌شود؛ `lot_per_100_usd` مسیر تصمیم جاری نیست.

## 6. اجرای محلی

```powershell
python -m pip install -e ".[test,web]"
python run_goldbot.py --help
python run_goldbot.py profiles
python run_goldbot.py selftest
python -m pytest
python run_goldbot.py demo --days 10 --profile medium --db var/demo.db
python run_goldbot.py report --db var/demo.db --funnel
```

## 7. اجرای MT5

- فقط Windows، ترمینال MT5 و پکیج رسمی `MetaTrader5`.
- ابتدا نشست read-only / `--dry-run` و سپس نشست دمو با نظارت اپراتور.
- رمز فقط از `GOLDBOT_MT5_PASSWORD` یا ورودی امن runtime؛ نه از فایل/ZIP/خط فرمان ذخیره‌شده.
- `--allow-real` در این RC مسیر پیش‌فرض نیست و فعال‌کردن آن نیازمند تصمیم و ارزیابی مستقل است.
- `--cold-start` فقط وقتی state DB تازه و حساب فاقد پوزیشن باز باشد.
- یک موتور در هر حساب؛ دو اجرای هم‌زمان می‌تواند duplicate submit ایجاد کند.
- پنل VPS به موتور MT5 ویندوزی sync نیست.

## 8. آزمون و محدودیت شواهد

- تست‌های قابل اجرای همین نسخه در `tests/` هستند؛ عدد واقعی را فقط خروجی `python -m pytest` مشخص می‌کند.
- `selftest` یک smoke test سه‌روزه با FakeBroker است؛ اثبات سودآوری، رفتار live یا پوشش کامل ایمنی نیست.
- آزمون MT5 با ترمینال واقعی در محیط Linux اجرا نشده است.
- نتایج `reports/` داده‌های تاریخی/synthetic موجودند و به‌تنهایی شواهد سودآوری آینده نیستند.
- هر ادعای `READY FOR LIVE` بدون تست ویندوز، جلسهٔ دمو تحت نظارت، بررسی ژورنال و تأیید اپراتور ممنوع است.
