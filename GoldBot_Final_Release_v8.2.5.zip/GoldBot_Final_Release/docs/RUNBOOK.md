# ران‌بوک عملیاتی GoldBot

> دامنه: اپراتور تک‌نفره‌ی ربات XAUUSD. این سند «چه کار کنم وقتی خراب شد» است، نه معماری.
> هر دستور از ریشه‌ی مخزن و با `$env:PYTHONPATH='src'` اجرا می‌شود.

---

## ۰. سه اصل غیرقابل مذاکره

۱. **بروکر منبع حقیقت است.** هر عدد در حافظه (پوزیشن، SL/TP، موجودی) فقط کش است؛ در هر ابهام با ترمینال بروکر تطبیق بده.
۲. **قفل ریسک خودکار باز نمی‌شود.** `KILLED`، `QUARANTINE` و `HALTED` فقط با `ack` انسانی و پس از بررسی پاک می‌شوند. ری‌استارت هیچ قفلی را پاک نمی‌کند.
۳. **در حالت غیر `NORMAL` ورود جدید ممنوع است اما مدیریت پوزیشن ادامه دارد.** بستن/تنگ‌کردن حد ضرر ریسک را کم می‌کند و باید انجام شود.

---

## ۱. مسیرها و لاگ‌ها

| مورد | مسیر پیش‌فرض | توضیح |
|---|---|---|
| ژورنال (events + trades) | `var/goldbot.db` | append-only؛ منبع گزارش و حسابرسی |
| وضعیت پایدار ریسک | `var/risk_state.db` | هم‌مسیر ژورنال؛ با `GOLDBOT_STATE_DB` قابل تغییر |
| هارت‌بیت | `var/heartbeat.json` | watchdog بیرونی هر ۵ دقیقه بررسی می‌کند |
| tapeهای parity | `var/tapes/` | سناریوهای gap/spread/requote/disconnect/stops/partial |
| بکاپ‌ها | `var/backups/` | پیش از هر دستکاری دستی بساز |
| لاگ برنامه | stderr (JSON ساختاری) | برای فایل: `... 2>> var/logs/goldbot.log` |

مسیر state از `GOLDBOT_STATE_DB` یا `--state-db` خوانده می‌شود؛ اگر هیچ‌کدام نبود، هم‌مسیر ژورنال است.

---

## ۲. چک‌لیست آنکال (هر ۵ دقیقه)

۱. `python scripts/watchdog.py --heartbeat var/heartbeat.json --max-age 900` — خروجی غیرصفر یعنی قلب تپیده نمی‌شود.
۲. `python run_goldbot.py status --state-db var/risk_state.db` — باید `NORMAL` باشد.
۳. `python run_goldbot.py report --db var/goldbot.db` — افت و تعداد معاملات روز را ببین.
۴. پنل محلی (`python run_goldbot.py serve`) — health باید `degraded=false` باشد (state، هارت‌بیت، ژورنال).
۵. اگر `degraded=true` یا watchdog غیرصفر بود ⇒ طبق بخش‌های ۳ تا ۱۰ عمل کن؛ **اول توقف، بعد تشخیص، آخر ack**.

---

## ۳. کیل‌سویچ و ack

سوییچ‌ها به ترتیب شدت: `SOFT_HALT < HALTED < KILLED < QUARANTINE`.

- `SOFT_HALT` (باخت‌های پیاپی) و `HALTED` (حد ضرر روزانه) خودکار و روز بعد آزاد می‌شوند.
- `KILLED` (افت کل سرمایه) و `QUARANTINE` (واگرایی یا رکورد خراب) فقط با اپراتور.
- `override` فقط **ورود جدید** را متوقف می‌کند؛ پوزیشن‌های باز دست نمی‌خورند.

```bash
# ۱) توقف ورود جدید در حین بررسی (اختیاری ولی توصیه‌شده)
python run_goldbot.py override --pause-minutes 60 --reason "بررسی واگرایی" --confirm

# ۲) مشاهده‌ی وضعیت و دلیل دقیق
python run_goldbot.py status --state-db var/risk_state.db --json

# ۳) فقط بعد از رفع علت: ack با یادداشت حسابرسی
python run_goldbot.py ack --level killed --note "پوزیشن‌ها دستی تخت شد؛ تطبیق پاک" --confirm

# ۴) آزادکردن توقف دستی
python run_goldbot.py override --resume --confirm
```

قواعد: هرگز `QUARANTINE` را قبل از `RECONCILE_COMPLETED` پاک نکن. هرگز `KILLED` را موقع باز بودن پوزیشن پاک نکن.

---

## ۴. شکست بستن آخر هفته

موتور جمعه بعد از ساعت پیکربندی‌شده `_flatten("weekend")` می‌زند (پروفایل‌ها: `flatten_on_kill`). اگر بستن شکست بخورد:

۱. `override --pause-minutes 120` بزن تا ورود جدید قفل شود.
۲. ژورنال را ببین: رویدادهای `UncertainOrder` / `CloseFailed` / `Reconcile` / `KILL`.
۳. پوزیشن‌ها را در ترمینال بروکر بررسی کن. **بستن از ترمینال مجاز است**؛ بعد از آن سیستم باید reconcile کند.
۴. اگر پوزیشن باز ماند: با ترمینال ببند، سپس reconcile بعدی (`RECONCILE_COMPLETED`) را در ژورنال تأیید کن.
۵. اگر سیستم `QUARANTINE` شد، فقط بعد از تطبیق پاک، `ack --level quarantine --confirm` بزن.
۶. آخر هفته بدون پوزیشن باز وارد شنبه شو؛ ریسک گپ آخر هفته قابل مدیریت نیست اگر پوزیشن باز باشد.

---

## ۵. قرنطینه‌ی تطبیق (reconciliation)

واگرایی چهار نوع دارد و در رویداد `DIVERGENCE` ثبت می‌شود:

| نوع | معنا | اقدام |
|---|---|---|
| `missing` | محلی باز است، بروکر ندارد | بسته‌شدن در بروکر را بررسی کن؛ پوزیشن را از دفتر محلی حذف/تطبیق بده |
| `orphan` | بروکر دارد، محلی نمی‌شناسد | تیکت را در ترمینال ببین؛ ببند یا با مجیک/کامنت مالکیت را ثبت کن |
| `volume_drift` | حجم محلی ≠ بروکر | حجم واقعی بروکر را مبنا بگیر؛ دفتر محلی را همگام کن |
| `protection_lost` | SL محلی هست، بروکر ندارد | **فوری** حد ضرر را روی بروکر بگذار؛ بدون SL معامله نکن |

روال: `override --pause-minutes 60` ⇒ بررسی ژورنال و ترمینال ⇒ رفع واگرایی ⇒ صبر تا چرخه‌ی reconcile بعدی (یا ری‌استارت کنترل‌شده) ⇒ تأیید `RECONCILE_COMPLETED` در ژورنال ⇒ `ack --level quarantine --confirm`.

---

## ۶. خرابی state DB (رکورد ریسک خراب)

نشانه‌ها: `status` پیام «وضعیت ریسک خراب است» می‌دهد؛ در حالت live/paper موتور با `QUARANTINE` بالا می‌آید (`StateCorruption`).

۱. **اول بکاپ، بعد دستکاری:** فایل‌های `risk_state.db` و `risk_state.db-wal` و `risk_state.db-shm` را کپی کن.
۲. یکپارچگی: `sqlite3 var/risk_state.db "PRAGMA integrity_check;"`.
۳. اگر فایل سالم ولی payload خراب است، از بکاپ سالم (بخش ۷) برگردان.
۴. اگر بکاپ نیست: در محیط live **بدون ack شروع نکن**. با ترمینال بروکر تطبیق بده، سپس آگاهانه `QUARANTINE` را ack کن و بدان که شمارنده‌ها (ضرر روزانه/افت/سفارش امروز) از نو شروع می‌شوند — این خودش یک ریسک است، آن را در ژورنال/یادداشت ثبت کن.
۵. هرگز دیتابیس را در live بی‌صدا حذف نکن؛ حذف یعنی از دست دادن سابقه‌ی قفل‌ها.

---

## ۷. بازگردانی از بکاپ

```powershell
# ۰) فرآیند متوقف باشد (بدون نویسنده‌ی دوم روی SQLite)
Copy-Item var/risk_state.db    var/backups/risk_state.db.$(Get-Date -f yyyyMMdd-HHmm)
Copy-Item var/goldbot.db       var/backups/goldbot.db.$(Get-Date -f yyyyMMdd-HHmm)
Copy-Item var/heartbeat.json   var/backups/heartbeat.json.$(Get-Date -f yyyyMMdd-HHmm) -ErrorAction SilentlyContinue

# ۱) بازگردانی (هر دو فایل WAL هم باید هم‌نسخه باشند)
Copy-Item var/backups/risk_state.db.20240101-1200 var/risk_state.db
Copy-Item var/backups/goldbot.db.20240101-1200    var/goldbot.db

# ۲) راستی‌آزمایی
python run_goldbot.py status --state-db var/risk_state.db
python run_goldbot.py report --db var/goldbot.db
```

بعد از بازگردانی: reconcile اجباری، بررسی پوزیشن‌های واقعی، سپس `ack` فقط اگر لازم بود.

---

## ۸. rollback نسخه (سازگاری schema)

Schema` وضعیت ریسک نسخه‌دار است (`SCHEMA_VERSION`). نسخه‌ی ناسازگار ⇒ `StateCorruption` ⇒ `QUARANTINE`؛ این fail-closed است و درست کار می‌کند.

۱. `override --pause-minutes 120` ⇒ توقف فرآیند.
۲. بکاپ کامل (بخش ۷).
۳. نسخه‌ی قبلی کد را برگردان (git checkout/tag یا محیط مجازی قبلی — تصمیم انتشار، نه ربات).
۴. **دیتابیس هم‌نسخه‌ی همان نسخه** را بازگردان؛ downgrade schema دستی ممنوع.
۵. `status` و `report` و `selftest` (روی tape، نه live) را اجرا کن.
۶. reconcile و مشاهده‌ی یک چرخه‌ی کامل، بعد ack و resume.

---

## ۹. بازیابی ژورنال

ژورنال append-only است و با WAL+FULL نوشته می‌شود؛ بستن/بازکردن پروسه داده را از دست نمی‌دهد.

- آمار: `python run_goldbot.py report --db var/goldbot.db` (و `--xlsx` برای خروجی اکسل، `--funnel` برای قیف سیگنال).
- شمارش: `SELECT COUNT(*) FROM events;` روی همان فایل (فقط وقتی پروسه متوقف است).
- اگر ژورنال قابل خواندن نیست: health `degraded` می‌شود؛ **بدون ژورنال معامله نکن**.
- آخرین راه‌حل: بازگردانی از بکاپ بخش ۷؛ حذف ژورنال فقط با ثبت دلیل و پذیرش از دست رفتن حسابرسی.

---

## ۱۰. فلتن اضطراری

۱. اولویت با بستن در ترمینال بروکر (منبع حقیقت) است؛ سپس reconcile تا دفتر محلی همگام شود.
۲. اگر پروسه زنده است و قفل `KILLED` با `flatten_on_kill=true` بالا آمده، موتور خودش فلتن می‌کند؛ منتظر بمان و نتیجه را در ژورنال (`KillFlatten`/`Close`) ببین.
۳. تأیید نهایی: `broker.positions()` خالی + `status` بدون تیکت + `RECONCILE_COMPLETED`.
۴. تا تخت‌شدن کامل، ورود جدید با `override` قفل بماند.

---

## ۱۱. تصاعد و ارتباط

| سطح | نمونه | اقدام |
|---|---|---|
| P3 | heartbeat دیر، اسپرد بالا | بررسی چک‌لیست؛ بدون دخالت در پوزیشن |
| P2 | تکرار close/modify failed، واگرایی حجم | override + تطبیق؛ گزارش روزانه |
| P1 | واگرایی تطبیق، رکورد state خراب، بستن آخر هفته شکست خورده | توقف کامل ورود، فلتن کنترل‌شده، ack فقط با یادداشت |
| P0 | پوزیشن بی‌SL، دو پوزیشن متناقض، ضرر خارج از سقف | فلتن فوری از ترمینال، ژورنال را حفظ کن، تا ریشه‌یابی معامله نکن |

---

## ۱۲. دستورهای سریع

| نیاز | دستور |
|---|---|
| وضعیت ریسک | `python run_goldbot.py status --state-db var/risk_state.db` |
| خروج از قفل | `python run_goldbot.py ack --level killed\|quarantine\|halted --note "..." --confirm` |
| توقف/آزادسازی ورود | `python run_goldbot.py override --pause-minutes 60 --reason "..." --confirm` / `--resume --confirm` |
| گزارش ژورنال | `python run_goldbot.py report --db var/goldbot.db` |
| smoke test | `python run_goldbot.py selftest` |
| tapeهای parity | `python run_goldbot.py tapes --out var/tapes` |
| watchdog | `python scripts/watchdog.py --heartbeat var/heartbeat.json --max-age 900` |
| تست کل | `python -m pytest` |

---

## ۱۳. قواعد طلایی (چیزی که هرگز نمی‌کنیم)

۱. هرگز `QUARANTINE` را بدون تطبیق پاک نمی‌کنیم.
۲. هرگز دیتابیس state یا ژورنال را در live بدون بکاپ حذف/بازنویسی نمی‌کنیم.
۳. هرگز پوزیشن بدون SL را رها نمی‌کنیم؛ `protection_lost` = P0.
۴. هرگز در حالت `degraded` یا heartbeat کهنه معامله‌ی جدید باز نمی‌کنیم.
۵. هرگز schema را دستی تغییر نمی‌دهیم؛ نسخه‌ی ناسازگار = QUARANTINE + بازگردانی.
۶. هرگز دو نمونه‌ی ربات روی یک ژورنال/state اجرا نمی‌کنیم (SQLite تک‌نویسنده).
۷. هر ack باید یادداشت داشته باشد تا حسابرسی ژورنال کامل بماند.
