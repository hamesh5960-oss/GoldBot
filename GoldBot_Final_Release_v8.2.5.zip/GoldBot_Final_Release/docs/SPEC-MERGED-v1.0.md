# GoldBot — مشخصات یکپارچهٔ نسخهٔ ۱.۰ (ادغام سه پرامپت)

> **یادداشت وضعیت:** سند تاریخی است و با ADRهای پذیرفته‌شدهٔ جدیدتر جایگزین شده؛ برای رفتار فعلی به `docs/HANDOFF-PROMPT.md` و ADRهای جدیدتر رجوع کنید.

> **این سند «منبع حقیقت» است.** هر جا کد، README یا پرامپت قبلی با این سند تناقض داشت، این سند حاکم است.
> پرامپت‌های پایه: (۱) HANDOFF v0.4 — بات قبلی، (۲) پرامپت محدودهٔ حمایت/مقاومت + کول‌داون چهار دروازه‌ای،
> (۳) پرامپت مدیریت ریسک و سرمایه. **اولویت در تناقض: ۳ > ۲ > ۱.**

---

## ۰. تصمیم‌های بنیادی (خلاصهٔ مدیریتی)

| موضوع | نسخهٔ قبلی | نسخهٔ ۱.۰ |
|---|---|---|
| استراتژی‌ها | ۵ استراتژی (rectangle, numeric, fvg, fvg_ma, ma_trend) | **۲ استراتژی**: `zones` (حمایت/مقاومت) و `numeric` (بدون تغییر منطق) |
| ناحیه‌ها | مستطیل دستی روزانه، SL/TP ثابت ۷۰ پیپ | **سطوح روزانهٔ دیروز** (PDH/PDL/PDC/PDO/Pivot/R1/S1) + H1 + دستی؛ SL = ساختار + ۱.۵×ATR، TP = ۲R تا ۳R |
| حجم | `equity/100×0.01` و `min(هدف، سقف ریسک)` | خط لولهٔ ۱۱ گامی مبتنی بر Tier، ضریب‌های DD/Vol/Event، clamp [۰.۱۰٪, ۱.۵٪]، بودجهٔ پورتفوی |
| کول‌داون | ۳/۵/۲ کندل سراسری (بلاک کور) | **۴ دروازهٔ مستقل A/B/C/D**؛ فقط A و D حق REJECT کامل دارند |
| کنفلوئنس | ۵ استراتژی، مستطیل معاف | ۲ استراتژی + **تأیید ناحیه (`sr_zone`)** برای عددی؛ استراتژی ناحیه معاف (اولویت ۱۰) |
| سقف پوزیشن | ۱/۲/۲ ثابت | Gate C تطبیقی: روند ۲، رِنج ۱ + استثنای Hedge |

---

## ۱. جدول حل تناقض‌ها (الزامی برای پیاده‌سازی)

| # | تناقض | حکم نهایی | دلیل فنی |
|---|---|---|---|
| ۱ | ۵ استراتژی در برابر ۲ استراتژی | fvg / fvg_ma / ma_trend / rectangle **حذف**؛ numeric دست‌نخورده | دستور صریح کاربر؛ کاهش همبستگی و بار پارامتر |
| ۲ | SL/TP ثابت ۷۰/۷۰ در برابر SL ساختاری + ۱.۵×ATR | ساختاری + ۱.۵×ATR، TP چندلایه (۲R..۳R) | پرامپت ۳ بخش ۴ |
| ۳ | مدل حجم v0.3 (`equity/100`) در برابر Tier-based | Tier-based؛ `lot_per_100_usd` حذف از مسیر تصمیم (فقط به‌عنوان سقف اهرمی می‌ماند) | پرامپت ۳ بخش ۵؛ مدل قدیمی روی طلای ۴۰۰۰$ بی‌معنی بود |
| ۴ | `risk_per_trade_pct` پروفایل ۰.۵/۱/۲ | پروفایل = **سقف مطلق**؛ ریسک پایه از Tier (۱.۰/۰.۷۵/۰.۵/۰.۲۵٪)؛ پروفایل high: ۲٪ → **۱.۵٪** | سقف ۱.۵٪ قانون اساسی پرامپت ۳ |
| ۵ | سقف پورتفوی ۳٪ در برابر Gate D با ۲٪ | Gate D = ۲٪ سخت (پیش‌فرض) و **هرگز > ۳٪**؛ ۳٪ سقف مطلق معماری | دو قید هم‌زمان؛ سخت‌تر حاکم است |
| ۶ | نام‌گذاری Tier: LOW=۱۰۰٪ / MEDIUM=۵۰٪ / HIGH=۲۵٪ | Tier کیفیت: A+/A/B/C (۱.۰/۰.۷۵/۰.۵/۰.۲۵٪) **جدا** از سطح حجم FULL/HALF/QUARTER (۱.۰/۰.۵/۰.۲۵) | نام‌گذاری پرامپت ۲ معکوس بود و با Tier پرامپت ۳ قاطی می‌شد |
| ۷ | کول‌داون سراسری ۳/۵/۲ | Gate A = ۱ کندل سخت؛ Gate B = ۲/۵/۳ کندل **per-zone/per-direction** | پرامپت ۲ |
| ۸ | کنفلوئنس ۲ استراتژی با فقط ۲ استراتژی موجود | تأیید ناحیه (`sr_zone`) به‌عنوان تأیید مستقل شمارش می‌شود | جلوگیری از خفه‌شدن عددی؛ درخواست صریح کاربر |
| ۹ | منع ورود در جهت مخالف (پوزیشن سودده) | Hedge فقط وقتی پوزیشن موجود **در ضرر** است، با ۲۵٪ حجم | پرامپت ۲، بخش Hedge |
| ۱۰ | R:R پروفایل (۱.۰/۱.۵) در برابر R:R tier (۱.۲/۱.۵/۲.۰/۲.۵) | `max(پروفایل، tier)`؛ کمبود R:R ⇒ **تنزل Tier** نه رد؛ زیر C ⇒ نویز | پرامپت ۳ گام ۲ |
| ۱۱ | TP سه‌لایه ۵۰/۳۰/۲۰ | **فاز ۱:** یک تارگت در TP2 + BE در ۱R + Trailing؛ **فاز ۲:** Partial close | موتور فعلی یک تارگت دارد؛ ادعای خلاف واقع نکنیم |
| ۱۲ | توقف‌های روزانه/افت کل (پروفایل قدیمی) | حفظ می‌شوند (محافظت حساب، نه محافظه‌کاری استراتژیک) | قانون اساسی بند ۲ |
| ۱۳ | اولویت ۱۰ = حذف رقبا در همان کندل | اولویت فقط **ترتیب ارزیابی** است؛ هیچ سیگنالی به‌خاطر اولویت حذف نمی‌شود | «سیگنال را نکش» |

---

## ۲. معماری

```
CBot
├── CZoneEngine            تشخیص/امتیازدهی ناحیه (H1 swings + ناحیهٔ دستی)
├── CSignalEngine
│   ├── CZonesStrategy     Rejection / Sweep&Reclaim / Break&Retest
│   └── CNumericStrategy   بدون تغییر (۱۲/۱۵/۱۸، RR پویا)
├── CDecisionMatrix        Composite/Tier، RR downgrade
├── CCooldownManager       Gate A + Gate B + Gate C  (Gate D در Capital)
├── CCapitalManager        گام‌های ۱..۱۱، DD/Vol/Event، پورتفوی، کمیسیون
├── CExecutionGuard        Spread / Margin / StopsLevel / Rollover
└── CTradeLifecycle        FSM پوزیشن + BE/Trailing
```

لایه‌بندی پروژه حفظ می‌شود: `domain ← ports ← app ← adapters ← runtime`؛ پلاگین‌ها فقط `goldbot.strategy_api`.

---

## ۳. مدل ناحیه و امتیازها

### ۳.۱ ناحیه (`Zone`)
```
zone_id, high, low, kind(support|resistance), score(0..100),
source(auto|manual), touches, starred, created_bar, last_touch_bar
```
- **روزانه (منبع اصلی):** در اولین کندل M15 روز معاملاتی جدید از **آخرین روز کامل بروکر** ساخته می‌شود:
  PDH/PDL/PDC/PDO/Pivot/R1/S1، نیم‌عرض `0.12×ATR(D1)`، امتیاز پایه ۸۲/۸۲/۷۲/۶۶/۵۸/۶۲/۶۲ + برخوردها (۳ هر برخورد) + عدد رُند (۵).
  تا پایان روز **ثابت** می‌ماند (رویداد `DailyLevelsReady`). مرز روز با `broker_offset`، نه UTC.
- **خودکار H1:** فراکتال H1 (span=3) روی ۲۰۰ کندل H1 (۸۰۰ کندل M15)؛ تلورانس `0.3×ATR(H1)`؛ حداقل ۲ برخورد؛ نیم‌عرض `0.15×ATR(H1)`.
- **دستی:** `var/zones.json` حفظ می‌شود؛ امتیاز پایه ۷۰ (ستاره‌دار ۸۵) با جریمهٔ عرض.
- **تقدم ادغام:** دستی > روزانه > H1 خودکار (`merge_all`)؛ ناحیهٔ هم‌پوشان با امتیاز کمتر حذف می‌شود.
- شناسه: `D{level}{mid×100}` برای روزانه، `M...` برای دستی، `Z...` برای H1.

### ۳.۲ Zone_Score (۰..۱۰۰)
| مؤلفه | وزن | سنجه |
|---|---:|---|
| برخوردها | ۲۰ | ۲→۰.۵، ۳→۰.۸، ≥۴→۱.۰ |
| قدرت واکنش | ۲۰ | میانگین سایهٔ برگشتی / (۰.۵×ATR) |
| تازگی | ۱۵ | افت خطی تا ۲۰۰ کندل |
| هم‌راستایی HTF | ۱۵ | نزدیکی به EMA200 H1 / عدد رُند ۱۰ دلاری |
| کیفیت عرض | ۱۵ | عرض مطلوب ۰.۲..۰.۶ ATR |
| حجم واکنش | ۱۵ | حجم کندل‌های برخورد / میانگین |

### ۳.۳ Signal_Score (−۲..+۲)
`score = Σ(wᵢ·fᵢ)/50` با `fᵢ∈[−1,+1]` و وزن‌های **۲۵/۲۰/۲۰/۲۰/۱۵**:
| i | مؤلفه | وزن |
|---|---|---:|
| ۱ | کیفیت واکنش ناحیه (سایه/سوئیپ/بدنه) + حجم نسبی ≥۱.۲ (+۰.۱) + Pin/Engulfing (+۰.۱۵) | ۲۵ |
| ۲ | ساختار و روند (EMA200 H1، شیب، ADX) + RSI(14) سازگار (+۰.۱) / اشباع مخالف (−۰.۲) | ۲۰ |
| ۳ | مومنتوم کندل تریگر | ۲۰ |
| ۴ | کیفیت ناحیه (Zone_Score/100) | ۲۰ |
| ۵ | سشن/نقدینگی | ۱۵ |

- `score < 0.3` ⇒ سیگنال صادر نمی‌شود (نویز).
- **آستانه‌های Bypass** (فقط Gate B/C، نه Tier): `≥1.5` و `≥1.0`.
- عددی: چون مومنتوم ندارد، مقدار خنثی `0.8` با پرچم `quality_source=numeric` (مستند و قابل بازبینی).

### ۳.۴ Composite و Tier
```
Composite = 0.5 × Zone_Score + 0.5 × clamp(Signal_Score/2, 0, 1) × 100
```
| Tier | Composite | Risk_Base | Min R:R | معنا |
|---|---:|---:|---:|---|
| **A+** | ۸۰..۱۰۰ | ۱.۰۰٪ | ۲.۵ | استثنایی (Zone≥۸۵ و Signal≥۱.۵ عملاً) |
| **A** | ۶۵..۷۹ | ۰.۷۵٪ | ۲.۰ | قوی |
| **B** | ۵۰..۶۴ | ۰.۵۰٪ | ۱.۵ | متوسط |
| **C** | ۳۵..۴۹ | ۰.۲۵٪ | ۱.۲ | حداقلی |
| — | <۳۵ | — | — | نویز؛ رد |

> چرا Composite؟ پرامپت ۳ امتیاز ۰..۱۰۰ می‌خواهد و پرامپت ۲ دو امتیاز مستقل. Composite تنها ترکیبی است که هر دو شرط A+ پرامپت ۲ (۸۵/۱.۵ → ۸۰) را بازتولید می‌کند.

---

## ۴. ماتریس تصمیم و R:R

```
Signal + Zone_Score → Composite → Tier پیشنهادی + Risk_Base + R:R_Min(Tier)
R:R_Achievable = |TP2 − Entry| / |Entry − SL|
IF R:R_Achievable < R:R_Min(Tier): تنزل یک Tier (نه رد)
IF Tier پس از تنزل < C: REJECT با دلیل "noise_rr"
```
R:R مؤثر = `max(profile.min_rr, R:R_Min(Tier))`.

---

## ۵. دروازه‌های کول‌داون

### Gate A — Tick-Noise (سخت)
- `GateA_Window = 1` کندل M15 بعد از هر اجرا (ورود/SL/TP/BE).
- **Bypass ندارد.** فقط Gate A و Gate D حق REJECT کامل دارند.

### Gate B — Zone Burn (per-zone, per-direction)
| رویداد | Burn |
|---|---|
| TP | ۲ کندل M15 |
| SL | ۵ کندل M15 |
| Break-even | ۳ کندل M15 |
- SL دوبار روی یک ناحیه ⇒ Burn تا پایان روز (ناحیهٔ معیوب).
- Bypass:
  - `Signal≥1.5 && Zone≥85 && Setup∈{Sweep, Break_Retest}` ⇒ **Full Pass**
  - `Signal≥1.0 && Zone≥70` ⇒ **Downgrade** (FULL→HALF→QUARTER→REJECT)
  - وگرنه REJECT با `Zone_Burn_No_Bypass`

### Gate C — Direction Concentration
| رژیم (ADX H1) | Max سقف هم‌جهت |
|---|---:|
| >۳۰ | ۲ |
| ≤۳۰ | ۱ |
- Bypass:
  - همهٔ پوزیشن‌های هم‌جهت در سود ≥۰.۵×ATR و ناحیهٔ متفاوت با Zone≥85 ⇒ Full Pass
  - سیگنال C با Zone≥85 و Signal≥1.2 ⇒ Full Pass (یک پوزیشن اضافه)
  - سیگنال C/B و همهٔ هم‌جهت‌ها ≥BE ⇒ Downgrade
  - Hedge: پوزیشن مخالف **در ضرر** + Signal≥1.0 + Zone≥75 ⇒ ورود ۲۵٪
  - پوزیشن سودده ⇒ Hedge ممنوع؛ سیگنال ضعیف ⇒ REJECT

### Gate D — Total Risk Cap (سخت)
```
OpenRisk + ProposedRisk > min(2% , 3%)×Equity ⇒ REJECT (بدون Bypass)
```

### ریست خودکار
| رویداد | ریست |
|---|---|
| BOS / CHoCH در H1 | Gate B و C |
| ناحیهٔ جدید با Zone≥90 (پروکسی: سیگنال اجراشده با Zone≥90) | شمارنده‌های Gate C |
| تغییر سشن | Gate B فقط برای ناحیه‌های Zone<70 |
| دو برابر شدن ATR(H1) نسبت به میانهٔ ۲۰ کندل | همهٔ دروازه‌ها |

---

## ۶. مدیریت سرمایه — ترتیب اجباری (تنها منبع حقیقت)

```
1) Tier + Risk_Base           ∈ {1.00, 0.75, 0.50, 0.25}%
2) R:R check + downgrade      (بخش ۴)
3) Risk_1 = Base × DD_Mult
4) Risk_2 = Risk_1 × Vol_Mult
5) Risk_3 = Risk_2 × Event_Mult
6) Risk_Intended = clamp(Risk_3, 0.10%, 1.50%)
7) Risk_Final = min(Risk_Intended, Remaining_Portfolio, GateD_Remaining)
8) Lot_raw = Risk_Final%×Equity / (SL_dist×Contract + Commission_RT)
   Lot = floor_to_step(Lot_raw)
9) Lot < 0.01 ⇒ SKIP (قید فیزیکی)
   ریسک واقعی = SL_dist×Contract×Lot + Commission×Lot
   > 1.5%×Equity ⇒ کاهش Lot
10) ExecutionGuard: Spread، MarginLevel≥300%، StopsLevel (clamp)، Rollover
11) ارسال
```

| افت از سقف | DD_Mult | | صدک ATR روزانه | Vol_Mult | | رویداد | Event_Mult |
|---|---:|---|---|---:|---|---|---:|
| ۰–۵٪ | ۱.۰۰ | | <۸۰ | ۱.۰۰ | | عادی | ۱.۰۰ |
| ۵–۱۰٪ | ۰.۷۵ | | ۸۰–۹۵ | ۰.۷۵ | | آسیا | ۰.۷۵ |
| ۱۰–۱۵٪ | ۰.۵۰ | | >۹۵ | ۰.۵۰ | | خبر ۱۵/۳۰ | ۰.۵۰ |
| >۱۵٪ | ۰.۲۵ | | | | | Rollover | ۰ (Hard) |

- بازگشت DD تدریجی است (فقط بعد از جبران ۵۰٪ افت، رمپ خطی).
- پورتفوی: `Max_Concurrent_Risk = 3%×Equity`, `Max_Positions = 2`.
- صدک ATR: از ATR روزانهٔ D1 (۹۰ روز) ساخته‌شده از ریزساختار M15؛ اگر تاریخچه <۲۰ روز ⇒ ضریب ۱.۰.
- کمیسیون: `execution.commission_per_lot` (پیش‌فرض ۷$/لات).

---

## ۷. خروج (فاز ۱)
- SL = `min/max(سایهٔ سوئیپ/سوئینگ، Entry ∓ ۱.۵×ATR(14,M15))`، سپس clamp به StopsLevel.
- Target = فاصله تا نزدیک‌ترین ناحیهٔ مخالف/نقدینگی ×۰.۹۵، محدود به [۲.۰R, ۳.۰R].
- BE در ۱R (risk engine)، Trailing ۰.۵×ATR بعد از ۱.۲R–۱.۵R (پروفایل).
- ابطال ساختاری: بسته‌شدن کندل به اندازهٔ **۱.۰×ATR** بیرون ناحیه ⇒ `exit_signal(zone_lost)` (قابل خاموش‌کردن با ۰).
  (در A/B اولیه، ۰.۵×ATR بیش از حد معامله‌ها را زود می‌بست و به −۸.۶٪ رسید؛ ۱.۰×ATR نتیجهٔ −۳.۹٪ داد.)
- **استراتژی عددی هم همین هندسه را دارد:** SL = ساختار (سوئینگ/سطح) + ۱.۵×ATR، TP = نزدیک‌ترین ناحیهٔ مخالف ×۰.۹۵ با clamp [۲R, ۳R]؛ `sl_mode=structure` و `target_zone` در ژورنال.
- **فاز ۲:** TP1 ۵۰٪ در ۱R + TP2 ۳۰٪ در ۲R + ۲۰٪ trailing (نیازمند partial close در لایهٔ اجرا).

---

## ۸. کنفلوئنس
- `min_confirmations = 2`.
- منابع تأیید: استراتژی‌های هم‌جهت در پنجرهٔ ۳۰ دقیقه + برچسب `sr_zone` (ناحیهٔ هم‌جهت با Zone_Score ≥ ۵۰ و فاصله ≤ ۲×ATR).
- `zones` اولویت ۱۰ ⇒ معاف از فیلتر (مثل مستطیل قبلی) ولی **بدون حذف رقبا**.
- `numeric`: خروج ۲R..۳R دارد (مثل استراتژی ناحیه)، پس مشکل R:R ندارد؛ ولی برای عبور از `min_confirmations` به تأیید دوم
  (`sr_zone` یا سیگنال `zones`) نیاز دارد. با سطوح روزانه، نرخ تأیید بالا می‌رود.
- **اولویت:** در هر کندل، اگر `zones` (priority 10) سیگنال ورود داشته باشد، سیگنال‌های با priority بالاتر (عددی) اجرا نمی‌شوند
  (`priority_skipped`). این تنها حذف مبتنی بر اولویت است و در ژورنال ثبت می‌شود.
- ژورنال: `by_confirmation_set` مثل `numeric+sr_zone`.

---

## ۹. پارامترها (کلیدهای TOML)

```toml
[trading]
min_confirmations = 2
confluence_window_minutes = 30
history_bars = 9600                 # ≈۱۰۰ روز M15 برای صدک ATR روزانه
zone_confirmation_min_score = 50
zone_confirmation_max_atr = 2.0     # فاصلهٔ مجاز ناحیه از قیمت سیگنال

[gates]
gate_a_window = 1
burn_after_tp = 2
burn_after_sl = 5
burn_after_be = 3
full_bypass_signal = 1.5
full_bypass_zone = 85
downgrade_min_signal = 1.0
downgrade_min_zone = 70
max_directional_trend = 2
max_directional_range = 1
profit_threshold_atr = 0.5
hedge_size_factor = 0.25
hedge_min_signal = 1.0
hedge_min_zone = 75

[capital]
risk_floor_pct = 0.10
risk_ceiling_pct = 1.50
portfolio_ceiling_pct = 3.0
gate_d_max_risk_pct = 2.0
vol_percentile_window_days = 90
```

---

## ۱۰. نگاشت فایل‌ها (پیاده‌سازی)

| مسئولیت | فایل |
|---|---|
| مدل/تشخیص/امتیاز ناحیه | `src/goldbot/strategy_api/zones.py` |
| اندیکاتورها (ADX، resample، صدک) | `src/goldbot/strategy_api/indicators.py` |
| استراتژی ناحیه | `src/strategies/zones/strategy.py` |
| ماتریس تصمیم/Tier | `src/goldbot/app/decision.py` |
| دروازه‌ها A/B/C + ریست | `src/goldbot/app/gates.py` |
| رژیم بازار (ATR/ADX/BOS) | `src/goldbot/app/regime.py` |
| ناحیهٔ مشترک موتور/تأیید | `src/goldbot/app/zones_engine.py` |
| مدیریت سرمایه | `src/goldbot/app/risk/capital.py` |
| اتصال در موتور | `src/goldbot/app/engine.py` |
| تأیید ناحیه در موتور | `src/goldbot/app/engine.py` (ZoneEngine) |

---

## ۱۱. لاگ اجباری هر سیگنال
`Decision{signal_score, zone_score, composite, tier, original_tier, gate_hit, bypass_type, final_size_factor, risk_base, risk_final, rr, volume, reasons}` — به‌صورت رویداد `DECISION_EVALUATED` و `GATE_EVALUATED` در ژورنال.

---

## ۱۲. معیارهای پذیرش
1. هیچ سیگنالی به‌خاطر «محافظه‌کاری» رد نشود؛ فقط Gate A/D، Lot<0.01، Rollover، Margin<300٪، Spread>0.3×SL.
2. هیچ معامله‌ای از ۱.۵٪ (تک) و ۳٪ (پورتفوی) فراتر نرود؛ هیچ سفارشی با Lot<0.01 ارسال نشود.
3. Missed Strong Signals < ۵٪ سیگنال‌های قوی؛ DD ناشی از تراکم ≤ ۱.۵× حالت بدون Gate C.
4. تست A/B قدیم/جدید + گزارش PF، MaxDD، تعداد سیگنال قوی ازدست‌رفته.
5. تست رگرسیون تناقض: مسیر گام‌های ۱..۱۱ با ورودی مصنوعی.
6. هر Downgrade/Bypass در ژورنال قابل ردیابی باشد.

---

## ۱۳. فازبندی
| فاز | محتوا | وضعیت |
|---|---|---|
| ۱ | دو استراتژی، ناحیهٔ خودکار، Tier، Gates A–D، Capital، BE/Trailing | **پیاده‌سازی همین نسخه** |
| ۲ | TP سه‌لایه با partial close، سواپ/کمیسیون ساعتی، فیلتر خبر واقعی | بعدی |
| ۳ | دادهٔ واقعی MT5 + walk-forward + مونت‌کارلو + گیت‌وی | بعدی |

> محدودیت صادقانه: بدون دادهٔ واقعی و بک‌تست walk-forward، اعداد ۲.۵٪/۱.۵٪ / ۸۵ و ۱.۵ «پیش‌فرض مهندسی» هستند، نه نتیجهٔ بهینه‌سازی.
