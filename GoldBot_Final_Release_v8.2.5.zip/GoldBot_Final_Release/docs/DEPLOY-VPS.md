# استقرار پنل GoldBot روی VPS (احراز هویت‌شده)

> هدف: پنل وب محلی روی یک VPS اوبونتو اجرا شود و از اینترنت **فقط با توکن** در دسترس باشد.
> این سند و اسکریپت هرگز معامله‌ای انجام نمی‌دهند؛ فقط پنل وب را بالا می‌آورند.

---

## ۱. معماری استقرار

- کد در **/opt/goldbot** (از همین مخزن بسته‌بندی و آپلود می‌شود).
- محیط مجازی: **/opt/goldbot/.venv** با fastapi و uvicorn و pydantic (بدون وابستگی جدید دیگر).
- سرویس systemd: **goldbot-panel** با کاربر root، WorkingDirectory=/opt/goldbot، Restart=always.
- توکن فقط در **/etc/goldbot/panel.env** (مالک root، مود 600) قرار می‌گیرد؛ در repo یا unit نوشته نمی‌شود.
- پورت پیش‌فرض پنل: **8199** (اگر روی سرور اشغال بود، در اسکریپت با GOLDBOT_PANEL_PORT عوض کن).
- آدرس‌ها: ریشه‌ی پنل در / و سلامت در /api/health؛ هر دو نیازمند توکن.

پورت 8099 روی این VPS متعلق به سرویس دیگری است؛ ۸۱۹۹ انتخاب شد چون آزاد بود.

---

## ۲. پیش‌نیازها روی ماشین اپراتور (ویندوز)

    python -m pip install -e ".[deploy]"

**اعتبارسنجی SSH:** اسکریپت فقط کلیدهای ثبت‌شده در `~/.ssh/known_hosts` را می‌پذیرد و کلید ناشناس را خودکار قبول نمی‌کند. fingerprint کلید VPS را از کنسول/ارائه‌دهنده به‌صورت مستقل دریافت کن؛ fingerprint خروجی `ssh-keyscan` را با آن تطبیق بده و فقط پس از تطبیق، کلید را به `known_hosts` اضافه کن.

پارامترهای ورود از محیط خوانده می‌شوند و در هیچ فایلی ذخیره نمی‌شوند:

    GOLDBOT_VPS_HOST       آدرس VPS (مثلاً <VPS_HOST>)
    GOLDBOT_VPS_PASSWORD   رمز SSH (یا GOLDBOT_VPS_KEY برای کلید خصوصی)
    GOLDBOT_VPS_USER       پیش‌فرض root
    GOLDBOT_PANEL_PORT     پیش‌فرض 8199
    GOLDBOT_PANEL_TOKEN    اختیاری: اگر بخواهی توکن خاصی جایگزین شود

---

## ۳. استقرار (یک‌دستوری و idempotent)

در PowerShell از ریشه‌ی مخزن:

    $env:GOLDBOT_VPS_HOST='<VPS_HOST>'
    $env:GOLDBOT_VPS_PASSWORD='<رمز SSH>'
    $env:PYTHONPATH='src'
    python scripts/deploy_vps.py

اسکریپت این کارها را به ترتیب انجام می‌دهد:

۱. بسته‌بندی فقط src و config و run_goldbot.py (بدون var و .git و __pycache__ و *.db).
۲. آپلود با SFTP و جایگزینی /opt/goldbot/src و /opt/goldbot/config.
۳. ساخت .venv (فقط بار اول) و نصب fastapi/uvicorn/pydantic.
۴. توکن موجود روی VPS را نگه می‌دارد؛ فقط اگر نبود، توکن ۲۵۶ بیتی می‌سازد و در panel.env می‌نویسد.
۵. نصب unit از scripts/systemd/goldbot-panel.service، فعال‌سازی و ری‌استارت سرویس.
۶. تست سلامت با توکن و تست این‌که بدون توکن ۴۰۱ برمی‌گردد.
۷. اگر ufw فعال باشد فقط پورت را allow می‌کند؛ هرگز ufw را روشن/خاموش نمی‌کند.

اجرای دوباره = به‌روزرسانی کد و ری‌استارت، با همان توکن قبلی.

---

## ۴. تأیید پس از استقرار

روی خود VPS:

    systemctl status goldbot-panel --no-pager
    journalctl -u goldbot-panel -n 50 --no-pager
    set -a; . /etc/goldbot/panel.env; set +a
    curl -s -o /dev/null -w '%{http_code}\n' -H "Authorization: Bearer $GOLDBOT_PANEL_TOKEN" http://127.0.0.1:8199/api/health
    curl -s -o /dev/null -w '%{http_code}\n' http://127.0.0.1:8199/api/health   # باید 401 باشد

کد 200 یعنی پنل سالم است؛ کد 503 یعنی پنل بالاست ولی health وضعیت degraded دارد (قفل ریسک، heartbeat کهنه یا ژورنال ناخوانا) — باید در RUNBOOK بررسی شود.

---

## ۵. استفاده از پنل

- مرورگر: http://<VPS_HOST>:8199/ باز کن؛ پنجره‌ی Basic Auth می‌آید.
- نام کاربری: هر چیزی (مثلاً goldbot) — رمز: همان توکن.
- کلاینت API: هدر Authorization: Bearer <token> هم پذیرفته می‌شود.
- توکن در پایان خروجی اسکریپت یک‌بار چاپ می‌شود؛ آن را در جای امن (مدیر رمز) نگه دار.

---

## ۶. تونل SSH (بدون باز کردن پورت عمومی — امن‌ترین راه)

روی ماشین خودت:

    ssh -L 8199:127.0.0.1:8199 root@<VPS_HOST>

سپس فقط http://127.0.0.1:8199 را باز کن. در این حالت لازم نیست پورت 8199 در ufw یا Security Group ابری باز باشد.
اگر پورت عمومی را باز می‌کنی، توجه کن HTTP ساده است و توکن روی شبکه منتقل می‌شود؛ برای استفاده‌ی طولانی‌مدت https (پروکسی معکوس nginx با گواهی) بهتر است.

---

## ۷. چرخش توکن

    # روی VPS، مقدار جدید را در فایل ریشه‌ای بنویس
    printf 'GOLDBOT_PANEL_TOKEN=%s\n' "$(python3 -c 'import secrets; print(secrets.token_urlsafe(32))')" > /etc/goldbot/panel.env
    chmod 600 /etc/goldbot/panel.env
    systemctl restart goldbot-panel
    # مقدار جدید را بخوان و در مدیر رمز ذخیره کن
    sudo sed -n 's/^GOLDBOT_PANEL_TOKEN=//p' /etc/goldbot/panel.env

پنل توکن را در هر درخواست از محیط می‌خواند، اما systemd متغیر را فقط هنگام شروع می‌دهد؛ پس ری‌استارت لازم است.

---

## ۸. عملیات روزمره

    systemctl status goldbot-panel      # وضعیت
    systemctl restart goldbot-panel     # ری‌استارت
    systemctl stop goldbot-panel        # توقف
    journalctl -u goldbot-panel -f      # لاگ زنده
    ufw status | grep 8199              # وضعیت فایروال
    ss -lntp | grep 8199                # چه چیزی روی پورت گوش می‌دهد

---

## ۹. عیب‌یابی

| نشانه | علت محتمل | راه‌حل |
|---|---|---|
| سرویس بالا نمی‌آید | خطای import یا config | journalctl -u goldbot-panel -n 80 و اجرای دستی: cd /opt/goldbot && .venv/bin/python run_goldbot.py serve --host 0.0.0.0 --port 8199 |
| 401 روی همه چیز | توکن اشتباه یا خالی | مقدار panel.env را با Basic/Bearer تست کن |
| 502/اتصال برقرار نمی‌شود از بیرون | Security Group ابری | TCP 8199 را در کنسول ابری allow کن؛ ufw سمت سرور قبلاً allow شده |
| 503 روی /api/health | degraded (قفل/heartbeat/ژورنال) | RUNBOOK بخش‌های ۳–۵ |
| پورت اشغال است | سرویس دیگر | GOLDBOT_PANEL_PORT=8199 را عوض کن و دوباره deploy کن (unit خودش render می‌شود) |
| pip در حافظه کم می‌آورد | RAM کم | swap موجود (سرور ۲.۵ گیگ swap آزاد دارد)؛ دوباره اجرا کن |

---

## ۱۰. rollback و حذف

    # توقف و غیرفعال‌سازی بدون حذف فایل‌ها
    systemctl disable --now goldbot-panel
    # حذف کامل (فقط وقتی مطمئنی)
    rm -f /etc/systemd/system/goldbot-panel.service
    systemctl daemon-reload
    rm -rf /opt/goldbot /etc/goldbot
    # و در صورت نیاز: ufw delete allow 8199/tcp

برای rollback نسخه، کافی است همان اسکریپت را با checkout قبلی repo اجرا کنی؛ توکن و unit دست نمی‌خورند.

---

## ۱۱. نکات امنیتی

- رمز SSH و توکن پنل هرگز در Git یا داخل اسکریپت ذخیره نمی‌شوند. فرمان نوشتن توکن در لاگ محلی چاپ نمی‌شود و مقدار توکن فقط در پایان deploy یک بار نمایش داده می‌شود.
- کلید SSH ناشناس رد می‌شود؛ host key را فقط پس از تطبیق fingerprint مستقل در `known_hosts` ثبت کن.
- panel.env فقط root-readable است؛ unit از EnvironmentFile می‌خواند.
- پنل فقط با توکن کار می‌کند؛ حالت بدون توکن فقط برای 127.0.0.1 (پیش‌فرض محلی) مجاز است و CLI اگر host غیر-loopback باشد و توکن نباشد، بالا نمی‌آید.
- سرویس پنل به MT5/معامله دسترسی ندارد؛ فقط فایل‌های config و var و ژورنال را می‌خواند.
- برای دسترسی دائمی، HTTPS معکوس (nginx موجود) یا تونل SSH را ترجیح بده؛ HTTP ساده توکن را رمزنگاری نمی‌کند.
