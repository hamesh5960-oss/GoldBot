# GoldBot — مشخصات یکپارچهٔ نسخهٔ ۱.۱ (v2.0: لایه‌بندی ایمنی و تقویت سیگنال)

> **یادداشت وضعیت:** این سند تاریخی است. بخش‌هایی از تصمیم‌های آن با ADRهای جدیدتر 031 تا 041 بازنشسته/جایگزین شده‌اند. برای رفتار جاری، `docs/HANDOFF-PROMPT.md` و ADRهای جدیدتر را مرجع قرار دهید؛ این سند به‌تنهایی مشخصات اجرایی نسخهٔ فعلی نیست.

> **این سند «منبع حقیقت» است.** هر جا کد، README یا پرامپت قبلی با این سند تناقض داشت، این سند حاکم است.
> پرامپت‌های پایه: (۱) HANDOFF v0.4 — بات قبلی، (۲) پرامپت محدودهٔ حمایت/مقاومت + کول‌داون چهار دروازه‌ای،
> (۳) پرامپت مدیریت ریسک و سرمایه. **اولویت در تناقض: ۳ > ۲ > ۱.**

---

## ۰. تصمیم‌های بنیادی (خلاصهٔ مدیریتی)

| موضوع | نسخهٔ قبلی | نسخهٔ ۱.۰ |
|---|---|---|
| استراتژی‌ها | ۵ استراتژی (rectangle, numeric, fvg, fvg_ma, ma_trend) | **۲ استراتژی**: `zones` (حمایت/مقاومت) و `numeric` (بدون تغییر منطق) |
| ناحیه‌ها | مستطیل دستی روزانه، SL/TP ثابت ۷۰ پیپ | **سطوح روزانهٔ دیروز** (PDH/PDL/PDC/PDO/Pivot/R1/S1) + H1 + دستی؛ SL = ساختار + ۱.۵×ATR، TP = ۲R تا ۳R |
| حجم | `equity/100×0.01` و `min(هدف، سقف ریسک)` | خط لولهٔ ۱۱ گامی مبتنی بر Tier، ضریب‌های DD/Vol/Event، clamp [۰.۱۰٪, ۱.۵٪]، بودجهٔ پورتفوی |
| کول‌داون | ۳/۵/۲ کندل سراسری (بلاک کور) | **۴ دروازهٔ مستقل A/B/C/D**؛ فقط A و D حق REJECT کامل دارند |
| کنفلوئنس | ۵ استراتژی، مستطیل معاف | ۲ استراتژی + **تأیید ناحیه (`sr_zone`)** برای عددی؛ استراتژی ناحیه معاف (اولویت ۱۰) |
| سقف پوزیشن | ۱/۲/۲ ثابت | Gate C تطبیقی: روند ۲، رِنج ۱ + استثنای Hedge |

---

## ۱. جدول حل تناقض‌ها (الزامی برای پیاده‌سازی)

| # | تناقض | حکم نهایی | دلیل فنی |
|---|---|---|---|
| ۱ | ۵ استراتژی در برابر ۲ استراتژی | fvg / fvg_ma / ma_trend / rectangle **حذف**؛ numeric دست‌نخورده | دستور صریح کاربر؛ کاهش همبستگی و بار پارامتر |
| ۲ | SL/TP ثابت ۷۰/۷۰ در برابر SL ساختاری + ۱.۵×ATR | ساختاری + ۱.۵×ATR، TP چندلایه (۲R..۳R) | پرامپت ۳ بخش ۴ |
| ۳ | مدل حجم v0.3 (`equity/100`) در برابر Tier-based | Tier-based؛ `lot_per_100_usd` حذف از مسیر تصمیم (فقط به‌عنوان سقف اهرمی می‌ماند) | پرامپت ۳ بخش ۵؛ مدل قدیمی روی طلای ۴۰۰۰$ بی‌معنی بود |
| ۴ | `risk_per_trade_pct` پروفایل ۰.۵/۱/۲ | پروفایل = **سقف مطلق**؛ ریسک پایه از Tier (۱.۰/۰.۷۵/۰.۵/۰.۲۵٪)؛ پروفایل high: ۲٪ → **۱.۵٪** | سقف ۱.۵٪ قانون اساسی پرامپت ۳ |
| ۵ | سقف پورتفوی ۳٪ در برابر Gate D با ۲٪ | Gate D = ۲٪ سخت (پیش‌فرض) و **هرگز > ۳٪**؛ ۳٪ سقف مطلق معماری | دو قید هم‌زمان؛ سخت‌تر حاکم است |
| ۶ | نام‌گذاری Tier: LOW=۱۰۰٪ / MEDIUM=۵۰٪ / HIGH=۲۵٪ | Tier کیفیت: A+/A/B/C (۱.۰/۰.۷۵/۰.۵/۰.۲۵٪) **جدا** از سطح حجم FULL/HALF/QUARTER (۱.۰/۰.۵/۰.۲۵) | نام‌گذاری پرامپت ۲ معکوس بود و با Tier پرامپت ۳ قاطی می‌شد |
| ۷ | کول‌داون سراسری ۳/۵/۲ | Gate A = ۱ کندل سخت؛ Gate B = ۲/۵/۳ کندل **per-zone/per-direction** | پرامپت ۲ |
| ۸ | کنفلوئنس ۲ استراتژی با فقط ۲ استراتژی موجود | تأیید ناحیه (`sr_zone`) به‌عنوان تأیید مستقل شمارش می‌شود | جلوگیری از خفه‌شدن عددی؛ درخواست صریح کاربر |
| ۹ | منع ورود در جهت مخالف (پوزیشن سودده) | Hedge فقط وقتی پوزیشن موجود **در ضرر** است، با ۲۵٪ حجم | پرامپت ۲، بخش Hedge |
| ۱۰ | R:R پروفایل (۱.۰/۱.۵) در برابر R:R tier (۱.۲/۱.۵/۲.۰/۲.۵) | `max(پروفایل، tier)`؛ کمبود R:R ⇒ **تنزل Tier** نه رد؛ زیر C ⇒ نویز | پرامپت ۳ گام ۲ |
| ۱۱ | TP سه‌لایه ۵۰/۳۰/۲۰ | **فاز ۱:** یک تارگت در TP2 + BE در ۱R + Trailing؛ **فاز ۲:** Partial close | موتور فعلی یک تارگت دارد؛ ادعای خلاف واقع نکنیم |
| ۱۲ | توقف‌های روزانه/افت کل (پروفایل قدیمی) | حفظ می‌شوند (محافظت حساب، نه محافظه‌کاری استراتژیک) | قانون اساسی بند ۲ |
| ۱۳ | اولویت ۱۰ = حذف رقبا در همان کندل | اولویت فقط **ترتیب ارزیابی** است؛ هیچ سیگنالی به‌خاطر اولویت حذف نمی‌شود | «سیگنال را نکش» |

---

## ۲. معماری

```
CBot
├── CZoneEngine            تشخیص/امتیازدهی ناحیه (H1 swings + ناحیهٔ دستی)
├── CSignalEngine
│   ├── CZonesStrategy     Rejection / Sweep&Reclaim / Break&Retest
│   └── CNumericStrategy   بدون تغییر (۱۲/۱۵/۱۸، RR پویا)
├── CDecisionMatrix        Composite/Tier، RR downgrade
├── CCooldownManager       Gate A + Gate B + Gate C  (Gate D در Capital)
├── CCapitalManager        گام‌های ۱..۱۱، DD/Vol/Event، پورتفوی، کمیسیون
├── CExecutionGuard        Spread / Margin / StopsLevel / Rollover
└── CTradeLifecycle        FSM پوزیشن + BE/Trailing
```

لایه‌بندی پروژه حفظ می‌شود: `domain ← ports ← app ← adapters ← runtime`؛ پلاگین‌ها فقط `goldbot.strategy_api`.

---

## ۳. مدل ناحیه و امتیازها

### ۳.۱ ناحیه (`Zone`)
```
zone_id, high, low, kind(support|resistance), score(0..100),
source(auto|manual), touches, starred, created_bar, last_touch_bar
```
- **روزانه (منبع اصلی):** در اولین کندل M15 روز معاملاتی جدید از **آخرین روز کامل بروکر** ساخته می‌شود:
  PDH/PDL/PDC/PDO/Pivot/R1/S1، نیم‌عرض `0.12×ATR(D1)`، امتیاز پایه ۸۲/۸۲/۷۲/۶۶/۵۸/۶۲/۶۲ + برخوردها (۳ هر برخورد) + عدد رُند (۵).
  تا پایان روز **ثابت** می‌ماند (رویداد `DailyLevelsReady`). مرز روز با `broker_offset`، نه UTC.
- **خودکار H1:** فراکتال H1 (span=3) روی ۲۰۰ کندل H1 (۸۰۰ کندل M15)؛ تلورانس `0.3×ATR(H1)`؛ حداقل ۲ برخورد؛ نیم‌عرض `0.15×ATR(H1)`.
- **دستی:** `var/zones.json` حفظ می‌شود؛ امتیاز پایه ۷۰ (ستاره‌دار ۸۵) با جریمهٔ عرض.
- **تقدم ادغام:** دستی > روزانه > H1 خودکار (`merge_all`)؛ ناحیهٔ هم‌پوشان با امتیاز کمتر حذف می‌شود.
- شناسه: `D{level}{mid×100}` برای روزانه، `M...` برای دستی، `Z...` برای H1.

### ۳.۲ Zone_Score (۰..۱۰۰)
| مؤلفه | وزن | سنجه |
|---|---:|---|
| برخوردها | ۲۰ | ۲→۰.۵، ۳→۰.۸، ≥۴→۱.۰ |
| قدرت واکنش | ۲۰ | میانگین سایهٔ برگشتی / (۰.۵×ATR) |
| تازگی | ۱۵ | افت خطی تا ۲۰۰ کندل |
| هم‌راستایی HTF | ۱۵ | نزدیکی به EMA200 H1 / عدد رُند ۱۰ دلاری |
| کیفیت عرض | ۱۵ | عرض مطلوب ۰.۲..۰.۶ ATR |
| حجم واکنش | ۱۵ | حجم کندل‌های برخورد / میانگین |

### ۳.۳ Signal_Score (−۲..+۲)
`score = Σ(wᵢ·fᵢ)/50` با `fᵢ∈[−1,+1]` و وزن‌های **۲۵/۲۰/۲۰/۲۰/۱۵**:
| i | مؤلفه | وزن |
|---|---|---:|
| ۱ | کیفیت واکنش ناحیه (سایه/سوئیپ/بدنه) + حجم نسبی ≥۱.۲ (+۰.۱) + Pin/Engulfing (+۰.۱۵) | ۲۵ |
| ۲ | ساختار و روند (EMA200 H1، شیب، ADX) + RSI(14) سازگار (+۰.۱) / اشباع مخالف (−۰.۲) | ۲۰ |
| ۳ | مومنتوم کندل تریگر | ۲۰ |
| ۴ | کیفیت ناحیه (Zone_Score/100) | ۲۰ |
| ۵ | سشن/نقدینگی | ۱۵ |

- `score < 0.3` ⇒ سیگنال صادر نمی‌شود (نویز).
- **آستانه‌های Bypass** (فقط Gate B/C، نه Tier): `≥1.5` و `≥1.0`.
- عددی: چون مومنتوم ندارد، مقدار خنثی `0.8` با پرچم `quality_source=numeric` (مستند و قابل بازبینی).

### ۳.۴ Composite و Tier
```
Composite = 0.5 × Zone_Score + 0.5 × clamp(Signal_Score/2, 0, 1) × 100
```
| Tier | Composite | Risk_Base | Min R:R | معنا |
|---|---:|---:|---:|---|
| **A+** | ۸۰..۱۰۰ | ۱.۰۰٪ | ۲.۵ | استثنایی (Zone≥۸۵ و Signal≥۱.۵ عملاً) |
| **A** | ۶۵..۷۹ | ۰.۷۵٪ | ۲.۰ | قوی |
| **B** | ۵۰..۶۴ | ۰.۵۰٪ | ۱.۵ | متوسط |
| **C** | ۳۵..۴۹ | ۰.۲۵٪ | ۱.۲ | حداقلی |
| — | <۳۵ | — | — | نویز؛ رد |

> چرا Composite؟ پرامپت ۳ امتیاز ۰..۱۰۰ می‌خواهد و پرامپت ۲ دو امتیاز مستقل. Composite تنها ترکیبی است که هر دو شرط A+ پرامپت ۲ (۸۵/۱.۵ → ۸۰) را بازتولید می‌کند.

---

## ۴. ماتریس تصمیم و R:R

```
Signal + Zone_Score → Composite → Tier پیشنهادی + Risk_Base + R:R_Min(Tier)
R:R_Achievable = |TP2 − Entry| / |Entry − SL|
IF R:R_Achievable < R:R_Min(Tier): تنزل یک Tier (نه رد)
IF Tier پس از تنزل < C: REJECT با دلیل "noise_rr"
```
R:R مؤثر = `max(profile.min_rr, R:R_Min(Tier))`.

---

## ۵. دروازه‌های کول‌داون

### Gate A — Tick-Noise (سخت)
- `GateA_Window = 1` کندل M15 بعد از هر اجرا (ورود/SL/TP/BE).
- **Bypass ندارد.** فقط Gate A و Gate D حق REJECT کامل دارند.

### Gate B — Zone Burn (per-zone, per-direction)
| رویداد | Burn |
|---|---|
| TP | ۲ کندل M15 |
| SL | ۵ کندل M15 |
| Break-even | ۳ کندل M15 |
- SL دوبار روی یک ناحیه ⇒ Burn تا پایان روز (ناحیهٔ معیوب).
- Bypass:
  - `Signal≥1.5 && Zone≥85 && Setup∈{Sweep, Break_Retest}` ⇒ **Full Pass**
  - `Signal≥1.0 && Zone≥70` ⇒ **Downgrade** (FULL→HALF→QUARTER→REJECT)
  - وگرنه REJECT با `Zone_Burn_No_Bypass`

### Gate C — Direction Concentration
| رژیم (ADX H1) | Max سقف هم‌جهت |
|---|---:|
| >۳۰ | ۲ |
| ≤۳۰ | ۱ |
- Bypass:
  - همهٔ پوزیشن‌های هم‌جهت در سود ≥۰.۵×ATR و ناحیهٔ متفاوت با Zone≥85 ⇒ Full Pass
  - سیگنال C با Zone≥85 و Signal≥1.2 ⇒ Full Pass (یک پوزیشن اضافه)
  - سیگنال C/B و همهٔ هم‌جهت‌ها ≥BE ⇒ Downgrade
  - Hedge: پوزیشن مخالف **در ضرر** + Signal≥1.0 + Zone≥75 ⇒ ورود ۲۵٪
  - پوزیشن سودده ⇒ Hedge ممنوع؛ سیگنال ضعیف ⇒ REJECT

### Gate D — Total Risk Cap (دو لایه: soft ۲٪ / hard ۳٪)
```
OpenRisk + Proposed ≤ 2%          ⇒ FULL
2% < OpenRisk + Proposed ≤ 3%     ⇒ HALF (سایز نصف؛ نه رد)
OpenRisk + Proposed > 3%          ⇒ REJECT (سخت، بدون Bypass)
```

- `gate_d_max_risk_pct` = آستانهٔ راحتی (soft)، `gate_d_hard_pct` = سقف فیزیکی (hard).
- پیش‌فرض hard = ۲٪ است تا پاکت ریسک v1.1 بالا نرود؛ افزایش به ۳٪ تصمیم صریح اپراتور است.
- اگر با HALF هم min-lot از سقف hard رد شود، رد می‌شود (قید فیزیکی).

### ریست خودکار
| رویداد | ریست |
|---|---|
| BOS / CHoCH در H1 | Gate B و C |
| ناحیهٔ جدید با Zone≥90 (پروکسی: سیگنال اجراشده با Zone≥90) | شمارنده‌های Gate C |
| تغییر سشن | Gate B فقط برای ناحیه‌های Zone<70 |
| دو برابر شدن ATR(H1) نسبت به میانهٔ ۲۰ کندل | همهٔ دروازه‌ها |

---

## ۶. مدیریت سرمایه — ترتیب اجباری (تنها منبع حقیقت)

```
1) Tier + Risk_Base           ∈ {1.00, 0.75, 0.50, 0.25}%
2) R:R check + downgrade      (بخش ۴)
3) Risk_1 = Base × DD_Mult
4) Risk_2 = Risk_1 × Vol_Mult
5) Risk_3 = Risk_2 × Event_Mult
6) Risk_Intended = clamp(Risk_3, 0.10%, 1.50%)
7) Risk_Final = min(Risk_Intended, Remaining_Hard, GateD_Hard_Remaining)
   اگر در ناحیهٔ soft..hard افتاد ⇒ ×۰.۵ (HALF)، نه رد
8) Lot_raw = Risk_Final%×Equity / (SL_dist×Contract + Commission_RT)
   Lot = floor_to_step(Lot_raw)
9) Lot < 0.01 ⇒ SKIP (قید فیزیکی)
   ریسک واقعی = SL_dist×Contract×Lot + Commission×Lot
   > 1.5%×Equity ⇒ کاهش Lot
10) ExecutionGuard: Spread، MarginLevel≥300%، StopsLevel (clamp)، Rollover
11) ارسال
```

| افت از سقف | DD_Mult | | صدک ATR روزانه | Vol_Mult | | رویداد | Event_Mult |
|---|---:|---|---|---:|---|---|---:|
| ۰–۵٪ | ۱.۰۰ | | <۸۰ | ۱.۰۰ | | عادی | ۱.۰۰ |
| ۵–۱۰٪ | ۰.۷۵ | | ۸۰–۹۵ | ۰.۷۵ | | آسیا | ۰.۷۵ |
| ۱۰–۱۵٪ | ۰.۵۰ | | >۹۵ | ۰.۵۰ | | خبر ۱۵/۳۰ | ۰.۵۰ |
| >۱۵٪ | ۰.۲۵ | | | | | Rollover | ۰ (Hard) |

- بازگشت DD تدریجی است (فقط بعد از جبران ۵۰٪ افت، رمپ خطی).
- پورتفوی: `Max_Concurrent_Risk = 3%×Equity`, `Max_Positions = 2`.
- صدک ATR: از ATR روزانهٔ D1 (۹۰ روز) ساخته‌شده از ریزساختار M15؛ اگر تاریخچه <۲۰ روز ⇒ ضریب ۱.۰.
- کمیسیون: `execution.commission_per_lot` (پیش‌فرض ۷$/لات).

---

## ۷. خروج (فاز ۱)
- SL = `min/max(سایهٔ سوئیپ/سوئینگ، Entry ∓ ۱.۵×ATR(14,M15))`، سپس clamp به StopsLevel.
- Target = فاصله تا نزدیک‌ترین ناحیهٔ مخالف/نقدینگی ×۰.۹۵، محدود به [۲.۰R, ۳.۰R].
- BE در ۱R (risk engine)، Trailing ۰.۵×ATR بعد از ۱.۲R–۱.۵R (پروفایل).
- ابطال ساختاری: بسته‌شدن کندل به اندازهٔ **۱.۰×ATR** بیرون ناحیه ⇒ `exit_signal(zone_lost)` (قابل خاموش‌کردن با ۰).
  (در A/B اولیه، ۰.۵×ATR بیش از حد معامله‌ها را زود می‌بست و به −۸.۶٪ رسید؛ ۱.۰×ATR نتیجهٔ −۳.۹٪ داد.)
- **استراتژی عددی هم همین هندسه را دارد:** SL = ساختار (سوئینگ/سطح) + ۱.۵×ATR، TP = نزدیک‌ترین ناحیهٔ مخالف ×۰.۹۵ با clamp [۲R, ۳R]؛ `sl_mode=structure` و `target_zone` در ژورنال.
- **فاز ۲:** TP1 ۵۰٪ در ۱R + TP2 ۳۰٪ در ۲R + ۲۰٪ trailing (نیازمند partial close در لایهٔ اجرا).

---

## ۸. کنفلوئنس
- `min_confirmations = 2`؛ شمارش صریح: سیگنال اصلی (+۱) + استراتژی دیگر (+۱) + `sr_zone` (+۱).
- **Amplifier:** هر تأیید اضافه ×۱.۲۵ (تا ×۱.۵) روی حجم؛ سقف ریسک هر معامله ۱.۰٪ می‌ماند (`trade_risk_cap_pct`).
  `zones` از فیلتر معاف است ولی سقف تأییدش برای عددی ۱ کمتر نیست؛ عددی بدون تأیید دوم ⇒ SMALLEST.
- منابع تأیید: استراتژی‌های هم‌جهت در پنجرهٔ ۳۰ دقیقه + برچسب `sr_zone` (ناحیهٔ هم‌جهت با Zone_Score ≥ ۵۰ و فاصله ≤ ۲×ATR).
- `zones` اولویت ۱۰ ⇒ معاف از فیلتر (مثل مستطیل قبلی) ولی **بدون حذف رقبا**.
- `numeric`: خروج ۲R..۳R دارد (مثل استراتژی ناحیه)، پس مشکل R:R ندارد؛ ولی برای عبور از `min_confirmations` به تأیید دوم
  (`sr_zone` یا سیگنال `zones`) نیاز دارد. با سطوح روزانه، نرخ تأیید بالا می‌رود.
- **اولویت:** در هر کندل، اگر `zones` (priority 10) سیگنال ورود داشته باشد، سیگنال‌های با priority بالاتر (عددی) اجرا نمی‌شوند
  (`priority_skipped`). این تنها حذف مبتنی بر اولویت است و در ژورنال ثبت می‌شود.
- ژورنال: `by_confirmation_set` مثل `numeric+sr_zone`.

---

## ۹. پارامترها (کلیدهای TOML)

```toml
[trading]
min_confirmations = 2
confluence_window_minutes = 30
history_bars = 9600                 # ≈۱۰۰ روز M15 برای صدک ATR روزانه
zone_confirmation_min_score = 50
zone_confirmation_max_atr = 2.0     # فاصلهٔ مجاز ناحیه از قیمت سیگنال

[gates]
gate_a_window = 1
burn_after_tp = 2
burn_after_sl = 5
burn_after_be = 3
full_bypass_signal = 1.5
full_bypass_zone = 85
downgrade_min_signal = 1.0
downgrade_min_zone = 70
max_directional_trend = 2
max_directional_range = 1
profit_threshold_atr = 0.5
hedge_size_factor = 0.25
hedge_min_signal = 1.0
hedge_min_zone = 75

[capital]
risk_floor_pct = 0.10
risk_ceiling_pct = 1.50
portfolio_ceiling_pct = 3.0
gate_d_max_risk_pct = 2.0
vol_percentile_window_days = 90
```

### ۹.۱ کلیدهای بازنشسته (RETIRED)

> Settings هر کلید ناشناخته را رد می‌کند (extra="forbid")؛ بنابراین کپی‌کردن نمونهٔ
> بالا با کلیدهای بازنشسته، در startup خطای ConfigError می‌دهد. جدول زیر تنها مرجع
> مجاز برای این کلیدهاست:

| کلید قدیمی | وضعیت | جایگزین / مرجع |
|---|---|---|
| trading.min_confirmations | RETIRED | ADR-031/033/034: Tier از confirmation_count محاسبه می‌شود؛ کلید حذف شد |
| trading.weak_confluence_mode | RETIRED | ADR-009 (بازنشسته با ADR-031/034)، ADR-034: amplifier و confluence نرم حذف شدند |
| trading.dynamic_tier_margin | RETIRED | ADR-007 + ADR-024/034: باندهای Tier استاتیک شده‌اند |

---

## ۱۰. نگاشت فایل‌ها (پیاده‌سازی)

| مسئولیت | فایل |
|---|---|
| مدل/تشخیص/امتیاز ناحیه | `src/goldbot/strategy_api/zones.py` |
| اندیکاتورها (ADX، resample، صدک) | `src/goldbot/strategy_api/indicators.py` |
| استراتژی ناحیه | `src/strategies/zones/strategy.py` |
| ماتریس تصمیم/Tier | `src/goldbot/app/decision.py` |
| دروازه‌ها A/B/C + ریست | `src/goldbot/app/gates.py` |
| رژیم بازار (ATR/ADX/BOS) | `src/goldbot/app/regime.py` |
| ناحیهٔ مشترک موتور/تأیید | `src/goldbot/app/zones_engine.py` |
| مدیریت سرمایه | `src/goldbot/app/risk/capital.py` |
| اتصال در موتور | `src/goldbot/app/engine.py` |
| تأیید ناحیه در موتور | `src/goldbot/app/engine.py` (ZoneEngine) |

---

## ۱۱. لاگ اجباری هر سیگنال
`Decision{signal_score, zone_score, composite, tier, original_tier, gate_hit, bypass_type, final_size_factor, risk_base, risk_final, rr, volume, reasons}` — به‌صورت رویداد `DECISION_EVALUATED` و `GATE_EVALUATED` در ژورنال.

---

## ۱۲. معیارهای پذیرش
1. هیچ سیگنالی به‌خاطر «محافظه‌کاری» رد نشود؛ فقط Gate A/D، Lot<0.01، Rollover، Margin<300٪، Spread>0.3×SL.
2. هیچ معامله‌ای از ۱.۵٪ (تک) و ۳٪ (پورتفوی) فراتر نرود؛ هیچ سفارشی با Lot<0.01 ارسال نشود.
3. Missed Strong Signals < ۵٪ سیگنال‌های قوی؛ DD ناشی از تراکم ≤ ۱.۵× حالت بدون Gate C.
4. تست A/B قدیم/جدید + گزارش PF، MaxDD، تعداد سیگنال قوی ازدست‌رفته.
5. تست رگرسیون تناقض: مسیر گام‌های ۱..۱۱ با ورودی مصنوعی.
6. هر Downgrade/Bypass در ژورنال قابل ردیابی باشد.

---

## ۱۳. فازبندی
| فاز | محتوا | وضعیت |
|---|---|---|
| ۱ | دو استراتژی، ناحیهٔ خودکار، Tier، Gates A–D، Capital، BE/Trailing | **پیاده‌سازی همین نسخه** |
| ۲ | TP سه‌لایه با partial close، سواپ/کمیسیون ساعتی، فیلتر خبر واقعی | بعدی |
| ۳ | دادهٔ واقعی MT5 + walk-forward + مونت‌کارلو + گیت‌وی | بعدی |

> محدودیت صادقانه: بدون دادهٔ واقعی و بک‌تست walk-forward، اعداد ۲.۵٪/۱.۵٪ / ۸۵ و ۱.۵ «پیش‌فرض مهندسی» هستند، نه نتیجهٔ بهینه‌سازی.

---

## ۱۴. لایه‌های نسخهٔ ۲.۰ (اضافه‌شده به v1.1)

| موضوع | v1.0 | v1.1 / v2.0 |
|---|---|---|
| Gate D | min(2٪, 3٪) ⇒ عدد ۳٪ مرده | soft 2٪ / hard 3٪؛ بین آن‌ها HALF؛ hard پیش‌فرض ۲٪ |
| Gate B بدون Bypass | REJECT | SMALLEST؛ پس از دو بار سوختن ⇒ `Zone_Burn_Trap` |
| Gate C تراکم | REJECT | SMALLEST؛ Hedge روی پوزیشن سودده/سیگنال ضعیف هنوز REJECT |
| Composite | clamp منفی به صفر | bonus ۵۰ + penalty ۳۰؛ Signal=-2 ⇒ کاهش، نه صفر |
| Confluence | فقط فیلتر | فیلتر + Amplifier (×۱.۲۵ تا ×۱.۵) با سقف ۱.۰٪ |
| SMALLEST | نداشت | یک لات حداقل؛ فقط قیدهای ایمنی/فیزیکی رد می‌کنند |
| Confluence نرم | رد سیگنال تک‌تأیید | پیش‌فرض رد؛ با `weak_confluence_mode="smallest"` ⇒ یک لات (ADR-009) |
| Kill switch | فقط peak | peak + کف مطلق ۵۰٪ سرمایهٔ اولیه |
| HMAC | کلید موقت | env اختیاری + fail-closed با `GOLDBOT_REQUIRE_SECRET=1` |
| Tier/Invalidation داینامیک | ثابت | پیاده‌شده ولی **پیش‌فرض خاموش** (بدون شاهد بیرون‌نمونه) |
| Signal Funnel | نبود | مراحل received..executed + `report --funnel` |

### ۱۴.۱ شمارش تأییدها (تعریف صریح)
منابع شمارش‌شده در کد: خود سیگنال، استراتژی‌های دیگر در پنجرهٔ ۳۰ دقیقه، و `sr_zone` (Zone≥۵۰ و فاصله ≤۲×ATR).
«Setup پایدار دو کندلی» و «H4» پیاده نشده‌اند چون شاهد یا دادهٔ H4 در موتور نیست؛ ادعای وجودشان داده نمی‌شود.

### ۱۴.۲ معیار کمیت سیگنال
`executed / received` در tape یکسان: v1.1 = ۶۰.۵٪ (۱۵۶/۲۵۸)، v2.0 = ۶۳.۳٪ (۱۵۹/۲۵۱).
DD: ۴.۴٪ → ۴.۲۳٪؛ حداکثر ریسک هر معامله: ۰.۹۸٪ → ۰.۷۴٪. (random walk؛ فقط معیار کمیت.)

### ۱۴.۳ تناقض‌های ادعایی که رد شدند
- «Gate B تا پایان روز REJECT می‌کند» نادرست بود؛ burn عادی ۲/۵/۳ کندل است و ۹۶ کندل فقط برای ناحیهٔ معیوب.
- «Gate C سه‌پله‌ای است» نادرست بود؛ Bypass/Downgrade/Hedge از قبل وجود داشت.
- «Gate D دو عدد متناقض دارد» در کد `min` بود؛ تناقض لفظی بود، نه دو مسیر اجرایی.
- «Kill switch تعریف‌نشده» نادرست بود؛ از peak تعریف شده بود.
- ×۱.۵ تا سقف ۱.۵٪ با معیار «افزایش ریسک صفر» خود پرامپت متناقض بود؛ سقف ۱.۰٪ حفظ شد.

---

## ۱۵. لایهٔ ایمنی عملیاتی و بودجهٔ سفارش (v3)

| مورد | پیاده‌سازی | تست |
|---|---|---|
| SymbolMeta + حد فاصلهٔ بروکر | `domain/symbol_meta.py`، `check_broker_stops`، validate در startup | `test_symbol_meta_*`, `test_broker_stops_*` |
| جدول Retcode | `domain/retcodes.py` (۲۰ کد، ناشناخته ⇒ QUARANTINE)، ثبت `action` در coordinator | `test_retcode_table_is_fail_closed` |
| زمان بروکر | `broker_now` در RiskContext؛ rollover و روز معاملاتی بروکری؛ سه‌شنبه‌سوآپ | `test_rollover_uses_broker_time_not_utc` |
| TimeService | UTC / broker / Iran (+03:30 ثابت) | `test_time_service_exposes_three_clocks` |
| Reconciliation دوره‌ای | هر ۵ دقیقه قبل از کندل؛ کهنگی snapshot ⇒ رد ورود | `test_reconciliation_check_is_fail_closed` |
| KILLED همیشه flatten | حذف شرط `flatten_on_kill` | `test_flatten_closes_every_position` |
| Order Budget سه‌لایه | `app/order_budget.py`؛ عمومی ۷، رزرو ۳، گسترده A+ HALF، spacing ۱۰ دقیقه، cooldown ۳۰ دقیقه | `tests/test_budget.py` |

### ۱۵.۱ نتیجهٔ ۱۰۰ روزه (tape یکسان، medium، random walk)
| معیار | v2.0 | v3.0 |
|---|---:|---:|
| معاملات | ۱۵۹ | ۱۴۹ |
| نرخ اجرا | ۶۳.۳٪ | ۵۳.۶٪ (کف مجاز ۴۸.۴٪) |
| PF | ۱.۲۵ | ۱.۲۶ |
| MaxDD | ۴.۲۳٪ | ۳.۷۹٪ |
| وضعیت پایانی | SOFT_HALT | NORMAL |
| رد بودجه | — | ۲۶ |

### ۱۵.۲ عمداً اعمال‌نشده / مسدود
- **P1-1 (TP سه‌لایه/PositionFSM):** نیازمند گسترش FSM پوزیشن و partial-close اتمی؛ فعلاً یک تارگت TP2 + BE/Trailing.
- **P0-2 retry loop:** بدون gateway، retry نیازمند بازمحاسبهٔ قیمت و **مهر مجدد ریسک** است؛ فقط جدول طبقه‌بندی پیاده شد.
- **P2-1 CostModel کامل، P2-2 walk-forward/MC:** نیازمند داده و مدل هزینهٔ واقعی؛ اعداد فعلی random walk هستند.
- **P3-1 Parity Harness:** بدون MT5 simulation معنا ندارد.
- **P3-2 Notifier/heartbeat، P3-3 config hash:** باقی‌مانده فاز رصدپذیری.
- **بازیابی وضعیت پس از ری‌استارت:** همچنان P0 باز است (KILLED/daily/peak/ticket_meta/burn پایدار نیستند).

---

## ۱۶. لایهٔ بازیابی، TP سه‌لایه، رصدپذیری و هزینهٔ کامل (v4)

| مورد | پیاده‌سازی | تست |
|---|---|---|
| بازیابی وضعیت ریسک | `ports/state.py` + `adapters/sqlite_state_store.py`؛ write-through روی هر transition؛ cold start در live/paper ⇒ QUARANTINE؛ `goldbot ack/status` | `tests/test_state_recovery.py` (۲۲) |
| burnهای Gate A/B/C | `CooldownManager.snapshot/restore` در فیلد `extras` همان رکورد؛ فقط روی تغییر نوشته می‌شود | `tests/test_gates.py` |
| PositionFSM + TP سه‌لایه | `domain/fsm/position.py` (فازها) + `app/position_fsm.py` (50/30/20، ایدمپوتنت، retry، SL یک‌طرفه) + اجرای partial در coordinator/engine | `tests/test_position_fsm.py` (۲۴) |
| Notifier + heartbeat | `adapters/notifier.py` (dedup/rate-limit، Telegram/SMTP از env) + `app/heartbeat.py` + `scripts/watchdog.py` بیرونی | `tests/test_notifier.py` (۲۴)، `tests/test_heartbeat.py` (۲۷) |
| CostModel کامل | `app/costs.py` (swap سه‌شنبه، slippage خبری، spread) و سایز بر اساس **ضرر مؤثر** در `capital.plan_entry` | `tests/test_costs.py` (۱۵)، `tests/test_capital.py` |
| Journal + config_hash | ۱۰ فیلد هزینه/تأخیر/لغزش + `config_hash` (SHA-256 canonical)؛ migration افزودنی | `tests/test_config_hash.py` (۹) |
| بودجهٔ per-profile | `BudgetParams.for_profile`؛ سقف بودجه هرگز از سقف پروفایل بزرگ‌تر نیست | `tests/test_budget.py` |
| Walk-forward + Monte Carlo | `research/walk_forward.py`، `research/monte_carlo.py`؛ چارچوب خالص با معیار پذیرش | `tests/test_walk_forward.py` (۳۳) |
| Tapeهای parity | `adapters/tape_library.py` + `goldbot tapes`؛ ۶ سناریو قطعی | `tests/test_parity_tapes.py` (۲۱) |
| Retry re-seal (آماده) | `app/retry_guard.py`؛ retry فقط با ارزیابی مجدد و مهر تازه، وگرنه abort | `tests/test_retry_reseal.py` (۸) |
| مالکیت orphan با magic | `GOLDBOT_MAGIC_BASE` + `owns_position_magic`؛ ناشناخته ⇒ هشدار، نه بستن | `tests/test_retry_reseal.py` |
| min_viable_volume | در FSM: `2 × volume_min`؛ زیر آن مسیر تک‌تارگت | `tests/test_position_fsm.py` |

### ۱۶.۱ نتیجهٔ ۱۰۰ روزه (همان tape، medium، random walk)
| معیار | v3.0 | v4.0 |
|---|---:|---:|
| معاملات | ۱۴۹ | ۱۵۲ |
| سود خالص | +۷.۳۰٪ | +۱۱.۶۳٪ |
| PF | ۱.۲۶ | ۱.۴۳ |
| MaxDD | ۳.۷۹٪ | ۳.۰۴٪ |
| وضعیت پایانی | NORMAL | NORMAL |
| نرخ اجرا | ۵۳.۶٪ | ۵۳.۷٪ (received ۲۸۳ / executed ۱۵۲) |
| رد بودجه | ۲۶ | ۳۱ |

هزینهٔ واقعی FakeBroker فقط کمیسیون است؛ swap/slippage در آن شبیه‌سازی نمی‌شوند، پس drift
`actual vs estimated` در synthetic طبیعی است و فقط در live معنا دارد. هیچ ادعای لبه‌ای نیست.

### ۱۶.۲ همچنان باز/مسدود
- **retry loop واقعی و orphan-close خودکار:** نیازمند gateway MT5 و اجرای `retry_guard` + re-seal.
- **Walk-forward با دادهٔ واقعی:** چارچوب آماده است؛ tape فعلی random walk است.
- **پنل وب برای ack/status/heartbeat:** CLI آماده است، UI نه.
- **اکانت/نماد چندگانه:** رکورد state یک کلید دارد؛ برای هر اکانت باید key جدا ساخت.
- **HMAC secret در production:** `GOLDBOT_REQUIRE_SECRET=1` باید در live اجباری شود.




---

## ۱۷. ارتقاء v5: ایمنی آخر هفته/خبر، امتیازدهی ناحیه‌محور، سطح سرمایه و ژورنال سیگنال

این بخش اجرای دو سند مالک (roadmap معماری و spec نهایی سرمایه/ریسک) را ثبت می‌کند.
ملاک: فقط تغییراتی که ریسک واقعی را کم می‌کنند اعمال شدند؛ هر تغییر با ADR و تست.

| مورد | پیاده‌سازی | ADR | تست |
|---|---|---|---|
| بستن اجباری آخر هفته | app/weekend.py + engine (WeekendClosePlan/FlattenCompleted) + override اپراتور | 022 | test_weekend (۳۱) + یکپارچه |
| سیاست خبر high/medium | app/news.py + CSV adapter + conservative fallback + RiskContext | 023 | test_news (۳۵) |
| امتیازدهی ناحیه‌محور، WATCH، A+ ۰.۸۵ | app/decision.py بازنویسی؛ R:R پیوسته و قابل‌تحقق | 024 | test_decision/tier (۲۶) + property |
| سقف ریسک باز پروفایل (رفع ۳٪ مرده) | RiskProfile.max_open_risk_pct + capital.plan_entry | 025 | test_capital/profiles |
| ژورنال سیگنال + ماتریس قابلیت + سشن/DST | domain/events، sqlite_store، level_eval، market_session، xlsx | 026 | ۹۰ تست |
| کنترلر سطح سرمایه + BASE قفل | capital_levels + level_gate + CLI level/approve/decline/onboarding | 027 | ۹۷ تست |
| گارد مشخصات بروکر + netting fail-closed | spec_guard + SymbolInfo(tick_value/filling_mode) + bootstrap | 028 | ۲۷+۱۳+۱۱+۱۳ |
| Override اپراتور + health + runbook | override CLI، check_manual_pause، health.py، /api/health، RUNBOOK | 029 | ۱۵ |
| BASE execution | عمداً مسلح نشده (قفل کامل، بدون ۵٪ خودکار) | 030 | اجرای equity=150 ⇒ base_locked |

### ۱۷.۱ نتیجهٔ ۱۰۰ روزه (همان tape، medium، random walk، seed 7)
| معیار | v4.0 | v5.0 |
|---|---:|---:|
| معاملات | ۱۵۲ | ۱۴۶ |
| سود خالص | +۱۱.۶۳٪ | +۱۴.۲۸٪ |
| PF | ۱.۴۳ | ۱.۵۴ |
| MaxDD | ۳.۰۴٪ | ۲.۳۲٪ |
| وضعیت پایانی | NORMAL | NORMAL |
| سیگنال/قصد | ۳۰۸/۲۲۹ | ۳۲۴/۲۴۱ |
| رد ریسک | ۵۲ | ۶۹ (news_window=۲۰) |

توزیع Tier در ژورنال: B=۱۷۰، A=۶۱، C=۲، noise=۱ (None=A+ در این tape؛ چون Zone_Score غالب
زیر ۸۰ بود). سشن‌ها: overlap 75، ny 56، asia 51، london 37، late_ny 15.
هیچ ادعای لبه‌ای نیست؛ داده random walk است و اعداد مسیر نمونه‌اند.

### ۱۷.۲ انحراف‌های آگاهانه از سند مالک
- **R:R:** فرمول iterative سند در باند کسری غیریکنوا بود (R:R کمتر ⇒ Tier بهتر). الگوریتم
  یک‌مرحله‌ای + انتخاب Tier قابل‌تحقق جایگزین شد؛ نتیجه سخت‌گیرانه‌تر و مونوتون است (ADR-024).
- **BASE ۵٪:** فقط قفل/باند/تست/onboarding پیاده شد؛ مسیر سایز ۵٪ مسلح نشده تا پاکت ۱.۵٪
  بی‌صدا شکسته نشود (ADR-030).
- **۳٪ ریسک باز:** مکانیزم per-profile اضافه شد ولی پیش‌فرض ۲٪؛ ۳٪ نیازمند ویرایش صریح profile.
- **Levels:** پیش‌فرض خاموش؛ روشن‌کردن آن رفتار معاملاتی را عوض می‌کند و باید با شواهد باشد.
- **Amplifier:** A+ از ۱٪ به ۰.۸۵٪ کاهش یافت (تنگ‌تر) تا آمپلیفایر تا سقف ۱٪ اثر واقعی داشته باشد.
- **numeric zone:** ناحیهٔ واقعی نزدیک استفاده می‌شود؛ در نبود ناحیه ۵۰ خنثی و floor=50.

### ۱۷.۳ همچنان باز
- gateway MT5 (read-only + order path)، retry loop با re-seal، orphan-close خودکار.
- اجرای walk-forward/Monte Carlo روی دادهٔ واقعی؛ اعداد فعلی synthetic هستند.
- BASE execution path (ADR-030)، multi-account state key، و پنل زندهٔ override/flatten.
- parity harness زنده، shadow mode ۱۴ روزه و کالیبراسیون swap/slippage از تاریخ بروکر.

---

## ۱۸. ارتقاء v6: طراحی تأییدیه‌محور (قفل‌شده)

این بخش سند نهایی مالک (چهار تصمیم قفل‌شدهٔ A1/B/C/D) را به مشخصات اجرایی تبدیل می‌کند و
همراه همان انتشار با کد می‌آید؛ ملاک پذیرش، سبز شدن تست‌های نام‌برده است، نه عدد عملکردی.
هیچ ادعای سوددهی در این بخش نیست و اعداد ریسک مستقیماً از سند مالک گرفته شده‌اند.

### ۱۸.۰ چهار تصمیم قفل‌شده
| تصمیم | انتخاب |
|---|---|
| A — D سخت یا نرم | A1: D یک کف سخت است؛ لایه ۳ نمی‌تواند آن را به C ارتقا دهد |
| B — تقارن تأیید | متقارن: zones و numeric یکدیگر را تأیید می‌کنند (+۱ هر طرف) |
| C — هم‌زمانی سه‌گانه | پذیرفته: پوزیشن سوم در ترکیب همه-A+ توسط Gate D نصف می‌شود |
| D — sr_zone | از لایه ۲ به لایه ۳: Zone_Score>=۵۰ و فاصله <=۲×ATR ⇒ +۰.۲ |

### ۱۸.۱ چهار لایه
| لایه | نقش | ورودی | قاعده |
|---|---|---|---|
| ۰ | فیلتر ناحیه | Zone_Score | >=۵۰ مجاز؛ کمتر ⇒ Tier D با reason=zone_filter (ثبت، بدون معامله) |
| ۱ | سیگنال استراتژی | zones یا numeric | RawSignal BUY/SELL؛ خود سیگنال در شمارش تأییدیه نیست |
| ۲ | تأییدیه (۰..۶) | پنج فاکتور مستقل + تأیید استراتژی دیگر (+۱) | جمع پیوسته ⇒ Tier پایه از باند ۱۸.۲ |
| ۳ | تقویت/تضعیف | شش رأی پایه + sr_zone | هر رأی ±۰.۲؛ جمع clamp به ±۱.۲؛ آستانه ±۰.۶ ⇒ ±۱ سطح |

### ۱۸.۲ باند Tier پایه (لایه ۲)
| بازهٔ تأییدیه | Tier پایه |
|---|---|
| [۰,۱) | D (کف سخت؛ ثبت بدون معامله) |
| [۱,۲) | C |
| [۲,۳) | B |
| [۳,۴) | A |
| [۴,۶] | A+ |

Tier نهایی = Tier پایه + delta لایه ۳، با سقف A+ و کف C. D هرگز ارتقا نمی‌یابد و لایه ۳
روی D اثر ندارد؛ پس Tier نهایی همیشه یکی از {پایه−۱، پایه، پایه+۱} است، مگر D که D می‌ماند.

### ۱۸.۳ ماتریس ریسک (پایه × پروفایل)
| Tier | Base | Low | Medium | High |
|---|---:|---:|---:|---:|
| D | — | ❌ | ❌ | ❌ |
| C | ۰.۲۵٪ | ❌ | ۰.۲۵٪ | ۰.۲۵٪ |
| B | ۰.۵٪ | ❌ | ۰.۵٪ | ۰.۵٪ |
| A | ۰.۷۵٪ | ۰.۵٪ | ۰.۷۵٪ | ۰.۷۵٪ |
| A+ | ۱.۰٪ | ۰.۷۵٪ | ۱.۰٪ | ۱.۰٪ |

ریسک پایهٔ هر Tier ابتدا با tier_risk_caps پروفایل و سپس با profile_cap_pct و Gate D
سخت‌تر می‌شود؛ Low فقط A+ و A را مجاز می‌کند و بقیه با reason=tier_not_allowed و حجم صفر
رد می‌شوند (ADR-036/037).

### ۱۸.۴ تعریف دقیق پنج فاکتور لایه ۲
| فاکتور | +۱ | +۰.۵ | ۰ |
|---|---|---|---|
| FVG/OB | FVG/OB هم‌پوشان با ناحیه و اندازه >= ۰.۵×ATR(14) | فاصله <= ۰.۵×ATR از ناحیه | نبود یا کوچک‌تر |
| MaxLines (Murrey) | قیمت روی خط بازگشتی +2/8 برای sell و −2/8 برای buy | فاصله <= ۰.۲۵×ATR از خط بازگشتی | میانهٔ محدوده |
| EMA50 M15 | قیمت در جهت سیگنال + شیب EMA در سه کندل هم‌جهت | قیمت در جهت سیگنال + شیب خنثی | قیمت روی EMA یا خلاف جهت |
| RSI(14) | دایورجنس هم‌جهت یا بازگشت از ۳۰/۷۰ | RSI>۵۰ برای buy یا RSI<۵۰ برای sell | نزدیک ۵۰ یا خلاف جهت |
| Bollinger(20,2) | بازگشت از باند مخالف + انبساط هم‌جهت | قیمت در نیمهٔ درست باند | میانه یا نیمهٔ مخالف |

جمع این پنج فاکتور به‌علاوهٔ تأیید استراتژی دیگر (+۱) عدد confirmation_count در [۰,۶] است
و مستقیماً Tier پایه را می‌سازد (ADR-033). هیچ وزن قابل‌تنظیمی برای فاکتورها وجود ندارد.

### ۱۸.۵ رأی‌های لایه ۳
| رأی | شرط |
|---|---|
| حجم نسبی | >=۱.۲ ⇒ رأی +۱ (در بازهٔ −۱..+۱) |
| Pin/Engulfing | الگوی کندلی هم‌جهت ⇒ +۱ |
| EMA200 H1 | قیمت هم‌جهت با EMA200 ⇒ +۱ |
| ADX | روند هم‌جهت ⇒ +۱ |
| سشن | لندن/نیویورک/آسیا هم‌جهت ⇒ +۱ |
| نوع سطح روزانه | سطح روزانهٔ هم‌جهت ⇒ +۱ |
| sr_zone | Zone_Score>=۵۰ و فاصله <=۲×ATR ⇒ +۱ |

هر رأی ضربدر ۰.۲ می‌شود؛ جمع در [−۱.۲,+۱.۲] clamp می‌شود؛ جمع >=+۰.۶ یعنی +۱ سطح (سقف
A+)، جمع <=−۰.۶ یعنی −۱ سطح (کف C) و برای Tier پایهٔ D بی‌اثر است (ADR-035/034). رأی‌ها را
engine و strategy تزریق می‌کنند؛ app/confirmations.py فقط محاسبهٔ خالص دارد.

### ۱۸.۶ هم‌زمانی، Gate D و انحراف این انتشار
| پروفایل | سقف هم‌زمانی این انتشار | جدول مالک | سقف ریسک باز این انتشار | جدول مالک |
|---|---:|---:|---:|---:|
| Low | ۱ | ۲ | ۱.۵٪ | ۱.۵٪ |
| Medium | ۲ | ۳ | ۳.۰٪ | ۳.۰٪ |
| High | ۲ | ۳ | ۳.۰٪ | ۳.۰٪ |

max_daily_loss_pct بدون تغییر می‌ماند: ۱/۲/۴. تصمیم C (نصف‌شدن پوزیشن سوم) با دو پوزیشن
A+ در Medium/High از خط soft عبور می‌کند و Gate D آن را HALF می‌کند؛ ولی چون سقف هم‌زمانی
این انتشار ۲ است این مسیر در عمل trigger نمی‌شود. شل‌کردن هم‌زمانی بی‌صدا ممنوع است و
نیازمند شواهد و ADR جداست (ADR-037).

### ۱۸.۷ فیلدهای ژورنال هر سیگنال
| فیلد | معنا |
|---|---|
| tier | Tier نهایی؛ D هم با برچسب D ثبت می‌شود، نه noise |
| tier_base | Tier پایه از باند ۱۸.۲ |
| confirmation_count | جمع لایه ۲ در [۰,۶] |
| confirmation_set | نام تأییدیه‌های فعال |
| layer3_score | جمع clamp‌شدهٔ لایه ۳ |
| d_hard_floor | آیا Tier از کف سخت D آمده است |
| reasons | zone_filter، rr_absolute_floor، d_hard_floor، tier_layer3_up، tier_layer3_down |

فیلدهای موجود ژورنال مانند session، خبر و منبع ناحیه بدون تغییر می‌مانند.

### ۱۸.۸ ناورداهای property
- confirmation_count == ۰ ⇒ tier_base == D
- confirmation_count >= ۴ ⇒ tier_base == A+
- Tier نهایی ∈ {tier_base−۱، tier_base، tier_base+۱} به‌جز D
- tier_base == D ⇒ Tier نهایی == D
- با افزایش confirmation_count، Tier پایه هرگز کاهش نمی‌یابد (مونوتونی)
- هیچ سیگنالی با Tier D به Gate یا Capital نمی‌رسد؛ فقط ژورنال می‌شود

### ۱۸.۹ انحراف‌های آگاهانه از سند مالک
| مورد | انحراف | ADR |
|---|---|---|
| سقف هم‌زمانی | Medium/High روی ۲ (سند: ۳) و Low روی ۱ (سند: ۲) | 037 |
| ریسک High | envelope ۱.۵٪ می‌ماند ولی A+ مؤثر ۱.۰٪ است | 036 |
| R:R | جریمهٔ Tier و آمپلیفایر حذف؛ فقط rr_net>=۱.۰ و min_rr پروفایل | 034 |
| ژورنال D | با برچسب D ثبت می‌شود، نه noise | 034 |
| RSI | دایورجنس نسخهٔ ساده و مستند | 033 |

### ۱۸.۱۰ ADRهای مرتبط
| ADR | موضوع |
|---|---|
| 031 | حذف معافیت zones از تأییدیه‌ها |
| 032 | انتقال Zone_Score از Composite به فیلتر لایه ۰ |
| 033 | پنج فاکتور مستقل و رأی‌های لایه ۳ |
| 034 | Tier D به‌عنوان کف سخت A1، ژورنال D و حذف دوباره‌شماری |
| 035 | انتقال sr_zone از لایه ۲ به لایه ۳ |
| 036 | A+ پایه ۱.۰٪، ماتریس Low، Gate D و نصف‌شدن پوزیشن سوم |
| 037 | پروفایل Low دو-سطحی و انحراف سقف هم‌زمانی |

### ۱۸.۱۱ پذیرش و پیاده‌سازی
پیاده‌سازی همراه همین انتشار می‌آید: app/decision.py (Tier و باندها)،
app/confirmations.py (پنج فاکتور و لایه ۳)، app/risk/profiles.py و app/risk/capital.py
(ماتریس ریسک و Gate D)، config/risk_profiles.toml، engine و ژورنال. پذیرش با سبز شدن
tests/test_decision.py، tests/test_tier_system.py، tests/test_tier_confirmation.py،
tests/test_confirmations_new.py، tests/test_profiles.py و tests/test_capital.py است.
پس از کد، توزیع Tier در ۱۰۰ روز random walk دیده می‌شود و هر تصمیم دربارهٔ آستانه‌ها یا
هم‌زمانی بعد از دادهٔ واقعی walk-forward گرفته می‌شود؛ تا آن زمان این بخش فقط plumbing را
توصیف می‌کند، نه سوددهی را.


---

## ۱۹. نتیجهٔ اجرای v6 (random walk) و کشف محیط واقعی

### ۱۹.۱ اجرای ۱۰۰ روزه (medium، tape seed 7)
| معیار | v5 (composite) | v6 (confirmation) |
|---|---:|---:|
| معاملات | ۱۴۶ | ۱۴۶ |
| سود خالص | +۱۴.۲۸٪ | +۱۸.۵۷٪ |
| PF | ۱.۵۴ | ۱.۴۹ |
| MaxDD | ۲.۳۲٪ | ۳.۳۵٪ |
| وضعیت پایانی | NORMAL | NORMAL |
| سیگنال ژورنال | ۲۳۴ | ۲۷۹ |

توزیع Tier سیگنال‌ها: A+ ۱۲۶ (۴۵.۲٪)، D ۶۱ (۲۱.۹٪)، A ۴۹، B ۳۱، C ۱۲.
همهٔ Dها از type=zone_filter هستند (۶۱ سیگنال؛ ناحیهٔ لایه ۰ ندارند).
توزیع اجراشده: A+ ۸۰، A ۳۳، B ۲۲، C ۱۱.
شمارش تأییدیه: ۴.۰ (۹۹)، ۳.۵ (۵۱)، ۲.۰ (۴۴)، ۳.۰ (۳۲)، ۱.۰ (۱۹)، بقیه ۲۵.
لایه ۳ در ۱۱۵ سیگنال +۱ شد و در هیچ سیگنال −۱ نشد.

**Counterfactual لایه ۳ خاموش:** ۱۴۸ معامله، +۱۳.۳۷٪، PF 1.37، MaxDD 3.85٪، A+ ۹۷.
یعنی لایه ۳ در این مسیر نمونه بهتر بود، ولی چون random walk است حکم لبه ندارد.

**ناهم‌خوانی با هدف طراحی:** target سند «D بیش از ۳۰٪ و A+ کمتر از ۵٪» بود؛ اجرای فعلی
D=۲۱.۹٪ و A+=۴۵.۲٪ داد. علت ساختاری: فاکتورهای پنج‌گانه در روند همبسته‌اند (FVG+EMA50+RSI+BB
همه با هم ۰.۵/۱ می‌گیرند) و «استراتژی دیگر» هم +۱ می‌دهد؛ در نتیجه ۴ تأییدیه شایع است.
این یک **یافتهٔ کالیبراسیون** است، نه باگ: طبق تصمیم سند، تغییر آستانه‌ها/وزن‌ها باید بعد از
دیدن توزیع و با شواهد walk-forward باشد. هیچ تغییر خاموشی اعمال نشد؛ گزینه‌های پیشنهادی:
(الف) A+ را به ≥۴.۵ یا ≥۵ تأییدیه ببریم، (ب) فاکتورهای همبسته را وزن‌دهی کنیم،
(ج) +۱ استراتژی دیگر را فقط برای Tier B/C نگه داریم. تصمیم با مالک.

Counterfactual «D با ریسک ۰.۱٪» اجرا نشد چون مسیر اجرای D عمداً وجود ندارد (D فقط ثبت می‌شود)؛
برای این کار باید یک simulate-only mode جدا اضافه شود، نه یک شل‌کننده در مسیر زنده.

### ۱۹.۲ کشف محیط واقعی (ePlanet MT5)
- سرور: ePlanet-MT5؛ حساب دمو <MT5_LOGIN> با هجینگ، AutoTrading خاموش؛ اتصال با
  MetaTrader5 5.0.6231 به build 6238 تأیید شد (path باید به terminal64.exe باشد، نه پوشه).
- نماد واقعی: XAUUSD.st (بدون پسوند پیدا نمی‌شود)؛ contract 100، tick_value 1.0، tick_size 0.01،
  min/step 0.01، max 10، filling_mode=IOC (FOK رد می‌شود)، stops/freeze=0،
  swap_long=-67.408، swap_short=+12.872، triple Wednesday.
- gateway GoldBot باید این موارد را از SymbolInfo/AccountInfo بخواند؛ هشدار spec_guard برای
  filling_mode/currency و سقف حجم اعمال می‌شود. هیچ سفارشی ارسال نشد.
- پنل وب روی VPS (Ubuntu 24.04) با توکن Bearer/Basic و systemd مستقر شد؛ جزئیات در
  docs/DEPLOY-VPS.md. پنل فعلاً فقط همان VPS را می‌خواند و به موتور معاملاتی ویندوز وصل نیست؛
  MT5 روی Linux اجرا نمی‌شود، پس مسیر واقعی معامله باید روی ویندوز بماند یا gateway جدا شود.

**محدودیت:** همهٔ اعداد ۱۹.۱ روی random walk هستند؛ هیچ ادعای سوددهی نیست. تصمیم نهایی فقط
با دادهٔ واقعی MT5 و walk-forward معنا دارد.
