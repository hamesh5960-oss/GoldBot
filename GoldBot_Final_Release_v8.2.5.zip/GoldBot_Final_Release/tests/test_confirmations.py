"""Confirmation helpers: RSI, relative volume, pin bar and engulfing."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone

from goldbot.domain.model import Bar
from goldbot.strategy_api import indicators

START = datetime(2024, 3, 4, tzinfo=timezone.utc)


def bar(i: int, o: float, h: float, l: float, c: float, volume: int = 10) -> Bar:
    return Bar(
        symbol="XAUUSD",  # type: ignore[arg-type]
        timeframe="M15",  # type: ignore[arg-type]
        open_time=START + timedelta(minutes=15 * i),
        o=o,
        h=h,
        l=l,
        c=c,
        tick_volume=volume,
    )


def test_rsi_extremes() -> None:
    assert indicators.rsi([float(i) for i in range(1, 40)]) == 100.0
    assert indicators.rsi([float(i) for i in range(40, 1, -1)]) == 0.0
    assert indicators.rsi([100.0] * 30) == 50.0


def test_relative_volume() -> None:
    bars = [bar(i, 100, 101, 99, 100, volume=10) for i in range(21)]
    assert indicators.volume_ratio(bars) == 1.0
    bars.append(bar(21, 100, 101, 99, 100, volume=30))
    assert indicators.volume_ratio(bars) == 3.0


def test_pin_bar_detects_rejection() -> None:
    hammer = bar(0, 100.0, 100.6, 98.0, 100.4)
    assert indicators.is_pin_bar(hammer, "buy") is True
    assert indicators.is_pin_bar(hammer, "sell") is False


def test_engulfing_requires_opposite_previous_body() -> None:
    previous = bar(0, 101.0, 101.2, 99.8, 100.0)
    trigger = bar(1, 99.9, 101.4, 99.8, 101.2)
    assert indicators.is_engulfing(previous, trigger, "buy") is True
    assert indicators.is_engulfing(previous, trigger, "sell") is False
