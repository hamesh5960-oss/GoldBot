"""Capital pipeline: eleven steps, clamps, portfolio budget and hard blocks."""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

import pytest

from goldbot.app.decision import Tier
from goldbot.app.risk import load_profiles
from goldbot.app.risk.capital import (
    CapitalParams,
    drawdown_factor,
    expected_nights_for,
    plan_entry,
    volatility_factor,
)

from helpers import make_info

LONDON = datetime(2024, 3, 4, 10, 0, tzinfo=timezone.utc)
MIDNIGHT = datetime(2024, 3, 5, 0, 0, tzinfo=timezone.utc)
CONFIG = Path(__file__).resolve().parents[1] / "config"
PROFILES = load_profiles(CONFIG / "risk_profiles.toml")


def plan(**overrides):
    values = dict(
        tier=Tier.A,
        risk_multiplier=1.0,
        equity=10_000.0,
        stop_distance=10.2,
        info=make_info(),
        commission_per_lot=7.0,
        open_risk_pct=0.0,
        profile_cap_pct=1.0,
        drawdown_pct=0.0,
        atr_percentile=None,
        session="london",
        news_blackout=False,
        now=LONDON,
        params=CapitalParams(),
    )
    values.update(overrides)
    return plan_entry(**values)


def plan_with_profile(name: str, tier: Tier | None, **overrides):
    """Plan against a real profile: envelope + tier caps + allowed tiers."""
    profile = PROFILES[name]
    values = dict(
        tier=tier,
        risk_multiplier=1.0,
        equity=10_000.0,
        stop_distance=10.2,
        info=make_info(),
        commission_per_lot=7.0,
        open_risk_pct=0.0,
        profile_cap_pct=profile.risk_per_trade_pct,
        drawdown_pct=0.0,
        atr_percentile=None,
        session="london",
        news_blackout=False,
        now=LONDON,
        params=CapitalParams(),
        tier_risk_caps=profile.tier_risk_caps,
        allowed_tiers=profile.allowed_tiers,
    )
    values.update(overrides)
    return plan_entry(**values)


def test_tier_risk_and_commission_are_in_the_lot() -> None:
    result = plan()
    # 0.75% of 10k = 75 USD; (10.2*100 + 7) = 1027 per lot -> floor(0.073) = 0.07
    assert result.volume == pytest.approx(0.07)
    assert result.risk_pct <= 0.75 + 1e-9
    assert result.reason == ""


# -- full cost model (swap, slippage, spread) -----------------------------

def test_zero_cost_model_matches_commission_only_estimate() -> None:
    from goldbot.app.costs import CostParams

    zero = CostParams(
        commission_per_lot_rt=7.0,
        default_spread_points=0.0,
        slippage_points=0.0,
        news_slippage_points=0.0,
        swap_long_per_lot_night=0.0,
        swap_short_per_lot_night=0.0,
    )
    baseline = plan()
    with_costs = plan(costs=zero, expected_nights=0)
    assert with_costs.loss_per_lot == pytest.approx(baseline.loss_per_lot)
    assert with_costs.volume == baseline.volume


def test_full_costs_cannot_increase_size() -> None:
    from goldbot.app.costs import CostParams

    costs = CostParams(
        commission_per_lot_rt=7.0,
        slippage_points=20.0,
        news_slippage_points=20.0,
        default_spread_points=0.0,
        swap_long_per_lot_night=12.0,
        swap_short_per_lot_night=2.0,
    )
    baseline = plan()
    loaded = plan(costs=costs, expected_nights=1)
    assert loaded.loss_per_lot > baseline.loss_per_lot
    # Sizing is more conservative in lots even when the floor step keeps the
    # lot count equal: each lot now carries the transaction costs too.
    assert loaded.volume <= baseline.volume
    assert loaded.risk_pct <= 0.75 + 1e-9


def test_drawdown_and_volatility_multipliers() -> None:
    assert drawdown_factor(4.9) == 1.0
    assert drawdown_factor(7.0) == 0.75
    assert drawdown_factor(12.0) == 0.5
    assert drawdown_factor(20.0) == 0.25
    assert volatility_factor(90.0, CapitalParams()) == 0.75
    assert volatility_factor(99.0, CapitalParams()) == 0.5
    assert plan(drawdown_pct=7.0).intended_pct == pytest.approx(0.5625)


def test_rollover_is_a_hard_block() -> None:
    result = plan(now=MIDNIGHT)
    assert result.volume == 0.0
    assert result.reason == "rollover_block"


def test_asia_and_news_soft_multipliers() -> None:
    asia = plan(session="asia")
    news = plan(news_blackout=True)
    normal = plan()
    assert asia.intended_pct == pytest.approx(0.75 * 0.75)
    assert news.intended_pct == pytest.approx(0.75 * 0.5)
    assert normal.intended_pct == pytest.approx(0.75)


def test_floor_and_ceiling_clamps() -> None:
    # A tiny tier after all multipliers is lifted to the 0.10% floor.
    floored = plan(tier=Tier.C, risk_multiplier=0.5, drawdown_pct=12.0)
    assert floored.intended_pct == pytest.approx(0.10)
    # A+ base is 1.0% (ADR-036) and the per-trade cap is 1.0%, so a generous
    # profile can never lift it above the ceiling.
    capped = plan(tier=Tier.A_PLUS, profile_cap_pct=3.0)
    assert capped.intended_pct == pytest.approx(1.0)
    assert capped.risk_pct <= 1.5


def test_gate_d_remaining_budget_shrinks_the_trade() -> None:
    result = plan(open_risk_pct=1.8)
    assert result.risk_pct <= 0.20 + 1e-9
    assert result.volume <= 0.02 + 1e-9
    full = plan(open_risk_pct=2.0)
    assert full.volume == 0.0
    assert full.reason == "gate_d_total_risk"


def test_minimum_lot_is_a_physical_skip() -> None:
    result = plan(equity=100.0, stop_distance=10.0)
    assert result.volume == 0.0
    assert result.reason == "below_min_lot"


def test_effective_risk_never_exceeds_the_ceiling() -> None:
    for tier in (Tier.A_PLUS, Tier.A, Tier.B, Tier.C):
        for dd in (0.0, 6.0, 12.0, 20.0):
            result = plan(tier=tier, drawdown_pct=dd, profile_cap_pct=1.5)
            assert result.risk_pct <= 1.5 + 1e-9


# -- locked tier matrix (ADR-036) -----------------------------------------

@pytest.mark.parametrize(
    ("tier", "expected"),
    [
        (Tier.A_PLUS, 0.75),
        (Tier.A, 0.50),
    ],
)
def test_low_profile_effective_tier_caps(tier: Tier, expected: float) -> None:
    result = plan_with_profile("low", tier)
    assert result.intended_pct == pytest.approx(expected)
    assert result.reason == ""
    assert result.volume > 0


@pytest.mark.parametrize("tier", [Tier.B, Tier.C, Tier.D])
def test_low_profile_rejects_disallowed_tiers(tier: Tier) -> None:
    result = plan_with_profile("low", tier)
    assert result.volume == 0.0
    assert result.risk_pct == 0.0
    assert result.reason == "tier_not_allowed"


@pytest.mark.parametrize(
    ("tier", "expected"),
    [
        (Tier.A_PLUS, 1.0),
        (Tier.A, 0.75),
        (Tier.B, 0.50),
        (Tier.C, 0.25),
    ],
)
def test_medium_and_high_profiles_share_the_tier_matrix(tier: Tier, expected: float) -> None:
    for name in ("medium", "high"):
        result = plan_with_profile(name, tier)
        assert result.intended_pct == pytest.approx(expected)
        assert result.reason == ""


def test_high_profile_a_plus_no_longer_uses_the_1_5_envelope() -> None:
    profile = PROFILES["high"]
    assert profile.risk_per_trade_pct == 1.5
    result = plan_with_profile("high", Tier.A_PLUS)
    assert result.intended_pct == pytest.approx(1.0)
    assert result.intended_pct != pytest.approx(1.5)


def test_medium_profile_rejects_d_tier() -> None:
    result = plan_with_profile("medium", Tier.D)
    assert result.volume == 0.0
    assert result.reason == "tier_not_allowed"


def test_baseline_risk_never_exceeds_the_tier_cap() -> None:
    # At baseline (multiplier 1.0, no gates) the effective base is exactly the
    # smaller of the tier cap and the profile envelope, clamped by the pipeline.
    for name in ("low", "medium", "high"):
        profile = PROFILES[name]
        for tier in (Tier.A_PLUS, Tier.A, Tier.B, Tier.C):
            if tier.value not in profile.allowed_tiers:
                continue
            tier_cap = profile.tier_risk_caps.get(tier.value, profile.risk_per_trade_pct)
            base_cap = min(tier_cap, profile.risk_per_trade_pct)
            expected = max(0.10, min(base_cap, 1.0))
            result = plan_with_profile(name, tier)
            assert result.intended_pct == pytest.approx(expected)
            assert result.risk_pct <= base_cap + 1e-9


def test_amplified_risk_stays_inside_the_global_envelope() -> None:
    # The confluence amplifier may lift a tier above its base (ADR-004), but the
    # global 1.0% trade cap and the 1.5% risk ceiling always hold.
    for name in ("low", "medium", "high"):
        profile = PROFILES[name]
        for tier in (Tier.A_PLUS, Tier.A, Tier.B, Tier.C):
            if tier.value not in profile.allowed_tiers:
                continue
            for dd in (0.0, 6.0, 12.0, 20.0):
                for multiplier in (0.5, 1.0, 1.5):
                    result = plan_with_profile(
                        name, tier, drawdown_pct=dd, risk_multiplier=multiplier
                    )
                    assert result.intended_pct <= 1.0 + 1e-9
                    assert result.risk_pct <= 1.0 + 1e-9
                    assert result.risk_pct <= 1.5 + 1e-9


def test_tier_cap_is_a_ceiling_not_a_target() -> None:
    result = plan_with_profile("low", Tier.A_PLUS, risk_multiplier=0.5)
    assert result.intended_pct == pytest.approx(0.375)


def test_tier_cap_cannot_lift_above_the_profile_envelope() -> None:
    result = plan(tier=Tier.A, profile_cap_pct=0.5, tier_risk_caps={"A": 1.5})
    assert result.intended_pct == pytest.approx(0.5)


def test_missing_tier_cap_falls_back_to_the_profile_envelope() -> None:
    # The tier base still applies: B is 0.50 even when only A+ has a cap.
    result = plan(tier=Tier.B, profile_cap_pct=1.0, tier_risk_caps={"A+": 1.0})
    assert result.intended_pct == pytest.approx(0.5)


def test_zero_risk_tiers_never_size() -> None:
    for tier in (Tier.D, Tier.NOISE):
        result = plan(tier=tier)
        assert result.volume == 0.0
        assert result.risk_pct == 0.0
        assert result.reason == "tier_no_risk"


def test_no_matrix_arguments_keeps_legacy_tier_behaviour() -> None:
    # None means "legacy": every tier allowed, no per-tier cap.
    assert plan(tier=Tier.B, allowed_tiers=None).intended_pct == pytest.approx(0.5)
    assert plan(tier=Tier.C, allowed_tiers=None).intended_pct == pytest.approx(0.25)
    assert plan(tier=Tier.C, allowed_tiers=()).volume == 0.0


def test_gate_d_halves_the_third_position_at_the_soft_line() -> None:
    # ADR-036 acceptance: two A+ positions are 2.0% open risk. With Gate D
    # soft=2 / hard=3 (operator raises hard from the 2.0 default), the third
    # A+ trade crosses the soft line and is HALVED to 0.5%, never rejected.
    gate_d = CapitalParams(gate_d_max_risk_pct=2.0, gate_d_hard_pct=3.0)
    second = plan_with_profile("medium", Tier.A_PLUS, open_risk_pct=1.0, params=gate_d)
    third = plan_with_profile("medium", Tier.A_PLUS, open_risk_pct=2.0, params=gate_d)
    assert second.intended_pct == pytest.approx(1.0)
    assert 0.9 < second.risk_pct <= 1.0
    assert third.intended_pct == pytest.approx(1.0)
    assert third.volume > 0.0
    assert third.risk_pct <= 0.5 + 1e-9
    assert third.risk_pct < second.risk_pct


# -- CL-05: multi-day holding horizon and swap under-count ----------------

def test_expected_nights_follow_the_profile_holding_horizon() -> None:
    assert expected_nights_for(24.0) == 1
    assert expected_nights_for(25.0) == 2
    assert expected_nights_for(36.0) == 2
    assert expected_nights_for(48.0) == 2
    assert expected_nights_for(72.0) == 3
    assert expected_nights_for(None) == 1
    assert expected_nights_for(0.0) == 1


def _swap_costs():
    from goldbot.app.costs import CostParams

    return CostParams(
        commission_per_lot_rt=7.0,
        default_spread_points=0.0,
        slippage_points=0.0,
        news_slippage_points=0.0,
        swap_long_per_lot_night=12.0,
        swap_short_per_lot_night=2.0,
    )


def test_multi_day_holding_horizon_cannot_undercount_swap() -> None:
    costs = _swap_costs()
    one_night = plan(costs=costs, max_holding_hours=24.0)
    two_nights = plan(costs=costs, max_holding_hours=36.0)
    three_nights = plan(costs=costs, max_holding_hours=72.0)
    # Monday broker day: 1 night = 1 charge; 3 nights = Mon+Tue+Wed(triple) = 5.
    assert one_night.loss_per_lot == pytest.approx(10.2 * 100 + 7.0 + 12.0)
    assert two_nights.loss_per_lot == pytest.approx(10.2 * 100 + 7.0 + 2 * 12.0)
    assert three_nights.loss_per_lot == pytest.approx(10.2 * 100 + 7.0 + 5 * 12.0)
    assert three_nights.loss_per_lot > two_nights.loss_per_lot > one_night.loss_per_lot
    assert three_nights.volume <= one_night.volume
    assert three_nights.intended_pct == pytest.approx(one_night.intended_pct)


def test_explicit_expected_nights_wins_over_the_horizon() -> None:
    costs = _swap_costs()
    no_swap = plan(costs=costs, expected_nights=0, max_holding_hours=72.0)
    assert no_swap.loss_per_lot == pytest.approx(10.2 * 100 + 7.0)


def test_gate_d_code_defaults_stay_fail_safe() -> None:
    import tomllib

    assert CapitalParams().gate_d_max_risk_pct == 2.0
    assert CapitalParams().gate_d_hard_pct == 2.0
    raw = tomllib.loads((CONFIG / "base.toml").read_text(encoding="utf-8"))
    # ADR-036's 3.0% comes from explicit config, never from the code default.
    assert raw["capital"]["gate_d_hard_pct"] == 3.0
    assert PROFILES["medium"].max_open_risk_pct == 3.0
    assert PROFILES["high"].max_open_risk_pct == 3.0
