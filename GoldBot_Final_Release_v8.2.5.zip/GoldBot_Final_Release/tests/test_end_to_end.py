"""End-to-end invariants: the limits must hold on a real (synthetic) tape."""

from __future__ import annotations

import os
import shutil
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

import pytest

from goldbot.adapters.config import load_settings
from goldbot.adapters.tape import write_synthetic_tape
from goldbot.runtime.bootstrap import build_components

from helpers import CONFIG, ROOT


def _work(name: str) -> Path:
    path = ROOT / "var" / "tests" / name
    if path.exists():
        shutil.rmtree(path, ignore_errors=True)
    path.mkdir(parents=True, exist_ok=True)
    return path


@pytest.fixture(scope="module")
def run():
    """Run the full stack once on a 3-day synthetic tape and hand back artefacts."""
    previous = os.getcwd()
    os.chdir(ROOT)  # config paths are relative to the project root
    tmp = _work("e2e")
    tape = tmp / "tape.jsonl"
    write_synthetic_tape(
        tape,
        symbol="XAUUSD",
        start=datetime(2024, 3, 3, tzinfo=timezone.utc),
        days=3,
        ticks_per_minute=2,
        seed=5,
    )
    settings = load_settings(CONFIG / "base.toml")
    # These tests exercise the execution mechanics; the confluence filter has
    # its own dedicated test below.
    settings = settings.model_copy(
        update={"trading": settings.trading.model_copy(update={"min_confirmations": 1})}
    )
    components = build_components(
        settings, tape_path=tape, profile_name="medium", db_path=tmp / "journal.db"
    )
    result = components.engine.run()
    events = list(components.journal.read_events(limit=100_000))
    trades = components.journal.trades()
    stats = components.journal.stats()
    profile = components.profile
    components.close()
    os.chdir(previous)
    return result, events, trades, stats, profile


def test_run_produces_activity(run) -> None:
    result, _, trades, _, _ = run
    assert result.ticks > 1000
    assert result.bars > 100
    assert result.signals > 0
    assert result.approved > 0
    assert trades, "expected at least one completed trade"


def test_every_trade_has_a_stop_loss(run) -> None:
    _, _, trades, _, _ = run
    for trade in trades:
        assert trade.sl is not None, f"trade {trade.trade_id} opened without a stop"
        assert trade.volume >= 0.01


def test_concurrency_never_exceeds_profile_limit(run) -> None:
    _, events, _, _, profile = run
    open_count = 0
    peak = 0
    for event in events:
        if event.type == "PositionOpened":
            open_count += 1
            peak = max(peak, open_count)
        elif event.type == "PositionClosed":
            open_count = max(0, open_count - 1)
    assert peak <= profile.max_positions


def test_orders_per_day_respect_limit(run) -> None:
    _, events, _, _, profile = run
    per_day: Counter[str] = Counter()
    for event in events:
        if event.type == "OrderIntentApproved":
            per_day[event.ts.wall.date().isoformat()] += 1
    assert per_day, "expected approved orders"
    for day, count in per_day.items():
        assert count <= profile.max_orders_per_day, f"{day}: {count} orders > limit"


def test_no_approved_order_without_risk_evaluation(run) -> None:
    _, events, _, _, _ = run
    approved = {e.payload.get("intent_id") for e in events if e.type == "OrderIntentApproved"}
    evaluated = {e.payload.get("intent_id") for e in events if e.type == "RiskEvaluated"}
    assert approved <= evaluated


def test_every_approved_order_was_submitted(run) -> None:
    _, events, _, _, _ = run
    approved = {e.payload.get("intent_id") for e in events if e.type == "OrderIntentApproved"}
    submitted = {e.payload.get("intent_id") for e in events if e.type == "OrderSubmitted"}
    assert approved <= submitted


def test_journal_projection_matches_trades(run) -> None:
    _, _, trades, stats, _ = run
    closed = [t for t in trades if t.close_time]
    if not closed:
        pytest.skip("no closed trades")
    assert stats["net"] == pytest.approx(sum(t.pnl_net for t in closed), abs=0.02)
    assert stats["trades"] == len(closed)


def test_deterministic_replay() -> None:
    previous = os.getcwd()
    os.chdir(ROOT)
    try:
        work = _work("determinism")
        tape = work / "tape.jsonl"
        write_synthetic_tape(
            tape,
            symbol="XAUUSD",
            start=datetime(2024, 3, 3, tzinfo=timezone.utc),
            days=2,
            ticks_per_minute=2,
            seed=9,
        )
        settings = load_settings(CONFIG / "base.toml")
        settings = settings.model_copy(
            update={"trading": settings.trading.model_copy(update={"min_confirmations": 1})}
        )
        results = []
        for i in range(2):
            comp = build_components(
                settings, tape_path=tape, profile_name="low", db_path=work / f"j{i}.db"
            )
            result = comp.engine.run()
            stats = comp.journal.stats()
            comp.close()
            results.append((result.trades_closed, round(stats["net"], 2)))
        assert results[0] == results[1]
    finally:
        os.chdir(previous)


def test_weak_confluence_only_allows_minimum_lot() -> None:
    previous = os.getcwd()
    os.chdir(ROOT)
    try:
        work = ROOT / "var" / "tests" / "confluence"
        if work.exists():
            shutil.rmtree(work, ignore_errors=True)
        work.mkdir(parents=True, exist_ok=True)
        tape = work / "tape.jsonl"
        write_synthetic_tape(
            tape,
            symbol="XAUUSD",
            start=datetime(2024, 3, 3, tzinfo=timezone.utc),
            days=4,
            ticks_per_minute=2,
            seed=13,
        )
        settings = load_settings(CONFIG / "base.toml")
        settings = settings.model_copy(
            update={"trading": settings.trading.model_copy(update={"min_confirmations": 2})}
        )
        comp = build_components(
            settings, tape_path=tape, profile_name="medium", db_path=work / "j.db"
        )
        try:
            result = comp.engine.run()
            trades = comp.journal.trades()
            signals = list(comp.journal.signals())
        finally:
            comp.close()

        # ADR-031/034: the old distinct-strategy confluence gate and the
        # amplifier are retired; the five-factor count is the tier source, and
        # a zero-confirmation signal is tier D (never executed).
        assert result.confluence_blocked == 0
        assert result.intents > 0
        executed = [s for s in signals if s.active_decision == "executed"]
        assert executed, "expected at least one executed signal"
        assert all(s.confirmation_count >= 1 for s in executed)
        assert all(s.d_hard_floor is False for s in executed)
    finally:
        os.chdir(previous)
