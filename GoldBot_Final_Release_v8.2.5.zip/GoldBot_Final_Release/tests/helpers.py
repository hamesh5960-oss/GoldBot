"""Shared test factories (importable as ``helpers`` from the tests directory)."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path

from goldbot.domain.model import AccountSnapshot, Symbol, SymbolInfo, Tick, Ts
from goldbot.domain.money import money
from goldbot.ports.risk import RiskContext

ROOT = Path(__file__).resolve().parents[1]
CONFIG = ROOT / "config"
NOW = datetime(2024, 3, 4, 10, 0, tzinfo=timezone.utc)


def make_info() -> SymbolInfo:
    return SymbolInfo(
        symbol=Symbol("XAUUSD"),
        broker_symbol="XAUUSD.a",
        digits=2,
        point=0.01,
        tick_size=0.01,
        contract_size=100.0,
        min_volume=0.01,
        max_volume=50.0,
        volume_step=0.01,
        stops_level_points=30,
    )


def make_tick(
    price: float = 2000.0, spread: float = 0.20, at: datetime = NOW, symbol: str = "XAUUSD"
) -> Tick:
    return Tick(
        symbol=Symbol(symbol),
        bid=price - spread / 2,
        ask=price + spread / 2,
        ts_event=Ts(at),
        ts_recv=Ts(at),
        volume=1,
    )


def make_account(
    equity: float = 10_000.0,
    balance: float = 10_000.0,
    leverage: int = 100,
    free_margin: float | None = None,
    mode: str = "hedging",
) -> AccountSnapshot:
    free = equity if free_margin is None else free_margin
    return AccountSnapshot(
        login=1,
        server="test",
        currency="USD",
        balance=money(balance),
        equity=money(equity),
        margin=money(max(0.0, equity - free)),
        free_margin=money(free),
        leverage=leverage,
        trade_mode=mode,  # type: ignore[arg-type]
        ts=Ts(NOW),
    )


def make_context(
    info: SymbolInfo,
    *,
    tick: Tick | None = None,
    account: AccountSnapshot | None = None,
    positions: list | None = None,
    atr: float | None = 2.0,
    session_open: bool = True,
    now: datetime = NOW,
) -> RiskContext:
    return RiskContext(
        account=account or make_account(),
        positions=positions or [],
        symbol_info=info,
        tick=tick or make_tick(),
        now=now,
        atr=atr,
        session_open=session_open,
        news_blackout=False,
    )


@dataclass
class FakeCtx:
    """Minimal StrategyContext for unit-testing plugins."""

    slot: str = "test_slot"
    symbol: str = "XAUUSD"
    symbol_info: SymbolInfo = field(default_factory=make_info)
    params: object = None
    risk_multiplier: float = 1.0
    _bars: list = field(default_factory=list)
    _bars_by_tf: dict = field(default_factory=dict)
    _positions: list = field(default_factory=list)
    _zones: tuple = ()
    _now: datetime = NOW

    def now(self) -> datetime:
        return self._now

    def bars(self, timeframe, count):
        if self._bars_by_tf:
            return self._bars_by_tf.get(timeframe, [])[-count:]
        return self._bars[-count:] if timeframe == "M15" else []

    def zones(self):
        return self._zones

    def last_tick(self):
        return None

    def positions(self):
        return self._positions

    def account(self):
        from goldbot.strategy_api.context import AccountView

        return AccountView(equity=10_000.0, balance=10_000.0, free_margin=10_000.0, open_positions=0)

    def atr(self, timeframe, period):
        return 1.0

    def log(self, message, **fields):
        pass

    def tags(self):
        return {}
