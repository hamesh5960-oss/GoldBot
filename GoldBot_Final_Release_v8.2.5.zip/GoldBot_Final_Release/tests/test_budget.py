"""Order budget: general pool, reserve, spacing, cooldown and half step."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone

from goldbot.app.order_budget import BudgetParams, evaluate_budget

NOW = datetime(2024, 3, 4, 12, 0, tzinfo=timezone.utc)


def evaluate(**overrides):
    values = dict(
        tier="B",
        orders_today=0,
        now=NOW,
        last_order_at=None,
        last_loss_at=None,
        params=BudgetParams(),
    )
    values.update(overrides)
    return evaluate_budget(**values)


def test_general_pool_accepts_any_tier() -> None:
    result = evaluate(orders_today=6, tier="C")
    assert result.outcome == "full"
    assert result.reason == "within_general_pool"


def test_reserve_is_high_quality_only() -> None:
    blocked = evaluate(orders_today=7, tier="B")
    assert blocked.rejected
    assert blocked.reason == "reserve_for_high_quality_only"
    allowed = evaluate(orders_today=7, tier="A")
    assert allowed.outcome == "full"
    assert allowed.reason == "within_reserve_pool"


def test_extended_zone_only_a_plus_at_half() -> None:
    half = evaluate(orders_today=10, tier="A+")
    assert half.outcome == "half"
    assert half.factor == 0.5
    blocked = evaluate(orders_today=10, tier="A")
    assert blocked.rejected
    assert blocked.reason == "extended_reserve"


def test_hard_limit_rejects() -> None:
    result = evaluate(orders_today=15, tier="A+")
    assert result.rejected
    assert result.reason == "hard_limit"


def test_spacing_and_cooldown() -> None:
    spacing = evaluate(last_order_at=NOW - timedelta(minutes=5))
    assert spacing.reason == "min_spacing_not_met"
    cooldown = evaluate(last_loss_at=NOW - timedelta(minutes=10))
    assert cooldown.reason == "post_loss_cooldown"
    clear = evaluate(
        last_order_at=NOW - timedelta(minutes=11), last_loss_at=NOW - timedelta(minutes=31)
    )
    assert clear.outcome == "full"

def test_budget_never_exceeds_the_profile_cap() -> None:
    """medium profile caps at 10: the budget must not advertise 15."""
    params = BudgetParams().for_profile(10)
    assert (params.soft_limit, params.hard_limit) == (10, 10)
    # No extended half zone exists on a 10-order profile; the cap wins.
    at_cap = evaluate(orders_today=10, tier="A+", params=params)
    assert at_cap.rejected
    assert at_cap.reason == "hard_limit"
    reserve = evaluate(orders_today=9, tier="A", params=params)
    assert reserve.outcome == "full"
    assert reserve.reason == "within_reserve_pool"


def test_budget_clamps_to_tighter_profile() -> None:
    params = BudgetParams().for_profile(6)
    assert (params.soft_limit, params.hard_limit) == (6, 6)
    assert evaluate(orders_today=5, tier="A", params=params).outcome == "full"
    assert evaluate(orders_today=6, tier="A+", params=params).rejected


def test_budget_keeps_defaults_on_a_wide_profile() -> None:
    params = BudgetParams().for_profile(40)
    assert (params.soft_limit, params.hard_limit) == (10, 15)
    assert params is BudgetParams() or params == BudgetParams()

