from __future__ import annotations

from pathlib import Path

import pytest

from goldbot.adapters.config import load_settings
from goldbot.app.risk.profiles import load_profiles, resolve_profile
from goldbot.domain.errors import ConfigError

ROOT = Path(__file__).resolve().parents[1]


def test_current_config_loads_and_gate_d_soft_hard_are_ordered():
    settings = load_settings(ROOT / "config/base.toml")
    assert settings.capital.gate_d_max_risk_pct == 2.0
    assert settings.capital.gate_d_hard_pct == 3.0
    assert settings.capital.portfolio_ceiling_pct == 3.0
    assert not hasattr(settings.trading, "min_confirmations")


def test_risk_profiles_match_locked_tier_matrix():
    profiles = load_profiles(ROOT / "config/risk_profiles.toml")
    assert profiles["low"].allowed_tiers == ("A+", "A")
    assert profiles["low"].tier_risk_caps == {"A+": 0.75, "A": 0.5}
    assert profiles["medium"].tier_risk_caps["A+"] == 1.0
    assert profiles["high"].tier_risk_caps["A+"] == 1.0
    assert profiles["low"].max_open_risk_pct == 1.5
    assert profiles["medium"].max_open_risk_pct == 3.0


def test_unknown_profile_fails_closed():
    profiles = load_profiles(ROOT / "config/risk_profiles.toml")
    with pytest.raises(ConfigError):
        resolve_profile("unknown", profiles)


def test_retired_min_confirmations_is_rejected_as_unknown_config(scratch):
    source = (ROOT / "config/base.toml").read_text(encoding="utf-8")
    source = source.replace("direction = \"both\"", 'direction = "both"\nmin_confirmations = 2', 1)
    path = scratch / "bad.toml"
    path.write_text(source, encoding="utf-8")
    with pytest.raises(ConfigError):
        load_settings(path)
