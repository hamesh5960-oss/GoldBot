"""Signal journal persistence: records, 4-level capability rows and stats."""

from __future__ import annotations

import sqlite3
from pathlib import Path

from goldbot.adapters.sqlite_store import SCHEMA, SqliteJournal
from goldbot.domain.events import SignalLevelRecord, SignalRecord


def _signal(signal_id: str = "sig-1", **overrides: object) -> SignalRecord:
    values: dict[str, object] = {
        "signal_id": signal_id,
        "ts_utc": "2024-03-06T10:00:00+00:00",
        "symbol": "XAUUSD",
        "side": "buy",
        "strategy": "numeric",
        "session": "london",
        "session_utc_offset": 3.5,
        "is_dst_active": False,
        "minutes_into_session": 90,
        "entry": 2000.0,
        "sl": 1990.0,
        "tp1": 2020.0,
        "tp2": 2030.0,
        "sl_price": 1990.0,
        "rr_net": 2.0,
        "atr_h1": 5.0,
        "adx_h1": 28.5,
        "news_flag": False,
        "spread_at_signal": 0.2,
        "zone_score_raw": 70.0,
        "zone_score_adj": 65.0,
        "signal_score": 60.0,
        "composite_raw": 61.5,
        "composite_adj": 59.0,
        "tier": "A",
        "confirmations": 2,
        "gate_status": {"gate_b": True},
        "equity_at_signal": 10_000.0,
        "active_level": "base",
        "active_decision": "executed",
        "active_reason": "eligible",
        "active_lot": 0.1,
        "active_risk_pct": 0.5,
        "active_risk_dollars": 50.0,
        "best_eligible_level": "base",
        "was_missed_opportunity": False,
        "params_snapshot": {"profile": "medium"},
    }
    values.update(overrides)
    return SignalRecord(**values)  # type: ignore[arg-type]


def _level(level: str, **overrides: object) -> SignalLevelRecord:
    values: dict[str, object] = {
        "signal_id": "sig-1",
        "level": level,
        "eligible": True,
        "reason": "eligible",
        "would_be_lot": 0.1,
        "would_be_risk_pct": 0.5,
        "would_be_risk_dollars": 50.0,
        "min_capital_needed": 200.0,
        "capital_gap": 0.0,
        "capacity_only": False,
        "session": "london",
        "tier": "A",
        "zone_score_adj": 65.0,
        "sl_price": 1990.0,
        "equity_at_signal": 10_000.0,
        "evaluated_at": "2024-03-06T10:00:01+00:00",
        "params_snapshot": {"profile": "medium"},
    }
    values.update(overrides)
    return SignalLevelRecord(**values)  # type: ignore[arg-type]


def test_signal_roundtrip_with_unicode_and_json(scratch: Path) -> None:
    journal = SqliteJournal(scratch / "signals.db")
    try:
        signal = _signal(
            gate_status={"gate_b": True, "note": "ناحیه طلایی"},
            params_snapshot={"profile": "medium", "tags": ["x", "y"]},
        )
        journal.record_signal(signal)
        loaded = journal.signals()
    finally:
        journal.close()
    assert len(loaded) == 1
    assert loaded[0] == signal
    assert loaded[0].gate_status["note"] == "ناحیه طلایی"
    assert loaded[0].session_utc_offset == 3.5


def test_signals_are_ordered_filtered_and_limited(scratch: Path) -> None:
    journal = SqliteJournal(scratch / "signals.db")
    try:
        journal.record_signal(_signal("b", ts_utc="2024-03-06T11:00:00+00:00"))
        journal.record_signal(_signal("a", ts_utc="2024-03-06T10:00:00+00:00"))
        journal.record_signal(_signal("c", ts_utc="2024-03-07T10:00:00+00:00"))
        ordered = [item.signal_id for item in journal.signals()]
        limited = [item.signal_id for item in journal.signals(limit=2)]
        since = [item.signal_id for item in journal.signals(since="2024-03-06T11:00:00+00:00")]
    finally:
        journal.close()
    assert ordered == ["a", "b", "c"]
    assert limited == ["a", "b"]
    assert since == ["b", "c"]  # inclusive lower bound


def test_recording_same_signal_id_upserts(scratch: Path) -> None:
    journal = SqliteJournal(scratch / "signals.db")
    try:
        journal.record_signal(_signal("sig-1", active_decision="watch", tier="B"))
        journal.record_signal(_signal("sig-1", active_decision="executed", tier="A"))
        loaded = journal.signals()
        count = int(
            journal._conn.execute("SELECT COUNT(*) FROM signal_journal").fetchone()[0]
        )
    finally:
        journal.close()
    assert len(loaded) == 1
    assert loaded[0].active_decision == "executed"
    assert loaded[0].tier == "A"
    assert count == 1


def test_signal_levels_roundtrip_all_four(scratch: Path) -> None:
    journal = SqliteJournal(scratch / "signals.db")
    try:
        journal.record_signal(_signal())
        journal.record_signal_levels(
            "sig-1",
            [
                _level("base"),
                _level("low_risk", eligible=False, reason="tier_floor", would_be_lot=None),
                _level("medium_risk", eligible=False, reason="tier_floor"),
                _level("high_risk", eligible=False, reason="not_allowed"),
            ],
        )
        loaded = journal.signal_levels("sig-1")
    finally:
        journal.close()
    assert [item.level for item in loaded] == ["base", "high_risk", "low_risk", "medium_risk"]
    base = next(item for item in loaded if item.level == "base")
    assert base.eligible is True
    assert base.would_be_lot == 0.1
    assert base.params_snapshot == {"profile": "medium"}


def test_capability_is_unique_per_signal_and_level(scratch: Path) -> None:
    journal = SqliteJournal(scratch / "signals.db")
    try:
        journal.record_signal(_signal())
        journal.record_signal_levels("sig-1", [_level("base")])
        journal.record_signal_levels(
            "sig-1", [_level("base", eligible=False, reason="capital_below_threshold", capital_gap=300.0)]
        )
        loaded = journal.signal_levels("sig-1")
        rows = int(
            journal._conn.execute(
                "SELECT COUNT(*) FROM signal_level_capability WHERE signal_id = 'sig-1' AND level = 'base'"
            ).fetchone()[0]
        )
    finally:
        journal.close()
    assert len(loaded) == 1
    assert loaded[0].eligible is False
    assert loaded[0].reason == "capital_below_threshold"
    assert loaded[0].capital_gap == 300.0
    assert rows == 1


def test_levels_filter_by_signal_and_normalize_the_id(scratch: Path) -> None:
    journal = SqliteJournal(scratch / "signals.db")
    try:
        journal.record_signal(_signal("sig-1"))
        journal.record_signal(_signal("sig-2"))
        # the explicit signal_id wins over the level row's own id
        journal.record_signal_levels("sig-2", [_level("base", signal_id="")])
        only_second = journal.signal_levels("sig-2")
        everything = journal.signal_levels()
        missing = journal.signal_levels("missing")
    finally:
        journal.close()
    assert len(only_second) == 1
    assert only_second[0].signal_id == "sig-2"
    assert len(everything) == 1
    assert list(missing) == []


def test_update_signal_outcome_roundtrip(scratch: Path) -> None:
    journal = SqliteJournal(scratch / "signals.db")
    try:
        journal.record_signal(_signal())
        journal.update_signal_outcome("sig-1", "win", 12.5, "2024-03-06T12:00:00+00:00")
        updated = journal.signals()[0]
        journal.update_signal_outcome("missing", "loss", 0.0, "2024-03-06T12:00:00+00:00")
        missing = journal.signals()
    finally:
        journal.close()
    assert updated.outcome == "win"
    assert updated.pnl_dollars == 12.5
    assert updated.outcome_updated_at == "2024-03-06T12:00:00+00:00"
    assert len(missing) == 1


def test_none_and_empty_values_roundtrip(scratch: Path) -> None:
    journal = SqliteJournal(scratch / "signals.db")
    try:
        journal.record_signal(
            _signal(
                entry=None,
                sl=None,
                tp1=None,
                tp2=None,
                sl_price=None,
                rr_net=None,
                atr_h1=None,
                adx_h1=None,
                spread_at_signal=None,
                gate_status={},
                params_snapshot={},
                best_eligible_level=None,
                outcome=None,
                pnl_dollars=None,
            )
        )
        loaded = journal.signals()[0]
    finally:
        journal.close()
    assert loaded.entry is None
    assert loaded.gate_status == {}
    assert loaded.best_eligible_level is None
    assert loaded.pnl_dollars is None


def test_projection_columns_mirror_the_record(scratch: Path) -> None:
    journal = SqliteJournal(scratch / "signals.db")
    try:
        journal.record_signal(
            _signal(
                "sig-1",
                tier="B",
                session="ny",
                active_level="low_risk",
                active_decision="missed_capital",
                was_missed_opportunity=True,
            )
        )
        row = journal._conn.execute(
            "SELECT ts_utc, session, tier, active_level, active_decision, was_missed_opportunity "
            "FROM signal_journal WHERE signal_id = 'sig-1'"
        ).fetchone()
    finally:
        journal.close()
    assert row is not None
    assert tuple(row) == (
        "2024-03-06T10:00:00+00:00",
        "ny",
        "B",
        "low_risk",
        "missed_capital",
        1,
    )


def test_signal_levels_respect_the_limit(scratch: Path) -> None:
    journal = SqliteJournal(scratch / "signals.db")
    try:
        journal.record_signal(_signal("sig-1"))
        journal.record_signal(_signal("sig-2"))
        journal.record_signal_levels("sig-1", [_level("base"), _level("low_risk")])
        journal.record_signal_levels("sig-2", [_level("base", signal_id="sig-2")])
        limited = journal.signal_levels(limit=2)
    finally:
        journal.close()
    assert [(item.signal_id, item.level) for item in limited] == [
        ("sig-1", "base"),
        ("sig-1", "low_risk"),
    ]


def test_default_signal_record_is_constructible() -> None:
    signal = SignalRecord()
    assert signal.signal_id == ""
    assert signal.gate_status == {}
    assert signal.params_snapshot == {}
    level = SignalLevelRecord()
    assert level.eligible is False
    assert level.params_snapshot == {}


def test_stats_exposes_signal_projection(scratch: Path) -> None:
    journal = SqliteJournal(scratch / "signals.db")
    try:
        journal.record_trade(_trade())
        journal.record_signal(
            _signal(
                "s1",
                session="london",
                tier="A",
                active_decision="executed",
                outcome="win",
                pnl_dollars=10.0,
            )
        )
        journal.record_signal(
            _signal(
                "s2",
                ts_utc="2024-03-06T11:00:00+00:00",
                session="london",
                tier="B",
                active_decision="missed_capital",
                was_missed_opportunity=True,
                active_reason="capital_below_threshold",
            )
        )
        journal.record_signal(
            _signal(
                "s3",
                ts_utc="2024-03-06T16:00:00+00:00",
                session="ny",
                tier="WATCH",
                active_decision="watch",
            )
        )
        journal.record_signal(
            _signal(
                "s4",
                ts_utc="2024-03-06T17:00:00+00:00",
                session="ny",
                tier="C",
                active_decision="missed_level",
                was_missed_opportunity=True,
            )
        )
        journal.record_signal_levels(
            "s1",
            [
                _level("base", signal_id="s1"),
                _level("low_risk", signal_id="s1"),
                _level("medium_risk", signal_id="s1"),
                _level("high_risk", signal_id="s1"),
            ],
        )
        stats = journal.stats()
    finally:
        journal.close()

    assert stats["signals_total"] == 4
    assert stats["signals_executed"] == 1
    assert stats["signals_watch"] == 1
    assert stats["missed_capital"] == 1
    assert stats["missed_level"] == 1
    assert stats["capability_rows"] == 4

    london = stats["by_session"]["london"]
    assert london["signals"] == 2
    assert london["executed"] == 1
    assert london["missed"] == 1
    assert london["pnl_dollars"] == 10.0
    assert london["outcomes"] == {"win": 1, "open": 1}
    ny = stats["by_session"]["ny"]
    assert ny["watch"] == 1
    assert ny["missed"] == 1

    assert stats["by_tier"]["A"]["executed"] == 1
    assert stats["by_tier"]["WATCH"]["watch"] == 1


def test_stats_keeps_the_existing_trade_keys(scratch: Path) -> None:
    journal = SqliteJournal(scratch / "signals.db")
    try:
        stats = journal.stats()
    finally:
        journal.close()
    for key in ("trades", "wins", "losses", "win_rate", "net", "by_slot", "config_hashes"):
        assert key in stats
    assert stats["signals_total"] == 0
    assert stats["capability_rows"] == 0


def test_migration_from_a_presignal_database(scratch: Path) -> None:
    db = scratch / "legacy.db"
    conn = sqlite3.connect(db)
    try:
        conn.executescript(SCHEMA)
        conn.commit()
        tables = {
            row[0]
            for row in conn.execute("SELECT name FROM sqlite_master WHERE type = 'table'")
        }
    finally:
        conn.close()
    assert "signal_journal" not in tables
    assert "signal_level_capability" not in tables

    journal = SqliteJournal(db)
    try:
        journal.record_signal(_signal("sig-1"))
        journal.record_signal_levels("sig-1", [_level("base")])
        assert len(journal.signals()) == 1
        assert len(journal.signal_levels("sig-1")) == 1
    finally:
        journal.close()

    conn = sqlite3.connect(db)
    try:
        tables = {
            row[0]
            for row in conn.execute("SELECT name FROM sqlite_master WHERE type = 'table'")
        }
    finally:
        conn.close()
    assert {"signal_journal", "signal_level_capability"} <= tables


def test_reopening_preserves_signals_and_levels(scratch: Path) -> None:
    db = scratch / "signals.db"
    journal = SqliteJournal(db)
    try:
        journal.record_signal(_signal("sig-1"))
        journal.record_signal_levels("sig-1", [_level("base")])
    finally:
        journal.close()

    reopened = SqliteJournal(db)
    try:
        assert [item.signal_id for item in reopened.signals()] == ["sig-1"]
        assert [item.level for item in reopened.signal_levels("sig-1")] == ["base"]
    finally:
        reopened.close()


def _trade():
    from goldbot.domain.events import TradeRecord

    return TradeRecord(
        trade_id="t1",
        slot="s",
        strategy="numeric",
        symbol="XAUUSD",
        side="buy",
        volume=0.1,
        open_time="2024-03-06T10:00:00+00:00",
        close_time="2024-03-06T12:00:00+00:00",
        open_price=2000.0,
        close_price=2010.0,
        sl=1990.0,
        tp=2020.0,
        pnl_gross=10.0,
        commission=0.0,
        swap=0.0,
        pnl_net=10.0,
        spread_at_entry=0.2,
    )
