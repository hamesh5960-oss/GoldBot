"""Decision matrix: confirmation tiers, layer-3 vote and hard floors."""

from __future__ import annotations

from goldbot.app.decision import (
    SIZE_FACTOR,
    TIER_ORDER,
    TIER_RISK_PCT,
    SizeLevel,
    Tier,
    adjust_tier,
    decide,
    downgrade_size,
    layer3_delta,
    tier_base_from_confirmations,
)


def test_tier_order_is_best_to_worst() -> None:
    assert TIER_ORDER == (Tier.A_PLUS, Tier.A, Tier.B, Tier.C, Tier.D, Tier.NOISE)
    assert [tier.value for tier in Tier] == ["D", "C", "B", "A", "A+", "noise"]


def test_risk_table() -> None:
    assert TIER_RISK_PCT == {
        Tier.A_PLUS: 1.0,
        Tier.A: 0.75,
        Tier.B: 0.5,
        Tier.C: 0.25,
        Tier.D: 0.0,
        Tier.NOISE: 0.0,
    }


def test_confirmation_bands() -> None:
    cases = (
        (0.0, Tier.D),
        (0.999, Tier.D),
        (1.0, Tier.C),
        (1.999, Tier.C),
        (2.0, Tier.B),
        (2.999, Tier.B),
        (3.0, Tier.A),
        (3.999, Tier.A),
        (4.0, Tier.A_PLUS),
        (5.0, Tier.A_PLUS),
        (6.0, Tier.A_PLUS),
    )
    for count, tier in cases:
        assert tier_base_from_confirmations(count) is tier
    # Out-of-range counts clamp instead of raising.
    assert tier_base_from_confirmations(-1.0) is Tier.D
    assert tier_base_from_confirmations(-0.5) is Tier.D
    assert tier_base_from_confirmations(6.5) is Tier.A_PLUS
    assert tier_base_from_confirmations(100.0) is Tier.A_PLUS


def test_layer3_thresholds() -> None:
    assert layer3_delta(0.0) == 0
    assert layer3_delta(0.59) == 0
    assert layer3_delta(0.6) == 1
    assert layer3_delta(1.0) == 1
    assert layer3_delta(-0.59) == 0
    assert layer3_delta(-0.6) == -1
    assert layer3_delta(-1.0) == -1
    # Values outside the vote range saturate.
    assert layer3_delta(5.0) == 1
    assert layer3_delta(-5.0) == -1


def test_adjust_tier_floors_and_caps() -> None:
    # A1 hard floor: a D base ignores layer 3 completely.
    for delta in (-2, -1, 0, 1, 2):
        assert adjust_tier(Tier.D, delta) is Tier.D
    # Layer 3 cannot leave the C..A+ window nor touch NOISE.
    assert adjust_tier(Tier.C, -1) is Tier.C
    assert adjust_tier(Tier.C, -5) is Tier.C
    assert adjust_tier(Tier.A_PLUS, 1) is Tier.A_PLUS
    assert adjust_tier(Tier.A_PLUS, 5) is Tier.A_PLUS
    assert adjust_tier(Tier.NOISE, 1) is Tier.NOISE
    assert adjust_tier(Tier.NOISE, -1) is Tier.NOISE
    # One-step moves in the middle of the ladder.
    assert adjust_tier(Tier.B, 1) is Tier.A
    assert adjust_tier(Tier.B, -1) is Tier.C
    assert adjust_tier(Tier.A, 1) is Tier.A_PLUS
    assert adjust_tier(Tier.A, -1) is Tier.B


def test_decide_returns_the_confirmation_tier_without_gates() -> None:
    top = decide(confirmation_count=4.0)
    assert top.tier is Tier.A_PLUS
    assert top.tier_base is Tier.A_PLUS
    assert top.risk_base_pct == 1.0
    assert top.confirmation_set == ()
    assert top.layer3_delta == 0
    assert top.reasons == ()
    assert top.d_hard_floor is False
    assert top.rejected is False
    assert top.upgraded is False and top.downgraded is False


def test_zero_confirmations_is_a_hard_floor_d() -> None:
    zero = decide(confirmation_count=0.0, layer3_score=1.0)
    assert zero.tier is Tier.D
    assert zero.tier_base is Tier.D
    assert zero.hard_floor is True
    assert zero.d_hard_floor is True
    assert zero.risk_base_pct == 0.0
    assert zero.reasons == ("d_hard_floor",)


def test_zone_filter_is_a_hard_floor_d() -> None:
    filtered = decide(confirmation_count=4.0, zone_score=49.0, min_zone=50.0)
    assert filtered.tier is Tier.D
    assert filtered.tier_base is Tier.A_PLUS
    assert filtered.hard_floor is True
    assert filtered.reasons == ("zone_filter",)
    # The boundary itself passes (strictly-below filter).
    assert (
        decide(confirmation_count=4.0, zone_score=50.0, min_zone=50.0).tier
        is Tier.A_PLUS
    )
    # No zone supplied means no filter.
    assert decide(confirmation_count=4.0, zone_score=None).tier is Tier.A_PLUS


def test_rr_absolute_floor_is_noise() -> None:
    noise = decide(confirmation_count=4.0, rr_net=0.99, rr_absolute_floor=1.0)
    assert noise.tier is Tier.NOISE
    assert noise.rejected is True
    assert noise.tier_base is Tier.A_PLUS
    assert noise.reasons == ("rr_absolute_floor",)
    assert noise.risk_base_pct == 0.0
    assert decide(confirmation_count=4.0, rr_net=1.0).tier is Tier.A_PLUS
    assert decide(confirmation_count=4.0, rr_net=None).tier is Tier.A_PLUS


def test_zone_filter_precedes_the_rr_floor() -> None:
    decision = decide(confirmation_count=4.0, zone_score=10.0, rr_net=0.1)
    assert decision.tier is Tier.D
    assert decision.reasons == ("zone_filter",)


def test_layer3_moves_one_step_and_records_the_reason() -> None:
    up = decide(confirmation_count=2.0, layer3_score=0.6)
    assert (up.tier_base, up.tier) == (Tier.B, Tier.A)
    assert up.layer3_delta == 1
    assert up.reasons == ("tier_layer3_up",)

    down = decide(confirmation_count=2.0, layer3_score=-0.6)
    assert (down.tier_base, down.tier) == (Tier.B, Tier.C)
    assert down.layer3_delta == -1
    assert down.reasons == ("tier_layer3_down",)

    # Votes that cannot move the tier leave no reason.
    assert decide(confirmation_count=4.0, layer3_score=0.9).reasons == ()
    assert decide(confirmation_count=1.0, layer3_score=-0.9).reasons == ()
    assert decide(confirmation_count=2.0, layer3_score=0.59).reasons == ()


def test_upgraded_and_downgraded_are_relative_to_the_base() -> None:
    up = decide(confirmation_count=2.0, layer3_score=0.7)
    assert up.upgraded is True and up.downgraded is False
    down = decide(confirmation_count=2.0, layer3_score=-0.7)
    assert down.downgraded is True and down.upgraded is False
    same = decide(confirmation_count=2.0)
    assert same.upgraded is False and same.downgraded is False
    filtered = decide(confirmation_count=4.0, zone_score=0.0)
    assert filtered.downgraded is True and filtered.upgraded is False


def test_confirmation_set_is_passed_through() -> None:
    decision = decide(
        confirmation_count=3.0, confirmation_set=("trend", "zone", "layer3")
    )
    assert decision.confirmation_set == ("trend", "zone", "layer3")
    as_list = decide(confirmation_count=3.0, confirmation_set=["zone", "trend"])
    assert as_list.confirmation_set == ("zone", "trend")
    assert decide(confirmation_count=3.0).confirmation_set == ()


def test_size_ladder_helpers_are_preserved_for_the_gates() -> None:
    assert SIZE_FACTOR[SizeLevel.FULL] == 1.0
    assert downgrade_size(SizeLevel.FULL) is SizeLevel.HALF
