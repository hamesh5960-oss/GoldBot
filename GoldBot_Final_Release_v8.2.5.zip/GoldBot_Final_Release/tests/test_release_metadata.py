from __future__ import annotations

import tomllib
from pathlib import Path

import goldbot

ROOT = Path(__file__).resolve().parents[1]


def test_runtime_and_package_versions_match():
    metadata = tomllib.loads((ROOT / "pyproject.toml").read_text(encoding="utf-8"))
    assert goldbot.__version__ == metadata["project"]["version"] == "8.2.5"


def test_repository_launcher_and_required_config_are_in_release_tree():
    assert (ROOT / "run_goldbot.py").is_file()
    assert (ROOT / "config/base.toml").is_file()
    assert (ROOT / "config/risk_profiles.toml").is_file()
    metadata = tomllib.loads((ROOT / "pyproject.toml").read_text(encoding="utf-8"))
    assert metadata["project"]["requires-python"] == ">=3.12"
