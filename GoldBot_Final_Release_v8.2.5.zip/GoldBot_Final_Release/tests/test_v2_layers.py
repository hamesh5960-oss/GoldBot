"""v2 layering: gate D soft/hard, kill floor, min lot and confirmation tiers.

The composite score, the dynamic tier shift and the confluence amplifier belong
to the retired v2 scoring model (ADR-033/034); the confirmation ladder is
pinned by tests/test_tier_confirmation.py, and this file keeps the sizing and
risk-engine layers that still apply.
"""

from __future__ import annotations

import pytest

from goldbot.app.decision import SIZE_FACTOR, SizeLevel, Tier, decide, downgrade_size
from goldbot.app.risk.capital import CapitalParams, plan_entry
from goldbot.app.risk_engine import RiskEngine
from goldbot.domain.errors import InvariantError
from goldbot.ports.risk import RiskState

from helpers import NOW, make_account, make_context, make_info, make_tick


def plan(**overrides):
    values = dict(
        tier=Tier.A,
        risk_multiplier=1.0,
        equity=10_000.0,
        stop_distance=10.2,
        info=make_info(),
        commission_per_lot=7.0,
        open_risk_pct=0.0,
        profile_cap_pct=1.0,
        drawdown_pct=0.0,
        atr_percentile=None,
        session="ny",
        news_blackout=False,
        now=NOW,
        params=CapitalParams(),
    )
    values.update(overrides)
    return plan_entry(**values)


def test_gate_d_soft_band_halves_size() -> None:
    tight = plan(open_risk_pct=2.2, params=CapitalParams(gate_d_hard_pct=3.0))
    assert tight.volume > 0
    assert tight.intended_pct == pytest.approx(0.75)
    assert tight.risk_pct < 0.75


def test_gate_d_hard_band_rejects() -> None:
    blocked = plan(open_risk_pct=3.0, params=CapitalParams(gate_d_hard_pct=3.0))
    assert blocked.volume == 0.0
    assert blocked.reason == "gate_d_total_risk"


def test_trade_cap_bounds_amplification() -> None:
    boosted = plan(tier=Tier.B, risk_multiplier=1.5, profile_cap_pct=1.5)
    assert boosted.intended_pct <= 1.0 + 1e-9


def test_force_min_lot_is_one_step() -> None:
    result = plan(force_min_lot=True)
    assert result.volume == 0.01
    assert result.risk_pct <= 0.11


def test_force_min_lot_can_still_be_blocked_by_hard_cap() -> None:
    blocked = plan(open_risk_pct=2.99, force_min_lot=True, params=CapitalParams(gate_d_hard_pct=3.0))
    assert blocked.volume == 0.0
    assert blocked.reason in ("gate_d_total_risk", "below_min_lot")


def test_confirmations_are_counted_once() -> None:
    # ADR-033: confirmations enter the tier only through confirmation_count;
    # a larger confirmation_set at the same count cannot change tier or risk.
    single = decide(confirmation_count=2.0, confirmation_set=("zone",))
    many = decide(
        confirmation_count=2.0,
        confirmation_set=("zone", "trend", "news", "layer3", "other"),
    )
    assert single.tier is Tier.B and many.tier is Tier.B
    assert single.risk_base_pct == many.risk_base_pct == 0.5


def test_smallest_ladder_reaches_min_lot_not_reject() -> None:
    assert SizeLevel.QUARTER in (SizeLevel.QUARTER,)
    assert SIZE_FACTOR[SizeLevel.SMALLEST] == 0.10
    assert downgrade_size(SizeLevel.QUARTER) is SizeLevel.SMALLEST
    assert downgrade_size(SizeLevel.SMALLEST) is SizeLevel.NONE


def test_retired_weak_confluence_mode_is_rejected() -> None:
    """ADR-031/033/034 retired the weak-confluence mode: the key must fail loudly.

    The old test asserted the retired default ("reject"); the behaviour that
    matters now is that a config still carrying the key cannot silently load.
    """
    import pydantic
    from goldbot.adapters.config import TradingCfg, load_settings

    from helpers import CONFIG

    settings = load_settings(CONFIG / "base.toml")
    assert not hasattr(settings.trading, "weak_confluence_mode")
    with pytest.raises(pydantic.ValidationError):
        TradingCfg(weak_confluence_mode="reject")


def test_hmac_secret_can_come_from_env(profile, journal, clock, monkeypatch) -> None:
    monkeypatch.setenv("GOLDBOT_HMAC_SECRET", "env-secret")
    engine = RiskEngine(profile, journal=journal, clock=clock)
    assert engine.secret() == "env-secret"


def test_hmac_required_fails_closed(profile, journal, clock, monkeypatch) -> None:
    monkeypatch.delenv("GOLDBOT_HMAC_SECRET", raising=False)
    monkeypatch.setenv("GOLDBOT_REQUIRE_SECRET", "1")
    with pytest.raises(InvariantError):
        RiskEngine(profile, journal=journal, clock=clock)


def test_catastrophic_floor_kills(profile, journal, clock, info) -> None:
    engine = RiskEngine(profile, journal=journal, clock=clock)
    engine.begin(10_000.0, NOW)
    ctx = make_context(info, tick=make_tick(), account=make_account(equity=4_000.0, balance=4_000.0))
    engine.on_mark(ctx)
    assert engine.state() is RiskState.KILLED
