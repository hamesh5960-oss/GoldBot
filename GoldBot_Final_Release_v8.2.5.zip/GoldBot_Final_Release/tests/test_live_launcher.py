"""Live launcher lifecycle: single-instance lock, secret delivery, log rotation.

The PowerShell paths are exercised with a test-only self-test hook that stops
before credentials/state checks and never starts MT5 or a live order session.
"""

from __future__ import annotations

import logging
import os
import shutil
import subprocess
import time
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
START_LIVE = ROOT / "scripts" / "start_live.ps1"
TASK_WRAPPER = ROOT / "scripts" / "run_live_task.ps1"
PWSH = shutil.which("pwsh") or shutil.which("powershell")


def script_text(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def _clean_env(extra: dict[str, str]) -> dict[str, str]:
    env = {key: value for key, value in os.environ.items() if not key.startswith("GOLDBOT_")}
    env.update(extra)
    return env


def _pwsh_or_skip() -> str:
    if not PWSH:
        pytest.skip("PowerShell is required to exercise the launcher scripts")
    return PWSH


def _run_script(
    script: Path,
    args: list[str],
    env: dict[str, str],
    timeout: int = 60,
) -> subprocess.CompletedProcess[str]:
    command = [
        _pwsh_or_skip(),
        "-NoProfile",
        "-ExecutionPolicy",
        "Bypass",
        "-File",
        str(script),
        *args,
    ]
    return subprocess.run(
        command,
        cwd=str(ROOT),
        env=env,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=timeout,
    )


# -- cold start policy (unchanged behaviour) --------------------------------


def test_live_launcher_never_adds_cold_start_automatically():
    script = script_text(START_LIVE)
    command = next(line for line in script.splitlines() if line.startswith("python run_goldbot.py live"))
    assert "--cold-start" not in command
    assert "@args" in command


def test_live_launcher_requires_explicit_cold_start_and_no_positions_confirmation():
    script = script_text(START_LIVE)
    assert '[Array]::IndexOf($args, "--cold-start")' in script
    assert "NO-OPEN-POSITIONS" in script
    assert "elseif (-not (Test-Path $stateDb))" in script
    assert '"--state-db"' in script and '"--db"' in script
    assert "$explicitStateDb = $env:GOLDBOT_STATE_DB" in script


# -- OBS-02: real single-instance lock --------------------------------------


def test_launcher_holds_an_exclusive_lock_and_covers_all_invocation_forms():
    script = script_text(START_LIVE)
    assert "[System.IO.FileShare]::None" in script
    assert "var/live.lock" in script
    assert "GOLDBOT_LIVE_LOCK" in script
    assert "run_goldbot.py live" in script
    assert "-m goldbot live" in script
    assert "goldbot.exe* live*" in script
    assert "already running" in script
    assert "exit 3" in script
    # The lock must be taken before the cold-start prompts and the python call.
    assert script.index("[System.IO.FileShare]::None") < script.index("NO-OPEN-POSITIONS")
    assert script.index("[System.IO.FileShare]::None") < script.index("python run_goldbot.py live")


def test_launcher_selftest_hook_exits_before_starting_a_live_session():
    script = script_text(START_LIVE)
    assert "GOLDBOT_LAUNCHER_SELFTEST" in script
    assert script.index("GOLDBOT_LAUNCHER_SELFTEST") < script.index("python run_goldbot.py live")
    assert "exit 0" in script


def test_second_launcher_is_refused_by_the_live_lock(scratch):
    pwsh = _pwsh_or_skip()
    lock = scratch / "live.lock"
    env = _clean_env(
        {
            "GOLDBOT_LIVE_LOCK": str(lock),
            "GOLDBOT_LAUNCHER_SELFTEST": "lock",
            "GOLDBOT_LAUNCHER_SELFTEST_HOLD": "8",
        }
    )
    first = subprocess.Popen(
        [pwsh, "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(START_LIVE)],
        cwd=str(ROOT),
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    try:
        deadline = time.time() + 20
        while time.time() < deadline and not lock.exists():
            time.sleep(0.05)
        assert lock.exists(), "first launcher never created the lock file"

        second = _run_script(START_LIVE, [], env)
        assert second.returncode != 0, (second.stdout, second.stderr)
        combined = (second.stdout or "") + (second.stderr or "")
        assert "already running" in combined
    finally:
        first.communicate(timeout=60)
    assert first.returncode == 0


# -- SEC-02: no MT5 password on the command line ---------------------------


def test_launcher_never_accepts_password_on_argv_and_supports_a_password_file():
    script = script_text(START_LIVE)
    assert "GOLDBOT_MT5_PASSWORD_FILE" in script
    assert '"--password"' in script and '"--password=*"' in script
    assert "must not be passed on the command line" in script
    assert script.index('"--password"') < script.index("Read-Host")


def test_launcher_refuses_password_on_the_command_line(scratch):
    env = _clean_env({"GOLDBOT_LIVE_LOCK": str(scratch / "live.lock")})
    result = _run_script(START_LIVE, ["--password", "hunter2"], env)
    assert result.returncode != 0
    combined = (result.stdout or "") + (result.stderr or "")
    assert "GOLDBOT_MT5_PASSWORD" in combined
    assert "hunter2" not in combined


# -- OBS-03: bounded logging ----------------------------------------------


def test_launcher_wires_bounded_in_process_logging():
    script = script_text(START_LIVE)
    assert "GOLDBOT_LOG_PATH" in script
    assert "GOLDBOT_LOG_MAX_BYTES" in script
    assert "GOLDBOT_LOG_BACKUPS" in script
    assert "var/live.jsonl" in script


def test_task_wrapper_rotates_the_console_log_and_is_testable():
    script = script_text(TASK_WRAPPER)
    assert "function Rotate-LiveLog" in script
    assert "GOLDBOT_LOG_ROTATE_SELFTEST" in script
    assert "$maxBytes = 5242880" in script
    assert "$keep = 5" in script
    assert "Out-File" in script
    assert "start_live.ps1" in script


def test_task_wrapper_rotates_an_oversized_live_log_and_keeps_n(scratch):
    log = scratch / "live.log"
    log.write_text("x" * 4096, encoding="utf-8")
    (scratch / "live.log.1").write_text("older-one", encoding="utf-8")
    (scratch / "live.log.2").write_text("older-two", encoding="utf-8")
    env = _clean_env(
        {
            "GOLDBOT_LOG_ROTATE_SELFTEST": str(log),
            "GOLDBOT_LOG_ROTATE_MAX_BYTES": "1024",
            "GOLDBOT_LOG_ROTATE_KEEP": "2",
        }
    )
    result = _run_script(TASK_WRAPPER, [], env)
    assert result.returncode == 0, (result.stdout, result.stderr)
    assert not log.exists()
    assert (scratch / "live.log.1").stat().st_size == 4096
    assert (scratch / "live.log.1").read_text(encoding="utf-8") == "x" * 4096
    assert (scratch / "live.log.2").read_text(encoding="utf-8") == "older-one"
    assert not (scratch / "live.log.3").exists()


def test_task_wrapper_leaves_a_small_live_log_alone(scratch):
    log = scratch / "live.log"
    log.write_text("small", encoding="utf-8")
    env = _clean_env(
        {
            "GOLDBOT_LOG_ROTATE_SELFTEST": str(log),
            "GOLDBOT_LOG_ROTATE_MAX_BYTES": "1024",
            "GOLDBOT_LOG_ROTATE_KEEP": "2",
        }
    )
    result = _run_script(TASK_WRAPPER, [], env)
    assert result.returncode == 0, (result.stdout, result.stderr)
    assert log.read_text(encoding="utf-8") == "small"
    assert not (scratch / "live.log.1").exists()


def test_log_module_writes_a_bounded_rotated_file(scratch, monkeypatch):
    from goldbot import log as goldbot_log

    target = scratch / "live.jsonl"
    monkeypatch.setenv(goldbot_log.LOG_PATH_ENV, str(target))
    monkeypatch.setenv(goldbot_log.LOG_MAX_BYTES_ENV, "256")
    monkeypatch.setenv(goldbot_log.LOG_BACKUPS_ENV, "2")

    root = logging.getLogger("goldbot")
    saved_handlers = list(root.handlers)
    saved_level = root.level
    saved_propagate = root.propagate
    try:
        goldbot_log.setup("INFO", json_logs=True)
        logger = goldbot_log.get_logger("rotation-test")
        for index in range(600):
            logger.info("line %s", index)
        for handler in root.handlers:
            handler.flush()
        assert target.exists()
        assert (scratch / "live.jsonl.1").exists()
        assert target.stat().st_size < 4096
    finally:
        for handler in list(root.handlers):
            root.removeHandler(handler)
            handler.close()
        for handler in saved_handlers:
            root.addHandler(handler)
        root.setLevel(saved_level)
        root.propagate = saved_propagate
