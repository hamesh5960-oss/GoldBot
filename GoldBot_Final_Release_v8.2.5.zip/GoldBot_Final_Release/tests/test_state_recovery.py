"""Cold-restart recovery: a crash must not clear a safety latch.

The risk engine's numbers are the only thing between a restart and a fresh
KILLED -> NORMAL reset, so these tests kill the process at every interesting
point and rebuild the engine from the same SQLite file.
"""

from __future__ import annotations

import json
import os
import sqlite3
from datetime import timedelta
from pathlib import Path
from typing import Any

import pytest

from goldbot.adapters.config import load_settings
from goldbot.adapters.sqlite_state_store import SqliteRiskStateStore
from goldbot.adapters.sqlite_store import SqliteJournal
from goldbot.app.risk_engine import RiskEngine
from goldbot.domain.execution import EntryIntent
from goldbot.domain.model import PositionSnapshot, Symbol
from goldbot.ports.risk import RiskState
from goldbot.ports.state import SCHEMA_VERSION, PersistedRiskState, StateCorruption
from goldbot.runtime import cli
from goldbot.runtime.bootstrap import build_components, resolve_allow_cold_start, state_db_path

from helpers import CONFIG, NOW, ROOT, make_account, make_context, make_tick


# -- helpers -------------------------------------------------------------
def _intent() -> EntryIntent:
    return EntryIntent(
        intent_id="i-restart",
        slot="fvg_m15",
        strategy="fvg",
        symbol=Symbol("XAUUSD"),
        side="buy",
        entry_ref=2000.2,
        stop=1990.0,
        target=2020.4,
        risk_multiplier=1.0,
        signal={"rationale": "restart test"},
        created_at=NOW,
    )


def _open(
    path: Path,
    profile: Any,
    journal: SqliteJournal,
    clock: Any,
    *,
    allow_cold_start: bool = False,
) -> tuple[RiskEngine, SqliteRiskStateStore]:
    store = SqliteRiskStateStore(path)
    engine = RiskEngine(
        profile,
        journal=journal,
        clock=clock,
        state_store=store,
        allow_cold_start=allow_cold_start,
    )
    return engine, store


def _corrupt(db: Path, *, payload: str = "{not json", version: int = SCHEMA_VERSION) -> None:
    store = SqliteRiskStateStore(db)
    store.close()
    conn = sqlite3.connect(db)
    try:
        conn.execute(
            "INSERT OR REPLACE INTO risk_state(key, schema_version, payload, updated_at)"
            " VALUES (?, ?, ?, ?)",
            ("default", version, payload, "2024-03-04T10:00:00+00:00"),
        )
        conn.commit()
    finally:
        conn.close()


def _write_tape(scratch: Path) -> Path:
    """One valid tick: TapeFeed validates the file before the engine connects."""
    tape = scratch / "tape.jsonl"
    if not tape.exists():
        row = {"ts": NOW.timestamp(), "bid": 1999.9, "ask": 2000.1, "v": 1}
        tape.write_text(json.dumps(row) + "\n", encoding="utf-8")
    return tape


def _build(scratch: Path, **kwargs: Any) -> Any:
    previous = os.getcwd()
    os.chdir(ROOT)
    try:
        settings = load_settings(CONFIG / "base.toml")
        return build_components(
            settings,
            tape_path=_write_tape(scratch),
            db_path=scratch / "journal.db",
            **kwargs,
        )
    finally:
        os.chdir(previous)


# -- engine cold restart -------------------------------------------------
def test_normal_state_is_restored_exactly(profile, journal, clock, info, scratch) -> None:
    db = scratch / "risk_state.db"
    engine, store = _open(db, profile, journal, clock, allow_cold_start=True)
    engine.begin(10_000.0, NOW)
    assert engine.evaluate_entry(_intent(), make_context(info)).approved
    engine.register_position(555, risk_amount=120.0, initial_stop=1990.0, slot="fvg_m15")
    engine.on_trade_closed(80.0, NOW)
    before = engine.persistable_state()
    assert before.orders_today == 1
    assert before.day == "2024-03-04"
    store.close()  # simulated crash: no graceful shutdown

    restored, store = _open(db, profile, journal, clock)
    try:
        assert restored.state() is RiskState.NORMAL
        after = restored.persistable_state()
        assert after.day == before.day
        assert after.day_start_equity == before.day_start_equity
        assert after.peak_equity == before.peak_equity
        assert after.initial_equity == before.initial_equity
        assert after.daily_pnl == before.daily_pnl
        assert after.drawdown_pct == before.drawdown_pct
        assert after.consecutive_losses == before.consecutive_losses
        assert after.orders_today == before.orders_today
        assert after.last_order_at == before.last_order_at
        assert dict(after.ticket_meta) == dict(before.ticket_meta)
        assert after.restored_at, "a restored record must be timestamped"

        # begin() on the same broker day must not reset the persisted counters.
        restored.begin(10_000.0, NOW)
        again = restored.persistable_state()
        assert again.day == before.day
        assert again.orders_today == before.orders_today
    finally:
        store.close()


def test_halted_state_survives_restart_until_acknowledged(
    profile, journal, clock, info, scratch
) -> None:
    db = scratch / "risk_state.db"
    engine, store = _open(db, profile, journal, clock, allow_cold_start=True)
    engine.begin(10_000.0, NOW)
    engine.engage(RiskState.HALTED, "operator halt", actor="operator")
    store.close()

    restored, store = _open(db, profile, journal, clock)
    try:
        assert restored.state() is RiskState.HALTED
        assert restored.persistable_state().reason == "operator halt"
        restored.on_mark(make_context(info))
        assert restored.state() is RiskState.HALTED, "a manual halt needs a human, not a bar"
        restored.acknowledge(level=RiskState.HALTED, actor="operator", note="checked")
        assert restored.state() is RiskState.NORMAL
    finally:
        store.close()
    after_ack, store = _open(db, profile, journal, clock)
    try:
        assert after_ack.state() is RiskState.NORMAL
    finally:
        store.close()


def test_daily_halt_still_clears_on_the_next_day_after_restart(
    profile, journal, clock, info, scratch
) -> None:
    db = scratch / "risk_state.db"
    engine, store = _open(db, profile, journal, clock, allow_cold_start=True)
    engine.begin(10_000.0, NOW)
    engine.on_mark(make_context(info, account=make_account(equity=9_700.0, balance=9_700.0)))
    assert engine.state() is RiskState.HALTED
    store.close()

    restored, store = _open(db, profile, journal, clock)
    try:
        assert restored.state() is RiskState.HALTED
        tomorrow = NOW + timedelta(days=1)
        restored.on_mark(
            make_context(
                info, account=make_account(equity=9_700.0, balance=9_700.0), now=tomorrow
            )
        )
        assert restored.state() is RiskState.NORMAL, "a daily brake must still reset with the day"
    finally:
        store.close()
    next_day, store = _open(db, profile, journal, clock)
    try:
        assert next_day.state() is RiskState.NORMAL
    finally:
        store.close()


def test_killed_state_survives_restart(profile, journal, clock, info, scratch) -> None:
    db = scratch / "risk_state.db"
    engine, store = _open(db, profile, journal, clock, allow_cold_start=True)
    engine.begin(10_000.0, NOW)
    engine.on_mark(make_context(info, account=make_account(equity=8_000.0, balance=8_000.0)))
    assert engine.state() is RiskState.KILLED
    reason = engine.persistable_state().reason
    store.close()

    restored, store = _open(db, profile, journal, clock)
    try:
        assert restored.state() is RiskState.KILLED
        assert restored.persistable_state().reason == reason
        tomorrow = NOW + timedelta(days=1)
        restored.on_mark(
            make_context(
                info, account=make_account(equity=8_000.0, balance=8_000.0), now=tomorrow
            )
        )
        assert restored.state() is RiskState.KILLED, "never auto-clear a kill switch"
        restored.acknowledge(level=RiskState.KILLED, actor="operator", note="reviewed")
        assert restored.state() is RiskState.NORMAL
    finally:
        store.close()
    after_ack, store = _open(db, profile, journal, clock)
    try:
        assert after_ack.state() is RiskState.NORMAL
    finally:
        store.close()


def test_quarantine_survives_restart_until_acknowledged(
    profile, journal, clock, info, scratch
) -> None:
    db = scratch / "risk_state.db"
    engine, store = _open(db, profile, journal, clock, allow_cold_start=True)
    engine.begin(10_000.0, NOW)
    engine.force_quarantine("startup reconciliation divergence")
    store.close()

    restored, store = _open(db, profile, journal, clock)
    try:
        assert restored.state() is RiskState.QUARANTINE
        assert restored.persistable_state().reason == "startup reconciliation divergence"
        restored.on_mark(make_context(info))
        assert restored.state() is RiskState.QUARANTINE
        restored.acknowledge(level=RiskState.QUARANTINE, actor="operator", note="flat and verified")
        assert restored.state() is RiskState.NORMAL
    finally:
        store.close()
    after_ack, store = _open(db, profile, journal, clock)
    try:
        assert after_ack.state() is RiskState.NORMAL
    finally:
        store.close()


def test_empty_store_quarantines_when_cold_start_is_refused(
    profile, journal, clock, scratch
) -> None:
    db = scratch / "risk_state.db"
    engine, store = _open(db, profile, journal, clock, allow_cold_start=False)
    store.close()
    assert engine.state() is RiskState.QUARANTINE
    assert engine.persistable_state().reason == "no persisted risk state (first run)"
    assert engine.restore_error is None

    # The refusal itself is latched: the next process sees a record, not an empty store.
    again, store = _open(db, profile, journal, clock, allow_cold_start=True)
    try:
        assert again.state() is RiskState.QUARANTINE
    finally:
        store.close()


def test_empty_store_allows_cold_start_for_synthetic(profile, journal, clock, scratch) -> None:
    db = scratch / "risk_state.db"
    engine, store = _open(db, profile, journal, clock, allow_cold_start=True)
    try:
        assert engine.state() is RiskState.NORMAL
        assert engine.restarted is False
        assert engine.persistable_state().day is None
    finally:
        store.close()


@pytest.mark.parametrize(
    ("payload", "version"),
    [
        ("{not json", SCHEMA_VERSION),
        ('{"schema_version": 1}', SCHEMA_VERSION),
        (json.dumps(PersistedRiskState().to_dict()), 99),
    ],
    ids=["bad-json", "missing-state", "unknown-schema"],
)
def test_corrupt_store_quarantines_never_normal(
    profile, journal, clock, scratch, payload, version
) -> None:
    db = scratch / "risk_state.db"
    _corrupt(db, payload=payload, version=version)
    store = SqliteRiskStateStore(db)
    try:
        with pytest.raises(StateCorruption):
            store.load()
    finally:
        store.close()

    engine, store = _open(db, profile, journal, clock, allow_cold_start=True)
    store.close()
    assert engine.state() is RiskState.QUARANTINE
    assert engine.restore_error, "the corruption must be reported, not swallowed"
    assert engine.persistable_state().reason.startswith("corrupt persisted risk state:")

    durable, store = _open(db, profile, journal, clock, allow_cold_start=True)
    try:
        assert durable.state() is RiskState.QUARANTINE, "corruption must not decay to NORMAL"
    finally:
        store.close()


def test_ticket_meta_and_orders_today_persist_across_restart(
    profile, journal, clock, info, scratch
) -> None:
    db = scratch / "risk_state.db"
    engine, store = _open(db, profile, journal, clock, allow_cold_start=True)
    engine.begin(10_000.0, NOW)
    assert engine.evaluate_entry(_intent(), make_context(info)).approved
    # The daily order budget enforces a minimum spacing between orders.
    later = NOW + timedelta(minutes=15)
    clock.advance(later)
    assert engine.evaluate_entry(_intent(), make_context(info, tick=make_tick(at=later), now=later)).approved
    engine.register_position(11, risk_amount=50.0, initial_stop=1990.0, slot="fvg_m15")
    engine.register_position(12, risk_amount=75.0, initial_stop=1985.0, slot="rect_m15")
    store.close()

    restored, store = _open(db, profile, journal, clock)
    try:
        state = restored.persistable_state()
        assert state.orders_today == 2
        assert set(state.ticket_meta) == {11, 12}
        assert state.ticket_meta[11]["slot"] == "fvg_m15"
        assert state.ticket_meta[12]["risk_amount"] == 75.0

        positions = [
            PositionSnapshot(
                ticket=ticket,
                symbol=Symbol("XAUUSD"),
                side="buy",
                volume=0.01,
                open_price=2000.0,
                sl=1990.0,
                tp=None,
                magic=1,
                comment="",
                open_time=NOW,
            )
            for ticket in (11, 12)
        ]
        ctx = make_context(info, positions=positions)
        expected = (50.0 + 75.0) / 10_000.0 * 100.0
        assert restored._open_risk_pct(ctx) == pytest.approx(expected)
    finally:
        store.close()


# -- adapter -------------------------------------------------------------
def test_store_roundtrip_upsert_and_clear(scratch) -> None:
    db = scratch / "state.db"
    store = SqliteRiskStateStore(db)
    try:
        assert store.load() is None
        record = PersistedRiskState(
            state=RiskState.HALTED,
            reason="daily loss",
            day="2024-03-04",
            orders_today=4,
            ticket_meta={7: {"slot": "fvg_m15", "risk_amount": 10.0}},
            updated_at="2024-03-04T10:00:00+00:00",
        )
        store.save(record)
        assert store.load() == record

        store.save(PersistedRiskState(state=RiskState.KILLED, reason="drawdown"))
        loaded = store.load()
        assert loaded is not None and loaded.state is RiskState.KILLED, "single-row upsert expected"

        store.clear()
        assert store.load() is None
    finally:
        store.close()


# -- cli -----------------------------------------------------------------
def test_ack_cli_clears_killed_state(scratch) -> None:
    db = scratch / "risk_state.db"
    store = SqliteRiskStateStore(db)
    store.save(
        PersistedRiskState(
            state=RiskState.KILLED,
            reason="total drawdown",
            updated_at="2024-03-04T10:00:00+00:00",
        )
    )
    store.close()
    journal_path = scratch / "journal.db"

    code = cli.main(
        [
            "ack",
            "--level",
            "killed",
            "--note",
            "checked by hand",
            "--state-db",
            str(db),
            "--db",
            str(journal_path),
            "--confirm",
        ]
    )
    assert code == 0

    store = SqliteRiskStateStore(db)
    try:
        cleared = store.load()
    finally:
        store.close()
    assert cleared is not None
    assert cleared.state is RiskState.NORMAL
    assert cleared.reason == ""

    journal = SqliteJournal(journal_path)
    try:
        events = [e for e in journal.read_events() if e.type == "RiskStateChanged"]
    finally:
        journal.close()
    assert events, "an acknowledgement without a journal trail is not auditable"
    assert events[-1].actor == "operator"
    assert events[-1].payload["from"] == "KILLED"
    assert events[-1].payload["to"] == "NORMAL"


def test_ack_cli_requires_confirm(scratch) -> None:
    db = scratch / "risk_state.db"
    store = SqliteRiskStateStore(db)
    store.save(PersistedRiskState(state=RiskState.KILLED, reason="drawdown"))
    store.close()

    code = cli.main(["ack", "--level", "killed", "--state-db", str(db)])
    assert code == 2, "clearing a kill switch must be explicit"
    store = SqliteRiskStateStore(db)
    try:
        still = store.load()
    finally:
        store.close()
    assert still is not None and still.state is RiskState.KILLED


def test_ack_cli_refuses_lower_severity(scratch) -> None:
    db = scratch / "risk_state.db"
    store = SqliteRiskStateStore(db)
    store.save(PersistedRiskState(state=RiskState.QUARANTINE, reason="corrupt"))
    store.close()

    code = cli.main(["ack", "--level", "killed", "--state-db", str(db), "--confirm"])
    assert code == 1, "KILLED cannot acknowledge QUARANTINE"
    store = SqliteRiskStateStore(db)
    try:
        still = store.load()
    finally:
        store.close()
    assert still is not None and still.state is RiskState.QUARANTINE


def test_status_cli_prints_persisted_state(scratch, capsys) -> None:
    db = scratch / "risk_state.db"
    store = SqliteRiskStateStore(db)
    store.save(PersistedRiskState(state=RiskState.KILLED, reason="total drawdown"))
    store.close()

    code = cli.main(["status", "--state-db", str(db), "--json"])
    captured = capsys.readouterr().out
    assert code == 0
    payload = json.loads(captured)
    assert payload["state"] == "KILLED"
    assert payload["reason"] == "total drawdown"


# -- bootstrap wiring ----------------------------------------------------
def test_bootstrap_quarantines_empty_store_in_live_mode(monkeypatch, scratch) -> None:
    monkeypatch.setenv("GOLDBOT_MODE", "live")
    state_path = scratch / "live_state.db"
    monkeypatch.setenv("GOLDBOT_STATE_DB", str(state_path))
    components = _build(scratch)
    try:
        assert components.risk.state() is RiskState.QUARANTINE
        assert state_path.exists(), "the refusal must be written to the state db"
        events = [e for e in components.journal.read_events() if e.type == "RiskStateRestored"]
        assert events
        assert events[-1].payload["state"] == "QUARANTINE"
        assert events[-1].payload["restored"] is False
    finally:
        components.close()


def test_bootstrap_restores_latched_state(scratch) -> None:
    db = scratch / "state.db"
    store = SqliteRiskStateStore(db)
    store.save(
        PersistedRiskState(
            state=RiskState.KILLED,
            reason="total drawdown",
            day="2024-03-04",
            peak_equity=10_000.0,
            updated_at="2024-03-04T10:00:00+00:00",
        )
    )
    store.close()

    components = _build(scratch, state_db=db)
    try:
        assert components.risk.state() is RiskState.KILLED
        assert components.risk.restarted is True
        events = [e for e in components.journal.read_events() if e.type == "RiskStateRestored"]
        assert events[-1].payload["restored"] is True
        assert events[-1].payload["state"] == "KILLED"
    finally:
        components.close()


def test_bootstrap_quarantines_corrupt_store(scratch) -> None:
    db = scratch / "state.db"
    _corrupt(db, payload="{oops")

    components = _build(scratch, state_db=db)
    try:
        assert components.risk.state() is RiskState.QUARANTINE
        events = [
            e for e in components.journal.read_events() if e.type == "RiskStateRestoreFailed"
        ]
        assert events, "a corrupt state db must raise an audit event"
        assert events[-1].payload["error"]
        assert events[-1].payload["reason"].startswith("corrupt persisted risk state:")
    finally:
        components.close()


# -- policy helpers ------------------------------------------------------
def test_state_db_path_resolution(monkeypatch, scratch) -> None:
    monkeypatch.delenv("GOLDBOT_STATE_DB", raising=False)
    assert state_db_path(Path("var/goldbot.db")) == Path("var/risk_state.db")
    assert state_db_path(Path("var/runs/run-1.db")) == Path("var/runs/run-1_risk_state.db")

    # ADR-016 item 8: the environment pins the store; an explicit flag only
    # decides when the environment is silent.
    explicit = scratch / "explicit.db"
    assert state_db_path(Path("var/goldbot.db"), explicit) == explicit
    monkeypatch.setenv("GOLDBOT_STATE_DB", str(scratch / "env.db"))
    assert state_db_path(Path("var/goldbot.db")) == scratch / "env.db"
    assert state_db_path(Path("var/goldbot.db"), explicit) == scratch / "env.db"
    monkeypatch.delenv("GOLDBOT_STATE_DB")
    assert state_db_path(Path("var/goldbot.db"), explicit) == explicit


def test_cold_start_policy(monkeypatch) -> None:
    monkeypatch.delenv("GOLDBOT_MODE", raising=False)
    assert resolve_allow_cold_start() is True
    assert resolve_allow_cold_start(False, mode="synthetic") is False
    assert resolve_allow_cold_start(mode="live") is False
    assert resolve_allow_cold_start(mode="paper") is False
    assert resolve_allow_cold_start(mode="backtest") is True

    monkeypatch.setenv("GOLDBOT_MODE", "live")
    assert resolve_allow_cold_start() is False

    # A live composition root (MT5 objects injected) is fail-closed even when
    # the environment still says synthetic; only an explicit True allows it.
    monkeypatch.delenv("GOLDBOT_MODE", raising=False)
    assert resolve_allow_cold_start(live_composition=True) is False
    assert resolve_allow_cold_start(True, live_composition=True) is True
    assert resolve_allow_cold_start(live_composition=False) is True


def test_live_composition_without_explicit_flag_quarantines(scratch, info) -> None:
    """D2: the shared composition root is fail-closed for injected live objects."""
    from goldbot.adapters.clock import SimulatedClock
    from goldbot.adapters.fake_broker import FakeBroker

    previous = os.getcwd()
    os.chdir(ROOT)
    try:
        settings = load_settings(CONFIG / "base.toml")
        broker = FakeBroker(info, balance=10_000.0)
        live_clock = SimulatedClock(NOW)
        live_clock.bind(info)
        components = build_components(
            settings,
            tape_path=_write_tape(scratch),
            db_path=scratch / "journal.db",
            state_db=scratch / "live_state.db",
            live_broker=broker,
            live_clock=live_clock,
        )
    finally:
        os.chdir(previous)
    try:
        assert components.risk.state() is RiskState.QUARANTINE
        assert (
            components.risk.persistable_state().reason
            == "no persisted risk state (first run)"
        )
    finally:
        components.close()


def test_synthetic_build_still_cold_starts_without_flag(scratch) -> None:
    """D2: demo/backtest keep the historical cold-start default (explicit True)."""
    components = _build(scratch, state_db=scratch / "synthetic_state.db")
    try:
        assert components.risk.state() is RiskState.NORMAL
        assert components.risk.restarted is False
        assert components.risk.persistable_state().day is None
    finally:
        components.close()


def test_heartbeat_file_is_namespaced_by_journal(scratch) -> None:
    """OBS-01: a demo/backtest journal must not overwrite the live heartbeat."""
    from goldbot.app.heartbeat import heartbeat_path_for

    components = _build(scratch, state_db=scratch / "hb_state.db")
    try:
        assert components.heartbeat is not None
        assert components.heartbeat.path == heartbeat_path_for(scratch / "journal.db")
        assert components.heartbeat.path == Path(str(scratch / "journal.db") + ".heartbeat.json")
        assert components.heartbeat.path != heartbeat_path_for(ROOT / "var" / "live.db")
    finally:
        components.close()


def test_aux_state_and_gate_burns_survive_restart(
    profile, journal, clock, scratch
) -> None:
    """Gate B burns and Gate A counters are safety state too, not cache."""
    from goldbot.app.gates import CooldownManager

    path = scratch / "state.db"
    first, store = _open(path, profile, journal, clock, allow_cold_start=True)
    first.begin(10_000.0, NOW)
    manager = CooldownManager()
    manager.bar_index = 42
    manager.last_exec_bar = 41
    manager._burns[("D1", "buy")] = {"until": 50, "reason": "SL", "count": 2}
    manager._sl_counts[("D1", "buy")] = 2
    first.update_aux("gates", manager.snapshot())
    store.close()

    second, store2 = _open(path, profile, journal, clock, allow_cold_start=True)
    try:
        saved = second.aux("gates")
        assert saved and saved["bar_index"] == 42
        restored = CooldownManager()
        assert restored.restore(saved) is True
        assert restored.bar_index == 42
        assert restored.last_exec_bar == 41
        assert restored.burns() == manager.burns()
        assert restored.snapshot()["sl_counts"] == manager.snapshot()["sl_counts"]
        assert restored.restore("not a mapping") is False  # fail-open, no crash
    finally:
        store2.close()
