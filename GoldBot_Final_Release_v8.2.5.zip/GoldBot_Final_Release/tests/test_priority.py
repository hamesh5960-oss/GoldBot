"""Per-bar priority: the S/R plan suppresses the numeric grid on the same bar."""

from __future__ import annotations

from types import SimpleNamespace

from goldbot.app.engine import dominant_entry_priority


def signal(kind: str, side: str | None, slot: str):
    return SimpleNamespace(kind=kind, side=side, slot=slot)


PRIORITY = {"zones": 10, "numeric": 100}


def test_dominant_priority_is_the_lowest_number() -> None:
    signals = [signal("entry", "buy", "numeric"), signal("entry", "buy", "zones")]
    assert dominant_entry_priority(signals, lambda item: PRIORITY[item.slot]) == 10


def test_exits_do_not_set_priority() -> None:
    signals = [signal("exit", None, "zones"), signal("entry", "buy", "numeric")]
    assert dominant_entry_priority(signals, lambda item: PRIORITY[item.slot]) == 100


def test_no_entries_means_no_priority() -> None:
    assert dominant_entry_priority([signal("noop", None, "zones")], lambda item: 10) is None
