"""Numeric exit geometry: structure stop and zone-based target (same as S/R)."""

from __future__ import annotations

from goldbot.strategy_api import Zone
from strategies.numeric import NumericParams, NumericStrategy


def test_numeric_target_uses_the_next_zone() -> None:
    zone = Zone(high=2012.0, low=2010.0, score=80, zone_id="Z201000")
    reward, zone_id = NumericStrategy._zone_target("buy", 2000.0, 5.0, (zone,), 3.0, NumericParams())
    # 10 USD pool -> 9.5 -> below 2R -> clamped up to 2R = 10.
    assert reward == 10.0
    assert zone_id == "Z201000"


def test_numeric_target_picks_the_nearest_pool_for_sells() -> None:
    far = Zone(high=1952.0, low=1950.0, score=80, zone_id="Z195000")
    near = Zone(high=1992.0, low=1990.0, score=80, zone_id="Z199000")
    reward, zone_id = NumericStrategy._zone_target("sell", 2000.0, 5.0, (far, near), 3.0, NumericParams())
    assert reward == 10.0
    assert zone_id == "Z199000"


def test_numeric_target_falls_back_to_two_r() -> None:
    reward, zone_id = NumericStrategy._zone_target("buy", 2000.0, 5.0, (), 3.0, NumericParams())
    assert reward == 10.0
    assert zone_id == ""


def test_numeric_target_is_capped_at_three_r() -> None:
    zone = Zone(high=2101.0, low=2099.0, score=80, zone_id="Z210000")
    reward, zone_id = NumericStrategy._zone_target("buy", 2000.0, 5.0, (zone,), 3.0, NumericParams())
    assert reward == 15.0
    assert zone_id == "Z210000"
