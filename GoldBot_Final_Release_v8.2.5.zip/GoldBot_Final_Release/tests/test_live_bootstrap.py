"""Integration test: the engine runs on the live composition with a fake venue.

No order is sent (the fake venue only serves ticks and account truth); the test
guards the wiring that the live command relies on: injected broker/feed/clock,
broker-truth symbol metadata, warm-up seeding and a clean session journal.
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from pathlib import Path
from types import SimpleNamespace

from goldbot.adapters.clock import SystemClock
from goldbot.adapters.config import load_settings
from goldbot.adapters.mt5_broker import MT5Broker, load_history, seed_builder, symbol_info_from_broker
from goldbot.adapters.sqlite_store import SqliteJournal
from goldbot.domain.model import Symbol, Tick, Ts
from goldbot.runtime.bootstrap import build_components

from test_mt5_broker import FakeMT5


def _bars(fake: FakeMT5, now: datetime, count: int = 400) -> list[dict]:
    start = int(now.timestamp()) // 900 * 900 - count * 900
    rows = []
    price = 3800.0
    for index in range(count):
        price += 0.5
        rows.append(
            {
                "time": start + index * 900,
                "open": price,
                "high": price + 2.0,
                "low": price - 2.0,
                "close": price + 0.5,
                "tick_volume": 10,
                "spread": 5,
            }
        )
    return rows


class FiniteFeed:
    """A tick feed that ends, so the engine lifecycle can be observed in a test."""

    def __init__(self, symbol: str, ticks: list[Tick]) -> None:
        self._symbol = symbol
        self._ticks = ticks

    def stop(self) -> None:
        pass

    def stream(self):
        yield from self._ticks


def test_engine_runs_on_the_live_composition(scratch: Path):
    settings = load_settings("config/base.toml")
    now = datetime.now(tz=timezone.utc)
    fake = FakeMT5()
    fake.tick.time = int((now + timedelta(hours=2)).timestamp())
    info = symbol_info_from_broker(
        fake,
        broker_symbol="XAUUSD.st",
        logical_name="XAUUSD",
        broker_offset=timedelta(hours=2),
        fallback=settings.symbol_info(),
    )
    fake.rates[15] = _bars(fake, now)
    broker = MT5Broker(
        info,
        login=80180927,
        password="secret",
        server="ePlanet-MT5",
        mt5_module=fake,
    )
    broker.connect()
    clock = SystemClock(info)
    mid = float(fake.tick.bid)
    ticks = [
        Tick(
            symbol=Symbol("XAUUSD"),
            bid=mid,
            ask=mid + 0.7,
            ts_event=Ts(now + timedelta(seconds=index)),
            ts_recv=Ts(now + timedelta(seconds=index)),
            volume=2,
        )
        for index in range(30)
    ]

    def seed(builder) -> None:
        load = load_history(
            fake,
            broker_symbol=info.broker_symbol,
            info=info,
            timeframes=["M15"],
            offset=timedelta(hours=2),
            counts={"M15": 500},
        )
        assert seed_builder(builder, load) > 0

    components = build_components(
        settings,
        tape_path="",
        profile_name="medium",
        db_path=scratch / "live.db",
        state_db=scratch / "live_state.db",
        allow_cold_start=True,
        live_broker=broker,
        live_feed=FiniteFeed("XAUUSD", ticks),
        live_clock=clock,
        seed_history=seed,
        info_override=info,
    )
    result = components.engine.run()
    journal = SqliteJournal(scratch / "live.db")
    try:
        types = [event.type for event in journal.read_events(limit=1000)]
        signals = list(journal.signals())
        stats = journal.stats()
    finally:
        journal.close()
        components.close()
    assert result.ticks == 30
    assert "SessionStarted" in types
    assert "SessionFinished" in types
    assert signals == []
    assert stats["trades"] == 0
    # The engine closed the session and shut the terminal down.
    assert broker.is_ready() is False
    assert float(fake.account.equity) == 1100.0
