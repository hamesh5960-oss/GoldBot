from __future__ import annotations

import itertools
import os
import shutil
from pathlib import Path

import pytest

from goldbot.adapters.clock import SimulatedClock
from goldbot.adapters.fake_broker import FakeBroker
from goldbot.adapters.sqlite_store import SqliteJournal
from goldbot.app.position_manager import PositionManager
from goldbot.app.risk import RiskProfile, load_profiles, resolve_profile

from helpers import CONFIG, NOW, ROOT, make_info

_COUNTER = itertools.count(1)


def workdir(name: str = "case") -> Path:
    """Workspace-local scratch directory (the sandbox blocks pytest's temp root)."""
    # PID-scoped: two pytest processes in the same tree must not share scratch
    # directories (one run must never delete another run's fixture data).
    path = ROOT / "var" / "tests" / f"{name}-{os.getpid()}-{next(_COUNTER):03d}"
    if path.exists():
        shutil.rmtree(path, ignore_errors=True)
    path.mkdir(parents=True, exist_ok=True)
    return path


@pytest.fixture
def scratch() -> Path:
    return workdir()


@pytest.fixture
def info():
    return make_info()


@pytest.fixture
def profiles() -> dict[str, RiskProfile]:
    return load_profiles(CONFIG / "risk_profiles.toml")


@pytest.fixture
def profile(profiles: dict[str, RiskProfile]) -> RiskProfile:
    return resolve_profile("medium", profiles)[0]


@pytest.fixture
def journal(scratch: Path):
    store = SqliteJournal(scratch / "journal.db")
    yield store
    store.close()


@pytest.fixture
def clock(info) -> SimulatedClock:
    clock = SimulatedClock(NOW)
    clock.bind(info)
    return clock


@pytest.fixture
def broker(info) -> FakeBroker:
    return FakeBroker(info, balance=10_000.0)


@pytest.fixture
def positions(info) -> PositionManager:
    return PositionManager(mode="hedging", contract_size=info.contract_size)
