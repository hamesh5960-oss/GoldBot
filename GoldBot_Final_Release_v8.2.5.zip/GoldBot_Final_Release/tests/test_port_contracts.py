"""Port contracts: every adapter must satisfy the Protocol it claims.

These are structural checks (the Protocols are not runtime_checkable) plus the
behavioural minimum: connect/account/positions/submit/close for the venue,
append/read/count for the event store, save/load/clear for risk state, and a
send() that fails safe for every notifier.
"""

from __future__ import annotations

import sqlite3
from datetime import timedelta

import pytest
from helpers import NOW, make_info, make_tick

from goldbot.adapters.clock import SimulatedClock
from goldbot.adapters.fake_broker import FakeBroker
from goldbot.adapters.notifier import DedupNotifier, LogNotifier, MultiNotifier
from goldbot.adapters.sqlite_state_store import SqliteRiskStateStore
from goldbot.adapters.sqlite_store import SqliteJournal
from goldbot.domain.events import Event, TradeRecord
from goldbot.domain.execution import ApprovedOrder, RiskSnapshot
from goldbot.domain.model import Symbol, Ts
from goldbot.ports.risk import RiskState
from goldbot.ports.state import PersistedRiskState, StateCorruption

IBROKER_METHODS = (
    "connect",
    "disconnect",
    "health",
    "is_ready",
    "symbol_info",
    "account",
    "positions",
    "orders",
    "deals",
    "submit",
    "modify",
    "close",
    "find_by_client_ref",
    "on_market_tick",
)
IEVENTSTORE_METHODS = ("append", "read_events", "count")
IJOURNAL_METHODS = (
    "record_trade",
    "update_trade",
    "trade",
    "trades",
    "record_equity",
    "equity_curve",
    "stats",
)
ISTATE_METHODS = ("load", "save", "clear")
ICLOCK_METHODS = ("now", "broker_now", "drift", "to_broker", "to_utc", "session")
INOTIFIER_METHODS = ("send",)


def _has_methods(instance, methods) -> None:
    for name in methods:
        assert callable(getattr(instance, name, None)), f"{type(instance).__name__}.{name} missing"


def _order(
    *, price: float = 2000.0, stop_distance: float = 2.0, volume: float = 0.1, side: str = "buy"
) -> ApprovedOrder:
    sl = price - stop_distance if side == "buy" else price + stop_distance
    tp = price + 2.0 * stop_distance if side == "buy" else price - 2.0 * stop_distance
    return ApprovedOrder(
        intent_id="port-1",
        slot="unit",
        strategy="zones",
        symbol=Symbol("XAUUSD"),
        side=side,
        volume=volume,
        order_type="market",
        sl=sl,
        tp=tp,
        magic=77001,
        client_ref="gbport",
        max_slippage_points=20,
        risk=RiskSnapshot(
            equity=10_000.0,
            balance=10_000.0,
            risk_pct=0.1,
            risk_amount=10.0,
            stop_distance=stop_distance,
            volume=volume,
            spread_points=20.0,
        ),
    )


def _trade(trade_id: str = "trade-1") -> TradeRecord:
    return TradeRecord(
        trade_id=trade_id,
        slot="unit",
        strategy="zones",
        symbol="XAUUSD",
        side="buy",
        volume=0.1,
        open_time=NOW.isoformat(),
        close_time=(NOW + timedelta(hours=1)).isoformat(),
        open_price=2000.0,
        close_price=2002.0,
        sl=1998.0,
        tp=2004.0,
        pnl_gross=20.0,
        commission=-1.4,
        swap=0.0,
        pnl_net=18.6,
        spread_at_entry=0.2,
    )


class FakeNotifier:
    def __init__(self, *, delivers: bool = True, raises: bool = False) -> None:
        self.calls: list[tuple[str, str, str, str]] = []
        self.delivers = delivers
        self.raises = raises

    def send(self, level: str, title: str, body: str, *, dedup_key: str = "") -> bool:
        self.calls.append((level, title, body, dedup_key))
        if self.raises:
            raise RuntimeError("channel down")
        return self.delivers


class ManualClock:
    def __init__(self) -> None:
        self.value = 0.0

    def __call__(self) -> float:
        return self.value


# ---------------------------------------------------------------- broker


def test_fake_broker_satisfies_ibroker(scratch) -> None:
    broker = FakeBroker(make_info(), balance=10_000.0)
    _has_methods(broker, IBROKER_METHODS)

    connection = broker.connect()
    assert connection.server == "Fake-Demo"
    assert connection.trade_mode == "hedging"
    assert broker.is_ready() is True
    assert broker.health().alive is True
    assert broker.symbol_info(Symbol("XAUUSD")) is broker.info
    account = broker.account()
    assert account.currency == "USD"
    assert account.leverage == 100
    assert list(broker.positions()) == []
    assert list(broker.orders()) == []
    assert list(broker.deals(since=NOW - timedelta(days=1))) == []


def test_fake_broker_submit_and_close_roundtrip() -> None:
    broker = FakeBroker(make_info(), balance=10_000.0)
    broker.connect()
    broker.on_market_tick(make_tick(2000.0))

    ack = broker.submit(_order(), idempotency_key="open-1")
    assert ack.accepted is True
    assert ack.retcode_name == "DONE"
    assert ack.ticket is not None
    positions = list(broker.positions())
    assert len(positions) == 1
    assert positions[0].ticket == ack.ticket

    duplicate = broker.submit(_order(), idempotency_key="open-1")
    assert duplicate == ack
    assert len(list(broker.positions())) == 1

    closed = broker.close(ack.ticket, volume=None, idempotency_key="close-1")
    assert closed.accepted is True
    assert closed.closed_trade is not None
    assert list(broker.positions()) == []


def test_fake_broker_rejects_orders_inside_the_stops_level() -> None:
    broker = FakeBroker(make_info())
    broker.connect()
    broker.on_market_tick(make_tick(2000.0))
    too_close = _order(price=2000.0, stop_distance=0.05)  # stops level is 0.30
    ack = broker.submit(too_close, idempotency_key="bad-1")
    assert ack.accepted is False
    assert ack.retcode_name == "INVALID_STOPS"
    assert list(broker.positions()) == []


# ---------------------------------------------------------------- journal


def test_sqlite_journal_satisfies_ieventstore_and_ijournal(scratch) -> None:
    journal = SqliteJournal(scratch / "journal.db")
    try:
        _has_methods(journal, IEVENTSTORE_METHODS)
        _has_methods(journal, IJOURNAL_METHODS)

        first = journal.append(Event(type="TestEvent", payload={"a": 1}, ts=Ts(NOW)))
        assert first == 1
        second = journal.append(
            Event(type="OtherEvent", payload={"b": 2}, ts=Ts(NOW), correlation_id="corr-1")
        )
        assert second == 2
        assert journal.count() == 2
        typed = list(journal.read_events(type="TestEvent"))
        assert len(typed) == 1 and typed[0].payload == {"a": 1}
        correlated = list(journal.read_events(correlation_id="corr-1"))
        assert len(correlated) == 1 and correlated[0].type == "OtherEvent"
    finally:
        journal.close()


def test_sqlite_journal_trade_and_equity_projection(scratch) -> None:
    journal = SqliteJournal(scratch / "journal.db")
    try:
        journal.record_trade(_trade())
        stored = journal.trade("trade-1")
        assert stored is not None
        assert stored.trade_id == "trade-1"
        assert stored.pnl_net == pytest.approx(18.6)

        journal.update_trade("trade-1", close_price=2003.0, pnl_net=28.6)
        updated = journal.trade("trade-1")
        assert updated is not None and updated.pnl_net == pytest.approx(28.6)
        assert len(journal.trades()) == 1

        journal.record_equity(NOW.isoformat(), 10_020.0, 10_020.0)
        curve = journal.equity_curve()
        assert curve == [(NOW.isoformat(), 10_020.0, 10_020.0)]
        stats = journal.stats()
        assert stats["trades"] == 1
    finally:
        journal.close()


def test_sqlite_journal_survives_reopen(scratch) -> None:
    path = scratch / "journal.db"
    journal = SqliteJournal(path)
    journal.append(Event(type="BeforeCrash", payload={"x": 1}, ts=Ts(NOW)))
    journal.close()

    reopened = SqliteJournal(path)
    try:
        assert reopened.count() == 1
        events = list(reopened.read_events())
        assert events[0].type == "BeforeCrash"
        reopened.append(Event(type="AfterCrash", payload={"x": 2}, ts=Ts(NOW)))
        assert reopened.count() == 2
    finally:
        reopened.close()


# ------------------------------------------------------------ risk state


def test_sqlite_risk_state_store_satisfies_iriskstatestore(scratch) -> None:
    store = SqliteRiskStateStore(scratch / "risk_state.db")
    try:
        _has_methods(store, ISTATE_METHODS)
        assert store.load() is None

        state = PersistedRiskState(
            state=RiskState.HALTED,
            reason="daily loss",
            daily_pnl=-120.0,
            drawdown_pct=2.5,
            orders_today=3,
            updated_at=NOW.isoformat(),
        )
        store.save(state)
        loaded = store.load()
        assert loaded is not None
        assert loaded.state is RiskState.HALTED
        assert loaded.reason == "daily loss"
        assert loaded.daily_pnl == pytest.approx(-120.0)
        assert loaded.orders_today == 3

        store.clear()
        assert store.load() is None
    finally:
        store.close()


def test_sqlite_risk_state_store_reports_corruption(scratch) -> None:
    path = scratch / "risk_state.db"
    store = SqliteRiskStateStore(path)
    store.save(PersistedRiskState(state=RiskState.NORMAL, updated_at=NOW.isoformat()))
    store.close()

    raw = sqlite3.connect(path)
    raw.execute("UPDATE risk_state SET payload = ?", ("not-json",))
    raw.commit()
    raw.close()

    broken = SqliteRiskStateStore(path)
    try:
        with pytest.raises(StateCorruption):
            broken.load()
    finally:
        broken.close()

    version_path = scratch / "risk_state_version.db"
    versioned = SqliteRiskStateStore(version_path)
    versioned.save(PersistedRiskState(updated_at=NOW.isoformat()))
    versioned.close()
    raw = sqlite3.connect(version_path)
    raw.execute("UPDATE risk_state SET schema_version = 99")
    raw.commit()
    raw.close()
    mismatch = SqliteRiskStateStore(version_path)
    try:
        with pytest.raises(StateCorruption, match="schema"):
            mismatch.load()
    finally:
        mismatch.close()


# ------------------------------------------------------------------ clock


def test_simulated_clock_satisfies_iclock(info) -> None:
    clock = SimulatedClock(NOW)
    clock.bind(info)
    _has_methods(clock, ICLOCK_METHODS)

    assert clock.now() == Ts(NOW)
    assert clock.broker_now() == NOW + info.broker_offset
    drift = clock.drift()
    assert drift.suspect is False
    assert clock.to_broker(NOW) == NOW + info.broker_offset
    assert clock.to_utc(clock.to_broker(NOW)) == NOW
    assert clock.session(info.symbol).value == "OPEN"

    clock.advance(NOW + timedelta(minutes=5))
    assert clock.now().mono == pytest.approx(300.0)
    clock.advance(NOW)  # going backwards is ignored
    assert clock.now().mono == pytest.approx(300.0)


# ------------------------------------------------------------- notifiers


def test_log_notifier_satisfies_inotifier() -> None:
    notifier = LogNotifier()
    _has_methods(notifier, INOTIFIER_METHODS)
    assert notifier.send("info", "title", "body", dedup_key="k") is True


def test_dedup_notifier_satisfies_inotifier() -> None:
    inner = FakeNotifier()
    manual = ManualClock()
    notifier = DedupNotifier(inner, ttl_seconds=600, max_per_minute=10, monotonic=manual)
    _has_methods(notifier, INOTIFIER_METHODS)

    assert notifier.send("warn", "title", "body", dedup_key="same") is True
    assert notifier.send("warn", "title", "body", dedup_key="same") is False
    manual.value = 601.0
    assert notifier.send("warn", "title", "body", dedup_key="same") is True
    assert notifier.send("warn", "other", "body", dedup_key="different") is True
    assert notifier.inner is inner


def test_dedup_notifier_does_not_cache_failures() -> None:
    inner = FakeNotifier(delivers=False)
    notifier = DedupNotifier(inner, ttl_seconds=600, monotonic=ManualClock())
    assert notifier.send("critical", "t", "b", dedup_key="k") is False
    assert notifier.send("critical", "t", "b", dedup_key="k") is False
    assert len(inner.calls) == 2  # a failed delivery may be retried

    delivering = FakeNotifier()
    retry = DedupNotifier(delivering, ttl_seconds=600, monotonic=ManualClock())
    assert retry.send("critical", "t", "b", dedup_key="k") is True
    assert retry.send("critical", "t", "b", dedup_key="k") is False


def test_multi_notifier_fans_out_and_survives_a_broken_channel() -> None:
    broken = FakeNotifier(raises=True)
    healthy = FakeNotifier()
    multi = MultiNotifier([broken, healthy])
    _has_methods(multi, INOTIFIER_METHODS)

    assert multi.send("warn", "title", "body") is True
    assert len(broken.calls) == 1
    assert len(healthy.calls) == 1

    all_down = MultiNotifier([FakeNotifier(delivers=False), FakeNotifier(raises=True)])
    assert all_down.send("warn", "title", "body") is False
