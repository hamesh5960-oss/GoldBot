"""Every generated entry signal must appear in the signal journal.

Regression for the pre-decision filters: direction bias, entry priority,
confirm_only and structurally invalid intents never reach decide(), so before
this fix they left no row and the operator could not compare generated signals
with traded signals. Each of them must now be journaled as a filtered row whose
active_reason names the filter.
"""

from __future__ import annotations

import os
import shutil
from datetime import datetime, timezone
from pathlib import Path
from types import SimpleNamespace

import pytest

from goldbot.adapters.config import load_settings
from goldbot.adapters.tape import write_synthetic_tape
from goldbot.runtime.bootstrap import build_components
from goldbot.strategy_api.signals import entry_signal

from helpers import CONFIG, NOW, ROOT, make_tick

JOURNALED_DECISIONS = {"executed", "filtered", "rejected", "skipped", "d_hard_floor"}
FILTERED_REASONS = {
    "direction_long_only",
    "direction_short_only",
    "priority_skipped",
    "confirm_only",
    "invalid_intent",
}


def _work(name: str) -> Path:
    path = ROOT / "var" / "tests" / name
    if path.exists():
        shutil.rmtree(path, ignore_errors=True)
    path.mkdir(parents=True, exist_ok=True)
    return path


def _settings(direction: str):
    settings = load_settings(CONFIG / "base.toml")
    trading = settings.trading.model_copy(
        update={"min_confirmations": 1, "direction": direction}
    )
    return settings.model_copy(update={"trading": trading})


def _build(name: str, *, direction: str, days: int):
    tmp = _work(name)
    tape = tmp / "tape.jsonl"
    write_synthetic_tape(
        tape,
        symbol="XAUUSD",
        start=datetime(2024, 3, 3, tzinfo=timezone.utc),
        days=days,
        ticks_per_minute=2,
        seed=13,
    )
    settings = _settings(direction)
    return build_components(
        settings, tape_path=tape, profile_name="medium", db_path=tmp / "journal.db"
    )


def _run(name: str, *, direction: str, days: int):
    previous = os.getcwd()
    os.chdir(ROOT)
    try:
        comp = _build(name, direction=direction, days=days)
        try:
            result = comp.engine.run()
            signals = list(comp.journal.signals())
            trades = list(comp.journal.trades())
            events = list(comp.journal.read_events(limit=200_000))
        finally:
            comp.close()
        return result, signals, trades, events
    finally:
        os.chdir(previous)


@pytest.fixture(scope="module")
def run_both():
    return _run("completeness-both", direction="both", days=4)


@pytest.fixture(scope="module")
def run_long():
    return _run("completeness-long", direction="long", days=3)


def _trade_signal_id(trade) -> str:
    signal = trade.signal if isinstance(trade.signal, dict) else {}
    tags = signal.get("tags") if isinstance(signal.get("tags"), dict) else {}
    return str(tags.get("signal_id") or "")


def _binding(strategy_id: str, priority: int, *, confirm_only: bool = False):
    return SimpleNamespace(
        strategy_id=strategy_id,
        strategy=SimpleNamespace(priority=priority),
        confirm_only=confirm_only,
        risk_multiplier=1.0,
    )


class _StubHost:
    """Deterministic two-signal host: no strategies, just ordered fixtures."""

    def __init__(self, signals, bindings) -> None:
        self._signals = list(signals)
        self.bindings = dict(bindings)

    def on_bar(self, bar) -> list:
        return list(self._signals)


def test_every_generated_entry_signal_is_journaled(run_both) -> None:
    result, signals, _, events = run_both
    assert result.signals_seen > 0
    assert result.signals_journaled == result.signals_seen
    assert result.signals_unlogged == 0
    assert len(signals) == result.signals_seen
    assert len({signal.signal_id for signal in signals}) == len(signals)
    assert [event for event in events if event.type == "JournalGap"] == []


def test_journal_rows_carry_a_decision_and_a_reason(run_both) -> None:
    _, signals, _, _ = run_both
    assert signals
    assert all(signal.active_decision in JOURNALED_DECISIONS for signal in signals)
    assert all((signal.active_reason or "").strip() for signal in signals)
    assert all(signal.ts_utc and signal.session for signal in signals)


def test_session_finished_payload_matches_the_result(run_both) -> None:
    result, _, _, events = run_both
    finished = [event for event in events if event.type == "SessionFinished"]
    assert finished
    payload = dict(finished[-1].payload)
    assert payload["signals_seen"] == result.signals_seen
    assert payload["signals_journaled"] == result.signals_journaled
    assert payload["signals_unlogged"] == result.signals_unlogged == 0


def test_executed_signal_row_matches_the_trade_signal_id(run_both) -> None:
    _, signals, trades, _ = run_both
    executed = [signal for signal in signals if signal.active_decision == "executed"]
    assert executed
    trade_signal_ids = set()
    for trade in trades:
        signal_id = _trade_signal_id(trade)
        assert signal_id, "every trade row must carry the signal_id tag"
        trade_signal_ids.add(signal_id)
    assert {signal.signal_id for signal in executed} <= trade_signal_ids


def test_direction_bias_yields_filtered_rows(run_long) -> None:
    result, signals, _, events = run_long
    assert result.bias_blocked > 0
    filtered = [signal for signal in signals if signal.active_decision == "filtered"]
    assert filtered, "dir-bias filtered signals must be journaled"
    assert {signal.active_reason for signal in filtered} == {"direction_short_only"}
    assert all(signal.side == "sell" for signal in filtered)
    assert len(signals) == result.signals_seen
    assert result.signals_unlogged == 0
    assert [event for event in events if event.type == "JournalGap"] == []


def test_filtered_rows_reject_missed_and_tier_claims(run_long) -> None:
    _, signals, _, _ = run_long
    filtered = [signal for signal in signals if signal.active_decision == "filtered"]
    assert filtered
    for signal in filtered:
        assert signal.was_missed_opportunity is False
        assert signal.tier == ""
        assert signal.active_level
        assert signal.params_snapshot.get("config_hash")


def test_predecision_filter_reasons_are_recorded_verbatim() -> None:
    previous = os.getcwd()
    os.chdir(ROOT)
    try:
        # Two days: the synthetic tape starts on a Sunday, so a one-day tape has
        # no ticks and the fail-closed tape validation (correctly) refuses it.
        comp = _build("completeness-reasons", direction="both", days=2)
        try:
            engine = comp.engine
            tick = make_tick()
            ctx = engine._context(tick, NOW, atr=1.0)
            # priority skip + invalid intent in one bar: the dominant signal is
            # structurally invalid (stop on the wrong side), the other waits.
            engine._host = _StubHost(
                [
                    entry_signal(
                        slot="zones",
                        symbol="XAUUSD",
                        side="buy",
                        stop=2001.0,
                        target=2020.0,
                    ),
                    entry_signal(
                        slot="numeric_m15",
                        symbol="XAUUSD",
                        side="buy",
                        stop=1990.0,
                        target=2020.0,
                    ),
                ],
                {"zones": _binding("zones", 10), "numeric_m15": _binding("numeric", 20)},
            )
            engine._process_signals(None, tick, ctx)
            engine._host = _StubHost(
                [
                    entry_signal(
                        slot="sr_zone",
                        symbol="XAUUSD",
                        side="buy",
                        stop=1990.0,
                        target=2020.0,
                    )
                ],
                {"sr_zone": _binding("sr_zone", 5, confirm_only=True)},
            )
            engine._process_signals(None, tick, ctx)
            rows = list(comp.journal.signals())
            seen = engine.result.signals_seen
            journaled = engine.result.signals_journaled
            unlogged = engine.result.signals_unlogged
        finally:
            comp.close()
    finally:
        os.chdir(previous)

    assert [row.active_reason for row in rows] == [
        "invalid_intent",
        "priority_skipped",
        "confirm_only",
    ]
    assert all(row.active_decision == "filtered" for row in rows)
    assert len({row.signal_id for row in rows}) == len(rows)
    assert seen == journaled == len(rows) == 3
    assert unlogged == 0
    assert all(row.params_snapshot.get("config_hash") for row in rows)
