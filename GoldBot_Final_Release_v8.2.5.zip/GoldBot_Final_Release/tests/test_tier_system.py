"""Tier system (locked confirmation design): ladder, risk table and journaling.

Complements test_decision.py with the system-level view: the exact tier ladder
and risk table, the no-gate decide() path for every base band, and the
TierDecision journaling contract.
"""

from __future__ import annotations

from dataclasses import FrozenInstanceError

import pytest

from goldbot.app.decision import (
    TIER_ORDER,
    TIER_RISK_PCT,
    Tier,
    TierDecision,
    adjust_tier,
    decide,
)


def test_every_base_band_has_the_spec_risk() -> None:
    expected = (
        (0.0, Tier.D, 0.0),
        (1.0, Tier.C, 0.25),
        (2.0, Tier.B, 0.50),
        (3.0, Tier.A, 0.75),
        (4.0, Tier.A_PLUS, 1.0),
    )
    for count, base, risk in expected:
        decision = decide(confirmation_count=count)
        assert decision.tier_base is base
        assert decision.tier is base
        assert decision.risk_base_pct == risk


def test_tier_order_matches_the_enum_values() -> None:
    assert TIER_ORDER == (Tier.A_PLUS, Tier.A, Tier.B, Tier.C, Tier.D, Tier.NOISE)
    assert len(set(TIER_ORDER)) == len(TIER_ORDER) == 6
    assert set(TIER_ORDER) == set(Tier)


def test_risk_table_covers_every_tier() -> None:
    assert set(TIER_RISK_PCT) == set(Tier)
    assert TIER_RISK_PCT[Tier.A_PLUS] == 1.0
    assert TIER_RISK_PCT[Tier.A] == 0.75
    assert TIER_RISK_PCT[Tier.B] == 0.50
    assert TIER_RISK_PCT[Tier.C] == 0.25
    assert TIER_RISK_PCT[Tier.D] == 0.0
    assert TIER_RISK_PCT[Tier.NOISE] == 0.0
    # Risk falls with the tier all the way to the D floor.
    risks = [TIER_RISK_PCT[tier] for tier in TIER_ORDER]
    assert risks == sorted(risks, reverse=True)


def test_layer3_can_only_move_inside_the_window() -> None:
    window = {Tier.A_PLUS, Tier.A, Tier.B, Tier.C}
    for base in window:
        for delta in (-1, 0, 1):
            assert adjust_tier(base, delta) in window


def test_decide_records_the_base_even_when_a_hard_gate_fires() -> None:
    zone_filtered = decide(confirmation_count=3.0, zone_score=10.0)
    assert zone_filtered.tier is Tier.D
    assert zone_filtered.tier_base is Tier.A
    assert zone_filtered.downgraded is True
    rr_filtered = decide(confirmation_count=3.0, rr_net=0.0)
    assert rr_filtered.tier is Tier.NOISE
    assert rr_filtered.tier_base is Tier.A
    assert rr_filtered.rejected is True


def test_tier_decision_is_frozen_and_reasons_default_to_empty() -> None:
    decision = TierDecision(
        tier=Tier.B,
        tier_base=Tier.B,
        confirmation_count=2.0,
        confirmation_set=("a", "b"),
        layer3_score=0.0,
        layer3_delta=0,
        d_hard_floor=False,
        risk_base_pct=0.5,
    )
    assert decision.reasons == ()
    with pytest.raises(FrozenInstanceError):
        decision.tier = Tier.A  # type: ignore[misc]


def test_as_dict_rounds_and_lists_every_field() -> None:
    decision = decide(
        confirmation_count=2.5,
        layer3_score=0.61,
        zone_score=80.0,
        confirmation_set=("zone",),
    )
    assert decision.as_dict() == {
        "tier": "A",
        "tier_base": "B",
        "confirmation_count": 2.5,
        "confirmation_set": ["zone"],
        "layer3_score": 0.61,
        "layer3_delta": 1,
        "d_hard_floor": False,
        "risk_base_pct": 0.75,
        "reasons": ["tier_layer3_up"],
    }
    rounded = decide(confirmation_count=3.14159, layer3_score=0.70711).as_dict()
    assert rounded["confirmation_count"] == 3.142
    assert rounded["layer3_score"] == 0.707


def test_decide_is_deterministic_and_pure() -> None:
    first = decide(
        confirmation_count=2.5,
        layer3_score=0.6,
        zone_score=70.0,
        rr_net=1.2,
        confirmation_set=("a", "b"),
    )
    second = decide(
        confirmation_count=2.5,
        layer3_score=0.6,
        zone_score=70.0,
        rr_net=1.2,
        confirmation_set=("a", "b"),
    )
    assert first == second
    assert first is not second
