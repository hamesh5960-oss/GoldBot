from __future__ import annotations

from datetime import time as dt_time, timedelta
from pathlib import Path

import pytest

from goldbot.adapters.config import load_settings
from goldbot.adapters.mt5_broker import MT5Broker
from goldbot.domain.model import ConnectionInfo
from goldbot.runtime import live

from test_mt5_broker import FakeMT5

ROOT = Path(__file__).resolve().parents[1]


class _FakeMT5Broker:
    def __init__(self, info, **kwargs):
        self.info = info
        self.offset = timedelta(hours=2)
        self.mt5 = object()
        self.disconnected = False

    def connect(self):
        return ConnectionInfo(server="Demo", login=123, trade_mode="hedging",
                             broker_offset=self.offset, terminal="fake")

    def is_demo(self):
        return True

    def positions(self):
        return ()

    def orders(self):
        return ()

    def disconnect(self):
        self.disconnected = True



def test_live_setup_failure_still_disconnects_broker(scratch, monkeypatch):
    settings = load_settings(ROOT / "config/base.toml")
    instances = []

    def make_broker(info, **kwargs):
        broker = _FakeMT5Broker(info, **kwargs)
        instances.append(broker)
        return broker

    monkeypatch.setattr(live, "MT5Broker", make_broker)
    monkeypatch.setattr(live, "_wait_for_fresh_tick", lambda *a, **k: None)
    monkeypatch.setattr(live, "symbol_info_from_broker", lambda *a, **k: (_ for _ in ()).throw(RuntimeError("metadata failure")))

    with pytest.raises(RuntimeError, match="metadata failure"):
        live.run_live(settings, login=123, password="test-only", server="Demo",
                      db_path=scratch / "live.db", state_db=scratch / "fresh.db",
                      cold_start=True, wait_open_seconds=0)

    assert instances and instances[0].disconnected is True


# -- D1: no state DB and no explicit --cold-start must stop before MT5 -----
def test_run_live_refuses_missing_state_db_without_cold_start(scratch, monkeypatch):
    settings = load_settings(ROOT / "config/base.toml")

    def forbidden(*args, **kwargs):
        raise AssertionError("MT5 must not connect when the state DB is missing")

    monkeypatch.setattr(live, "MT5Broker", forbidden)
    missing = scratch / "missing_state.db"
    result = live.run_live(
        settings,
        login=123,
        password="test-only",
        server="Demo",
        db_path=scratch / "live.db",
        state_db=missing,
        cold_start=False,
    )
    assert result == 2
    assert not missing.exists()


# -- SES-03: the synthetic session placeholder is refused for live ----------
def _session_broker_factory(fake):
    instances = []

    def make_broker(info, **kwargs):
        broker = MT5Broker(
            info,
            login=80180927,
            password="secret",
            server="ePlanet-MT5",
            mt5_module=fake,
        )
        instances.append(broker)
        return broker

    return make_broker, instances


class _ReachedComposition(Exception):
    pass


def test_run_live_refuses_the_placeholder_session_table(scratch, monkeypatch, capsys):
    # The shipped config now carries the real ePlanet week; this test needs the
    # synthetic placeholder explicitly to prove the live guard rejects it.
    settings = load_settings(ROOT / "config/base.toml")
    settings = settings.model_copy(
        update={"symbol": settings.symbol.model_copy(update={"sessions": ["00:00-23:59"]})}
    )
    fake = FakeMT5()
    make_broker, instances = _session_broker_factory(fake)
    monkeypatch.setattr(live, "MT5Broker", make_broker)
    monkeypatch.setattr(live, "_wait_for_fresh_tick", lambda *a, **k: None)

    result = live.run_live(
        settings,
        login=80180927,
        password="secret",
        server="ePlanet-MT5",
        broker_symbol="XAUUSD.st",
        db_path=scratch / "live.db",
        state_db=scratch / "fresh.db",
        cold_start=True,
        wait_open_seconds=0,
    )
    captured = capsys.readouterr().out
    assert result == 2
    assert "جدول سشن" in captured
    assert fake.sent == [], "no order may be sent on a refused session table"
    assert instances and instances[0].is_ready() is False


def test_run_live_proceeds_with_an_explicit_real_session_table(scratch, monkeypatch):
    settings = load_settings(ROOT / "config/base.toml")
    settings = settings.model_copy(
        update={
            "symbol": settings.symbol.model_copy(update={"sessions": ["01:00-23:00"]})
        }
    )
    fake = FakeMT5()
    # Monday..Friday have the real window; the venue is closed at the weekend.
    fake.symbol.session_trade = [
        [(dt_time(1, 0), dt_time(23, 0))] for _ in range(5)
    ] + [[], []]
    make_broker, instances = _session_broker_factory(fake)
    monkeypatch.setattr(live, "MT5Broker", make_broker)
    monkeypatch.setattr(live, "_wait_for_fresh_tick", lambda *a, **k: None)

    def probe(*args, **kwargs):
        raise _ReachedComposition("composition root reached")

    monkeypatch.setattr(live, "build_components", probe)
    with pytest.raises(_ReachedComposition):
        live.run_live(
            settings,
            login=80180927,
            password="secret",
            server="ePlanet-MT5",
            broker_symbol="XAUUSD.st",
            db_path=scratch / "live.db",
            state_db=scratch / "fresh.db",
            cold_start=True,
            wait_open_seconds=0,
        )
    assert instances and instances[0].is_ready() is False


def test_cold_start_is_refused_when_state_database_already_exists(scratch, monkeypatch):
    settings = load_settings(ROOT / "config/base.toml")
    state_db = scratch / "risk_state.db"
    state_db.write_bytes(b"existing-state")

    def forbidden_broker(*args, **kwargs):
        raise AssertionError("MT5 must not connect when cold-start is invalid")

    monkeypatch.setattr(live, "MT5Broker", forbidden_broker)
    result = live.run_live(settings, login=123, password="test-only", server="Demo",
                           db_path=scratch / "live.db", state_db=state_db, cold_start=True)
    assert result == 2


def test_cold_start_is_refused_when_broker_has_open_position(scratch, monkeypatch):
    settings = load_settings(ROOT / "config/base.toml")
    instances = []

    class _BrokerWithPosition(_FakeMT5Broker):
        def positions(self):
            return (object(),)

    def make_broker(info, **kwargs):
        broker = _BrokerWithPosition(info, **kwargs)
        instances.append(broker)
        return broker

    monkeypatch.setattr(live, "MT5Broker", make_broker)
    result = live.run_live(settings, login=123, password="test-only", server="Demo",
                           db_path=scratch / "live.db", state_db=scratch / "fresh.db", cold_start=True)
    assert result == 2
    assert instances and instances[0].disconnected is True


def test_cold_start_fails_closed_and_disconnects_if_broker_state_cannot_be_read(scratch, monkeypatch):
    settings = load_settings(ROOT / "config/base.toml")
    instances = []

    class _BrokerWithUnknownState(_FakeMT5Broker):
        def positions(self):
            raise RuntimeError("positions unavailable")

    def make_broker(info, **kwargs):
        broker = _BrokerWithUnknownState(info, **kwargs)
        instances.append(broker)
        return broker

    monkeypatch.setattr(live, "MT5Broker", make_broker)
    result = live.run_live(settings, login=123, password="test-only", server="Demo",
                           db_path=scratch / "live.db", state_db=scratch / "fresh.db", cold_start=True)
    assert result == 2
    assert instances and instances[0].disconnected is True
