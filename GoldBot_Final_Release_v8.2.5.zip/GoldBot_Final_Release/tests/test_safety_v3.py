"""P0 safety primitives: symbol metadata, retcodes, broker time and checks."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone

import pytest

from goldbot.adapters.clock import SimulatedClock
from goldbot.adapters.time_service import TimeService
from goldbot.app.risk.capital import CapitalParams, event_factor
from goldbot.app.risk.checks import check_broker_stops, check_reconciliation
from goldbot.domain.errors import InvariantError
from goldbot.domain.retcodes import RetcodeAction, classify
from goldbot.domain.symbol_meta import SymbolMeta

from helpers import NOW, make_context, make_info

INFO = make_info()


def test_symbol_meta_roundtrip_and_validation() -> None:
    meta = SymbolMeta.from_symbol_info(INFO)
    meta.validate()
    assert meta.stops_level_points == 30
    assert meta.stops_level_price == pytest.approx(0.30)
    broken = SymbolMeta(
        name="XAUUSD", digits=2, point=0.0, contract_size=100.0,
        volume_min=0.01, volume_max=50.0, volume_step=0.01,
        stops_level_points=0, freeze_level_points=0,
    )
    with pytest.raises(InvariantError):
        broken.validate()


def test_retcode_table_is_fail_closed() -> None:
    assert classify(10009) is RetcodeAction.DONE
    assert classify(10004) is RetcodeAction.RETRY_PRICE
    assert classify(10016) is RetcodeAction.RETRY_STOPS
    assert classify(10019) is RetcodeAction.ABORT
    assert classify(99999) is RetcodeAction.QUARANTINE


def test_broker_stops_are_independent_of_profile() -> None:
    assert check_broker_stops(0.30, 0.60, INFO).ok
    assert not check_broker_stops(0.20, 0.60, INFO).ok
    assert not check_broker_stops(0.30, 0.20, INFO).ok


def test_reconciliation_check_is_fail_closed() -> None:
    ctx = make_context(INFO)
    assert check_reconciliation(ctx).ok
    from dataclasses import replace

    assert not check_reconciliation(replace(ctx, reconciled=False)).ok


def test_time_service_exposes_three_clocks() -> None:
    clock = SimulatedClock(NOW)
    clock.bind(INFO)
    service = TimeService(clock)
    assert service.utc.hour == 10
    assert service.broker.hour == 12
    assert service.trading_day() == "2024-03-04"


def test_rollover_uses_broker_time_not_utc() -> None:
    utc_midnight = datetime(2024, 3, 4, 0, 0, tzinfo=timezone.utc)
    broker_at_utc_midnight = datetime(2024, 3, 4, 2, 0, tzinfo=timezone.utc)
    utc_evening = datetime(2024, 3, 4, 22, 0, tzinfo=timezone.utc)
    broker_midnight = datetime(2024, 3, 5, 0, 0, tzinfo=timezone.utc)
    # 00:00 UTC is 02:00 broker => not rollover; 22:00 UTC is 00:00 broker => blocked.
    assert event_factor(utc_midnight, "ny", False, CapitalParams())[1] is True
    assert (
        event_factor(
            utc_midnight, "ny", False, CapitalParams(), broker_now=broker_at_utc_midnight
        )[1]
        is False
    )
    assert (
        event_factor(utc_evening, "ny", False, CapitalParams(), broker_now=broker_midnight)[1]
        is True
    )


def test_triple_swap_blackout() -> None:
    wednesday_evening = datetime(2024, 3, 6, 20, 30, tzinfo=timezone.utc)
    assert event_factor(wednesday_evening, "ny", False, CapitalParams())[1] is True
