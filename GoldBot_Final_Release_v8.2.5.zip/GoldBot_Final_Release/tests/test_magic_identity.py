"""CONF-02: the order magic must be a restart-stable identity.

The magic is the only ownership marker reconciliation has. Deriving it from
Python's salted hash() means a restart sees its own orders as foreign. The
identity lives in app.ids.magic_for_slot (crc32 of the canonical slot string,
bucket 1..8999); app.signal_pipeline.stable_magic and RiskEngine order sealing
both delegate to it, and ORDER_APPROVED journals the magic plus MAGIC_SCHEME.
"""

from __future__ import annotations

import os
import subprocess
import sys
import tomllib
from pathlib import Path

from goldbot.app.ids import (
    GOLDBOT_MAGIC_BASE,
    MAGIC_SCHEME,
    MAGIC_USABLE_BUCKETS,
    magic_for_slot,
    owns_position_magic,
)
from goldbot.app.signal_pipeline import SignalPipeline, stable_magic

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"

# Configured slots plus the slot names used by the historical strategies/tests.
KNOWN_SLOTS: tuple[str, ...] = (
    "zones_m15",
    "numeric_m15",
    "fvg_m15",
    "rect_m15",
    "zones",
    "numeric",
    "fvg",
    "rect",
    "sr_zone",
    "unit",
)


def _configured_slots() -> tuple[str, ...]:
    slots: list[str] = []
    for path in sorted((ROOT / "config" / "strategies").glob("*.toml")):
        data = tomllib.loads(path.read_text(encoding="utf-8"))
        slot = data.get("slot")
        if isinstance(slot, str):
            slots.append(slot)
    return tuple(slots)


def test_configured_strategy_slots_are_discovered() -> None:
    configured = _configured_slots()
    assert configured, "no strategy slot found in config/strategies"
    assert set(configured) <= set(KNOWN_SLOTS)


def test_magic_is_never_bucket_zero_and_inside_the_ownership_envelope() -> None:
    low = (GOLDBOT_MAGIC_BASE % 2_000) * 10_000
    for slot in KNOWN_SLOTS:
        magic = magic_for_slot(slot)
        assert magic == magic_for_slot(slot), "magic must be deterministic"
        assert low < magic <= low + MAGIC_USABLE_BUCKETS
        assert 1 <= magic - low <= MAGIC_USABLE_BUCKETS
        # Never the bare ownership base (bucket 0 is reserved).
        assert magic != low
        assert owns_position_magic(magic)
    # Legacy compatibility: the ownership envelope still spans bucket 0; the
    # generator never produces it, but owns_position_magic stays range-based.
    assert owns_position_magic(low)
    assert not owns_position_magic(low + MAGIC_USABLE_BUCKETS + 1)


def test_known_slots_have_unique_magics() -> None:
    slots = tuple(dict.fromkeys(KNOWN_SLOTS + _configured_slots()))
    magics = [magic_for_slot(slot) for slot in slots]
    assert len(set(magics)) == len(magics), "known slots must be collision-free"


def test_magic_matches_the_locked_golden_values() -> None:
    # Locks the scheme: any change is a documented, journaled migration.
    assert magic_for_slot("zones_m15") == 13_005_391
    assert magic_for_slot("numeric_m15") == 13_004_161
    assert MAGIC_SCHEME == "crc32-slot-v1"


def test_magic_is_stable_across_processes_with_different_hash_seeds() -> None:
    slots_repr = repr(KNOWN_SLOTS)
    code = (
        "import sys; sys.path.insert(0, 'src');"
        "from goldbot.app.ids import magic_for_slot;"
        "from goldbot.app.signal_pipeline import stable_magic;"
        f"print(','.join(str(magic_for_slot(s)) for s in {slots_repr}));"
        f"print(','.join(str(stable_magic(s)) for s in {slots_repr}))"
    )
    outputs: list[str] = []
    for seed in ("0", "12345"):
        env = {**os.environ, "PYTHONHASHSEED": seed, "PYTHONPATH": str(SRC)}
        result = subprocess.run(
            [sys.executable, "-c", code],
            cwd=str(ROOT),
            env=env,
            capture_output=True,
            text=True,
            check=True,
        )
        outputs.append(result.stdout.strip())
    assert outputs[0] == outputs[1], "magic must not depend on PYTHONHASHSEED"
    ids_line, pipeline_line = outputs[0].splitlines()
    expected = ",".join(str(magic_for_slot(slot)) for slot in KNOWN_SLOTS)
    assert ids_line == expected
    assert pipeline_line == expected


def test_signal_pipeline_delegates_to_the_single_identity() -> None:
    for slot in KNOWN_SLOTS:
        assert stable_magic(slot) == magic_for_slot(slot)
        assert SignalPipeline().magic_for(slot) == magic_for_slot(slot)


def test_custom_base_keeps_the_slot_bucket() -> None:
    bucket = magic_for_slot("zones_m15") % 10_000
    assert magic_for_slot("zones_m15", base=42) % 10_000 == bucket
    assert owns_position_magic(magic_for_slot("zones_m15", base=42), base=42)


def test_risk_engine_seals_and_journals_the_stable_magic(profile, journal, clock, info) -> None:
    from goldbot.app.risk_engine import RiskEngine
    from goldbot.domain.execution import EntryIntent
    from goldbot.domain.model import Symbol
    from helpers import NOW, make_context

    engine = RiskEngine(profile, journal=journal, clock=clock)
    engine.begin(10_000.0, NOW)
    intent = EntryIntent(
        intent_id="magic-1",
        slot="fvg_m15",
        strategy="fvg",
        symbol=Symbol("XAUUSD"),
        side="buy",
        entry_ref=2000.2,
        stop=1990.0,
        target=2020.4,
        risk_multiplier=1.0,
        signal={},
        created_at=NOW,
    )
    decision = engine.evaluate_entry(intent, make_context(info))
    assert decision.order is not None, decision.reasons
    expected = magic_for_slot("fvg_m15", engine._magic_base)
    assert decision.order.magic == expected
    events = [e for e in journal.read_events() if e.type == "OrderIntentApproved"]
    assert events, "the approved order must be journaled"
    payload = events[-1].payload
    assert payload["magic"] == expected
    assert payload["magic_scheme"] == MAGIC_SCHEME
    assert payload["slot"] == "fvg_m15"
