"""Risk profiles and manual overrides must fail closed."""

from __future__ import annotations

from pathlib import Path

import pytest
from pydantic import ValidationError

from goldbot.app.risk import ABSOLUTE_MAX, load_profiles, resolve_profile, validate_consistency
from goldbot.app.risk.profiles import (
    DEFAULT_ALLOWED_TIERS,
    MAX_TIER_RISK_CAP_PCT,
    VALID_TIER_KEYS,
    RiskProfile,
)
from goldbot.domain.errors import ConfigError

CONFIG = Path(__file__).resolve().parents[1] / "config"


def make_profile(**overrides) -> RiskProfile:
    """A minimal valid profile; tests override only what they exercise."""
    values = dict(
        name="test",
        risk_per_trade_pct=1.0,
        max_daily_loss_pct=2.0,
        max_total_dd_pct=10.0,
        max_positions=2,
        max_positions_per_symbol=1,
        max_positions_per_slot=1,
        max_orders_per_day=10,
        max_spread_points=30,
        min_rr=1.0,
        max_leverage=10,
        min_sl_points=30,
        max_sl_points=3000,
        stale_tick_seconds=20,
        max_consecutive_losses=3,
        news_blackout_minutes=20,
        breakeven_after_r=1.0,
        trail_after_r=1.2,
        trail_atr_mult=2.0,
        max_holding_hours=48,
    )
    values.update(overrides)
    return RiskProfile(**values)


def test_three_profiles_exist_and_are_consistent() -> None:
    profiles = load_profiles(CONFIG / "risk_profiles.toml")
    assert set(profiles) == {"low", "medium", "high"}
    for p in profiles.values():
        validate_consistency(p)


def test_risk_grows_from_low_to_high() -> None:
    profiles = load_profiles(CONFIG / "risk_profiles.toml")
    assert profiles["low"].risk_per_trade_pct < profiles["medium"].risk_per_trade_pct
    assert profiles["medium"].risk_per_trade_pct < profiles["high"].risk_per_trade_pct
    assert profiles["low"].max_positions <= profiles["medium"].max_positions <= profiles["high"].max_positions


def test_override_inside_bounds_is_applied() -> None:
    profiles = load_profiles(CONFIG / "risk_profiles.toml")
    profile, applied = resolve_profile("low", profiles, {"risk_per_trade_pct": 0.4})
    assert profile.risk_per_trade_pct == 0.4
    assert profile.name == "low+manual"
    assert applied[0].field == "risk_per_trade_pct"
    assert applied[0].value == 0.4


def test_override_outside_bounds_is_rejected() -> None:
    profiles = load_profiles(CONFIG / "risk_profiles.toml")
    with pytest.raises(ConfigError):
        resolve_profile("low", profiles, {"risk_per_trade_pct": 9.0})


def test_override_cannot_exceed_absolute_ceiling() -> None:
    profiles = load_profiles(CONFIG / "risk_profiles.toml")
    with pytest.raises(ConfigError):
        resolve_profile("high", profiles, {"max_positions": 50})
    assert ABSOLUTE_MAX["risk_per_trade_pct"] == 3.0


def test_unknown_override_key_is_rejected() -> None:
    profiles = load_profiles(CONFIG / "risk_profiles.toml")
    with pytest.raises(ConfigError):
        resolve_profile("low", profiles, {"not_a_field": 1})


def test_tier_override_is_applied() -> None:
    profiles = load_profiles(CONFIG / "risk_profiles.toml")
    profile, applied = resolve_profile(
        "low",
        profiles,
        {"allowed_tiers": ["A+"], "tier_risk_caps": {"A+": 0.5}},
    )
    assert profile.allowed_tiers == ("A+",)
    assert profile.tier_risk_caps == {"A+": 0.5}
    assert {item.field for item in applied} == {"allowed_tiers", "tier_risk_caps"}


@pytest.mark.parametrize(
    "overrides",
    [
        {"allowed_tiers": ["A+", "Z"]},
        {"allowed_tiers": ["A+", "A+"]},
        {"allowed_tiers": ["noise"]},
        {"tier_risk_caps": {"D+": 0.5}},
        {"tier_risk_caps": {"A": -0.1}},
        {"tier_risk_caps": {"A": 2.0}},
    ],
)
def test_invalid_tier_matrix_is_rejected(overrides: dict) -> None:
    with pytest.raises(ValidationError):
        make_profile(**overrides)


@pytest.mark.parametrize(
    "overrides",
    [
        {"allowed_tiers": ["Z"]},
        {"tier_risk_caps": {"A": 2.0}},
    ],
)
def test_invalid_tier_override_is_rejected(overrides: dict) -> None:
    profiles = load_profiles(CONFIG / "risk_profiles.toml")
    with pytest.raises(ConfigError):
        resolve_profile("low", profiles, overrides)


def test_tier_vocabulary_is_locked() -> None:
    assert DEFAULT_ALLOWED_TIERS == ("A+", "A", "B", "C", "D")
    assert VALID_TIER_KEYS == frozenset({"A+", "A", "B", "C", "D"})
    assert MAX_TIER_RISK_CAP_PCT == 1.5


def test_tier_matrix_defaults_to_all_tradable_tiers() -> None:
    profile = make_profile()
    assert profile.allowed_tiers == DEFAULT_ALLOWED_TIERS
    assert profile.tier_risk_caps == {}


def test_locked_matrix_is_loaded_from_config() -> None:
    profiles = load_profiles(CONFIG / "risk_profiles.toml")
    expected = {
        "low": (
            ("A+", "A"),
            {"A+": 0.75, "A": 0.50},
            1.5,
        ),
        "medium": (
            ("A+", "A", "B", "C"),
            {"A+": 1.0, "A": 0.75, "B": 0.50, "C": 0.25},
            3.0,
        ),
        "high": (
            ("A+", "A", "B", "C"),
            {"A+": 1.0, "A": 0.75, "B": 0.50, "C": 0.25},
            3.0,
        ),
    }
    for name, (allowed, caps, open_cap) in expected.items():
        assert profiles[name].allowed_tiers == allowed
        assert profiles[name].tier_risk_caps == caps
        assert profiles[name].max_open_risk_pct == open_cap


def test_high_profile_keeps_the_envelope_but_a_plus_cap_is_one() -> None:
    profiles = load_profiles(CONFIG / "risk_profiles.toml")
    high = profiles["high"]
    assert high.risk_per_trade_pct == 1.5
    assert high.tier_risk_caps["A+"] == 1.0


def test_concurrency_and_daily_loss_limits_are_unchanged() -> None:
    # ADR-037: the locked matrix must not silently loosen position count or the
    # daily loss cap. Values are the pre-T14 ones (task text quoted 2/2/3 but
    # the repo baseline is 1/2/2; the invariant is "unchanged", so the baseline
    # wins and the Lead is told about the mismatch).
    profiles = load_profiles(CONFIG / "risk_profiles.toml")
    assert [profiles[name].max_positions for name in ("low", "medium", "high")] == [1, 2, 2]
    assert [
        profiles[name].max_daily_loss_pct for name in ("low", "medium", "high")
    ] == [1.0, 2.0, 4.0]


def test_inconsistent_profile_is_rejected() -> None:
    bad = make_profile(risk_per_trade_pct=2.0, max_daily_loss_pct=1.0, max_positions=3)
    with pytest.raises(ConfigError):
        validate_consistency(bad)


def test_unknown_profile_name_is_rejected() -> None:
    profiles = load_profiles(CONFIG / "risk_profiles.toml")
    with pytest.raises(ConfigError):
        resolve_profile("aggressive", profiles, {})
