"""Heartbeat file plus the external watchdog that reacts to a stale one."""

from __future__ import annotations

import importlib.util
import json
import os
import sys
from datetime import datetime, timedelta
from typing import Any

import pytest

from goldbot.app.heartbeat import EV_HEARTBEAT, Heartbeat, heartbeat_path_for
from goldbot.domain.model import Ts
from helpers import NOW, ROOT


class FakeJournal:
    def __init__(self, error: BaseException | None = None) -> None:
        self.events: list[Any] = []
        self.error = error

    def append(self, event: Any, *, fsync: bool = True) -> int:
        if self.error is not None:
            raise self.error
        self.events.append(event)
        return len(self.events)


class FakeNotifier:
    def __init__(self) -> None:
        self.calls: list[tuple[str, str, str]] = []

    def send(self, level: str, title: str, body: str, *, dedup_key: str = "") -> bool:
        self.calls.append((level, title, body))
        return True


def heartbeat_for(scratch: Any, clock: Any, **kwargs: Any) -> Heartbeat:
    return Heartbeat(scratch / "heartbeat.json", clock, **kwargs)


# -- atomic write ----------------------------------------------------------


def test_beat_writes_the_record(scratch: Any, clock: Any) -> None:
    heartbeat = heartbeat_for(scratch, clock)
    record = heartbeat.beat({"equity": 10000.0})
    path = scratch / "heartbeat.json"
    assert path.exists()
    data = json.loads(path.read_text(encoding="utf-8"))
    assert data == record
    assert data["pid"] == os.getpid()
    assert data["payload"] == {"equity": 10000.0}
    assert datetime.fromisoformat(data["ts"]) == NOW


def test_beat_leaves_no_temporary_file(scratch: Any, clock: Any) -> None:
    heartbeat_for(scratch, clock).beat({"x": 1})
    leftovers = [entry.name for entry in scratch.iterdir() if entry.suffix == ".tmp"]
    assert leftovers == []


def test_beat_replaces_the_target_atomically(scratch: Any, clock: Any, monkeypatch: Any) -> None:
    import goldbot.app.heartbeat as heartbeat_module

    target = scratch / "heartbeat.json"
    real_replace = os.replace
    seen: list[tuple[str, str]] = []

    def spy(source: Any, destination: Any) -> None:
        seen.append((str(source), str(destination)))
        real_replace(source, destination)

    monkeypatch.setattr(heartbeat_module.os, "replace", spy)
    heartbeat_for(scratch, clock).beat({"x": 1})
    assert len(seen) == 1
    source, destination = seen[0]
    assert destination == str(target)
    assert source != destination
    assert not os.path.exists(source)


def test_beat_creates_missing_parent_directories(scratch: Any, clock: Any) -> None:
    path = scratch / "nested" / "deeper" / "heartbeat.json"
    Heartbeat(path, clock).beat({"x": 1})
    assert path.exists()


def test_beat_overwrites_previous_record(scratch: Any, clock: Any) -> None:
    heartbeat = heartbeat_for(scratch, clock)
    heartbeat.beat({"step": 1})
    clock.advance(NOW + timedelta(seconds=60))
    heartbeat.beat({"step": 2})
    data = json.loads((scratch / "heartbeat.json").read_text(encoding="utf-8"))
    assert data["payload"] == {"step": 2}
    assert datetime.fromisoformat(data["ts"]) == NOW + timedelta(seconds=60)


# -- throttle --------------------------------------------------------------


def test_first_beat_is_always_due(scratch: Any, clock: Any) -> None:
    assert heartbeat_for(scratch, clock).should_beat(clock.now()) is True


def test_should_beat_throttles_until_interval(scratch: Any, clock: Any) -> None:
    heartbeat = heartbeat_for(scratch, clock, interval_seconds=300)
    heartbeat.beat()
    clock.advance(NOW + timedelta(seconds=299))
    assert heartbeat.should_beat(clock.now()) is False
    clock.advance(NOW + timedelta(seconds=301))
    assert heartbeat.should_beat(clock.now()) is True


# -- staleness -------------------------------------------------------------


def test_is_stale_missing_file(scratch: Any, clock: Any) -> None:
    stale, age, data = Heartbeat.is_stale(scratch / "absent.json", NOW, 900)
    assert stale is True
    assert age is None
    assert data == {}


def test_is_stale_corrupt_file(scratch: Any, clock: Any) -> None:
    path = scratch / "heartbeat.json"
    path.write_text("not json at all", encoding="utf-8")
    stale, age, data = Heartbeat.is_stale(path, NOW, 900)
    assert (stale, age, data) == (True, None, {})


def test_is_stale_rejects_missing_timestamp(scratch: Any, clock: Any) -> None:
    path = scratch / "heartbeat.json"
    path.write_text(json.dumps({"pid": 1, "payload": {}}), encoding="utf-8")
    stale, age, _ = Heartbeat.is_stale(path, NOW, 900)
    assert stale is True
    assert age is None


def test_is_stale_rejects_bad_timestamp(scratch: Any, clock: Any) -> None:
    path = scratch / "heartbeat.json"
    path.write_text(json.dumps({"ts": "yesterday", "pid": 1}), encoding="utf-8")
    stale, age, _ = Heartbeat.is_stale(path, NOW, 900)
    assert stale is True
    assert age is None


def test_is_stale_old_file(scratch: Any, clock: Any) -> None:
    path = scratch / "heartbeat.json"
    heartbeat_for(scratch, clock).beat({"x": 1})
    stale, age, data = Heartbeat.is_stale(path, NOW + timedelta(seconds=901), 900)
    assert stale is True
    assert age == pytest.approx(901.0)
    assert data["pid"] == os.getpid()


def test_is_stale_fresh_file(scratch: Any, clock: Any) -> None:
    path = scratch / "heartbeat.json"
    heartbeat_for(scratch, clock).beat()
    stale, age, data = Heartbeat.is_stale(path, NOW + timedelta(seconds=10), 900)
    assert stale is False
    assert age == pytest.approx(10.0)
    assert "ts" in data


def test_is_stale_accepts_ts_objects(scratch: Any, clock: Any) -> None:
    path = scratch / "heartbeat.json"
    heartbeat_for(scratch, clock).beat()
    moment = Ts(NOW + timedelta(seconds=120))
    stale, age, _ = Heartbeat.is_stale(path, moment, 900)
    assert stale is False
    assert age == pytest.approx(120.0)


def test_is_stale_now_uses_instance_max_age(scratch: Any, clock: Any) -> None:
    heartbeat = heartbeat_for(scratch, clock, max_age_seconds=60)
    heartbeat.beat()
    clock.advance(NOW + timedelta(seconds=61))
    stale, age, _ = heartbeat.is_stale_now()
    assert stale is True
    assert age == pytest.approx(61.0)


# -- journal (optional) ----------------------------------------------------


def test_journal_event_only_when_journal_is_passed(scratch: Any, clock: Any) -> None:
    journal = FakeJournal()
    heartbeat = heartbeat_for(scratch, clock, journal=journal)
    heartbeat.beat({"equity": 1.0})
    assert len(journal.events) == 1
    event = journal.events[0]
    assert event.type == EV_HEARTBEAT == "Heartbeat"
    assert event.payload == {"pid": os.getpid(), "payload": {"equity": 1.0}}
    assert event.ts.wall == NOW

    heartbeat_for(scratch, clock, journal=None).beat()
    assert len(journal.events) == 1


def test_journal_failure_does_not_break_the_beat(scratch: Any, clock: Any) -> None:
    journal = FakeJournal(error=RuntimeError("journal broke"))
    heartbeat = heartbeat_for(scratch, clock, journal=journal)
    record = heartbeat.beat({"x": 1})
    assert record["payload"] == {"x": 1}
    assert (scratch / "heartbeat.json").exists()


# -- watchdog --------------------------------------------------------------


def _load_watchdog() -> Any:
    path = ROOT / "scripts" / "watchdog.py"
    spec = importlib.util.spec_from_file_location("goldbot_watchdog", path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules["goldbot_watchdog"] = module
    spec.loader.exec_module(module)
    return module


@pytest.fixture
def watchdog() -> Any:
    return _load_watchdog()


def _stale_heartbeat(scratch: Any, clock: Any) -> Any:
    path = scratch / "heartbeat.json"
    heartbeat_for(scratch, clock).beat({"equity": 1000.0})
    return path


def test_watchdog_fresh_heartbeat_exits_zero(watchdog: Any, scratch: Any, clock: Any, capsys: Any) -> None:
    path = _stale_heartbeat(scratch, clock)
    code = watchdog.main(
        ["--heartbeat", str(path), "--no-notify"],
        now=NOW + timedelta(seconds=60),
        environ={},
    )
    assert code == 0
    assert "fresh" in capsys.readouterr().out


def test_watchdog_stale_heartbeat_exits_one(watchdog: Any, scratch: Any, clock: Any, capsys: Any) -> None:
    path = _stale_heartbeat(scratch, clock)
    code = watchdog.main(
        ["--heartbeat", str(path), "--no-notify"],
        now=NOW + timedelta(seconds=3600),
        environ={},
    )
    assert code == 1
    output = capsys.readouterr().out
    assert "stale" in output
    assert "3600s" in output


def test_watchdog_missing_heartbeat_exits_one_as_json(
    watchdog: Any, scratch: Any, capsys: Any
) -> None:
    code = watchdog.main(
        ["--heartbeat", str(scratch / "absent.json"), "--json", "--no-notify"],
        now=NOW,
        environ={},
    )
    assert code == 1
    payload = json.loads(capsys.readouterr().out)
    assert payload["status"] == "stale"
    assert payload["age_seconds"] is None
    assert "missing" in payload["reason"]
    assert payload["notified"] is False


def test_watchdog_corrupt_heartbeat_exits_one(
    watchdog: Any, scratch: Any, capsys: Any
) -> None:
    path = scratch / "heartbeat.json"
    path.write_text("{broken", encoding="utf-8")
    code = watchdog.main(["--heartbeat", str(path), "--no-notify"], now=NOW, environ={})
    assert code == 1
    assert "unreadable" in capsys.readouterr().out


def test_watchdog_respects_max_age_flag(watchdog: Any, scratch: Any, clock: Any, capsys: Any) -> None:
    path = _stale_heartbeat(scratch, clock)
    moment = NOW + timedelta(seconds=120)

    def run(max_age: str) -> int:
        return watchdog.main(
            ["--heartbeat", str(path), "--max-age", max_age, "--no-notify"],
            now=moment,
            environ={},
        )

    assert run("900") == 0
    capsys.readouterr()
    assert run("60") == 1
    assert "stale" in capsys.readouterr().out


def test_watchdog_notifies_configured_channel(
    watchdog: Any, scratch: Any, clock: Any, monkeypatch: Any
) -> None:
    path = _stale_heartbeat(scratch, clock)
    notifier = FakeNotifier()
    monkeypatch.setattr(watchdog, "from_env", lambda environ=None: notifier)
    code = watchdog.main(
        ["--heartbeat", str(path), "--json"],
        now=NOW + timedelta(seconds=3600),
        environ={"GOLDBOT_TELEGRAM_TOKEN": "x", "GOLDBOT_TELEGRAM_CHAT_ID": "y"},
    )
    assert code == 1
    assert len(notifier.calls) == 1
    level, title, body = notifier.calls[0]
    assert level == "critical"
    assert "heartbeat" in title.lower()
    assert "stale" in body


def test_watchdog_no_notify_skips_channels(
    watchdog: Any, scratch: Any, clock: Any, monkeypatch: Any
) -> None:
    path = _stale_heartbeat(scratch, clock)

    def forbidden(environ: Any = None) -> Any:
        raise AssertionError("notification must not be attempted")

    monkeypatch.setattr(watchdog, "from_env", forbidden)
    code = watchdog.main(
        ["--heartbeat", str(path), "--no-notify"],
        now=NOW + timedelta(seconds=3600),
        environ={},
    )
    assert code == 1


def test_watchdog_fresh_never_notifies(
    watchdog: Any, scratch: Any, clock: Any, monkeypatch: Any
) -> None:
    path = _stale_heartbeat(scratch, clock)

    def forbidden(environ: Any = None) -> Any:
        raise AssertionError("fresh heartbeat must not alert")

    monkeypatch.setattr(watchdog, "from_env", forbidden)
    code = watchdog.main(["--heartbeat", str(path)], now=NOW + timedelta(seconds=10), environ={})
    assert code == 0


def test_watchdog_falls_back_when_engine_package_is_broken(
    watchdog: Any, scratch: Any, monkeypatch: Any, capsys: Any
) -> None:
    path = scratch / "heartbeat.json"
    path.write_text(
        json.dumps({"ts": NOW.isoformat(), "pid": 123, "payload": {}}),
        encoding="utf-8",
    )
    monkeypatch.setattr(watchdog, "Heartbeat", None)
    assert watchdog.main(["--heartbeat", str(path), "--no-notify"], now=NOW, environ={}) == 0
    capsys.readouterr()
    stale = watchdog.main(
        ["--heartbeat", str(path), "--no-notify", "--json"],
        now=NOW + timedelta(seconds=3600),
        environ={},
    )
    assert stale == 1
    payload = json.loads(capsys.readouterr().out)
    assert payload["status"] == "stale"
    assert payload["pid"] == 123


def test_heartbeat_path_is_derived_from_the_journal(scratch) -> None:
    """OBS-01: one heartbeat file per journal; demo/backtest cannot beat for live."""
    live = heartbeat_path_for(scratch / "live.db")
    demo = heartbeat_path_for(scratch / "goldbot.db")
    assert live == scratch / "live.db.heartbeat.json"
    assert demo == scratch / "goldbot.db.heartbeat.json"
    assert live != demo
    assert live.parent == demo.parent == scratch


def test_watchdog_survives_broken_notifier_import(
    watchdog: Any, scratch: Any, clock: Any, monkeypatch: Any, capsys: Any
) -> None:
    path = _stale_heartbeat(scratch, clock)
    monkeypatch.setattr(watchdog, "from_env", None)
    code = watchdog.main(["--heartbeat", str(path)], now=NOW + timedelta(seconds=3600), environ={})
    assert code == 1
    assert "alert: not sent" in capsys.readouterr().out
