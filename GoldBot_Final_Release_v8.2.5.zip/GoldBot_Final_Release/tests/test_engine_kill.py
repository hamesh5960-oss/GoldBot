"""Engine-level kill switch: when KILLED, open exposure must actually go away."""

from __future__ import annotations

import os
import shutil
from datetime import datetime, timezone
from pathlib import Path

import pytest

from goldbot.adapters.config import load_settings
from goldbot.adapters.tape import write_synthetic_tape
from goldbot.domain.execution import EntryIntent
from goldbot.domain.model import Symbol
from goldbot.runtime.bootstrap import build_components

from helpers import CONFIG, ROOT


@pytest.fixture
def components():
    previous = os.getcwd()
    os.chdir(ROOT)
    work = ROOT / "var" / "tests" / "kill"
    if work.exists():
        shutil.rmtree(work, ignore_errors=True)
    work.mkdir(parents=True, exist_ok=True)
    tape = work / "tape.jsonl"
    write_synthetic_tape(
        tape,
        symbol="XAUUSD",
        start=datetime(2024, 3, 4, 10, tzinfo=timezone.utc),
        days=1,
        ticks_per_minute=1,
        seed=3,
    )
    settings = load_settings(CONFIG / "base.toml")
    comp = build_components(settings, tape_path=tape, profile_name="medium", db_path=work / "j.db")
    comp.engine.start()
    yield comp
    comp.close()
    os.chdir(previous)


def test_flatten_closes_every_position(components) -> None:
    comp = components
    tick = next(iter(comp.engine._feed.stream()))
    comp.clock.advance(tick.ts_event.wall)
    comp.broker.on_market_tick(tick)

    info = comp.info
    comp.engine._last_reconcile_ok = tick.ts_event.wall
    ctx = comp.engine._context(tick, tick.ts_event.wall, atr=2.0)
    intent = EntryIntent(
        intent_id="kill-1",
        slot="manual_test",
        strategy="zones",
        symbol=Symbol("XAUUSD"),
        side="buy",
        entry_ref=round(tick.ask, 2),
        stop=round(tick.ask - 8.0, 2),
        target=round(tick.ask + 16.0, 2),
        risk_multiplier=1.0,
        signal={"rationale": "kill test"},
        created_at=tick.ts_event.wall,
    )
    decision = comp.risk.evaluate_entry(intent, ctx)
    assert decision.approved, f"setup order rejected: {decision.reasons}"

    comp.coordinator.execute(decision.order)
    assert comp.positions.count() == 1
    assert len(comp.broker.positions()) == 1

    comp.engine._flatten("kill")

    assert comp.positions.count() == 0
    assert len(comp.broker.positions()) == 0
    closed = [t for t in comp.journal.trades() if t.close_time]
    assert closed and closed[0].exit_reason == "kill"
