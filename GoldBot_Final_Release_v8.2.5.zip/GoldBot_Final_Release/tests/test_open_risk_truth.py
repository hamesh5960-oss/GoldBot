"""CL-04 proof: broker positions without risk-engine metadata must not size to 0.

Evidence (read-only):
* engine._context() builds RiskContext(positions=self._broker.positions()), i.e.
  the unfiltered broker snapshot (engine.py:234-253), and
* RiskEngine.register_position() is only called after the engine's own fill ack
  (engine.py:1215-1240), and
* reconciliation explicitly models "missing"/"orphan" positions
  (engine.py:204-214).

Manual, foreign-magic or restart-adopted orphan positions therefore appear in
ctx.positions with no _ticket_meta entry. Before this fix they contributed 0.0
open risk, silently enlarging the Gate D budget. The engine now counts each
untracked position at the worst-case per-trade cap and journals a warning.
"""

from __future__ import annotations

import pytest

from goldbot.app.risk.capital import CapitalParams
from goldbot.app.risk_engine import RiskEngine
from goldbot.domain.execution import EntryIntent
from goldbot.domain.model import PositionSnapshot, Symbol
from goldbot.ports.risk import Verdict

from helpers import NOW, make_account, make_context


def _intent() -> EntryIntent:
    return EntryIntent(
        intent_id="open-risk-1",
        slot="fvg_m15",
        strategy="fvg",
        symbol=Symbol("XAUUSD"),
        side="buy",
        entry_ref=2000.2,
        stop=1990.0,
        target=2020.4,
        risk_multiplier=1.0,
        signal={"rationale": "open-risk-truth"},
        created_at=NOW,
    )


def _position(ticket: int, *, magic: int = 1) -> PositionSnapshot:
    return PositionSnapshot(
        ticket=ticket,
        symbol=Symbol("XAUUSD"),
        side="buy",
        volume=0.01,
        open_price=2000.0,
        sl=1990.0,
        tp=None,
        magic=magic,
        comment="manual-or-foreign" if magic != 1 else "",
        open_time=NOW,
    )


def _engine(profile, journal, clock, capital: CapitalParams | None = None) -> RiskEngine:
    engine = RiskEngine(profile, journal=journal, clock=clock, capital=capital)
    engine.begin(10_000.0, NOW)
    return engine


def test_untracked_positions_are_counted_at_the_worst_case_cap(
    profile, journal, clock, info
) -> None:
    engine = _engine(profile, journal, clock)
    ctx = make_context(info, positions=[_position(101), _position(102, magic=555)])
    # Medium: worst case = min(risk_ceiling 1.5, trade_risk_cap 1.0) = 1.0% each.
    assert engine._open_risk_pct(ctx) == pytest.approx(2.0)


def test_tracked_positions_keep_their_exact_registered_risk(
    profile, journal, clock, info
) -> None:
    engine = _engine(profile, journal, clock)
    engine.register_position(7, risk_amount=50.0, initial_stop=1990.0, slot="fvg_m15")
    ctx = make_context(info, positions=[_position(7)])
    assert engine._open_risk_pct(ctx) == pytest.approx(0.5)
    events = [e for e in journal.read_events() if e.type == "DivergenceDetected"]
    assert events == [], "tracked positions must not emit an untracked warning"


def test_untracked_warning_is_journalled_only_once(
    profile, journal, clock, info
) -> None:
    engine = _engine(profile, journal, clock)
    ctx = make_context(info, positions=[_position(101), _position(102)])
    engine._open_risk_pct(ctx)
    engine._open_risk_pct(ctx)
    events = [
        e
        for e in journal.read_events()
        if e.type == "DivergenceDetected"
        and (e.payload or {}).get("kind") == "untracked_open_positions"
    ]
    assert len(events) == 1
    payload = events[0].payload
    assert payload["tickets"] == [101, 102]
    assert payload["untracked_count"] == 2
    assert payload["worst_case_pct"] == pytest.approx(1.0)


def test_untracked_positions_reject_a_new_entry(
    profile, journal, clock, info
) -> None:
    engine = _engine(profile, journal, clock)
    # Two untracked positions = 2.0% worst-case open risk, equal to the default
    # Gate D hard line, so there is no budget left for a new position.
    ctx = make_context(info, positions=[_position(101), _position(102, magic=555)])
    decision = engine.evaluate_entry(_intent(), ctx)
    assert decision.verdict is Verdict.REJECT
    assert "gate_d_total_risk" in decision.reasons
    assert decision.order is None


def test_untracked_position_can_only_shrink_the_new_size(
    profile, journal, clock, info
) -> None:
    # soft 1% / hard 2%: one untracked position (1.0%) pushes the new 1.0% trade
    # over the soft line, so it must be halved; without it the full size is used.
    soft = CapitalParams(gate_d_max_risk_pct=1.0)
    clean = _engine(profile, journal, clock, capital=soft).evaluate_entry(
        _intent(), make_context(info)
    )
    noisy = _engine(profile, journal, clock, capital=soft).evaluate_entry(
        _intent(), make_context(info, positions=[_position(101)])
    )
    assert clean.order is not None, clean.reasons
    assert noisy.order is not None, noisy.reasons
    assert noisy.order.volume < clean.order.volume
    assert noisy.order.risk.risk_amount < clean.order.risk.risk_amount


def test_foreign_magic_position_is_not_ignored(
    profile, journal, clock, info
) -> None:
    engine = _engine(profile, journal, clock)
    foreign = _position(9001, magic=4242)
    ctx = make_context(info, positions=[foreign])
    # An EA/manual position is exactly the untracked case: risk 1.0%, not 0.
    assert engine._open_risk_pct(ctx) == pytest.approx(1.0)


def test_untracked_positions_do_not_require_margin_or_equity(
    profile, journal, clock, info
) -> None:
    # Fail-closed accounting must not divide by a zero/negative equity.
    engine = _engine(profile, journal, clock)
    ctx = make_context(
        info,
        positions=[_position(101)],
        account=make_account(equity=0.0, balance=0.0, free_margin=0.0),
    )
    assert engine._open_risk_pct(ctx) == 0.0
