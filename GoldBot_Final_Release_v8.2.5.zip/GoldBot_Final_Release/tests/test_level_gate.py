"""Capital-level gate: tightens entries, keeps BASE locked by default."""

from __future__ import annotations

from datetime import datetime, timezone

from goldbot.app.capital_levels import CapitalLevel, LevelConfig, LevelState
from goldbot.app.level_gate import LevelGate, from_settings

from helpers import CONFIG

from goldbot.adapters.config import load_settings

NOW = datetime(2024, 3, 8, 12, 0, tzinfo=timezone.utc)


def _config(**overrides) -> LevelConfig:
    base = dict(
        low_risk_threshold=1500.0,
        medium_risk_threshold=2000.0,
        high_risk_threshold=4000.0,
        base_enabled=False,
    )
    base.update(overrides)
    return LevelConfig(**base)


def _gate(**overrides) -> LevelGate:
    gate = LevelGate(config=_config(**overrides), enabled=True)
    gate.state = LevelState(active_level=CapitalLevel.HIGH_RISK)
    return gate


def test_disabled_gate_allows_everything() -> None:
    gate = LevelGate(config=_config(), enabled=False)
    assert gate.active(10_000.0) is None
    assert gate.tier_allowed("noise") is True
    assert gate.amplifier_allowed() is True
    assert gate.max_trades_per_day() is None
    assert gate.session_allowed("asia") is True


def test_high_level_allows_all_tiers_and_amplifies() -> None:
    gate = _gate()
    assert gate.active(10_000.0) is CapitalLevel.HIGH_RISK
    for tier in ("A+", "A", "B", "C"):
        assert gate.tier_allowed(tier) is True
    assert gate.tier_allowed("watch") is False
    assert gate.amplifier_allowed() is True
    assert gate.max_trades_per_day() == 3


def test_low_level_blocks_b_and_asia() -> None:
    gate = _gate()
    gate.state.active_level = CapitalLevel.LOW_RISK
    assert gate.tier_allowed("B") is False
    assert gate.tier_allowed("A") is True
    assert gate.session_allowed("asia") is False
    assert gate.session_allowed("london") is True
    assert gate.amplifier_allowed() is False
    assert gate.max_trades_per_day() == 2


def test_base_is_locked_without_arming_and_ack() -> None:
    gate = _gate(base_enabled=True)
    gate.state.active_level = CapitalLevel.BASE
    assert gate.active(100.0) is None
    assert gate.stop_reason(100.0) == "base_locked"
    gate.base_armed = True
    assert gate.active(100.0) is None  # onboarding still missing
    gate.set_onboarding_ack(True)
    assert gate.active(100.0) is CapitalLevel.BASE
    assert gate.active(250.0) is None  # above the BASE ladder


def test_step_downgrades_on_drawdown() -> None:
    gate = _gate()
    gate.state.active_level = CapitalLevel.HIGH_RISK
    decision = gate.step(
        equity=10_000.0,
        drawdown_pct=25.0,
        consecutive_losses=1,
        open_positions=0,
        now=NOW,
    )
    assert decision is not None
    assert decision.action == "downgrade"
    assert gate.state.active_level is CapitalLevel.MEDIUM_RISK
    assert gate.dirty() is not None


def test_proposal_approve_and_decline() -> None:
    gate = _gate()
    gate.state.active_level = CapitalLevel.LOW_RISK
    gate.state.pending_level = CapitalLevel.MEDIUM_RISK
    gate.state.pending_since = NOW
    assert gate.approve(NOW) is True
    assert gate.state.active_level is CapitalLevel.MEDIUM_RISK
    gate.state.pending_level = CapitalLevel.HIGH_RISK
    gate.state.pending_since = NOW
    assert gate.decline(NOW) is True
    assert gate.state.decline_until is not None


def test_snapshot_roundtrip() -> None:
    gate = _gate()
    gate.state.previous_band = 2
    gate.state.trades_in_level = 4
    payload = gate.snapshot()
    other = LevelGate(config=_config(), enabled=True)
    assert other.restore(payload) is True
    assert other.state.active_level is CapitalLevel.HIGH_RISK
    assert other.state.previous_band == 2
    assert other.state.trades_in_level == 4


def test_from_settings_never_enables_implicitly() -> None:
    settings = load_settings(CONFIG / "base.toml")
    gate = from_settings(settings)
    assert gate.enabled is settings.levels.enabled
    assert gate.base_armed is settings.levels.base_armed
    assert gate.config.base_enabled is settings.levels.base_enabled
