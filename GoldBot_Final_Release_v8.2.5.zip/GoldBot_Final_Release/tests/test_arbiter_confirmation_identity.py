"""ADR-041 confirmation identity plus engine wiring for CONF-03/04/05.

These tests pin the confirmation-path contracts the audit found broken:
  * strategy identity is never a slot id (ADR-041);
  * only strictly earlier signals are visible (no look-ahead);
  * sr_zone needs score AND distance for both strategy paths (ADR-035);
  * the layer-3 EMA200 vote needs a real 200-bar history and a slope;
  * the journal stores the real zone score, not the retired Decision.zone_score_adj.
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from types import SimpleNamespace

from goldbot.app.arbiter import SignalArbiter, has_other_strategy_confirmation
from goldbot.app.decision import decide
from goldbot.app.engine import TradingEngine
from goldbot.domain.execution import EntryIntent
from goldbot.domain.model import Bar, Symbol
from goldbot.strategy_api.signals import entry_signal
from goldbot.strategy_api.zones import Zone
from helpers import NOW, make_context, make_info, make_tick

T0 = datetime(2024, 3, 4, 10, 0, tzinfo=timezone.utc)


def _engine(**attributes):
    engine = object.__new__(TradingEngine)
    for name, value in attributes.items():
        setattr(engine, name, value)
    return engine


def _h1_bars(closes: list[float]) -> list[Bar]:
    bars: list[Bar] = []
    for index, close in enumerate(closes):
        bars.append(
            Bar(
                symbol="XAUUSD",  # type: ignore[arg-type]
                timeframe="H1",  # type: ignore[arg-type]
                open_time=NOW + timedelta(hours=index),
                o=close,
                h=close + 0.2,
                l=close - 0.2,
                c=close,
                tick_volume=10,
            )
        )
    return bars


# -- ADR-041 identity ------------------------------------------------------


def test_arbiter_returns_strategy_ids_never_slot_ids() -> None:
    arbiter = SignalArbiter(window_minutes=30)
    arbiter.register(ts=T0, slot="zones_m15", strategy="zones", symbol="XAUUSD", side="buy")
    later = arbiter.confirmations(
        ts=T0 + timedelta(minutes=5), strategy="numeric", symbol="XAUUSD", side="buy"
    )
    assert later == ("zones",)
    assert "zones_m15" not in later


def test_same_strategy_never_confirms_itself() -> None:
    arbiter = SignalArbiter(window_minutes=30)
    arbiter.register(ts=T0, slot="zones_m15", strategy="zones", symbol="XAUUSD", side="buy")
    arbiter.register(ts=T0 + timedelta(minutes=5), slot="zones_h1", strategy="zones",
                     symbol="XAUUSD", side="buy")
    later = arbiter.confirmations(
        ts=T0 + timedelta(minutes=10), strategy="numeric", symbol="XAUUSD", side="buy"
    )
    assert later == ("zones",)


def test_has_other_strategy_confirmation_uses_strategy_identity() -> None:
    assert has_other_strategy_confirmation(("zones",), "zones") is False
    assert has_other_strategy_confirmation(("numeric", "zones"), "zones") is True
    assert has_other_strategy_confirmation(("numeric",), "zones") is True


# -- no look-ahead / strict ordering --------------------------------------


def test_same_timestamp_does_not_confirm() -> None:
    arbiter = SignalArbiter(window_minutes=30)
    arbiter.register(ts=T0, slot="zones_m15", strategy="zones", symbol="XAUUSD", side="buy")
    assert arbiter.confirmations(ts=T0, strategy="numeric", symbol="XAUUSD", side="buy") == ()
    arbiter.register(ts=T0, slot="numeric_m15", strategy="numeric", symbol="XAUUSD", side="buy")


def test_future_signal_is_not_visible() -> None:
    arbiter = SignalArbiter(window_minutes=30)
    arbiter.register(ts=T0 + timedelta(minutes=10), slot="zones_m15", strategy="zones",
                     symbol="XAUUSD", side="buy")
    assert arbiter.confirmations(ts=T0, strategy="numeric", symbol="XAUUSD", side="buy") == ()


def test_confirmations_read_is_read_only() -> None:
    arbiter = SignalArbiter(window_minutes=30)
    arbiter.register(ts=T0, slot="zones_m15", strategy="zones", symbol="XAUUSD", side="buy")
    before = len(arbiter.recent())
    assert arbiter.confirmations(ts=T0 + timedelta(minutes=5), strategy="numeric",
                                 symbol="XAUUSD", side="buy") == ("zones",)
    assert arbiter.confirmations(ts=T0 + timedelta(minutes=5), strategy="numeric",
                                 symbol="XAUUSD", side="buy") == ("zones",)
    assert len(arbiter.recent()) == before


def test_window_boundary_is_inclusive() -> None:
    arbiter = SignalArbiter(window_minutes=30)
    arbiter.register(ts=T0, slot="zones_m15", strategy="zones", symbol="XAUUSD", side="buy")
    at_boundary = arbiter.confirmations(
        ts=T0 + timedelta(minutes=30), strategy="numeric", symbol="XAUUSD", side="buy"
    )
    assert at_boundary == ("zones",)
    after = arbiter.confirmations(
        ts=T0 + timedelta(minutes=30, seconds=1), strategy="numeric", symbol="XAUUSD", side="buy"
    )
    assert after == ()


# -- CONF-03: sr_zone distance for both strategy paths --------------------


def test_zones_signal_far_zone_is_not_confirmed() -> None:
    near = Zone(high=2005.0, low=1995.0, score=60, source="auto")
    engine = _engine(
        _zones=[near], _min_zone_confirmation=50, _zone_confirmation_max_atr=2.0
    )
    signal = entry_signal(
        slot="zones_m15", symbol="XAUUSD", side="buy", stop=1990.0, target=2020.0,
        tags={"signal_score": 1.2, "zone_id": near.zone_id, "zone_score": 60},
    )
    _, tags = engine._enrich_signal(signal, "zones", make_tick(price=2000.0), 2.0)
    assert tags["zone_confirmed"] is True

    far = Zone(high=2105.0, low=2095.0, score=60, source="auto")
    engine._zones = [far]
    far_signal = entry_signal(
        slot="zones_m15", symbol="XAUUSD", side="buy", stop=1990.0, target=2020.0,
        tags={"signal_score": 1.2, "zone_id": far.zone_id, "zone_score": 60},
    )
    _, far_tags = engine._enrich_signal(far_signal, "zones", make_tick(price=2000.0), 2.0)
    assert far_tags["zone_confirmed"] is False


def test_numeric_signal_confirms_only_the_near_zone() -> None:
    near = Zone(high=2005.0, low=1995.0, score=60, source="auto")
    engine = _engine(
        _zones=[near], _min_zone_confirmation=50, _zone_confirmation_max_atr=2.0
    )
    signal = entry_signal(slot="numeric_m15", symbol="XAUUSD", side="buy", stop=1990.0,
                          target=2020.0)
    _, tags = engine._enrich_signal(signal, "numeric", make_tick(price=2000.0), 2.0)
    assert tags["zone_confirmed"] is True

    far = Zone(high=2105.0, low=2095.0, score=60, source="auto")
    engine._zones = [far]
    _, far_tags = engine._enrich_signal(signal, "numeric", make_tick(price=2000.0), 2.0)
    assert far_tags["zone_confirmed"] is False
    assert int(far_tags.get("zone_score", 0) or 0) == 0


# -- CONF-05: EMA200-H1 layer-3 vote --------------------------------------


def test_layer3_ema200_requires_real_history_and_slope() -> None:
    engine = _engine(_regime_state=None)
    ctx = make_context(make_info())

    short = _h1_bars([100.0 + index for index in range(199)])
    assert engine._layer3_votes({}, ctx, short, "buy", 300.0)["ema200_h1"] == 0

    exactly_200 = _h1_bars([100.0 + index for index in range(200)])
    assert engine._layer3_votes({}, ctx, exactly_200, "buy", 300.0)["ema200_h1"] == 0

    rising = _h1_bars([100.0 + index for index in range(210)])
    votes = engine._layer3_votes({}, ctx, rising, "buy", 320.0)
    assert votes["ema200_h1"] == 1
    assert engine._layer3_votes({}, ctx, rising, "sell", 320.0)["ema200_h1"] == -1

    flat = _h1_bars([200.0] * 210)
    assert engine._layer3_votes({}, ctx, flat, "buy", 210.0)["ema200_h1"] == 0


# -- CONF-04: journal stores the real zone score --------------------------


def test_signal_journal_stores_the_real_zone_score() -> None:
    engine = _engine(
        _info=make_info(),
        _config_hash="cfg",
        _profile_name="medium",
        _level_gate=None,
        _session_offset_hours=0.0,
        _pending_signal=None,
        _slippage_points=0.0,
        _commission_per_lot=7.0,
        _risk=SimpleNamespace(orders_today=0, drawdown_pct=0.0, consecutive_losses=0),
    )
    tags = {"zone_score": 72.0, "zone_id": "Z0000000", "signal_score": 1.1}
    decision = decide(confirmation_count=3.0, zone_score=72.0)
    assert not hasattr(decision, "zone_score_adj")  # retired field (CONF-04)

    ctx = make_context(make_info(), tick=make_tick(price=2000.0), atr=2.0)
    intent = EntryIntent(
        intent_id="i1",
        slot="zones_m15",
        strategy="zones",
        symbol=Symbol("XAUUSD"),
        side="buy",
        entry_ref=2000.0,
        stop=1990.0,
        target=2020.0,
        risk_multiplier=1.0,
        signal={"tags": tags},
        created_at=NOW,
    )
    engine._prepare_signal_journal(intent, decision, ctx, (), tags)

    pending = engine._pending_signal
    assert pending is not None
    record = pending["record"]
    assert record.zone_score_raw == 72.0
    assert record.zone_score_adj == 72.0
    assert all(level.zone_score_adj == 72.0 for level in pending["levels"])
