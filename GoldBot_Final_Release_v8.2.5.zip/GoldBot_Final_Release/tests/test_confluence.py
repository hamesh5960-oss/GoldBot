"""Confirmation contract regression: arbiter identity, factors, layer 3, magic.

Replaces the retired v2 confluence tests. The new contract is:
  * only five independent factors + an other-strategy approval form the count;
  * layer 3 is a separate ±0.6-capped vote (ADR-033/035);
  * rejected signals never confirm a later signal (CONF-01);
  * order magic is deterministic across processes (CONF-02).
"""

from __future__ import annotations

import os
import subprocess
import sys
from datetime import datetime, timedelta, timezone

import pytest

from goldbot.adapters.sqlite_store import SqliteJournal
from goldbot.app.arbiter import SignalArbiter, has_other_strategy_confirmation
from goldbot.app.confirmations import (
    FACTOR_NAMES,
    ema200_h1_vote,
    evaluate_confirmations,
    layer3_score,
    zone_confirms_layer3,
)
from goldbot.app.decision import decide
from goldbot.app.signal_pipeline import SignalPipeline, stable_magic
from goldbot.domain.events import TradeRecord
from goldbot.domain.model import Bar
from helpers import ROOT

T0 = datetime(2024, 3, 4, 10, 0, tzinfo=timezone.utc)


def _bar(index: int, o: float, h: float, low: float, c: float) -> Bar:
    return Bar(
        symbol="XAUUSD",  # type: ignore[arg-type]
        timeframe="M15",  # type: ignore[arg-type]
        open_time=T0 + timedelta(minutes=15 * index),
        o=o,
        h=h,
        l=low,
        c=c,
        tick_volume=10,
    )


def _closes(n: int, start: float = 2000.0, step: float = 0.5) -> list[Bar]:
    out: list[Bar] = []
    price = start
    for index in range(n):
        nxt = price + step
        out.append(_bar(index, price, max(price, nxt) + 0.2, min(price, nxt) - 0.2, nxt))
        price = nxt
    return out


# -- arbiter identity / window --------------------------------------------


def test_same_direction_within_window_confirms() -> None:
    arbiter = SignalArbiter(window_minutes=30)
    first = arbiter.register(ts=T0, slot="a", strategy="zones", symbol="XAUUSD", side="buy")
    assert first == ("zones",)

    second = arbiter.register(
        ts=T0 + timedelta(minutes=10), slot="b", strategy="numeric", symbol="XAUUSD", side="buy"
    )
    assert second == ("numeric", "zones")


def test_opposite_direction_does_not_confirm() -> None:
    arbiter = SignalArbiter(window_minutes=30)
    arbiter.register(ts=T0, slot="a", strategy="zones", symbol="XAUUSD", side="buy")
    second = arbiter.register(
        ts=T0 + timedelta(minutes=5), slot="b", strategy="numeric", symbol="XAUUSD", side="sell"
    )
    assert second == ("numeric",)


def test_window_expiry_drops_old_signals() -> None:
    arbiter = SignalArbiter(window_minutes=30)
    arbiter.register(ts=T0, slot="a", strategy="zones", symbol="XAUUSD", side="buy")
    late = arbiter.register(
        ts=T0 + timedelta(minutes=45), slot="b", strategy="numeric", symbol="XAUUSD", side="buy"
    )
    assert late == ("numeric",)


def test_rejected_signal_cannot_confirm_a_later_signal() -> None:
    # CONF-01: the engine reads confirmations, decides, and only registers a
    # signal that qualified. A D/NOISE outcome must leave the arbiter clean.
    arbiter = SignalArbiter(window_minutes=30)
    prior = arbiter.confirmations(ts=T0, strategy="zones", symbol="XAUUSD", side="buy")
    assert prior == ()
    rejected = decide(confirmation_count=0.0)
    assert rejected.hard_floor  # D -> never registered
    assert not has_other_strategy_confirmation(prior, "zones")
    assert arbiter.confirmations(ts=T0 + timedelta(minutes=5), strategy="numeric",
                                 symbol="XAUUSD", side="buy") == ()

    # A qualifying signal is registered and does confirm the next one.
    prior = arbiter.confirmations(ts=T0 + timedelta(minutes=10), strategy="zones",
                                  symbol="XAUUSD", side="buy")
    qualified = decide(confirmation_count=1.0)
    assert not qualified.hard_floor and not qualified.rejected
    arbiter.register(ts=T0 + timedelta(minutes=10), slot="a", strategy="zones",
                     symbol="XAUUSD", side="buy")
    later = arbiter.confirmations(ts=T0 + timedelta(minutes=15), strategy="numeric",
                                  symbol="XAUUSD", side="buy")
    assert later == ("zones",)
    assert has_other_strategy_confirmation(later, "numeric")


def test_magic_is_stable_across_python_hash_seeds() -> None:
    # CONF-02: magic must survive a restart, so it cannot use salted hash().
    code = (
        "import sys; sys.path.insert(0, 'src');"
        "from goldbot.app.signal_pipeline import stable_magic;"
        "print(stable_magic('zones_m15'))"
    )
    outputs = []
    for seed in ("1", "2"):
        env = {**os.environ, "PYTHONHASHSEED": seed, "PYTHONPATH": str(ROOT / "src")}
        result = subprocess.run(
            [sys.executable, "-c", code], cwd=str(ROOT), env=env,
            capture_output=True, text=True, check=True,
        )
        outputs.append(result.stdout.strip())
    assert outputs[0] == outputs[1]
    assert int(outputs[0]) == stable_magic("zones_m15")
    assert SignalPipeline().magic_for("zones_m15") == stable_magic("zones_m15")


def test_magic_is_nonzero_and_unique_for_known_slots() -> None:
    slots = ["zones_m15", "numeric_m15", "zones_m5", "numeric_m5", "zones_h1", "numeric_h1"]
    magics = {slot: stable_magic(slot) for slot in slots}
    assert all(value != 0 for value in magics.values())
    assert len(set(magics.values())) == len(magics)


# -- five factors + layer 3 ----------------------------------------------


def test_five_factors_are_the_confirmation_layer() -> None:
    bars = _closes(80)
    report = evaluate_confirmations(
        bars, side="buy", zone=None, entry=bars[-1].c, atr=2.0, rsi_m15=55.0
    )
    assert report.names == FACTOR_NAMES
    assert set(report.factors) == set(FACTOR_NAMES)
    assert all(value in (0.0, 0.5, 1.0) for value in report.factors.values())
    assert 0.0 <= report.total <= 5.0
    assert report.total == sum(report.factors.values())


def test_layer3_vote_contract_thresholds_and_cap() -> None:
    assert layer3_score({}).delta == 0
    assert layer3_score({"a": 1, "b": 1, "c": 1}).score == pytest.approx(0.6)
    assert layer3_score({"a": 1, "b": 1, "c": 1}).delta == 1
    assert layer3_score({"a": 1, "b": 1}).delta == 0
    assert layer3_score({"a": -1, "b": -1, "c": -1}).delta == -1
    capped = layer3_score({name: 1 for name in ("a", "b", "c", "d", "e", "f", "g")})
    assert capped.score == 1.2 and capped.delta == 1


def test_sr_zone_vote_requires_score_and_distance() -> None:
    # Both strategy paths use the same ADR-035 rule (CONF-03).
    assert zone_confirms_layer3(zone_score=60, distance=1.0, atr=1.0) is True
    assert zone_confirms_layer3(zone_score=60, distance=2.5, atr=1.0) is False
    assert zone_confirms_layer3(zone_score=49, distance=0.0, atr=1.0) is False
    assert zone_confirms_layer3(zone_score=60, distance=0.0, atr=0.0) is False
    assert zone_confirms_layer3(zone_score=60, distance=float("inf"), atr=1.0) is False


def test_ema200_h1_vote_requires_real_history_and_slope() -> None:
    base = [100.0 + index for index in range(200)]
    assert ema200_h1_vote(300.0, base[:-1], side="buy") == 0  # 199 bars: no history
    assert ema200_h1_vote(300.0, base, side="buy") == 0  # slope undefined: neutral
    rising = [100.0 + index for index in range(210)]
    assert ema200_h1_vote(320.0, rising, side="buy") == 1
    assert ema200_h1_vote(320.0, rising, side="sell") == -1
    flat = [200.0] * 210
    assert ema200_h1_vote(210.0, flat, side="buy") == 0  # no slope: neutral


# -- journal projections (kept from the old file) -------------------------


def _trade(i: int, net: float, confirmations: list[str]) -> TradeRecord:
    return TradeRecord(
        trade_id=f"t{i}",
        slot="s",
        strategy=confirmations[0] if confirmations else "zones",
        symbol="XAUUSD",
        side="buy",
        volume=0.01,
        open_time=T0.isoformat(),
        close_time=(T0 + timedelta(hours=1)).isoformat(),
        open_price=4000.0,
        close_price=4000.0 + net,
        sl=3990.0,
        tp=4020.0,
        pnl_gross=net,
        commission=0.0,
        swap=0.0,
        pnl_net=net,
        spread_at_entry=0.2,
        risk_amount=10.0,
        confirmations=confirmations,
    )


def test_journal_splits_single_and_multi_confirmation(scratch) -> None:
    journal = SqliteJournal(scratch / "j.db")
    try:
        journal.record_trade(_trade(1, 20.0, ["zones"]))
        journal.record_trade(_trade(2, -10.0, ["numeric"]))
        journal.record_trade(_trade(3, 40.0, ["zones", "numeric"]))
        stats = journal.stats()
    finally:
        journal.close()

    assert stats["by_confirmation"]["single"]["trades"] == 2
    assert stats["by_confirmation"]["single"]["net"] == 10.0
    assert stats["by_confirmation"]["multi"]["trades"] == 1
    assert stats["by_confirmation"]["multi"]["net"] == 40.0
    assert stats["by_confirmation_set"]["numeric+zones"]["trades"] == 1


def test_trade_confirmation_key_is_stable() -> None:
    trade = _trade(9, 1.0, ["numeric", "zones"])
    assert trade.confirmation_key == "numeric+zones"
    assert trade.confirmation_count == 2
