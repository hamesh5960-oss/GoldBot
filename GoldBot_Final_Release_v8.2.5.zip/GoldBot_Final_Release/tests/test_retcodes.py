"""Retcode classification table (ADR-011): every code pinned, unknown quarantines.

SES-01 regression: MT5 10012 (TIMEOUT) is an unknown-outcome code and must never
be treated as a definitive rejection that could be retried/re-sent.
"""

from __future__ import annotations

import pytest

from goldbot.adapters.mt5_broker import ACCEPTED_RETCODES
from goldbot.domain.retcodes import (
    RETCODE_TABLE,
    RETRYABLE_ACTIONS,
    RetcodeAction,
    classify,
)

EXPECTED: dict[int, RetcodeAction] = {
    # definitive success (including partial fill / no-op modify)
    10008: RetcodeAction.DONE,          # PLACED
    10009: RetcodeAction.DONE,          # DONE
    10010: RetcodeAction.DONE,          # DONE_PARTIAL
    10025: RetcodeAction.DONE,          # NO_CHANGES
    # re-quote / stale price or stops
    10004: RetcodeAction.RETRY_PRICE,   # REQUOTE
    10020: RetcodeAction.RETRY_PRICE,   # PRICE_CHANGED
    10021: RetcodeAction.RETRY_PRICE,   # PRICE_OFF
    10016: RetcodeAction.RETRY_STOPS,   # INVALID_STOPS
    # unknown or ambiguous outcome => QUARANTINE (never retry blindly)
    10011: RetcodeAction.QUARANTINE,    # ERROR
    10012: RetcodeAction.QUARANTINE,    # TIMEOUT (SES-01)
    10031: RetcodeAction.QUARANTINE,    # CONNECTION
    10036: RetcodeAction.QUARANTINE,    # POSITION_CLOSED (context-dependent; SES-02)
    # definitive refusal => ABORT (nothing executed; never replay a stale signal)
    10006: RetcodeAction.ABORT,
    10007: RetcodeAction.ABORT,
    10013: RetcodeAction.ABORT,
    10014: RetcodeAction.ABORT,
    10015: RetcodeAction.ABORT,
    10017: RetcodeAction.ABORT,
    10018: RetcodeAction.ABORT,
    10019: RetcodeAction.ABORT,
    10022: RetcodeAction.ABORT,
    10023: RetcodeAction.ABORT,
    10024: RetcodeAction.ABORT,
    10026: RetcodeAction.ABORT,
    10027: RetcodeAction.ABORT,
    10028: RetcodeAction.ABORT,
    10029: RetcodeAction.ABORT,
    10030: RetcodeAction.ABORT,
    10032: RetcodeAction.ABORT,
    10033: RetcodeAction.ABORT,
    10034: RetcodeAction.ABORT,
    10035: RetcodeAction.ABORT,
}


@pytest.mark.parametrize("code,action", sorted(EXPECTED.items()))
def test_every_table_entry_matches_the_policy(code: int, action: RetcodeAction) -> None:
    assert RETCODE_TABLE[code] is action
    assert classify(code) is action


def test_table_has_exactly_the_reviewed_entries() -> None:
    assert set(RETCODE_TABLE) == set(EXPECTED)


def test_table_values_are_retcode_actions() -> None:
    assert set(RETCODE_TABLE.values()) <= set(RetcodeAction)


def test_unknown_codes_quarantine_never_retry() -> None:
    for code in (-1, 0, 1, 10005, 10037, 10040, 99999):
        assert classify(code) is RetcodeAction.QUARANTINE


def test_timeout_is_quarantine_ses01_regression() -> None:
    assert classify(10012) is RetcodeAction.QUARANTINE
    assert classify(10012) not in RETRYABLE_ACTIONS


def test_connection_loss_is_quarantine() -> None:
    assert classify(10031) is RetcodeAction.QUARANTINE


def test_market_closed_aborts_the_stale_signal_instead_of_retrying() -> None:
    assert classify(10018) is RetcodeAction.ABORT
    assert classify(10018) not in RETRYABLE_ACTIONS


def test_accepted_adapter_retcodes_are_done() -> None:
    """The adapter's accepted set and the domain table must not contradict."""
    assert ACCEPTED_RETCODES
    for code in ACCEPTED_RETCODES:
        assert classify(code) is RetcodeAction.DONE


def test_retryable_set_is_only_price_and_stops() -> None:
    assert RETRYABLE_ACTIONS == frozenset({RetcodeAction.RETRY_PRICE, RetcodeAction.RETRY_STOPS})


def test_classify_coerces_int_like_inputs() -> None:
    assert classify("10012") is RetcodeAction.QUARANTINE
    assert classify(10012.0) is RetcodeAction.QUARANTINE
