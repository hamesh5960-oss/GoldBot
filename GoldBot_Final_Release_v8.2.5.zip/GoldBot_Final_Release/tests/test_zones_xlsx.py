"""Zone storage, Iran trading day and the dependency-free XLSX writer."""

from __future__ import annotations

import zipfile
from datetime import date, datetime, timezone

import pytest

from goldbot.adapters.xlsx import write_xlsx
from goldbot.adapters.zones import (
    MAX_ZONES_PER_DAY,
    ZoneStore,
    parse_zones_text,
)
from goldbot.strategy_api import Zone
from goldbot.timeutil import iran_day


def test_parse_csv_lines_with_persian_digits_and_comments() -> None:
    text = """
    # سقف,کف,مهم,یادداشت
    ۴۰۵۰.۰۰, ۴۰۴۸.۰۰, ۱, ناحیه مهم
    4035.5 4032.0
    ; این خط نادیده گرفته می‌شود
    """
    zones = parse_zones_text(text)
    assert len(zones) == 2
    assert zones[0].high == 4050.0 and zones[0].low == 4048.0
    assert zones[0].starred is True
    assert zones[0].note == "ناحیه مهم"
    assert zones[1].high == 4035.5


def test_parse_swapped_high_low_is_sorted() -> None:
    zones = parse_zones_text("4000,4010,0")
    assert zones[0].high == 4010.0 and zones[0].low == 4000.0


def test_parse_json_payload() -> None:
    text = '[{"high": 4050, "low": 4048, "starred": true}, {"high": 4035, "low": 4032}]'
    zones = parse_zones_text(text)
    assert len(zones) == 2
    assert zones[0].starred is True


def test_parse_rejects_bad_row_with_line_number() -> None:
    with pytest.raises(ValueError) as exc:
        parse_zones_text("4050,4048\nآب,4032")
    assert "خط 2" in str(exc.value)


def test_parse_rejects_empty_file() -> None:
    with pytest.raises(ValueError):
        parse_zones_text("   \n  ")


def test_zone_store_enforces_max_40(scratch) -> None:
    store = ZoneStore(scratch / "zones.json")
    day = date(2024, 3, 4)
    zones = [Zone(4000 + i, 3999 + i) for i in range(MAX_ZONES_PER_DAY + 1)]
    with pytest.raises(ValueError):
        store.replace_day(day, zones)

    store.replace_day(day, zones[:MAX_ZONES_PER_DAY])
    assert len(store.for_day(day)) == MAX_ZONES_PER_DAY


def test_zone_store_has_day_is_strict(scratch) -> None:
    store = ZoneStore(scratch / "zones.json")
    day = date(2024, 3, 4)
    store.add(day, 4050, 4048)
    assert store.has_day(day) is True
    assert store.has_day(date(2024, 3, 5)) is False
    # zones from yesterday must not leak into today
    assert store.for_day(date(2024, 3, 5)) == ()


def test_zone_store_roundtrip(scratch) -> None:
    store = ZoneStore(scratch / "zones.json")
    day = date(2024, 3, 4)
    store.add(day, 4050.0, 4048.0, starred=True, note="مهم")
    store.add(day, 4035.0, 4032.0)

    zones = store.for_day(day)
    assert len(zones) == 2
    assert zones[0].high == 4050.0  # sorted high -> low
    assert zones[0].starred is True
    assert store.for_day(date(2024, 3, 5)) == ()


def test_zone_store_remove_and_replace(scratch) -> None:
    store = ZoneStore(scratch / "zones.json")
    day = date(2024, 3, 4)
    store.replace_day(day, [Zone(4050, 4048), Zone(4035, 4032)])
    assert len(store.for_day(day)) == 2
    assert store.remove(day, 0) is True
    assert len(store.for_day(day)) == 1
    assert store.remove(day, 5) is False


def test_zone_store_survives_corrupt_file(scratch) -> None:
    path = scratch / "zones.json"
    path.write_text("{not json", encoding="utf-8")
    assert ZoneStore(path).for_day(date(2024, 3, 4)) == ()


def test_zone_rejects_inverted_bounds() -> None:
    with pytest.raises(ValueError):
        Zone(high=100.0, low=105.0)


def test_iran_day_crosses_midnight() -> None:
    # 21:00 UTC Monday == 00:30 Tuesday in Tehran (+03:30)
    monday_late = datetime(2024, 3, 4, 21, 0, tzinfo=timezone.utc)
    assert iran_day(monday_late) == date(2024, 3, 5)
    # 10:00 UTC is 13:30 the same day
    assert iran_day(datetime(2024, 3, 4, 10, 0, tzinfo=timezone.utc)) == date(2024, 3, 4)


def test_xlsx_is_a_valid_package(scratch) -> None:
    out = write_xlsx(
        scratch / "journal.xlsx",
        ["ردیف", "سود", "استراتژی"],
        [[1, 12.5, "fvg_ma"], [2, -3.0, "numeric"]],
        sheet="trades",
    )
    assert out.exists()
    with zipfile.ZipFile(out) as zf:
        names = set(zf.namelist())
        assert {"[Content_Types].xml", "xl/workbook.xml", "xl/worksheets/sheet1.xml"} <= names
        sheet = zf.read("xl/worksheets/sheet1.xml").decode("utf-8")
    assert "fvg_ma" in sheet
    assert "12.5" in sheet
    assert 't="inlineStr"' in sheet


def test_workbook_supports_multiple_sheets(scratch) -> None:
    from goldbot.adapters.xlsx import write_workbook

    path = write_workbook(
        scratch / "multi.xlsx",
        [
            ("خلاصه", ["پروفایل", "بازده"], [["کم", 8.1]]),
            ("معاملات", ["ردیف", "نماد"], [[1, "XAUUSD"]]),
        ],
    )
    with zipfile.ZipFile(path) as zf:
        assert "xl/worksheets/sheet2.xml" in zf.namelist()
        workbook = zf.read("xl/workbook.xml").decode("utf-8")
        sheet2 = zf.read("xl/worksheets/sheet2.xml").decode("utf-8")
    assert "خلاصه" in workbook and "معاملات" in workbook
    assert "XAUUSD" in sheet2
