"""Capital level controller: BASE bands, hysteresis and the approval protocol."""

from __future__ import annotations

import json
import math
from dataclasses import replace
from datetime import datetime, timedelta, timezone

import pytest

from goldbot.app.capital_levels import (
    ALL_SESSIONS,
    BASE_BANDS,
    BASE_MAX_EQUITY,
    CORE_SESSIONS,
    LEVEL_POLICIES,
    CapitalLevel,
    LevelConfig,
    LevelPolicy,
    LevelState,
    active_level_for_execution,
    approve_upgrade,
    band_risk_pct,
    decline_upgrade,
    determine_level,
    enforce_level,
    policy_for,
    risk_pct_for_level,
    start_level,
    update_counters,
)
from goldbot.app.decision import TIER_RISK_PCT, Tier

NOW = datetime(2026, 1, 5, 12, 0, tzinfo=timezone.utc)


def make_state(level: CapitalLevel = CapitalLevel.BASE, **overrides) -> LevelState:
    values: dict = {"active_level": level}
    values.update(overrides)
    return LevelState(**values)


def base_ready() -> dict:
    """Every BASE->LOW upgrade gate satisfied, except what a test overrides."""
    return {
        "equity": 1500.0,
        "drawdown_pct": 0.0,
        "consecutive_losses": 0,
        "open_positions": 0,
        "trades_in_level": 5,
        "days_above_threshold": 5,
    }


def ready_base_state(**overrides) -> LevelState:
    values: dict = {"last_level_change": NOW - timedelta(days=10)}
    values.update(overrides)
    return make_state(CapitalLevel.BASE, **values)


def level_action(
    level: CapitalLevel,
    equity: float,
    drawdown_pct: float = 0.0,
    consecutive_losses: int = 0,
    *,
    config: LevelConfig | None = None,
    **state_overrides,
):
    """Run one evaluation from a fresh state for the given level."""
    return determine_level(
        equity,
        drawdown_pct,
        consecutive_losses,
        0,
        NOW,
        make_state(level, **state_overrides),
        config if config is not None else LevelConfig(),
    )


# ---------------------------------------------------------------------------
# BASE bands: the 5% is band 0 only
# ---------------------------------------------------------------------------


def test_base_band_table_matches_spec() -> None:
    expected = [
        (0.0, 200.0, 5.0, 0.0),
        (200.0, 300.0, 4.0, 220.0),
        (300.0, 400.0, 3.0, 330.0),
        (400.0, 500.0, 2.0, 440.0),
        (500.0, math.inf, 1.5, 550.0),
    ]
    assert [
        (band.min_eq, band.max_eq, band.risk_pct, band.hysteresis_enter)
        for band in BASE_BANDS
    ] == expected


@pytest.mark.parametrize(
    ("equity", "expected_risk", "expected_band"),
    [
        (0.0, 5.0, 0),
        (100.0, 5.0, 0),
        (199.0, 5.0, 0),
        (200.0, 4.0, 1),
        (250.0, 4.0, 1),
        (299.99, 4.0, 1),
        (300.0, 3.0, 2),
        (350.0, 3.0, 2),
        (400.0, 2.0, 3),
        (450.0, 2.0, 3),
        (500.0, 1.5, 4),
        (800.0, 1.5, 4),
    ],
)
def test_base_band_risk_curve(equity: float, expected_risk: float, expected_band: int) -> None:
    assert band_risk_pct(equity) == (expected_risk, expected_band)


def test_band_risk_never_exceeds_five_percent() -> None:
    equities = [0.0, 1.0, 50.0, 199.0, 200.0, 250.0, 300.0, 500.0, 10_000.0]
    for previous in (None, 0, 1, 2, 3, 4):
        for equity in equities:
            risk, _ = band_risk_pct(equity, previous)
            assert 0.0 < risk <= 5.0


def test_hysteresis_keeps_band_zero_at_201() -> None:
    assert band_risk_pct(201.0, 0) == (5.0, 0)


def test_hysteresis_enters_band_one_at_221() -> None:
    assert band_risk_pct(221.0, 0) == (4.0, 1)


@pytest.mark.parametrize("previous", [1, 2, 3, 4])
def test_band_steps_back_to_riskier_band_immediately(previous: int) -> None:
    assert band_risk_pct(199.0, previous) == (5.0, 0)


def test_band_cannot_skip_an_unmet_entry_trigger() -> None:
    # Equity is in band 2 territory, but band 2 needs 330. At 320 only band 1
    # (needs 220) is unlocked, so the controller stops there.
    assert band_risk_pct(320.0, 0) == (4.0, 1)
    assert band_risk_pct(350.0, 0) == (3.0, 2)


def test_band_stays_when_equity_stays_in_current_band() -> None:
    assert band_risk_pct(250.0, 1) == (4.0, 1)
    # 210 is still above the floor of band 1, so dropping from band 2 is
    # immediate: the riskier move never waits for a trigger.
    assert band_risk_pct(210.0, 2) == (4.0, 1)


# ---------------------------------------------------------------------------
# Per-level risk: only BASE may exceed 1.0%
# ---------------------------------------------------------------------------


def test_risk_pct_for_base_uses_bands_when_enabled() -> None:
    assert risk_pct_for_level(CapitalLevel.BASE, Tier.A_PLUS, 100.0, base_enabled=True) == 5.0
    assert risk_pct_for_level(CapitalLevel.BASE, Tier.A_PLUS, 250.0, base_enabled=True) == 4.0
    assert (
        risk_pct_for_level(
            CapitalLevel.BASE, Tier.A_PLUS, 221.0, previous_band=0, base_enabled=True
        )
        == 4.0
    )


def test_risk_pct_for_base_is_zero_when_disabled() -> None:
    assert risk_pct_for_level(CapitalLevel.BASE, Tier.A_PLUS, 100.0, base_enabled=False) == 0.0
    assert risk_pct_for_level(CapitalLevel.BASE, Tier.A_PLUS, 250.0, base_enabled=False) == 0.0


def test_risk_pct_for_tier_levels() -> None:
    for level in (CapitalLevel.LOW_RISK, CapitalLevel.MEDIUM_RISK, CapitalLevel.HIGH_RISK):
        for tier, expected in TIER_RISK_PCT.items():
            assert risk_pct_for_level(level, tier, 10_000.0) == expected
    assert risk_pct_for_level(CapitalLevel.HIGH_RISK, "Z", 10_000.0) == 0.0
    assert risk_pct_for_level(CapitalLevel.LOW_RISK, None, 10_000.0) == 0.0
    assert risk_pct_for_level("low_risk", "A+", 10_000.0) == TIER_RISK_PCT[Tier.A_PLUS]


def test_tier_levels_never_exceed_one_percent() -> None:
    for level in (CapitalLevel.LOW_RISK, CapitalLevel.MEDIUM_RISK, CapitalLevel.HIGH_RISK):
        for tier in Tier:
            for equity in (0.0, 100.0, 1500.0, 50_000.0):
                assert 0.0 <= risk_pct_for_level(level, tier, equity) <= 1.0


# ---------------------------------------------------------------------------
# Level policy table
# ---------------------------------------------------------------------------


def test_level_policy_table_matches_spec() -> None:
    assert policy_for(CapitalLevel.BASE) == LevelPolicy(
        allowed_tiers=frozenset({"A+"}),
        zone_floors={},
        max_trades_per_day=1,
        max_open_risk_pct=5.0,
        max_daily_loss_pct=3.0,
        max_consecutive_losses=2,
        amplifier_enabled=False,
        gates_enabled=False,
        sessions=("london", "overlap", "ny"),
        news_before_minutes=30,
        spread_ratio=0.08,
        kill_switch_dd_pct=10.0,
        min_equity=0.0,
        risk_source="base_bands",
    )
    assert policy_for(CapitalLevel.LOW_RISK) == LevelPolicy(
        allowed_tiers=frozenset({"A+", "A"}),
        zone_floors={},
        max_trades_per_day=2,
        max_open_risk_pct=2.0,
        max_daily_loss_pct=3.0,
        max_consecutive_losses=3,
        amplifier_enabled=False,
        gates_enabled=True,
        sessions=("london", "overlap", "ny"),
        news_before_minutes=15,
        spread_ratio=0.10,
        kill_switch_dd_pct=15.0,
        min_equity=0.0,
        risk_source="tier",
    )
    assert policy_for(CapitalLevel.MEDIUM_RISK) == LevelPolicy(
        allowed_tiers=frozenset({"A+", "A", "B"}),
        zone_floors={},
        max_trades_per_day=3,
        max_open_risk_pct=3.0,
        max_daily_loss_pct=3.0,
        max_consecutive_losses=4,
        amplifier_enabled=True,
        gates_enabled=True,
        sessions=ALL_SESSIONS,
        news_before_minutes=15,
        spread_ratio=0.15,
        kill_switch_dd_pct=20.0,
        min_equity=0.0,
        risk_source="tier",
    )
    assert policy_for(CapitalLevel.HIGH_RISK) == LevelPolicy(
        allowed_tiers=frozenset({"A+", "A", "B", "C"}),
        zone_floors={},
        max_trades_per_day=3,
        max_open_risk_pct=3.0,
        max_daily_loss_pct=3.0,
        max_consecutive_losses=4,
        amplifier_enabled=True,
        gates_enabled=True,
        sessions=ALL_SESSIONS,
        news_before_minutes=15,
        spread_ratio=0.15,
        kill_switch_dd_pct=20.0,
        min_equity=0.0,
        risk_source="tier",
    )


def test_policy_lookup_accepts_strings() -> None:
    assert policy_for("high_risk") is LEVEL_POLICIES[CapitalLevel.HIGH_RISK]


# ---------------------------------------------------------------------------
# Config and state
# ---------------------------------------------------------------------------


def test_level_config_defaults() -> None:
    config = LevelConfig()
    assert config.low_risk_threshold == 1500.0
    assert config.medium_risk_threshold == 2000.0
    assert config.high_risk_threshold == 4000.0
    assert config.approval_timeout_days == 7
    assert config.decline_cooldown_days == 30
    assert config.min_days_above_threshold == 5
    assert config.min_trades_in_level == 5
    assert config.base_enabled is False
    assert config.auto_downgrade is True


@pytest.mark.parametrize(
    "overrides",
    [
        {"low_risk_threshold": 0.0},
        {"low_risk_threshold": -1.0},
        {"medium_risk_threshold": 1400.0},
        {"high_risk_threshold": 1900.0},
        {"approval_timeout_days": -1},
        {"decline_cooldown_days": -1},
        {"min_days_above_threshold": -1},
        {"min_trades_in_level": -1},
    ],
)
def test_level_config_rejects_invalid_values(overrides: dict) -> None:
    with pytest.raises(ValueError):
        LevelConfig(**overrides)


def test_level_state_json_roundtrip() -> None:
    state = LevelState(
        active_level=CapitalLevel.MEDIUM_RISK,
        previous_band=4,
        pending_level=CapitalLevel.HIGH_RISK,
        pending_since=NOW,
        decline_until=NOW + timedelta(days=5),
        days_above_threshold=3,
        trades_in_level=7,
        last_level_change=NOW - timedelta(days=2),
        base_started_at=NOW - timedelta(days=10),
    )
    encoded = json.loads(json.dumps(state.to_dict()))
    assert LevelState.from_dict(encoded) == state
    assert LevelState.from_dict(LevelState().to_dict()) == LevelState()


def test_level_state_rejects_unknown_level() -> None:
    with pytest.raises(ValueError):
        LevelState.from_dict({"active_level": "sideways"})


@pytest.mark.parametrize(
    ("equity", "expected"),
    [
        (100.0, CapitalLevel.BASE),
        (1499.99, CapitalLevel.BASE),
        (1500.0, CapitalLevel.LOW_RISK),
        (1999.99, CapitalLevel.LOW_RISK),
        (2000.0, CapitalLevel.MEDIUM_RISK),
        (3999.99, CapitalLevel.MEDIUM_RISK),
        (4000.0, CapitalLevel.HIGH_RISK),
        (10_000.0, CapitalLevel.HIGH_RISK),
    ],
)
def test_start_level_maps_equity_to_level(equity: float, expected: CapitalLevel) -> None:
    state = start_level(equity, LevelConfig())
    assert state.active_level is expected
    assert state.previous_band == band_risk_pct(equity, None)[1]


# ---------------------------------------------------------------------------
# Auto-downgrade: immediate, no approval
# ---------------------------------------------------------------------------


def test_high_downgrades_on_equity_floor() -> None:
    state = make_state(CapitalLevel.HIGH_RISK)
    decision = determine_level(1599.99, 0.0, 0, 0, NOW, state, LevelConfig())
    assert decision.action == "downgrade"
    assert decision.active_level is CapitalLevel.MEDIUM_RISK
    assert decision.reason == "equity_below_floor"
    assert state.last_level_change == NOW
    assert state.days_above_threshold == 0
    assert state.trades_in_level == 0


def test_high_downgrade_boundaries() -> None:
    assert level_action(CapitalLevel.HIGH_RISK, 1600.0).action == "keep"
    assert level_action(CapitalLevel.HIGH_RISK, 5000.0, 20.0).action == "keep"
    assert level_action(CapitalLevel.HIGH_RISK, 5000.0, 20.01).action == "downgrade"
    assert level_action(CapitalLevel.HIGH_RISK, 5000.0, 0.0, 3).action == "keep"
    assert level_action(CapitalLevel.HIGH_RISK, 5000.0, 0.0, 4).action == "downgrade"


def test_medium_and_low_downgrade_boundaries() -> None:
    assert level_action(CapitalLevel.MEDIUM_RISK, 1200.0).action == "keep"
    below = level_action(CapitalLevel.MEDIUM_RISK, 1199.99)
    assert below.active_level is CapitalLevel.LOW_RISK
    assert level_action(CapitalLevel.MEDIUM_RISK, 2500.0, 15.0).action == "keep"
    drawdown = level_action(CapitalLevel.MEDIUM_RISK, 2500.0, 15.01)
    assert drawdown.active_level is CapitalLevel.LOW_RISK
    assert level_action(CapitalLevel.MEDIUM_RISK, 2500.0, 0.0, 2).action == "keep"
    losses = level_action(CapitalLevel.MEDIUM_RISK, 2500.0, 0.0, 3)
    assert losses.active_level is CapitalLevel.LOW_RISK

    assert level_action(CapitalLevel.LOW_RISK, 1200.0).action == "keep"
    low_drawdown = level_action(CapitalLevel.LOW_RISK, 1200.0, 10.01)
    assert low_drawdown.active_level is CapitalLevel.BASE
    assert low_drawdown.state.base_started_at == NOW
    low_losses = level_action(CapitalLevel.LOW_RISK, 1200.0, 0.0, 3)
    assert low_losses.active_level is CapitalLevel.BASE


def test_auto_downgrade_can_be_disabled() -> None:
    config = LevelConfig(auto_downgrade=False)
    decision = determine_level(100.0, 50.0, 9, 0, NOW, make_state(CapitalLevel.HIGH_RISK), config)
    assert decision.action == "keep"
    assert decision.active_level is CapitalLevel.HIGH_RISK


def test_downgrade_clears_a_pending_proposal() -> None:
    state = make_state(
        CapitalLevel.MEDIUM_RISK,
        pending_level=CapitalLevel.HIGH_RISK,
        pending_since=NOW - timedelta(days=1),
    )
    decision = determine_level(2000.0, 16.0, 0, 0, NOW, state, LevelConfig())
    assert decision.action == "downgrade"
    assert decision.active_level is CapitalLevel.LOW_RISK
    assert state.pending_level is None
    assert state.pending_since is None


# ---------------------------------------------------------------------------
# Upgrades: proposal only
# ---------------------------------------------------------------------------


def test_base_upgrade_proposes_when_all_gates_met() -> None:
    config = LevelConfig(base_enabled=True)
    state = ready_base_state()
    decision = determine_level(
        now=NOW,
        state=state,
        config=config,
        **base_ready(),
    )
    assert decision.action == "propose_upgrade"
    assert decision.active_level is CapitalLevel.BASE
    assert decision.proposed_level is CapitalLevel.LOW_RISK
    assert decision.state is state
    assert state.pending_level is CapitalLevel.LOW_RISK
    assert state.pending_since == NOW


@pytest.mark.parametrize(
    ("state_overrides", "kwargs_overrides", "expected_reason"),
    [
        ({}, {"equity": 1499.0}, "below_threshold"),
        ({}, {"days_above_threshold": 4}, "days_below_min"),
        ({}, {"trades_in_level": 4}, "trades_below_min"),
        ({}, {"open_positions": 1}, "open_positions"),
        ({"last_level_change": NOW - timedelta(days=6)}, {}, "min_interval"),
        ({"decline_until": NOW + timedelta(days=1)}, {}, "decline_cooldown"),
    ],
)
def test_base_upgrade_blocked_by_each_gate(
    state_overrides: dict, kwargs_overrides: dict, expected_reason: str
) -> None:
    state = ready_base_state(**state_overrides)
    kwargs = {**base_ready(), **kwargs_overrides}
    decision = determine_level(now=NOW, state=state, config=LevelConfig(base_enabled=True), **kwargs)
    assert decision.action == "keep"
    assert decision.reason == expected_reason
    assert decision.proposed_level is None
    assert state.pending_level is None


def test_base_upgrade_needs_seven_days_since_last_change() -> None:
    state = ready_base_state(last_level_change=NOW - timedelta(days=7))
    decision = determine_level(now=NOW, state=state, config=LevelConfig(base_enabled=True), **base_ready())
    assert decision.action == "propose_upgrade"


def test_base_upgrade_never_proposed_while_base_disabled() -> None:
    state = ready_base_state()
    decision = determine_level(now=NOW, state=state, config=LevelConfig(), **base_ready())
    assert decision.action == "keep"
    assert decision.reason == "base_disabled"
    assert state.pending_level is None


def test_low_to_medium_proposal() -> None:
    state = make_state(CapitalLevel.LOW_RISK)
    decision = determine_level(1999.0, 0.0, 0, 0, NOW, state, LevelConfig())
    assert decision.action == "keep"
    assert decision.reason == "below_threshold"

    decision = determine_level(2000.0, 0.0, 0, 0, NOW, state, LevelConfig())
    assert decision.action == "propose_upgrade"
    assert decision.proposed_level is CapitalLevel.MEDIUM_RISK


def test_medium_to_high_proposal() -> None:
    state = make_state(CapitalLevel.MEDIUM_RISK)
    decision = determine_level(4000.0, 0.0, 0, 0, NOW, state, LevelConfig())
    assert decision.action == "propose_upgrade"
    assert decision.proposed_level is CapitalLevel.HIGH_RISK


def test_high_has_no_upgrade_path() -> None:
    decision = determine_level(1_000_000.0, 0.0, 0, 0, NOW, make_state(CapitalLevel.HIGH_RISK), LevelConfig())
    assert decision.action == "keep"
    assert decision.reason == "no_upgrade_path"


# ---------------------------------------------------------------------------
# Proposal expiry and operator approval
# ---------------------------------------------------------------------------


def test_pending_proposal_waits_before_timeout() -> None:
    state = ready_base_state(
        pending_level=CapitalLevel.LOW_RISK,
        pending_since=NOW - timedelta(days=6),
    )
    decision = determine_level(1000.0, 0.0, 0, 0, NOW, state, LevelConfig())
    assert decision.action == "keep"
    assert decision.reason == "awaiting_approval"
    assert decision.proposed_level is CapitalLevel.LOW_RISK
    assert state.pending_level is CapitalLevel.LOW_RISK


def test_pending_proposal_expires_and_starts_cooldown() -> None:
    state = ready_base_state(
        pending_level=CapitalLevel.LOW_RISK,
        pending_since=NOW - timedelta(days=8),
    )
    decision = determine_level(1000.0, 0.0, 0, 0, NOW, state, LevelConfig())
    assert decision.action == "expire_proposal"
    assert decision.proposed_level is CapitalLevel.LOW_RISK
    assert decision.reason == "approval_timeout"
    assert state.pending_level is None
    assert state.decline_until == NOW + timedelta(days=30)

    blocked = determine_level(now=NOW, state=state, config=LevelConfig(base_enabled=True), **base_ready())
    assert blocked.action == "keep"
    assert blocked.reason == "decline_cooldown"


def test_decline_upgrade_starts_cooldown() -> None:
    config = LevelConfig()
    state = make_state(
        CapitalLevel.BASE,
        pending_level=CapitalLevel.LOW_RISK,
        pending_since=NOW - timedelta(days=1),
        days_above_threshold=3,
    )
    assert decline_upgrade(state, NOW, config) is state
    assert state.pending_level is None
    assert state.pending_since is None
    assert state.decline_until == NOW + timedelta(days=config.decline_cooldown_days)
    assert state.days_above_threshold == 0


def test_decline_without_pending_is_noop() -> None:
    state = make_state(CapitalLevel.LOW_RISK)
    assert decline_upgrade(state, NOW, LevelConfig()) is state
    assert state.decline_until is None


def test_approve_upgrade_activates_pending_level() -> None:
    state = make_state(
        CapitalLevel.BASE,
        pending_level=CapitalLevel.LOW_RISK,
        pending_since=NOW - timedelta(days=1),
        days_above_threshold=5,
        trades_in_level=5,
        base_started_at=NOW - timedelta(days=20),
    )
    assert approve_upgrade(state, NOW) is state
    assert state.active_level is CapitalLevel.LOW_RISK
    assert state.pending_level is None
    assert state.pending_since is None
    assert state.last_level_change == NOW
    assert state.base_started_at is None
    assert state.days_above_threshold == 0
    assert state.trades_in_level == 0


def test_approve_without_pending_is_noop() -> None:
    state = make_state(CapitalLevel.LOW_RISK)
    assert approve_upgrade(state, NOW) is state
    assert state.active_level is CapitalLevel.LOW_RISK


# ---------------------------------------------------------------------------
# BASE execution gating
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    ("enabled", "armed", "ack", "equity", "expected"),
    [
        (True, True, True, 100.0, CapitalLevel.BASE),
        (True, True, True, 199.99, CapitalLevel.BASE),
        (False, True, True, 100.0, None),
        (True, False, True, 100.0, None),
        (True, True, False, 100.0, None),
        (True, True, True, BASE_MAX_EQUITY, None),
        (True, True, True, 500.0, None),
    ],
)
def test_base_gating_requires_all_interlocks(enabled, armed, ack, equity, expected) -> None:
    assert active_level_for_execution(CapitalLevel.BASE, enabled, armed, ack, equity) is expected


def test_base_gating_accepts_string_level() -> None:
    assert active_level_for_execution("base", True, True, True, 100.0) is CapitalLevel.BASE


def test_non_base_levels_pass_through_gating() -> None:
    for level in (CapitalLevel.LOW_RISK, CapitalLevel.MEDIUM_RISK, CapitalLevel.HIGH_RISK):
        assert active_level_for_execution(level, False, False, False, 50.0) is level


# ---------------------------------------------------------------------------
# Counters and enforce_level
# ---------------------------------------------------------------------------


def test_update_counters_counts_trades_and_days() -> None:
    state = make_state(CapitalLevel.BASE)
    config = LevelConfig()
    update_counters(state, day_passed=True, equity=1500.0, config=config)
    assert state.days_above_threshold == 1
    update_counters(state, day_passed=True, equity=1500.0, config=config)
    assert state.days_above_threshold == 2
    update_counters(state, day_passed=True, equity=1400.0, config=config)
    assert state.days_above_threshold == 0
    update_counters(state, trade_closed=True)
    assert state.trades_in_level == 1


def test_update_counters_explicit_threshold() -> None:
    state = make_state(CapitalLevel.LOW_RISK, days_above_threshold=2)
    update_counters(state, day_passed=True, equity=2001.0, threshold=2000.0)
    assert state.days_above_threshold == 3


def test_update_counters_high_level_has_no_next_threshold() -> None:
    state = make_state(CapitalLevel.HIGH_RISK)
    update_counters(state, day_passed=True, equity=1_000_000.0, config=LevelConfig())
    assert state.days_above_threshold == 0


def test_enforce_level_never_loosens() -> None:
    policy = LEVEL_POLICIES[CapitalLevel.LOW_RISK]
    effective = enforce_level(
        policy,
        {
            "max_daily_loss_pct": 10.0,
            "max_trades_per_day": 50,
            "max_open_risk_pct": 9.0,
            "max_consecutive_losses": 9,
            "spread_ratio": 0.5,
            "kill_switch_dd_pct": 90.0,
            "news_before_minutes": 5,
            "min_equity": -100.0,
        },
    )
    assert effective["max_daily_loss_pct"] == policy.max_daily_loss_pct
    assert effective["max_trades_per_day"] == policy.max_trades_per_day
    assert effective["max_open_risk_pct"] == policy.max_open_risk_pct
    assert effective["max_consecutive_losses"] == policy.max_consecutive_losses
    assert effective["spread_ratio"] == policy.spread_ratio
    assert effective["kill_switch_dd_pct"] == policy.kill_switch_dd_pct
    assert effective["news_before_minutes"] == policy.news_before_minutes
    assert effective["min_equity"] == policy.min_equity


def test_enforce_level_applies_tighter_profile_limits() -> None:
    policy = LEVEL_POLICIES[CapitalLevel.LOW_RISK]
    effective = enforce_level(
        policy,
        {
            "max_trades_per_day": 1,
            "max_open_risk_pct": 1.0,
            "max_daily_loss_pct": 1.5,
            "max_consecutive_losses": 2,
            "spread_ratio": 0.05,
            "kill_switch_dd_pct": 5.0,
            "news_before_minutes": 45,
            "min_equity": 500.0,
        },
    )
    assert effective["max_trades_per_day"] == 1
    assert effective["max_open_risk_pct"] == 1.0
    assert effective["max_daily_loss_pct"] == 1.5
    assert effective["max_consecutive_losses"] == 2
    assert effective["spread_ratio"] == 0.05
    assert effective["kill_switch_dd_pct"] == 5.0
    assert effective["news_before_minutes"] == 45
    assert effective["min_equity"] == 500.0


def test_enforce_level_intersects_tiers_and_sessions() -> None:
    policy = LEVEL_POLICIES[CapitalLevel.HIGH_RISK]
    effective = enforce_level(
        policy,
        {"allowed_tiers": ["A+", "A", "Z"], "sessions": "london,ny"},
    )
    assert effective["allowed_tiers"] == frozenset({"A+", "A"})
    assert effective["sessions"] == ("london", "ny")

    empty = enforce_level(policy, {"allowed_tiers": ["noise"]})
    assert empty["allowed_tiers"] == frozenset()


def test_enforce_level_and_booleans_and_floors() -> None:
    high = LEVEL_POLICIES[CapitalLevel.HIGH_RISK]
    effective = enforce_level(high, {"amplifier_enabled": False, "gates_enabled": False})
    assert effective["amplifier_enabled"] is False
    assert effective["gates_enabled"] is False

    base = LEVEL_POLICIES[CapitalLevel.BASE]
    assert enforce_level(base, {"amplifier_enabled": True})["amplifier_enabled"] is False

    floored = replace(base, zone_floors={"A": 85})
    merged = enforce_level(floored, {"zone_floors": {"A": 80, "B": 60}})
    assert merged["zone_floors"] == {"A": 85, "B": 60}
    raised = enforce_level(floored, {"zone_floors": {"A": 90}})
    assert raised["zone_floors"] == {"A": 90}


def test_enforce_level_returns_defensive_copies() -> None:
    policy = LEVEL_POLICIES[CapitalLevel.BASE]
    effective = enforce_level(policy, {})
    effective["zone_floors"]["X"] = 1
    assert policy.zone_floors == {}
    assert effective["allowed_tiers"] == frozenset({"A+"})
    assert effective["sessions"] == policy.sessions
    assert effective["risk_source"] == "base_bands"
    assert enforce_level(LEVEL_POLICIES[CapitalLevel.LOW_RISK], {})["risk_source"] == "tier"
