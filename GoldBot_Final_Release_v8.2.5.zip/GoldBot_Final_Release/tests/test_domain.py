"""Domain invariants: money, rounding, and the state machines that guard orders."""

from __future__ import annotations

from datetime import datetime, timezone
from decimal import Decimal

import pytest

from goldbot.domain.errors import IllegalTransition
from goldbot.domain.fsm.connection import ConnectionState, allows_new_orders, assert_transition as conn_ok
from goldbot.domain.fsm.order import OrderState, can_transition
from goldbot.domain.fsm.position import PositionState, Protection, assert_transition
from goldbot.domain.model import SymbolInfo, Symbol, Tick, Ts
from goldbot.domain.money import Money, dec, money


def test_money_arithmetic_is_exact() -> None:
    assert money(0.1) + money(0.2) == money(0.3)
    assert (money(10) - money(3.5)) * 2 == money(13.0)


def test_money_rejects_currency_mix() -> None:
    with pytest.raises(ValueError):
        money(1, "USD") + money(1, "EUR")


def test_float_noise_is_removed() -> None:
    assert str(dec(0.1 + 0.2)) == "0.30000000000000004"  # input float is already lossy
    assert money(0.1 + 0.2).amount == Decimal("0.30")  # but the boundary quantises


def test_volume_rounding_never_rounds_up() -> None:
    info = SymbolInfo(symbol=Symbol("XAUUSD"), broker_symbol="XAUUSD")
    assert info.round_volume(0.014) == 0.01
    assert info.round_volume(0.0159) == 0.01


def test_order_state_machine_blocks_illegal_paths() -> None:
    assert can_transition(OrderState.APPROVED, OrderState.SUBMITTING)
    assert not can_transition(OrderState.UNKNOWN, OrderState.REJECTED)
    assert not can_transition(OrderState.FILLED, OrderState.SUBMITTING)


def test_unknown_can_only_be_resolved_by_reconciliation() -> None:
    assert can_transition(OrderState.UNKNOWN, OrderState.ADOPTED)
    assert can_transition(OrderState.UNKNOWN, OrderState.RESOLVED_ABSENT)


def test_position_transition_guard() -> None:
    from goldbot.domain.fsm.position import can_transition as can

    assert can(PositionState.NONE, PositionState.OPENING)
    assert not can(PositionState.CLOSED, PositionState.OPEN)


def test_connection_gate_denies_orders_outside_ready() -> None:
    assert allows_new_orders(ConnectionState.READY)
    assert not allows_new_orders(ConnectionState.DEGRADED)
    assert not allows_new_orders(ConnectionState.LOST)


def test_illegal_connection_transition_raises() -> None:
    with pytest.raises(IllegalTransition):
        conn_ok(ConnectionState.DISCONNECTED, ConnectionState.READY)


def test_tick_derived_values() -> None:
    tick = Tick(
        symbol=Symbol("XAUUSD"),
        bid=1999.9,
        ask=2000.1,
        ts_event=Ts(datetime(2024, 3, 4, tzinfo=timezone.utc)),
        ts_recv=Ts(datetime(2024, 3, 4, tzinfo=timezone.utc)),
    )
    assert tick.mid == pytest.approx(2000.0)
    assert tick.spread == pytest.approx(0.2)
    assert Protection.UNPROTECTED != Protection.PROTECTED
