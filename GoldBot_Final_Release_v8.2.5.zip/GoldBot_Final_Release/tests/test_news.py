"""News blackout policy plus the tolerant economic-calendar CSV adapter."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

from goldbot.adapters.news_calendar import load_calendar, write_example_calendar
from goldbot.app.market_session import us_dst_active
from goldbot.app.news import (
    REASON_CONSERVATIVE,
    REASON_HIGH,
    REASON_MEDIUM,
    REASON_UNAVAILABLE,
    Impact,
    NewsEvent,
    NewsParams,
    NewsWindow,
    classify_events,
)

MONDAY = datetime(2024, 3, 4, tzinfo=timezone.utc)
FRIDAY = datetime(2024, 3, 8, tzinfo=timezone.utc)
SATURDAY = datetime(2024, 3, 9, tzinfo=timezone.utc)


def utc_at(day: datetime, hour: int, minute: int = 0) -> datetime:
    return day.replace(hour=hour, minute=minute)


def test_news_event_normalises_timestamps_to_utc() -> None:
    shifted = NewsEvent(datetime(2024, 3, 4, 15, 0, tzinfo=timezone(timedelta(hours=2))), Impact.HIGH)
    assert shifted.when_utc == utc_at(MONDAY, 13)
    naive = NewsEvent(datetime(2024, 3, 4, 14, 0), Impact.HIGH)
    assert naive.when_utc == utc_at(MONDAY, 14)


def test_impact_enum_roundtrip() -> None:
    assert {impact.value for impact in Impact} == {"high", "medium", "low"}
    assert Impact("high") is Impact.HIGH
    assert Impact.HIGH == "high"


def test_default_params_match_the_config_table() -> None:
    params = NewsParams()
    assert params.enabled is True
    assert params.high_before_minutes == 30
    assert params.high_after_minutes == 60
    assert params.medium_before_minutes == 15
    assert params.medium_after_minutes == 30
    assert params.fail_safe == "conservative"
    assert params.conservative_windows == ((14, 30, 15), (18, 0, 15))
    assert params.max_events == 500


def test_high_impact_before_window_is_inclusive() -> None:
    event = NewsEvent(utc_at(MONDAY, 14), Impact.HIGH)
    window = NewsWindow([event])
    state = window.blackout(utc_at(MONDAY, 13, 30))
    assert state.blackout is True
    assert state.reason == REASON_HIGH
    assert state.event == event
    assert state.until_utc == utc_at(MONDAY, 15)
    assert window.blackout(utc_at(MONDAY, 13, 29)).blackout is False


def test_high_impact_after_window_is_inclusive() -> None:
    window = NewsWindow([NewsEvent(utc_at(MONDAY, 14), Impact.HIGH)])
    assert window.blackout(utc_at(MONDAY, 15, 0)).blackout is True
    assert window.blackout(utc_at(MONDAY, 15, 1)).blackout is False


def test_medium_impact_window_edges() -> None:
    window = NewsWindow([NewsEvent(utc_at(MONDAY, 14), Impact.MEDIUM)])
    assert window.blackout(utc_at(MONDAY, 13, 45)).blackout is True
    assert window.blackout(utc_at(MONDAY, 13, 44)).blackout is False
    assert window.blackout(utc_at(MONDAY, 14, 30)).blackout is True
    assert window.blackout(utc_at(MONDAY, 14, 31)).blackout is False


def test_low_impact_never_blackouts() -> None:
    window = NewsWindow([NewsEvent(utc_at(MONDAY, 14), Impact.LOW)])
    assert window.blackout(utc_at(MONDAY, 14)).blackout is False


def test_high_impact_wins_over_overlapping_medium() -> None:
    high = NewsEvent(utc_at(MONDAY, 14), Impact.HIGH, "NFP")
    medium = NewsEvent(utc_at(MONDAY, 14, 10), Impact.MEDIUM, "Speech")
    state = NewsWindow([medium, high]).blackout(utc_at(MONDAY, 14, 5))
    assert state.blackout is True
    assert state.reason == REASON_HIGH
    assert state.event == high
    assert state.until_utc == utc_at(MONDAY, 15)


def test_earliest_high_event_wins_deterministically() -> None:
    first = NewsEvent(utc_at(MONDAY, 14), Impact.HIGH, "a")
    second = NewsEvent(utc_at(MONDAY, 14, 10), Impact.HIGH, "b")
    state = NewsWindow([second, first]).blackout(utc_at(MONDAY, 14, 5))
    assert state.event == first
    assert state.until_utc == utc_at(MONDAY, 15)


def test_expired_and_far_future_events_are_ignored() -> None:
    stale = NewsEvent(utc_at(FRIDAY, 14), Impact.HIGH)
    later = NewsEvent(utc_at(MONDAY, 11), Impact.HIGH)
    window = NewsWindow([stale, later])
    assert window.blackout(utc_at(MONDAY, 10)).blackout is False


def test_malformed_events_are_dropped_without_raising() -> None:
    good = NewsEvent(utc_at(MONDAY, 14), Impact.HIGH, "NFP")
    broken = NewsEvent(utc_at(MONDAY, 14), Impact.HIGH, "broken")
    object.__setattr__(broken, "when_utc", "not a datetime")
    kept = classify_events([good, broken, None, "junk", 42], NewsParams())  # type: ignore[list-item]
    assert kept == (good,)
    malformed_window = NewsWindow([None, "junk"])  # type: ignore[list-item]
    assert malformed_window.blackout(utc_at(MONDAY, 14)).blackout is False


def test_unknown_impact_becomes_medium() -> None:
    event = NewsEvent(utc_at(MONDAY, 14), "surprise")  # type: ignore[arg-type]
    assert event.impact is Impact.MEDIUM
    state = NewsWindow([event]).blackout(utc_at(MONDAY, 13, 50))
    assert state.blackout is True
    assert state.reason == REASON_MEDIUM


def test_classify_events_sorts_and_caps_to_the_newest_rows() -> None:
    times = [utc_at(MONDAY, hour) for hour in (10, 11, 12, 13, 14)]
    events = [NewsEvent(when, Impact.HIGH) for when in reversed(times)]
    kept = classify_events(events, NewsParams(max_events=2))
    assert [event.when_utc for event in kept] == [utc_at(MONDAY, 13), utc_at(MONDAY, 14)]


def test_disabled_news_filter_never_blackouts() -> None:
    event = NewsEvent(utc_at(MONDAY, 14), Impact.HIGH)
    window = NewsWindow([event], NewsParams(enabled=False))
    assert window.blackout(utc_at(MONDAY, 14)).blackout is False


def test_conservative_fallback_windows_are_deterministic() -> None:
    window = NewsWindow([], NewsParams(), calendar_available=False)
    state = window.blackout(utc_at(MONDAY, 14, 30))
    assert state.blackout is True
    assert state.reason == REASON_CONSERVATIVE
    assert state.event is None
    assert state.until_utc == utc_at(MONDAY, 14, 45)
    assert window.blackout(utc_at(MONDAY, 14, 14)).blackout is False
    assert window.blackout(utc_at(MONDAY, 14, 45)).blackout is True
    assert window.blackout(utc_at(MONDAY, 14, 46)).blackout is False
    assert window.blackout(utc_at(MONDAY, 18, 0)).until_utc == utc_at(MONDAY, 18, 15)
    assert window.blackout(utc_at(MONDAY, 18, 16)).blackout is False


def test_conservative_fallback_skips_the_weekend() -> None:
    window = NewsWindow([], NewsParams(), calendar_available=False)
    assert window.blackout(utc_at(SATURDAY, 14, 30)).blackout is False


def test_trading_disabled_mode_always_blackouts() -> None:
    window = NewsWindow([], NewsParams(fail_safe="trading_disabled"), calendar_available=False)
    state = window.blackout(utc_at(SATURDAY, 3))
    assert state.blackout is True
    assert state.reason == REASON_UNAVAILABLE
    assert state.event is None
    assert state.until_utc is None


def test_available_but_empty_calendar_is_clear() -> None:
    window = NewsWindow([], NewsParams(), calendar_available=True)
    assert window.blackout(utc_at(MONDAY, 14, 30)).blackout is False


def test_custom_conservative_windows() -> None:
    params = NewsParams(conservative_windows=((9, 0, 10),))
    window = NewsWindow([], params, calendar_available=False)
    assert window.blackout(utc_at(MONDAY, 8, 49)).blackout is False
    state = window.blackout(utc_at(MONDAY, 9, 5))
    assert state.blackout is True
    assert state.until_utc == utc_at(MONDAY, 9, 10)
    assert window.blackout(utc_at(MONDAY, 9, 10)).blackout is True
    assert window.blackout(utc_at(MONDAY, 9, 11)).blackout is False


@pytest.mark.parametrize(
    "params",
    [
        NewsParams(high_before_minutes=-1),
        NewsParams(fail_safe="nope"),  # type: ignore[arg-type]
        NewsParams(max_events=0),
        NewsParams(conservative_windows=((25, 0, 5),)),
        NewsParams(conservative_windows=((14, 30),)),  # type: ignore[arg-type]
    ],
)
def test_invalid_params_raise(params: NewsParams) -> None:
    with pytest.raises(ValueError):
        NewsWindow([], params)


JAN_MONDAY = datetime(2026, 1, 12, tzinfo=timezone.utc)
JULY_MONDAY = datetime(2026, 7, 13, tzinfo=timezone.utc)


def test_us_dst_rule_boundaries_are_deterministic() -> None:
    assert us_dst_active(datetime(2026, 3, 8, 6, 59, tzinfo=timezone.utc)) is False
    assert us_dst_active(datetime(2026, 3, 8, 7, 0, tzinfo=timezone.utc)) is True
    assert us_dst_active(datetime(2026, 11, 1, 5, 59, tzinfo=timezone.utc)) is True
    assert us_dst_active(datetime(2026, 11, 1, 6, 0, tzinfo=timezone.utc)) is False


def test_conservative_fallback_tracks_the_us_dst_release_clock() -> None:
    window = NewsWindow([], NewsParams(), calendar_available=False)
    winter = window.blackout(utc_at(JAN_MONDAY, 14, 30))
    assert winter.blackout is True
    assert winter.reason == REASON_CONSERVATIVE
    assert window.blackout(utc_at(JAN_MONDAY, 13, 30)).blackout is False
    summer = window.blackout(utc_at(JULY_MONDAY, 13, 30))
    assert summer.blackout is True
    assert summer.until_utc == utc_at(JULY_MONDAY, 13, 45)
    assert window.blackout(utc_at(JULY_MONDAY, 14, 30)).blackout is False


def test_conservative_fallback_second_window_follows_dst() -> None:
    window = NewsWindow([], NewsParams(), calendar_available=False)
    assert window.blackout(utc_at(JAN_MONDAY, 18, 0)).blackout is True
    assert window.blackout(utc_at(JULY_MONDAY, 17, 0)).blackout is True
    assert window.blackout(utc_at(JULY_MONDAY, 18, 0)).blackout is False


def test_conservative_fallback_around_dst_transition_dates() -> None:
    window = NewsWindow([], NewsParams(), calendar_available=False)
    friday_before = datetime(2026, 3, 6, tzinfo=timezone.utc)
    monday_after = datetime(2026, 3, 9, tzinfo=timezone.utc)
    friday_dst = datetime(2026, 10, 30, tzinfo=timezone.utc)
    monday_winter = datetime(2026, 11, 2, tzinfo=timezone.utc)
    assert window.blackout(utc_at(friday_before, 14, 30)).blackout is True
    assert window.blackout(utc_at(friday_before, 13, 30)).blackout is False
    assert window.blackout(utc_at(monday_after, 13, 30)).blackout is True
    assert window.blackout(utc_at(monday_after, 14, 30)).blackout is False
    assert window.blackout(utc_at(friday_dst, 13, 30)).blackout is True
    assert window.blackout(utc_at(monday_winter, 14, 30)).blackout is True


def test_custom_conservative_window_shifts_in_dst() -> None:
    params = NewsParams(conservative_windows=((9, 0, 10),))
    window = NewsWindow([], params, calendar_available=False)
    assert window.blackout(utc_at(JAN_MONDAY, 9, 0)).blackout is True
    assert window.blackout(utc_at(JAN_MONDAY, 8, 0)).blackout is False
    assert window.blackout(utc_at(JULY_MONDAY, 8, 0)).blackout is True
    assert window.blackout(utc_at(JULY_MONDAY, 9, 0)).blackout is False


def _write(path: Path, text: str) -> Path:
    path.write_text(text, encoding="utf-8")
    return path


def test_load_calendar_reads_iso_datetimes(scratch: Path) -> None:
    path = _write(
        scratch / "calendar.csv",
        "timestamp,impact,title,currency\n"
        "2024-03-08 14:30:00,high,US payrolls,USD\n"
        "2024-03-08T18:00:00+02:00,medium,ECB speech,EUR\n",
    )
    events, available = load_calendar(path)
    assert available is True
    assert [event.when_utc for event in events] == [utc_at(FRIDAY, 14, 30), utc_at(FRIDAY, 16)]
    assert [event.impact for event in events] == [Impact.HIGH, Impact.MEDIUM]


def test_load_calendar_accepts_separate_date_and_time_columns(scratch: Path) -> None:
    path = _write(
        scratch / "calendar.csv",
        "date,time,importance,event,currency\n"
        "2024-03-08,14:30,weird,US payrolls,\n"
        "2024-03-08,18:00,low,Fed speaker,USD\n",
    )
    events, available = load_calendar(path)
    assert available is True
    assert len(events) == 2
    assert events[0].impact is Impact.MEDIUM  # unknown importance is conservative
    assert events[0].currency == "USD"
    assert events[0].title == "US payrolls"
    assert events[1].impact is Impact.LOW


def test_load_calendar_skips_all_day_rows(scratch: Path) -> None:
    path = _write(
        scratch / "calendar.csv",
        "date,time,impact,title\n"
        "2024-03-08,,high,All day event\n",
    )
    events, available = load_calendar(path)
    assert available is True
    assert events == []


def test_load_calendar_skips_date_only_timestamps(scratch: Path) -> None:
    path = _write(scratch / "calendar.csv", "timestamp,impact\n2024-03-08,high\n")
    assert load_calendar(path) == ([], True)


def test_load_calendar_missing_file_is_unavailable(scratch: Path) -> None:
    assert load_calendar(scratch / "missing.csv") == ([], False)


def test_load_calendar_directory_is_unavailable(scratch: Path) -> None:
    assert load_calendar(scratch) == ([], False)


def test_load_calendar_unknown_columns_are_unavailable(scratch: Path) -> None:
    path = _write(scratch / "calendar.csv", "foo,bar\n1,2\n")
    assert load_calendar(path) == ([], False)


def test_load_calendar_undecodable_file_is_unavailable(scratch: Path) -> None:
    path = scratch / "broken.csv"
    path.write_bytes(b"\xff\xfe\x00\x00not utf-8")
    assert load_calendar(path) == ([], False)


def test_load_calendar_empty_file_is_unavailable(scratch: Path) -> None:
    path = scratch / "empty.csv"
    path.write_text("", encoding="utf-8")
    assert load_calendar(path) == ([], False)


def test_load_calendar_respects_max_events(scratch: Path) -> None:
    path = _write(
        scratch / "calendar.csv",
        "timestamp,impact\n"
        "2024-03-08 10:00:00,high\n"
        "2024-03-08 14:00:00,high\n"
        "2024-03-08 18:00:00,high\n",
    )
    events, available = load_calendar(path, params=NewsParams(max_events=1))
    assert available is True
    assert [event.when_utc for event in events] == [utc_at(FRIDAY, 18)]


def test_write_example_calendar_roundtrip(scratch: Path) -> None:
    path = scratch / "news" / "calendar.csv"
    written = write_example_calendar(path)
    assert written == path
    events, available = load_calendar(path)
    assert available is True
    assert len(events) == 4
    assert {event.impact for event in events} == {Impact.HIGH, Impact.MEDIUM, Impact.LOW}
    assert events == sorted(events, key=lambda event: event.when_utc)
