from __future__ import annotations

import io
import sys
import tarfile
from types import SimpleNamespace

from scripts import deploy_vps
import pytest


class _FakeTransport:
    def __init__(self):
        self.keepalive = None

    def set_keepalive(self, value):
        self.keepalive = value


class _FakeSSHClient:
    def __init__(self):
        self.connect_calls = []
        self.policy = None
        self.loaded_system_keys = False
        self.transport = _FakeTransport()

    def load_system_host_keys(self):
        self.loaded_system_keys = True

    def set_missing_host_key_policy(self, policy):
        self.policy = policy

    def connect(self, *args, **kwargs):
        self.connect_calls.append((args, kwargs))

    def get_transport(self):
        return self.transport


def test_ssh_key_connection_is_attempted_exactly_once(monkeypatch):
    client = _FakeSSHClient()
    reject_policy = object()
    fake_paramiko = SimpleNamespace(SSHClient=lambda: client, RejectPolicy=lambda: reject_policy)
    monkeypatch.setitem(sys.modules, "paramiko", fake_paramiko)

    result = deploy_vps._connect("host.example", "operator", "unused", "/keys/goldbot")

    assert result is client
    assert len(client.connect_calls) == 1
    assert client.connect_calls[0][1]["key_filename"] == "/keys/goldbot"
    assert client.transport.keepalive == 30
    assert client.loaded_system_keys is True
    assert client.policy is reject_policy


def test_password_connection_is_attempted_exactly_once(monkeypatch):
    client = _FakeSSHClient()
    reject_policy = object()
    fake_paramiko = SimpleNamespace(SSHClient=lambda: client, RejectPolicy=lambda: reject_policy)
    monkeypatch.setitem(sys.modules, "paramiko", fake_paramiko)

    result = deploy_vps._connect("host.example", "operator", "secret", "")

    assert result is client
    assert len(client.connect_calls) == 1
    assert client.connect_calls[0][1]["password"] == "secret"


def test_panel_token_write_command_is_shell_quoted_and_not_logged(monkeypatch, capsys):
    calls = []

    def fake_run(ssh, command, **kwargs):
        calls.append((command, kwargs))
        if command.startswith("stat -c"):
            return 0, "600 root", ""
        return 0, "", ""

    monkeypatch.setattr(deploy_vps, "_run", fake_run)
    token = "abcDEF0123456789_abcdefghijklmnopqrstuvwxyz'$(id)"
    result = deploy_vps._ensure_token(object(), token)

    assert result == token
    token_call = next((command, kwargs) for command, kwargs in calls if "GOLDBOT_PANEL_TOKEN=" in command)
    assert token_call[1].get("quiet") is True
    assert token_call[1].get("redact") is True
    assert deploy_vps.shlex.quote(f"GOLDBOT_PANEL_TOKEN={token}") in token_call[0]
    assert token not in capsys.readouterr().out


def test_panel_token_rejects_newline_injection(monkeypatch):
    calls = []
    monkeypatch.setattr(deploy_vps, "_run", lambda *a, **k: calls.append((a, k)) or (0, "", ""))
    with pytest.raises(deploy_vps.DeployError, match="single-line"):
        deploy_vps._ensure_token(object(), "A" * 24 + "\nGOLDBOT_OTHER=bad")
    assert calls == []


class _FakeStream:
    def __init__(self, payload, status=1):
        self.payload = payload
        self.channel = SimpleNamespace(recv_exit_status=lambda: status)

    def read(self):
        return self.payload


class _FakeSSHFailure:
    def __init__(self, stderr=b"remote failure"):
        self.stderr = stderr

    def exec_command(self, command, timeout=900):
        return None, _FakeStream(b"", 1), _FakeStream(self.stderr, 1)


def test_sensitive_remote_command_is_redacted_from_failure(monkeypatch):
    token = "top-secret-token-value-123456"
    with pytest.raises(deploy_vps.DeployError) as exc:
        deploy_vps._run(_FakeSSHFailure(token.encode()), f"write {token}", quiet=True, redact=True)
    assert token not in str(exc.value)
    assert "<redacted command>" in str(exc.value)


def test_vps_bundle_contains_panel_runtime_and_excludes_local_state():
    payload = deploy_vps._pack_repo()
    with tarfile.open(fileobj=io.BytesIO(payload), mode="r:gz") as archive:
        names = set(archive.getnames())
    assert "run_goldbot.py" in names
    assert "src/goldbot/web/ui.html" in names
    assert "config/base.toml" in names
    assert "config/risk_profiles.toml" in names
    assert "docs/DEPLOY-VPS.md" in names
    assert not any(name.startswith(("var/", "tests/", "reports/")) for name in names)
    assert not any(name.endswith((".db", ".jsonl", ".pyc")) for name in names)
