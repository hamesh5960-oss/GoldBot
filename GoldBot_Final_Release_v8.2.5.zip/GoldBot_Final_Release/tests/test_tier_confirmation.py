"""Property invariants of the locked confirmation-tier design.

Pins the four invariants the design commits to:
  1. confirmation_count == 0        => base D
  2. confirmation_count >= 4        => base A+
  3. final tier is base-1, base or base+1 (except D)
  4. a D base always stays D
plus the zone filter, the R:R absolute floor, the layer-3 thresholds and the
C/A+ clamps.
"""

from __future__ import annotations

from goldbot.app.decision import (
    TIER_ORDER,
    TIER_RISK_PCT,
    Tier,
    adjust_tier,
    decide,
    layer3_delta,
    tier_base_from_confirmations,
)


def _rank(tier: Tier) -> int:
    return TIER_ORDER.index(tier)


def test_zero_confirmations_always_base_d() -> None:
    assert tier_base_from_confirmations(0.0) is Tier.D
    assert tier_base_from_confirmations(0) is Tier.D
    assert tier_base_from_confirmations(-3.0) is Tier.D
    for score in (-1.0, -0.6, 0.0, 0.6, 1.0):
        assert decide(confirmation_count=0.0, layer3_score=score).tier is Tier.D


def test_four_or_more_confirmations_base_a_plus() -> None:
    for count in (4.0, 4.5, 5.0, 5.5, 6.0, 6.5, 100.0):
        assert tier_base_from_confirmations(count) is Tier.A_PLUS


def test_final_tier_stays_within_one_step_of_base() -> None:
    scores = (-1.0, -0.61, -0.6, -0.59, 0.0, 0.59, 0.6, 0.61, 1.0)
    counts = (0.0, 0.5, 1.0, 1.5, 2.0, 2.5, 3.0, 3.5, 4.0, 5.0, 6.0)
    for count in counts:
        base = tier_base_from_confirmations(count)
        for score in scores:
            final = decide(confirmation_count=count, layer3_score=score).tier
            if base is Tier.D:
                assert final is Tier.D
            else:
                assert abs(_rank(final) - _rank(base)) <= 1, (count, score)


def test_d_base_never_moves() -> None:
    for delta in (-3, -2, -1, 0, 1, 2, 3):
        assert adjust_tier(Tier.D, delta) is Tier.D
    decision = decide(confirmation_count=0.0, layer3_score=5.0)
    assert decision.tier is Tier.D
    assert decision.hard_floor is True


def test_higher_count_never_lowers_the_base() -> None:
    previous = Tier.D
    for count in (0.0, 0.5, 1.0, 1.5, 2.0, 2.5, 3.0, 3.5, 4.0, 5.0, 6.0, 7.0):
        current = tier_base_from_confirmations(count)
        assert _rank(current) <= _rank(previous)
        previous = current


def test_zone_filter_is_independent_of_confirmations() -> None:
    for count in (0.0, 2.0, 4.0, 6.0):
        filtered = decide(confirmation_count=count, zone_score=49.999, min_zone=50.0)
        assert filtered.tier is Tier.D
        assert filtered.reasons == ("zone_filter",)
    for count in (2.0, 4.0, 6.0):
        passed = decide(confirmation_count=count, zone_score=50.0, min_zone=50.0)
        assert "zone_filter" not in passed.reasons


def test_rr_absolute_floor_is_independent_of_confirmations() -> None:
    for count in (0.0, 2.0, 4.0, 6.0):
        filtered = decide(confirmation_count=count, rr_net=0.999, rr_absolute_floor=1.0)
        assert filtered.rejected
        assert filtered.reasons == ("rr_absolute_floor",)
    for count in (2.0, 4.0):
        assert not decide(
            confirmation_count=count, rr_net=1.0, rr_absolute_floor=1.0
        ).rejected


def test_layer3_threshold_boundaries() -> None:
    assert layer3_delta(0.5999999) == 0
    assert layer3_delta(0.6) == 1
    assert layer3_delta(-0.5999999) == 0
    assert layer3_delta(-0.6) == -1
    assert layer3_delta(0.0) == 0


def test_layer3_clamps_at_c_and_a_plus() -> None:
    assert adjust_tier(Tier.C, -1) is Tier.C
    assert adjust_tier(Tier.A_PLUS, 1) is Tier.A_PLUS
    worst = _rank(Tier.C)
    best = _rank(Tier.A_PLUS)
    for base in TIER_ORDER:
        for delta in (-3, -1, 0, 1, 3):
            final = adjust_tier(base, delta)
            if base is Tier.NOISE:
                assert final is Tier.NOISE
            elif base is Tier.D:
                assert final is Tier.D
            else:
                assert best <= _rank(final) <= worst


def test_confirmation_set_passthrough_is_a_tuple() -> None:
    decision = decide(
        confirmation_count=3.0, confirmation_set=["zone", "trend", "layer3"]
    )
    assert decision.confirmation_set == ("zone", "trend", "layer3")
    assert isinstance(decision.confirmation_set, tuple)


def test_risk_table_follows_the_tier() -> None:
    expected = {0.0: 0.0, 1.0: 0.25, 2.0: 0.5, 3.0: 0.75, 4.0: 1.0}
    for count, risk in expected.items():
        decision = decide(confirmation_count=count)
        assert decision.risk_base_pct == TIER_RISK_PCT[decision.tier]
        assert decision.risk_base_pct == risk
