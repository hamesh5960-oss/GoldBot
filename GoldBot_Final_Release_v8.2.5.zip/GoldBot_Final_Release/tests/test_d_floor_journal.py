"""D-floor journal: the hard-floor tier is recorded, counted and exported.

ADR-034: zero confirmations (or an S/R zone filter) produce tier D. D never
executes and never reaches gates/capital, but it is journaled as tier "D" so
counterfactual analysis can see it; the Excel workbook keeps the D label.
"""

from __future__ import annotations

import zipfile

from goldbot.adapters.xlsx import build_signal_workbook, write_workbook
from goldbot.domain.events import (
    CAPITAL_LEVEL_ORDER,
    SignalLevelRecord,
    SignalRecord,
)


def _d_signal(signal_id: str = "sig-d") -> SignalRecord:
    # A zero-confirmation D that the engine journals as a watch signal; every
    # execution field stays unset because the row never reaches capital.
    return SignalRecord(
        signal_id=signal_id,
        ts_utc="2024-03-06T10:00:00+00:00",
        symbol="XAUUSD",
        side="buy",
        strategy="numeric",
        session="london",
        tier="D",
        tier_base="D",
        tier_final="D",
        confirmation_count=0.0,
        confirmation_set=(),
        layer3_score=0.0,
        layer3_delta=0,
        d_hard_floor=True,
        entry=2000.0,
        sl=1990.0,
        tp1=2020.0,
        tp2=2030.0,
        rr_net=2.0,
        gate_status={},
        active_level="",
        active_decision="watch",
        active_reason="d_hard_floor",
        params_snapshot={"profile": "medium"},
    )


def _d_levels(signal_id: str = "sig-d") -> list[SignalLevelRecord]:
    return [
        SignalLevelRecord(
            signal_id=signal_id,
            level=level,
            eligible=False,
            reason="d_hard_floor",
            session="london",
            tier="D",
        )
        for level in CAPITAL_LEVEL_ORDER
    ]


def test_sqlite_stats_keep_the_d_row_visible(journal) -> None:
    journal.record_signal(_d_signal())
    journal.record_signal_levels("sig-d", _d_levels())

    stats = journal.stats()
    assert stats["signals_total"] == 1
    assert stats["signals_executed"] == 0
    assert stats["signals_watch"] == 1
    assert stats["by_tier"]["D"]["signals"] == 1
    assert stats["by_tier"]["D"]["executed"] == 0
    assert stats["by_tier"]["D"]["watch"] == 1
    assert stats["capability_rows"] == len(CAPITAL_LEVEL_ORDER)

    # stats() has no d_hard_floor counter yet: derive it from the stored rows.
    signals_d_hard_floor = sum(1 for signal in journal.signals() if signal.d_hard_floor)
    assert signals_d_hard_floor == 1
    stored = list(journal.signals())
    assert stored[0].tier == "D"
    assert stored[0].d_hard_floor is True
    assert stored[0].active_decision == "watch"


def test_xlsx_accepts_the_d_row_without_execution_fields(scratch) -> None:
    sheets = build_signal_workbook([_d_signal()], _d_levels())
    by_name = {name: (headers, rows) for name, headers, rows in sheets}

    headers, rows = by_name["Signals"]
    row = dict(zip(headers, rows[0]))
    assert row["tier"] == "D"
    assert row["tier_base"] == "D"
    assert row["d_hard_floor"] is True
    assert row["confirmation_count"] == 0.0
    assert row["active_decision"] == "watch"
    # A D row has no execution fields; the workbook must not require them.
    assert row["active_lot"] is None
    assert row["active_risk_pct"] is None
    assert row["active_risk_dollars"] is None

    matrix_headers, matrix_rows = by_name["Capability_Matrix"]
    matrix = dict(zip(matrix_headers, matrix_rows[0]))
    assert matrix["tier"] == "D"
    assert matrix["active_decision"] == "watch"

    _, session_rows = by_name["Session_Analysis"]
    d_tier_rows = [item for item in session_rows if item[1] == "tier" and item[2] == "D"]
    assert d_tier_rows
    assert d_tier_rows[0][3] == 1  # signals
    assert d_tier_rows[0][4] == 0  # executed
    assert d_tier_rows[0][5] == 1  # watch

    _, summary_rows = by_name["Summary"]
    summary = {values[0]: values[1] for values in summary_rows}
    assert summary["signals_total"] == 1
    assert summary["signals_executed"] == 0
    assert summary["signals_watch"] == 1
    assert summary["capability_rows"] == len(CAPITAL_LEVEL_ORDER)

    # A D row with no capability levels at all is still accepted.
    assert build_signal_workbook([_d_signal("sig-bare")], [])

    # The label survives the real workbook write.
    out = scratch / "d_floor_signals.xlsx"
    write_workbook(out, sheets)
    assert out.exists() and out.stat().st_size > 0
    with zipfile.ZipFile(out) as archive:
        sheet = archive.read("xl/worksheets/sheet1.xml").decode("utf-8")
    assert ">D<" in sheet
    assert ">watch<" in sheet
