"""Load-time consistency of duplicated instrument/cost config sources (CJ-02).

ADR-019 introduced [costs].point/contract_size/commission_per_lot_rt while the
broker/spec layer keeps [symbol].point/contract_size and
[execution].commission_per_lot.  A silent divergence would misprice sizing and
PnL, so Settings fails closed at load time and points at both sources.
"""

from __future__ import annotations

import tomllib
from pathlib import Path

import pytest
from pydantic import ValidationError

from goldbot.adapters.config import Settings, load_settings
from goldbot.domain.errors import ConfigError

from helpers import CONFIG

BASE = CONFIG / "base.toml"


def _raw() -> dict:
    return tomllib.loads(BASE.read_text(encoding="utf-8"))


def test_current_config_passes_the_consistency_check() -> None:
    settings = load_settings(BASE)
    assert settings.symbol.point == settings.costs.point
    assert settings.symbol.contract_size == settings.costs.contract_size
    assert settings.execution.commission_per_lot == settings.costs.commission_per_lot_rt


@pytest.mark.parametrize(
    ("section", "field", "value", "mismatched_with"),
    [
        ("costs", "point", 0.02, "symbol.point"),
        ("symbol", "point", 0.02, "costs.point"),
        ("costs", "contract_size", 10.0, "symbol.contract_size"),
        ("symbol", "contract_size", 10.0, "costs.contract_size"),
        (
            "execution",
            "commission_per_lot",
            9.0,
            "costs.commission_per_lot_rt",
        ),
        (
            "costs",
            "commission_per_lot_rt",
            9.0,
            "execution.commission_per_lot",
        ),
    ],
)
def test_mismatched_duplicate_constant_is_rejected(
    section: str, field: str, value: float, mismatched_with: str
) -> None:
    raw = _raw()
    raw[section][field] = value
    with pytest.raises(ValidationError) as excinfo:
        Settings.model_validate(raw)
    message = str(excinfo.value)
    assert "duplicated instrument/cost constants" in message
    assert "ADR-019" in message
    assert mismatched_with in message


def test_load_settings_wraps_consistency_failure_in_config_error(
    tmp_path: Path,
) -> None:
    source = BASE.read_text(encoding="utf-8")
    old = "commission_per_lot = 7.0"
    assert old in source
    bad = source.replace(old, "commission_per_lot = 9.0", 1)
    path = tmp_path / "inconsistent.toml"
    path.write_text(bad, encoding="utf-8")

    with pytest.raises(ConfigError) as excinfo:
        load_settings(path)

    message = str(excinfo.value)
    assert "execution.commission_per_lot=9" in message
    assert "costs.commission_per_lot_rt=7" in message
    assert "inconsistent.toml" in message


def test_default_settings_are_consistent() -> None:
    settings = Settings()
    assert settings.symbol.point == settings.costs.point
    assert settings.symbol.contract_size == settings.costs.contract_size
    assert settings.execution.commission_per_lot == settings.costs.commission_per_lot_rt
