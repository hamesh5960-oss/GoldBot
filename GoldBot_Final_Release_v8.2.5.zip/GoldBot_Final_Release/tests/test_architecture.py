"""Architecture guards: dependency rules enforced in CI, not by convention."""

from __future__ import annotations

import ast
from pathlib import Path

from helpers import ROOT

SRC = ROOT / "src"
SDK_ALLOWED = {"goldbot.strategy_api"}
STDLIB_ALLOWED = {
    "__future__",
    "typing",
    "dataclasses",
    "datetime",
    "enum",
    "math",
    "statistics",
    "collections",
}
THIRD_PARTY_ALLOWED = {"pydantic"}


def _imported_modules(path: Path) -> list[str]:
    tree = ast.parse(path.read_text(encoding="utf-8"))
    modules: list[str] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            modules.extend(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module and node.level == 0:
            modules.append(node.module)
    return modules


def test_strategies_only_touch_the_sdk() -> None:
    """A plugin may import the SDK, stdlib and pydantic — nothing else from goldbot."""
    plugins = [p for p in (SRC / "strategies").rglob("*.py") if p.name != "registry.py"]
    assert plugins, "no strategy plugins found"
    for path in plugins:
        for module in _imported_modules(path):
            root = module.split(".")[0]
            if root == "goldbot":
                assert any(module == m or module.startswith(m + ".") for m in SDK_ALLOWED), (
                    f"{path.name} imports {module}; plugins may only import goldbot.strategy_api"
                )
            else:
                assert root in STDLIB_ALLOWED or root in THIRD_PARTY_ALLOWED, (
                    f"{path.name} imports unexpected '{module}'"
                )


def test_no_module_imports_metatrader5_except_gateway() -> None:
    offenders = []
    for path in SRC.rglob("*.py"):
        for module in _imported_modules(path):
            if module.split(".")[0] == "MetaTrader5":
                if "goldbot_gateway" not in path.parts:
                    offenders.append(str(path))
    assert not offenders, f"MetaTrader5 leaked outside the gateway: {offenders}"


def test_domain_and_app_do_not_import_adapters() -> None:
    for package in ("domain", "app"):
        for path in (SRC / "goldbot" / package).rglob("*.py"):
            for module in _imported_modules(path):
                assert not module.startswith("goldbot.adapters"), (
                    f"{path.relative_to(SRC)} imports adapter {module}"
                )


def test_domain_has_no_io_imports() -> None:
    forbidden = {"sqlite3", "urllib", "requests", "httpx", "socket", "subprocess", "os"}
    for path in (SRC / "goldbot" / "domain").rglob("*.py"):
        for module in _imported_modules(path):
            assert module.split(".")[0] not in forbidden, f"{path.name} imports {module}"


def test_ports_do_not_import_application_layer() -> None:
    for path in (SRC / "goldbot" / "ports").rglob("*.py"):
        for module in _imported_modules(path):
            assert not module.startswith("goldbot.app"), f"{path.name} imports {module}"
            assert not module.startswith("goldbot.adapters"), f"{path.name} imports {module}"


def test_no_direct_wall_clock_in_core() -> None:
    """Time must come from IClock, otherwise replay stops being reproducible."""
    suspicious = []
    for path in list((SRC / "goldbot" / "domain").rglob("*.py")) + list(
        (SRC / "goldbot" / "app").rglob("*.py")
    ):
        text = path.read_text(encoding="utf-8")
        if "datetime.now(" in text and "clock" not in path.name and "adapters" not in str(path):
            suspicious.append(path.name)
    assert not suspicious, f"direct wall-clock usage in core: {suspicious}"
