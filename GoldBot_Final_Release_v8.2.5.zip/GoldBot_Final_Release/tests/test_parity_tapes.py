"""Parity tapes: deterministic scenario builders and their documented magnitudes."""

from __future__ import annotations

import json
from datetime import timedelta
from pathlib import Path

import pytest

from goldbot.adapters.tape import TapeFeed
from goldbot.adapters.tape_library import (
    BROKER_MIN_STOPS_POINTS,
    BURST_TICKS,
    DISCONNECT_SECONDS,
    GAP_PCT,
    INVALID_STOPS_POINTS,
    MIN_BARS,
    NORMAL_SPREAD,
    PARTIAL_VOLUME,
    REQUOTE_POINTS,
    SCENARIO_NAMES,
    SL_FAIL_SLIPPAGE_POINTS,
    SPREAD_SPIKE_MULT,
    ScenarioTape,
    build_scenario,
    disconnect,
    gap_open,
    invalid_stops,
    partial_then_sl_fail,
    requote,
    write_scenario_tape,
)

from helpers import make_info

EXPECTED_SCENARIOS = (
    "gap_open",
    "spread_spike",
    "requote",
    "disconnect",
    "invalid_stops",
    "partial_then_sl_fail",
)
POINT = 0.01


def _price_range(tape: ScenarioTape, indexes: tuple[int, ...]) -> float:
    prices = [tape.ticks[index].mid for index in indexes]
    return max(prices) - min(prices)


def test_scenario_registry_is_complete() -> None:
    assert set(SCENARIO_NAMES) == set(EXPECTED_SCENARIOS)
    assert len(SCENARIO_NAMES) == 6


@pytest.mark.parametrize("name", SCENARIO_NAMES)
def test_every_scenario_is_deterministic_with_markers(name: str) -> None:
    first = build_scenario(name)
    second = build_scenario(name)

    assert isinstance(first, ScenarioTape)
    assert first.scenario == name
    assert first.ticks == second.ticks
    assert first.bars == second.bars
    assert first.markers == second.markers

    assert len(first.bars) >= MIN_BARS
    assert all(bar.timeframe == "M15" for bar in first.bars)
    for previous, current in zip(first.bars, first.bars[1:]):
        assert current.open_time - previous.open_time == timedelta(minutes=15)
    assert len(first.ticks) > len(first.bars)  # at least one dense burst

    events = [tick.ts_event for tick in first.ticks]
    assert events == sorted(events)  # replay order is chronological

    markers = first.markers
    assert markers.scenario == name
    assert markers.expected
    assert markers.critical_bar_indexes
    assert len(markers.critical_tick_indexes) == BURST_TICKS
    assert all(0 <= index < len(first.ticks) for index in markers.critical_tick_indexes)
    assert all(0 <= index < len(first.bars) for index in markers.critical_bar_indexes)
    assert markers.magnitudes


def test_write_tape_roundtrips_through_tape_feed(scratch: Path) -> None:
    tape = gap_open()
    path = scratch / "gap_open.jsonl"
    count = tape.write_tape(path)

    assert count == len(tape.ticks)
    assert path.stat().st_size < 2_000_000

    sidecar = path.with_suffix(".meta.json")
    payload = json.loads(sidecar.read_text(encoding="utf-8"))
    assert payload["scenario"] == "gap_open"
    assert payload["bars"] == len(tape.bars)
    assert payload["ticks"] == count
    assert payload["critical_tick_indexes"] == list(tape.markers.critical_tick_indexes)
    assert payload["expected"] == tape.markers.expected
    assert payload["magnitudes"] == tape.markers.magnitudes

    feed = TapeFeed(path, tape.symbol, make_info(), close_final_bar=False)
    replayed = list(feed.stream())
    assert len(replayed) == count
    assert replayed[0].bid == pytest.approx(tape.ticks[0].bid)
    assert replayed[-1].ask == pytest.approx(tape.ticks[-1].ask)

    # Default replay appends exactly one volume-0 closing tick so the final
    # partial bar is closed; byte-for-byte replay is opt-out only.
    closing = list(
        TapeFeed(path, tape.symbol, make_info()).stream()
    )
    assert len(closing) == count + 1
    assert closing[-1].volume == 0
    assert closing[-1].bid == pytest.approx(replayed[-1].bid)
    assert closing[-1].ask == pytest.approx(replayed[-1].ask)


@pytest.mark.parametrize("name", SCENARIO_NAMES)
def test_every_tape_is_small_enough(scratch: Path, name: str) -> None:
    path = scratch / f"{name}.jsonl"
    count = write_scenario_tape(name, path)
    assert count > MIN_BARS
    assert path.stat().st_size < 2_000_000
    assert path.with_suffix(".meta.json").exists()


def test_unknown_scenario_and_short_series_are_rejected() -> None:
    with pytest.raises(ValueError, match="unknown scenario"):
        build_scenario("does-not-exist")
    with pytest.raises(ValueError, match="at least"):
        build_scenario("gap_open", bars=10)


def test_gap_open_magnitude_and_marker() -> None:
    tape = gap_open()
    (gap_index,) = tape.markers.critical_bar_indexes
    previous_close = tape.bars[gap_index - 1].c
    realized = tape.bars[gap_index].o / previous_close - 1.0

    assert realized == pytest.approx(GAP_PCT, rel=1e-3)
    assert tape.markers.magnitudes["gap_pct"] == pytest.approx(GAP_PCT)
    assert tape.markers.magnitudes["gap_price"] == pytest.approx(
        tape.bars[gap_index].o - previous_close, abs=0.01
    )
    first_critical = min(tape.markers.critical_tick_indexes)
    assert tape.ticks[first_critical].mid / previous_close - 1.0 == pytest.approx(
        GAP_PCT, rel=1e-3
    )


def test_spread_spike_magnitude_and_marker() -> None:
    tape = build_scenario("spread_spike")
    indexes = tape.markers.critical_tick_indexes
    spreads = [tape.ticks[index].spread for index in indexes]

    assert max(spreads) == pytest.approx(NORMAL_SPREAD * SPREAD_SPIKE_MULT)
    assert min(spreads) == pytest.approx(NORMAL_SPREAD * 2.0)
    assert tape.markers.magnitudes["spread_mult"] == SPREAD_SPIKE_MULT
    assert tape.markers.magnitudes["spike_spread"] == pytest.approx(
        NORMAL_SPREAD * SPREAD_SPIKE_MULT
    )
    assert tape.ticks[0].spread == pytest.approx(NORMAL_SPREAD)


def test_requote_magnitude_and_marker() -> None:
    tape = requote()
    indexes = tape.markers.critical_tick_indexes

    assert _price_range(tape, indexes) == pytest.approx(REQUOTE_POINTS * POINT, abs=0.02)
    assert tape.markers.magnitudes["requote_points"] == REQUOTE_POINTS
    assert tape.markers.magnitudes["requote_price"] == pytest.approx(REQUOTE_POINTS * POINT)
    assert any(tick.ts_recv.wall > tick.ts_event.wall for tick in tape.ticks)


def test_disconnect_gap_is_longer_than_the_stale_limit() -> None:
    tape = disconnect()
    deltas = [
        (tape.ticks[index].ts_event.wall - tape.ticks[index - 1].ts_event.wall).total_seconds()
        for index in range(1, len(tape.ticks))
    ]

    assert max(deltas) >= DISCONNECT_SECONDS
    assert tape.markers.magnitudes["gap_seconds"] >= DISCONNECT_SECONDS
    assert tape.markers.magnitudes["bars_without_ticks"] > 0
    assert len(tape.bars) >= MIN_BARS  # bars stay on the grid while ticks are missing


def test_invalid_stops_is_inside_the_broker_limit() -> None:
    tape = invalid_stops()
    magnitudes = tape.markers.magnitudes

    assert magnitudes["sl_distance_points"] == INVALID_STOPS_POINTS
    assert magnitudes["broker_min_stops_points"] == BROKER_MIN_STOPS_POINTS
    assert magnitudes["sl_distance_points"] < magnitudes["broker_min_stops_points"]
    assert magnitudes["sl_distance_price"] == pytest.approx(INVALID_STOPS_POINTS * POINT)
    assert _price_range(tape, tape.markers.critical_tick_indexes) == pytest.approx(
        INVALID_STOPS_POINTS * POINT, abs=0.02
    )
    assert "reject" in tape.markers.expected.lower()


def test_partial_fill_then_sl_fail_scenario() -> None:
    tape = partial_then_sl_fail()
    magnitudes = tape.markers.magnitudes

    assert magnitudes["partial_volume"] == PARTIAL_VOLUME
    assert PARTIAL_VOLUME == 0.01  # equals the symbol's min_volume
    assert magnitudes["sl_slippage_points"] == SL_FAIL_SLIPPAGE_POINTS
    assert SL_FAIL_SLIPPAGE_POINTS > magnitudes["broker_min_stops_points"]
    assert _price_range(tape, tape.markers.critical_tick_indexes) == pytest.approx(
        SL_FAIL_SLIPPAGE_POINTS * POINT, abs=0.02
    )
    assert "unknown" in tape.markers.expected.lower()
    assert "reconcile" in tape.markers.expected.lower()
