"""Weekend-close policy: broker session close, flatten window and close order."""

from __future__ import annotations

from datetime import datetime, time, timedelta, timezone

import pytest

from goldbot.app.weekend import (
    REASON_SESSION_END,
    REASON_WINDOW,
    WeekendParams,
    broker_time,
    close_order_key,
    fallback_close_deadline,
    in_weekend_close_window,
    next_session_open,
    session_end_broker,
    weekend_close_plan,
    weekend_override_allowed,
    weekend_plan_utc,
)
from goldbot.domain.model import SessionWindow, Symbol, SymbolInfo

# 2024-03-04 is a Monday, so 2024-03-08 is the Friday close of that week.
MONDAY = datetime(2024, 3, 4, 10, 0)
FRIDAY = datetime(2024, 3, 8)
SATURDAY = datetime(2024, 3, 9)
SUNDAY = datetime(2024, 3, 10)
NEXT_MONDAY = datetime(2024, 3, 11)

SESSIONS = (SessionWindow(time(1, 0), time(23, 59)),)
OVERNIGHT = (SessionWindow(time(22, 0), time(2, 0)),)


def at(day: datetime, hour: int, minute: int = 0) -> datetime:
    return day.replace(hour=hour, minute=minute)


def make_info(offset_hours: float) -> SymbolInfo:
    return SymbolInfo(
        symbol=Symbol("XAUUSD"),
        broker_symbol="XAUUSD.a",
        sessions=SESSIONS,
        broker_offset=timedelta(hours=offset_hours),
    )


def test_session_end_is_the_next_close_same_day() -> None:
    assert session_end_broker(at(FRIDAY, 10), SESSIONS) == at(FRIDAY, 23, 59)


def test_session_end_at_the_exact_close_is_inclusive() -> None:
    assert session_end_broker(at(FRIDAY, 23, 59), SESSIONS) == at(FRIDAY, 23, 59)


def test_session_end_rolls_forward_after_the_close() -> None:
    # Saturday opens no session, so the next close is Monday's.
    assert session_end_broker(at(SATURDAY, 0), SESSIONS) == at(NEXT_MONDAY, 23, 59)


def test_session_end_handles_an_overnight_window() -> None:
    assert session_end_broker(at(FRIDAY, 1), OVERNIGHT) == at(FRIDAY, 2)
    assert session_end_broker(at(FRIDAY, 3), OVERNIGHT) == at(SATURDAY, 2)
    assert session_end_broker(at(FRIDAY, 23), OVERNIGHT) == at(SATURDAY, 2)


def test_session_end_picks_the_earliest_of_several_windows() -> None:
    sessions = (SessionWindow(time(1, 0), time(10, 0)), SessionWindow(time(12, 0), time(23, 59)))
    assert session_end_broker(at(FRIDAY, 0, 30), sessions) == at(FRIDAY, 10)
    assert session_end_broker(at(FRIDAY, 11), sessions) == at(FRIDAY, 23, 59)


def test_next_session_open_skips_the_weekend() -> None:
    assert next_session_open(at(FRIDAY, 23, 59), SESSIONS) == at(NEXT_MONDAY, 1)
    assert next_session_open(at(FRIDAY, 0, 30), SESSIONS) == at(FRIDAY, 1)


@pytest.mark.parametrize("minute,expected", [(28, False), (29, True), (30, True)])
def test_close_window_opens_thirty_minutes_before_the_friday_close(
    minute: int, expected: bool
) -> None:
    plan = in_weekend_close_window(at(FRIDAY, 23, minute), SESSIONS, WeekendParams())
    assert plan.flatten is expected
    if expected:
        assert plan.reason == REASON_WINDOW
        assert plan.deadline == at(FRIDAY, 23, 59)
        assert plan.window_start == at(FRIDAY, 23, 29)
    else:
        assert plan.reason == ""
        assert plan.deadline is None
        assert plan.window_start is None


def test_midweek_is_never_a_weekend_window() -> None:
    tuesday = datetime(2024, 3, 5)
    thursday = datetime(2024, 3, 7)
    assert not in_weekend_close_window(at(tuesday, 23, 50), SESSIONS, WeekendParams()).flatten
    assert not in_weekend_close_window(at(thursday, 23, 50), SESSIONS, WeekendParams()).flatten


@pytest.mark.parametrize(
    "moment", [at(SATURDAY, 12), at(SUNDAY, 20), at(NEXT_MONDAY, 0, 30)]
)
def test_weekend_gap_stays_flat_until_the_monday_open(moment: datetime) -> None:
    plan = in_weekend_close_window(moment, SESSIONS, WeekendParams())
    assert plan.flatten is True
    assert plan.reason == REASON_SESSION_END
    assert plan.deadline == at(FRIDAY, 23, 59)
    assert plan.window_start == at(FRIDAY, 23, 29)


def test_the_plan_clears_at_the_monday_open() -> None:
    assert not in_weekend_close_window(at(NEXT_MONDAY, 1), SESSIONS, WeekendParams()).flatten
    assert not in_weekend_close_window(at(NEXT_MONDAY, 12), SESSIONS, WeekendParams()).flatten


def test_disabled_policy_is_never_armed() -> None:
    plan = in_weekend_close_window(at(FRIDAY, 23, 50), SESSIONS, WeekendParams(enabled=False))
    assert plan.flatten is False
    assert plan.reason == ""


def test_overnight_session_pushes_the_weekly_close_into_saturday() -> None:
    params = WeekendParams()
    assert not in_weekend_close_window(at(SATURDAY, 1, 29), OVERNIGHT, params).flatten
    plan = in_weekend_close_window(at(SATURDAY, 1, 30), OVERNIGHT, params)
    assert plan.flatten is True
    assert plan.reason == REASON_WINDOW
    assert plan.deadline == at(SATURDAY, 2)
    post_close = in_weekend_close_window(at(SATURDAY, 2, 30), OVERNIGHT, params)
    assert post_close.flatten is True
    assert post_close.reason == REASON_SESSION_END
    assert in_weekend_close_window(at(NEXT_MONDAY, 21), OVERNIGHT, params).flatten is True
    assert not in_weekend_close_window(at(NEXT_MONDAY, 22), OVERNIGHT, params).flatten


def test_dst_offset_moves_the_same_utc_instant_across_the_window() -> None:
    now_utc = datetime(2024, 3, 8, 20, 45, tzinfo=timezone.utc)
    winter = make_info(2.0)  # broker 22:45, before the 23:29 window start
    summer = make_info(3.0)  # broker 23:45, inside the window
    assert broker_time(now_utc, winter) == now_utc + timedelta(hours=2)
    assert broker_time(now_utc, summer) == now_utc + timedelta(hours=3)
    assert not weekend_plan_utc(now_utc, winter).flatten
    plan = weekend_plan_utc(now_utc, summer)
    assert plan.flatten is True
    assert plan.reason == REASON_WINDOW
    assert plan.deadline == datetime(2024, 3, 8, 23, 59, tzinfo=timezone.utc)


def test_close_order_profit_first_puts_winners_before_losers() -> None:
    params = WeekendParams(close_order="profit_first")
    positions = {101: 5.0, 102: -20.0, 103: 0.0, 104: -20.0}
    assert weekend_close_plan(positions, params) == (101, 103, 102, 104)


def test_close_order_loss_first_puts_losers_first() -> None:
    params = WeekendParams(close_order="loss_first")
    positions = {101: 5.0, 102: -20.0, 103: 0.0, 104: -20.0}
    assert weekend_close_plan(positions, params) == (102, 104, 103, 101)


def test_close_order_ticket_is_pure_ticket_order() -> None:
    params = WeekendParams(close_order="ticket")
    positions = {9: 5.0, 2: -20.0, 7: 0.0}
    assert weekend_close_plan(positions, params) == (2, 7, 9)
    assert close_order_key(-20.0, 2, params) == (0.0, 2)


def test_close_plan_is_independent_of_mapping_order() -> None:
    params = WeekendParams(close_order="profit_first")
    first = {101: 5.0, 102: -20.0, 103: 0.0}
    second = {103: 0.0, 101: 5.0, 102: -20.0}
    assert weekend_close_plan(first, params) == weekend_close_plan(second, params)
    assert weekend_close_plan({}, params) == ()


@pytest.mark.parametrize(
    "params",
    [
        WeekendParams(close_minutes_before_session_end=19),
        WeekendParams(close_minutes_before_session_end=61),
        WeekendParams(max_deviation_points=0),
        WeekendParams(close_order="random"),  # type: ignore[arg-type]
        WeekendParams(fallback_grace_minutes=-1),
    ],
)
def test_invalid_parameters_raise(params: WeekendParams) -> None:
    with pytest.raises(ValueError):
        weekend_close_plan({1: 0.0}, params)


def test_invalid_close_order_key_raises() -> None:
    with pytest.raises(ValueError):
        close_order_key(0.0, 1, WeekendParams(close_order="random"))  # type: ignore[arg-type]


def test_override_needs_config_and_operator() -> None:
    assert weekend_override_allowed(WeekendParams(), True) is False
    assert weekend_override_allowed(WeekendParams(override=True), False) is False
    assert weekend_override_allowed(WeekendParams(override=True), True) is True


def test_fallback_deadline_includes_the_grace_period() -> None:
    params = WeekendParams(fallback_grace_minutes=10)
    plan = in_weekend_close_window(at(FRIDAY, 23, 45), SESSIONS, params)
    assert plan.flatten is True
    assert fallback_close_deadline(plan, params) == at(SATURDAY, 0, 9)
    clear = in_weekend_close_window(at(FRIDAY, 12), SESSIONS, params)
    assert fallback_close_deadline(clear, params) is None


def test_empty_session_table_is_rejected() -> None:
    with pytest.raises(ValueError):
        session_end_broker(at(FRIDAY, 10), ())
    with pytest.raises(ValueError):
        in_weekend_close_window(at(FRIDAY, 10), (), WeekendParams())


def test_default_params_match_the_config_table() -> None:
    params = WeekendParams()
    assert params.enabled is True
    assert params.close_minutes_before_session_end == 30
    assert params.max_deviation_points == 200
    assert params.close_order == "profit_first"
    assert params.fallback_grace_minutes == 10
    assert params.override is False


def test_weekend_close_plan_is_engine_ready_ordered_list() -> None:
    positions = {30: 12.5, 10: -8.0, 20: 0.0, 40: -8.0, 50: 3.25}
    profit_first = WeekendParams(close_order="profit_first")
    loss_first = WeekendParams(close_order="loss_first")
    ticket_order = WeekendParams(close_order="ticket")
    expected_profit = (30, 50, 20, 10, 40)
    assert weekend_close_plan(positions, profit_first) == expected_profit
    reversed_positions = dict(reversed(list(positions.items())))
    assert weekend_close_plan(reversed_positions, profit_first) == expected_profit
    assert weekend_close_plan(positions, loss_first) == (10, 40, 20, 50, 30)
    assert weekend_close_plan(positions, ticket_order) == (10, 20, 30, 40, 50)
    plan = weekend_close_plan(positions, profit_first)
    assert isinstance(plan, tuple)
    assert all(isinstance(ticket, int) for ticket in plan)
