"""Deterministic failure injection for the execution/venue boundary.

Offline only: a fake MetaTrader5 module (injected terminal) and FakeBroker.
Scenarios: send None; requote/price-changed; partial fills; margin/invalid
volume; venue disconnect mid-close; duplicate close delivery; terminal rejects
(10036/10012); crash between order_send and the journal/book append.
"""

from __future__ import annotations

import time
from dataclasses import replace
from datetime import timedelta
from types import SimpleNamespace

import pytest

from goldbot.app.order_coordinator import OrderCoordinator
from goldbot.app.position_manager import PositionManager
from goldbot.app.reconciler import Reconciler
from goldbot.domain.errors import SubmitUncertain
from goldbot.domain.events import Ev, Event
from goldbot.domain.execution import ExitIntent
from goldbot.domain.model import Symbol, Ticket

from helpers import NOW, make_info, make_tick
from test_mt5_broker import FakeMT5, _broker, _info, _order

SECRET = "failure-injection-secret"
SYMBOL = Symbol("XAUUSD")
OWNED_MAGIC = 13_000_123  # inside ids.owns_position_magic's range


def _order_with_magic(*, volume: float = 0.02, magic: int = OWNED_MAGIC):
    return replace(_order(volume=volume), magic=magic)


def _sealed(*, volume: float = 0.02):
    return _order_with_magic(volume=volume).seal(SECRET)


def _types(journal) -> list[str]:
    return [event.type for event in journal.read_events(limit=10_000)]


def _exit(ticket: int, intent_id: str = "close-1", reason: str = "kill") -> ExitIntent:
    return ExitIntent(
        intent_id=intent_id,
        slot="zones_m15",
        ticket=int(ticket),
        symbol=SYMBOL,
        reason=reason,
    )


class FaultyMT5(FakeMT5):
    """Fake terminal with deterministic transport/venue fault switches."""

    def __init__(self) -> None:
        super().__init__()
        self.none_on: set[str] = set()
        self.next_retcodes: list[int] = []
        self.raise_before_close = False
        self.raise_after_close = False
        self.partial_open_volume: float | None = None
        self.partial_close_volume: float | None = None
        self.open_sends = 0
        self.close_sends = 0

    def _kind(self, request: dict) -> str:
        if "position" in request:
            return "close"
        if int(request.get("action", 1)) == 6:  # TRADE_ACTION_SLTP
            return "modify"
        return "open"

    def _row(self, request: dict, *, volume: float) -> SimpleNamespace:
        row = SimpleNamespace(
            ticket=self.next_ticket, symbol=request["symbol"], type=int(request["type"]),
            volume=float(volume), price_open=float(self.fill_price),
            sl=float(request.get("sl", 0.0)), tp=float(request.get("tp", 0.0)),
            magic=int(request.get("magic", 0)), comment=str(request.get("comment", "")),
            time=int(time.time()), profit=0.0, swap=0.0,
        )
        self.next_ticket += 1
        self.positions_list.append(row)
        return row

    def order_send(self, request):
        kind = self._kind(request)
        if kind == "open":
            self.open_sends += 1
        elif kind == "close":
            self.close_sends += 1
        if kind in self.none_on:
            return None
        if kind == "close" and self.raise_before_close:
            raise RuntimeError("venue disconnected before the close was sent")
        if kind == "close" and self.raise_after_close:
            super().order_send(request)  # the venue executes...
            raise RuntimeError("connection lost after the close reached the venue")
        if self.next_retcodes:
            code = self.next_retcodes.pop(0)
            return SimpleNamespace(retcode=code, comment="injected", price=0.0, volume=0.0, order=0, deal=0)
        if kind == "open" and self.partial_open_volume is not None:
            row = self._row(request, volume=self.partial_open_volume)
            self._add_deal(
                position=row.ticket, ticket=self.next_deal, volume=row.volume,
                price=row.price_open, profit=0.0, commission=-0.35, comment="partial fill",
            )
            self.next_deal += 1
            return SimpleNamespace(
                retcode=10010, comment="done partial", price=row.price_open,
                volume=row.volume, order=row.ticket, deal=self.next_deal - 1,
            )
        if kind == "close" and self.partial_close_volume is not None:
            ticket = int(request["position"])
            row = next(p for p in self.positions_list if p.ticket == ticket)
            qty = min(float(self.partial_close_volume), float(row.volume))
            row.volume = round(float(row.volume) - qty, 8)
            if row.volume <= 1e-9:
                self.positions_list.remove(row)
            price = float(self.tick.bid if int(request["type"]) == 1 else self.tick.ask)
            self._add_deal(
                position=ticket, ticket=self.next_deal, volume=-qty, price=price,
                profit=1.0, commission=-0.2, comment=str(request.get("comment", "close")),
            )
            self.next_deal += 1
            return SimpleNamespace(
                retcode=10010, comment="done partial", price=price, volume=qty,
                order=ticket, deal=self.next_deal - 1,
            )
        return super().order_send(request)


def _mt5_env(journal, clock, fake=None):
    fake = fake or FaultyMT5()
    broker, _ = _broker(fake, settlement_poll_s=0.0)
    broker.connect()
    positions = PositionManager(mode="hedging", contract_size=_info().contract_size)
    coordinator = OrderCoordinator(
        broker=broker, journal=journal, clock=clock, positions=positions,
        secret=SECRET, run_id="fi",
    )
    return broker, positions, coordinator, fake


def _open(coordinator, positions, *, volume=0.02):
    result = coordinator.execute(_sealed(volume=volume))
    assert result.status == "acked", result
    assert result.ack is not None and result.ack.ticket is not None
    return int(result.ack.ticket)


# -- 1. order_send returns None --------------------------------------------
def test_send_none_is_uncertain_never_a_reject_and_never_resent(journal, clock):
    broker, positions, coordinator, fake = _mt5_env(journal, clock)
    fake.none_on.add("open")
    order = _sealed(volume=0.02)
    result = coordinator.execute(order)

    assert result.status == "uncertain"
    assert fake.open_sends == 1
    assert positions.count() == 0 and len(broker.positions()) == 0
    types = _types(journal)
    assert "OrderUncertain" in types
    assert "OrderRejected" not in types and "OrderAcked" not in types
    assert order.intent_id in coordinator.uncertain
    assert order.intent_id in coordinator.in_flight()

    assert coordinator.resolve_uncertain(since=NOW - timedelta(minutes=5)) == []
    assert fake.open_sends == 1
    assert "OrderResolvedAbsent" in _types(journal)


# -- 2. requote / price changed --------------------------------------------
@pytest.mark.parametrize(
    ("retcode", "name", "action"),
    [(10004, "REQUOTE", "retry_price"), (10020, "PRICE_CHANGED", "retry_price")],
)
def test_transient_price_rejections_are_retryable_and_do_not_book(journal, clock, retcode, name, action):
    broker, positions, coordinator, fake = _mt5_env(journal, clock)
    fake.next_retcodes.append(retcode)
    result = coordinator.execute(_sealed(volume=0.02))

    assert result.status == "rejected"
    assert result.retryable is True
    assert result.action == action
    assert result.ack is not None and result.ack.retcode == retcode
    assert positions.count() == 0 and len(broker.positions()) == 0
    rejected = [e for e in journal.read_events(limit=10_000) if e.type == "OrderRejected"][-1]
    assert rejected.payload["retcode"] == retcode
    assert rejected.payload["retcode_name"] == name
    assert rejected.payload["action"] == action


# -- 3. partial fills -------------------------------------------------------
def test_partial_open_fill_books_the_deal_volume_only(journal, clock):
    broker, positions, coordinator, fake = _mt5_env(journal, clock)
    fake.partial_open_volume = 0.01
    result = coordinator.execute(_sealed(volume=0.02))

    assert result.status == "acked" and result.ack is not None
    assert float(result.ack.filled_volume) == pytest.approx(0.01)
    book, venue = positions.raw(), broker.positions()
    assert len(book) == 1 and len(venue) == 1
    assert book[0].ticket == int(venue[0].ticket)
    assert book[0].volume == pytest.approx(0.01) == float(venue[0].volume)


def test_partial_close_keeps_the_remainder_and_never_over_closes_on_retry(journal, clock):
    broker, positions, coordinator, fake = _mt5_env(journal, clock)
    ticket = _open(coordinator, positions, volume=0.02)
    fake.partial_close_volume = 0.01

    first = coordinator.close_position(_exit(ticket, "pc-1"))
    trade = first.ack.closed_trade if first.ack is not None else None
    assert first.status == "acked" and trade is not None
    assert float(trade.volume) == pytest.approx(0.01)
    positions.apply_close(trade)
    assert positions.get(ticket).volume == pytest.approx(0.01)
    assert fake.close_sends == 1

    duplicate = coordinator.close_position(_exit(ticket, "pc-1"))
    assert duplicate.ack is not None and duplicate.ack.closed_trade is trade
    assert fake.close_sends == 1  # duplicate delivery never sends

    fake.partial_close_volume = None
    second = coordinator.close_position(_exit(ticket, "pc-2"))
    rest = second.ack.closed_trade if second.ack is not None else None
    assert second.status == "acked" and rest is not None
    positions.apply_close(rest)
    assert positions.count() == 0 and len(broker.positions()) == 0
    assert fake.close_sends == 2
    assert float(trade.volume) + float(rest.volume) == pytest.approx(0.02)


# -- 4. insufficient margin / invalid volume -------------------------------
def test_insufficient_margin_and_invalid_volume_abort_without_booking(journal, clock):
    broker, positions, coordinator, fake = _mt5_env(journal, clock)
    fake.next_retcodes.append(10019)
    result = coordinator.execute(_sealed(volume=0.02))
    assert result.status == "rejected" and result.retryable is False
    assert result.action == "abort"
    assert result.ack is not None and result.ack.retcode == 10019
    assert positions.count() == 0 and fake.open_sends == 1
    assert "OrderUncertain" not in _types(journal)

    # Invalid volume (below min_volume) is rejected before any send at all.
    broker2, positions2, coordinator2, fake2 = _mt5_env(journal, clock)
    bad = coordinator2.execute(_sealed(volume=0.001))
    assert bad.status == "rejected" and bad.action == "abort"
    assert bad.ack is not None and bad.ack.retcode == 10014
    assert fake2.open_sends == 0
    assert positions2.count() == 0 and len(broker2.positions()) == 0


# -- 5. venue disconnect mid-close -----------------------------------------
def test_disconnect_after_execution_recovers_from_venue_truth_without_a_second_send(journal, clock):
    broker, positions, coordinator, fake = _mt5_env(journal, clock)
    ticket = _open(coordinator, positions)
    fake.raise_after_close = True

    first = coordinator.close_position(_exit(ticket, "dc-1"))
    assert first.status == "uncertain" and first.action == "quarantine"
    assert positions.count() == 1  # no phantom flat
    assert "OrderUncertain" in _types(journal)
    assert fake.close_sends == 1

    fake.raise_after_close = False
    retry = coordinator.close_position(_exit(ticket, "dc-1"))
    trade = retry.ack.closed_trade if retry.ack is not None else None
    assert retry.status == "acked" and trade is not None
    assert float(trade.volume) == pytest.approx(0.02)
    assert fake.close_sends == 1  # venue truth settled it, nothing re-sent
    positions.apply_close(trade)
    assert positions.count() == 0 and len(broker.positions()) == 0


def test_disconnect_before_execution_is_uncertain_then_recovers_with_a_fresh_intent(journal, clock):
    broker, positions, coordinator, fake = _mt5_env(journal, clock)
    ticket = _open(coordinator, positions)
    fake.raise_before_close = True

    first = coordinator.close_position(_exit(ticket, "dc-before"))
    assert first.status == "uncertain"
    assert positions.count() == 1 and len(broker.positions()) == 1
    fake.raise_before_close = False

    recovered = coordinator.close_position(_exit(ticket, "dc-before-2"))
    assert recovered.status == "acked" and recovered.ack is not None
    assert recovered.ack.closed_trade is not None
    positions.apply_close(recovered.ack.closed_trade)
    assert positions.count() == 0 and len(broker.positions()) == 0


# -- 6. duplicate delivery of one close intent -----------------------------
def test_duplicate_close_delivery_sends_exactly_one_order(journal, clock):
    broker, positions, coordinator, fake = _mt5_env(journal, clock)
    ticket = _open(coordinator, positions)
    first = coordinator.close_position(_exit(ticket, "dup-1"))
    second = coordinator.close_position(_exit(ticket, "dup-1"))

    assert first.status == "acked" and second.status == "acked"
    assert first.ack is not None and second.ack is not None
    assert second.ack.closed_trade is first.ack.closed_trade
    assert fake.close_sends == 1
    assert len(broker.positions()) == 0


# -- 7. terminal rejects: settle or quarantine, never loop -----------------
def test_position_closed_at_the_venue_settles_from_history_without_a_send(journal, clock):
    broker, positions, coordinator, fake = _mt5_env(journal, clock)
    ticket = _open(coordinator, positions)
    venue = broker.positions()[0]
    fake.positions_list.clear()
    fake._add_deal(
        position=ticket, ticket=991, volume=-float(venue.volume),
        price=3880.0, profit=1.5, commission=-0.2, comment="tp",
    )

    result = coordinator.close_position(_exit(ticket, "gone-1"))
    trade = result.ack.closed_trade if result.ack is not None else None
    assert result.status == "acked" and trade is not None
    assert float(trade.volume) == pytest.approx(0.02)
    assert fake.close_sends == 0  # venue truth replaced the send
    positions.apply_close(trade)
    assert positions.count() == 0 and len(broker.positions()) == 0

    replay = coordinator.close_position(_exit(ticket, "gone-1"))
    # Known gap (reported): the cached ack of an already-closed attempt is not
    # stamped, so the replay is quarantined instead of returning that ack; it
    # still never sends and never loops.
    assert replay.status in ("acked", "uncertain")
    assert fake.close_sends == 0


def test_timeout_on_close_quarantines_and_does_not_loop(journal, clock):
    broker, positions, coordinator, fake = _mt5_env(journal, clock)
    ticket = _open(coordinator, positions)
    fake.next_retcodes.append(10012)

    first = coordinator.close_position(_exit(ticket, "to-1"))
    assert first.status == "uncertain" and first.action == "quarantine"
    assert positions.count() == 1 and len(broker.positions()) == 1
    assert "OrderUncertain" in _types(journal)
    assert fake.close_sends == 1

    retry = coordinator.close_position(_exit(ticket, "to-1"))
    assert retry.status == "uncertain"
    assert fake.close_sends == 1  # an uncertain attempt is never blindly resent


# -- 8. crash between the venue send and the journal/book append -----------
def test_crashed_open_is_adopted_once_and_never_reopened(journal, clock):
    info = make_info()
    fake = FaultyMT5()
    broker, _ = _broker(fake)
    broker.connect()
    order = _order_with_magic(volume=0.02)
    payload = {
        "intent_id": order.intent_id, "idempotency_key": f"fi:{order.intent_id}",
        "client_ref": order.client_ref, "volume": order.volume,
        "side": order.side, "sl": order.sl, "tp": order.tp,
    }
    journal.append(
        Event(type=Ev.ORDER_SUBMITTED, payload=payload, ts=clock.now(),
              correlation_id=order.intent_id, actor="executor"),
        fsync=True,
    )
    ack = broker.submit(order, idempotency_key=f"fi:{order.intent_id}")
    assert ack.accepted and ack.ticket is not None
    ticket = int(ack.ticket)

    # Crash: only the venue and the write-ahead journal survive.
    restarted = PositionManager(mode="hedging", contract_size=info.contract_size)
    reconciler = Reconciler(positions=restarted, broker=broker, journal=journal, clock=clock)
    report = reconciler.run()
    assert not report.clean and ticket in report.orphan
    assert len(reconciler.adopt_orphans(max_holding_hours=24.0)) == 1
    assert restarted.count() == 1
    assert _types(journal).count("PositionAdopted") == 1
    assert reconciler.run().clean
    assert reconciler.adopt_orphans(max_holding_hours=24.0) == ()  # idempotent
    assert fake.open_sends == 1  # never reopened

    coordinator = OrderCoordinator(
        broker=broker, journal=journal, clock=clock, positions=restarted,
        secret=SECRET, run_id="fi-restart",
    )
    closed = coordinator.close_position(_exit(ticket, "recovery-close"))
    assert closed.status == "acked" and closed.ack is not None
    assert closed.ack.closed_trade is not None
    restarted.apply_close(closed.ack.closed_trade)
    assert restarted.count() == 0 and len(broker.positions()) == 0
    replay = coordinator.close_position(_exit(ticket, "recovery-close"))
    assert replay.ack is not None and fake.close_sends == 1  # closed once


def test_crashed_close_is_reconciled_fail_closed_and_never_closed_twice(journal, clock):
    broker, positions, coordinator, fake = _mt5_env(journal, clock)
    ticket = _open(coordinator, positions)
    # The engine sent the close and the venue executed it, then the process died
    # before the closed trade was booked.
    executed = broker.close(Ticket(ticket), volume=None, idempotency_key="fi:crashed-close", reason="kill")
    assert executed.accepted and fake.close_sends == 1

    broker2, _ = _broker(fake)  # restart: in-memory ledgers are gone
    broker2.connect()
    reconciler = Reconciler(positions=positions, broker=broker2, journal=journal, clock=clock)
    report = reconciler.run()
    assert not report.clean and ticket in report.missing  # fail closed, never auto-closed
    assert "DivergenceDetected" in _types(journal)

    with pytest.raises(SubmitUncertain):
        broker2.close(Ticket(ticket), volume=None, idempotency_key="fi:crashed-close", reason="kill")
    assert fake.close_sends == 1  # the venue was never closed a second time


# -- FakeBroker parity (no MT5 terminal at all) ----------------------------
def test_fake_broker_offline_send_is_uncertain_and_never_retried(broker, positions, journal, clock):
    broker.set_offline(True)
    coordinator = OrderCoordinator(
        broker=broker, journal=journal, clock=clock, positions=positions,
        secret=SECRET, run_id="fi-fake",
    )
    order = _order_with_magic(volume=0.02).seal(SECRET)
    assert coordinator.execute(order).status == "uncertain"
    assert positions.count() == 0 and len(broker.positions()) == 0
    assert "OrderUncertain" in _types(journal)

    broker.set_offline(False)
    assert coordinator.resolve_uncertain(since=NOW - timedelta(minutes=5)) == []
    assert len(broker.positions()) == 0


# -- Known product gap (reported to the Lead, not fixed here) --------------
@pytest.mark.xfail(
    strict=False,
    reason=(
        "mt5_broker.py:901-903 does not stamp an already-closed close attempt, so "
        "_prune_close_attempts (987-993) drops its cached ack and a replay reports "
        "uncertain instead of the settled ack (no double send either way)"
    ),
)
def test_already_closed_duplicate_delivery_returns_the_cached_ack(journal, clock):
    broker, positions, coordinator, fake = _mt5_env(journal, clock)
    ticket = _open(coordinator, positions)
    fake.positions_list.clear()
    fake._add_deal(
        position=ticket, ticket=992, volume=-0.02, price=3880.0,
        profit=1.0, commission=-0.2, comment="tp",
    )
    first = coordinator.close_position(_exit(ticket, "gone-cached"))
    replay = coordinator.close_position(_exit(ticket, "gone-cached"))
    assert first.ack is not None and replay.status == "acked"
    assert replay.ack.closed_trade is first.ack.closed_trade


def test_duplicate_submit_delivery_is_not_sent_twice(journal, clock):
    fake = FaultyMT5()
    broker, _ = _broker(fake)
    broker.connect()
    order = _order_with_magic(volume=0.01)
    first = broker.submit(order, idempotency_key="same-open-key")
    second = broker.submit(order, idempotency_key="same-open-key")
    assert first.accepted and second.accepted
    assert len(broker.positions()) == 1
