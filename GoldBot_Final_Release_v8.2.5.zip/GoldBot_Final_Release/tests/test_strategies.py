"""Zones strategy + zone detection/scoring tests."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone

from goldbot.strategy_api import Bar, Zone, detect_zones, score_manual_zones
from strategies.zones import ZonesParams, ZonesStrategy

from helpers import FakeCtx

START = datetime(2024, 3, 4, tzinfo=timezone.utc)


def bar(i: int, o: float, h: float, l: float, c: float, tf: str = "M15") -> Bar:
    return Bar(
        symbol="XAUUSD",  # type: ignore[arg-type]
        timeframe=tf,  # type: ignore[arg-type]
        open_time=START + timedelta(minutes=15 * i),
        o=o,
        h=h,
        l=l,
        c=c,
    )


def h1(i: int, o: float, h: float, l: float, c: float) -> Bar:
    return Bar(
        symbol="XAUUSD",  # type: ignore[arg-type]
        timeframe="H1",  # type: ignore[arg-type]
        open_time=START + timedelta(hours=i),
        o=o,
        h=h,
        l=l,
        c=c,
    )


def test_detect_zones_clusters_repeated_swings() -> None:
    bars = []
    for i in range(40):
        if i % 4 == 0:
            bars.append(h1(i, 2004.0, 2005.0, 2003.0, 2004.0))
        else:
            bars.append(h1(i, 1999.0, 2000.0, 1998.0, 1999.0))
    zones = detect_zones(bars, atr=1.0, span=3, cluster_atr=0.3, min_touches=2)
    assert zones, "repeated swing highs must produce a resistance zone"
    resistance = max(zones, key=lambda zone: zone.high)
    assert resistance.high > 2004.0
    assert resistance.touches >= 2
    assert resistance.score > 0
    assert resistance.zone_id.startswith("Z")
    # ids are stable: same inputs, same id
    again = detect_zones(bars, atr=1.0, span=3, cluster_atr=0.3, min_touches=2)
    assert [z.zone_id for z in zones] == [z.zone_id for z in again]


def test_manual_zone_scoring_prefers_starred() -> None:
    plain = Zone(high=2001.0, low=1999.0)
    starred = Zone(high=2001.0, low=1999.0, starred=True)
    scored = score_manual_zones((plain, starred), atr=3.0)
    assert scored[1].score > scored[0].score
    assert scored[1].zone_id.startswith("M")


SUPPORT = Zone(high=1990.2, low=1988.0, starred=True, note="daily support", score=85)


def decline_bars(tail_low: float = 1987.8, tail_close: float = 1992.2) -> list[Bar]:
    bars: list[Bar] = []
    price = 2020.0
    for i in range(139):
        price -= 0.2
        bars.append(bar(i, price + 0.3, price + 1.5, price - 1.5, price))
    bars.append(bar(139, 1991.6, 1992.8, tail_low, tail_close))
    return bars


def test_zones_rejection_emits_long_with_scores() -> None:
    bars = decline_bars()
    strategy = ZonesStrategy(params=ZonesParams(max_zone_distance_atr=3.0))
    ctx = FakeCtx(_bars=bars, _zones=(SUPPORT,))

    signals = strategy.on_bar(ctx, bars[-1])
    assert signals, "a rejection candle at support must produce a long"
    signal = signals[0]
    assert signal.kind == "entry"
    assert signal.side == "buy"
    assert signal.tags["zone_id"] == SUPPORT.zone_id
    assert signal.tags["zone_score"] >= 70
    assert signal.tags["signal_score"] >= 0.3
    assert signal.tags["setup_type"] in ("rejection", "sweep")
    assert signal.stop < SUPPORT.low
    assert signal.target > signal.entry_hint
    risk = signal.entry_hint - signal.stop
    reward = signal.target - signal.entry_hint
    assert reward >= 1.9 * risk


def test_zones_sweep_is_detected_and_scored() -> None:
    sweep_bars = decline_bars(tail_low=1986.5, tail_close=1991.0)
    sweep = ZonesStrategy(params=ZonesParams(max_zone_distance_atr=3.0)).on_bar(
        FakeCtx(_bars=sweep_bars, _zones=(SUPPORT,)), sweep_bars[-1]
    )[0]
    assert sweep.tags["setup_type"] == "sweep"
    assert sweep.tags["signal_score"] >= 0.3


def test_zones_reaction_weight_is_25_percent() -> None:
    import pytest

    strategy = ZonesStrategy(params=ZonesParams())
    trigger = bar(0, 1991.6, 1992.8, 1987.8, 1992.2)
    fixed = dict(
        side="buy",
        bar=trigger,
        zone=SUPPORT,
        atr=3.2,
        ema=2000.0,
        ema_prev=2001.0,
        adx_h1=20.0,
        rsi_m15=None,
        relative_volume=None,
        candle="",
    )
    sweep = strategy._signal_score(reaction=1.0, **fixed)
    rejection = strategy._signal_score(reaction=0.65, **fixed)
    # weight 25 / 50 == 0.5 per unit of f1; 0.35 of f1 -> 0.175
    assert sweep - rejection == pytest.approx(0.175)


def test_dynamic_invalidation_scales_with_atr() -> None:
    from strategies.zones import ZonesParams, ZonesStrategy

    strategy = ZonesStrategy(params=ZonesParams(invalidate_mode="dynamic", atr_period=14))
    flat = [bar(i, 2000.0, 2000.6, 1999.4, 2000.0) for i in range(80)]
    volatile = [bar(i, 2000.0, 2000.6, 1999.4, 2000.0) for i in range(70)] + [
        bar(i, 2000.0, 2008.0, 1992.0, 2000.0) for i in range(70, 80)
    ]
    calm_multiplier = strategy._invalidation_multiplier(flat, strategy.params)
    wild_multiplier = strategy._invalidation_multiplier(volatile, strategy.params)
    assert 0.8 <= calm_multiplier < wild_multiplier <= 1.5


def test_fixed_invalidation_ignores_atr() -> None:
    from strategies.zones import ZonesParams, ZonesStrategy

    strategy = ZonesStrategy(params=ZonesParams(invalidate_atr=1.2))
    bars = [bar(i, 2000.0, 2006.0, 1994.0, 2000.0) for i in range(80)]
    assert strategy._invalidation_multiplier(bars, strategy.params) == 1.2


def test_zones_needs_history() -> None:
    bars = [bar(i, 2000.0, 2001.0, 1999.0, 2000.0) for i in range(10)]
    strategy = ZonesStrategy(params=ZonesParams())
    ctx = FakeCtx(_bars=bars, _zones=(SUPPORT,))
    assert strategy.on_bar(ctx, bars[-1]) == ()


def test_liquidity_reward_picks_the_nearest_pool_for_sells() -> None:
    far = Zone(high=1952.0, low=1950.0, score=80, zone_id="Z195000")
    near = Zone(high=1992.0, low=1990.0, score=80, zone_id="Z199000")
    reward = ZonesStrategy._liquidity_reward("sell", 2000.0, (far, near), 3.0, 5.0, ZonesParams())
    assert reward == 10.0


def test_zones_without_zones_never_trades() -> None:
    bars = [bar(i, 2000.0, 2002.0, 1998.0, 2000.0) for i in range(140)]
    strategy = ZonesStrategy(params=ZonesParams())
    ctx = FakeCtx(_bars=bars, _zones=())
    assert strategy.on_bar(ctx, bars[-1]) == ()


def test_zones_bad_params_are_rejected() -> None:
    import pytest
    from pydantic import ValidationError

    with pytest.raises(ValidationError):
        ZonesParams(sl_atr=99.0)
