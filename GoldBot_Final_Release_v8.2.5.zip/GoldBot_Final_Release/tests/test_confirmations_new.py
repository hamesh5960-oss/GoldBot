"""Five confirmation scorers and layer-3 votes: only exact half steps."""

from __future__ import annotations

from dataclasses import replace
from datetime import datetime, timedelta, timezone

import pytest

from goldbot.app.confirmations import (
    FACTOR_NAMES,
    LAYER3_CAP,
    LAYER3_WEIGHT,
    ConfirmationReport,
    Layer3Report,
    ema200_h1_vote,
    evaluate_confirmations,
    layer3_score,
    score_bollinger,
    score_ema50,
    score_fvg_ob,
    score_maxlines,
    score_rsi,
    zone_confirms_layer3,
)
from goldbot.domain.model import Bar
from goldbot.strategy_api.zones import Zone

START = datetime(2024, 3, 4, tzinfo=timezone.utc)
HALF_STEPS = (0.0, 0.5, 1.0)


def bar(i: int, o: float, h: float, l: float, c: float, volume: int = 10) -> Bar:
    return Bar(
        symbol="XAUUSD",  # type: ignore[arg-type]
        timeframe="M15",  # type: ignore[arg-type]
        open_time=START + timedelta(minutes=15 * i),
        o=o,
        h=h,
        l=l,
        c=c,
        tick_volume=volume,
    )


def bars_from_closes(closes: list[float], wick: float = 0.15) -> list[Bar]:
    out: list[Bar] = []
    previous = closes[0]
    for index, close in enumerate(closes):
        open_price = previous if index else close
        out.append(
            bar(
                index,
                open_price,
                max(open_price, close) + wick,
                min(open_price, close) - wick,
                close,
            )
        )
        previous = close
    return out


def zone(low: float, high: float) -> Zone:
    return Zone(low=low, high=high)


# -- score_fvg_ob --------------------------------------------------------
def _bullish_fvg_bars() -> list[Bar]:
    return [
        bar(0, 98.0, 99.0, 97.0, 98.5),
        bar(1, 98.5, 100.0, 98.0, 99.0),  # high is the top of the gap
        bar(2, 99.0, 101.5, 99.5, 101.0),
        bar(3, 101.0, 103.0, 102.0, 102.5),  # low is the bottom of the gap
    ]


def test_fvg_overlapping_a_zone_scores_one() -> None:
    score = score_fvg_ob(
        _bullish_fvg_bars(), side="buy", zone=zone(100.4, 101.6), entry=101.0, atr=2.0
    )
    assert score == 1.0


def test_fvg_without_a_zone_uses_the_entry_price() -> None:
    assert (
        score_fvg_ob(_bullish_fvg_bars(), side="buy", zone=None, entry=101.0, atr=2.0)
        == 1.0
    )


def test_fvg_near_the_zone_scores_half() -> None:
    # Gap is 100..102; zone starts 0.2 above it and half an ATR is 1.0.
    assert (
        score_fvg_ob(_bullish_fvg_bars(), side="buy", zone=zone(102.2, 103.0), entry=102.2, atr=2.0)
        == 0.5
    )


def test_fvg_far_from_the_zone_scores_zero() -> None:
    assert (
        score_fvg_ob(_bullish_fvg_bars(), side="buy", zone=zone(110.0, 111.0), entry=110.0, atr=2.0)
        == 0.0
    )


def test_undersized_gap_overlapping_the_zone_is_only_half() -> None:
    bars = [
        bar(0, 98.0, 99.0, 97.0, 98.5),
        bar(1, 98.5, 100.0, 98.0, 99.0),
        bar(2, 99.0, 100.5, 99.0, 100.0),
        bar(3, 100.0, 101.0, 100.4, 100.8),  # gap 100.0..100.4 is 0.4 < 1.0
    ]
    assert score_fvg_ob(bars, side="buy", zone=zone(100.1, 100.3), entry=100.2, atr=2.0) == 0.5


def test_bearish_fvg_counts_for_a_sell() -> None:
    bars = [
        bar(0, 102.0, 103.0, 101.0, 102.5),
        bar(1, 102.5, 103.0, 102.0, 102.2),  # low 102.0 is the top of the gap
        bar(2, 102.2, 102.5, 100.5, 101.0),
        bar(3, 100.4, 100.4, 99.8, 100.0),  # high 100.4 is the bottom of the gap
    ]
    # Bearish gap 100.4..102.0; the entry sits inside it.
    assert score_fvg_ob(bars, side="sell", zone=None, entry=101.2, atr=1.0) == 1.0


def test_order_block_impulse_counts_for_a_buy() -> None:
    bars = [
        bar(0, 100.0, 101.0, 99.5, 100.0),
        bar(1, 105.0, 105.5, 102.5, 103.0),  # bearish opposite candle
        bar(2, 103.0, 106.5, 102.8, 106.0),  # impulse closes above 105.5
    ]
    assert score_fvg_ob(bars, side="buy", zone=zone(103.0, 105.0), entry=104.0, atr=1.0) == 1.0


@pytest.mark.parametrize("bad_bars", [[], [object()], None])
def test_fvg_scorer_never_raises_on_malformed_input(bad_bars: object) -> None:
    assert score_fvg_ob(bad_bars, side="buy", zone=None, entry=1.0, atr=1.0) == 0.0


def test_fvg_scorer_rejects_bad_atr() -> None:
    assert score_fvg_ob(_bullish_fvg_bars(), side="buy", zone=None, entry=101.0, atr=0.0) == 0.0
    assert score_fvg_ob(_bullish_fvg_bars(), side="buy", zone=None, entry=101.0, atr=None) == 0.0  # type: ignore[arg-type]


# -- score_maxlines ------------------------------------------------------
def _range_bars(high: float = 110.0, low: float = 90.0, count: int = 64) -> list[Bar]:
    mid = (high + low) / 2.0
    return [bar(i, mid, high, low, mid) for i in range(count)]


def test_maxlines_buy_reversal_line_levels() -> None:
    bars = _range_bars()  # span 20 -> step 2.5 -> -2/8 line = 85
    assert score_maxlines(bars, side="buy", entry=84.0, atr=2.0) == 1.0
    assert score_maxlines(bars, side="buy", entry=85.0, atr=2.0) == 1.0
    assert score_maxlines(bars, side="buy", entry=85.4, atr=2.0) == 0.5
    assert score_maxlines(bars, side="buy", entry=85.6, atr=2.0) == 0.0


def test_maxlines_sell_reversal_line_levels() -> None:
    bars = _range_bars()  # +2/8 line = 115
    assert score_maxlines(bars, side="sell", entry=116.0, atr=2.0) == 1.0
    assert score_maxlines(bars, side="sell", entry=115.0, atr=2.0) == 1.0
    assert score_maxlines(bars, side="sell", entry=114.6, atr=2.0) == 0.5
    assert score_maxlines(bars, side="sell", entry=114.4, atr=2.0) == 0.0


def test_maxlines_needs_a_range_and_finite_atr() -> None:
    flat = [bar(i, 100.0, 100.0, 100.0, 100.0) for i in range(10)]
    assert score_maxlines(flat, side="buy", entry=100.0, atr=2.0) == 0.0
    assert score_maxlines([], side="buy", entry=85.0, atr=2.0) == 0.0
    # At/through is judged without ATR; the 0.5 band requires it.
    assert score_maxlines(_range_bars(), side="buy", entry=85.4, atr=None) == 0.0  # type: ignore[arg-type]


# -- score_ema50 ---------------------------------------------------------
def _trend_bars(start: float, step: float, count: int = 60) -> list[Bar]:
    return bars_from_closes([start + step * i for i in range(count)])


def test_ema50_aligned_slope_scores_one() -> None:
    assert score_ema50(_trend_bars(100.0, 0.2), side="buy", entry=112.5, atr=1.0) == 1.0
    assert score_ema50(_trend_bars(200.0, -0.2), side="sell", entry=187.5, atr=1.0) == 1.0


def test_ema50_flat_slope_scores_half() -> None:
    flat = bars_from_closes([100.0] * 60)
    assert score_ema50(flat, side="buy", entry=101.0, atr=1.0) == 0.5
    assert score_ema50(flat, side="sell", entry=99.0, atr=1.0) == 0.5


def test_ema50_on_or_against_the_average_scores_zero() -> None:
    up = _trend_bars(100.0, 0.2)
    assert score_ema50(up, side="buy", entry=50.0, atr=1.0) == 0.0
    down = _trend_bars(200.0, -0.2)
    assert score_ema50(down, side="sell", entry=300.0, atr=1.0) == 0.0


def test_ema50_needs_enough_history() -> None:
    assert score_ema50(_trend_bars(100.0, 0.2, count=40), side="buy", entry=200.0, atr=1.0) == 0.0
    assert score_ema50([], side="buy", entry=1.0, atr=1.0) == 0.0


# -- score_rsi -----------------------------------------------------------
@pytest.mark.parametrize(
    ("rsi", "prev", "side", "expected"),
    [
        (25.0, None, "buy", 1.0),
        (30.0, None, "buy", 1.0),
        (28.0, 24.0, "buy", 1.0),   # turning out of oversold
        (45.0, 40.0, "buy", 0.0),   # 45 is neither extreme nor above 50
        (55.0, 50.0, "buy", 0.5),
        (50.0, 48.0, "buy", 0.0),   # near 50
        (40.0, 45.0, "buy", 0.0),   # wrong direction
        (75.0, None, "sell", 1.0),
        (70.0, None, "sell", 1.0),
        (72.0, 78.0, "sell", 1.0),  # turning out of overbought
        (55.0, 60.0, "sell", 0.0),  # 55 is neither extreme nor below 50
        (45.0, 50.0, "sell", 0.5),
        (50.0, 52.0, "sell", 0.0),
        (60.0, 55.0, "sell", 0.0),
    ],
)
def test_rsi_scores(rsi: float, prev: float | None, side: str, expected: float) -> None:
    assert score_rsi(rsi, side=side, prev_rsi=prev) == expected


def _divergence_closes() -> list[float]:
    rise = [100.0 + i * 0.5 for i in range(20)]
    crash = [rise[-1] - i * 4.0 for i in range(1, 17)]
    low = crash[-1]
    rally = [low + i * (abs(low) * 0.01 + 0.5) for i in range(1, 7)]
    top = rally[-1]
    step = (top - (low - 0.5)) / 6
    slow = [top - i * step for i in range(1, 7)]
    return rise + crash + rally + slow + [slow[-1] + 1.0]


def test_rsi_bullish_divergence_uses_the_last_two_swing_lows() -> None:
    bars = bars_from_closes(_divergence_closes())
    # Lower price low with a higher RSI low is the only reason for the +1 here.
    assert score_rsi(55.0, side="buy", bars=bars) == 1.0
    assert score_rsi(55.0, side="buy") == 0.5


def test_rsi_bearish_divergence_uses_the_last_two_swing_highs() -> None:
    bars = bars_from_closes([200.0 - close for close in _divergence_closes()])
    assert score_rsi(45.0, side="sell", bars=bars) == 1.0
    assert score_rsi(45.0, side="sell") == 0.5


def test_rsi_without_divergence_falls_back_to_the_momentum_rules() -> None:
    assert score_rsi(55.0, side="buy", bars=_trend_bars(100.0, 0.2)) == 0.5
    assert score_rsi(45.0, side="sell", bars=_trend_bars(200.0, -0.2)) == 0.5


def test_rsi_none_scores_zero() -> None:
    assert score_rsi(None, side="buy") == 0.0
    assert score_rsi(None, side="sell", prev_rsi=20.0) == 0.0


# -- score_bollinger -----------------------------------------------------
def _bollinger_bars(touch_low: bool = False) -> list[Bar]:
    closes = [99.0, 101.0] * 10 + [98.0, 104.0]
    bars = bars_from_closes(closes)
    if touch_low:
        # A wick well below the current lower band counts as touching it.
        bars[20] = replace(bars[20], l=96.0)
    return bars


def test_bollinger_return_from_lower_band_scores_one() -> None:
    bars = _bollinger_bars(touch_low=True)
    assert score_bollinger(bars, side="buy", entry=104.0, atr=2.0) == 1.0


def test_bollinger_correct_half_scores_half() -> None:
    closes = [99.0, 101.0] * 11
    bars = bars_from_closes(closes)
    assert score_bollinger(bars, side="buy", entry=100.5, atr=2.0) == 0.5
    assert score_bollinger(bars, side="sell", entry=99.5, atr=2.0) == 0.5


def test_bollinger_mid_or_wrong_half_scores_zero() -> None:
    closes = [99.0, 101.0] * 11
    bars = bars_from_closes(closes)
    assert score_bollinger(bars, side="buy", entry=100.0, atr=2.0) == 0.0
    assert score_bollinger(bars, side="buy", entry=99.0, atr=2.0) == 0.0
    assert score_bollinger(bars, side="sell", entry=101.0, atr=2.0) == 0.0


def test_bollinger_sell_return_from_upper_band_scores_one() -> None:
    closes = [99.0, 101.0] * 10 + [102.0, 96.0]
    bars = bars_from_closes(closes)
    bars[20] = replace(bars[20], h=104.0)  # wick above the upper band
    assert score_bollinger(bars, side="sell", entry=97.0, atr=2.0) == 1.0


def test_bollinger_short_or_bad_input_scores_zero() -> None:
    assert score_bollinger(bars_from_closes([100.0] * 20), side="buy", entry=101.0, atr=1.0) == 0.0
    assert score_bollinger([], side="buy", entry=1.0, atr=1.0) == 0.0
    assert score_bollinger(
        bars_from_closes([99.0, 101.0] * 11), side="buy", entry=101.0, atr=0.0
    ) == 0.0


# -- layer 3 -------------------------------------------------------------
def test_layer3_positive_threshold_and_cap() -> None:
    report = layer3_score({"volume": 1, "pin_engulfing": 1, "ema200_h1": 1})
    assert isinstance(report, Layer3Report)
    assert report.score == pytest.approx(0.6)
    assert report.delta == 1
    assert report.votes == {"volume": 1, "pin_engulfing": 1, "ema200_h1": 1}

    capped = layer3_score({f"vote{i}": 1 for i in range(10)})
    assert capped.score == pytest.approx(LAYER3_CAP)
    assert capped.delta == 1


def test_layer3_negative_threshold_and_cap() -> None:
    report = layer3_score({"volume": -1, "adx": -1, "daily_level": -1})
    assert report.score == pytest.approx(-0.6)
    assert report.delta == -1
    capped = layer3_score({f"vote{i}": -1 for i in range(10)})
    assert capped.score == pytest.approx(-LAYER3_CAP)
    assert capped.delta == -1


@pytest.mark.parametrize(
    ("votes", "expected_score", "expected_delta"),
    [
        ({}, 0.0, 0),
        ({"volume": 1}, LAYER3_WEIGHT, 0),
        ({"volume": 1, "adx": 1}, 0.4, 0),
        ({"volume": 1, "adx": -1}, 0.0, 0),
        # A single vote is clamped to [-1, 1], so it can never reach the cap.
        ({"volume": 3}, LAYER3_WEIGHT, 0),
        ({"volume": -3}, -LAYER3_WEIGHT, 0),
        ({"volume": 5, "adx": -3, "session": 0}, 0.0, 0),
    ],
)
def test_layer3_delta_mapping(votes: dict[str, int], expected_score: float, expected_delta: int) -> None:
    report = layer3_score(votes)
    assert report.score == pytest.approx(expected_score)
    assert report.delta == expected_delta


def test_layer3_clamps_each_vote_and_returns_cleaned_votes() -> None:
    report = layer3_score({"volume": 9, "adx": -9, "session": 2})
    assert report.votes == {"volume": 1, "adx": -1, "session": 1}
    assert report.score == pytest.approx(0.2)
    assert report.delta == 0


def test_layer3_is_deterministic() -> None:
    votes = {"volume": 1, "adx": 1, "sr_zone": -1}
    assert layer3_score(votes) == layer3_score(dict(votes))
    assert votes == {"volume": 1, "adx": 1, "sr_zone": -1}, "inputs must not be mutated"


# -- evaluate_confirmations ---------------------------------------------
def test_report_sums_the_five_factors() -> None:
    report = evaluate_confirmations(
        _trend_bars(100.0, 0.2), side="buy", zone=None, entry=112.5, atr=1.0, rsi_m15=25.0
    )
    assert isinstance(report, ConfirmationReport)
    assert report.names == FACTOR_NAMES
    assert tuple(report.factors) == FACTOR_NAMES
    assert report.total == pytest.approx(sum(report.factors.values()))
    assert 0.0 <= report.total <= 5.0
    for value in report.factors.values():
        assert value in HALF_STEPS


def test_report_handles_empty_and_malformed_bars() -> None:
    for bars in ([], None, [object(), object()], [None]):
        report = evaluate_confirmations(
            bars, side="buy", zone=None, entry=100.0, atr=1.0, rsi_m15=None
        )
        assert report.total == 0.0
        assert all(value == 0.0 for value in report.factors.values())


def test_report_accepts_a_zone_and_optional_h1_bars() -> None:
    bars = _bullish_fvg_bars()
    baseline = evaluate_confirmations(
        bars, side="buy", zone=zone(100.4, 101.6), entry=101.0, atr=2.0, rsi_m15=55.0
    )
    with_h1 = evaluate_confirmations(
        bars,
        side="buy",
        zone=zone(100.4, 101.6),
        entry=101.0,
        atr=2.0,
        rsi_m15=55.0,
        bars_h1=_range_bars(),
    )
    assert with_h1 == baseline
    assert baseline.total == pytest.approx(sum(baseline.factors.values()))


def test_report_is_deterministic_and_does_not_mutate_inputs() -> None:
    bars = _trend_bars(100.0, 0.2)
    snapshot = list(bars)
    first = evaluate_confirmations(bars, side="buy", zone=None, entry=112.5, atr=1.0, rsi_m15=55.0)
    second = evaluate_confirmations(bars, side="buy", zone=None, entry=112.5, atr=1.0, rsi_m15=55.0)
    assert first == second
    assert bars == snapshot


def test_report_total_can_reach_both_ends() -> None:
    low = evaluate_confirmations([], side="buy", zone=None, entry=0.0, atr=0.0, rsi_m15=None)
    assert low.total >= 0.0
    high = evaluate_confirmations(
        _trend_bars(100.0, 0.2), side="buy", zone=None, entry=112.5, atr=1.0, rsi_m15=25.0
    )
    assert high.total <= 5.0


# -- ADR-035 / ADR-033 contract helpers (audit fixes CONF-03/CONF-05) ------


def test_zone_confirms_layer3_needs_score_and_distance() -> None:
    assert zone_confirms_layer3(zone_score=60.0, distance=1.0, atr=1.0) is True
    assert zone_confirms_layer3(zone_score=60.0, distance=2.0, atr=1.0) is True
    assert zone_confirms_layer3(zone_score=60.0, distance=2.5, atr=1.0) is False
    assert zone_confirms_layer3(zone_score=49.0, distance=0.0, atr=1.0) is False
    assert zone_confirms_layer3(zone_score=60.0, distance=0.0, atr=0.0) is False
    assert zone_confirms_layer3(zone_score=60.0, distance=float("inf"), atr=1.0) is False
    assert zone_confirms_layer3(zone_score=60.0, distance=-1.0, atr=1.0) is False
    assert zone_confirms_layer3(
        zone_score=55.0, distance=1.0, atr=1.0, min_score=55.0, max_distance_atr=1.5
    ) is True


def test_ema200_h1_vote_requires_full_history_and_slope() -> None:
    # 200 closes give exactly one EMA value, so the slope is undefined (neutral).
    base = [100.0 + index for index in range(200)]
    assert ema200_h1_vote(300.0, base[:-1], side="buy") == 0  # <200: no history
    assert ema200_h1_vote(300.0, base, side="buy") == 0  # no slope yet: neutral
    rising = [100.0 + index for index in range(210)]
    assert ema200_h1_vote(320.0, rising, side="buy") == 1
    assert ema200_h1_vote(320.0, rising, side="sell") == -1
    assert ema200_h1_vote(310.0, [200.0] * 210, side="buy") == 0
    assert ema200_h1_vote(320.0, rising, side="hold") == 0
    assert ema200_h1_vote(320.0, [], side="buy") == 0
