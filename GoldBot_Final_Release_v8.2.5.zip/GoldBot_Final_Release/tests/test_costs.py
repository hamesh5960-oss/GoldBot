"""Full cost model: commission, spread, slippage, swap (triple Wednesday).

Also covers the journal projection of those costs: the new nullable columns and
the in-place migration of journals created before the cost model existed.
"""

from __future__ import annotations

import json
import sqlite3
from pathlib import Path

import pytest

from goldbot.adapters.sqlite_store import SqliteJournal
from goldbot.app.costs import (
    DEFAULT_COSTS,
    CostBreakdown,
    CostParams,
    effective_loss_per_lot,
    estimated_round_trip,
    nights_charged,
    swap_for_nights,
)
from goldbot.domain.events import TradeRecord

# -- nights and swap -------------------------------------------------------


def test_nights_charged_plain_week() -> None:
    assert nights_charged(0, 0) == 0
    assert nights_charged(1, 0) == 1  # Monday -> Tuesday
    assert nights_charged(2, 0) == 2  # Monday, Tuesday
    assert nights_charged(3, 0) == 5  # Monday, Tuesday, Wednesday (triple)


def test_triple_swap_charges_wednesday_three_times() -> None:
    # broker_day: Monday=0 ... Wednesday=2
    assert nights_charged(1, 2) == 3  # Wed -> Thu is the triple swap
    assert nights_charged(2, 2) == 4  # Wed (triple) + Thu
    assert nights_charged(2, 1) == 4  # Tue + Wed (triple)
    assert nights_charged(3, 1) == 5  # Tue + Wed (triple) + Thu
    # a custom triple-swap day is honoured
    assert nights_charged(1, 2, params=CostParams(triple_swap_weekday=3)) == 1


def test_triple_swap_day_is_wednesday_per_live_mt5_metadata() -> None:
    """CJ-06 evidence: ePlanet MT5 reports XAUUSD.st swap_rollover3days=3.

    MT5 ENUM_DAY_OF_WEEK is 0=Sunday..6=Saturday, so 3 is Wednesday; this module
    uses broker weekdays Monday=0, where Wednesday is 2.  ADR-040 records the
    same live symbol metadata ("triple Wednesday").  The exact charge instant
    within Wednesday (00:00 entering vs 00:00 leaving the day) stays UNRESOLVED
    until broker swap_actual history proves it; the behaviour below is therefore
    an explicit, tested assumption rather than a guess.
    """
    assert DEFAULT_COSTS.triple_swap_weekday == 2
    assert nights_charged(1, 2) == 3  # Wednesday hold -> triple
    assert nights_charged(1, 1) == 1  # Tuesday hold -> single


def test_weekend_has_no_rollover() -> None:
    # Friday -> Monday is one charged night, not three calendar nights.
    assert nights_charged(1, 4) == 1
    # Fri, Mon, Tue, Wed (triple), Thu
    assert nights_charged(5, 4) == 7
    with pytest.raises(ValueError):
        nights_charged(1, 5)  # Saturday cannot charge a rollover


def test_swap_for_nights_uses_side_rate() -> None:
    params = CostParams(swap_long_per_lot_night=10.0, swap_short_per_lot_night=-4.0)
    assert swap_for_nights("buy", 1, 0, params=params) == pytest.approx(10.0)
    assert swap_for_nights("sell", 1, 0, params=params) == pytest.approx(-4.0)  # credit
    assert swap_for_nights("buy", 1, 2, params=params) == pytest.approx(30.0)  # triple
    assert swap_for_nights("buy", 0, 2, params=params) == 0.0


def test_news_never_changes_the_swap_leg() -> None:
    params = CostParams(swap_long_per_lot_night=10.0)
    plain = swap_for_nights("buy", 1, 2, params=params)
    news = swap_for_nights("buy", 1, 2, is_news=True, params=params)
    assert plain == news == pytest.approx(30.0)
    normal = estimated_round_trip(1.0, nights=1, side="buy", broker_day=2, params=params)
    news_rt = estimated_round_trip(
        1.0, nights=1, is_news=True, side="buy", broker_day=2, params=params
    )
    assert news_rt.swap == pytest.approx(normal.swap)  # triple only applies to swap
    assert news_rt.slippage > normal.slippage  # news only applies to slippage


# -- round trip ------------------------------------------------------------


def test_estimated_round_trip_components() -> None:
    breakdown = estimated_round_trip(0.5, spread_points=20, nights=0, side="buy")
    assert breakdown.commission == pytest.approx(3.5)  # $7/lot round trip
    assert breakdown.spread == pytest.approx(10.0)  # 20 points x $1/point/lot
    assert breakdown.slippage == pytest.approx(1.0)  # 2 points
    assert breakdown.swap == 0.0
    assert breakdown.total == pytest.approx(14.5)
    assert breakdown.as_dict()["total"] == pytest.approx(14.5)


def test_estimated_round_trip_spread_default_and_news_slippage() -> None:
    params = CostParams(default_spread_points=25.0, news_slippage_points=20.0)
    neutral = estimated_round_trip(1.0, params=params)
    assert neutral.spread == pytest.approx(25.0)
    assert neutral.slippage == pytest.approx(2.0)
    assert estimated_round_trip(1.0, spread_points=0, params=params).spread == 0.0
    assert estimated_round_trip(1.0, is_news=True, params=params).slippage == pytest.approx(20.0)


def test_estimated_round_trip_uses_charged_nights_without_broker_day() -> None:
    params = CostParams(swap_long_per_lot_night=-10.0)
    # nights is an already charged-night count (e.g. 3 for a Wednesday hold).
    breakdown = estimated_round_trip(1.0, nights=3, side="buy", params=params)
    assert breakdown.swap == pytest.approx(-30.0)


def test_cost_breakdown_total_is_the_signed_sum() -> None:
    breakdown = CostBreakdown(commission=1.0, slippage=2.0, spread=3.0, swap=-1.0)
    assert breakdown.total == pytest.approx(5.0)


# -- effective loss --------------------------------------------------------


def test_effective_loss_adds_stop_distance_and_costs() -> None:
    params = CostParams()
    expected = 5.0 * 100.0 * 0.1 + 7.0 * 0.1 + 2.0 * 1.0 * 0.1 + 20.0 * 1.0 * 0.1
    assert effective_loss_per_lot(5.0, 0.1, spread_points=20, params=params) == pytest.approx(expected)
    # a short stop above entry is the same risk magnitude
    assert effective_loss_per_lot(-5.0, 0.1, spread_points=20, params=params) == pytest.approx(expected)


def test_effective_loss_treats_a_swap_credit_as_a_cost() -> None:
    params = CostParams(swap_long_per_lot_night=-6.0)
    breakdown = estimated_round_trip(1.0, nights=1, side="buy", broker_day=3, params=params)
    assert breakdown.swap == pytest.approx(-6.0)  # credit lowers the round trip
    assert breakdown.total == pytest.approx(7.0 + 2.0 - 6.0)
    loss = effective_loss_per_lot(10.0, 1.0, nights=1, side="buy", broker_day=3, params=params)
    assert loss == pytest.approx(10.0 * 100.0 + 7.0 + 2.0 + 6.0)  # abs(swap) is a cost


def test_effective_loss_is_higher_on_a_triple_swap_wednesday() -> None:
    params = CostParams(swap_long_per_lot_night=10.0)
    wednesday = effective_loss_per_lot(5.0, 1.0, nights=1, broker_day=2, side="buy", params=params)
    thursday = effective_loss_per_lot(5.0, 1.0, nights=1, broker_day=3, side="buy", params=params)
    assert wednesday - thursday == pytest.approx(20.0)  # two extra charged nights x $10


def test_invalid_inputs_are_rejected() -> None:
    with pytest.raises(ValueError):
        nights_charged(-1, 0)
    with pytest.raises(ValueError):
        nights_charged(1, 7)
    with pytest.raises(ValueError):
        swap_for_nights("long", 1, 0)  # type: ignore[arg-type]
    with pytest.raises(ValueError):
        estimated_round_trip(-0.1)
    with pytest.raises(ValueError):
        estimated_round_trip(0.1, spread_points=-1)


# -- journal projection ----------------------------------------------------

OLD_TRADES_SCHEMA = """
CREATE TABLE trades (
    trade_id TEXT PRIMARY KEY,
    slot TEXT NOT NULL,
    strategy TEXT NOT NULL,
    symbol TEXT NOT NULL,
    side TEXT NOT NULL,
    open_time TEXT NOT NULL,
    close_time TEXT,
    pnl_net REAL NOT NULL DEFAULT 0,
    volume REAL NOT NULL DEFAULT 0,
    payload TEXT NOT NULL
);
"""


def _record(**overrides: object) -> TradeRecord:
    fields: dict[str, object] = {
        "trade_id": "s-1",
        "slot": "s",
        "strategy": "numeric",
        "symbol": "XAUUSD",
        "side": "buy",
        "volume": 0.1,
        "open_time": "2024-03-06T10:00:00+00:00",
        "close_time": None,
        "open_price": 2000.0,
        "close_price": None,
        "sl": 1990.0,
        "tp": 2010.0,
        "pnl_gross": 0.0,
        "commission": 0.0,
        "swap": 0.0,
        "pnl_net": 0.0,
        "spread_at_entry": 0.2,
    }
    fields.update(overrides)
    return TradeRecord(**fields)  # type: ignore[arg-type]


def _trade_columns(path: Path) -> set[str]:
    conn = sqlite3.connect(path)
    try:
        return {row[1] for row in conn.execute("PRAGMA table_info(trades)")}
    finally:
        conn.close()


def test_journal_round_trips_cost_fields(scratch: Path) -> None:
    db = scratch / "costs.db"
    journal = SqliteJournal(db)
    try:
        journal.record_trade(
            _record(
                config_hash="deadbeef",
                entry_slippage_pts=1.5,
                spread_at_signal_pts=18.0,
                spread_at_fill_pts=21.0,
                latency_ms=42.0,
                mt5_deal_ids=[101, 102],
                estimated_cost=6.5,
            )
        )
        journal.update_trade(
            "s-1",
            close_time="2024-03-06T12:00:00+00:00",
            pnl_net=10.0,
            commission_actual=0.7,
            swap_actual=1.2,
            actual_cost=5.9,
        )
        trade = journal.trade("s-1")
        trades = journal.trades()
        stats = journal.stats()
    finally:
        journal.close()

    assert trade is not None
    assert trade.config_hash == "deadbeef"
    assert trade.entry_slippage_pts == pytest.approx(1.5)
    assert trade.spread_at_signal_pts == pytest.approx(18.0)
    assert trade.spread_at_fill_pts == pytest.approx(21.0)
    assert trade.latency_ms == pytest.approx(42.0)
    assert trade.mt5_deal_ids == [101, 102]
    assert trade.estimated_cost == pytest.approx(6.5)
    assert trade.actual_cost == pytest.approx(5.9)
    assert trade.commission_actual == pytest.approx(0.7)
    assert trade.swap_actual == pytest.approx(1.2)
    assert [t.trade_id for t in trades] == ["s-1"]

    assert stats["estimated_cost"] == pytest.approx(6.5)
    assert stats["actual_cost"] == pytest.approx(5.9)
    assert stats["cost_drift"] == pytest.approx(-0.6)
    assert stats["commission_actual"] == pytest.approx(0.7)
    assert stats["swap_actual"] == pytest.approx(1.2)
    assert stats["avg_latency_ms"] == pytest.approx(42.0)
    assert stats["avg_entry_slippage_pts"] == pytest.approx(1.5)
    assert stats["config_hashes"] == ["deadbeef"]

    # the columns are a real SQL projection, not payload-only metadata
    conn = sqlite3.connect(db)
    try:
        row = conn.execute(
            "SELECT config_hash, mt5_deal_ids, actual_cost FROM trades WHERE trade_id = 's-1'"
        ).fetchone()
    finally:
        conn.close()
    assert row is not None
    assert row[0] == "deadbeef"
    assert json.loads(row[1]) == [101, 102]
    assert row[2] == pytest.approx(5.9)


def test_journal_migrates_a_legacy_schema_in_place(scratch: Path) -> None:
    db = scratch / "legacy.db"
    payload = {
        "trade_id": "legacy-1",
        "slot": "x",
        "strategy": "s",
        "symbol": "XAUUSD",
        "side": "sell",
        "volume": 0.2,
        "open_time": "2024-01-01T00:00:00+00:00",
        "close_time": "2024-01-01T01:00:00+00:00",
        "open_price": 2000.0,
        "close_price": 1999.0,
        "sl": 2002.0,
        "tp": 1996.0,
        "pnl_gross": 20.0,
        "commission": 0.0,
        "swap": 0.0,
        "pnl_net": 18.0,
        "spread_at_entry": 0.2,
    }
    conn = sqlite3.connect(db)
    try:
        conn.executescript(OLD_TRADES_SCHEMA)
        conn.execute(
            "INSERT INTO trades VALUES (?,?,?,?,?,?,?,?,?,?)",
            (
                "legacy-1",
                "x",
                "s",
                "XAUUSD",
                "sell",
                payload["open_time"],
                payload["close_time"],
                18.0,
                0.2,
                json.dumps(payload),
            ),
        )
        conn.commit()
    finally:
        conn.close()

    assert "estimated_cost" not in _trade_columns(db)
    journal = SqliteJournal(db)
    try:
        legacy = journal.trade("legacy-1")
        assert legacy is not None
        assert legacy.pnl_net == pytest.approx(18.0)
        assert legacy.config_hash == ""
        assert legacy.estimated_cost is None
        assert legacy.mt5_deal_ids == []
        journal.record_trade(_record(trade_id="new-1", estimated_cost=4.0, mt5_deal_ids=[7]))
        fresh = journal.trade("new-1")
        assert fresh is not None
        assert fresh.estimated_cost == pytest.approx(4.0)
        assert len(journal.trades()) == 2
        assert journal.stats()["trades"] == 1  # stats only counts closed trades
    finally:
        journal.close()

    columns = _trade_columns(db)
    assert {
        "config_hash",
        "entry_slippage_pts",
        "spread_at_signal_pts",
        "spread_at_fill_pts",
        "latency_ms",
        "mt5_deal_ids",
        "commission_actual",
        "swap_actual",
        "estimated_cost",
        "actual_cost",
    } <= columns

    # reopening an already migrated journal is a no-op, not an error
    reopened = SqliteJournal(db)
    try:
        assert len(reopened.trades()) == 2
    finally:
        reopened.close()
