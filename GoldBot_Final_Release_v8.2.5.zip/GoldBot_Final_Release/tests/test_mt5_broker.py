"""Contract tests for the MetaTrader 5 adapter against a fake terminal.

No MetaTrader5 install is required: the adapter takes the module by injection,
exactly like production takes the real terminal.
"""

from __future__ import annotations

import time
from datetime import datetime, timedelta, timezone
from types import SimpleNamespace

import pytest

from goldbot.adapters.mt5_broker import (
    MT5Broker,
    MT5ConnectionError,
    MT5TickFeed,
    load_history,
    symbol_info_from_broker,
)
from goldbot.domain.execution import ApprovedOrder, RiskSnapshot
from goldbot.domain.model import Symbol, SymbolInfo, Tick, Ts, utc


def _info(**updates):
    base = dict(
        symbol=Symbol("XAUUSD"),
        broker_symbol="XAUUSD.st",
        digits=2,
        point=0.01,
        tick_size=0.01,
        contract_size=100.0,
        min_volume=0.01,
        max_volume=10.0,
        volume_step=0.01,
        stops_level_points=0,
        freeze_level_points=0,
        margin_rate=0.01,
        currency_profit="USD",
        trade_mode="full",
        broker_offset=timedelta(0),
        tick_value=1.0,
        filling_mode="ioc",
    )
    base.update(updates)
    return SymbolInfo(**base)


class FakeMT5:
    TIMEFRAME_M5 = 5
    TIMEFRAME_M15 = 15
    TIMEFRAME_H1 = 16385

    def __init__(self) -> None:
        now = int(time.time())
        self.account = SimpleNamespace(
            login=80180927,
            server="ePlanet-MT5",
            currency="USD",
            balance=1100.0,
            equity=1100.0,
            margin=0.0,
            margin_free=1100.0,
            leverage=100,
            margin_mode=2,
            trade_mode=0,
            trade_allowed=True,
        )
        self.terminal = SimpleNamespace(build=6238, connected=True, trade_allowed=True)
        self.symbol = SimpleNamespace(
            name="XAUUSD.st",
            digits=2,
            point=0.01,
            trade_contract_size=100.0,
            volume_min=0.01,
            volume_max=10.0,
            volume_step=0.01,
            trade_stops_level=0,
            trade_freeze_level=0,
            filling_mode=2,
            trade_mode=4,
            trade_tick_value=1.0,
            trade_tick_size=0.01,
            swap_long=-67.408,
            swap_short=12.872,
            currency_profit="USD",
        )
        self.tick = SimpleNamespace(time=now, bid=3879.99, ask=3880.69, volume=3)
        self.positions_list: list[SimpleNamespace] = []
        self.orders_list: list[SimpleNamespace] = []
        self.deals_list: list[SimpleNamespace] = []
        self.history_orders_list: list[SimpleNamespace] = []
        self.rates: dict[int, list[dict]] = {}
        self.sent: list[dict] = []
        self.init_kwargs: dict | None = None
        self.shutdown_called = False
        self.retcode = 10009
        self.fill_price = 3880.69
        self.next_ticket = 100001
        self.next_deal = 900001

    def initialize(self, **kwargs):
        self.init_kwargs = kwargs
        return True

    def shutdown(self):
        self.shutdown_called = True
        return True

    def last_error(self):
        return (1, "Success")

    def account_info(self):
        return self.account

    def terminal_info(self):
        return self.terminal

    def symbol_info(self, name):
        return self.symbol if name == "XAUUSD.st" else None

    def symbol_select(self, name, enable):
        return True

    def symbol_info_tick(self, name):
        return self.tick

    def positions_get(self, symbol=None, ticket=None, group=None):
        rows = self.positions_list
        if symbol:
            rows = [row for row in rows if row.symbol == symbol]
        if ticket:
            rows = [row for row in rows if row.ticket == ticket]
        return tuple(rows)

    def orders_get(self, symbol=None, ticket=None, group=None):
        return tuple(self.orders_list)

    def history_deals_get(self, *args, position=0, ticket=0):
        rows = self.deals_list
        if position:
            rows = [row for row in rows if row.position == position]
        if ticket:
            rows = [row for row in rows if row.ticket == ticket]
        return tuple(rows)

    def history_orders_get(self, *args, position=0, ticket=0):
        return tuple(self.history_orders_list)

    def copy_rates_from_pos(self, symbol, timeframe, start, count):
        return self.rates.get(timeframe, [])[:count]

    def _add_deal(self, *, position, ticket, volume, price, profit, commission, swap=0.0, comment="sl"):
        self.deals_list.append(
            SimpleNamespace(
                ticket=ticket,
                position=position,
                order=ticket + 1,
                entry=1,
                symbol="XAUUSD.st",
                type=1,
                volume=volume,
                price=price,
                profit=profit,
                commission=commission,
                swap=swap,
                time=int(time.time()),
                comment=comment,
            )
        )

    def order_send(self, request):
        self.sent.append(dict(request))
        if self.retcode != 10009:
            return SimpleNamespace(
                retcode=self.retcode, comment="rejected", price=0.0, volume=0.0, order=0, deal=0
            )
        action = int(request.get("action", 1))
        if action == 1 and "position" not in request:
            ticket = self.next_ticket
            self.next_ticket += 1
            self.positions_list.append(
                SimpleNamespace(
                    ticket=ticket,
                    symbol=request["symbol"],
                    type=int(request["type"]),
                    volume=float(request["volume"]),
                    price_open=self.fill_price,
                    sl=float(request.get("sl", 0.0)),
                    tp=float(request.get("tp", 0.0)),
                    magic=int(request.get("magic", 0)),
                    comment=str(request.get("comment", "")),
                    time=int(time.time()),
                    profit=0.0,
                    swap=0.0,
                )
            )
            return SimpleNamespace(
                retcode=10009,
                comment="done",
                price=self.fill_price,
                volume=float(request["volume"]),
                order=ticket,
                deal=self.next_deal,
            )
        if action == 1 and "position" in request:
            ticket = int(request["position"])
            volume = float(request["volume"])
            closed = [row for row in self.positions_list if row.ticket == ticket]
            if not closed:
                return SimpleNamespace(
                    retcode=10036, comment="closed", price=0.0, volume=0.0, order=0, deal=0
                )
            row = closed[0]
            row.volume = round(row.volume - volume, 8)
            if row.volume <= 1e-9:
                self.positions_list.remove(row)
            price = float(self.tick.bid if int(request["type"]) == 1 else self.tick.ask)
            self._add_deal(
                position=ticket,
                ticket=self.next_deal,
                volume=-volume,
                price=price,
                profit=2.5,
                commission=-0.35,
                swap=0.0,
                comment=str(request.get("comment", "close")),
            )
            self.next_deal += 1
            return SimpleNamespace(
                retcode=10009,
                comment="done",
                price=price,
                volume=volume,
                order=ticket,
                deal=self.next_deal,
            )
        return SimpleNamespace(
            retcode=10009,
            comment="ok",
            price=0.0,
            volume=0.0,
            order=int(request.get("position", 0)),
            deal=0,
        )


def _broker(fake=None, info=None, **kwargs):
    module = fake or FakeMT5()
    return (
        MT5Broker(
            info or _info(),
            login=80180927,
            password="secret",
            server="ePlanet-MT5",
            path=r"C:\MT5\terminal64.exe",
            mt5_module=module,
            **kwargs,
        ),
        module,
    )


def _order(info=None, *, side="buy", volume=0.01):
    info = info or _info()
    entry = 3880.69 if side == "buy" else 3879.99
    stop = entry - 3.0 if side == "buy" else entry + 3.0
    target = entry + 6.0 if side == "buy" else entry - 6.0
    return ApprovedOrder(
        intent_id="zones_m15-000001-abcdef",
        slot="zones_m15",
        strategy="zones",
        symbol=Symbol("XAUUSD"),
        side=side,
        volume=volume,
        order_type="market",
        sl=round(stop, 2),
        tp=round(target, 2),
        magic=73_000_001,
        client_ref="gbm15-000001-abcdef",
        max_slippage_points=15,
        risk=RiskSnapshot(
            equity=1100.0,
            balance=1100.0,
            risk_pct=1.0,
            risk_amount=11.0,
            stop_distance=3.0,
            volume=volume,
            spread_points=70.0,
            profile="medium",
        ),
    )


def _fake_tick(fake):
    return Tick(
        symbol=Symbol("XAUUSD"),
        bid=float(fake.tick.bid),
        ask=float(fake.tick.ask),
        ts_event=Ts(datetime.now(tz=timezone.utc)),
        ts_recv=Ts(datetime.now(tz=timezone.utc)),
        volume=1,
    )


def test_connect_maps_account_and_learns_server_offset():
    fake = FakeMT5()
    fake.tick.time = int(time.time()) + 7200
    broker, _ = _broker(fake)
    connection = broker.connect()
    assert connection.login == 80180927
    assert connection.server == "ePlanet-MT5"
    assert connection.trade_mode == "hedging"
    assert connection.terminal == "MT5 build 6238"
    assert connection.broker_offset == timedelta(hours=2)
    assert fake.init_kwargs["password"] == "secret"
    assert fake.init_kwargs["path"].endswith("terminal64.exe")
    account = broker.account()
    assert float(account.equity.amount) == 1100.0
    assert account.currency == "USD"
    assert account.leverage == 100
    assert broker.is_demo() is True


def test_raw_tick_removes_the_clock_skew_left_by_offset_rounding():
    fake = FakeMT5()
    skew = -32.0  # the PC clock runs 32 s ahead of the broker timestamp
    fake.tick.time = int(time.time()) + 7200 + int(skew)
    broker, _ = _broker(fake)
    broker.connect()
    assert broker.offset == timedelta(hours=2)
    tick = broker.raw_tick()
    assert tick is not None
    age = (datetime.now(tz=timezone.utc) - tick.ts_event.wall).total_seconds()
    assert -2.0 <= age <= 2.0
    assert broker.skew_seconds == pytest.approx(skew, abs=2.0)


def test_raw_tick_keeps_a_frozen_feed_stale_after_calibration():
    fake = FakeMT5()
    fake.tick.time = int(time.time()) + 7200 - 2
    broker, _ = _broker(fake)
    broker.connect()
    assert broker.raw_tick() is not None
    fake.tick.time = int(time.time()) + 7200 - 2 - 300
    tick = broker.raw_tick()
    assert tick is not None
    age = (datetime.now(tz=timezone.utc) - tick.ts_event.wall).total_seconds()
    assert 295.0 <= age <= 305.0


def test_connect_refuses_a_different_login():
    fake = FakeMT5()
    fake.account.login = 42
    broker, _ = _broker(fake)
    with pytest.raises(MT5ConnectionError):
        broker.connect()
    assert fake.shutdown_called is True


def test_connect_refuses_symbol_metadata_mismatch():
    fake = FakeMT5()
    fake.symbol.trade_contract_size = 10.0
    broker, _ = _broker(fake)
    with pytest.raises(MT5ConnectionError):
        broker.connect()


def test_submit_builds_an_ioc_market_deal_with_protection():
    fake = FakeMT5()
    broker, _ = _broker(fake)
    broker.connect()
    order = _order()
    ack = broker.submit(order, idempotency_key="run:intent")
    assert ack.accepted is True
    assert ack.ticket == 100001
    assert ack.fill_price == pytest.approx(fake.fill_price)
    request = fake.sent[-1]
    assert request["action"] == 1
    assert request["symbol"] == "XAUUSD.st"
    assert request["type"] == 0
    assert request["volume"] == pytest.approx(0.01)
    assert request["price"] == pytest.approx(fake.tick.ask)
    assert request["sl"] == pytest.approx(order.sl)
    assert request["tp"] == pytest.approx(order.tp)
    assert request["magic"] == order.magic
    assert request["comment"] == order.client_ref
    assert request["type_filling"] == 1
    assert broker.positions() and broker.positions()[0].ticket == 100001


def test_submit_refuses_when_autotrading_is_off():
    fake = FakeMT5()
    fake.terminal.trade_allowed = False
    broker, _ = _broker(fake)
    broker.connect()
    ack = broker.submit(_order(), idempotency_key="k")
    assert ack.accepted is False
    assert ack.retcode == 10027
    assert fake.sent == []


def test_submit_refuses_a_closed_market():
    fake = FakeMT5()
    broker, _ = _broker(fake)
    broker.connect()
    fake.tick.ask = 0.0
    ack = broker.submit(_order(), idempotency_key="k")
    assert ack.accepted is False
    assert ack.retcode == 10018
    assert fake.sent == []


def test_close_returns_a_closed_trade_with_positive_cost_commission():
    fake = FakeMT5()
    broker, _ = _broker(fake)
    broker.connect()
    broker.submit(_order(), idempotency_key="k")
    ack = broker.close(100001, volume=None, idempotency_key="c", reason="sl")
    assert ack.accepted is True
    trade = ack.closed_trade
    assert trade is not None
    assert float(trade.volume) == pytest.approx(0.01)
    assert trade.reason == "sl"
    assert float(trade.pnl_gross.amount) == pytest.approx(2.5)
    assert float(trade.commission.amount) == pytest.approx(0.35)
    assert float(trade.pnl_net.amount) == pytest.approx(2.5 - 0.35)
    assert trade.close_time.tzinfo is not None


def test_settlement_is_detected_once_from_venue_history():
    fake = FakeMT5()
    broker, _ = _broker(fake, settlement_poll_s=0.0)
    broker.connect()
    # A position that existed before the engine started (restart case).
    fake.positions_list.append(
        SimpleNamespace(
            ticket=555,
            symbol="XAUUSD.st",
            type=0,
            volume=0.02,
            price_open=3800.0,
            sl=3790.0,
            tp=3830.0,
            magic=1,
            comment="gbx",
            time=int(time.time()) - 3600,
            profit=0.0,
            swap=0.0,
        )
    )
    broker.on_market_tick(_fake_tick(fake))  # track it
    fake.positions_list.clear()
    fake._add_deal(
        position=555,
        ticket=777,
        volume=-0.02,
        price=3790.0,
        profit=-20.0,
        commission=-0.7,
        comment="sl 3790.00",
    )
    broker._last_poll = 0.0
    closed = broker.on_market_tick(_fake_tick(fake))
    assert len(closed) == 1
    trade = closed[0]
    assert trade.reason == "sl"
    assert float(trade.volume) == pytest.approx(0.02)
    assert float(trade.pnl_net.amount) == pytest.approx(-20.0 - 0.7)
    assert trade.open_time.tzinfo is not None
    broker._last_poll = 0.0
    assert broker.on_market_tick(_fake_tick(fake)) == ()


def test_find_by_client_ref_adopts_an_open_position():
    fake = FakeMT5()
    broker, _ = _broker(fake)
    broker.connect()
    broker.submit(_order(), idempotency_key="k")
    found = broker.find_by_client_ref("gbm15-000001-abcdef", since=datetime.now(tz=timezone.utc) - timedelta(minutes=5))
    assert len(found) == 1
    assert found[0].ticket == 100001
    assert found[0].state == "filled"


def test_load_history_converts_to_utc_and_drops_the_forming_bar():
    fake = FakeMT5()
    offset = timedelta(hours=2)
    server_now = int(time.time()) + int(offset.total_seconds())
    start = server_now - (server_now % 900)
    fake.rates[15] = [
        {"time": start - 1800, "open": 1.0, "high": 2.0, "low": 0.5, "close": 1.5, "tick_volume": 10, "spread": 5},
        {"time": start - 900, "open": 1.5, "high": 2.5, "low": 1.0, "close": 2.0, "tick_volume": 12, "spread": 6},
        {"time": start, "open": 2.0, "high": 9.0, "low": 2.0, "close": 9.0, "tick_volume": 1, "spread": 7},
    ]
    bars = load_history(
        fake,
        broker_symbol="XAUUSD.st",
        info=_info(broker_offset=offset),
        timeframes=["M15"],
        offset=offset,
        counts={"M15": 10},
    )
    rows = bars["M15"]
    assert [row.c for row in rows] == [1.5, 2.0]
    assert rows[0].open_time == datetime.fromtimestamp(start - 1800, tz=timezone.utc) - offset
    assert rows[0].spread_avg == pytest.approx(0.05)
    assert rows[0].is_closed is True


def test_tick_feed_yields_utc_ticks_and_updates_the_clock():
    fake = FakeMT5()
    fake.tick.time = int(time.time()) + 7200
    broker, _ = _broker(fake)
    broker.connect()

    class _Clock:
        def __init__(self):
            self.offset = None

        def set_offset(self, value):
            self.offset = value

    clock = _Clock()
    feed = MT5TickFeed(broker, clock=clock, poll_s=0.01)
    stream = feed.stream()
    tick = next(stream)
    feed.stop()
    assert tick.bid == pytest.approx(3879.99)
    assert tick.ask == pytest.approx(3880.69)
    assert tick.ts_event.wall.tzinfo is not None
    assert abs((tick.ts_event.wall - datetime.now(tz=timezone.utc)).total_seconds()) < 5
    assert clock.offset == timedelta(hours=2)


def test_symbol_info_from_broker_uses_venue_truth():
    fake = FakeMT5()
    info = symbol_info_from_broker(
        fake,
        broker_symbol="XAUUSD.st",
        logical_name="XAUUSD",
        broker_offset=timedelta(hours=2),
        fallback=_info(),
    )
    assert info.broker_symbol == "XAUUSD.st"
    assert info.symbol == "XAUUSD"
    assert info.max_volume == pytest.approx(10.0)
    assert info.stops_level_points == 0
    assert info.tick_value == pytest.approx(1.0)
    assert info.filling_mode == "ioc"
    assert info.trade_mode == "full"
    assert info.broker_offset == timedelta(hours=2)
