"""Tape validation (D04): a broken tape must fail closed before replay/start.

TapeFeed validates the whole file in __init__, and bootstrap constructs the feed
before the engine connects the broker, so these tests prove the ordering: a
malformed file raises at construction time, never after a partial replay.
"""

from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest
from helpers import make_info

from goldbot.adapters.tape import (
    TapeFeed,
    TapeFormatError,
    TapeWriter,
    generate_synthetic_ticks,
    validate_tape,
)
from goldbot.domain.model import Symbol, Tick, Ts

SYMBOL = Symbol("XAUUSD")
START = datetime(2024, 3, 4, 10, 0, tzinfo=timezone.utc)


def _tick(price: float = 2000.0, *, at: datetime = START, spread: float = 0.2, volume: int = 3) -> Tick:
    return Tick(
        symbol=SYMBOL,
        bid=round(price - spread / 2, 2),
        ask=round(price + spread / 2, 2),
        ts_event=Ts(at),
        ts_recv=Ts(at),
        volume=volume,
    )


def _write_tape(path: Path, ticks) -> Path:
    with TapeWriter(path) as writer:
        for tick in ticks:
            writer.write(tick)
    return path


def _write_lines(path: Path, lines) -> Path:
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


def _valid_lines(count: int = 3):
    lines = []
    for index in range(count):
        stamp = (START + timedelta(minutes=index)).timestamp()
        lines.append(json.dumps({"ts": stamp, "bid": 1999.9, "ask": 2000.1, "v": 2}))
    return lines


def test_valid_tape_summary_and_stream(scratch: Path) -> None:
    path = _write_tape(scratch / "ok.jsonl", [_tick(at=START + timedelta(minutes=i)) for i in range(3)])
    summary = validate_tape(path)
    assert summary.ticks == 3
    assert summary.first_ts == START
    assert summary.last_ts == START + timedelta(minutes=2)
    assert summary.max_spread == pytest.approx(0.2)
    assert summary.size_bytes == path.stat().st_size

    feed = TapeFeed(path, SYMBOL, make_info())
    assert feed.summary == summary
    ticks = list(feed.stream())
    assert len(ticks) == 4  # 3 real + 1 closing tick
    assert ticks[-1].volume == 0
    assert feed.ticks_processed == 3


def test_closing_tick_disabled_yields_only_file_ticks(scratch: Path) -> None:
    path = _write_tape(scratch / "ok.jsonl", [_tick(at=START + timedelta(minutes=i)) for i in range(3)])
    feed = TapeFeed(path, SYMBOL, make_info(), close_final_bar=False)
    assert len(list(feed.stream())) == 3
    assert feed.closing_tick is None


def test_closing_tick_lands_in_the_next_hour_bucket(scratch: Path) -> None:
    last = START.replace(minute=5, second=30)
    path = _write_tape(scratch / "ok.jsonl", [_tick(at=START), _tick(at=last)])
    feed = TapeFeed(path, SYMBOL, make_info())
    closing = list(feed.stream())[-1]
    assert closing.ts_event.wall == START.replace(minute=0, second=0) + timedelta(hours=1)
    assert closing.bid == pytest.approx(1999.9)
    assert closing.ask == pytest.approx(2000.1)
    assert closing.volume == 0


def test_closing_tick_is_deterministic(scratch: Path) -> None:
    path = _write_tape(scratch / "ok.jsonl", [_tick(at=START + timedelta(minutes=i)) for i in range(2)])
    first = list(TapeFeed(path, SYMBOL, make_info()).stream())
    second = list(TapeFeed(path, SYMBOL, make_info()).stream())
    assert first == second


def test_missing_file_fails_construction(scratch: Path) -> None:
    with pytest.raises(TapeFormatError, match="not readable"):
        TapeFeed(scratch / "absent.jsonl", SYMBOL, make_info())


def test_empty_tape_fails_construction(scratch: Path) -> None:
    path = _write_lines(scratch / "empty.jsonl", ["", "   "])
    with pytest.raises(TapeFormatError, match="empty"):
        TapeFeed(path, SYMBOL, make_info())


def test_invalid_json_names_the_line(scratch: Path) -> None:
    path = _write_lines(scratch / "bad.jsonl", [*_valid_lines(2), "{not json"])
    with pytest.raises(TapeFormatError, match="line 3: invalid JSON"):
        TapeFeed(path, SYMBOL, make_info())


def test_missing_required_field_names_field(scratch: Path) -> None:
    line = json.dumps({"ts": START.timestamp(), "bid": 1999.9})
    path = _write_lines(scratch / "bad.jsonl", [line])
    with pytest.raises(TapeFormatError, match="missing required field"):
        validate_tape(path)


@pytest.mark.parametrize("value", ["NaN", "Infinity", "-Infinity"])
def test_non_finite_values_are_rejected(scratch: Path, value: str) -> None:
    line = '{"ts": %f, "bid": %s, "ask": 2000.1}' % (START.timestamp(), value)
    path = _write_lines(scratch / "bad.jsonl", [line])
    with pytest.raises(TapeFormatError, match="not finite"):
        validate_tape(path)


def test_negative_or_zero_price_is_rejected(scratch: Path) -> None:
    for bad in (-1.0, 0.0):
        line = json.dumps({"ts": START.timestamp(), "bid": bad, "ask": 2000.1})
        path = _write_lines(scratch / "bad.jsonl", [line])
        with pytest.raises(TapeFormatError, match="positive"):
            validate_tape(path)


def test_bid_above_ask_is_rejected(scratch: Path) -> None:
    line = json.dumps({"ts": START.timestamp(), "bid": 2000.5, "ask": 2000.1})
    path = _write_lines(scratch / "bad.jsonl", [line])
    with pytest.raises(TapeFormatError, match="bid .* > ask"):
        validate_tape(path)


def test_non_monotonic_timestamps_are_rejected(scratch: Path) -> None:
    lines = _valid_lines(3)
    shuffled = [lines[1], lines[0], lines[2]]
    path = _write_lines(scratch / "bad.jsonl", shuffled)
    with pytest.raises(TapeFormatError, match="non-monotonic"):
        validate_tape(path)


@pytest.mark.parametrize("volume", [-1, 2.5, "many"])
def test_invalid_volume_is_rejected(scratch: Path, volume) -> None:
    line = json.dumps({"ts": START.timestamp(), "bid": 1999.9, "ask": 2000.1, "v": volume})
    path = _write_lines(scratch / "bad.jsonl", [line])
    with pytest.raises(TapeFormatError, match="'v'"):
        validate_tape(path)


def test_bad_tail_fails_before_any_tick_is_replayed(scratch: Path) -> None:
    # 100 valid lines, then one broken line: construction must fail BEFORE the
    # feed yields anything, because bootstrap builds the feed before broker.start().
    path = _write_lines(scratch / "bad_tail.jsonl", [*_valid_lines(100), '{"ts": 1, "bid": 2}'])
    with pytest.raises(TapeFormatError, match="line 101"):
        TapeFeed(path, SYMBOL, make_info())


def test_validate_false_defers_but_stream_still_fails_closed(scratch: Path) -> None:
    path = _write_lines(scratch / "bad_tail.jsonl", [*_valid_lines(2), "{oops"])
    feed = TapeFeed(path, SYMBOL, make_info(), validate=False)  # permits construction
    with pytest.raises(TapeFormatError, match="line 3: invalid JSON"):
        list(feed.stream())


def test_validation_does_not_modify_the_tape(scratch: Path) -> None:
    path = _write_tape(scratch / "ok.jsonl", [_tick(at=START + timedelta(minutes=i)) for i in range(5)])
    before = path.read_bytes()
    validate_tape(path)
    list(TapeFeed(path, SYMBOL, make_info()).stream())
    assert path.read_bytes() == before


def test_generated_synthetic_tape_passes_validation(scratch: Path) -> None:
    path = scratch / "synthetic.jsonl"
    with TapeWriter(path) as writer:
        for tick in generate_synthetic_ticks(
            symbol=SYMBOL, start=START, days=2, ticks_per_minute=2, seed=7
        ):
            writer.write(tick)
    summary = validate_tape(path)
    assert summary.ticks > 0  # weekday-only generator output
    assert summary.span_seconds > 0
