"""Chaos: injected venue failures, feed loss and crash/reopen paths must recover.

Every scenario uses deterministic injection points on FakeBroker/SQLite, so a
failure names the exact step instead of depending on timing.
"""

from __future__ import annotations

import json
import sqlite3
from datetime import timedelta

import pytest
from helpers import NOW, make_info, make_tick

from goldbot.adapters.clock import SimulatedClock
from goldbot.adapters.fake_broker import FakeBroker
from goldbot.adapters.sqlite_state_store import SqliteRiskStateStore
from goldbot.adapters.sqlite_store import SqliteJournal
from goldbot.app.health import HealthSnapshot, snapshot
from goldbot.app.position_manager import PositionManager
from goldbot.app.reconciler import Reconciler
from goldbot.domain.errors import SubmitUncertain
from goldbot.domain.events import Ev, Event
from goldbot.domain.execution import ApprovedOrder, RiskSnapshot
from goldbot.domain.model import Fill, Symbol, Ts
from goldbot.domain.money import money
from goldbot.ports.risk import RiskState
from goldbot.ports.state import PersistedRiskState, StateCorruption


def _broker(**kwargs) -> FakeBroker:
    broker = FakeBroker(make_info(), balance=10_000.0, **kwargs)
    broker.connect()
    broker.on_market_tick(make_tick(2000.0))
    return broker


def _order(*, volume: float = 0.1, stop_distance: float = 2.0, side: str = "buy") -> ApprovedOrder:
    price = 2000.0
    sl = price - stop_distance if side == "buy" else price + stop_distance
    return ApprovedOrder(
        intent_id="chaos-1",
        slot="unit",
        strategy="zones",
        symbol=Symbol("XAUUSD"),
        side=side,
        volume=volume,
        order_type="market",
        sl=sl,
        tp=price + 2.0 * stop_distance if side == "buy" else price - 2.0 * stop_distance,
        magic=77002,
        client_ref="gbchaos",
        max_slippage_points=20,
        risk=RiskSnapshot(
            equity=10_000.0,
            balance=10_000.0,
            risk_pct=0.5,
            risk_amount=50.0,
            stop_distance=stop_distance,
            volume=volume,
            spread_points=20.0,
        ),
    )


def _open(broker: FakeBroker, *, volume: float = 0.1) -> int:
    ack = broker.submit(_order(volume=volume), idempotency_key="chaos-open")
    assert ack.accepted is True
    assert ack.ticket is not None
    return int(ack.ticket)


def _fill(ticket: int = 42) -> Fill:
    return Fill(
        ticket=ticket,
        symbol=Symbol("XAUUSD"),
        side="buy",
        volume=0.1,
        price=2000.0,
        commission=money(0.0),
        ts=Ts(NOW),
    )


def test_modify_failure_then_same_key_retry_succeeds() -> None:
    broker = _broker()
    ticket = _open(broker)
    assert broker.positions()[0].sl == pytest.approx(1998.0)

    broker.inject_modify_failure(1)
    failed = broker.modify(ticket, sl=1997.0, tp=2004.0, idempotency_key="mod-1")
    assert failed.accepted is False
    assert failed.retcode_name == "INJECTED_MODIFY_FAILURE"
    assert broker.positions()[0].sl == pytest.approx(1998.0)  # untouched on failure

    retried = broker.modify(ticket, sl=1997.0, tp=2004.0, idempotency_key="mod-1")
    assert retried.accepted is True
    assert broker.positions()[0].sl == pytest.approx(1997.0)


def test_close_failure_during_flatten_is_retryable() -> None:
    broker = _broker()
    ticket = _open(broker)
    broker.inject_close_failure(1)

    failed = broker.close(ticket, volume=None, idempotency_key="flat-1", reason="kill")
    assert failed.accepted is False
    assert failed.retcode_name == "INJECTED_CLOSE_FAILURE"
    assert broker.open_tickets == [ticket]

    retried = broker.close(ticket, volume=None, idempotency_key="flat-1", reason="kill")
    assert retried.accepted is True
    assert retried.closed_trade is not None
    assert broker.open_tickets == []


def test_disconnect_blocks_writes_and_reconnect_restores_them() -> None:
    broker = _broker()
    broker.set_offline(True)
    assert broker.is_ready() is False
    with pytest.raises(SubmitUncertain):
        broker.submit(_order(), idempotency_key="offline-1")

    broker.set_offline(False)
    assert broker.is_ready() is True
    assert broker.submit(_order(), idempotency_key="offline-2").accepted is True

    broker.disconnect()
    assert broker.is_ready() is False
    broker.connect()
    assert broker.is_ready() is True


def test_reconciliation_orphan_is_journaled(scratch) -> None:
    broker = _broker()
    ticket = _open(broker)
    journal = SqliteJournal(scratch / "journal.db")
    try:
        manager = PositionManager()
        reconciler = Reconciler(
            positions=manager, broker=broker, journal=journal, clock=SimulatedClock(NOW)
        )
        report = reconciler.run()
        assert report.clean is False
        assert report.orphan == (ticket,)
        assert reconciler.last_report is report

        divergence = list(journal.read_events(type=Ev.DIVERGENCE))
        assert len(divergence) == 1
        assert list(divergence[0].payload["orphan"]) == [ticket]
        assert divergence[0].correlation_id == ""
    finally:
        journal.close()


def test_reconciliation_missing_position_is_journaled(scratch) -> None:
    broker = _broker()  # venue is flat
    journal = SqliteJournal(scratch / "journal.db")
    try:
        manager = PositionManager()
        manager.apply_fill(_fill(42))
        report = Reconciler(
            positions=manager, broker=broker, journal=journal, clock=SimulatedClock(NOW)
        ).run()
        assert report.clean is False
        assert report.missing == (42,)
        divergence = list(journal.read_events(type=Ev.DIVERGENCE))
        assert len(divergence) == 1
        assert list(divergence[0].payload["missing"]) == [42]
    finally:
        journal.close()


def test_journal_reopens_after_a_crash(scratch) -> None:
    path = scratch / "journal.db"
    journal = SqliteJournal(path)
    journal.append(Event(type="BeforeCrash", payload={"n": 1}, ts=Ts(NOW)))
    journal.record_equity(NOW.isoformat(), 10_000.0, 10_000.0)
    journal.close()  # what a SIGKILL leaves behind: committed WAL, no cleanup

    reopened = SqliteJournal(path)
    try:
        assert reopened.count() == 1
        events = list(reopened.read_events())
        assert events[0].type == "BeforeCrash"
        assert len(reopened.equity_curve()) == 1
        reopened.append(Event(type="AfterCrash", payload={"n": 2}, ts=Ts(NOW)))
        assert reopened.count() == 2
    finally:
        reopened.close()


def test_state_store_corrupt_row_is_not_a_cold_start(scratch) -> None:
    path = scratch / "risk_state.db"
    store = SqliteRiskStateStore(path)
    store.save(
        PersistedRiskState(state=RiskState.KILLED, reason="daily loss", updated_at=NOW.isoformat())
    )
    store.close()

    raw = sqlite3.connect(path)
    raw.execute("UPDATE risk_state SET payload = ?", ("{broken",))
    raw.commit()
    raw.close()

    reopened = SqliteRiskStateStore(path)
    try:
        with pytest.raises(StateCorruption):
            reopened.load()
    finally:
        reopened.close()


def test_partial_close_then_sl_failure_then_flatten() -> None:
    broker = _broker(scenario="partial_then_sl_fail")
    ticket = _open(broker, volume=1.0)

    partial = broker.close(
        ticket, volume=0.5, idempotency_key="partial-1", reason="tp"
    )
    assert partial.accepted is True
    assert partial.closed_trade is not None
    assert partial.closed_trade.volume == pytest.approx(0.5)
    assert broker.fail_next_modify == 1  # the scenario armed one SL failure
    assert broker.open_tickets == [ticket]

    failed = broker.modify(ticket, sl=1997.0, tp=2004.0, idempotency_key="sl-1")
    assert failed.accepted is False
    assert failed.retcode_name == "INJECTED_MODIFY_FAILURE"

    retried = broker.modify(ticket, sl=1997.0, tp=2004.0, idempotency_key="sl-1")
    assert retried.accepted is True

    flat = broker.close(ticket, volume=None, idempotency_key="flat-1", reason="kill")
    assert flat.accepted is True
    assert flat.closed_trade is not None
    assert broker.open_tickets == []


# ---------------------------------------------------------------- health


class _Risk:
    def __init__(
        self,
        *,
        state: str = "NORMAL",
        reason: str = "",
        daily_pnl: float = 0.0,
        drawdown_pct: float = 0.0,
        orders_today: int = 0,
        open_positions: int = 0,
    ) -> None:
        self._state_value = state
        self.reason = reason
        self.daily_pnl = daily_pnl
        self.drawdown_pct = drawdown_pct
        self.orders_today = orders_today
        self.open_positions = open_positions

    def state(self) -> str:
        return self._state_value


class _BrokenRisk:
    @property
    def state(self):
        raise RuntimeError("state accessor is broken")

    @property
    def daily_pnl(self):
        raise RuntimeError("daily_pnl accessor is broken")

    @property
    def positions(self):
        raise RuntimeError("positions accessor is broken")


class _BrokenJournal:
    def count(self):
        raise OSError("journal file vanished")


def _write_heartbeat(path, ts) -> None:
    path.write_text(
        json.dumps({"ts": ts.isoformat(), "pid": 1, "payload": {"equity": 10_000.0}}),
        encoding="utf-8",
    )


def test_health_snapshot_is_healthy_when_everything_is(scratch) -> None:
    journal = SqliteJournal(scratch / "journal.db")
    try:
        journal.append(Event(type="SessionStarted", payload={}, ts=Ts(NOW)))
        heartbeat = scratch / "heartbeat.json"
        _write_heartbeat(heartbeat, NOW)

        snap = snapshot(
            risk=_Risk(daily_pnl=12.5, drawdown_pct=1.5, orders_today=2, open_positions=1),
            journal=journal,
            heartbeat_path=heartbeat,
            now=NOW,
        )
        assert isinstance(snap, HealthSnapshot)
        assert snap.degraded is False
        assert snap.ok is True
        assert snap.risk_state == "NORMAL"
        assert snap.heartbeat_stale is False
        assert snap.heartbeat_age_seconds == pytest.approx(0.0)
        assert snap.journal_events == 1
        assert snap.open_positions == 1
        assert snap.orders_today == 2
        assert snap.daily_pnl == pytest.approx(12.5)
        assert snap.drawdown_pct == pytest.approx(1.5)
        assert snap.ts == NOW.isoformat()
        assert snap.details["heartbeat"] == "fresh"
        assert json.loads(json.dumps(snap.as_dict()))["degraded"] is False
    finally:
        journal.close()


def test_health_snapshot_degrades_on_a_latched_state(scratch) -> None:
    journal = SqliteJournal(scratch / "journal.db")
    try:
        heartbeat = scratch / "heartbeat.json"
        _write_heartbeat(heartbeat, NOW)
        snap = snapshot(
            risk=_Risk(state="HALTED", reason="daily loss"),
            journal=journal,
            heartbeat_path=heartbeat,
            now=NOW,
        )
        assert snap.degraded is True
        assert snap.risk_state == "HALTED"
        assert snap.reason == "daily loss"
        assert "risk state HALTED" in snap.details["problems"]
    finally:
        journal.close()


def test_health_snapshot_flags_a_stale_heartbeat(scratch) -> None:
    journal = SqliteJournal(scratch / "journal.db")
    try:
        heartbeat = scratch / "heartbeat.json"
        _write_heartbeat(heartbeat, NOW - timedelta(seconds=3600))
        snap = snapshot(risk=_Risk(), journal=journal, heartbeat_path=heartbeat, now=NOW)
        assert snap.heartbeat_stale is True
        assert snap.heartbeat_age_seconds == pytest.approx(3600.0, abs=5.0)
        assert snap.degraded is True
        assert snap.details["heartbeat"] == "stale"
    finally:
        journal.close()


def test_health_snapshot_never_raises_on_broken_inputs() -> None:
    snap = snapshot(risk=_BrokenRisk(), journal=_BrokenJournal(), heartbeat_path=None, now=NOW)
    assert isinstance(snap, HealthSnapshot)
    assert snap.degraded is True
    assert snap.risk_state == "UNKNOWN"
    assert snap.journal_events == -1
    assert snap.details["journal"].startswith("unreachable")

    missing_heartbeat = snapshot(
        risk=_Risk(), journal=_BrokenJournal(), heartbeat_path=None, now=NOW
    )
    assert missing_heartbeat.heartbeat_stale is True
    assert missing_heartbeat.details["heartbeat"] == "not_configured"

    broken_now = snapshot(risk=_Risk(), journal=_BrokenJournal(), now=None)
    assert broken_now.details["now_ok"] is False
    assert broken_now.degraded is True


def test_health_snapshot_survives_a_corrupt_heartbeat_file(scratch) -> None:
    journal = SqliteJournal(scratch / "journal.db")
    try:
        heartbeat = scratch / "heartbeat.json"
        heartbeat.write_text("not-json", encoding="utf-8")
        snap = snapshot(risk=_Risk(), journal=journal, heartbeat_path=heartbeat, now=NOW)
        assert snap.heartbeat_stale is True
        assert snap.heartbeat_age_seconds is None
        assert snap.details["heartbeat"] == "unknown"
        assert snap.degraded is True
    finally:
        journal.close()
