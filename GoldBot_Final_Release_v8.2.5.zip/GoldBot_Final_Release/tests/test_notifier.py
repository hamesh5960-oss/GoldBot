"""Notifiers: delivery, dedup TTL, rate limit, fan-out and fail-safe behaviour."""

from __future__ import annotations

import logging
import smtplib
import urllib.request
from typing import Any

from goldbot.adapters.notifier import (
    DedupNotifier,
    LogNotifier,
    MultiNotifier,
    SmtpNotifier,
    TelegramNotifier,
    from_env,
)


class FakeMonotonic:
    def __init__(self, start: float = 1000.0) -> None:
        self.now = start

    def __call__(self) -> float:
        return self.now

    def advance(self, seconds: float) -> None:
        self.now += seconds


class RecordingNotifier:
    def __init__(self, delivered: bool = True, error: BaseException | None = None) -> None:
        self.delivered = delivered
        self.error = error
        self.calls: list[tuple[str, str, str, str]] = []

    def send(self, level: str, title: str, body: str, *, dedup_key: str = "") -> bool:
        self.calls.append((level, title, body, dedup_key))
        if self.error is not None:
            raise self.error
        return self.delivered


class FakeResponse:
    def __init__(self, status: int = 200, body: bytes = b'{"ok": true}') -> None:
        self.status = status
        self.body = body

    def read(self) -> bytes:
        return self.body

    def __enter__(self) -> "FakeResponse":
        return self

    def __exit__(self, *exc: object) -> bool:
        return False


class FakeSmtp:
    instances: list["FakeSmtp"] = []

    def __init__(self, host: str, port: int, timeout: float | None = None) -> None:
        self.host = host
        self.port = port
        self.timeout = timeout
        self.started_tls = False
        self.login_args: tuple[str, str] | None = None
        self.message: Any = None
        self.quit_called = False
        FakeSmtp.instances.append(self)

    def starttls(self) -> None:
        self.started_tls = True

    def login(self, user: str, password: str) -> None:
        self.login_args = (user, password)

    def send_message(self, message: Any) -> None:
        self.message = message

    def quit(self) -> None:
        self.quit_called = True


# -- log channel ---------------------------------------------------------


def test_log_notifier_always_delivers(caplog: Any) -> None:
    with caplog.at_level(logging.INFO, logger="goldbot.notify"):
        assert LogNotifier().send("info", "heartbeat", "still alive") is True
    assert any("heartbeat" in record.getMessage() for record in caplog.records)


# -- dedup -----------------------------------------------------------------


def test_dedup_suppresses_same_key_within_ttl() -> None:
    inner = RecordingNotifier()
    clock = FakeMonotonic()
    notifier = DedupNotifier(inner, ttl_seconds=600, max_per_minute=10, monotonic=clock)
    assert notifier.send("critical", "risk", "halted", dedup_key="risk-halted") is True
    clock.advance(599)
    assert notifier.send("critical", "risk", "halted", dedup_key="risk-halted") is False
    assert len(inner.calls) == 1


def test_dedup_allows_same_key_after_ttl() -> None:
    inner = RecordingNotifier()
    clock = FakeMonotonic()
    notifier = DedupNotifier(inner, ttl_seconds=600, max_per_minute=10, monotonic=clock)
    assert notifier.send("warn", "t", "b", dedup_key="k") is True
    clock.advance(601)
    assert notifier.send("warn", "t", "b", dedup_key="k") is True
    assert len(inner.calls) == 2


def test_different_keys_pass() -> None:
    inner = RecordingNotifier()
    clock = FakeMonotonic()
    notifier = DedupNotifier(inner, ttl_seconds=600, max_per_minute=10, monotonic=clock)
    assert notifier.send("warn", "t", "b", dedup_key="a") is True
    assert notifier.send("warn", "t", "b", dedup_key="b") is True
    assert len(inner.calls) == 2


def test_empty_dedup_key_is_never_suppressed() -> None:
    inner = RecordingNotifier()
    notifier = DedupNotifier(inner, ttl_seconds=600, max_per_minute=10, monotonic=FakeMonotonic())
    assert notifier.send("info", "t", "b") is True
    assert notifier.send("info", "t", "b") is True
    assert len(inner.calls) == 2


def test_rate_limit_caps_per_minute() -> None:
    inner = RecordingNotifier()
    clock = FakeMonotonic()
    notifier = DedupNotifier(inner, ttl_seconds=600, max_per_minute=2, monotonic=clock)
    assert notifier.send("warn", "t", "b", dedup_key="a") is True
    assert notifier.send("warn", "t", "b", dedup_key="b") is True
    assert notifier.send("warn", "t", "b", dedup_key="c") is False
    assert len(inner.calls) == 2


def test_rate_limit_window_slides() -> None:
    inner = RecordingNotifier()
    clock = FakeMonotonic()
    notifier = DedupNotifier(inner, ttl_seconds=600, max_per_minute=1, monotonic=clock)
    assert notifier.send("warn", "t", "b", dedup_key="a") is True
    assert notifier.send("warn", "t", "b", dedup_key="b") is False
    clock.advance(61)
    assert notifier.send("warn", "t", "b", dedup_key="c") is True


def test_failed_delivery_is_not_deduped() -> None:
    inner = RecordingNotifier(delivered=False)
    clock = FakeMonotonic()
    notifier = DedupNotifier(inner, ttl_seconds=600, max_per_minute=10, monotonic=clock)
    assert notifier.send("critical", "t", "b", dedup_key="k") is False
    assert notifier.send("critical", "t", "b", dedup_key="k") is False
    assert len(inner.calls) == 2


def test_failing_inner_adapter_never_raises() -> None:
    inner = RecordingNotifier(error=RuntimeError("channel exploded"))
    notifier = DedupNotifier(inner, monotonic=FakeMonotonic())
    assert notifier.send("critical", "t", "b", dedup_key="k") is False


# -- fan-out ---------------------------------------------------------------


def test_multi_notifier_true_if_any_delivered() -> None:
    failed = RecordingNotifier(delivered=False)
    delivered = RecordingNotifier()
    notifier = MultiNotifier([failed, delivered])
    assert notifier.send("warn", "t", "b", dedup_key="k") is True
    assert len(failed.calls) == 1 and len(delivered.calls) == 1


def test_multi_notifier_false_when_all_fail() -> None:
    notifier = MultiNotifier([RecordingNotifier(delivered=False), RecordingNotifier(delivered=False)])
    assert notifier.send("warn", "t", "b") is False


def test_multi_notifier_survives_raising_channel() -> None:
    broken = RecordingNotifier(error=RuntimeError("boom"))
    delivered = RecordingNotifier()
    notifier = MultiNotifier([broken, delivered])
    assert notifier.send("warn", "t", "b") is True


# -- telegram --------------------------------------------------------------


def test_telegram_success(monkeypatch: Any) -> None:
    captured: dict[str, Any] = {}

    def fake_urlopen(request: Any, timeout: float | None = None) -> FakeResponse:
        captured["url"] = request.full_url
        captured["data"] = request.data
        captured["timeout"] = timeout
        return FakeResponse()

    monkeypatch.setattr(urllib.request, "urlopen", fake_urlopen)
    notifier = TelegramNotifier("token-123", "42")
    assert notifier.send("critical", "Risk HALTED", "reason") is True
    assert "token-123" in captured["url"]
    assert b"chat_id=42" in captured["data"]
    assert captured["timeout"] is not None and captured["timeout"] <= 5.0


def test_telegram_network_error_returns_false(monkeypatch: Any) -> None:
    def boom(*args: Any, **kwargs: Any) -> FakeResponse:
        raise OSError("network down")

    monkeypatch.setattr(urllib.request, "urlopen", boom)
    assert TelegramNotifier("token", "chat").send("warn", "t", "b") is False


def test_telegram_unexpected_error_is_swallowed(monkeypatch: Any) -> None:
    def boom(*args: Any, **kwargs: Any) -> FakeResponse:
        raise ValueError("bad response")

    monkeypatch.setattr(urllib.request, "urlopen", boom)
    assert TelegramNotifier("token", "chat").send("info", "t", "b") is False


def test_telegram_non_200_returns_false(monkeypatch: Any) -> None:
    monkeypatch.setattr(urllib.request, "urlopen", lambda *a, **k: FakeResponse(status=500))
    assert TelegramNotifier("token", "chat").send("warn", "t", "b") is False


def test_telegram_api_ok_false_returns_false(monkeypatch: Any) -> None:
    response = FakeResponse(body=b'{"ok": false}')
    monkeypatch.setattr(urllib.request, "urlopen", lambda *a, **k: response)
    assert TelegramNotifier("token", "chat").send("warn", "t", "b") is False


# -- smtp ------------------------------------------------------------------


def test_smtp_success(monkeypatch: Any) -> None:
    FakeSmtp.instances.clear()
    monkeypatch.setattr(smtplib, "SMTP", FakeSmtp)
    notifier = SmtpNotifier("smtp.local", 587, "user", "secret", "ops@example.com")
    assert notifier.send("critical", "Kill switch", "all flat") is True
    client = FakeSmtp.instances[0]
    assert client.started_tls is True
    assert client.login_args == ("user", "secret")
    assert client.message["Subject"] == "[GoldBot CRITICAL] Kill switch"
    assert client.quit_called is True


def test_smtp_failure_returns_false(monkeypatch: Any) -> None:
    def boom(*args: Any, **kwargs: Any) -> FakeSmtp:
        raise OSError("no route to host")

    monkeypatch.setattr(smtplib, "SMTP", boom)
    assert SmtpNotifier("smtp.local", 587, "u", "p", "ops@example.com").send("warn", "t", "b") is False


# -- from_env --------------------------------------------------------------


def test_from_env_returns_none_when_unconfigured() -> None:
    assert from_env({}) is None
    assert from_env({"GOLDBOT_TELEGRAM_TOKEN": "only-token"}) is None


def test_from_env_builds_dedup_wrapped_telegram(monkeypatch: Any) -> None:
    monkeypatch.setattr(urllib.request, "urlopen", lambda *a, **k: FakeResponse())
    notifier = from_env(
        {"GOLDBOT_TELEGRAM_TOKEN": "token", "GOLDBOT_TELEGRAM_CHAT_ID": "42"},
        max_per_minute=5,
    )
    assert isinstance(notifier, DedupNotifier)
    assert notifier.send("critical", "t", "b", dedup_key="k") is True


def test_from_env_accepts_chat_alias(monkeypatch: Any) -> None:
    monkeypatch.setattr(urllib.request, "urlopen", lambda *a, **k: FakeResponse())
    notifier = from_env({"GOLDBOT_TELEGRAM_TOKEN": "token", "GOLDBOT_TELEGRAM_CHAT": "7"})
    assert isinstance(notifier, DedupNotifier)
    assert notifier.send("warn", "t", "b") is True


def test_from_env_builds_smtp(monkeypatch: Any) -> None:
    FakeSmtp.instances.clear()
    monkeypatch.setattr(smtplib, "SMTP", FakeSmtp)
    notifier = from_env(
        {
            "GOLDBOT_SMTP_HOST": "smtp.local",
            "GOLDBOT_SMTP_PORT": "2525",
            "GOLDBOT_SMTP_USER": "user",
            "GOLDBOT_SMTP_PASSWORD": "secret",
            "GOLDBOT_SMTP_TO": "ops@example.com",
            "GOLDBOT_SMTP_TLS": "0",
        }
    )
    assert isinstance(notifier, DedupNotifier)
    assert notifier.send("critical", "t", "b") is True
    client = FakeSmtp.instances[0]
    assert (client.host, client.port) == ("smtp.local", 2525)
    assert client.started_tls is False


def test_from_env_fans_out_to_every_configured_channel(monkeypatch: Any) -> None:
    FakeSmtp.instances.clear()
    monkeypatch.setattr(smtplib, "SMTP", FakeSmtp)
    monkeypatch.setattr(urllib.request, "urlopen", lambda *a, **k: FakeResponse())
    notifier = from_env(
        {
            "GOLDBOT_TELEGRAM_TOKEN": "token",
            "GOLDBOT_TELEGRAM_CHAT_ID": "42",
            "GOLDBOT_SMTP_HOST": "smtp.local",
            "GOLDBOT_SMTP_USER": "user",
            "GOLDBOT_SMTP_PASSWORD": "secret",
        }
    )
    assert isinstance(notifier, DedupNotifier)
    assert isinstance(notifier.inner, MultiNotifier)
    assert notifier.send("critical", "t", "b") is True
    assert len(FakeSmtp.instances) == 1
