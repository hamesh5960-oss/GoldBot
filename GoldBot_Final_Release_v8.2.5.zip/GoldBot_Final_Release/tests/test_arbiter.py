from __future__ import annotations

from datetime import datetime, timedelta, timezone

from goldbot.app.arbiter import SignalArbiter, has_other_strategy_confirmation


def test_own_strategy_confirmation_does_not_count_as_other_strategy():
    assert has_other_strategy_confirmation(("zones",), "zones") is False


def test_different_strategy_confirmation_counts():
    assert has_other_strategy_confirmation(("numeric", "zones"), "zones") is True


def test_slot_identifier_is_not_used_as_strategy_identity():
    # The engine slot is zones_m15; the arbiter stores the strategy id zones.
    assert has_other_strategy_confirmation(("zones",), "zones") is False


def test_arbiter_only_returns_other_strategy_when_present():
    arbiter = SignalArbiter(window_minutes=30)
    now = datetime(2026, 1, 1, tzinfo=timezone.utc)
    first = arbiter.register(ts=now, slot="zones_m15", strategy="zones", symbol="XAUUSD", side="buy")
    second = arbiter.register(ts=now + timedelta(minutes=5), slot="numeric_m15", strategy="numeric", symbol="XAUUSD", side="buy")
    assert first == ("zones",)
    assert set(second) == {"numeric", "zones"}


def test_arbiter_confirmation_uses_trailing_window_without_lookahead():
    arbiter = SignalArbiter(window_minutes=30)
    now = datetime(2026, 1, 1, tzinfo=timezone.utc)
    arbiter.register(ts=now, slot="zones_m15", strategy="zones", symbol="XAUUSD", side="buy")
    at_boundary = arbiter.register(ts=now + timedelta(minutes=30), slot="numeric_m15",
                                   strategy="numeric", symbol="XAUUSD", side="buy")
    assert "zones" in at_boundary
    after_window = arbiter.register(ts=now + timedelta(minutes=30, seconds=1),
                                    slot="numeric_m15", strategy="numeric",
                                    symbol="XAUUSD", side="buy")
    assert after_window == ("numeric",)


def test_confirmations_is_read_only_and_strictly_earlier():
    arbiter = SignalArbiter(window_minutes=30)
    now = datetime(2026, 1, 1, tzinfo=timezone.utc)
    arbiter.register(ts=now, slot="zones_m15", strategy="zones", symbol="XAUUSD", side="buy")
    assert arbiter.confirmations(ts=now, strategy="numeric", symbol="XAUUSD", side="buy") == ()
    assert arbiter.confirmations(ts=now + timedelta(minutes=1), strategy="numeric",
                                 symbol="XAUUSD", side="buy") == ("zones",)
    assert len(arbiter.recent()) == 1


def test_register_returns_current_then_earlier_strategy_ids():
    arbiter = SignalArbiter(window_minutes=30)
    now = datetime(2026, 1, 1, tzinfo=timezone.utc)
    arbiter.register(ts=now, slot="zones_m15", strategy="zones", symbol="XAUUSD", side="buy")
    assert arbiter.register(ts=now + timedelta(minutes=5), slot="numeric_m15",
                            strategy="numeric", symbol="XAUUSD", side="buy") == ("numeric", "zones")
