"""Session resolution: window validation, DST boundaries and bucket names."""

from __future__ import annotations

from dataclasses import FrozenInstanceError
from datetime import datetime, time, timezone

import pytest

from goldbot.app.market_session import (
    DEFAULT_SESSION_WINDOWS,
    PLACEHOLDER_SESSIONS,
    SESSION_NAMES,
    SessionTableError,
    SessionWindows,
    eu_dst_active,
    is_placeholder_session_table,
    resolve_session,
    us_dst_active,
    validate_live_session_table,
)
from goldbot.domain.model import SessionWindow


def _utc(year: int, month: int, day: int, hour: int = 0, minute: int = 0, second: int = 0) -> datetime:
    return datetime(year, month, day, hour, minute, second, tzinfo=timezone.utc)


_DEFAULT_MAPPING = {
    "asia": [(23, 7)],
    "london": [(7, 12)],
    "overlap": [(12, 16)],
    "ny": [(16, 21)],
    "late_ny": [(21, 23)],
}


# -- defaults and validation --------------------------------------------
def test_default_windows_are_the_documented_buckets() -> None:
    windows = SessionWindows()
    assert windows.asia == ((23.0, 7.0),)
    assert windows.london == ((7.0, 12.0),)
    assert windows.overlap == ((12.0, 16.0),)
    assert windows.ny == ((16.0, 21.0),)
    assert windows.late_ny == ((21.0, 23.0),)
    assert DEFAULT_SESSION_WINDOWS == windows
    assert SESSION_NAMES == ("asia", "london", "overlap", "ny", "late_ny")


def test_from_mapping_matches_the_default() -> None:
    assert SessionWindows.from_mapping(_DEFAULT_MAPPING) == SessionWindows()


def test_overlapping_windows_are_rejected() -> None:
    mapping = dict(_DEFAULT_MAPPING)
    mapping["london"] = [(6, 12)]  # overlaps asia (23 -> 7)
    with pytest.raises(ValueError, match="overlap"):
        SessionWindows.from_mapping(mapping)


def test_windows_must_be_in_ascending_start_order() -> None:
    mapping = dict(_DEFAULT_MAPPING)
    mapping["london"] = [(12, 14), (7, 9)]
    with pytest.raises(ValueError, match="ascending"):
        SessionWindows.from_mapping(mapping)


def test_coverage_under_23_hours_is_rejected() -> None:
    mapping = dict(_DEFAULT_MAPPING)
    mapping["late_ny"] = []  # 24h -> 22h coverage
    with pytest.raises(ValueError, match="at least 23h"):
        SessionWindows.from_mapping(mapping)


def test_zero_length_window_is_rejected() -> None:
    mapping = dict(_DEFAULT_MAPPING)
    mapping["ny"] = [(21, 21)]
    with pytest.raises(ValueError, match="zero length"):
        SessionWindows.from_mapping(mapping)


def test_hours_outside_the_day_are_rejected() -> None:
    mapping = dict(_DEFAULT_MAPPING)
    mapping["asia"] = [(25, 7)]
    with pytest.raises(ValueError, match="outside"):
        SessionWindows.from_mapping(mapping)


def test_unknown_session_names_are_rejected() -> None:
    mapping = dict(_DEFAULT_MAPPING)
    mapping["sydney"] = [(1, 2)]
    with pytest.raises(ValueError, match="unknown session"):
        SessionWindows.from_mapping(mapping)


def test_windows_are_immutable() -> None:
    with pytest.raises(FrozenInstanceError):
        SessionWindows().asia = ()  # type: ignore[misc]


# -- DST ----------------------------------------------------------------
def test_us_dst_boundaries() -> None:
    assert us_dst_active(_utc(2024, 1, 15)) is False
    # 02:00 local is 07:00 UTC at the US spring-forward (EST = UTC-5).
    assert us_dst_active(_utc(2024, 3, 10, 6, 59)) is False
    assert us_dst_active(_utc(2024, 3, 10, 7, 0)) is True
    assert us_dst_active(_utc(2024, 7, 4)) is True
    # 02:00 local is 06:00 UTC at the US fall-back (EDT = UTC-4).
    assert us_dst_active(_utc(2024, 11, 3, 5, 59)) is True
    assert us_dst_active(_utc(2024, 11, 3, 6, 0)) is False
    assert us_dst_active(_utc(2024, 12, 31, 23, 59)) is False


def test_eu_dst_boundaries() -> None:
    assert eu_dst_active(_utc(2024, 1, 15)) is False
    assert eu_dst_active(_utc(2024, 3, 31, 0, 59)) is False
    assert eu_dst_active(_utc(2024, 3, 31, 1, 0)) is True
    assert eu_dst_active(_utc(2024, 7, 4)) is True
    assert eu_dst_active(_utc(2024, 10, 27, 0, 59)) is True
    assert eu_dst_active(_utc(2024, 10, 27, 1, 0)) is False


# -- session names and boundaries ---------------------------------------
@pytest.mark.parametrize(
    ("hour", "minute", "expected"),
    [
        (0, 30, "asia"),
        (6, 59, "asia"),
        (7, 0, "london"),
        (11, 59, "london"),
        (12, 0, "overlap"),
        (15, 59, "overlap"),
        (16, 0, "ny"),
        (20, 59, "ny"),
        (21, 0, "late_ny"),
        (22, 59, "late_ny"),
        (23, 0, "asia"),
        (23, 59, "asia"),
    ],
)
def test_session_boundaries_in_utc(hour: int, minute: int, expected: str) -> None:
    info = resolve_session(_utc(2024, 1, 15, hour, minute), dst_mode="none")
    assert info.name == expected
    assert info.is_open is True
    assert info.utc_offset_hours == 0.0
    assert info.is_dst_active is False


def test_minutes_into_session_counts_from_the_window_start() -> None:
    assert resolve_session(_utc(2024, 1, 15, 7, 30), dst_mode="none").minutes_into_session == pytest.approx(30.0)
    assert resolve_session(_utc(2024, 1, 15, 7, 0), dst_mode="none").minutes_into_session == 0.0
    # Overnight wrap: 06:30 is 7.5h after the 23:00 start.
    assert resolve_session(_utc(2024, 1, 15, 6, 30), dst_mode="none").minutes_into_session == pytest.approx(450.0)
    assert resolve_session(_utc(2024, 1, 15, 7, 30, 30), dst_mode="none").minutes_into_session == pytest.approx(30.5)


# -- offsets ------------------------------------------------------------
def test_us_dst_shifts_the_window_interpretation() -> None:
    winter = resolve_session(_utc(2024, 1, 15, 12, 0), dst_mode="us")
    assert winter.name == "london"
    assert winter.utc_offset_hours == -5.0
    assert winter.is_dst_active is False
    assert winter.minutes_into_session == 0.0

    summer = resolve_session(_utc(2024, 7, 15, 12, 0), dst_mode="us")
    assert summer.name == "london"
    assert summer.utc_offset_hours == -4.0
    assert summer.is_dst_active is True
    assert summer.minutes_into_session == pytest.approx(60.0)


def test_eu_dst_shifts_the_window_interpretation() -> None:
    winter = resolve_session(_utc(2024, 1, 15, 12, 0), dst_mode="eu")
    assert winter.name == "overlap"
    assert winter.utc_offset_hours == 1.0
    assert winter.is_dst_active is False
    assert winter.minutes_into_session == pytest.approx(60.0)

    summer = resolve_session(_utc(2024, 7, 15, 12, 0), dst_mode="eu")
    assert summer.name == "overlap"
    assert summer.utc_offset_hours == 2.0
    assert summer.is_dst_active is True
    assert summer.minutes_into_session == pytest.approx(120.0)


def test_fixed_offset_is_used_as_given() -> None:
    info = resolve_session(
        _utc(2024, 1, 15, 12, 0), dst_mode="fixed", fixed_offset_hours=3.5
    )
    assert info.name == "overlap"
    assert info.utc_offset_hours == 3.5
    assert info.is_dst_active is False
    assert info.minutes_into_session == pytest.approx(210.0)


def test_default_mode_is_us() -> None:
    assert resolve_session(_utc(2024, 1, 15, 12, 0)) == resolve_session(
        _utc(2024, 1, 15, 12, 0), dst_mode="us"
    )


def test_naive_datetimes_are_treated_as_utc() -> None:
    assert resolve_session(datetime(2024, 1, 15, 12, 0), dst_mode="none") == resolve_session(
        _utc(2024, 1, 15, 12, 0), dst_mode="none"
    )


def test_closed_gap_is_reported_as_closed() -> None:
    # Exactly 23h coverage, with the 21:00-22:00 hour left out.
    gap_windows = SessionWindows.from_mapping(
        {
            "asia": [(22, 7)],
            "london": [(7, 12)],
            "overlap": [(12, 16)],
            "ny": [(16, 21)],
            "late_ny": [],
        }
    )
    info = resolve_session(_utc(2024, 1, 15, 21, 30), gap_windows, dst_mode="none")
    assert info.name == "closed"
    assert info.is_open is False
    assert info.minutes_into_session == 0.0
    assert resolve_session(_utc(2024, 1, 15, 22, 15), gap_windows, dst_mode="none").name == "asia"


def test_unknown_dst_mode_is_rejected() -> None:
    with pytest.raises(ValueError, match="dst_mode"):
        resolve_session(_utc(2024, 1, 15, 12, 0), dst_mode="mars")


def test_windows_argument_must_be_session_windows() -> None:
    with pytest.raises(TypeError):
        resolve_session(_utc(2024, 1, 15, 12, 0), "default", dst_mode="none")


# -- live session-table guard (SES-03) ---------------------------------------

_MON_THU_SESSIONS = (SessionWindow(time(1, 0), time(23, 59)),)
_BROKER_OK = {day: [(time(1, 0), time(23, 59))] for day in range(5)}


def test_placeholder_session_table_is_rejected_for_live() -> None:
    assert is_placeholder_session_table(PLACEHOLDER_SESSIONS) is True
    with pytest.raises(SessionTableError, match="placeholder"):
        validate_live_session_table(PLACEHOLDER_SESSIONS)


def test_placeholder_can_be_allowed_explicitly_for_tests_only() -> None:
    warnings = validate_live_session_table(PLACEHOLDER_SESSIONS, allow_placeholder=True)
    assert any("placeholder" in warning for warning in warnings)


def test_missing_broker_sessions_is_a_warning_not_a_pass() -> None:
    warnings = validate_live_session_table(_MON_THU_SESSIONS)
    assert any("unverified" in warning for warning in warnings)


def test_matching_broker_week_passes_clean() -> None:
    assert validate_live_session_table(_MON_THU_SESSIONS, broker_sessions=_BROKER_OK) == ()


def test_friday_early_close_is_rejected() -> None:
    broker = dict(_BROKER_OK)
    broker[4] = [(time(1, 0), time(22, 0))]
    with pytest.raises(SessionTableError, match="Friday"):
        validate_live_session_table(_MON_THU_SESSIONS, broker_sessions=broker)


def test_weekend_broker_session_is_rejected() -> None:
    broker = dict(_BROKER_OK)
    broker[5] = [(time(1, 0), time(12, 0))]
    with pytest.raises(SessionTableError, match="Saturday"):
        validate_live_session_table(_MON_THU_SESSIONS, broker_sessions=broker)


def test_missing_trading_day_is_rejected() -> None:
    broker = dict(_BROKER_OK)
    del broker[2]
    with pytest.raises(SessionTableError, match="Wednesday"):
        validate_live_session_table(_MON_THU_SESSIONS, broker_sessions=broker)


def test_overnight_and_multi_window_template_matches_broker() -> None:
    sessions = (SessionWindow(time(22, 0), time(2, 0)), SessionWindow(time(3, 0), time(6, 0)))
    broker = {
        day: [SessionWindow(time(22, 0), time(2, 0)), (time(3, 0), time(6, 0))]
        for day in range(5)
    }
    assert validate_live_session_table(sessions, broker_sessions=broker) == ()


def test_invalid_weekday_key_is_rejected() -> None:
    broker = dict(_BROKER_OK)
    broker[7] = []
    with pytest.raises(SessionTableError, match="weekday"):
        validate_live_session_table(_MON_THU_SESSIONS, broker_sessions=broker)


def test_empty_session_table_is_rejected() -> None:
    with pytest.raises(SessionTableError, match="empty"):
        validate_live_session_table(())


def test_zero_length_broker_session_is_rejected() -> None:
    broker = dict(_BROKER_OK)
    broker[0] = [(time(1, 0), time(1, 0))]
    with pytest.raises(SessionTableError, match="zero-length"):
        validate_live_session_table(_MON_THU_SESSIONS, broker_sessions=broker)
