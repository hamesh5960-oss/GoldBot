"""Close idempotency and settlement safety on the real MT5 adapter.

Regression tests for the Phase-4 audit defects:
POS-01 (duplicate close / lagging history), POS-02 (flatten failure is reported
and latched), MT5-01 (placed != filled), MT5-02 (a live position is never
forgotten when history lags), MT5-05 (terminal rejects settle/quarantine) and
MT5-06 (TIMEOUT is uncertain).

The fake MetaTrader5 module is injected exactly like the production terminal.
"""

from __future__ import annotations

import time
from dataclasses import replace
from datetime import datetime, timezone
from types import SimpleNamespace

import pytest

from goldbot.adapters.mt5_broker import MT5Broker
from goldbot.app.engine import EngineResult, TradingEngine
from goldbot.app.order_coordinator import OrderCoordinator
from goldbot.app.position_fsm import TPPlan, PositionFSM
from goldbot.app.position_manager import PositionManager
from goldbot.app.weekend import WeekendParams
from goldbot.domain.errors import SubmitUncertain
from goldbot.domain.model import Fill, Symbol, Ticket, Ts
from goldbot.domain.money import money

from test_mt5_broker import FakeMT5, _broker, _fake_tick, _info, _order


class IdemMT5(FakeMT5):
    """Fake terminal with controls for history lag and non-execution."""

    def __init__(self) -> None:
        super().__init__()
        self.hide_deals = False
        self.simulate_no_execution = False
        self.retcode_close = 10009
        self.market_retcode = 0
        self.fill_on_place = False
        self.place_ticket = 424242
        self.close_sends = 0
        self.cancel_sends = 0
        self.pending_sends: list[dict] = []

    def history_deals_get(self, *args, position=0, ticket=0):
        if self.hide_deals:
            return ()
        return super().history_deals_get(*args, position=position, ticket=ticket)

    def order_send(self, request):
        action = int(request.get("action", 1))
        if action == 3:
            self.cancel_sends += 1
            return SimpleNamespace(
                retcode=10009, comment="canceled", price=0.0, volume=0.0,
                order=int(request.get("order", 0)), deal=0,
            )
        self.sent.append(dict(request))
        if "position" in request:
            self.close_sends += 1
            if self.retcode_close != 10009:
                return SimpleNamespace(
                    retcode=self.retcode_close, comment="rejected", price=0.0,
                    volume=0.0, order=0, deal=0,
                )
            if self.simulate_no_execution:
                return SimpleNamespace(
                    retcode=10009, comment="done", price=float(self.tick.bid),
                    volume=float(request["volume"]), order=int(request["position"]),
                    deal=self.next_deal,
                )
            return super().order_send(request)
        if action == 5:
            self.pending_sends.append(dict(request))
            if self.fill_on_place:
                ticket = self.next_ticket
                self.next_ticket += 1
                self.positions_list.append(
                    SimpleNamespace(
                        ticket=ticket,
                        symbol=request["symbol"],
                        type=int(request["type"]),
                        volume=float(request["volume"]),
                        price_open=float(request["price"]),
                        sl=float(request.get("sl", 0.0)),
                        tp=float(request.get("tp", 0.0)),
                        magic=int(request.get("magic", 0)),
                        comment=str(request.get("comment", "")),
                        time=int(time.time()),
                        profit=0.0,
                        swap=0.0,
                    )
                )
                return SimpleNamespace(
                    retcode=10009, comment="done", price=float(request["price"]),
                    volume=float(request["volume"]), order=ticket,
                    deal=self.next_deal,
                )
            return SimpleNamespace(
                retcode=10008, comment="placed", price=0.0, volume=0.0,
                order=self.place_ticket, deal=0,
            )
        if self.market_retcode:
            return SimpleNamespace(
                retcode=self.market_retcode, comment="edge", price=0.0,
                volume=0.0, order=0, deal=0,
            )
        return super().order_send(request)


def _connected(**kwargs):
    fake = IdemMT5()
    broker, _ = _broker(fake, settlement_poll_s=0.0, **kwargs)
    broker.connect()
    return broker, fake


def _open(broker, *, volume=0.02, key="open-1"):
    ack = broker.submit(_order(volume=volume), idempotency_key=key)
    assert ack.accepted and ack.ticket is not None
    return int(ack.ticket)


# ---------------------------------------------------------------------------
# POS-01: one close key -> one send
# ---------------------------------------------------------------------------
def test_same_close_key_sends_exactly_once():
    broker, fake = _connected()
    ticket = _open(broker)
    first = broker.close(Ticket(ticket), volume=None, idempotency_key="close-key", reason="kill")
    assert first.accepted and first.closed_trade is not None
    second = broker.close(Ticket(ticket), volume=None, idempotency_key="close-key", reason="kill")
    assert second.closed_trade is first.closed_trade
    assert fake.close_sends == 1
    assert broker.positions() == ()


def test_partial_close_key_is_idempotent_and_keeps_the_remainder():
    broker, fake = _connected()
    ticket = _open(broker, volume=0.02)
    first = broker.close(Ticket(ticket), volume=0.01, idempotency_key="slice", reason="tp1")
    assert first.accepted and first.closed_trade is not None
    assert float(first.closed_trade.volume) == pytest.approx(0.01)
    second = broker.close(Ticket(ticket), volume=0.01, idempotency_key="slice", reason="tp1")
    assert second.closed_trade is first.closed_trade
    assert fake.close_sends == 1
    assert len(broker.positions()) == 1
    assert broker.positions()[0].volume == pytest.approx(0.01)


def test_acked_close_with_lagging_history_settles_from_snapshot_once():
    broker, fake = _connected()
    ticket = _open(broker)
    fake.hide_deals = True
    first = broker.close(Ticket(ticket), volume=None, idempotency_key="lag", reason="sl")
    assert first.accepted
    assert first.closed_trade is not None
    assert float(first.closed_trade.volume) == pytest.approx(0.02)
    second = broker.close(Ticket(ticket), volume=None, idempotency_key="lag", reason="sl")
    assert second.closed_trade is first.closed_trade
    assert fake.close_sends == 1
    assert broker.positions() == ()


def test_close_without_execution_evidence_is_uncertain_and_not_resent():
    broker, fake = _connected()
    ticket = _open(broker)
    fake.simulate_no_execution = True
    with pytest.raises(SubmitUncertain):
        broker.close(Ticket(ticket), volume=None, idempotency_key="uncertain", reason="kill")
    with pytest.raises(SubmitUncertain):
        broker.close(Ticket(ticket), volume=None, idempotency_key="uncertain", reason="kill")
    assert fake.close_sends == 1  # never a second blind send
    assert len(broker.positions()) == 1


def test_close_on_a_venue_closed_position_settles_from_history():
    broker, fake = _connected()
    ticket = _open(broker)
    fake.positions_list.clear()
    fake._add_deal(
        position=ticket, ticket=777, volume=-0.02, price=3878.0,
        profit=-5.2, commission=-0.2, comment="sl 3878.00",
    )
    ack = broker.close(Ticket(ticket), volume=None, idempotency_key="gone", reason="sl")
    assert ack.accepted and ack.closed_trade is not None
    assert float(ack.closed_trade.volume) == pytest.approx(0.02)
    assert fake.close_sends == 0  # the venue truth stopped the send


# ---------------------------------------------------------------------------
# MT5-02: a tracked ticket is never forgotten when history lags
# ---------------------------------------------------------------------------
def test_settlement_keeps_a_vanished_ticket_until_history_arrives():
    broker, fake = _connected()
    ticket = _open(broker)
    broker.on_market_tick(_fake_tick(fake))  # track the open position
    fake.positions_list.clear()
    broker._last_poll = 0.0
    assert broker.on_market_tick(_fake_tick(fake)) == ()
    assert ticket in broker.pending_settlements
    fake._add_deal(
        position=ticket, ticket=888, volume=-0.02, price=3879.0,
        profit=-4.8, commission=-0.2, comment="sl 3879.00",
    )
    broker._last_poll = 0.0
    closed = broker.on_market_tick(_fake_tick(fake))
    assert len(closed) == 1 and int(closed[0].ticket) == ticket
    assert broker.pending_settlements == ()
    broker._last_poll = 0.0
    assert broker.on_market_tick(_fake_tick(fake)) == ()


# ---------------------------------------------------------------------------
# MT5-01 / MT5-06: acceptance is not execution
# ---------------------------------------------------------------------------
def test_market_submit_without_a_fill_is_uncertain_not_a_phantom_position():
    broker, fake = _connected()
    fake.market_retcode = 10008  # PLACED for a market order
    with pytest.raises(SubmitUncertain):
        broker.submit(_order(), idempotency_key="placed-market")
    assert broker.positions() == ()
    assert fake.sent and fake.sent[-1]["type_filling"] in (0, 1, 2)


def test_limit_order_is_cancelled_instead_of_becoming_a_position():
    broker, fake = _connected(pending_fill_timeout_s=0.0)
    limit = replace(_order(), order_type="limit", limit_price=3879.5)
    ack = broker.submit(limit, idempotency_key="limit-1")
    assert ack.accepted is False
    assert ack.retcode == 10007
    assert fake.cancel_sends == 1
    assert broker.positions() == ()
    assert broker.pending_settlements == ()


def test_limit_order_that_fills_reconciles_into_a_position():
    broker, fake = _connected(pending_fill_timeout_s=0.0)
    fake.fill_on_place = True
    limit = replace(_order(volume=0.02), order_type="limit", limit_price=3879.5)
    ack = broker.submit(limit, idempotency_key="limit-2")
    assert ack.accepted is True
    assert ack.ticket is not None and float(ack.filled_volume) == pytest.approx(0.02)
    assert len(broker.positions()) == 1


def test_timeout_retcode_is_uncertain_on_submit_and_close():
    broker, fake = _connected()
    fake.market_retcode = 10012
    with pytest.raises(SubmitUncertain):
        broker.submit(_order(), idempotency_key="timeout-open")
    fake.market_retcode = 0
    ticket = _open(broker)
    fake.retcode_close = 10012
    with pytest.raises(SubmitUncertain):
        broker.close(Ticket(ticket), volume=None, idempotency_key="timeout-close", reason="kill")
    with pytest.raises(SubmitUncertain):
        broker.close(Ticket(ticket), volume=None, idempotency_key="timeout-close", reason="kill")
    assert fake.close_sends == 1


# ---------------------------------------------------------------------------
# POS-02 / MT5-05: engine flatten failure and terminal rejects
# ---------------------------------------------------------------------------
class _StubRisk:
    def __init__(self) -> None:
        self.realized: list[float] = []
        self.engaged: list[tuple[str, str]] = []

    def manage(self, ctx):
        return []

    def on_trade_closed(self, pnl: float, at) -> None:
        self.realized.append(pnl)

    def engage(self, level, reason, *, actor: str, auto_clear: bool = False) -> None:
        self.engaged.append((getattr(level, "value", str(level)), reason))

    def update_aux(self, **fields) -> None:
        pass

    def aux(self, key):
        return None


class _StubGates:
    def note_close(self, **fields) -> None:
        pass

    def snapshot(self):
        return None


class _StubHost:
    def __init__(self) -> None:
        self.paused = False

    def on_trade_closed(self, slot, trade) -> None:
        pass

    def pause_all(self) -> None:
        self.paused = True


def _engine_harness(info, clock, journal):
    fake = IdemMT5()
    broker, _ = _broker(fake, settlement_poll_s=0.0)
    broker.connect()
    positions = PositionManager(mode="hedging", contract_size=info.contract_size)
    coordinator = OrderCoordinator(
        broker=broker, journal=journal, clock=clock, positions=positions,
        secret="test-secret", run_id="idem",
    )
    order = _order(volume=0.02)
    ack = broker.submit(order, idempotency_key="engine-open")
    ticket = int(ack.ticket or 0)
    snapshot = [p for p in broker.positions() if int(p.ticket) == ticket][0]
    positions.apply_fill(
        Fill(
            ticket=Ticket(ticket),
            symbol=Symbol("XAUUSD"),
            side="buy",
            volume=float(snapshot.volume),
            price=float(snapshot.open_price),
            commission=money(0),
            ts=Ts(datetime.now(tz=timezone.utc)),
        ),
        slot="zones_m15",
        strategy="zones",
        risk_amount=11.0,
        initial_stop=ORDER_STOP,
    )
    engine = TradingEngine.__new__(TradingEngine)
    engine._positions = positions
    engine._symbol = Symbol("XAUUSD")
    engine._info = info
    engine._broker = broker
    engine._coordinator = coordinator
    engine._clock = clock
    engine._journal = journal
    engine._notifier = None
    engine._risk = _StubRisk()
    engine._gates = _StubGates()
    engine._host = _StubHost()
    engine.result = EngineResult()
    engine._pending_flatten = None
    engine._flatten_failures = 0
    engine._partials = {}
    engine._exec_meta = {}
    engine._config_hash = ""
    engine._last_gates_snapshot = None
    engine._flatten_attempts = 3
    return engine, broker, fake, positions, ticket


ORDER_STOP = 3877.69


def _event_types(journal):
    return [event.type for event in journal.read_events(limit=10_000)]


def test_weekend_flatten_uses_the_deterministic_close_order(info, clock, journal):
    """SES-05 / ADR-022: winner/loser order comes from weekend_close_plan."""

    def two_positions() -> tuple:
        engine, broker, fake, positions, first = _engine_harness(info, clock, journal)
        fake.fill_price = 3890.0
        second_order = replace(
            _order(volume=0.02),
            intent_id="zones_m15-000002-second",
            client_ref="gbm15-000002-abcdef",
        )
        ack = broker.submit(second_order, idempotency_key="engine-open-2")
        second = int(ack.ticket)
        snapshot = [p for p in broker.positions() if int(p.ticket) == second][0]
        positions.apply_fill(
            Fill(
                ticket=Ticket(second),
                symbol=Symbol("XAUUSD"),
                side="buy",
                volume=0.02,
                price=3890.0,
                commission=money(0),
                ts=Ts(datetime.now(tz=timezone.utc)),
            ),
            slot="zones_m15",
            strategy="zones",
            risk_amount=11.0,
            initial_stop=3887.0,
        )
        for row in fake.positions_list:
            row.profit = 7.0 if int(row.ticket) == first else -5.0
        calls: list[int] = []
        original = engine._coordinator.close_position

        def recording(intent):
            calls.append(int(intent.ticket))
            return original(intent)

        engine._coordinator.close_position = recording
        return engine, first, second, calls

    engine, first, second, calls = two_positions()
    engine._weekend = WeekendParams(close_order="profit_first")
    assert engine._flatten("weekend") is True
    assert calls == [first, second]  # winner (+7) closes before loser (-5)

    engine, first, second, calls = two_positions()
    engine._weekend = WeekendParams(close_order="loss_first")
    assert engine._flatten("weekend") is True
    assert calls == [second, first]  # deepest loser (-5) closes first


def _event_types(journal):
    return [event.type for event in journal.read_events(limit=10_000)]


def test_failed_flatten_latches_halted_and_never_claims_flat(info, clock, journal):
    engine, broker, fake, positions, ticket = _engine_harness(info, clock, journal)
    fake.retcode_close = 10017  # TRADE_DISABLED: the close cannot execute
    assert engine._flatten("kill") is False
    assert engine._pending_flatten == "kill"
    assert positions.count() == 1
    types = _event_types(journal)
    assert "FlattenFailed" in types
    assert "FlattenCompleted" not in types
    assert engine._risk.engaged and engine._risk.engaged[0][0] == "HALTED"
    assert engine._host.paused is True

    fake.retcode_close = 10009
    assert engine._flatten("kill") is True
    assert engine._pending_flatten is None
    assert positions.count() == 0
    assert "FlattenCompleted" in _event_types(journal)


def test_terminal_position_closed_reject_settles_instead_of_retrying(info, clock, journal):
    engine, broker, fake, positions, ticket = _engine_harness(info, clock, journal)
    pos = positions.get(ticket)
    fsm = PositionFSM(
        TPPlan(
            tp1=float(pos.open_price) + 1.0,
            tp2=float(pos.open_price) + 2.0,
            tp3=float(pos.open_price) + 3.0,
        ),
        float(pos.open_price),
        "buy",
        float(pos.volume),
        float(info.min_volume),
        float(pos.initial_stop or pos.open_price - 1.0),
        volume_step=float(info.volume_step),
    )
    positions.attach_fsm(ticket, fsm)
    action = fsm.request_close("tp3")
    assert action is not None
    # The venue already closed it and its deal is in history.
    fake.positions_list.clear()
    fake._add_deal(
        position=ticket, ticket=999, volume=-float(pos.volume), price=3880.0,
        profit=2.0, commission=-0.2, comment="tp",
    )
    price = float(fake.tick.bid)
    engine._advance_fsm(pos, action, {Symbol("XAUUSD"): (price, price + 0.7)}, None)
    assert positions.count() == 0
    assert fsm.closed
    assert "PositionClosed" in _event_types(journal)


def test_terminal_close_reject_on_a_live_position_abandons_and_latches(info, clock, journal):
    engine, broker, fake, positions, ticket = _engine_harness(info, clock, journal)
    pos = positions.get(ticket)
    fsm = PositionFSM(
        TPPlan(
            tp1=float(pos.open_price) + 1.0,
            tp2=float(pos.open_price) + 2.0,
            tp3=float(pos.open_price) + 3.0,
        ),
        float(pos.open_price),
        "buy",
        float(pos.volume),
        float(info.min_volume),
        float(pos.initial_stop or pos.open_price - 1.0),
        volume_step=float(info.volume_step),
    )
    positions.attach_fsm(ticket, fsm)
    action = fsm.request_close("tp3")
    assert action is not None
    fake.retcode_close = 10036  # POSITION_CLOSED, but the venue still shows it
    price = float(fake.tick.bid)
    engine._advance_fsm(pos, action, {Symbol("XAUUSD"): (price, price + 0.7)}, None)
    assert fsm.closed  # the plan is abandoned, not retried forever
    assert engine._risk.engaged and engine._risk.engaged[0][0] == "HALTED"
    assert "CloseAbandoned" in _event_types(journal)
    assert positions.count() == 1
