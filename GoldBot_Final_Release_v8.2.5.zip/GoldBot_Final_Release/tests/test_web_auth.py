"""Panel auth: optional bearer/basic token must fail closed when configured.

The panel is loopback-only by default; a remote deployment sets
GOLDBOT_PANEL_TOKEN so every route (health included) requires credentials.
These tests use TestClient and never touch the network.
"""

from __future__ import annotations

import base64

import pytest
from fastapi.testclient import TestClient

import goldbot.web.app as web

TOKEN = "test-panel-token-0123456789"
OTHER = "rotated-panel-token"


@pytest.fixture(autouse=True)
def _clean_env(monkeypatch):
    """Never inherit a token from the developer shell."""
    monkeypatch.delenv(web.PANEL_TOKEN_ENV, raising=False)
    return monkeypatch


@pytest.fixture
def client(_clean_env) -> TestClient:
    return TestClient(web.app)


def _basic(user: str, password: str) -> dict[str, str]:
    raw = base64.b64encode(f"{user}:{password}".encode("utf-8")).decode("ascii")
    return {"Authorization": f"Basic {raw}"}


def test_without_a_token_the_local_panel_stays_open(client) -> None:
    assert client.get("/").status_code == 200
    assert client.get("/api/status").status_code == 200
    assert client.get("/api/health").status_code in (200, 503)


def test_with_a_token_every_route_requires_credentials(client, _clean_env) -> None:
    _clean_env.setenv(web.PANEL_TOKEN_ENV, TOKEN)
    for path in ("/", "/api/status", "/api/health", "/api/zones", "/api/docs", "/does-not-exist"):
        response = client.get(path)
        assert response.status_code == 401, path
        assert response.json() == {"detail": "unauthorized"}, path
        assert response.headers["www-authenticate"].lower().startswith("basic"), path


def test_valid_bearer_token_is_accepted(client, _clean_env) -> None:
    _clean_env.setenv(web.PANEL_TOKEN_ENV, TOKEN)
    headers = {"Authorization": f"Bearer {TOKEN}"}
    assert client.get("/", headers=headers).status_code == 200
    assert client.get("/api/status", headers=headers).status_code == 200
    assert client.get("/api/health", headers=headers).status_code in (200, 503)


def test_bearer_scheme_is_case_insensitive(client, _clean_env) -> None:
    _clean_env.setenv(web.PANEL_TOKEN_ENV, TOKEN)
    assert client.get("/", headers={"Authorization": f"bearer {TOKEN}"}).status_code == 200


def test_wrong_or_empty_bearer_token_is_rejected(client, _clean_env) -> None:
    _clean_env.setenv(web.PANEL_TOKEN_ENV, TOKEN)
    assert client.get("/", headers={"Authorization": "Bearer wrong"}).status_code == 401
    assert client.get("/", headers={"Authorization": "Bearer "}).status_code == 401
    assert client.get("/", headers={"Authorization": "Bearer"}).status_code == 401


def test_basic_auth_with_any_username_and_the_token_works(client, _clean_env) -> None:
    _clean_env.setenv(web.PANEL_TOKEN_ENV, TOKEN)
    assert client.get("/", headers=_basic("operator", TOKEN)).status_code == 200
    assert client.get("/", headers=_basic("goldbot", TOKEN)).status_code == 200
    assert client.get("/api/status", headers=_basic("x", TOKEN)).status_code == 200


def test_basic_auth_with_the_wrong_password_is_rejected(client, _clean_env) -> None:
    _clean_env.setenv(web.PANEL_TOKEN_ENV, TOKEN)
    assert client.get("/", headers=_basic("operator", "wrong")).status_code == 401


def test_malformed_and_unknown_auth_schemes_do_not_crash(client, _clean_env) -> None:
    _clean_env.setenv(web.PANEL_TOKEN_ENV, TOKEN)
    for header in (
        {"Authorization": "Basic !!!not-base64!!!"},
        {"Authorization": "Basic "},
        {"Authorization": "Token abc"},
        {"Authorization": "Bearer"},
    ):
        response = client.get("/", headers=header)
        assert response.status_code == 401, header
        assert response.json() == {"detail": "unauthorized"}, header


def test_basic_auth_with_non_ascii_password_is_rejected_not_crashing(client, _clean_env) -> None:
    _clean_env.setenv(web.PANEL_TOKEN_ENV, TOKEN)
    raw = base64.b64encode("user:پسورد".encode("utf-8")).decode("ascii")
    response = client.get("/", headers={"Authorization": f"Basic {raw}"})
    assert response.status_code == 401


def test_whitespace_only_token_means_auth_disabled(client, _clean_env) -> None:
    _clean_env.setenv(web.PANEL_TOKEN_ENV, "   ")
    assert client.get("/").status_code == 200


def test_rotating_the_env_token_applies_without_a_restart(client, _clean_env) -> None:
    _clean_env.setenv(web.PANEL_TOKEN_ENV, TOKEN)
    assert client.get("/", headers={"Authorization": f"Bearer {TOKEN}"}).status_code == 200

    _clean_env.setenv(web.PANEL_TOKEN_ENV, OTHER)
    assert client.get("/", headers={"Authorization": f"Bearer {TOKEN}"}).status_code == 401
    assert client.get("/", headers={"Authorization": f"Bearer {OTHER}"}).status_code == 200


def test_authorization_helper_accepts_documented_forms(_clean_env) -> None:
    _clean_env.setenv(web.PANEL_TOKEN_ENV, TOKEN)
    assert web.panel_token() == TOKEN
    assert web._authorized(f"Bearer {TOKEN}") is True
    assert web._authorized(f"Basic {base64.b64encode(f'u:{TOKEN}'.encode()).decode()}") is True
    assert web._authorized(None) is False
    assert web._authorized("Bearer nope") is False
    assert web._authorized("Basic " + base64.b64encode(b"no-separator").decode()) is False

    _clean_env.delenv(web.PANEL_TOKEN_ENV, raising=False)
    assert web.panel_token() == ""
    assert web._authorized(None) is True
