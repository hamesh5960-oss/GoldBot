"""Three-layer TP FSM, atomic partial exits and FakeBroker failure injection."""

from __future__ import annotations

import pytest

from goldbot.adapters.fake_broker import FakeBroker
from goldbot.app.order_coordinator import OrderCoordinator
from goldbot.app.position_fsm import (
    FSMAction,
    PositionFSM,
    TPPlan,
    build_tp_plan,
)
from goldbot.app.position_manager import PositionManager
from goldbot.app.risk_engine import RiskEngine
from goldbot.domain.errors import InvariantError
from goldbot.domain.execution import ApprovedOrder, EntryIntent, ExitIntent, RiskSnapshot
from goldbot.domain.fsm.position import PositionPhase
from goldbot.domain.model import Fill, Symbol, Ticket, Ts
from goldbot.domain.money import money

from helpers import NOW, make_context, make_tick


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------
def buy_plan() -> TPPlan:
    return TPPlan(tp1=2010.0, tp2=2020.0, tp3=2030.0)


def sell_plan() -> TPPlan:
    return TPPlan(tp1=1990.0, tp2=1980.0, tp3=1970.0)


def make_fsm(
    *,
    plan: TPPlan | None = None,
    side: str = "buy",
    entry: float = 2000.0,
    stop: float = 1990.0,
    volume: float = 0.1,
    volume_min: float = 0.01,
    atr: float | None = None,
) -> PositionFSM:
    if plan is None:
        plan = buy_plan() if side == "buy" else sell_plan()
    return PositionFSM(
        plan,
        entry=entry,
        side=side,
        volume=volume,
        volume_min=volume_min,
        initial_stop=stop,
        atr=atr,
        volume_step=0.01,
    )


def _apply(fsm: PositionFSM, action: FSMAction | None) -> None:
    assert action is not None
    fsm.on_action_done(action)


def _walk_to_trailing(fsm: PositionFSM) -> None:
    """Drive the standard buy ladder until the plan is trailing."""
    first = fsm.on_price(fsm.plan.tp1)
    assert first is not None and first.kind == "PARTIAL"
    _apply(fsm, first)
    _apply(fsm, fsm.pending)
    second = fsm.on_price(fsm.plan.tp2)
    assert second is not None and second.kind == "PARTIAL"
    _apply(fsm, second)
    _apply(fsm, fsm.pending)


def manual_order(
    *, intent_id: str = "manual", volume: float = 0.2, sl: float = 1990.0, tp: float | None = None
) -> ApprovedOrder:
    return ApprovedOrder(
        intent_id=intent_id,
        slot="manual",
        strategy="fvg",
        symbol=Symbol("XAUUSD"),
        side="buy",
        volume=volume,
        order_type="market",
        sl=sl,
        tp=tp,
        magic=1,
        client_ref=intent_id,
        max_slippage_points=10,
        risk=RiskSnapshot(
            equity=10_000.0,
            balance=10_000.0,
            risk_pct=1.0,
            risk_amount=100.0,
            stop_distance=abs(2000.0 - sl),
            volume=volume,
            spread_points=20.0,
        ),
    )


# ---------------------------------------------------------------------------
# plan construction
# ---------------------------------------------------------------------------
def test_build_plan_uses_one_and_two_r_with_the_intent_target_as_tp3() -> None:
    plan = build_tp_plan(entry=2000.0, side="buy", stop=1990.0, target=2035.0)
    assert plan.tp1 == pytest.approx(2010.0)
    assert plan.tp2 == pytest.approx(2020.0)
    assert plan.tp3 == pytest.approx(2035.0)


def test_build_plan_mirrors_for_sells() -> None:
    plan = build_tp_plan(entry=2000.0, side="sell", stop=2010.0, target=1965.0)
    assert plan.tp1 == pytest.approx(1990.0)
    assert plan.tp2 == pytest.approx(1980.0)
    assert plan.tp3 == pytest.approx(1965.0)


def test_build_plan_ladders_a_target_closer_than_two_r() -> None:
    plan = build_tp_plan(entry=2000.0, side="buy", stop=1990.0, target=2015.0)
    assert plan.tp1 == pytest.approx(2010.0)
    assert plan.tp2 == pytest.approx(2011.25)  # 0.75 * 1.5R distance
    assert plan.tp3 == pytest.approx(2015.0)


def test_build_plan_uses_three_r_when_there_is_no_target() -> None:
    plan = build_tp_plan(entry=2000.0, side="buy", stop=1990.0, target=None)
    assert plan.tp1 == pytest.approx(2010.0)
    assert plan.tp2 == pytest.approx(2020.0)
    assert plan.tp3 == pytest.approx(2030.0)


# ---------------------------------------------------------------------------
# phase progression and 50/30/20 volumes
# ---------------------------------------------------------------------------
def test_phases_advance_open_partial1_partial2_trailing_closed() -> None:
    fsm = make_fsm()
    assert fsm.phase is PositionPhase.OPEN
    assert fsm.on_price(2009.0) is None

    part1 = fsm.on_price(2010.0)
    assert part1 is not None and part1.kind == "PARTIAL"
    fsm.on_action_done(part1)
    assert fsm.phase is PositionPhase.PARTIAL_1

    sl_be = fsm.pending
    fsm.on_action_done(sl_be)
    assert fsm.phase is PositionPhase.PARTIAL_1

    part2 = fsm.on_price(2020.0)
    fsm.on_action_done(part2)
    assert fsm.phase is PositionPhase.PARTIAL_2

    sl_tp1 = fsm.pending
    fsm.on_action_done(sl_tp1)
    assert fsm.phase is PositionPhase.TRAILING

    close = fsm.on_price(2030.0)
    assert close is not None and close.kind == "CLOSE"
    fsm.on_action_done(close)
    assert fsm.phase is PositionPhase.CLOSED
    assert fsm.realized_fraction == pytest.approx(1.0)


def test_partials_are_fifty_thirty_twenty() -> None:
    fsm = make_fsm(volume=0.2)
    volumes: list[float] = []
    action = fsm.on_price(fsm.plan.tp1)
    volumes.append(action.volume)
    _apply(fsm, action)
    _apply(fsm, fsm.pending)
    action = fsm.on_price(fsm.plan.tp2)
    volumes.append(action.volume)
    _apply(fsm, action)
    _apply(fsm, fsm.pending)
    action = fsm.on_price(fsm.plan.tp3)
    volumes.append(action.volume)
    assert volumes == [pytest.approx(v) for v in (0.1, 0.06, 0.04)]
    assert sum(volumes) == pytest.approx(0.2)


def test_pending_action_is_repeated_verbatim_until_acknowledged() -> None:
    fsm = make_fsm()
    first = fsm.on_price(2010.0)
    assert fsm.on_price(2010.0) is first
    assert fsm.on_price(2019.0) is first
    fsm.on_action_done(first)
    waiting = fsm.on_price(2010.0)
    assert waiting is not None and waiting.kind == "MODIFY_SL"


def test_sl_moves_to_break_even_after_tp1_and_to_tp1_after_tp2() -> None:
    fsm = make_fsm()
    _apply(fsm, fsm.on_price(2010.0))
    sl_be = fsm.pending
    assert sl_be is not None and sl_be.kind == "MODIFY_SL"
    assert sl_be.sl == pytest.approx(2000.0)
    fsm.on_action_done(sl_be)
    assert fsm.current_sl == pytest.approx(2000.0)

    _apply(fsm, fsm.on_price(2020.0))
    sl_tp1 = fsm.pending
    assert sl_tp1 is not None and sl_tp1.kind == "MODIFY_SL"
    assert sl_tp1.sl == pytest.approx(2010.0)
    fsm.on_action_done(sl_tp1)
    assert fsm.current_sl == pytest.approx(2010.0)


def test_sl_never_widens_while_trailing() -> None:
    fsm = make_fsm(atr=4.0)
    _walk_to_trailing(fsm)
    assert fsm.current_sl == pytest.approx(2010.0)

    trail = fsm.on_price(2028.0, 4.0)
    assert trail is not None and trail.kind == "MODIFY_SL"
    assert trail.sl == pytest.approx(2022.0)
    fsm.on_action_done(trail)
    assert fsm.current_sl == pytest.approx(2022.0)

    # Price slips back: the candidate stop is worse, so no action is emitted.
    assert fsm.on_price(2026.0, 4.0) is None
    assert fsm.current_sl == pytest.approx(2022.0)

    better = fsm.on_price(2029.0, 4.0)
    assert better is not None and better.sl == pytest.approx(2023.0)
    fsm.on_action_done(better)
    assert fsm.current_sl == pytest.approx(2023.0)


def test_volume_below_two_minimums_uses_a_single_target_path() -> None:
    fsm = make_fsm(volume=0.01, volume_min=0.01)
    assert fsm.single_target_path
    be = fsm.on_price(2010.0)
    assert be is not None and be.kind == "MODIFY_SL"
    assert be.sl == pytest.approx(2000.0)
    fsm.on_action_done(be)
    assert fsm.phase is PositionPhase.TRAILING
    close = fsm.on_price(2030.0)
    assert close is not None and close.kind == "CLOSE"
    assert close.volume == pytest.approx(0.01)
    fsm.on_action_done(close)
    assert fsm.closed


def test_exactly_two_minimums_can_still_split() -> None:
    fsm = make_fsm(volume=0.02, volume_min=0.01)
    assert not fsm.single_target_path
    first = fsm.on_price(2010.0)
    assert first is not None and first.kind == "PARTIAL"
    assert first.volume == pytest.approx(0.01)


# ---------------------------------------------------------------------------
# idempotent retries and flattening
# ---------------------------------------------------------------------------
def test_retry_keeps_the_same_pending_sl_until_it_succeeds() -> None:
    fsm = make_fsm()
    _apply(fsm, fsm.on_price(2010.0))
    sl_be = fsm.pending
    assert sl_be is not None

    fsm.on_action_failed("modify_failed")
    assert fsm.pending is sl_be
    assert fsm.on_price(2010.0) is sl_be

    fsm.on_action_done(sl_be)
    assert fsm.current_sl == pytest.approx(2000.0)
    assert fsm.last_failure == "modify_failed"


def test_retry_exhaustion_queues_a_full_close() -> None:
    fsm = make_fsm()
    _apply(fsm, fsm.on_price(2010.0))
    assert fsm.pending is not None and fsm.pending.kind == "MODIFY_SL"
    for _ in range(fsm.retry_limit):
        fsm.on_action_failed("modify_failed")
    flat = fsm.pending
    assert flat is not None and flat.kind == "CLOSE"
    assert flat.reason == "retry_exhausted"
    assert flat.volume == pytest.approx(0.05)
    assert fsm.on_price(2010.0) is flat
    fsm.on_action_done(flat)
    assert fsm.closed


def test_over_close_is_rejected() -> None:
    fsm = make_fsm()
    first = fsm.on_price(2010.0)
    assert first is not None
    with pytest.raises(InvariantError, match="over-close"):
        fsm.on_action_done(first, filled_volume=1.0)


# ---------------------------------------------------------------------------
# sell-side mirror
# ---------------------------------------------------------------------------
def test_sell_side_mirrors_the_buy_ladder() -> None:
    fsm = make_fsm(side="sell", stop=2010.0)
    assert fsm.phase is PositionPhase.OPEN
    part1 = fsm.on_price(1990.0)
    assert part1 is not None and part1.kind == "PARTIAL"
    assert part1.volume == pytest.approx(0.05)
    fsm.on_action_done(part1)
    sl_be = fsm.pending
    assert sl_be is not None and sl_be.sl == pytest.approx(2000.0)
    fsm.on_action_done(sl_be)

    part2 = fsm.on_price(1980.0)
    assert part2 is not None and part2.volume == pytest.approx(0.03)
    fsm.on_action_done(part2)
    sl_tp1 = fsm.pending
    assert sl_tp1 is not None and sl_tp1.sl == pytest.approx(1990.0)
    fsm.on_action_done(sl_tp1)
    assert fsm.phase is PositionPhase.TRAILING

    # Falling price tightens a sell stop; a bounce must never widen it.
    trail = fsm.on_price(1975.0, 4.0)
    assert trail is not None and trail.sl == pytest.approx(1981.0)
    fsm.on_action_done(trail)
    assert fsm.current_sl == pytest.approx(1981.0)
    assert fsm.on_price(1978.0, 4.0) is None
    assert fsm.current_sl == pytest.approx(1981.0)

    close = fsm.on_price(1970.0)
    assert close is not None and close.kind == "CLOSE"
    fsm.on_action_done(close)
    assert fsm.closed


# ---------------------------------------------------------------------------
# position book
# ---------------------------------------------------------------------------
def test_position_book_polls_armed_fsm(positions) -> None:
    positions.apply_fill(
        Fill(Ticket(7), Symbol("XAUUSD"), "buy", 0.1, 2000.0, money(0), Ts(NOW)),
        slot="s",
        strategy="fvg",
        initial_stop=1990.0,
    )
    fsm = make_fsm()
    positions.attach_fsm(7, fsm)
    assert positions.fsm_actions({Symbol("XAUUSD"): (2009.0, 2009.2)}) == []
    actions = positions.fsm_actions({Symbol("XAUUSD"): (2010.0, 2010.2)})
    assert len(actions) == 1
    pos, action = actions[0]
    assert pos.ticket == 7 and action.kind == "PARTIAL"
    assert positions.fsm_actions({Symbol("XAUUSD"): (2010.0, 2010.2)})[0][1] is action


def test_netting_mode_refuses_the_partial_tp_machine() -> None:
    pm = PositionManager(mode="netting", contract_size=100.0)
    pm.apply_fill(
        Fill(Ticket(1), Symbol("XAUUSD"), "buy", 0.1, 2000.0, money(0), Ts(NOW)), slot="s"
    )
    with pytest.raises(InvariantError, match="netting"):
        pm.attach_fsm(1, make_fsm())
    assert pm.fsm_actions({Symbol("XAUUSD"): (2010.0, 2010.2)}) == []
    assert pm.get_by_symbol(Symbol("XAUUSD")) is not None


# ---------------------------------------------------------------------------
# FakeBroker + coordinator: atomic partial close, failure injection
# ---------------------------------------------------------------------------
def _approved(engine: RiskEngine, info) -> ApprovedOrder:
    intent = EntryIntent(
        intent_id="i-fsm",
        slot="fvg_m15",
        strategy="fvg",
        symbol=Symbol("XAUUSD"),
        side="buy",
        entry_ref=2000.2,
        stop=1990.0,
        target=2020.4,
        risk_multiplier=1.0,
        signal={"rationale": "fsm"},
        created_at=NOW,
    )
    decision = engine.evaluate_entry(intent, make_context(info))
    assert decision.order is not None
    return decision.order


def _coordinator(broker, journal, clock, positions, secret) -> OrderCoordinator:
    return OrderCoordinator(
        broker=broker,
        journal=journal,
        clock=clock,
        positions=positions,
        secret=secret,
        run_id="fsm",
    )


@pytest.fixture
def risk(profile, journal, clock) -> RiskEngine:
    engine = RiskEngine(profile, journal=journal, clock=clock)
    engine.begin(10_000.0, NOW)
    return engine


def _open_position(risk, broker, journal, clock, positions, info):
    broker.on_market_tick(make_tick(price=2000.0))
    coordinator = _coordinator(broker, journal, clock, positions, risk.secret())
    result = coordinator.execute(_approved(risk, info))
    assert result.status == "acked" and result.ack is not None
    ticket = int(result.ack.ticket)
    return coordinator, ticket, positions.get(ticket)


def test_fake_broker_partial_close_keeps_remainder_and_pnl(info) -> None:
    broker = FakeBroker(info, balance=10_000.0)
    broker.on_market_tick(make_tick(price=2000.0))
    ack = broker.submit(manual_order(intent_id="manual-1", volume=0.2, tp=2020.0), idempotency_key="open-1")
    assert ack.accepted and ack.ticket is not None
    ticket = int(ack.ticket)
    entry = float(ack.fill_price or 0.0)

    broker.on_market_tick(make_tick(price=entry + 10.0, at=NOW.replace(minute=1)))
    ack_close = broker.close(ticket, volume=0.1, idempotency_key="close-1", reason="tp")
    assert ack_close.accepted
    trade = ack_close.closed_trade
    assert trade is not None
    assert trade.volume == pytest.approx(0.1)
    expected_gross = (trade.close_price - trade.open_price) * info.contract_size * 0.1
    assert float(trade.pnl_gross.amount) == pytest.approx(expected_gross)
    assert float(trade.pnl_net.amount) < float(trade.pnl_gross.amount)
    assert len(broker.positions()) == 1
    assert broker.positions()[0].volume == pytest.approx(0.1)
    assert int(broker.positions()[0].ticket) == ticket


def test_partial_close_then_modify_failure_retries_to_success(
    risk, broker, journal, clock, positions, info
) -> None:
    coordinator, ticket, pos = _open_position(risk, broker, journal, clock, positions, info)
    entry = pos.open_price
    broker.on_market_tick(make_tick(price=entry + 10.0, at=NOW.replace(minute=1)))

    plan = TPPlan(tp1=entry + 1.0, tp2=entry + 2.0, tp3=entry + 20.0)
    fsm = PositionFSM(
        plan,
        entry=entry,
        side="buy",
        volume=pos.volume,
        volume_min=info.min_volume,
        initial_stop=pos.initial_stop,
        volume_step=info.volume_step,
    )
    positions.attach_fsm(ticket, fsm)

    tick = broker._last_tick
    action = fsm.on_price(tick.bid)
    assert action is not None and action.kind == "PARTIAL"

    broker.fail_next_modify = 1
    result = coordinator.close_position(
        ExitIntent(
            "fsm-retry-1",
            "fvg_m15",
            ticket,
            Symbol("XAUUSD"),
            "tp1",
            fraction=action.volume / pos.volume,
        )
    )
    assert result.status == "acked"
    assert result.ack is not None and result.ack.closed_trade is not None
    filled = result.ack.closed_trade
    fsm.on_action_done(action, filled_volume=filled.volume)
    positions.apply_close(filled)
    assert filled.volume == pytest.approx(0.04)
    assert positions.get(ticket).volume == pytest.approx(0.05)

    sl_be = fsm.pending
    assert sl_be is not None and sl_be.kind == "MODIFY_SL"
    assert coordinator.modify(ticket, sl=sl_be.sl) is False  # injected failure
    fsm.on_action_failed("modify_failed")
    assert fsm.pending is sl_be
    assert coordinator.modify(ticket, sl=sl_be.sl) is True  # retry succeeds
    fsm.on_action_done(sl_be)
    assert fsm.current_sl == pytest.approx(round(entry, 2))
    venue = [p for p in broker.positions() if int(p.ticket) == ticket]
    assert len(venue) == 1
    assert venue[0].sl == pytest.approx(round(entry, 2))
    assert venue[0].volume == pytest.approx(0.05)


class _StubRisk:
    def __init__(self) -> None:
        self.realized: list[float] = []

    def manage(self, ctx):
        return []

    def on_trade_closed(self, pnl: float, at) -> None:
        self.realized.append(pnl)


class _StubGates:
    def note_close(self, **fields) -> None:
        pass


class _StubHost:
    def on_trade_closed(self, slot, trade) -> None:
        pass


class _StubNotifier:
    def __init__(self) -> None:
        self.sent: list[tuple[str, str]] = []

    def send(self, level, title, body, *, dedup_key="") -> bool:
        self.sent.append((level, title))
        return True


def test_engine_disables_the_fsm_in_netting_mode_with_one_notification(
    broker, journal, clock, info
) -> None:
    from goldbot.app.engine import EngineResult, TradingEngine

    netting = PositionManager(mode="netting", contract_size=info.contract_size)
    notifier = _StubNotifier()
    engine = TradingEngine.__new__(TradingEngine)
    engine._positions = netting
    engine._symbol = Symbol("XAUUSD")
    engine._journal = None
    engine._notifier = notifier
    engine._fsm_netting_notified = False
    engine.result = EngineResult()

    engine._arm_position_fsm(1, manual_order(intent_id="net", volume=0.1), None)
    engine._arm_position_fsm(2, manual_order(intent_id="net-2", volume=0.1), None)
    assert [level for level, _ in notifier.sent] == ["warn"]
    assert netting.fsm_actions({Symbol("XAUUSD"): (2000.0, 2000.2)}) == []


def test_engine_management_runs_the_three_layer_plan(
    risk, broker, journal, clock, positions, info
) -> None:
    from goldbot.app.engine import EngineResult, TradingEngine

    coordinator, ticket, pos = _open_position(risk, broker, journal, clock, positions, info)
    entry = pos.open_price
    plan = TPPlan(tp1=entry + 1.0, tp2=entry + 2.0, tp3=entry + 3.0)
    fsm = PositionFSM(
        plan,
        entry=entry,
        side="buy",
        volume=pos.volume,
        volume_min=info.min_volume,
        initial_stop=pos.initial_stop,
        volume_step=info.volume_step,
    )
    positions.attach_fsm(ticket, fsm)

    engine = TradingEngine.__new__(TradingEngine)
    engine._positions = positions
    engine._symbol = Symbol("XAUUSD")
    engine._coordinator = coordinator
    engine._clock = clock
    engine._journal = None
    engine._notifier = None
    engine._fsm_netting_notified = False
    engine._risk = _StubRisk()
    engine._gates = _StubGates()
    engine._host = _StubHost()
    engine.result = EngineResult()

    def bar(price: float, minute: int) -> None:
        broker.on_market_tick(make_tick(price=price, at=NOW.replace(minute=minute)))
        engine._apply_management(make_context(info, tick=broker._last_tick, atr=4.0))

    bar(entry + 0.5, 1)
    assert positions.get(ticket).volume == pytest.approx(0.09)

    bar(entry + 1.5, 2)  # TP1 + break-even
    assert positions.get(ticket).volume == pytest.approx(0.05)
    assert engine.result.trades_closed == 0  # a partial is not a closed trade
    venue = [p for p in broker.positions() if int(p.ticket) == ticket][0]
    assert venue.sl == pytest.approx(round(entry, 2))

    bar(entry + 2.5, 3)  # TP2 + stop to TP1
    assert positions.get(ticket).volume == pytest.approx(0.03)
    venue = [p for p in broker.positions() if int(p.ticket) == ticket][0]
    assert venue.sl == pytest.approx(round(entry + 1.0, 2))

    bar(entry + 3.5, 4)  # TP3 closes the remainder
    assert positions.get(ticket) is None
    assert broker.positions() == []
    assert engine.result.trades_closed == 1
    assert len(engine._risk.realized) == 3


def test_scenario_partial_then_sl_fail_is_deterministic(info) -> None:
    broker = FakeBroker(info, balance=10_000.0, scenario="partial_then_sl_fail")
    broker.on_market_tick(make_tick(price=2000.0))
    ack = broker.submit(manual_order(intent_id="manual-2", volume=0.2, tp=2030.0), idempotency_key="open-2")
    ticket = int(ack.ticket or 0)
    entry = float(ack.fill_price or 0.0)
    broker.on_market_tick(make_tick(price=entry + 10.0, at=NOW.replace(minute=2)))

    first = broker.close(ticket, volume=0.1, idempotency_key="sc-close-1", reason="tp1")
    assert first.accepted and first.closed_trade is not None
    assert broker.fail_next_modify == 1  # armed by the scenario
    blocked = broker.modify(Ticket(ticket), sl=entry, tp=None, idempotency_key="sc-mod-1")
    assert not blocked.accepted
    retried = broker.modify(Ticket(ticket), sl=entry, tp=None, idempotency_key="sc-mod-1b")
    assert retried.accepted
    remaining = [p for p in broker.positions() if int(p.ticket) == ticket]
    assert len(remaining) == 1
    assert remaining[0].sl == pytest.approx(round(entry, 2))


def test_fake_broker_injected_close_failure_leaves_position_untouched(info) -> None:
    broker = FakeBroker(info, balance=10_000.0, fail_next_close=1)
    broker.on_market_tick(make_tick(price=2000.0))
    ack = broker.submit(manual_order(intent_id="manual-3", volume=0.1), idempotency_key="open-3")
    ticket = int(ack.ticket or 0)
    blocked = broker.close(ticket, volume=None, idempotency_key="c-3", reason="manual")
    assert not blocked.accepted
    assert len(broker.positions()) == 1
    ok = broker.close(ticket, volume=None, idempotency_key="c-3b", reason="manual")
    assert ok.accepted and ok.closed_trade is not None
    assert broker.positions() == []


def test_close_idempotency_returns_the_same_ack(info) -> None:
    broker = FakeBroker(info, balance=10_000.0)
    broker.on_market_tick(make_tick(price=2000.0))
    ack = broker.submit(manual_order(intent_id="manual-4", volume=0.1), idempotency_key="open-4")
    ticket = int(ack.ticket or 0)
    first = broker.close(ticket, volume=0.05, idempotency_key="same-close", reason="tp1")
    second = broker.close(ticket, volume=0.05, idempotency_key="same-close", reason="tp1")
    assert first.closed_trade is not None and first.closed_trade is second.closed_trade
    assert len(broker.positions()) == 1
    assert broker.positions()[0].volume == pytest.approx(0.05)
