"""Engine integration: signal journal, weekend audit and health wiring."""

from __future__ import annotations

import os
import shutil
from datetime import datetime, timezone
from pathlib import Path

import pytest

from goldbot.adapters.config import load_settings
from goldbot.adapters.tape import write_synthetic_tape
from goldbot.app.health import snapshot
from goldbot.runtime.bootstrap import build_components

from helpers import CONFIG, ROOT


def _work(name: str) -> Path:
    path = ROOT / "var" / "tests" / name
    if path.exists():
        shutil.rmtree(path, ignore_errors=True)
    path.mkdir(parents=True, exist_ok=True)
    return path


@pytest.fixture(scope="module")
def run():
    previous = os.getcwd()
    os.chdir(ROOT)
    tmp = _work("engine-signals")
    tape = tmp / "tape.jsonl"
    write_synthetic_tape(
        tape,
        symbol="XAUUSD",
        start=datetime(2024, 3, 3, tzinfo=timezone.utc),
        days=8,
        ticks_per_minute=1,
        seed=13,
    )
    settings = load_settings(CONFIG / "base.toml")
    settings = settings.model_copy(
        update={"trading": settings.trading.model_copy(update={"min_confirmations": 1})}
    )
    components = build_components(
        settings, tape_path=tape, profile_name="medium", db_path=tmp / "journal.db"
    )
    result = components.engine.run()
    signals = list(components.journal.signals())
    levels = list(components.journal.signal_levels())
    events = list(components.journal.read_events(limit=200_000))
    health = snapshot(
        risk=components.risk,
        journal=components.journal,
        heartbeat_path=components.heartbeat._path,
        now=components.clock.now().wall,
    )
    stats = dict(components.journal.stats())
    components.close()
    os.chdir(previous)
    return result, signals, levels, events, health, stats


def test_signals_are_journaled(run) -> None:
    result, signals, levels, _, _, _ = run
    assert result.intents > 0
    assert signals, "every evaluated intent must be journaled"
    assert len(levels) == 4 * len(signals)
    assert {s.signal_id for s in signals} == {s.signal_id for s in levels}
    assert all(s.session for s in signals)
    assert all(s.active_decision for s in signals)
    assert all(s.params_snapshot.get("config_hash") for s in signals)


def test_capability_rows_cover_four_levels(run) -> None:
    _, _, levels, _, _, _ = run
    by_signal: dict[str, set[str]] = {}
    for row in levels:
        by_signal.setdefault(row.signal_id, set()).add(row.level)
    assert by_signal
    assert all(levels_set == {"base", "low_risk", "medium_risk", "high_risk"} for levels_set in by_signal.values())


def test_executed_signals_have_outcome_and_lot(run) -> None:
    _, signals, _, _, _, _ = run
    executed = [s for s in signals if s.active_decision == "executed"]
    if not executed:
        pytest.skip("the fixed tape produced no executed signal")
    assert all(s.active_lot and s.active_lot > 0 for s in executed)
    assert all(s.active_level for s in executed)


def test_weekend_close_plan_is_audited(run) -> None:
    _, _, _, events, _, _ = run
    plans = [e for e in events if e.type == "WeekendClosePlan"]
    assert plans, "the Friday close window must be journaled"
    assert any(bool(dict(e.payload).get("flatten")) for e in plans)
    assert any(e.type == "FlattenCompleted" for e in events)


def test_health_snapshot_is_wired(run) -> None:
    _, _, _, _, health, stats = run
    assert health.journal_events > 0
    assert health.heartbeat_age_seconds is not None
    assert health.heartbeat_stale is False
    assert health.ok is True
    assert stats["signals_total"] == stats.get("signals_total", 0)
