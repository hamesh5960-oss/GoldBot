"""Numeric strategy tests (unchanged logic, kept from the previous suite)."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone

from goldbot.strategy_api import Bar
from strategies.numeric import NumericParams, NumericStrategy, base_from_price

from helpers import FakeCtx

START = datetime(2024, 3, 4, tzinfo=timezone.utc)


def bar(i: int, o: float, h: float, l: float, c: float, tf: str = "M15") -> Bar:
    return Bar(
        symbol="XAUUSD",  # type: ignore[arg-type]
        timeframe=tf,  # type: ignore[arg-type]
        open_time=START + timedelta(minutes=15 * i),
        o=o,
        h=h,
        l=l,
        c=c,
    )


def test_base_number_mapping_from_document_example() -> None:
    # 4136.87 -> digits 36 -> 3+6 = 9 -> third set -> 18
    assert base_from_price(4136.87) == 18
    # 4137 -> 37 -> 10 -> first set -> 12
    assert base_from_price(4137.0) == 12
    # 4138 -> 38 -> 11 -> second set -> 15
    assert base_from_price(4138.0) == 15


def numeric_bars() -> list[Bar]:
    """Swing low at 4052.5, a long rally, then a fall through the first level."""
    bars: list[Bar] = []
    price = 4060.0
    for i in range(15):
        price -= 0.5
        bars.append(bar(i, price + 0.4, price + 0.5, price - 0.5, price))
    for i in range(15, 45):
        price += 5.6
        bars.append(bar(i, price - 0.6, price + 0.6, price - 0.7, price))
    for i in range(45, 90):
        price -= 2.0
        bars.append(bar(i, price + 2.0, price + 2.5, price - 2.5, price))
    return bars


def test_numeric_enters_long_at_first_multiple() -> None:
    bars = numeric_bars()
    strategy = NumericStrategy(params=NumericParams(swing_span=2, lookback=120))
    ctx = FakeCtx(_bars=bars)

    signals = []
    for i in range(44, len(bars)):
        ctx._bars = bars[: i + 1]
        signals.extend(strategy.on_bar(ctx, bars[i]))

    assert strategy._anchor_high is not None
    assert signals, "expected an entry at anchor - base"
    signal = signals[0]
    assert signal.side == "buy"
    assert "numeric_level" in signal.tags["pattern"]
    assert signal.tags["base"] in (12, 15, 18)
    # Exit geometry is the S/R geometry: structure stop + liquidity target.
    assert signal.tags["sl_mode"] == "structure"
    assert signal.tags["rr"] >= 2.0
    risk = signal.entry_hint - signal.stop
    reward = signal.target - signal.entry_hint
    assert reward >= 2.0 * risk - 1e-6


def test_numeric_advances_level_after_stop() -> None:
    strategy = NumericStrategy(params=NumericParams(max_level=3))
    strategy._side = "long"
    strategy._level = 1

    class Trade:
        side = "buy"
        reason = "sl"
        entry_price = 4100.0
        ticket = 1

    strategy.on_close(FakeCtx(), Trade())
    assert strategy._level == 2
    assert strategy._reversal_side == "short"


def test_numeric_level_caps_at_max() -> None:
    strategy = NumericStrategy(params=NumericParams(max_level=2))
    strategy._side = "long"
    strategy._level = 2

    class Trade:
        side = "buy"
        reason = "sl"
        entry_price = 4100.0
        ticket = 1

    strategy.on_close(FakeCtx(), Trade())
    assert strategy._level == 2
