"""Restart adoption (ADR-013 P0): venue positions must become managed.

Cold restart with an open MT5 position used to force QUARANTINE while leaving
the real exposure without trailing/time/TP management. These tests prove the
engine now adopts each orphan into PositionManager, journals it, keeps broker
SL/TP, blocks duplicate adoption, and fails closed when truth is unreadable.
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from pathlib import Path
from types import SimpleNamespace

import pytest

from goldbot.adapters.clock import SystemClock
from goldbot.adapters.config import load_settings
from goldbot.adapters.mt5_broker import (
    MT5Broker,
    load_history,
    seed_builder,
    symbol_info_from_broker,
)
from goldbot.adapters.sqlite_store import SqliteJournal
from goldbot.domain.model import Symbol, Tick, Ts
from goldbot.ports.risk import RiskState
from goldbot.runtime.bootstrap import build_components

from test_mt5_broker import FakeMT5

ROOT = Path(__file__).resolve().parents[1]
OWNED_MAGIC = 13_000_123  # (7300 % 2000) * 10_000 + slot bucket
FOREIGN_MAGIC = 999


def _bars(fake: FakeMT5, now: datetime, count: int = 400) -> list[dict]:
    start = int(now.timestamp()) // 900 * 900 - count * 900
    rows = []
    price = 3800.0
    for index in range(count):
        price += 0.5
        rows.append(
            {
                "time": start + index * 900,
                "open": price,
                "high": price + 2.0,
                "low": price - 2.0,
                "close": price + 0.5,
                "tick_volume": 10,
                "spread": 5,
            }
        )
    return rows


class FiniteFeed:
    def __init__(self, symbol: str, ticks: list[Tick]) -> None:
        self._symbol = symbol
        self._ticks = ticks

    def stop(self) -> None:
        pass

    def stream(self):
        yield from self._ticks


def _position_row(fake: FakeMT5, *, magic: int = OWNED_MAGIC, age_hours: float = 1.0) -> SimpleNamespace:
    return SimpleNamespace(
        ticket=555001,
        symbol="XAUUSD.st",
        type=0,  # buy
        volume=0.02,
        price_open=3800.0,
        sl=3780.0,
        tp=3860.0,
        magic=magic,
        comment="adopt-me",
        time=int((datetime.now(tz=timezone.utc) - timedelta(hours=age_hours)).timestamp()),
        profit=0.0,
        swap=0.0,
    )


def _build(scratch: Path, *, magic: int = OWNED_MAGIC):
    settings = load_settings(ROOT / "config/base.toml")
    now = datetime.now(tz=timezone.utc)
    fake = FakeMT5()
    fake.tick.time = int((now + timedelta(hours=2)).timestamp())
    info = symbol_info_from_broker(
        fake,
        broker_symbol="XAUUSD.st",
        logical_name="XAUUSD",
        broker_offset=timedelta(hours=2),
        fallback=settings.symbol_info(),
    )
    fake.rates[15] = _bars(fake, now)
    fake.positions_list.append(_position_row(fake, magic=magic))
    broker = MT5Broker(
        info,
        login=80180927,
        password="secret",
        server="ePlanet-MT5",
        mt5_module=fake,
    )
    broker.connect()
    clock = SystemClock(info)
    mid = float(fake.tick.bid)
    ticks = [
        Tick(
            symbol=Symbol("XAUUSD"),
            bid=mid,
            ask=mid + 0.7,
            ts_event=Ts(now + timedelta(seconds=index)),
            ts_recv=Ts(now + timedelta(seconds=index)),
            volume=2,
        )
        for index in range(3)
    ]

    def seed(builder) -> None:
        load = load_history(
            fake,
            broker_symbol=info.broker_symbol,
            info=info,
            timeframes=["M15"],
            offset=timedelta(hours=2),
            counts={"M15": 500},
        )
        assert seed_builder(builder, load) > 0

    components = build_components(
        settings,
        tape_path="",
        profile_name="medium",
        db_path=scratch / "live.db",
        state_db=scratch / "state.db",
        allow_cold_start=True,
        live_broker=broker,
        live_feed=FiniteFeed("XAUUSD", ticks),
        live_clock=clock,
        seed_history=seed,
        info_override=info,
    )
    return components, broker, fake


def _adoption_events(components) -> list:
    return [
        event
        for event in components.journal.read_events(limit=1000)
        if event.type == "PositionAdopted"
    ]


def test_orphan_position_is_adopted_journaled_and_managed(scratch) -> None:
    components, broker, fake = _build(scratch)
    try:
        components.engine.start()

        assert components.positions.count() == 1
        adopted = components.positions.raw()[0]
        assert adopted.ticket == 555001
        assert adopted.slot == "adopted"
        assert adopted.strategy == "adopted"
        # Broker SL/TP are copied verbatim; adoption never rewrites them.
        assert adopted.sl == pytest.approx(3780.0)
        assert adopted.tp == pytest.approx(3860.0)
        assert adopted.fsm is not None, "adopted exposure must have a protective policy"

        events = _adoption_events(components)
        assert len(events) == 1
        payload = events[0].payload
        assert payload["ticket"] == 555001
        assert payload["slot"] == "adopted"
        assert payload["magic"] == OWNED_MAGIC
        assert payload["magic_owned"] is True
        assert payload["sl"] == pytest.approx(3780.0)

        # Reconciliation is clean only after adoption; no order was needed.
        assert components.reconciler.run().clean is True
        assert components.risk.state() is RiskState.NORMAL
        assert fake.sent == []

        # Kill flatten (the generic path) acts on the adopted ticket.
        components.engine._flatten("kill")
        assert components.positions.count() == 0
        assert fake.positions_list == []
        assert [row for row in fake.sent], "the flatten must reach the venue"
    finally:
        components.close()


def test_repeated_reconcile_adopts_once(scratch) -> None:
    components, _broker, _fake = _build(scratch)
    try:
        components.engine.start()
        assert components.positions.count() == 1
        components.reconciler.run()
        components.reconciler.adopt_orphans(max_holding_hours=48.0)
        components.reconciler.run()
        assert components.positions.count() == 1, "repeated adoption must be idempotent"
        assert len(_adoption_events(components)) == 1
    finally:
        components.close()


def test_foreign_magic_is_adopted_by_default_and_flagged(scratch) -> None:
    components, _broker, _fake = _build(scratch, magic=FOREIGN_MAGIC)
    try:
        components.engine.start()
        assert components.positions.count() == 1
        events = _adoption_events(components)
        assert len(events) == 1
        assert events[0].payload["magic"] == FOREIGN_MAGIC
        assert events[0].payload["magic_owned"] is False
    finally:
        components.close()


def test_unreadable_broker_snapshot_quarantines_without_adoption(scratch) -> None:
    components, broker, _fake = _build(scratch)
    try:
        def boom():
            raise RuntimeError("positions unavailable")

        broker.positions = boom  # type: ignore[assignment]
        components.engine.start()

        assert components.risk.state() is RiskState.QUARANTINE
        assert components.positions.count() == 0
        assert _adoption_events(components) == []
        report = components.reconciler.run()
        assert report.clean is False
        assert any("unreadable" in detail for detail in report.details)
    finally:
        components.close()
