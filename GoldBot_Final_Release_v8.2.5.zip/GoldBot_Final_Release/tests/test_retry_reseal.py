"""Retry without a new seal is a risk bypass; ownership of orphans is explicit."""

from __future__ import annotations

from dataclasses import replace

import pytest
from helpers import make_context, make_info, make_tick

from goldbot.app.ids import GOLDBOT_MAGIC_BASE, magic_for_slot, owns_position_magic
from goldbot.app.retry_guard import revalidate_for_retry
from goldbot.domain.execution import ApprovedOrder, RiskSnapshot
from goldbot.domain.model import Symbol

SECRET = "unit-test-secret"


def make_order(*, price: float = 2000.0, stop_distance: float = 2.0, volume: float = 0.1,
               max_slippage_points: int = 20, side: str = "buy") -> ApprovedOrder:
    sl = price - stop_distance if side == "buy" else price + stop_distance
    order = ApprovedOrder(
        intent_id="retry-1",
        slot="unit",
        strategy="zones",
        symbol=Symbol("XAUUSD"),
        side=side,
        volume=volume,
        order_type="market",
        sl=sl,
        tp=price + 2.0 * stop_distance if side == "buy" else price - 2.0 * stop_distance,
        magic=magic_for_slot("unit"),
        client_ref="gbretry",
        max_slippage_points=max_slippage_points,
        risk=RiskSnapshot(
            equity=10_000.0,
            balance=10_000.0,
            risk_pct=1.0,
            risk_amount=100.0,
            stop_distance=stop_distance,
            volume=volume,
            spread_points=20.0,
        ),
    )
    return order.seal(SECRET)


def test_widened_spread_aborts_retry() -> None:
    info = make_info()
    order = make_order()
    ok = revalidate_for_retry(order, make_context(info), max_spread_points=50)
    assert ok.allowed and ok.requires_reseal
    wide = make_context(info, tick=make_tick(spread=0.80))  # 80 points
    decision = revalidate_for_retry(order, wide, max_spread_points=50)
    assert decision.aborted and decision.reason == "spread_widened"


def test_invalid_broker_stops_aborts_retry() -> None:
    info = make_info()  # stops_level = 30 points = 0.30
    order = make_order()
    decision = revalidate_for_retry(order, make_context(info), max_spread_points=50,
                                    price=2000.0, sl=2000.05)
    assert decision.aborted and decision.reason == "broker_stops_invalid"


def test_price_drift_beyond_slippage_aborts_retry() -> None:
    info = make_info()
    order = make_order(max_slippage_points=20)
    decision = revalidate_for_retry(order, make_context(info), max_spread_points=50,
                                    price=2000.50, sl=1998.50)
    assert decision.aborted and decision.reason == "price_drift_exceeds_slippage"


def test_retry_risk_above_cap_aborts() -> None:
    info = make_info()
    order = make_order(volume=1.0, stop_distance=2.0)  # 200 USD loss at stop
    decision = revalidate_for_retry(order, make_context(info), max_spread_points=50,
                                    max_risk_amount=100.0)
    assert decision.aborted and decision.reason == "retry_risk_above_cap"
    allowed = revalidate_for_retry(order, make_context(info), max_spread_points=50,
                                   max_risk_amount=200.0)
    assert allowed.allowed


def test_old_seal_is_invalid_for_a_new_price() -> None:
    order = make_order()
    assert order.is_sealed(SECRET)
    repriced = replace(order, sl=order.sl - 0.25)
    assert not repriced.is_sealed(SECRET)  # stale token travels with the copy
    assert repriced.seal(SECRET).is_sealed(SECRET)


def test_foreign_magic_is_not_owned() -> None:
    assert owns_position_magic(magic_for_slot("zones"))
    assert owns_position_magic(magic_for_slot("numeric"), GOLDBOT_MAGIC_BASE)
    assert not owns_position_magic(0)
    assert not owns_position_magic(99_999_999)


@pytest.mark.parametrize("side", ["buy", "sell"])
def test_clean_retry_is_only_a_pre_check(side: str) -> None:
    info = make_info()
    order = make_order(side=side)
    decision = revalidate_for_retry(order, make_context(info), max_spread_points=50)
    assert decision.allowed
    assert decision.requires_reseal  # always a fresh engine approval, never a replay
