"""Daily S/R levels: broker-day aggregation, pivot math and zone precedence."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone

from goldbot.domain.model import Bar
from goldbot.strategy_api import (
    Zone,
    broker_daily_bars,
    daily_levels,
    daily_zones,
    merge_all,
)

UTC = timezone.utc


def daily(day: int, o: float, h: float, l: float, c: float) -> Bar:
    return Bar(
        symbol="XAUUSD",  # type: ignore[arg-type]
        timeframe="D1",  # type: ignore[arg-type]
        open_time=datetime(2024, 3, day, tzinfo=UTC),
        o=o,
        h=h,
        l=l,
        c=c,
    )


def m15(hour: int, minute: int, price: float = 2000.0, day: int = 3) -> Bar:
    return Bar(
        symbol="XAUUSD",  # type: ignore[arg-type]
        timeframe="M15",  # type: ignore[arg-type]
        open_time=datetime(2024, 3, day, hour, minute, tzinfo=UTC),
        o=price,
        h=price + 1,
        l=price - 1,
        c=price,
        tick_volume=10,
    )


def test_broker_daily_bars_use_the_server_offset() -> None:
    bars = [m15(21, 45), m15(22, 0), m15(22, 15), m15(23, 45)]
    grouped = broker_daily_bars(bars, timedelta(hours=2))
    # 21:45 UTC is 23:45 server (previous day); 22:00 UTC starts the new day.
    assert len(grouped) == 2
    assert grouped[0].c == 2000.0
    assert grouped[1].o == 2000.0


def test_daily_levels_use_the_last_completed_day() -> None:
    bars = [
        daily(1, 95.0, 109.0, 91.0, 104.0),
        daily(2, 104.0, 112.0, 96.0, 100.0),
        daily(3, 95.0, 110.0, 90.0, 105.0),
        daily(4, 105.0, 107.0, 103.0, 106.0),  # running day: must be ignored
    ]
    levels = daily_levels(bars, now=datetime(2024, 3, 4, 10, tzinfo=UTC), offset=timedelta(0))
    assert levels is not None
    assert levels.pdh == 110.0
    assert levels.pdl == 90.0
    assert levels.pdo == 95.0
    assert levels.pdc == 105.0
    assert levels.pivot == (110.0 + 90.0 + 105.0) / 3.0
    assert levels.r1 == 2.0 * levels.pivot - 90.0
    assert levels.s1 == 2.0 * levels.pivot - 110.0
    assert levels.previous_day.isoformat() == "2024-03-03"


def test_daily_levels_are_none_before_the_first_close() -> None:
    bars = [daily(4, 105.0, 107.0, 103.0, 106.0)]
    assert daily_levels(bars, now=datetime(2024, 3, 4, 10, tzinfo=UTC), offset=timedelta(0)) is None


def test_daily_zones_are_scored_and_stable() -> None:
    bars = [daily(1, 95.0, 109.0, 91.0, 104.0), daily(2, 104.0, 112.0, 96.0, 100.0), daily(3, 95.0, 110.0, 90.0, 105.0)]
    levels = daily_levels(bars, now=datetime(2024, 3, 4, 10, tzinfo=UTC), offset=timedelta(0))
    assert levels is not None
    zones = daily_zones(levels, price=105.0)
    assert zones
    pdh = next(zone for zone in zones if zone.note == "PDH")
    assert pdh.source == "daily"
    assert pdh.zone_id.startswith("D")
    assert pdh.score >= 80
    assert pdh.low < levels.pdh < pdh.high
    again = daily_zones(levels, price=105.0)
    assert [zone.zone_id for zone in zones] == [zone.zone_id for zone in again]


def test_manual_zones_win_over_daily_on_overlap() -> None:
    bars = [daily(2, 104.0, 112.0, 96.0, 100.0), daily(3, 95.0, 110.0, 90.0, 105.0)]
    levels = daily_levels(bars, now=datetime(2024, 3, 4, 10, tzinfo=UTC), offset=timedelta(0))
    assert levels is not None
    daily_level = next(zone for zone in daily_zones(levels) if zone.note == "PDH")
    manual = Zone(
        high=daily_level.high,
        low=daily_level.low,
        score=90,
        source="manual",
        note="operator",
    )
    merged = merge_all((manual,), (daily_level,), ())
    assert len(merged) == 1
    assert merged[0].source == "manual"


def test_zone_engine_includes_daily_levels() -> None:
    from datetime import timedelta

    from goldbot.app.zones_engine import ZoneEngine

    m15 = []
    for day in (1, 2, 3, 4):
        for minute in range(0, 24 * 60, 15):
            hour = minute // 60
            if hour > 22:
                continue
            m15.append(
                Bar(
                    symbol="XAUUSD",  # type: ignore[arg-type]
                    timeframe="M15",  # type: ignore[arg-type]
                    open_time=datetime(2024, 3, day, hour, minute % 60, tzinfo=UTC),
                    o=2000.0 + day,
                    h=2005.0 + day,
                    l=1995.0 + day,
                    c=2001.0 + day,
                    tick_volume=10,
                )
            )
    engine = ZoneEngine(history_fn=lambda: m15, broker_offset=timedelta(0))
    zones = engine.snapshot(m15[-200:], now=datetime(2024, 3, 5, 10, tzinfo=UTC))
    assert any(zone.source == "daily" for zone in zones)
    assert engine.levels is not None
    assert engine.levels.pdh == 2009.0

