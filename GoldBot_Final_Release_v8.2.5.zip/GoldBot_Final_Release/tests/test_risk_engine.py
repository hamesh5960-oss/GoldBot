"""The risk engine is the only gate. These tests try to get orders through it."""

from __future__ import annotations

from dataclasses import replace
from datetime import datetime, timedelta, timezone

import pytest

from goldbot.app.risk_engine import RiskEngine
from goldbot.domain.execution import EntryIntent
from goldbot.domain.model import Symbol
from goldbot.ports.risk import RiskState, Verdict

from helpers import NOW, make_account, make_context, make_tick


def _intent(stop: float = 1990.0, target: float | None = 2020.4, side: str = "buy") -> EntryIntent:
    return EntryIntent(
        intent_id="i-1",
        slot="fvg_m15",
        strategy="fvg",
        symbol=Symbol("XAUUSD"),
        side=side,  # type: ignore[arg-type]
        entry_ref=2000.2,
        stop=stop,
        target=target,
        risk_multiplier=1.0,
        signal={"rationale": "test"},
        created_at=NOW,
    )


@pytest.fixture
def engine(profile, journal, clock) -> RiskEngine:
    eng = RiskEngine(profile, journal=journal, clock=clock)
    eng.begin(10_000.0, NOW)
    return eng


def test_valid_intent_is_approved_and_sealed(engine, info) -> None:
    decision = engine.evaluate_entry(_intent(), make_context(info))
    assert decision.verdict is Verdict.APPROVE
    assert decision.order is not None
    assert decision.order.volume > 0
    assert decision.order.is_sealed(engine.secret())
    assert not decision.order.is_sealed("wrong-secret")
    assert {c.name for c in decision.checks} >= {"spread", "daily_loss", "max_positions", "volume"}


def test_wide_spread_blocks_entry(engine, info) -> None:
    tick = make_tick(spread=1.0)  # 100 points > 35
    decision = engine.evaluate_entry(_intent(), make_context(info, tick=tick))
    assert decision.verdict is Verdict.REJECT
    assert "spread" in decision.reasons


def test_poor_reward_risk_is_rejected(engine, info) -> None:
    decision = engine.evaluate_entry(_intent(target=2005.0), make_context(info))
    assert decision.verdict is Verdict.REJECT
    assert "risk_reward" in decision.reasons


def test_stop_too_wide_is_rejected(engine, info) -> None:
    decision = engine.evaluate_entry(_intent(stop=1900.0, target=2100.0), make_context(info))
    assert decision.verdict is Verdict.REJECT
    assert "stop_distance" in decision.reasons


def test_too_many_positions_blocked(engine, info) -> None:
    from goldbot.domain.model import PositionSnapshot

    open_pos = [
        PositionSnapshot(
            ticket=1,
            symbol=Symbol("XAUUSD"),
            side="buy",
            volume=0.01,
            open_price=2000.0,
            sl=1990.0,
            tp=None,
            magic=1,
            comment="",
            open_time=NOW,
        )
    ]
    decision = engine.evaluate_entry(_intent(), make_context(info, positions=open_pos * 2))
    assert decision.verdict is Verdict.REJECT
    assert "max_positions" in decision.reasons


def test_daily_loss_engages_halt_and_blocks(engine, info) -> None:
    # equity drops 2.5% (> medium 2% daily limit)
    ctx = make_context(info, account=make_account(equity=9_750.0, balance=9_750.0))
    engine.on_mark(ctx)
    assert engine.state() is RiskState.HALTED
    decision = engine.evaluate_entry(_intent(), ctx)
    assert decision.verdict is Verdict.REJECT
    assert "risk_state" in decision.reasons


def test_trade_halt_can_only_be_cleared_by_human(engine, info) -> None:
    engine.engage(RiskState.HALTED, "manual test", actor="test")
    engine.on_mark(make_context(info))
    assert engine.state() is RiskState.HALTED
    engine.acknowledge(level=RiskState.HALTED, actor="operator", note="checked")
    assert engine.state() is RiskState.NORMAL


def test_consecutive_losses_trigger_soft_halt(engine) -> None:
    for _ in range(3):
        engine.on_trade_closed(-50.0, NOW)
    assert engine.state() is RiskState.SOFT_HALT


def test_total_drawdown_kills(engine, info) -> None:
    engine.begin(10_000.0, NOW)
    ctx = make_context(info, account=make_account(equity=8_900.0, balance=8_900.0))
    engine.on_mark(ctx)
    assert engine.state() is RiskState.KILLED


def test_risk_multiplier_scales_risk(profile, journal, clock, info) -> None:
    engine = RiskEngine(profile, journal=journal, clock=clock)
    engine.begin(10_000.0, NOW)
    full = engine.evaluate_entry(_intent(), make_context(info))
    engine2 = RiskEngine(profile, journal=journal, clock=clock)
    engine2.begin(10_000.0, NOW)
    half = engine2.evaluate_entry(_intent(), make_context(info))
    assert full.order and half.order
    assert half.order.risk.risk_amount == pytest.approx(full.order.risk.risk_amount)

    engine3 = RiskEngine(profile, journal=journal, clock=clock)
    engine3.begin(10_000.0, NOW)
    intent = _intent()
    scaled = replace(intent, risk_multiplier=0.5)
    half = engine3.evaluate_entry(scaled, make_context(info))
    assert half.order and full.order
    assert half.order.volume < full.order.volume
    assert half.order.risk.risk_amount <= full.order.risk.risk_amount * 0.5 + 1e-6


def test_daily_halt_clears_on_the_next_day(profile, journal, clock, info) -> None:
    engine = RiskEngine(profile, journal=journal, clock=clock)
    engine.begin(10_000.0, NOW)
    engine.on_mark(make_context(info, account=make_account(equity=9_700.0, balance=9_700.0)))
    assert engine.state() is RiskState.HALTED

    tomorrow = NOW + timedelta(days=1)
    engine.on_mark(
        make_context(info, account=make_account(equity=9_700.0, balance=9_700.0), now=tomorrow)
    )
    assert engine.state() is RiskState.NORMAL, "a daily brake must reset with the new day"


def test_kill_switch_is_never_auto_cleared(profile, journal, clock, info) -> None:
    engine = RiskEngine(profile, journal=journal, clock=clock)
    engine.begin(10_000.0, NOW)
    engine.on_mark(make_context(info, account=make_account(equity=8_000.0, balance=8_000.0)))
    assert engine.state() is RiskState.KILLED

    tomorrow = NOW + timedelta(days=1)
    engine.on_mark(
        make_context(info, account=make_account(equity=8_000.0, balance=8_000.0), now=tomorrow)
    )
    assert engine.state() is RiskState.KILLED, "total drawdown requires a human"


def test_manual_halt_requires_acknowledgement(profile, journal, clock, info) -> None:
    engine = RiskEngine(profile, journal=journal, clock=clock)
    engine.begin(10_000.0, NOW)
    engine.engage(RiskState.HALTED, "operator test", actor="operator")
    engine.on_mark(make_context(info, now=NOW + timedelta(days=1)))
    assert engine.state() is RiskState.HALTED


def test_orders_per_day_limit(profile, journal, clock, info) -> None:
    tight = profile.model_copy(update={"max_orders_per_day": 1})
    engine = RiskEngine(tight, journal=journal, clock=clock)
    engine.begin(10_000.0, NOW)
    first = engine.evaluate_entry(_intent(), make_context(info))
    assert first.approved
    second = engine.evaluate_entry(_intent(), make_context(info))
    assert second.verdict is Verdict.REJECT
    assert "orders_per_day" in second.reasons


def test_stale_tick_blocks(engine, info) -> None:
    old = NOW - timedelta(seconds=120)
    ctx = make_context(info, tick=make_tick(at=old), now=NOW)
    decision = engine.evaluate_entry(_intent(), ctx)
    assert decision.verdict is Verdict.REJECT
    assert "stale_tick" in decision.reasons


def test_every_decision_is_journalled(engine, info, journal) -> None:
    engine.evaluate_entry(_intent(), make_context(info))
    events = [e for e in journal.read_events() if e.type == "RiskEvaluated"]
    assert len(events) == 1
    assert events[0].payload["verdict"] == "approve"
    assert events[0].payload["checks"]


def test_management_moves_stop_to_breakeven(profile, journal, clock, info) -> None:
    from goldbot.domain.model import PositionSnapshot

    engine = RiskEngine(profile, journal=journal, clock=clock)
    engine.begin(10_000.0, NOW)
    engine.register_position(7, risk_amount=50.0, initial_stop=1990.0, slot="fvg_m15")
    ctx = make_context(
        info,
        tick=make_tick(price=2011.0),
        positions=[
            PositionSnapshot(
                ticket=7,
                symbol=Symbol("XAUUSD"),
                side="buy",
                volume=0.05,
                open_price=2000.0,
                sl=1990.0,
                tp=None,
                magic=1,
                comment="",
                open_time=NOW,
            )
        ],
    )
    actions = engine.manage(ctx)
    assert actions and actions[0].action in {"breakeven", "trail"}
    assert actions[0].sl is not None and actions[0].sl >= 2000.0

def test_volume_is_capped_by_risk_percent(profile, journal, clock, info) -> None:
    # 10k equity, 1% cap = 100 USD; (10.2 * 100 + 7 commission) per lot -> 0.09 lots.
    engine = RiskEngine(profile, journal=journal, clock=clock)
    engine.begin(10_000.0, NOW)
    decision = engine.evaluate_entry(_intent(), make_context(info))
    assert decision.order is not None
    assert decision.order.volume == pytest.approx(0.09)
    assert decision.order.risk.risk_amount <= 100.0 + 1e-6


def test_capital_rule_sizes_from_risk_not_from_equity(profile, journal, clock, info) -> None:
    # 1000 equity, 1% = 10 USD; 0.5 * 100 + 7 = 57 per lot -> floor(0.175) = 0.17.
    engine = RiskEngine(profile, journal=journal, clock=clock)
    engine.begin(1_000.0, NOW)
    tight = replace(_intent(), stop=1999.7, target=2001.5)  # 0.5 USD stop
    decision = engine.evaluate_entry(tight, make_context(info, account=make_account(equity=1_000.0, balance=1_000.0)))
    assert decision.order is not None, decision.reasons
    assert decision.order.volume == pytest.approx(0.17)
    assert decision.order.risk.risk_amount <= 10.0 + 1e-6


def test_micro_account_is_rejected_when_min_lot_breaches_cap(profile, journal, clock, info) -> None:
    # 100 USD, 1% cap = 1 USD; one 0.01 lot with a 10 USD stop risks 10 USD.
    engine = RiskEngine(profile, journal=journal, clock=clock)
    engine.begin(100.0, NOW)
    ctx = make_context(info, account=make_account(equity=100.0, balance=100.0, free_margin=100.0))
    decision = engine.evaluate_entry(_intent(), ctx)
    assert decision.verdict is Verdict.REJECT
    assert "volume" in decision.reasons


def test_manual_lot_is_still_capped_by_risk(profile, journal, clock, info) -> None:
    manual = profile.model_copy(update={"manual_lot": 0.50})
    engine = RiskEngine(manual, journal=journal, clock=clock)
    engine.begin(1_400.0, NOW)
    tight = replace(_intent(), stop=1999.5, target=2001.5)  # 0.7 USD stop
    decision = engine.evaluate_entry(tight, make_context(info, account=make_account(equity=1_400.0, balance=1_400.0)))
    assert decision.order is not None, decision.reasons
    # 1% of 1400 = 14 USD; 0.7 * 100 + 7 = 77 per lot -> cap 0.18 lots
    assert decision.order.volume <= 0.18 + 1e-9
    assert decision.order.risk.risk_amount <= 14.0 + 1e-6


# -- CL-05: swap horizon follows the profile holding window ----------------

def _swap_costs():
    from goldbot.app.costs import CostParams

    return CostParams(
        commission_per_lot_rt=7.0,
        default_spread_points=0.0,
        slippage_points=0.0,
        news_slippage_points=0.0,
        swap_long_per_lot_night=12.0,
        swap_short_per_lot_night=2.0,
    )


def test_cost_estimate_uses_the_profile_holding_horizon(profile, journal, clock, info) -> None:
    costs = _swap_costs()
    one_night = RiskEngine(
        profile.model_copy(update={"max_holding_hours": 24.0}),
        journal=journal,
        clock=clock,
        costs=costs,
    )
    three_nights = RiskEngine(
        profile.model_copy(update={"max_holding_hours": 72.0}),
        journal=journal,
        clock=clock,
        costs=costs,
    )
    ctx = make_context(info)
    # Monday broker day: 1 night = 1 charge; 3 nights = 1+1+3 (Wed triple) = 5.
    assert one_night._estimate_cost(_intent(), 0.10, ctx)["swap"] == pytest.approx(
        12.0 * 1 * 0.10
    )
    assert three_nights._estimate_cost(_intent(), 0.10, ctx)["swap"] == pytest.approx(
        12.0 * 5 * 0.10
    )


def test_sealed_order_journals_the_holding_horizon_cost(profile, journal, clock, info) -> None:
    costs = _swap_costs()
    short = RiskEngine(
        profile.model_copy(update={"max_holding_hours": 24.0}),
        journal=journal,
        clock=clock,
        costs=costs,
    )
    long = RiskEngine(
        profile.model_copy(update={"max_holding_hours": 72.0}),
        journal=journal,
        clock=clock,
        costs=costs,
    )
    short.begin(10_000.0, NOW)
    long.begin(10_000.0, NOW)
    short_decision = short.evaluate_entry(_intent(), make_context(info))
    long_decision = long.evaluate_entry(_intent(), make_context(info))
    assert short_decision.order is not None, short_decision.reasons
    assert long_decision.order is not None, long_decision.reasons
    short_cost = short_decision.order.signal["_estimated_cost"]
    long_cost = long_decision.order.signal["_estimated_cost"]
    assert short_cost["swap"] == pytest.approx(12.0 * 1 * short_decision.order.volume)
    assert long_cost["swap"] == pytest.approx(12.0 * 5 * long_decision.order.volume)
    assert long_cost["swap"] > short_cost["swap"]
    assert long_decision.order.volume <= short_decision.order.volume
