"""Property sweeps: deterministic, seeded invariants over sizing and confirmation tiers.

No hypothesis dependency: each sweep is a fixed seed so a failure reproduces
exactly from the test name alone.

The decision half pins the locked confirmation design (ADR-031..037): count ->
tier_base is monotone, the layer-3 vote only moves one step, D is a hard floor,
the zone filter and the R:R absolute floor are the only hard gates, and the
risk table is fixed.
"""

from __future__ import annotations

import random

import pytest
from helpers import NOW, make_info

from goldbot.app.decision import (
    TIER_ORDER,
    TIER_RISK_PCT,
    Tier,
    adjust_tier,
    decide,
    layer3_delta,
    tier_base_from_confirmations,
)
from goldbot.app.risk.capital import CapitalParams, plan_entry

TIERS = (Tier.A_PLUS, Tier.A, Tier.B, Tier.C, Tier.D, None)
INFO = make_info()


def _rank(tier: Tier) -> int:
    return TIER_ORDER.index(tier)


def _plan(**overrides):
    kwargs = {
        "tier": Tier.A,
        "risk_multiplier": 1.0,
        "equity": 10_000.0,
        "stop_distance": 2.0,
        "info": INFO,
        "commission_per_lot": 7.0,
        "open_risk_pct": 0.0,
        "profile_cap_pct": 1.5,
        "drawdown_pct": 0.0,
        "atr_percentile": None,
        "session": "london",
        "news_blackout": False,
        "now": NOW,
        "params": CapitalParams(),
    }
    kwargs.update(overrides)
    return plan_entry(**kwargs)


def _cases(count: int = 200):
    rng = random.Random(20240304)
    for _ in range(count):
        yield {
            "tier": rng.choice(TIERS),
            "risk_multiplier": rng.uniform(0.0, 1.5),
            "equity": rng.uniform(200.0, 500_000.0),
            "stop_distance": rng.uniform(0.5, 40.0),
            "open_risk_pct": rng.uniform(0.0, 2.5),
            "profile_cap_pct": rng.choice([0.5, 1.0, 1.5, 2.0, 3.0]),
            "drawdown_pct": rng.uniform(0.0, 25.0),
            "atr_percentile": rng.choice([None, 50.0, 85.0, 97.0]),
            "session": rng.choice(["asia", "london", "ny"]),
        }


# -- sizing sweeps ------------------------------------------------------


def test_risk_pct_never_exceeds_the_trade_cap() -> None:
    params = CapitalParams()
    cap = min(params.risk_ceiling_pct, params.trade_risk_cap_pct)
    for case in _cases():
        plan = _plan(**case)
        assert plan.intended_pct <= cap + 1e-9
        if plan.volume > 0:
            assert plan.risk_pct <= cap + 1e-9
        else:
            assert plan.risk_pct == 0.0


def test_volume_is_always_zero_or_a_broker_step_multiple() -> None:
    step = INFO.volume_step
    for case in _cases():
        volume = _plan(**case).volume
        assert volume == 0 or (
            INFO.min_volume - 1e-9 <= volume <= INFO.max_volume + 1e-9
            and abs(volume / step - round(volume / step)) < 1e-6
        )


def test_no_volume_sits_between_zero_and_the_minimum_lot() -> None:
    volumes = [_plan(**case).volume for case in _cases()]
    assert volumes
    assert all(volume == 0 or volume >= INFO.min_volume - 1e-9 for volume in volumes)


def test_risk_pct_for_non_base_levels_is_capped_at_one_percent() -> None:
    try:
        from goldbot.app.capital_levels import (
            MAX_LEVEL_RISK_PCT,
            CapitalLevel,
            risk_pct_for_level,
        )
    except ImportError:
        pytest.skip("capital_levels module is not available")
    assert MAX_LEVEL_RISK_PCT <= 1.0
    rng = random.Random(23)
    for level in (CapitalLevel.LOW_RISK, CapitalLevel.MEDIUM_RISK, CapitalLevel.HIGH_RISK):
        for _ in range(50):
            tier = rng.choice((Tier.A_PLUS, Tier.A, Tier.B, Tier.C, Tier.D, None))
            equity = rng.uniform(100.0, 1_000_000.0)
            value = risk_pct_for_level(level, tier, equity)
            assert 0.0 <= value <= MAX_LEVEL_RISK_PCT + 1e-9
            assert value <= 1.0 + 1e-9


def test_base_level_risk_is_zero_unless_armed() -> None:
    try:
        from goldbot.app.capital_levels import CapitalLevel, risk_pct_for_level
    except ImportError:
        pytest.skip("capital_levels module is not available")
    assert risk_pct_for_level(CapitalLevel.BASE, Tier.A, 500.0) == 0.0
    armed = risk_pct_for_level(CapitalLevel.BASE, Tier.A, 500.0, base_enabled=True)
    assert armed > 0.0


def test_plan_entry_is_deterministic() -> None:
    case = next(_cases())
    assert _plan(**case) == _plan(**case)
    manual = _plan(**case, manual_lot=0.5)
    assert manual == _plan(**case, manual_lot=0.5)


def test_invalid_stop_returns_no_volume() -> None:
    for stop in (0.0, -1.0):
        plan = _plan(stop_distance=stop, commission_per_lot=0.0)
        assert plan.volume == 0.0
        assert plan.reason == "invalid_stop"
        assert plan.tradable is False


def test_manual_lot_is_an_upper_bound_not_a_floor() -> None:
    rng = random.Random(31)
    for _ in range(100):
        manual_lot = rng.uniform(0.01, 60.0)
        plan = _plan(
            manual_lot=manual_lot,
            equity=rng.uniform(200.0, 200_000.0),
            stop_distance=rng.uniform(0.5, 30.0),
        )
        assert plan.volume <= INFO.max_volume + 1e-9
        if plan.volume > 0:
            assert plan.volume <= manual_lot + 1e-9
            assert plan.volume >= INFO.min_volume - 1e-9


# -- confirmation-tier sweeps (ADR-031..037) ---------------------------


def test_confirmation_base_is_monotone() -> None:
    previous = Tier.D
    for step in range(0, 61):
        base = tier_base_from_confirmations(step / 10.0)
        assert _rank(base) <= _rank(previous)
        previous = base


def test_zero_confirmations_are_always_d() -> None:
    for score in (-1.0, -0.61, -0.6, -0.59, 0.0, 0.59, 0.6, 0.61, 1.0):
        decision = decide(confirmation_count=0.0, layer3_score=score)
        assert decision.tier is Tier.D
        assert decision.tier_base is Tier.D
        assert decision.hard_floor is True


def test_four_or_more_confirmations_are_a_plus_base() -> None:
    for count in (4.0, 4.5, 5.0, 5.5, 6.0, 7.0):
        assert tier_base_from_confirmations(count) is Tier.A_PLUS
        for score in (-0.6, 0.0, 0.6):
            assert decide(
                confirmation_count=count, layer3_score=score
            ).tier in (Tier.A_PLUS, Tier.A)


def test_layer3_delta_is_only_minus_one_zero_or_one() -> None:
    for step in range(-20, 21):
        score = step / 20.0
        delta = layer3_delta(score)
        assert delta in (-1, 0, 1)
        expected = 1 if score >= 0.6 else (-1 if score <= -0.6 else 0)
        assert delta == expected


def test_final_tier_is_at_most_one_step_from_base() -> None:
    rng = random.Random(20240304)
    for _ in range(200):
        count = rng.uniform(0.0, 6.5)
        score = rng.uniform(-1.0, 1.0)
        base = tier_base_from_confirmations(count)
        final = decide(confirmation_count=count, layer3_score=score).tier
        if base is Tier.D:
            assert final is Tier.D
        else:
            assert abs(_rank(final) - _rank(base)) <= 1


def test_d_base_never_moves() -> None:
    for score in (-1.0, -0.6, 0.0, 0.6, 1.0):
        assert adjust_tier(Tier.D, layer3_delta(score)) is Tier.D


def test_zone_filter_is_a_hard_d() -> None:
    rng = random.Random(5)
    for _ in range(100):
        count = rng.uniform(0.5, 6.0)
        zone = rng.uniform(0.0, 49.999)
        decision = decide(confirmation_count=count, zone_score=zone, min_zone=50.0)
        assert decision.tier is Tier.D
        assert decision.reasons == ("zone_filter",)
    for count in (1.0, 2.0, 4.0, 6.0):
        assert decide(confirmation_count=count, zone_score=None).tier is not Tier.D


def test_rr_floor_is_a_hard_noise() -> None:
    rng = random.Random(9)
    for _ in range(100):
        count = rng.uniform(0.0, 6.0)
        rr = rng.uniform(0.0, 0.999)
        decision = decide(confirmation_count=count, rr_net=rr, rr_absolute_floor=1.0)
        assert decision.tier is Tier.NOISE
        assert decision.reasons == ("rr_absolute_floor",)
        assert decision.rejected is True
    for count in (0.0, 2.0, 4.0):
        assert decide(confirmation_count=count, rr_net=1.0).tier is not Tier.NOISE


def test_risk_table_matches_the_locked_matrix() -> None:
    assert TIER_RISK_PCT == {
        Tier.A_PLUS: 1.0,
        Tier.A: 0.75,
        Tier.B: 0.5,
        Tier.C: 0.25,
        Tier.D: 0.0,
        Tier.NOISE: 0.0,
    }
    for count in (0.0, 1.0, 2.0, 3.0, 4.0):
        decision = decide(confirmation_count=count)
        assert decision.risk_base_pct == TIER_RISK_PCT[decision.tier]
