"""BarBuilder edge cases (D01/D02): final-bar flush and explicit bucket gaps."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone

import pytest

from goldbot.app.bar_builder import BarBuilder, BarGap
from goldbot.domain.model import Symbol, Tick, Ts

SYMBOL = Symbol("XAUUSD")
START = datetime(2024, 3, 4, 10, 0, tzinfo=timezone.utc)


def _tick(price: float = 2000.0, *, at: datetime = START, spread: float = 0.2, volume: int = 2) -> Tick:
    return Tick(
        symbol=SYMBOL,
        bid=round(price - spread / 2, 2),
        ask=round(price + spread / 2, 2),
        ts_event=Ts(at),
        ts_recv=Ts(at),
        volume=volume,
    )


def _m15(times=None) -> BarBuilder:
    return BarBuilder(SYMBOL, ("M15",))


def test_flush_closes_the_final_partial_bar() -> None:
    builder = _m15()
    for index, price in enumerate((2000.0, 2001.0, 1999.0)):
        closed = builder.on_tick(_tick(price, at=START + timedelta(seconds=60 * index)))
        assert closed == []
    assert builder.bars("M15", 10) == []

    flushed = builder.flush()
    assert len(flushed) == 1
    bar = flushed[0]
    assert bar.timeframe == "M15"
    assert bar.open_time == START.replace(minute=0, second=0)
    assert bar.o == pytest.approx(2000.0)
    assert bar.h == pytest.approx(2001.0)
    assert bar.l == pytest.approx(1999.0)
    assert bar.c == pytest.approx(1999.0)
    assert bar.tick_volume == 6
    assert bar.spread_avg == pytest.approx(0.2)
    assert bar.is_closed is True
    assert builder.last_bar("M15") == bar
    assert builder.bars("M15", 10) == [bar]


def test_flush_is_idempotent() -> None:
    builder = _m15()
    builder.on_tick(_tick(at=START))
    assert len(builder.flush()) == 1
    assert builder.flush() == []
    assert len(builder.bars("M15", 10)) == 1


def test_flush_with_no_ticks_is_empty() -> None:
    assert _m15().flush() == []


def test_flush_closes_every_configured_timeframe() -> None:
    builder = BarBuilder(SYMBOL, ("M15", "H1"))
    builder.on_tick(_tick(at=START))
    flushed = builder.flush()
    assert {bar.timeframe for bar in flushed} == {"M15", "H1"}
    assert len(flushed) == 2
    assert all(bar.open_time == START.replace(minute=0, second=0) for bar in flushed)


def test_adjacent_bucket_closes_one_bar_without_a_gap() -> None:
    builder = _m15()
    builder.on_tick(_tick(2000.0, at=START))
    closed = builder.on_tick(_tick(2001.0, at=START + timedelta(minutes=15)))
    assert len(closed) == 1
    assert closed[0].open_time == START.replace(minute=0, second=0)
    assert builder.gaps == ()
    assert builder.take_gaps() == ()


def test_multi_bucket_jump_records_one_explicit_gap() -> None:
    builder = _m15()
    builder.on_tick(_tick(2000.0, at=START))
    closed = builder.on_tick(_tick(2001.0, at=START + timedelta(minutes=45)))
    assert len(closed) == 1  # the 10:00 bar
    # 10:15 and 10:30 buckets are missing; no synthetic bars were invented.
    assert len(builder.bars("M15", 100)) == 1
    (gap,) = builder.gaps
    assert isinstance(gap, BarGap)
    assert gap.timeframe == "M15"
    assert gap.missing_from == START.replace(minute=15, second=0)
    assert gap.missing_until == START.replace(minute=45, second=0)
    assert gap.missing_bars == 2


def test_weekend_jump_records_exactly_one_gap_record() -> None:
    builder = _m15()
    friday = datetime(2024, 3, 8, 21, 0, tzinfo=timezone.utc)
    monday = datetime(2024, 3, 11, 0, 0, tzinfo=timezone.utc)
    builder.on_tick(_tick(at=friday))
    closed = builder.on_tick(_tick(at=monday))
    assert len(closed) == 1
    assert len(builder.bars("M15", 100)) == 1
    (gap,) = builder.gaps
    expected_missing = int((monday - friday).total_seconds() // 900) - 1
    assert gap.missing_bars == expected_missing
    assert gap.missing_from == friday.replace(minute=15, second=0)


def test_gaps_are_recorded_per_timeframe() -> None:
    builder = BarBuilder(SYMBOL, ("M15", "H1"))
    builder.on_tick(_tick(at=START))
    builder.on_tick(_tick(at=START + timedelta(minutes=150)))  # 10:00 -> 12:30
    per_tf = {gap.timeframe: gap.missing_bars for gap in builder.gaps}
    assert per_tf["M15"] == 9   # 10:15..12:15
    assert per_tf["H1"] == 1    # 11:00


def test_take_gaps_clears_them() -> None:
    builder = _m15()
    builder.on_tick(_tick(at=START))
    builder.on_tick(_tick(at=START + timedelta(minutes=45)))
    assert len(builder.take_gaps()) == 1
    assert builder.gaps == ()
    assert builder.take_gaps() == ()
    assert len(builder.flush()) == 1  # flushing never creates a gap record
    assert builder.gaps == ()


def test_flush_after_a_gap_closes_the_current_partial() -> None:
    builder = _m15()
    builder.on_tick(_tick(at=START))
    builder.on_tick(_tick(at=START + timedelta(minutes=45)))
    flushed = builder.flush()
    assert len(flushed) == 1
    assert flushed[0].open_time == START.replace(minute=45, second=0)
    assert len(builder.bars("M15", 100)) == 2  # 10:00 and 10:45; never back-filled


def test_history_is_bounded_and_in_order() -> None:
    builder = BarBuilder(SYMBOL, ("M15",), history=2)
    for index in range(5):
        at = START + timedelta(minutes=15 * index)
        builder.on_tick(_tick(2000.0 + index, at=at))
    builder.on_tick(_tick(3000.0, at=START + timedelta(minutes=90)))
    history = builder.bars("M15", 10)
    assert len(history) == 2
    assert [bar.open_time for bar in history] == sorted(bar.open_time for bar in history)
    builder.flush()
    assert len(builder.bars("M15", 10)) == 2  # flush respects maxlen


def test_each_bucket_closes_exactly_once() -> None:
    builder = _m15()
    bars: list = []
    for index in range(11):
        bars.extend(builder.on_tick(_tick(2000.0, at=START + timedelta(seconds=30 * index))))
    bars.extend(builder.flush())
    assert len(bars) == 1
    assert bars[0].open_time == START.replace(minute=0, second=0)
