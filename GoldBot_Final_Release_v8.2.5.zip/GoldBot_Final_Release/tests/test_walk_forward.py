"""Walk-forward, Monte Carlo and regime validation of the research framework."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone

import pytest

from goldbot.domain.model import Bar, Symbol
from goldbot.research.monte_carlo import (
    HIGH_VOL,
    LOW_VOL,
    RANGING,
    REGIMES,
    TRENDING,
    group_stats,
    percentile,
    regime_split,
    shuffle_trades,
)
from goldbot.research.walk_forward import (
    Window,
    accept,
    make_windows,
    run_walk_forward,
)

SYMBOL = Symbol("XAUUSD")
START = datetime(2024, 3, 4, tzinfo=timezone.utc)


def _bars(closes: list[float], *, wick: float = 0.05) -> list[Bar]:
    bars: list[Bar] = []
    for index, close in enumerate(closes):
        open_price = closes[index - 1] if index else close
        bars.append(
            Bar(
                symbol=SYMBOL,
                timeframe="M15",
                open_time=START + timedelta(minutes=15 * index),
                o=round(open_price, 2),
                h=round(max(open_price, close) + wick, 2),
                l=round(min(open_price, close) - wick, 2),
                c=round(close, 2),
                tick_volume=100,
                spread_avg=0.2,
            )
        )
    return bars


def _trend_bars(count: int = 200) -> list[Bar]:
    return _bars([2000.0 + index for index in range(count)], wick=0.10)


def _volatility_regime_bars() -> list[Bar]:
    closes: list[float] = []
    price = 2000.0
    for index in range(200):  # quiet oscillation
        price += 0.01 if index % 2 else -0.01
        closes.append(price)
    for index in range(200):  # violent oscillation
        price += 4.0 if index % 2 else -4.0
        closes.append(price)
    for index in range(200):  # quiet again
        price += 0.01 if index % 2 else -0.01
        closes.append(price)
    return _bars(closes)


def _edge_run(bars):
    return {
        "trades": 80,
        "expectancy": 1.5,
        "pnl": 120.0,
        "max_dd_pct": 4.0,
        "regimes_positive": 3,
    }


def _no_edge_run(bars):
    return {
        "trades": 80,
        "expectancy": 0.0,
        "pnl": 0.0,
        "max_dd_pct": 20.0,
        "regimes_positive": 0,
    }


# ---------------------------------------------------------------- windows


def test_make_windows_is_non_overlapping_and_anchored_to_the_tail() -> None:
    windows = make_windows(1000, folds=5, is_ratio=0.7, slide_frac=0.5)
    assert len(windows) == 5
    for window in windows:
        assert window.is_bars > 0
        assert window.oos_bars > 0
        assert window.end == window.start + window.is_bars + window.oos_bars
        assert 0 <= window.start
        assert window.end <= 1000
        assert window.is_bars / window.span == pytest.approx(0.7, abs=0.02)
    assert windows[0].start >= 0
    assert windows[-1].end == 1000
    for previous, current in zip(windows, windows[1:]):
        assert current.start > previous.start
        assert current.oos_range[0] >= previous.oos_range[1]
    assert windows[-1].oos_range == (940, 1000)


def test_make_windows_full_slide_tiles_the_series() -> None:
    windows = make_windows(1000, folds=5, is_ratio=0.7, slide_frac=1.0)
    assert [window.start for window in windows] == [0, 200, 400, 600, 800]
    for window in windows:
        assert window.span == 200
        assert window.is_bars == 140
        assert window.oos_bars == 60


def test_make_windows_never_lets_oos_overlap() -> None:
    # slide_frac 0.2 would slide 40 bars while OOS is 60, so it clamps to 60.
    windows = make_windows(1000, folds=5, is_ratio=0.7, slide_frac=0.2)
    assert [window.start for window in windows] == [560, 620, 680, 740, 800]
    for previous, current in zip(windows, windows[1:]):
        assert current.oos_range[0] == previous.oos_range[1]


def test_make_windows_single_fold_is_the_tail_split() -> None:
    (window,) = make_windows(1000, folds=1, is_ratio=0.7)
    assert window == Window(start=0, end=1000, is_bars=700, oos_bars=300)


@pytest.mark.parametrize(
    "kwargs",
    [
        {"n_bars": 9, "folds": 5},
        {"n_bars": 1000, "folds": 0},
        {"n_bars": 1000, "is_ratio": 1.5},
        {"n_bars": 1000, "is_ratio": 0.0},
        {"n_bars": 1000, "slide_frac": 0.0},
        {"n_bars": 1000, "slide_frac": 1.5},
    ],
)
def test_make_windows_rejects_bad_arguments(kwargs) -> None:
    with pytest.raises(ValueError):
        make_windows(**kwargs)


def test_window_slices_and_validation() -> None:
    window = Window(start=10, end=110, is_bars=70, oos_bars=30)
    assert window.is_range == (10, 80)
    assert window.oos_range == (80, 110)
    assert window.span == 100
    with pytest.raises(ValueError):
        Window(start=0, end=99, is_bars=70, oos_bars=30)
    with pytest.raises(ValueError):
        Window(start=-1, end=99, is_bars=70, oos_bars=30)


# ------------------------------------------------------- run_walk_forward


def test_run_walk_forward_feeds_exact_boundary_slices() -> None:
    bars = list(range(1000))
    seen: list[list[int]] = []

    def run_fn(block):
        seen.append(list(block))
        return _edge_run(block)

    report = run_walk_forward(bars, run_fn)
    first, second = report.rows[0].window, report.rows[1].window
    assert seen[0] == bars[first.is_range[0] : first.is_range[1]]
    assert seen[1] == bars[first.oos_range[0] : first.oos_range[1]]
    assert len(seen) == 10  # IS + OOS for five folds


def test_run_walk_forward_aggregates_weighted_expectancy() -> None:
    calls = {"n": 0}

    def run_fn(block):
        calls["n"] += 1
        if calls["n"] % 2 == 0:  # OOS calls are the even ones
            return {"trades": 100, "expectancy": 2.0, "pnl": 200.0, "max_dd_pct": 5.0}
        return {"trades": 50, "expectancy": -1.0, "pnl": -50.0, "max_dd_pct": 9.0}

    report = run_walk_forward(list(range(1000)), run_fn)
    aggregate = report.aggregate
    assert aggregate["folds"] == 5
    assert aggregate["is_trades"] == 250
    assert aggregate["oos_trades"] == 500
    assert aggregate["is_expectancy"] == pytest.approx(-1.0)
    assert aggregate["oos_expectancy"] == pytest.approx(2.0)
    assert aggregate["oos_positive_folds"] == 5
    assert aggregate["p95_dd_pct"] == pytest.approx(5.0)
    assert aggregate["regimes_positive"] == 0.0


def test_run_walk_forward_rejects_incomplete_metrics() -> None:
    def run_fn(block):
        return {"trades": 10, "expectancy": 1.0, "pnl": 1.0}

    with pytest.raises(ValueError, match="max_dd_pct"):
        run_walk_forward(list(range(1000)), run_fn)

    def not_a_mapping(block):
        return 42

    with pytest.raises(ValueError, match="mapping"):
        run_walk_forward(list(range(1000)), not_a_mapping)


def test_accept_accepts_a_consistent_edge() -> None:
    report = run_walk_forward(list(range(1000)), _edge_run)
    ok, reasons = accept(report)
    assert ok is True
    assert reasons == ()
    assert report.aggregate["oos_positive_folds"] == 5
    assert report.aggregate["p95_dd_pct"] == pytest.approx(4.0)


def test_accept_rejects_a_no_edge_stub() -> None:
    report = run_walk_forward(list(range(1000)), _no_edge_run)
    ok, reasons = accept(report)
    assert ok is False
    joined = " | ".join(reasons)
    assert "oos_positive_folds" in joined
    assert "p95_dd_pct" in joined
    assert "regimes_positive" in joined
    assert len(reasons) == 3


@pytest.mark.parametrize(
    ("thresholds", "needle"),
    [
        ({"min_oos_positive_folds": 6}, "oos_positive_folds"),
        ({"max_p95_dd_pct": 1.0}, "p95_dd_pct"),
        ({"min_oos_trades": 10_000}, "oos_trades"),
        ({"min_regimes_positive": 5}, "regimes_positive"),
    ],
)
def test_accept_each_rule_can_reject(thresholds, needle) -> None:
    report = run_walk_forward(list(range(1000)), _edge_run)
    ok, reasons = accept(report, **thresholds)
    assert ok is False
    assert any(needle in reason for reason in reasons)


def test_accept_thresholds_are_inclusive() -> None:
    report = run_walk_forward(list(range(1000)), _edge_run)
    ok, reasons = accept(
        report,
        min_oos_positive_folds=5,
        max_p95_dd_pct=4.0,
        min_oos_trades=400,
        min_regimes_positive=3,
    )
    assert ok is True
    assert reasons == ()


def test_walk_forward_is_deterministic() -> None:
    first = run_walk_forward(list(range(1000)), _edge_run)
    second = run_walk_forward(list(range(1000)), _edge_run)
    assert first.rows == second.rows
    assert first.aggregate == second.aggregate


# ------------------------------------------------------------ monte carlo


def test_shuffle_trades_is_deterministic_and_bounded() -> None:
    pnls = [5.0, -3.0, 2.5, -1.0, 4.0, -2.0] * 10
    first = shuffle_trades(pnls, n=500, seed=7, initial_equity=10_000.0)
    second = shuffle_trades(pnls, n=500, seed=7, initial_equity=10_000.0)
    assert first == second
    assert first.final_equity_p5 <= first.final_equity_p50 <= first.final_equity_p95
    assert first.p95_max_drawdown_pct >= first.median_max_drawdown_pct >= 0.0
    assert 0.0 <= first.prob_profit <= 1.0
    assert 0 <= first.worst_streak <= len(pnls)
    assert first.trades_per_sim == len(pnls)
    assert first.initial_equity == 10_000.0
    assert set(first.as_dict()) >= {"final_equity_p5", "prob_profit", "worst_streak"}

    other = shuffle_trades(pnls, n=500, seed=8, initial_equity=10_000.0)
    assert other != first


def test_shuffle_trades_all_positive_has_no_drawdown() -> None:
    summary = shuffle_trades([10.0] * 50, n=200, seed=42, initial_equity=1000.0)
    assert summary.final_equity_p5 == pytest.approx(1500.0)
    assert summary.final_equity_p50 == pytest.approx(1500.0)
    assert summary.final_equity_p95 == pytest.approx(1500.0)
    assert summary.p95_max_drawdown_pct == 0.0
    assert summary.prob_profit == 1.0
    assert summary.worst_streak == 0


def test_shuffle_trades_drawdown_tracks_a_single_large_loss() -> None:
    pnls = [-500.0] + [1.0] * 99
    summary = shuffle_trades(pnls, n=400, seed=3, initial_equity=10_000.0)
    # The worst case is the loss landing after every win: 500 / 10_500.
    lower_bound = 500.0 / (10_000.0 + 99.0) * 100.0
    assert lower_bound <= summary.p95_max_drawdown_pct <= 5.0 + 1e-9
    assert summary.worst_streak == 1


def test_shuffle_trades_rejects_bad_input() -> None:
    with pytest.raises(ValueError, match="at least one trade"):
        shuffle_trades([])
    with pytest.raises(ValueError, match="n must be"):
        shuffle_trades([1.0], n=0)
    with pytest.raises(ValueError, match="initial_equity"):
        shuffle_trades([1.0], initial_equity=0.0)


def test_percentile_interpolates() -> None:
    assert percentile([1.0, 2.0, 3.0, 4.0], 0.0) == 1.0
    assert percentile([1.0, 2.0, 3.0, 4.0], 50.0) == pytest.approx(2.5)
    assert percentile([1.0, 2.0, 3.0, 4.0], 100.0) == 4.0
    assert percentile([7.0], 95.0) == 7.0
    with pytest.raises(ValueError):
        percentile([], 50.0)
    with pytest.raises(ValueError):
        percentile([1.0], 101.0)


# ---------------------------------------------------------------- regimes


def test_regime_labels_are_deterministic_and_cover_every_bar() -> None:
    bars = _volatility_regime_bars()
    first = regime_split(bars)
    second = regime_split(bars)
    assert first == second
    assert len(first) == len(bars)
    assert set(first) <= set(REGIMES)


def test_regime_labels_detect_a_trend() -> None:
    labels = regime_split(_trend_bars())
    assert labels[-1] == TRENDING
    assert TRENDING in labels
    assert len(labels) == 200


def test_regime_labels_detect_volatility_extremes() -> None:
    labels = regime_split(_volatility_regime_bars())
    assert HIGH_VOL in labels
    assert LOW_VOL in labels
    # The expanding baseline re-adapts, so the final quiet bars are normal again.
    assert labels[-1] in REGIMES
    assert labels[-1] != HIGH_VOL
    assert RANGING in labels  # warmup bars are neutral


def test_regime_labels_require_positive_periods() -> None:
    with pytest.raises(ValueError):
        regime_split(_trend_bars(), atr_period=0)
    with pytest.raises(ValueError):
        regime_split(_trend_bars(), adx_period=-1)


def test_group_stats_buckets_by_regime() -> None:
    labels = [TRENDING, RANGING, TRENDING, HIGH_VOL]
    values = [10.0, -5.0, 6.0, -2.0]
    stats = group_stats(labels, values)
    assert set(stats) == {TRENDING, RANGING, HIGH_VOL}

    trending = stats[TRENDING]
    assert trending.count == 2
    assert trending.total == pytest.approx(16.0)
    assert trending.mean == pytest.approx(8.0)
    assert trending.win_rate == pytest.approx(1.0)
    assert trending.profit_factor is None
    assert trending.best == pytest.approx(10.0)
    assert trending.worst == pytest.approx(6.0)

    ranging = stats[RANGING]
    assert ranging.count == 1
    assert ranging.win_rate == 0.0
    assert ranging.profit_factor == pytest.approx(0.0)
    assert stats[HIGH_VOL].worst == pytest.approx(-2.0)


def test_group_stats_rejects_mismatched_lengths() -> None:
    with pytest.raises(ValueError):
        group_stats([TRENDING], [1.0, 2.0])
    assert group_stats([], []) == {}
