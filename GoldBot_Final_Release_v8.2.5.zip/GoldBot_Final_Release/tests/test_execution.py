"""Execution path: sealing, idempotency, uncertainty, reconciliation."""

from __future__ import annotations

from datetime import datetime, timezone

import pytest

from goldbot.adapters.fake_broker import FakeBroker
from goldbot.app.order_coordinator import OrderCoordinator
from goldbot.app.position_manager import PositionManager
from goldbot.app.reconciler import Reconciler
from goldbot.app.risk_engine import RiskEngine
from goldbot.domain.errors import InvariantError, SubmitUncertain
from goldbot.domain.execution import EntryIntent, ExitIntent
from goldbot.domain.model import PositionSnapshot, Symbol, Ticket, Ts
from goldbot.ports.risk import RiskState

from helpers import NOW, make_context, make_tick


def _approved(engine: RiskEngine, info):
    intent = EntryIntent(
        intent_id="i-exec",
        slot="fvg_m15",
        strategy="fvg",
        symbol=Symbol("XAUUSD"),
        side="buy",
        entry_ref=2000.2,
        stop=1990.0,
        target=2020.4,
        risk_multiplier=1.0,
        signal={"rationale": "unit"},
        created_at=NOW,
    )
    decision = engine.evaluate_entry(intent, make_context(info))
    assert decision.order is not None
    return decision.order


def _coordinator(broker, journal, clock, positions, secret) -> OrderCoordinator:
    return OrderCoordinator(
        broker=broker, journal=journal, clock=clock, positions=positions, secret=secret, run_id="test"
    )


@pytest.fixture
def engine(profile, journal, clock) -> RiskEngine:
    eng = RiskEngine(profile, journal=journal, clock=clock)
    eng.begin(10_000.0, NOW)
    return eng


def test_acked_order_creates_position_and_journal(engine, broker, journal, clock, positions, info) -> None:
    broker.on_market_tick(make_tick(price=2000.0))
    coordinator = _coordinator(broker, journal, clock, positions, engine.secret())
    result = coordinator.execute(_approved(engine, info))

    assert result.status == "acked"
    assert positions.count() == 1
    types = [e.type for e in journal.read_events()]
    assert "OrderSubmitted" in types
    assert "OrderAcked" in types
    assert "PositionOpened" in types
    trade = journal.trades()[0]
    assert trade.sl is not None
    assert trade.risk_amount > 0


def test_unsealed_order_is_refused(engine, broker, journal, clock, positions, info) -> None:
    broker.on_market_tick(make_tick())
    order = _approved(engine, info)
    intruder = _coordinator(broker, journal, clock, positions, "some-other-secret")
    with pytest.raises(InvariantError):
        intruder.execute(order)


def test_broker_is_idempotent_by_key(engine, broker, journal, clock, positions, info) -> None:
    broker.on_market_tick(make_tick())
    order = _approved(engine, info)
    first = broker.submit(order, idempotency_key="k1")
    second = broker.submit(order, idempotency_key="k1")
    assert first.ticket == second.ticket
    assert len(broker.positions()) == 1


def test_uncertain_order_is_recovered_by_reconciliation(
    engine, broker, journal, clock, positions, info, monkeypatch
) -> None:
    broker.on_market_tick(make_tick())
    coordinator = _coordinator(broker, journal, clock, positions, engine.secret())
    order = _approved(engine, info)

    original = broker.submit

    def flaky(*args, **kwargs):
        original(*args, **kwargs)          # venue accepted it...
        raise SubmitUncertain("timeout")   # ...but we never saw the ack

    monkeypatch.setattr(broker, "submit", flaky)
    result = coordinator.execute(order)
    assert result.status == "uncertain"
    assert coordinator.in_flight()

    monkeypatch.setattr(broker, "submit", original)
    adopted = coordinator.resolve_uncertain(since=datetime(2024, 1, 1, tzinfo=timezone.utc))
    assert adopted, "order should be found at the venue"
    types = [e.type for e in journal.read_events()]
    assert "OrderResolvedPresent" in types


def test_broker_rejection_is_journaled(engine, broker, journal, clock, positions, info) -> None:
    broker.on_market_tick(make_tick())
    broker._reject_next = "invalid_stops"
    coordinator = _coordinator(broker, journal, clock, positions, engine.secret())
    result = coordinator.execute(_approved(engine, info))
    assert result.status == "rejected"
    assert positions.count() == 0


def test_sl_exit_is_settled_with_pnl(engine, broker, journal, clock, positions, info) -> None:
    broker.on_market_tick(make_tick(price=2000.0))
    coordinator = _coordinator(broker, journal, clock, positions, engine.secret())
    coordinator.execute(_approved(engine, info))

    closed = broker.on_market_tick(make_tick(price=1985.0, at=NOW.replace(minute=30)))
    assert len(closed) == 1
    assert closed[0].reason == "sl"
    assert float(closed[0].pnl_net.amount) < 0


def test_close_intent_returns_closed_trade(engine, broker, journal, clock, positions, info) -> None:
    broker.on_market_tick(make_tick(price=2000.0))
    coordinator = _coordinator(broker, journal, clock, positions, engine.secret())
    ack = coordinator.execute(_approved(engine, info))
    ticket = ack.ack.ticket
    assert ticket is not None

    broker.on_market_tick(make_tick(price=2005.0))
    result = coordinator.close_position(
        ExitIntent("x1", "fvg_m15", int(ticket), Symbol("XAUUSD"), "manual")
    )
    assert result.status == "acked"
    assert result.ack is not None and result.ack.closed_trade is not None


def test_hedging_keeps_two_positions(info) -> None:
    pm = PositionManager(mode="hedging", contract_size=info.contract_size)
    from goldbot.domain.model import Fill
    from goldbot.domain.money import money

    for ticket in (1, 2):
        pm.apply_fill(
            Fill(Ticket(ticket), Symbol("XAUUSD"), "buy", 0.1, 2000.0, money(0), Ts(NOW)),
            slot="s",
            strategy="fvg",
        )
    assert pm.count() == 2
    assert pm.net_volume(Symbol("XAUUSD")) == pytest.approx(0.2)


def test_netting_merges_positions(info) -> None:
    pm = PositionManager(mode="netting", contract_size=info.contract_size)
    from goldbot.domain.model import Fill
    from goldbot.domain.money import money

    pm.apply_fill(Fill(Ticket(1), Symbol("XAUUSD"), "buy", 0.1, 2000.0, money(0), Ts(NOW)), slot="s")
    pm.apply_fill(Fill(Ticket(2), Symbol("XAUUSD"), "buy", 0.1, 2002.0, money(0), Ts(NOW)), slot="s")
    assert pm.count() == 1
    only = pm.view()[0]
    assert only.volume == pytest.approx(0.2)
    assert only.open_price == pytest.approx(2001.0)


def test_reconcile_detects_missing_and_orphan(info) -> None:
    """A local ticket the venue does not know about is the dangerous direction."""
    pm = PositionManager(mode="hedging", contract_size=info.contract_size)
    from goldbot.domain.model import Fill
    from goldbot.domain.money import money

    pm.apply_fill(Fill(Ticket(1), Symbol("XAUUSD"), "buy", 0.1, 2000.0, money(0), Ts(NOW)), slot="s")
    truth = [
        PositionSnapshot(
            ticket=Ticket(2),
            symbol=Symbol("XAUUSD"),
            side="buy",
            volume=0.1,
            open_price=2000.0,
            sl=1990.0,
            tp=None,
            magic=1,
            comment="",
            open_time=NOW,
        )
    ]
    report = pm.reconcile(truth)
    assert not report.clean
    assert report.missing == (1,)
    assert report.orphan == (2,)


def test_reconciler_emits_divergence(broker, journal, clock) -> None:
    pm = PositionManager(mode="hedging")
    broker.on_market_tick(make_tick())
    reconciler = Reconciler(positions=pm, broker=broker, journal=journal, clock=clock)
    report = reconciler.run()
    assert report.clean
    assert any(e.type == "ReconcileCompleted" for e in journal.read_events())


def test_position_without_stop_is_reported(info) -> None:
    pm = PositionManager(mode="hedging", contract_size=info.contract_size)
    from goldbot.domain.model import Fill
    from goldbot.domain.money import money

    pm.apply_fill(
        Fill(Ticket(9), Symbol("XAUUSD"), "buy", 0.1, 2000.0, money(0), Ts(NOW)),
        slot="s",
        initial_stop=1990.0,
    )
    truth = [
        PositionSnapshot(
            ticket=Ticket(9),
            symbol=Symbol("XAUUSD"),
            side="buy",
            volume=0.1,
            open_price=2000.0,
            sl=None,
            tp=None,
            magic=1,
            comment="",
            open_time=NOW,
        )
    ]
    report = pm.reconcile(truth)
    assert report.protection_lost == (9,)
