"""Pure multi-level capability evaluator: reasons, sizing and classification."""

from __future__ import annotations

import copy
import math
from types import SimpleNamespace

import pytest

from goldbot.app.level_eval import (
    CAPACITY_REASONS,
    LEVEL_ORDER,
    CapitalSpec,
    LevelEvaluation,
    SignalSpec,
    capability_summary,
    classify_capabilities,
    eval_for_level,
    level_capabilities,
    min_capital_for_base,
    min_capital_for_level,
)


def _policy(**overrides: object) -> dict[str, object]:
    base: dict[str, object] = {
        "allowed_tiers": frozenset({"A+", "A"}),
        "zone_floors": {},
        "max_trades_per_day": 3,
        "max_open_risk_pct": 3.0,
        "max_daily_loss_pct": 3.0,
        "max_consecutive_losses": 4,
        "amplifier_enabled": True,
        "gates_enabled": True,
        "sessions": ("london", "overlap", "ny"),
        "news_before_minutes": 15,
        "spread_ratio": 0.15,
        "kill_switch_dd_pct": 20.0,
        "min_equity": 0.0,
        "risk_source": "tier",
    }
    base.update(overrides)
    return base


def _capital(**overrides: object) -> CapitalSpec:
    base: dict[str, object] = {
        "min_lot": 0.01,
        "lot_step": 0.01,
        "tick_value": 1.0,  # 1 USD per 0.01 price unit -> 100 USD per price unit
        "tick_size": 0.01,
        "contract_size": 100.0,
        "point": 0.01,
        "equity": 10_000.0,
    }
    base.update(overrides)
    return CapitalSpec(**base)  # type: ignore[arg-type]


def _signal(**overrides: object) -> SignalSpec:
    base: dict[str, object] = {
        "signal_id": "s-1",
        "tier": "A",
        "entry": 2000.0,
        "sl": 1990.0,
        "tp": 2020.0,
        "rr_net": 2.0,
        "zone_score_adj": 60.0,
        "session": "london",
        "news_blackout": False,
        "spread_ratio": 0.05,
        "direction": "buy",
    }
    base.update(overrides)
    return SignalSpec(**base)  # type: ignore[arg-type]


def _ev(
    level: object = "LOW_RISK",
    signal: SignalSpec | None = None,
    policy: dict[str, object] | None = None,
    capital: CapitalSpec | None = None,
    **state: object,
) -> LevelEvaluation:
    defaults: dict[str, object] = {
        "equity": 10_000.0,
        "open_risk_pct": 0.0,
        "trades_today": 0,
        "drawdown_pct": 0.0,
        "consecutive_losses": 0,
        "risk_pct": 1.0,
    }
    defaults.update(state)
    return eval_for_level(
        level,
        signal or _signal(),
        policy or _policy(),
        capital or _capital(),
        **defaults,  # type: ignore[arg-type]
    )


_BANDS = tuple(
    SimpleNamespace(min_eq=low, max_eq=high, risk_pct=pct, hysteresis_enter=0.0)
    for low, high, pct in (
        (0.0, 200.0, 5.0),
        (200.0, 300.0, 4.0),
        (300.0, 400.0, 3.0),
        (400.0, 500.0, 2.0),
        (500.0, math.inf, 1.5),
    )
)


# -- eligibility and sizing ---------------------------------------------
def test_eligible_row_reports_the_full_sizing_picture() -> None:
    row = _ev()
    assert row.level == "LOW"
    assert row.eligible is True
    assert row.reason == "eligible"
    assert row.would_be_lot == pytest.approx(0.10)
    assert row.would_be_risk_dollars == pytest.approx(100.0)
    assert row.would_be_risk_pct == pytest.approx(1.0)
    assert row.min_capital_needed == pytest.approx(1_000.0)
    assert row.capital_gap == pytest.approx(0.0)
    assert row.capacity_only is False


def test_capital_spec_risk_per_min_lot_uses_ticks_or_contract_fallback() -> None:
    assert _capital().risk_per_min_lot(10.0) == pytest.approx(1_000.0)
    fallback = _capital(tick_size=0.0, contract_size=50.0)
    assert fallback.risk_per_min_lot(10.0) == pytest.approx(500.0)
    assert _capital().risk_per_min_lot(0.0) == 0.0


def test_capital_spec_rejects_impossible_numbers() -> None:
    with pytest.raises(ValueError):
        _capital(min_lot=0.0)
    with pytest.raises(ValueError):
        _capital(lot_step=0.0)
    with pytest.raises(ValueError):
        _capital(max_lot=0.001)


def test_never_rounds_up_to_the_next_lot_step() -> None:
    # 1% of 1500 = 15 USD -> 0.015 lots; the floor must be 0.01, not 0.02.
    row = _ev(capital=_capital(equity=1_500.0), equity=1_500.0)
    assert row.eligible is True
    assert row.would_be_lot == pytest.approx(0.01)
    assert row.would_be_risk_dollars == pytest.approx(10.0)
    assert row.would_be_risk_pct == pytest.approx(10.0 / 1_500.0 * 100.0)


def test_minimum_lot_that_exceeds_the_risk_budget_is_skipped() -> None:
    row = _ev(capital=_capital(equity=150.0), equity=150.0)
    assert row.eligible is False
    assert row.reason == "min_lot_exceeds_risk"
    assert row.would_be_lot == 0.0
    assert row.capacity_only is True
    assert row.min_capital_needed == pytest.approx(1_000.0)
    assert row.capital_gap == pytest.approx(850.0)


def test_no_risk_budget_is_a_capacity_gap_not_eligibility() -> None:
    row = _ev(risk_pct=None)
    assert row.eligible is False
    assert row.reason == "min_lot_exceeds_risk"
    assert row.capacity_only is True
    assert row.min_capital_needed == math.inf


def test_negative_risk_pct_is_rejected() -> None:
    with pytest.raises(ValueError):
        _ev(risk_pct=-1.0)


# -- policy checks ------------------------------------------------------
def test_tier_floor_blocks_a_disallowed_tier() -> None:
    row = _ev(signal=_signal(tier="C"))
    assert row.reason == "tier_floor"
    assert row.capacity_only is False


def test_zone_floor_uses_the_per_tier_floor() -> None:
    policy = _policy(zone_floors={"A": 70})
    assert _ev(signal=_signal(zone_score_adj=60.0), policy=policy).reason == "zone_floor"
    assert _ev(signal=_signal(zone_score_adj=70.0), policy=policy).reason == "eligible"


def test_session_filter_blocks_unlisted_sessions() -> None:
    assert _ev(signal=_signal(session="asia")).reason == "session"
    assert _ev(signal=_signal(session="asia"), policy=_policy(sessions=("all",))).eligible


def test_news_blackout_blocks_only_when_the_level_filters_news() -> None:
    assert _ev(signal=_signal(news_blackout=True)).reason == "news"
    row = _ev(signal=_signal(news_blackout=True), policy=_policy(news_before_minutes=0))
    assert row.eligible is True


def test_spread_ratio_is_a_hard_budget() -> None:
    assert _ev(signal=_signal(spread_ratio=0.20)).reason == "spread"
    assert _ev(signal=_signal(spread_ratio=0.15)).eligible


def test_rr_floor_is_absolute_with_a_policy_override() -> None:
    # ADR-034 removed the per-tier R:R minimum: the only floor is the absolute
    # one (1.0R by default), so tier A no longer requires 2.0R.
    assert _ev(signal=_signal(tier="A", rr_net=0.99)).reason == "rr_floor"
    assert _ev(signal=_signal(tier="A", rr_net=1.9)).eligible
    policy = _policy(allowed_tiers=frozenset({"A+", "A", "B"}))
    assert _ev(signal=_signal(tier="B", rr_net=1.5), policy=policy).eligible
    assert _ev(signal=_signal(tier="A", rr_net=1.2), policy=_policy(min_rr=1.0)).eligible
    assert _ev(signal=_signal(tier="A", rr_net=1.2), policy=_policy(min_rr=1.5)).reason == "rr_floor"


def test_gate_reasons_are_reachable_and_gates_can_be_disabled() -> None:
    assert _ev(gate_b_burn=True).reason == "gate_b_burn"
    assert _ev(gate_c_hedge=True).reason == "gate_c_hedge"
    assert _ev(gate_d_hard=True).reason == "gate_d_hard"
    assert _ev(gate_b_burn=True, policy=_policy(gates_enabled=False)).eligible


# -- state checks -------------------------------------------------------
def test_state_caps_block_in_their_documented_order() -> None:
    assert _ev(trades_today=3).reason == "max_trades_reached"
    assert _ev(open_risk_pct=3.0).reason == "max_open_risk"
    assert _ev(drawdown_pct=20.0).reason == "kill_switch_active"
    assert _ev(consecutive_losses=4).reason == "max_consecutive_losses"


# -- risk percent checks ------------------------------------------------
def test_absolute_five_percent_cap_holds_for_band_source() -> None:
    row = _ev(policy=_policy(risk_source="base_bands"), risk_pct=5.5)
    assert row.reason == "absolute_cap_5pct"


def test_band_risk_never_leaks_into_a_tier_level() -> None:
    row = _ev(policy=_policy(risk_source="tier"), risk_pct=1.5)
    assert row.reason == "band_risk_exceeded"
    base = _ev(policy=_policy(risk_source="base_bands"), risk_pct=3.0)
    assert base.eligible is True


# -- capital floor ------------------------------------------------------
def test_min_equity_is_a_capacity_gate() -> None:
    row = _ev(policy=_policy(min_equity=5_000.0), capital=_capital(equity=1_000.0), equity=1_000.0)
    assert row.reason == "capital_below_threshold"
    assert row.capacity_only is True
    assert row.min_capital_needed == pytest.approx(5_000.0)
    assert row.capital_gap == pytest.approx(4_000.0)


def test_min_capital_for_level_math() -> None:
    signal = _signal()
    capital = _capital()
    assert min_capital_for_level(signal, capital, 1.0) == pytest.approx(1_000.0)
    assert min_capital_for_level(signal, capital, 1.0, 2_500.0) == pytest.approx(2_500.0)
    assert min_capital_for_level(signal, capital, 0.0) == math.inf  # tier not allowed
    flat = _signal(entry=2000.0, sl=2000.0)
    assert min_capital_for_level(flat, capital, 1.0) == math.inf


def test_min_capital_for_base_walks_the_band_ranges() -> None:
    assert min_capital_for_base(_signal(), _capital(), _BANDS) == pytest.approx(250.0)
    small_stop = _signal(sl=1995.0)  # 5 USD away -> 5 USD minimum-lot risk
    assert min_capital_for_base(small_stop, _capital(), _BANDS) == pytest.approx(100.0)
    fallback = _capital(tick_size=0.0, contract_size=50.0)
    assert min_capital_for_base(_signal(), fallback, _BANDS) == pytest.approx(100.0)


# -- level_capabilities / classify / summary ----------------------------
def test_level_capabilities_follows_the_canonical_order() -> None:
    policies = {
        "HIGH": _policy(),
        "BASE": _policy(),
        "LOW_RISK": _policy(),
        "MEDIUM": _policy(),
    }
    rows = level_capabilities(_signal(), _capital(), policies, 10_000.0, risk_pct=1.0)
    assert [row.level for row in rows] == list(LEVEL_ORDER)


def test_level_capabilities_accepts_per_level_risk_pct() -> None:
    policies = {"BASE": _policy(), "LOW": _policy()}
    rows = level_capabilities(
        _signal(),
        _capital(),
        policies,
        10_000.0,
        risk_pct={"BASE": 3.0, "LOW": 1.0},
    )
    by_level = {row.level: row for row in rows}
    assert by_level["BASE"].would_be_risk_dollars == pytest.approx(300.0)
    assert by_level["LOW"].would_be_risk_dollars == pytest.approx(100.0)


def test_level_capabilities_skips_absent_levels_and_rejects_unknown_ones() -> None:
    rows = level_capabilities(_signal(), _capital(), {"LOW": _policy()}, 10_000.0, risk_pct=1.0)
    assert [row.level for row in rows] == ["LOW"]
    with pytest.raises(ValueError, match="unknown capital level"):
        level_capabilities(_signal(), _capital(), {"turbo": _policy()}, 10_000.0, risk_pct=1.0)


def test_classify_picks_the_safest_eligible_level() -> None:
    policies = {
        "BASE": _policy(allowed_tiers=frozenset({"C"})),
        "LOW": _policy(),
        "MEDIUM": _policy(max_trades_per_day=1),
        "HIGH": _policy(allowed_tiers=frozenset({"C"})),
    }
    rows = level_capabilities(
        _signal(), _capital(), policies, 10_000.0, risk_pct=1.0, trades_today=1
    )
    assert classify_capabilities(rows) == ("LOW", False)


def test_classify_flags_a_capacity_only_miss() -> None:
    policies = {"BASE": _policy(), "LOW": _policy()}
    rows = level_capabilities(
        _signal(),
        _capital(equity=150.0),
        policies,
        150.0,
        risk_pct=1.0,
    )
    assert all(row.reason == "min_lot_exceeds_risk" for row in rows)
    assert classify_capabilities(rows) == (None, True)


def test_classify_does_not_flag_a_policy_rejection_as_missed() -> None:
    rows = level_capabilities(
        _signal(tier="C"),
        _capital(),
        {"LOW": _policy()},
        10_000.0,
        risk_pct=1.0,
    )
    assert classify_capabilities(rows) == (None, False)


def test_capability_summary_counts_gaps_and_the_capital_floor() -> None:
    policies = {
        "BASE": _policy(allowed_tiers=frozenset({"C"})),
        "LOW": _policy(),
        "MEDIUM": _policy(max_trades_per_day=1),
    }
    rows = level_capabilities(
        _signal(), _capital(), policies, 10_000.0, risk_pct=1.0, trades_today=1
    )
    summary = capability_summary(rows)
    assert set(summary) == {"count_eligible", "gaps_by_reason", "min_capital_needed"}
    assert summary["count_eligible"] == 1
    assert summary["gaps_by_reason"] == {"tier_floor": 1, "max_trades_reached": 1}
    assert summary["min_capital_needed"] == pytest.approx(1_000.0)
    assert capability_summary([])["min_capital_needed"] == math.inf


# -- purity -------------------------------------------------------------
def test_evaluation_is_pure_and_deterministic() -> None:
    policy = _policy(zone_floors={"A": 55})
    snapshot = copy.deepcopy(policy)
    signal = _signal()
    capital = _capital()
    first = level_capabilities(
        signal, capital, {"LOW": policy}, 10_000.0, risk_pct=1.0, open_risk_pct=0.5
    )
    second = level_capabilities(
        signal, capital, {"LOW": policy}, 10_000.0, risk_pct=1.0, open_risk_pct=0.5
    )
    assert first == second
    assert policy == snapshot, "policy must not be mutated"
    assert signal == _signal()
    assert capital == _capital()


def test_policy_can_be_an_attribute_object_or_a_mapping() -> None:
    capital = _capital()
    signal = _signal()
    as_object = SimpleNamespace(**_policy())
    from_mapping = eval_for_level(
        "LOW", signal, _policy(), capital, equity=10_000.0, risk_pct=1.0
    )
    from_object = eval_for_level(
        "LOW", signal, as_object, capital, equity=10_000.0, risk_pct=1.0
    )
    assert from_object == from_mapping


def test_every_documented_reason_code_is_reachable() -> None:
    observed = {
        "eligible": _ev().reason,
        "tier_floor": _ev(signal=_signal(tier="C")).reason,
        "zone_floor": _ev(
            signal=_signal(zone_score_adj=0.0), policy=_policy(zone_floors={"A": 55})
        ).reason,
        "session": _ev(signal=_signal(session="asia")).reason,
        "news": _ev(signal=_signal(news_blackout=True)).reason,
        "spread": _ev(signal=_signal(spread_ratio=0.99)).reason,
        "rr_floor": _ev(signal=_signal(rr_net=0.99)).reason,
        "gate_b_burn": _ev(gate_b_burn=True).reason,
        "gate_c_hedge": _ev(gate_c_hedge=True).reason,
        "gate_d_hard": _ev(gate_d_hard=True).reason,
        "max_trades_reached": _ev(trades_today=3).reason,
        "max_open_risk": _ev(open_risk_pct=3.0).reason,
        "kill_switch_active": _ev(drawdown_pct=20.0).reason,
        "max_consecutive_losses": _ev(consecutive_losses=4).reason,
        "absolute_cap_5pct": _ev(
            policy=_policy(risk_source="base_bands"), risk_pct=5.5
        ).reason,
        "band_risk_exceeded": _ev(policy=_policy(risk_source="tier"), risk_pct=1.5).reason,
        "min_lot_exceeds_risk": _ev(capital=_capital(equity=150.0), equity=150.0).reason,
        "capital_below_threshold": _ev(
            policy=_policy(min_equity=5_000.0), equity=1_000.0
        ).reason,
    }
    assert all(reason == expected for expected, reason in observed.items())


def test_capacity_reasons_are_declared_once() -> None:
    assert CAPACITY_REASONS == {"min_lot_exceeds_risk", "capital_below_threshold"}
    assert _ev(capital=_capital(equity=150.0), equity=150.0).capacity_only is True
    assert _ev(signal=_signal(tier="C")).capacity_only is False
