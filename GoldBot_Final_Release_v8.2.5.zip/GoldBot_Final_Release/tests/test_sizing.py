"""Position sizing is the first line of defence: it must never exceed the budget."""

from __future__ import annotations

import pytest

from goldbot.app.risk import compute_capital_volume, compute_volume


def _size(info, **kwargs):
    defaults = dict(
        equity=10_000.0,
        risk_pct=0.5,
        stop_distance=10.0,
        info=info,
        price=2000.0,
        max_leverage=5.0,
        free_margin=10_000.0,
    )
    defaults.update(kwargs)
    return compute_volume(**defaults)


def test_volume_matches_risk_budget(info) -> None:
    result = _size(info)
    # 0.5% of 10k = $50 risk; stop 10.0 * 100 = $1000 per lot -> 0.05 lots
    assert result.volume == pytest.approx(0.05)
    assert result.risk_amount == pytest.approx(50.0)
    assert result.tradable


def test_volume_is_floored_to_step(info) -> None:
    result = _size(info, stop_distance=13.0)  # raw 0.0384
    assert result.volume == pytest.approx(0.03)


def test_below_minimum_is_rejected_not_rounded_up(info) -> None:
    result = _size(info, equity=500.0)  # $2.5 risk, needs stop < $250 per lot
    assert result.volume == 0.0
    assert result.capped_by == "below_min_volume"
    assert not result.tradable


def test_leverage_cap_reduces_volume(info) -> None:
    result = _size(info, equity=1_000.0, risk_pct=1.0, stop_distance=0.5, max_leverage=1.0)
    # risk allows 0.2 lots => notional 40k vs equity 1k => must be capped
    assert result.volume <= 0.05
    assert result.capped_by == "max_leverage"


def test_zero_stop_is_invalid(info) -> None:
    assert _size(info, stop_distance=0.0).volume == 0.0


def _cap_size(info, **kwargs):
    defaults = dict(
        equity=10_000.0,
        lot_per_100=0.01,
        risk_cap_pct=1.0,
        stop_distance=10.0,
        info=info,
        price=4000.0,
        max_leverage=100.0,
        free_margin=10_000.0,
        manual_lot=0.0,
    )
    defaults.update(kwargs)
    return compute_capital_volume(**defaults)


def test_capital_rule_is_001_lot_per_100_usd(info) -> None:
    # 1000 USD -> 0.10 lot, tight stop so the risk cap does not interfere
    result = _cap_size(info, equity=1_000.0, stop_distance=0.5)
    assert result.volume == pytest.approx(0.10)
    assert result.capped_by == "capital_rule"


def test_risk_cap_beats_the_capital_rule(info) -> None:
    # 10k -> capital target 1.00 lot, but 1% of 10k = 100 USD; stop 10 -> 0.10 lot
    result = _cap_size(info, equity=10_000.0, stop_distance=10.0)
    assert result.volume == pytest.approx(0.10)
    assert result.capped_by == "risk_cap"
    assert result.risk_amount <= 100.0


def test_min_lot_above_risk_cap_is_rejected(info) -> None:
    # 100 USD, 1% cap = 1 USD; 0.01 lot with a 10 USD stop risks 10 USD
    result = _cap_size(info, equity=100.0, stop_distance=10.0)
    assert result.volume == 0.0
    assert result.capped_by == "risk_cap_below_min_lot"


def test_manual_lot_is_capped(info) -> None:
    result = _cap_size(info, equity=1_400.0, stop_distance=0.7, manual_lot=0.50)
    assert result.volume == pytest.approx(0.20)   # 14 USD / (0.7 * 100)
    assert result.capped_by == "risk_cap"


def test_manual_lot_used_when_below_cap(info) -> None:
    result = _cap_size(info, equity=1_400.0, stop_distance=0.7, manual_lot=0.05)
    assert result.volume == pytest.approx(0.05)
    assert result.capped_by == "manual_lot"


def test_lot_per_100_scales_with_equity(info) -> None:
    two = _cap_size(info, equity=2_000.0, stop_distance=0.5)
    ten = _cap_size(info, equity=10_000.0, stop_distance=0.5)
    assert two.volume == pytest.approx(0.20)
    assert ten.volume == pytest.approx(1.00)
