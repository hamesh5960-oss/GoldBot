"""Config fingerprint (sha256) and the new [costs] table."""

from __future__ import annotations

import tomllib
from pathlib import Path

import pytest
from pydantic import ValidationError

from goldbot.adapters.config import (
    CostCfg,
    Settings,
    canonical_config_hash,
    journal_config_fields,
    load_settings,
)
from goldbot.app.costs import CostParams
from goldbot.domain.errors import ConfigError
from helpers import CONFIG


def _raw() -> dict:
    return tomllib.loads((CONFIG / "base.toml").read_text(encoding="utf-8"))


def _settings() -> Settings:
    return load_settings(CONFIG / "base.toml")


# -- [costs] table ---------------------------------------------------------


def test_cost_section_loads_and_mirrors_cost_params() -> None:
    settings = _settings()
    assert CostParams(**settings.costs.model_dump()) == CostParams()
    assert settings.costs.commission_per_lot_rt == 7.0
    assert settings.costs.triple_swap_weekday == 2
    assert settings.costs.triple_swap_hour == 20
    assert settings.costs.news_window_minutes == 30


def test_existing_keys_are_untouched_by_the_costs_section() -> None:
    settings = _settings()
    assert settings.execution.commission_per_lot == 7.0
    assert settings.execution.slippage_points == 2.0
    assert settings.capital.risk_ceiling_pct == 1.50
    assert settings.gates.burn_after_sl == 5


def test_cost_config_rejects_invalid_values() -> None:
    with pytest.raises(ValidationError):
        CostCfg(triple_swap_weekday=7)
    with pytest.raises(ValidationError):
        CostCfg(triple_swap_hour=24)
    with pytest.raises(ValidationError):
        CostCfg(point=0.0)
    with pytest.raises(ValidationError):
        CostCfg(not_a_field=1)


# -- hash stability --------------------------------------------------------


def test_hash_is_a_stable_sha256_hex() -> None:
    first = canonical_config_hash(_settings())
    second = canonical_config_hash(_settings())
    assert first == second
    assert len(first) == 64
    assert all(char in "0123456789abcdef" for char in first)


def test_hash_ignores_toml_and_dict_key_order() -> None:
    straight = Settings.model_validate(_raw())
    raw = _raw()
    reordered = {
        key: dict(reversed(list(value.items()))) if isinstance(value, dict) else value
        for key, value in reversed(list(raw.items()))
    }
    reordered_settings = Settings.model_validate(reordered)
    assert canonical_config_hash(straight) == canonical_config_hash(reordered_settings)
    # rebuilding the same model from a differently ordered payload is a no-op
    assert canonical_config_hash(straight) == canonical_config_hash(Settings.model_validate(raw))


def test_hash_ignores_volatile_paths_and_database(tmp_path: Path) -> None:
    base = _settings()
    # A relocated profile with identical content is still the same effective
    # configuration (only the location changed); the *content* is hashed per CJ-01.
    relocated_profiles = tmp_path / "elsewhere.toml"
    relocated_profiles.write_text(
        (CONFIG / "risk_profiles.toml").read_text(encoding="utf-8"), encoding="utf-8"
    )
    relocated = base.model_copy(
        update={
            "journal": base.journal.model_copy(update={"path": "D:/elsewhere/other.db"}),
            "zones": base.zones.model_copy(update={"path": "var/other-zones.json"}),
            "strategies": base.strategies.model_copy(update={"directory": "config/elsewhere"}),
            "risk": base.risk.model_copy(update={"profiles_path": str(relocated_profiles)}),
        }
    )
    assert canonical_config_hash(relocated) == canonical_config_hash(base)


def test_hash_tracks_virtual_every_effective_field() -> None:
    base = _settings()
    baseline = canonical_config_hash(base)
    seen = {baseline}
    changes = [
        ("costs", {"slippage_points": 3.0}),
        ("costs", {"swap_long_per_lot_night": 15.0}),
        ("costs", {"triple_swap_weekday": 3}),
        ("gates", {"burn_after_sl": 6}),
        ("capital", {"risk_ceiling_pct": 1.20}),
        ("budget", {"soft_limit": 9}),
        ("risk", {"profile": "high"}),
    ]
    for section, update in changes:
        section_cfg = getattr(base, section)
        mutated = base.model_copy(update={section: section_cfg.model_copy(update=update)})
        digest = canonical_config_hash(mutated)
        assert digest != baseline, f"{section}.{update} did not change the hash"
        seen.add(digest)
    assert len(seen) == len(changes) + 1


def test_hash_tracks_behaviour_not_just_location() -> None:
    base = _settings()
    logs_on = base.model_copy(
        update={"journal": base.journal.model_copy(update={"json_logs": True})}
    )
    assert canonical_config_hash(logs_on) != canonical_config_hash(base)


def test_journal_config_fields_attach_the_fingerprint() -> None:
    settings = _settings()
    fields = journal_config_fields(settings)
    assert fields["config_hash"] == canonical_config_hash(settings)
    assert fields["profile"] == settings.risk.profile == "medium"


# -- CJ-01: the fingerprint must cover the effective configuration ----------


def _profile_copy(tmp_path: Path, *, replace: tuple[str, str] | None = None) -> Path:
    source = (CONFIG / "risk_profiles.toml").read_text(encoding="utf-8")
    if replace is not None:
        old, new = replace
        assert old in source, f"fixture anchor not found: {old!r}"
        source = source.replace(old, new, 1)
    path = tmp_path / "risk_profiles.toml"
    path.write_text(source, encoding="utf-8")
    return path


def _with_profiles_path(settings: Settings, path: Path) -> Settings:
    return settings.model_copy(
        update={"risk": settings.risk.model_copy(update={"profiles_path": str(path)})}
    )


def test_hash_covers_resolved_risk_profile_money_math(tmp_path: Path) -> None:
    base = _settings()
    mutated = _profile_copy(
        tmp_path,
        replace=(
            "[profiles.medium]\nrisk_per_trade_pct = 1.0",
            "[profiles.medium]\nrisk_per_trade_pct = 0.5",
        ),
    )
    assert canonical_config_hash(_with_profiles_path(base, mutated)) != canonical_config_hash(base)


def test_hash_ignores_profile_file_location_but_not_content(tmp_path: Path) -> None:
    base = _settings()
    relocated = _profile_copy(tmp_path)
    assert canonical_config_hash(_with_profiles_path(base, relocated)) == canonical_config_hash(base)


def test_hash_does_not_drop_behaviour_path_overrides() -> None:
    base = _settings()

    def overridden(url: str) -> Settings:
        return base.model_copy(
            update={
                "risk": base.risk.model_copy(update={"overrides": {"webhook_url": url}})
            }
        )

    assert canonical_config_hash(overridden("https://a")) != canonical_config_hash(
        overridden("https://b")
    )


def test_hash_fails_closed_when_profile_document_is_missing(tmp_path: Path) -> None:
    settings = _with_profiles_path(_settings(), tmp_path / "missing.toml")
    with pytest.raises(ConfigError, match="risk profiles file not found"):
        canonical_config_hash(settings)
