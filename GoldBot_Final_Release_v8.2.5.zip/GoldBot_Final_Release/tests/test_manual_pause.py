"""Operator override: a manual pause blocks new entries but not management."""

from __future__ import annotations

from datetime import timedelta

from goldbot.app.risk_engine import RiskEngine
from goldbot.domain.execution import EntryIntent
from goldbot.domain.model import Symbol

from helpers import NOW, make_context, make_info, make_tick


def _intent() -> EntryIntent:
    return EntryIntent(
        intent_id="pause-1",
        slot="zones_m15",
        strategy="zones",
        symbol=Symbol("XAUUSD"),
        side="buy",
        entry_ref=2000.2,
        stop=1990.0,
        target=2020.4,
        risk_multiplier=1.0,
        signal={"rationale": "pause test"},
        created_at=NOW,
    )


def _engine(profile, journal, clock) -> RiskEngine:
    return RiskEngine(profile, journal=journal, clock=clock)


def test_manual_pause_blocks_new_entries(profile, journal, clock) -> None:
    risk = _engine(profile, journal, clock)
    risk.begin(10_000.0, NOW)
    info = make_info()
    ctx = make_context(info)
    assert risk.evaluate_entry(_intent(), ctx).approved is True
    risk.set_manual_pause(NOW + timedelta(minutes=30), reason="operator check")
    at15 = NOW + timedelta(minutes=15)
    decision = risk.evaluate_entry(
        _intent(), make_context(info, now=at15, tick=make_tick(at=at15))
    )
    assert decision.approved is False
    assert "manual_pause" in decision.reasons
    risk.set_manual_pause(None)
    at30 = NOW + timedelta(minutes=30)
    later = make_context(info, now=at30, tick=make_tick(at=at30))
    assert risk.evaluate_entry(_intent(), later).approved is True


def test_pause_persists_in_aux(profile, journal, clock, scratch) -> None:
    from goldbot.adapters.sqlite_state_store import SqliteRiskStateStore

    store = SqliteRiskStateStore(scratch / "state.db")
    risk = RiskEngine(profile, journal=journal, clock=clock, state_store=store, allow_cold_start=True)
    risk.begin(10_000.0, NOW)
    risk.set_manual_pause(NOW + timedelta(hours=2), reason="maintenance")
    store.close()
    store2 = SqliteRiskStateStore(scratch / "state.db")
    risk2 = RiskEngine(profile, journal=journal, clock=clock, state_store=store2, allow_cold_start=True)
    try:
        assert risk2.manual_pause_until() == NOW + timedelta(hours=2)
        assert risk2.manual_pause_reason() == "maintenance"
    finally:
        store2.close()
