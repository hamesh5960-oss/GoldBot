"""Spec guard: fail-closed symbol/account validation before a session runs."""

from __future__ import annotations

import json
from dataclasses import replace

import pytest
from helpers import make_account, make_info

from goldbot.app.spec_guard import SpecIssue, SpecReport, risk_per_lot, validate_specs
from goldbot.domain.errors import InvariantError
from goldbot.domain.symbol_meta import SymbolMeta

FATAL_CODES = {
    "contract_size": "contract_size_invalid",
    "point": "point_invalid",
    "tick_size": "tick_size_invalid",
    "min_lot": "min_lot_invalid",
    "volume_step": "volume_step_invalid",
    "stops": "stops_level_negative",
    "freeze": "freeze_level_negative",
}


def _info(**overrides):
    return replace(make_info(), **overrides)


def _account(**overrides):
    return replace(make_account(), **overrides)


def _codes(report: SpecReport) -> list[str]:
    return [issue.code for issue in report.issues]


def test_valid_specs_pass_with_effective_numbers() -> None:
    report = validate_specs(_info(tick_value=1.0), make_account())
    assert report.ok is True
    assert report.issues == ()
    assert report.effective["symbol"] == "XAUUSD"
    assert report.effective["contract_size"] == pytest.approx(100.0)
    assert report.effective["stops_level_points"] == 30
    assert report.effective["account_currency"] == "USD"
    assert report.effective["leverage"] == pytest.approx(100.0)
    assert report.effective["require_filling_mode"] is False


@pytest.mark.parametrize(
    ("overrides", "code"),
    [
        ({"contract_size": 0.0}, "contract_size_invalid"),
        ({"contract_size": -100.0}, "contract_size_invalid"),
        ({"point": 0.0}, "point_invalid"),
        ({"tick_size": 0.0}, "tick_size_invalid"),
        ({"min_volume": 0.0}, "min_lot_invalid"),
        ({"max_volume": 0.001}, "max_lot_below_min"),
        ({"volume_step": 0.0}, "volume_step_invalid"),
        ({"stops_level_points": -1}, "stops_level_negative"),
        ({"freeze_level_points": -5}, "freeze_level_negative"),
        ({"trade_mode": "bogus"}, "symbol_trade_mode_invalid"),
        ({"filling_mode": "bogus"}, "filling_mode_invalid"),
        ({"tick_value": -1.0}, "tick_value_invalid"),
    ],
)
def test_fatal_field_rules_fail_closed(overrides, code: str) -> None:
    report = validate_specs(_info(**overrides), make_account())
    assert report.ok is False
    assert code in _codes(report)
    fatal = [issue for issue in report.issues if issue.severity == "fatal"]
    assert any(issue.code == code for issue in fatal)


def test_every_fatal_rule_has_a_detail() -> None:
    report = validate_specs(_info(contract_size=0.0, point=0.0), make_account())
    assert all(isinstance(issue, SpecIssue) for issue in report.issues)
    assert all(issue.detail for issue in report.issues)
    assert len(report.fatal) == 2


def test_netting_is_rejected_unless_explicitly_allowed() -> None:
    account = make_account(mode="netting")
    rejected = validate_specs(make_info(), account)
    assert rejected.ok is False
    assert "netting_not_allowed" in _codes(rejected)

    allowed = validate_specs(make_info(), account, allow_netting=True)
    assert allowed.ok is True
    assert "netting_not_allowed" not in _codes(allowed)


def test_account_currency_must_match() -> None:
    account = _account(currency="EUR")
    report = validate_specs(make_info(), account)
    assert report.ok is False
    assert "currency_mismatch" in _codes(report)

    accepted = validate_specs(make_info(), account, expected_currency="EUR")
    assert accepted.ok is True
    assert accepted.effective["account_currency"] == "EUR"


def test_filling_mode_unknown_is_fatal_only_when_required() -> None:
    info = _info(filling_mode="unknown")
    lenient = validate_specs(info, make_account())
    assert lenient.ok is True
    assert "filling_mode_unknown" not in _codes(lenient)

    strict = validate_specs(info, make_account(), require_filling_mode=True)
    assert strict.ok is False
    assert "filling_mode_unknown" in _codes(strict)

    known = validate_specs(_info(filling_mode="ioc"), make_account(), require_filling_mode=True)
    assert known.ok is True


def test_tick_value_unknown_is_only_a_warning() -> None:
    report = validate_specs(_info(tick_value=0.0), make_account())
    assert report.ok is True
    assert "tick_value_unknown" in _codes(report)
    assert all(issue.severity == "warn" for issue in report.warnings)

    known = validate_specs(
        _info(tick_value=1.0), make_account()
    )
    assert "tick_value_unknown" not in _codes(known)


def test_restricted_symbol_mode_warns_but_does_not_block() -> None:
    report = validate_specs(_info(trade_mode="longonly"), make_account())
    assert report.ok is True
    assert "symbol_trade_mode_not_full" in _codes(report)
    assert all(issue.severity == "warn" for issue in report.warnings)


def test_expected_contract_size_mismatch_is_fatal() -> None:
    assert validate_specs(
        make_info(), make_account(), expected_contract_size=100.0
    ).ok is True
    mismatch = validate_specs(make_info(), make_account(), expected_contract_size=10.0)
    assert mismatch.ok is False
    assert "contract_size_mismatch" in _codes(mismatch)


def test_missing_inputs_never_raise() -> None:
    no_symbol = validate_specs(None, make_account())
    assert no_symbol.ok is False
    assert "symbol_missing" in _codes(no_symbol)
    assert no_symbol.effective == {}

    no_account = validate_specs(make_info(), None)
    assert no_account.ok is False
    assert "account_missing" in _codes(no_account)

    junk = validate_specs(object(), object())
    assert isinstance(junk, SpecReport)
    assert junk.ok is False


def test_risk_per_lot_prefers_tick_value_over_contract_size() -> None:
    tick_info = _info(tick_value=0.5)  # 0.5 USD per 0.01 -> 50 USD per price unit
    fallback_info = _info()  # tick_value 0 -> contract_size 100 USD per price unit
    assert risk_per_lot(tick_info, 2.0) == pytest.approx(100.0)
    assert risk_per_lot(fallback_info, 2.0) == pytest.approx(200.0)


def test_risk_per_lot_includes_costs_and_volume() -> None:
    info = _info(tick_value=1.0)  # 100 USD per price unit
    total = risk_per_lot(info, 2.0, volume=1.0, slippage_points=10, commission_per_lot=7.0)
    assert total == pytest.approx((2.0 + 0.10) * 100.0 + 7.0)
    scaled = risk_per_lot(info, 2.0, volume=0.1, slippage_points=10, commission_per_lot=7.0)
    assert scaled == pytest.approx(total * 0.1)


def test_risk_per_lot_rejects_bad_inputs() -> None:
    info = make_info()
    with pytest.raises(ValueError, match="stop_distance"):
        risk_per_lot(info, 0.0)
    with pytest.raises(ValueError, match="stop_distance"):
        risk_per_lot(info, -1.0)
    with pytest.raises(ValueError, match="volume"):
        risk_per_lot(info, 2.0, volume=0.0)
    with pytest.raises(ValueError, match="slippage_points"):
        risk_per_lot(info, 2.0, slippage_points=-1)
    with pytest.raises(ValueError, match="commission_per_lot"):
        risk_per_lot(info, 2.0, commission_per_lot=-1)
    with pytest.raises(ValueError, match="tick_size"):
        risk_per_lot(_info(tick_value=1.0, tick_size=0.0), 2.0)
    with pytest.raises(ValueError, match="contract_size"):
        risk_per_lot(_info(tick_value=0.0, contract_size=0.0), 2.0)


def test_validate_specs_is_deterministic_and_json_safe() -> None:
    info = _info(tick_value=0.0, trade_mode="longonly")
    first = validate_specs(info, make_account())
    second = validate_specs(info, make_account())
    assert first == second
    payload = first.as_dict()
    assert json.loads(json.dumps(payload))["ok"] is True
    assert payload["issues"] == [
        {"code": "symbol_trade_mode_not_full", "detail": payload["issues"][0]["detail"], "severity": "warn"},
        {"code": "tick_value_unknown", "detail": payload["issues"][1]["detail"], "severity": "warn"},
    ]


def test_symbol_meta_maps_the_new_symbol_info_fields() -> None:
    meta = SymbolMeta.from_symbol_info(_info(tick_value=1.0, filling_mode="fok"))
    assert meta.tick_value == pytest.approx(1.0)
    assert meta.filling_mode == "fok"
    meta.validate()


def test_symbol_meta_validates_tick_value_and_filling_mode() -> None:
    meta = SymbolMeta.from_symbol_info(_info(tick_value=1.0, filling_mode="ioc"))
    with pytest.raises(InvariantError, match="tick_value"):
        replace(meta, tick_value=-1.0).validate()
    with pytest.raises(InvariantError, match="filling_mode"):
        replace(meta, filling_mode="weird").validate()
    # 0.0 tick value stays valid: it is the documented "unknown" fallback.
    replace(meta, tick_value=0.0).validate()
