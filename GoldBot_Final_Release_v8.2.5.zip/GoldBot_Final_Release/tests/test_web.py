"""Local web panel API (TestClient): zones, toggles, profile and journal."""

from __future__ import annotations

import json

import pytest
from fastapi.testclient import TestClient

import goldbot.web.app as web
from goldbot.adapters.zones import ZoneStore


@pytest.fixture
def client(monkeypatch, scratch):
    monkeypatch.setattr(web, "STATE_PATH", scratch / "panel_state.json")
    store = ZoneStore(scratch / "zones.json")
    monkeypatch.setattr(web, "_zones", lambda: store)
    return TestClient(web.app)


def test_index_page(client) -> None:
    response = client.get("/")
    assert response.status_code == 200
    assert "GoldBot" in response.text


def test_status_lists_all_strategies(client) -> None:
    data = client.get("/api/status").json()
    assert {"equity", "profile", "strategies", "zones"} <= set(data)
    ids = {s["strategy"] for s in data["strategies"]}
    assert {"zones", "numeric"} == ids


def test_add_and_delete_zone(client) -> None:
    put = client.put("/api/zones", json={"zones": [{"high": 4050.0, "low": 4048.0, "starred": True}]})
    assert put.status_code == 200

    zones = client.get("/api/zones").json()["zones"]
    assert len(zones) == 1
    assert zones[0]["high"] == 4050.0

    assert client.delete("/api/zones/0").status_code == 200
    assert client.get("/api/zones").json()["zones"] == []


def test_config_update_is_reflected_in_status(client) -> None:
    response = client.put("/api/config", json={"profile": "high", "direction": "long"})
    assert response.status_code == 200
    status = client.get("/api/status").json()
    assert status["profile"] == "high"
    assert status["direction"] == "long"


def test_invalid_profile_is_rejected(client) -> None:
    response = client.put("/api/config", json={"profile": "yolo"})
    assert response.status_code == 400
    assert "detail" in response.json()


def test_import_zones_from_csv(client) -> None:
    response = client.post(
        "/api/zones/import",
        json={"text": "4050,4048,1,ناحیه مهم\n4035.5,4032"},
    )
    assert response.status_code == 200
    assert response.json()["count"] == 2
    zones = client.get("/api/zones").json()["zones"]
    assert len(zones) == 2
    assert zones[0]["starred"] is True


def test_import_rejects_bad_file_with_json_error(client) -> None:
    response = client.post("/api/zones/import", json={"text": "فقط یک ستون"})
    assert response.status_code == 400
    body = response.json()
    assert "detail" in body


def test_import_more_than_40_zones_is_rejected(client) -> None:
    text = "\n".join(f"{4000 + i},{3999 + i}" for i in range(41))
    response = client.post("/api/zones/import", json={"text": text})
    assert response.status_code == 400
    assert "40" in response.json()["detail"]


def test_run_validates_days(client) -> None:
    response = client.post("/api/run?days=0")
    assert response.status_code == 400
    assert "detail" in response.json()


def test_strategy_toggle_roundtrip(client) -> None:
    first = client.post("/api/strategies/zones_m15/toggle").json()
    assert first["enabled"] is False
    status = client.get("/api/status").json()
    slot = next(s for s in status["strategies"] if s["slot"] == "zones_m15")
    assert slot["enabled"] is False

    second = client.post("/api/strategies/zones_m15/toggle").json()
    assert second["enabled"] is True

def test_inconsistent_overrides_are_rejected_on_save(client) -> None:
    # 2% risk with a 1% daily stop is contradictory; the panel must refuse it
    # instead of saving a state that breaks every later run.
    response = client.put(
        "/api/config", json={"profile": "low", "overrides": {"risk_per_trade_pct": 2.0}}
    )
    assert response.status_code == 400
    assert "ناسازگار" in response.json()["detail"]


RETIRED_CONFIG_KEYS = ("min_confirmations", "weak_confluence_mode", "dynamic_tier_margin")


def test_retired_min_confirmations_is_rejected_and_absent(client) -> None:
    # RC 8.2.5 retired min_confirmations; the panel must not pretend to save it.
    response = client.put("/api/config", json={"min_confirmations": 3})
    assert response.status_code == 400
    detail = response.json()["detail"]
    assert "min_confirmations" in detail

    status = client.get("/api/status").json()
    assert "min_confirmations" not in json.dumps(status)
    assert status["effective_config"]["profile"] in {"low", "medium", "high"}


def test_every_retired_config_key_is_rejected_and_not_persisted(client) -> None:
    for key in RETIRED_CONFIG_KEYS:
        response = client.put("/api/config", json={key: 3})
        assert response.status_code == 400, key
        assert key in response.json()["detail"], key

    status = client.get("/api/status").json()
    assert status["profile"] == "medium"
    assert status["direction"] == "both"
    assert status["effective_config"]["overrides"] == {}


def test_unknown_config_key_is_rejected(client) -> None:
    response = client.put("/api/config", json={"yolo_mode": True})
    assert response.status_code == 400
    assert "yolo_mode" in response.json()["detail"]


def test_status_exposes_only_effective_config(client) -> None:
    data = client.get("/api/status").json()
    assert set(data["effective_config"]) == {
        "profile",
        "direction",
        "overrides",
        "disabled_slots",
    }
    blob = json.dumps(data)
    for retired in RETIRED_CONFIG_KEYS:
        assert retired not in blob


def test_invalid_config_payload_is_rejected_with_400(client) -> None:
    response = client.put("/api/config", json={"profile": 123})
    assert response.status_code == 400
    assert "detail" in response.json()
