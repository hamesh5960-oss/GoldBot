"""Cooldown gates A/B/C: hard silence, zone burn and direction concentration."""

from __future__ import annotations

from types import SimpleNamespace

from goldbot.app.decision import Tier
from goldbot.app.gates import CooldownManager, GateParams
from goldbot.domain.model import PositionSnapshot, Symbol
from goldbot.domain.money import money
from goldbot.strategy_api import Zone

from helpers import NOW, make_context, make_info, make_tick

INFO = make_info()


def test_snapshot_restore_roundtrip_keeps_burns_and_counters() -> None:
    manager = CooldownManager()
    manager.bar_index = 120
    manager.last_exec_bar = 118
    manager._burns[("D1", "buy")] = {"until": 125, "reason": "SL", "count": 2}
    manager._sl_counts[("D1", "buy")] = 2
    manager.note_execution(ticket=7, zone_id="D1", side="buy", stop=2000.0)
    manager._session = "london"

    snapshot = manager.snapshot()
    clone = CooldownManager()
    assert clone.restore(snapshot) is True
    assert clone.bar_index == manager.bar_index
    assert clone.last_exec_bar == manager.last_exec_bar
    assert clone.burns() == manager.burns()
    assert clone.snapshot() == snapshot
    assert clone.restore("junk") is False


def position(side: str = "buy", open_price: float = 2000.0, profit: float = 0.0):
    return PositionSnapshot(
        ticket=1,
        symbol=Symbol("XAUUSD"),
        side=side,  # type: ignore[arg-type]
        volume=0.10,
        open_price=open_price,
        sl=open_price - 10.0,
        tp=None,
        magic=1,
        comment="",
        open_time=NOW,
        profit=money(profit),
    )


def evaluate(manager, *, side="buy", signal=0.8, zone=60, setup="rejection", tier=Tier.B, positions=(), price=2000.0):
    manager.bar_index = getattr(manager, "bar_index", 0) or 10
    return manager.evaluate(
        side=side,
        zone_id="Z200000",
        signal_score=signal,
        zone_score=zone,
        setup_type=setup,
        tier=tier,
        atr=2.0,
        adx_h1=20.0,
        positions=positions,
        ctx=make_context(INFO, tick=make_tick(price=price), positions=list(positions)),
    )


def test_gate_a_is_one_candle_of_silence() -> None:
    manager = CooldownManager(GateParams())
    manager.bar_index = 10
    manager.note_execution(ticket=7, zone_id="Z200000", side="buy", stop=1990.0)
    manager.bar_index = 11
    blocked = evaluate(manager)
    assert blocked.rejected
    assert blocked.reason == "GateA_TickNoise"
    manager.bar_index = 12
    assert not evaluate(manager).rejected


def test_gate_b_burn_blocks_weak_and_bypasses_strong() -> None:
    manager = CooldownManager(GateParams())
    manager.bar_index = 10
    manager._burns[("Z200000", "buy")] = {"until": 15, "reason": "SL", "count": 1}

    weak = evaluate(manager, signal=0.4, zone=60)
    assert not weak.rejected
    assert weak.verdict == "downgrade"
    assert weak.size_level.value == "SMALLEST"
    assert weak.size_factor == 0.10
    assert weak.fields["bypass_type"] == "smallest"

    downgraded = evaluate(manager, signal=1.1, zone=72)
    assert downgraded.verdict == "downgrade"
    assert downgraded.size_factor == 0.5

    strong = evaluate(manager, signal=1.6, zone=90, setup="sweep")
    assert strong.verdict == "pass"
    assert strong.fields["bypass_type"] == "full_quality"

    # The full bypass is reserved for sweep / break-retest setups.
    downgraded = evaluate(manager, signal=1.6, zone=90, setup="rejection")
    assert downgraded.verdict == "downgrade"
    assert downgraded.size_level.value == "HALF"


def test_gate_b_twice_burned_zone_is_a_trap() -> None:
    manager = CooldownManager(GateParams())
    manager.bar_index = 10
    manager._burns[("Z200000", "buy")] = {"until": 15, "reason": "SL", "count": 2}
    result = evaluate(manager, signal=0.4, zone=60)
    assert result.rejected
    assert result.reason == "Zone_Burn_Trap"


def test_gate_b_burn_expires() -> None:
    manager = CooldownManager(GateParams())
    manager.bar_index = 10
    manager._burns[("Z200000", "buy")] = {"until": 12, "reason": "TP", "count": 1}
    manager.bar_index = 13
    assert not evaluate(manager, signal=0.4, zone=50).rejected


def test_gate_c_range_allows_one_direction() -> None:
    manager = CooldownManager(GateParams())
    manager.bar_index = 10
    losing = position(profit=-20.0)
    capped = evaluate(manager, positions=[losing], price=1999.0, tier=Tier.C, zone=60, signal=0.5)
    assert not capped.rejected
    assert capped.verdict == "downgrade"
    assert capped.size_level.value == "SMALLEST"


def test_gate_c_downgrades_at_breakeven() -> None:
    manager = CooldownManager(GateParams())
    manager.bar_index = 10
    flat = position(profit=0.0)
    result = evaluate(manager, positions=[flat], price=2000.0, tier=Tier.B, zone=60, signal=0.8)
    assert result.verdict == "downgrade"
    assert result.size_factor == 0.5


def test_gate_c_profit_in_another_zone_passes() -> None:
    manager = CooldownManager(GateParams())
    manager.bar_index = 10
    winner = position(profit=50.0)
    result = evaluate(manager, positions=[winner], price=2003.0, tier=Tier.B, zone=90, signal=0.9)
    assert result.verdict == "pass"
    assert result.fields["bypass_type"] == "profit_other_zone"


def test_hedge_needs_a_losing_position_and_quality() -> None:
    manager = CooldownManager(GateParams())
    manager.bar_index = 10
    losing_short = position(side="sell", open_price=2000.0, profit=-30.0)

    allowed = evaluate(manager, side="buy", positions=[losing_short], price=2003.0, signal=1.2, zone=80)
    assert allowed.hedge
    assert allowed.size_factor == 0.25

    weak = evaluate(manager, side="buy", positions=[losing_short], price=2003.0, signal=0.6, zone=60)
    assert weak.rejected and weak.reason == "Hedge_Weak_Signal"

    winning_short = position(side="sell", open_price=2000.0, profit=40.0)
    blocked = evaluate(manager, side="buy", positions=[winning_short], price=2000.0, signal=1.2, zone=80)
    assert blocked.rejected and blocked.reason == "Hedge_Into_Profit"


def test_structure_break_resets_burns() -> None:
    manager = CooldownManager(GateParams())
    zone = Zone(high=2001.0, low=1999.0)
    manager.bar_index = 10
    manager._burns[(zone.zone_id, "buy")] = {"until": 99, "reason": "SL", "count": 1}
    regime = SimpleNamespace(structure_event="BOS", atr_h1=2.0, atr_h1_median=2.0, session="london")
    manager.on_bar(zones=(zone,), regime=regime)
    assert manager.burns() == {}
