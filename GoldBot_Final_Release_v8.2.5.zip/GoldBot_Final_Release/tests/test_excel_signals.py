"""Excel signal workbook shaping: sheets, widths, JSON cells and validity."""

from __future__ import annotations

import json
import xml.etree.ElementTree as ET
import zipfile
from dataclasses import fields
from pathlib import Path

from goldbot.adapters.xlsx import build_signal_workbook, write_workbook
from goldbot.domain.events import CAPITAL_LEVEL_ORDER, SignalLevelRecord, SignalRecord

MAIN_NS = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"


def _signal(signal_id: str, **overrides: object) -> SignalRecord:
    values: dict[str, object] = {
        "signal_id": signal_id,
        "ts_utc": "2024-03-06T10:00:00+00:00",
        "symbol": "XAUUSD",
        "side": "buy",
        "strategy": "numeric",
        "session": "london",
        "tier": "A",
        "entry": 2000.0,
        "sl": 1990.0,
        "tp1": 2020.0,
        "tp2": 2030.0,
        "gate_status": {"zone": 65, "gate_b": True},
        "params_snapshot": {"profile": "medium"},
        "active_level": "base",
        "active_decision": "executed",
        "active_lot": 0.1,
        "active_risk_dollars": 50.0,
        "best_eligible_level": "base",
    }
    values.update(overrides)
    return SignalRecord(**values)  # type: ignore[arg-type]


def _level(level: str, **overrides: object) -> SignalLevelRecord:
    values: dict[str, object] = {
        "signal_id": "sig-1",
        "level": level,
        "eligible": True,
        "reason": "eligible",
        "would_be_lot": 0.1,
        "capital_gap": 0.0,
        "session": "london",
        "tier": "A",
    }
    values.update(overrides)
    return SignalLevelRecord(**values)  # type: ignore[arg-type]


def _sheets():
    signals = [
        _signal("sig-1"),
        _signal(
            "sig-2",
            ts_utc="2024-03-06T16:00:00+00:00",
            session="ny",
            tier="D",
            tier_base="D",
            confirmation_count=0.0,
            d_hard_floor=True,
            active_decision="watch",
            active_reason="d_hard_floor",
            active_level="",
            outcome="win",
            pnl_dollars=12.5,
            gate_status={},
        ),
    ]
    levels = [
        _level("base", signal_id="sig-1"),
        _level("low_risk", signal_id="sig-1", eligible=False, reason="tier_floor", would_be_lot=None),
        _level("medium_risk", signal_id="sig-1", eligible=False, reason="tier_floor"),
        _level("high_risk", signal_id="sig-1", eligible=False, reason="tier_floor"),
    ]
    return build_signal_workbook(signals, levels)


def test_workbook_has_the_expected_sheets_in_order() -> None:
    sheets = _sheets()
    assert [name for name, _, _ in sheets] == [
        "Signals",
        "Level_Capability",
        "Capability_Matrix",
        "Session_Analysis",
        "Summary",
    ]


def test_signals_sheet_headers_match_the_dataclass() -> None:
    sheets = _sheets()
    headers = list(sheets[0][1])
    assert headers == [item.name for item in fields(SignalRecord)]
    row = list(sheets[0][2][0])
    assert len(row) == len(headers)


def test_signals_json_fields_are_compact_and_sorted() -> None:
    sheets = _sheets()
    headers = list(sheets[0][1])
    row = list(sheets[0][2][0])
    gate_cell = row[headers.index("gate_status")]
    snapshot_cell = row[headers.index("params_snapshot")]
    assert json.loads(gate_cell) == {"gate_b": True, "zone": 65}
    assert json.loads(snapshot_cell) == {"profile": "medium"}
    assert gate_cell == '{"gate_b":true,"zone":65}'  # sorted keys, no spaces
    assert ", " not in gate_cell
    empty_cell = list(sheets[0][2][1])[headers.index("gate_status")]
    assert empty_cell == "{}"


def test_level_capability_has_four_rows_per_signal() -> None:
    sheets = _sheets()
    name, headers, rows = next(item for item in sheets if item[0] == "Level_Capability")
    assert headers == tuple(item.name for item in fields(SignalLevelRecord))
    assert len(rows) == 4 * 2
    signal_one = [row for row in rows if row[0] == "sig-1"]
    assert [row[1] for row in signal_one] == list(CAPITAL_LEVEL_ORDER)
    base = signal_one[0]
    assert base[2] is True
    assert base[3] == "eligible"
    assert base[4] == 0.1
    low = signal_one[1]
    assert low[4] is None
    # a signal with no capability rows still gets four synthetic rows
    signal_two = [row for row in rows if row[0] == "sig-2"]
    assert len(signal_two) == 4
    assert all(row[3] == "not_evaluated" for row in signal_two)
    assert all(row[2] is False for row in signal_two)


def test_capability_matrix_is_wide_one_row_per_signal() -> None:
    sheets = _sheets()
    name, headers, rows = next(item for item in sheets if item[0] == "Capability_Matrix")
    assert list(headers[:7]) == [
        "signal_id",
        "tier",
        "session",
        "active_level",
        "active_decision",
        "was_missed_opportunity",
        "best_eligible_level",
    ]
    for level in CAPITAL_LEVEL_ORDER:
        for metric in ("eligible", "reason", "would_be_lot", "capital_gap"):
            assert f"{level}_{metric}" in headers
    assert len(rows) == 2
    first = list(rows[0])
    assert len(first) == len(headers)
    assert first[headers.index("base_eligible")] is True
    assert first[headers.index("base_reason")] == "eligible"
    assert first[headers.index("low_risk_would_be_lot")] is None
    second = list(rows[1])
    assert second[headers.index("high_risk_eligible")] is None


def test_session_analysis_is_pivot_ready() -> None:
    sheets = _sheets()
    name, headers, rows = next(item for item in sheets if item[0] == "Session_Analysis")
    assert headers == (
        "session",
        "bucket_type",
        "bucket",
        "signals",
        "executed",
        "watch",
        "missed",
        "pnl_dollars",
    )
    assert len({len(row) for row in rows}) == 1
    london_tier = next(
        row for row in rows if row[0] == "london" and row[1] == "tier" and row[2] == "A"
    )
    assert london_tier[3] == 1
    assert london_tier[4] == 1
    ny_tier = next(row for row in rows if row[0] == "ny" and row[1] == "tier" and row[2] == "D")
    assert ny_tier[4] == 0  # a D row is never executed
    assert ny_tier[5] == 1  # but it is counted as watch for display
    output_row = next(
        row for row in rows if row[0] == "ny" and row[1] == "outcome" and row[2] == "win"
    )
    assert output_row[3] == 1
    assert output_row[7] == 12.5
    missed_rows = [row for row in rows if row[1] == "missed"]
    assert any(row[2] == "not_missed" for row in missed_rows)


def test_summary_metadata_and_counts() -> None:
    sheets = _sheets()
    name, headers, rows = next(item for item in sheets if item[0] == "Summary")
    assert headers == ("metric", "value")
    summary = {row[0]: row[1] for row in rows}
    assert summary["sheet_version"] == 1
    assert summary["signals_total"] == 2
    assert summary["signals_executed"] == 1
    assert summary["signals_watch"] == 1
    assert summary["capability_rows"] == 4
    assert summary["signals_with_outcome"] == 1
    assert summary["pnl_dollars_total"] == 12.5
    assert summary["period_start"] == "2024-03-06T10:00:00+00:00"
    assert summary["period_end"] == "2024-03-06T16:00:00+00:00"
    assert summary["levels_per_signal"] == 4


def test_legacy_mode_returns_one_classic_sheet() -> None:
    signals = [_signal("sig-1", outcome="win", pnl_dollars=12.5), _signal("sig-2", pnl_dollars=-4.0)]
    sheets = build_signal_workbook(signals, [], legacy=True)
    assert len(sheets) == 1
    name, headers, rows = sheets[0]
    assert name == "Signals"
    assert headers == (
        "row",
        "open_time",
        "close_time",
        "strategy",
        "side",
        "symbol",
        "entry",
        "exit",
        "volume",
        "profit",
        "loss",
        "net",
        "r_multiple",
        "exit_reason",
        "profile",
    )
    assert len(rows) == 2
    assert len(rows[0]) == len(headers)
    first = list(rows[0])
    assert first[0] == 1
    assert first[8] == 0.1  # volume
    assert first[9] == 12.5  # profit
    assert first[11] == 12.5  # net
    assert first[13] == "win"  # exit reason mirrors the outcome
    second = list(rows[1])
    assert second[9] == 0.0
    assert second[10] == 4.0  # loss
    assert second[11] == -4.0


def test_all_sheets_have_equal_row_widths() -> None:
    sheets = _sheets()
    for name, headers, rows in sheets:
        assert rows, name
        for row in rows:
            assert len(row) == len(headers), name


def test_build_is_deterministic() -> None:
    assert build_signal_workbook(
        [_signal("sig-1")], [_level("base", signal_id="sig-1")]
    ) == build_signal_workbook([_signal("sig-1")], [_level("base", signal_id="sig-1")])


def test_workbook_xml_is_well_formed_and_has_no_merged_cells(scratch: Path) -> None:
    out = scratch / "signals.xlsx"
    write_workbook(out, _sheets())
    with zipfile.ZipFile(out) as archive:
        names = archive.namelist()
        sheet_parts = sorted(
            name for name in names if name.startswith("xl/worksheets/sheet") and name.endswith(".xml")
        )
        assert len(sheet_parts) == 5
        workbook = archive.read("xl/workbook.xml").decode("utf-8")
        for sheet_name in ("Signals", "Level_Capability", "Capability_Matrix", "Session_Analysis", "Summary"):
            assert sheet_name in workbook
        for part in sheet_parts:
            data = archive.read(part).decode("utf-8")
            assert "mergeCell" not in data
            root = ET.fromstring(data)
            rows = root.findall(f".//{{{MAIN_NS}}}sheetData/{{{MAIN_NS}}}row")
            assert rows


def test_none_values_become_blank_cells_without_breaking_the_write(scratch: Path) -> None:
    signal = _signal("sig-null", entry=None, active_lot=None, gate_status={})
    sheets = build_signal_workbook([signal], [])
    headers = list(sheets[0][1])
    row = list(sheets[0][2][0])
    assert row[headers.index("entry")] is None
    assert row[headers.index("gate_status")] == "{}"
    out = scratch / "nulls.xlsx"
    write_workbook(out, sheets)
    with zipfile.ZipFile(out) as archive:
        sheet = archive.read("xl/worksheets/sheet1.xml").decode("utf-8")
    assert "<sheetData>" in sheet
