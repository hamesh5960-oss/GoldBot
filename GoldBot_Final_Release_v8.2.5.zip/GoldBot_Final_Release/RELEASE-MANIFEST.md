# Release Manifest — GoldBot 8.2.5 Final Engineering Release

- **Package version:** 8.2.5 (runtime `goldbot.__version__ == "8.2.5"`)
- **Baseline:** GoldBot v8.2.5 Engineering RC
- **Scope:** XAUUSD / MetaTrader 5، استراتژی‌های `zones` و `numeric`، پنل محلی و ابزار استقرار پنل VPS.
- **Platform:** Windows برای MT5، Linux برای پنل/بک‌تست.
- **Python:** >= 3.12 (آزمون‌شده: 3.14.7)
- **وضعیت:** READY FOR DEMO VALIDATION — مجوز پول واقعی نیست.
- **تاریخ ساخت:** 2026-11-21

## اعداد تحویل

| مورد | مقدار |
|---|---|
| فایل‌های تست | 79 |
| تست‌های اجراشده | 1,084 PASS / 0 FAIL |
| زمان full suite | ≈128 s |
| ADRها | 046 |
| بک‌تست واقعی | 120 روز، 147 معامله، PF 0.95، خالص −158.34 |
| بک‌تست ۱۰۰ روزهٔ مصنوعی | 147 معامله، PF 1.37، +1,129.10 |
| SHA-256 | `SHA256SUMS` (همهٔ فایل‌ها) |

## ساختار

```
src/goldbot/{domain,ports,app,adapters,runtime,strategy_api,web}
src/strategies/{numeric,zones}
config/  tests/  docs/ (adr/ + architecture)  scripts/  reports/  archive/
```

## چک‌سام و تأیید

- `SHA256SUMS` شامل hash همهٔ ۲۹۳ فایل تحویلی است (۲۹۳/۲۹۳ تأیید شد).
- بسته پس از ساخت در یک پوشهٔ خالی استخراج و از همان پوشه تست شد: 1,082 passed، 2 skipped (soak lane)، 1 xfailed، exit 0.
- `MANIFEST.sha256` قدیمی RC حذف شد؛ مرجع یکتای چک‌سام `SHA256SUMS` است.
- بسته پس از ساخت، در یک پوشهٔ خالی استخراج و از همان پوشه تست شد (نتیجه در `TEST-REPORT.md` و گزارش نهایی).

## تأییدیه‌ها

- هیچ P0 باز در مسیر معاملاتی وجود ندارد.
- P1های شناسایی‌شده رفع یا با دلیل صریح به عنوان ریسک باقی‌مانده مستند شده‌اند (`KNOWN-ISSUES.md`).
- بک‌تست منفی است و هیچ ادعای سودآوری وجود ندارد.
