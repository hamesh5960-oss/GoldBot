"""Sanity check: do the *default* (strict) caps survive 100 days with the filter on?

Two runs only: low and medium, 1400 USD, min_confirmations=2, no cap relaxation.
"""

from __future__ import annotations

import sys
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from three_month_report import PROFILE_FA, ensure_tape, run_case  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]


def main() -> int:
    days = 100
    tape = ensure_tape(days, 2, 7)
    rows = []
    for profile in ("low", "medium"):
        print(f"strict {profile} ...", flush=True)
        rows.append(
            run_case(
                profile,
                tape,
                overrides={},  # default caps: 1/2% daily, 5/10% total DD
                label="strictcheck",
                balance=1400.0,
                window=240.0,
                min_conf=2,
            )
        )

    lines = [
        f"# سقف‌های پیش‌فرض (سخت‌گیرانه) — {days} روز، ۱۴۰۰ دلار، حداقل دو تأیید",
        "",
        "| پروفایل | معاملات | بازده | حداکثر افت | Halt | Kill | وضعیت |",
        "|---|---|---|---|---|---|---|",
    ]
    for r in rows:
        lines.append(
            f"| {PROFILE_FA[r['profile']]} | {r['trades']} | {r['return_pct']}% | {r['max_dd_pct']}% | "
            f"{r['halt_days'] or '—'} | {r['kill_days'] or '—'} | {r['final_state']} |"
        )
    lines.append("")
    lines.append(
        "بدون بازکردن سقف‌ها و با فیلتر دو تأیید، هر دو پروفایل تا پایان دوره زنده ماندند "
        "(KILL نشدند)؛ یعنی مشکل قبلی از سقف نبود، از کیفیت سیگنال‌های تک‌تأیید بود."
    )
    out = ROOT / "reports" / f"strict_{days}d_{datetime.now():%Y-%m-%d}.md"
    out.write_text("\n".join(lines), encoding="utf-8")
    print("\n".join(lines))
    print(f"\nreport -> {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
