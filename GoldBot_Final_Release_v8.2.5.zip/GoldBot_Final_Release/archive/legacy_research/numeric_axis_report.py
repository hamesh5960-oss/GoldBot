"""Numeric-axis 100-day study.

The numeric strategy is the only trader; FVG+MA and MA-trend act as
confirmation-only strategies. A numeric signal that stands alone targets 1R
(SL 50 pips / TP 50 pips); when another strategy confirms it, the target
doubles to 2R (SL 50 / TP 100).

Output: an Excel workbook (summary + per-profile trades + capital scan).

Run:
    python scripts/numeric_axis_report.py --days 100 --balance 1400
"""

from __future__ import annotations

import argparse
import sys
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from goldbot.adapters.config import load_settings  # noqa: E402
from goldbot.adapters.tape import write_synthetic_tape  # noqa: E402
from goldbot.adapters.xlsx import write_workbook  # noqa: E402
from goldbot.runtime.bootstrap import build_components  # noqa: E402
from strategies.registry import load_instances  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
PROFILE_FA = {"low": "کم‌ریسک", "medium": "متوسط", "high": "پرخطر"}
LOOSE = {
    "max_daily_loss_pct": 10.0,
    "max_total_dd_pct": 25.0,
    "max_consecutive_losses": 10,
    "max_orders_per_day": 40,
}


def ensure_tape(days: int, tpm: int, seed: int) -> Path:
    path = ROOT / "var" / f"tape_{days}d_{tpm}tpm_seed{seed}.jsonl"
    if path.exists():
        return path
    print(f"building tape {days}d ...", flush=True)
    write_synthetic_tape(
        path,
        symbol="XAUUSD",
        start=datetime(2024, 3, 3),
        days=days,
        ticks_per_minute=tpm,
        seed=seed,
    )
    return path


def run_case(profile: str, tape: Path, *, balance: float, overrides: dict, window: float, label: str, min_conf: int = 1) -> dict:
    settings = load_settings(ROOT / "config" / "base.toml")
    trading = settings.trading.model_copy(
        update={"confluence_window_minutes": window, "min_confirmations": min_conf}
    )
    settings = settings.model_copy(update={"trading": trading})

    instances = [
        inst
        for inst in load_instances(settings.strategies.directory, include_disabled=True)
        if inst.enabled
    ]
    for inst in instances:
        inst.confirm_only = inst.strategy_id != "numeric"

    db = ROOT / "var" / f"numaxis_{profile}_{label}.db"
    for suffix in ("", "-wal", "-shm"):
        candidate = Path(str(db) + suffix)
        if candidate.exists():
            candidate.unlink()

    comp = build_components(
        settings,
        tape_path=tape,
        profile_name=profile,
        extra_overrides=dict(overrides),
        instances=instances,
        db_path=db,
        initial_balance=balance,
    )
    try:
        result = comp.engine.run()
        stats = comp.journal.stats()
        trades = comp.journal.trades()
    finally:
        comp.close()

    singles = [t for t in trades if len(t.confirmations) <= 1]
    multis = [t for t in trades if len(t.confirmations) >= 2]
    volumes = [t.volume for t in trades if t.volume]
    start = balance
    end = stats.get("end_equity", start)
    return {
        "profile": profile,
        "label": label,
        "trades": len(trades),
        "singles": len(singles),
        "multis": len(multis),
        "single_net": round(sum(t.pnl_net for t in singles), 2),
        "multi_net": round(sum(t.pnl_net for t in multis), 2),
        "single_win": round(sum(1 for t in singles if t.pnl_net > 0) / len(singles) * 100, 1) if singles else 0.0,
        "multi_win": round(sum(1 for t in multis if t.pnl_net > 0) / len(multis) * 100, 1) if multis else 0.0,
        "win_rate": stats.get("win_rate", 0.0),
        "pf": stats.get("profit_factor", 0.0),
        "net": round(stats.get("net", 0.0), 2),
        "start": start,
        "end": round(end, 2),
        "return_pct": round((end / start - 1) * 100, 2) if start else 0.0,
        "max_dd_pct": stats.get("max_dd_pct", 0.0),
        "avg_volume": round(sum(volumes) / len(volumes), 3) if volumes else 0.0,
        "final_state": result.final_state,
        "rejects": result.rejects,
        "trades_list": trades,
    }


def trade_rows(trades) -> list[list]:
    rows: list[list] = []
    for i, t in enumerate(trades, start=1):
        risk = abs(t.open_price - (t.sl or t.open_price))
        reward = abs((t.tp or t.open_price) - t.open_price)
        rr = round(reward / risk, 2) if risk else ""
        confirmed = len(t.confirmations) >= 2
        rows.append(
            [
                i,
                (t.open_time or "").replace("T", " ")[:16],
                (t.close_time or "").replace("T", " ")[:16],
                "خرید" if t.side == "buy" else "فروش",
                t.volume,
                t.open_price,
                t.close_price,
                t.sl,
                t.tp,
                rr,
                "چندتأیید (2R)" if confirmed else "تک‌تأیید (1R)",
                " + ".join(t.confirmations) if t.confirmations else t.strategy,
                t.exit_reason,
                round(t.pnl_net, 2),
                t.r_multiple,
                "برد" if t.pnl_net > 0 else "باخت",
            ]
        )
    return rows


TRADE_HEADERS = [
    "ردیف", "ورود", "خروج", "جهت", "حجم", "قیمت ورود", "قیمت خروج", "حد ضرر", "حد سود",
    "R:R", "نوع تأیید", "تأییدکننده‌ها", "دلیل خروج", "خالص ($)", "R", "نتیجه",
]


def summary_rows(cases: list[dict]) -> list[list]:
    rows = []
    for c in cases:
        rows.append(
            [
                PROFILE_FA[c["profile"]],
                "سقف باز" if c["label"] == "loose" else "سخت‌گیرانه",
                c["trades"],
                c["singles"],
                c["multis"],
                c["single_net"],
                c["multi_net"],
                c["single_win"],
                c["multi_win"],
                c["win_rate"],
                c["pf"],
                c["return_pct"],
                c["max_dd_pct"],
                c["final_state"],
            ]
        )
    return rows


SUMMARY_HEADERS = [
    "پروفایل", "سقف‌ها", "معاملات", "تک‌تأیید (1R)", "چندتأیید (2R)",
    "خالص تک‌تأیید", "خالص چندتأیید", "برد تک‌تأیید٪", "برد چندتأیید٪",
    "برد کل٪", "PF", "بازده٪", "حداکثر افت٪", "وضعیت",
]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--days", type=int, default=100)
    parser.add_argument("--balance", type=float, default=1400.0)
    parser.add_argument("--seed", type=int, default=7)
    parser.add_argument("--tpm", type=int, default=2)
    parser.add_argument("--window", type=float, default=240.0)
    parser.add_argument("--capitals", default="500,1400,3000,6000")
    parser.add_argument("--min-confirmations", type=int, default=1)
    parser.add_argument("--profiles", default="low,medium,high")
    parser.add_argument("--suffix", default="")
    args = parser.parse_args()
    profiles = [p for p in args.profiles.split(",") if p.strip()]

    tape = ensure_tape(args.days, args.tpm, args.seed)
    cases: list[dict] = []
    for profile in profiles:
        print(f"{profile} loose ...", flush=True)
        cases.append(run_case(profile, tape, balance=args.balance, overrides=LOOSE, window=args.window, label="loose", min_conf=args.min_confirmations))
    for profile in profiles:
        print(f"{profile} strict ...", flush=True)
        cases.append(run_case(profile, tape, balance=args.balance, overrides={}, window=args.window, label="strict", min_conf=args.min_confirmations))

    capital_rows: list[list] = []
    for cap in (float(x) for x in args.capitals.split(",") if x.strip()):
        print(f"capital {cap:.0f} ...", flush=True)
        row = run_case("low", tape, balance=cap, overrides=LOOSE, window=args.window, label="cap", min_conf=args.min_confirmations)
        capital_rows.append(
            [f"{cap:.0f}$", row["trades"], row["avg_volume"], row["return_pct"], row["max_dd_pct"],
             row["rejects"].get("volume", 0), row["final_state"]]
        )

    stamp = datetime.now().strftime("%Y-%m-%d")
    out_dir = ROOT / "reports"
    out_dir.mkdir(exist_ok=True)
    path = out_dir / f"numeric_axis_{args.days}d_{stamp}{('_' + args.suffix) if args.suffix else ''}.xlsx"

    sheets = [("خلاصه", SUMMARY_HEADERS, summary_rows(cases))]
    for profile in ("low", "medium", "high"):
        loose = next(c for c in cases if c["profile"] == profile and c["label"] == "loose")
        sheets.append((PROFILE_FA[profile], TRADE_HEADERS, trade_rows(loose["trades_list"])))
    sheets.append(("سرمایه", ["سرمایه", "معاملات", "حجم میانگین", "بازده٪", "افت٪", "رد حجم", "وضعیت"], capital_rows))
    write_workbook(path, sheets)

    print("\nخلاصه:")
    for c in cases:
        print(
            f"  {PROFILE_FA[c['profile']]:<8} {c['label']:<7} trades={c['trades']:<4} "
            f"single={c['singles']:<3} multi={c['multis']:<3} ret={c['return_pct']:>7}% "
            f"dd={c['max_dd_pct']:>6}% {c['final_state']}"
        )
    print(f"\nexcel -> {path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
