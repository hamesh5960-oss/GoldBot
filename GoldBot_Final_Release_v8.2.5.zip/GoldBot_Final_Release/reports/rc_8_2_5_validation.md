# GoldBot RC 8.2.5 — گزارش اعتبارسنجی این بسته

**وضعیت:** Engineering RC — not approved for unattended live or real-money trading.

## کنترل‌های انجام‌شده

| کنترل | نتیجه | جزئیات |
|---|---|---|
| سلامت ZIP ورودی | PASS | آرشیو ورودی بدون خطای ساختاری باز شد. |
| Compile | PASS | `compileall` روی سورس، اسکریپت‌ها و launcher. |
| تست خودکار | PASS | 56 تست در `tests/`، همگی سبز. |
| پیکربندی TOML | PASS | چهار فایل TOML parse و schema validation شدند. |
| CLI launcher | PASS | `python run_goldbot.py --help` و console script `goldbot --help`. |
| پنل وب | PASS (import) | ماژول FastAPI در محیط آزمون import شد؛ آزمون امنیتی/دسترسی راه دور کامل نیست. |
| Smoke test | PASS با محدودیت | 5,760 tick، 191 bar، 12 سیگنال؛ 0 سفارش تأییدشده و 0 معامله. این smoke فقط مسیر اجرا را بررسی می‌کند. |
| بک‌تست مصنوعی 10 روزه | اجرا شد؛ عملکرد منفی | 20,160 tick، 671 bar، 41 سیگنال ورودی، 14 معامله؛ net = -222.79 USD، PF = 0.41، MaxDD = 3.3%. داده synthetic/random walk است. |
| بازرسی ژورنال 10 روزه | PASS | seen=41، journaled=41، unlogged=0؛ سیگنال اجراشدهٔ بدون معامله=0 و معاملهٔ بدون سیگنال=0. |
| بک‌تست 100 روزه | INCOMPLETE / TIMEOUT | اجرای آزمایشی در محیط فعلی از محدودیت 240 ثانیه عبور کرد؛ خروجی ناقص کنار گذاشته شد و هیچ نتیجه‌ای از آن گزارش نمی‌شود. |
| MT5 terminal integration | NOT RUN | محیط آزمون Linux است و پکیج/ترمینال MetaTrader5 ویندوزی در دسترس نبود. |
| جلسهٔ دمو با بروکر | NOT RUN | نیازمند Windows، ترمینال ePlanet و نظارت اپراتور. |
| اجرای پول واقعی | NOT AUTHORIZED | این RC مجوز اجرای حساب واقعی نیست. |

## پروفایل عملکرد

اجرای `cProfile` روی tape مصنوعی ۱۰روزه حدود 10.12M فراخوانی و 8.17 ثانیه زمان instrumented نشان داد. نقاط داغ شامل SQLite commit، heartbeat/fsync، reconciliation و resample H1 هستند؛ جزئیات و برنامهٔ بهینه‌سازی در `docs/PERFORMANCE-BASELINE.md` آمده است. وضعیت performance optimization هنوز OPEN است.

## اصلاحات کد مهم

1. اصلاح مثبت کاذب در تشخیص تأیید استراتژی دیگر: مقایسه اکنون بر اساس strategy ID انجام می‌شود، نه slot ID (`zones` در برابر `zones_m15`) — ADR-041.
2. اصلاح بازیابی Gate A برای حفظ `last_exec_bar=0` و جلوگیری از دور زدن پنجرهٔ سکوت پس از restart — ADR-042.
3. آزادسازی اتصال MT5 در مسیرهای setup failure و پایان نشست — ADR-043.
4. حذف فراخوانی دوبارهٔ SSH connect، هم‌ترازی نسخهٔ Python، و سخت‌سازی host-key/token handling در استقرار VPS — ADR-044 و ADR-046.
5. جلوگیری از cold-start خودکار در launcher زنده؛ cold-start فقط با flag صریح و تأیید عدم وجود پوزیشن باز — ADR-045.
6. حذف کنترل قدیمی `min_confirmations`، `weak_confluence_mode` و تنظیمات Composite از CLI، پیکربندی و پنل؛ به‌روزرسانی متن‌های ریسک/حجم پنل.
7. افزودن launcher، pyproject، تست‌های بازسازی‌شده و گزارش وضعیت پوشش.

## تفسیر و محدودیت

- 56 تست فعلی معادل 837 تست تاریخی ادعاشده نیست؛ فایل‌های تست تاریخی در ZIP ورودی موجود نبودند.
- نتیجهٔ 10 روزهٔ synthetic منفی است و باید به‌عنوان هشدار دربارهٔ کیفیت عملکرد روی همین tape تلقی شود، نه پیش‌بینی بازار واقعی.
- برای پذیرش عملی، ابتدا بک‌تست 100 روزهٔ قابل‌تکرار باید با زمان اجرای قابل قبول تکمیل شود؛ سپس walk-forward روی دادهٔ واقعی XAUUSD، fake-terminal tests، آزمون ویندوزی MT5، dry-run و نشست دمو تحت نظارت اجرا شوند.
- تا زمان بسته‌شدن موارد فوق، وضعیت `READY FOR LIVE` صادر نمی‌شود.
