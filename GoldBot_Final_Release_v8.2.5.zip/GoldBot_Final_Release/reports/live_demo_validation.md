# Live MT5 Demo Validation — 2026-11-21 (Tehran)

## هدف

اثبات اینکه زنجیرهٔ startup → اتصال MT5 → cold start → reconcile → session → journal/heartbeat روی حساب دمو کار می‌کند و در شرایط بستهٔ بازار هیچ سفارشی نمی‌فرستد.

## تنظیمات اجرا

- حساب: دمو **80180927** @ `ePlanet-MT5` (hedging، balance 11,087.42 USD)، نماد `XAUUSD.st`، ترمینال build 6238.
- دستور: `python run_goldbot.py live --profile medium --db var/demo_validate.db --state-db var/demo_validate_state.db --cold-start`
- اعتبارنامه از `GOLDBOT_MT5_PASSWORD_FILE` (argv خالی)؛ پروفایل medium.
- زمان: 2026-11-20 **23:20 UTC** (2026-11-21 02:50 تهران) — **بازار بسته (آخر هفته)**.

## شواهد ژورنال (17 رویداد)

| رویداد | تعداد | معنا |
|---|---:|---|
| ConfigLoaded | 1 | پیکربندی معتبر، بدون کلید بازنشسته |
| SessionStarted | 1 | سشن موتور آغاز شد |
| LiveArmed | 1 | اجازهٔ ورود فعال (دمو، trade_allowed) |
| RiskStateRestored | 1 | state ریسک از صفر بازیابی شد (cold start مجاز) |
| ReconcileStarted / Completed | 2 / 2 | تطبیق اولیه + تطبیق پس از بستن آخر هفته، بدون واگرایی |
| StrategyStarted / WarmedUp | 2 / 2 | هر دو استراتژی warm-up شدند |
| DailyLevelsReady | 1 | سطوح روزانه از ۹٬۵۹۹ کندل M15 |
| WeekendClosePlan | 1 | پلن بستن آخر هفته به‌صورت قطعی ساخته شد |
| FlattenCompleted | 1 | هیچ پوزیشنی برای بستن نبود (کتاب خالی) و ادعای flat فقط پس از تأیید |
| Heartbeat | 2 | تپش هر ۵ دقیقه، بدون توقف |

**سیگنال: 0 · سفارش: 0 · پوزیشن: 0** — مطابق انتظار چون بازار بسته است.

## رفتار fail-closed تأییدشده

- تیک‌های MT5 کهنه تشخیص داده شدند (`MT5 tick is stale (market closed?)`) و هیچ تحلیلی/ورودی صادر نشد.
- گارد سشن: قبل از این اصلاح، startup با جدول placeholder رد می‌شد؛ پس از تنظیم جدول واقعی بروکر (`01:05-23:55`)، startup عبور کرد. یعنی گارد هم مثبت کاذب ندارد و هم placeholder را رد می‌کند (تست‌های `test_live_cleanup`).
- رمز در argv رد شد (SEC-02)؛ اجرای مستقیم بدون فایل رمز، exit 2 می‌دهد.

## آنچه تأیید **نشد** (صادقانه)

- ارسال سفارش واقعی، پر شدن، بستن، trailing و kill-flatten روی venue به‌دلیل بسته بودن بازار اجرا نشد.
- رفتار settlement با history واقعی بروکر دیده نشد.
- نشست طولانی ۲۴/۵ روی VPS ویندوز اجرا نشد.

## نتیجه

**READY FOR DEMO VALIDATION**: زنجیرهٔ startup/recovery/journal روی حساب دموی واقعی کار می‌کند و در بازار بسته امن می‌ماند. برای تأیید اجرای سفارش، یک نشست دمو در ساعات باز بازار (دوشنبه–جمعه) لازم است.
