# Configuration Guide — GoldBot 8.2.5

همهٔ کلیدها در `config/base.toml` (و پروفایل‌ها در `config/risk_profiles.toml`) هستند. مدل‌ها `extra="forbid"` دارند: هر کلید ناشناخته یا بازنشسته باعث خطای startup می‌شود (fail loud).

## [symbol]

| کلید | معنا | مقدار مرجع |
|---|---|---|
| `broker_symbol` | نماد واقعی بروکر | `XAUUSD.st` |
| `digits` / `point` / `contract_size` | مشخصات ابزار (از MT5 بازخوانی و تطبیق می‌شود) | 2 / 0.01 / 100 |
| `min_volume`/`max_volume`/`volume_step` | محدودیت حجم | 0.01 / 50 / 0.01 |
| `stops_level_points` / `freeze_level_points` | حداقل فاصلهٔ SL/TP از بروکر | 30 / 0 (ePlanet) |
| `filling_mode` | `fok`/`ioc`/`return`/`unknown`؛ ePlanet = IOC | `ioc` |
| `broker_offset_hours` | اختلاف ساعت سرور (آداپتور از ticks بازکالیبره می‌کند) | 2 |
| `sessions` | قالب روزانهٔ سشن به وقت بروکر | `["01:05-23:55"]` |

> `sessions` باید تقویم واقعی بروکر باشد. جدول placeholder `00:00-23:59` در live رد می‌شود. تغییر آن روی weekend flatten و Gateهای سشن اثر دارد.

## [risk]

| کلید | معنا |
|---|---|
| `profile` | low/medium/high |
| `profiles_path` | مسیر TOML پروفایل‌ها (محتوایش در config_hash می‌آید) |
| `[risk.overrides]` | override دستی؛ محدود به بازه‌های سخت کد |

## [execution]

`magic_base` (پایهٔ magic)، `slippage_points`، `commission_per_lot` (باید با `[costs].commission_per_lot_rt` برابر باشد)، `max_slippage_points`.

## [costs]

`commission_per_lot_rt`، `point`، `contract_size`، اسپرد/اسلیپیج/سواپ. سه ثابت تکراری باید با `[symbol]`/`[execution]` برابر باشند وگرنه startup خطا می‌دهد (ADR-019).

## [risk] / Gate D

- `gate_d_max_risk_pct` = soft (2.0)
- `gate_d_hard_pct` = hard (3.0 در config؛ پیش‌فرض کد 2.0)
- `portfolio_ceiling_pct` = 3.0
- بین soft و hard حجم نصف می‌شود؛ بالای hard رد (ADR-001).

## [weekend]

`enabled`، `close_minutes_before_session_end` (30)، `close_order` (profit_first/loss_first/ticket)، `max_deviation_points`، `fallback_grace_minutes`. ترتیب بستن اجباری و قطعی است.

## [news]

`enabled`، `calendar_source` (csv)، `calendar_path`، پنجره‌های before/after، `fail_safe=conservative`. در نبود تقویم، پنجره‌های ثابت UTC با تصحیح DST آمریکا اعمال می‌شوند (ADR-023).

## [journal] / [state]

مسیر `live.db` و `live.state.db`؛ `GOLDBOT_STATE_DB` بر `--state-db` اولویت دارد (ADR-016). heartbeat در `<journal>.heartbeat.json` نوشته می‌شود تا دمو/بک‌تست heartbeat زنده را خراب نکند.

## کلیدهای بازنشسته (خطا می‌دهند)

`min_confirmations`، `weak_confluence_mode`، `dynamic_tier_margin`، کلیدهای composite scoring. مرجع: ADR-031/033/034.

## متغیرهای محیطی

| متغیر | کاربرد |
|---|---|
| `GOLDBOT_MT5_LOGIN` / `GOLDBOT_MT5_PASSWORD` / `GOLDBOT_MT5_PASSWORD_FILE` | اعتبارنامه |
| `GOLDBOT_MT5_SERVER` / `GOLDBOT_MT5_SYMBOL` / `GOLDBOT_MT5_PATH` | اتصال |
| `GOLDBOT_STATE_DB` | مسیر state |
| `GOLDBOT_PANEL_TOKEN` | توکن پنل |
| `GOLDBOT_LOG_PATH` / `GOLDBOT_LOG_MAX_BYTES` / `GOLDBOT_LOG_BACKUPS` | لاگ چرخشی |
| `GOLDBOT_SOAK` | `0` = رد کردن تست soak |
