# Installation Guide — GoldBot 8.2.5

## ۱. پیش‌نیازها

- **Windows 10/11 یا Windows Server 2019+** برای اجرای MT5 (ترمینال MetaTrader 5 و پکیج `MetaTrader5` فقط ویندوزی است).
- Python **3.12+** (آزمون‌شده روی 3.14.7). `python --version` را چک کنید.
- ترمینال ePlanet MT5 نصب‌شده و AutoTrading روشن.
- حداقل ۲ گیگابایت RAM و ۱ گیگابایت فضای دیسک برای journal/rotation.

## ۲. استخراج و نصب

```powershell
Expand-Archive GoldBot_Final_Release_v8.2.5.zip -DestinationPath C:\GoldBot
cd C:\GoldBot
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -e .
python -m pip install -e ".[web,mt5,test]"
```

بررسی سلامت نصب:

```powershell
python run_goldbot.py --help
python -m pytest -q          # باید 1,067 تست سبز باشد (≈106 ثانیه)
```

## ۳. پیکربندی

1. `config/base.toml` را باز کنید (کلیدها: `CONFIGURATION-GUIDE.md`).
2. مطمئن شوید:
   - `[symbol].broker_symbol = "XAUUSD.st"`
   - `[symbol].sessions = ["01:05-23:55"]` (تقویم واقعی بروکر)
   - `[symbol].broker_offset_hours = 2`
3. اعتبارنامه فقط از محیط/فایل:

```powershell
$env:GOLDBOT_MT5_LOGIN='80180927'
$env:GOLDBOT_MT5_SERVER='ePlanet-MT5'
$env:GOLDBOT_MT5_SYMBOL='XAUUSD.st'
$env:GOLDBOT_MT5_PASSWORD_FILE='C:\secure\mt5.pw'   # یک‌خطی، دسترسی فقط کاربر جاری
```

## ۴. اولین اجرای دمو (Cold Start)

```powershell
python run_goldbot.py live --profile medium --db var/live.db --state-db var/live.state.db --cold-start
```

`--cold-start` فقط برای بار اول یا پس از پاک‌کردن state DB. اگر state DB موجود باشد و `--cold-start` بدهید، عمداً رد می‌شود (ADR-045). اگر state DB نباشد و `--cold-start` ندهید، قبل از اتصال به MT5 رد می‌شود.

خروجی مورد انتظار: بنر حساب/سرور، `LiveArmed`، `SessionStarted`، `DailyLevelsReady` و heartbeat هر ۵ دقیقه. در `var/live.db` رویدادها و ژورنال سیگنال ثبت می‌شوند.

## ۵. اجرای دائمی با Task Scheduler

```powershell
schtasks /Create /TN GoldBotLive /SC ONLOGON /RL HIGHEST /TR "powershell -NoProfile -ExecutionPolicy Bypass -File C:\GoldBot\scripts\run_live_task.ps1"
```

- `run_live_task.ps1` لاگ را در `var/live.log` به‌صورت چرخشی (۵ MiB × ۵) می‌نویسد.
- `start_live.ps1` قفل انحصاری `var/live.lock` می‌گیرد: اجرای دوم با **exit code 3** و پیام `already running` خارج می‌شود (برای Task Scheduler بی‌خطر است).
- رمز را در argv ندهید؛ launcher آن را رد می‌کند.

## ۶. پنل وب (اختیاری)

```powershell
python run_goldbot.py serve --host 127.0.0.1 --port 8000
```

توکن پنل از `GOLDBOT_PANEL_TOKEN` خوانده می‌شود. برای دسترسی از راه دور، آن را پشت reverse proxy با TLS بگذارید (SECURITY-REPORT).

## ۷. عیب‌یابی سریع

| نشانه | علت احتمالی | راه‌حل |
|---|---|---|
| `سشن‌های بروکر قابل اعتماد نیست` | `[symbol].sessions` هنوز placeholder است | جدول واقعی بروکر را تنظیم کنید |
| `MT5 tick is stale (market closed?)` | بازار بسته (آخر هفته/تعطیلی) | طبیعی است؛ هیچ ورودی صادر نمی‌شود |
| exit code 3 | نشست دیگری فعال است | `var/live.lock`؛ فرآیند قبلی را بررسی کنید |
| `cold start` رد شد | state DB موجود است | بدون `--cold-start` اجرا کنید |
| `رمز عبور نباید در آرگومان...` | `--password` داده‌اید | از env یا فایل استفاده کنید |
| تست‌ها با خطای permission روی TEMP | سیاست sandbox میزبان | پوشهٔ `var/tests` داخل پروژه استفاده می‌شود؛ با همان کاربر اجرا کنید |

## ۸. به‌روزرسانی و پشتیبان

- قبل از هر به‌روزرسانی: `var/live.db`، `var/live.state.db*` و `config/` را کپی کنید.
- پس از به‌روزرسانی: `python -m pytest -q` و سپس `python run_goldbot.py health --db var/live.db`.
- برای بازگشت: پوشهٔ قبلی + بکاپ `var/` را برگردانید.
