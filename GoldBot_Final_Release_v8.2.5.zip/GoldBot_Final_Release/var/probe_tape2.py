import sys
sys.path.insert(0, "src")
from datetime import datetime, timezone
from pathlib import Path
from goldbot.adapters.tape import write_synthetic_tape
for d in (1, 2):
    p = Path("var/tests/probe-tape/tape-%dd.jsonl" % d)
    p.parent.mkdir(parents=True, exist_ok=True)
    write_synthetic_tape(p, symbol="XAUUSD", start=datetime(2024,3,3,tzinfo=timezone.utc), days=d, ticks_per_minute=2, seed=13)
    n = sum(1 for _ in open(p, encoding="utf-8"))
    print("days", d, "bytes", p.stat().st_size, "lines", n)
