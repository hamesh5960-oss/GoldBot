import sys, os
sys.path.insert(0, "src")
from datetime import datetime, timezone
from pathlib import Path
from goldbot.adapters.tape import write_synthetic_tape
p = Path("var/tests/probe-tape/tape.jsonl")
p.parent.mkdir(parents=True, exist_ok=True)
write_synthetic_tape(p, symbol="XAUUSD", start=datetime(2024,3,3,tzinfo=timezone.utc), days=2, ticks_per_minute=2, seed=13)
print("size", p.stat().st_size)
print(open(p, encoding="utf-8").readline()[:200])
