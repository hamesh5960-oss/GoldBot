import os, MetaTrader5 as mt5
print([n for n in dir(mt5) if "session" in n.lower() or "symbol_info" in n.lower()])
path = r"C:\Program Files\ePlanet MetaTrader 5 Terminal\terminal64.exe"
login = int(os.environ["GOLDBOT_MT5_LOGIN"]); pw = open(os.environ["GOLDBOT_MT5_PASSWORD_FILE"], encoding="utf-8").read().strip()
ok = mt5.initialize(path=path, login=login, password=pw, server=os.environ["GOLDBOT_MT5_SERVER"])
print("init", ok, mt5.last_error())
if ok:
    info = mt5.symbol_info("XAUUSD.st")
    for attr in ("session_deals", "session_buy_orders", "session_sell_orders", "trade_mode", "trade_tick_value", "swap_rollover3days"):
        print(attr, getattr(info, attr, "n/a"))
    for fn in [n for n in dir(mt5) if "session" in n.lower()]:
        f = getattr(mt5, fn)
        if callable(f):
            try:
                print(fn, "->", f("XAUUSD.st", 0, 0) if "trade" in fn or "quote" in fn or "deal" in fn else "?")
            except Exception as e:
                print(fn, "ERR", e)
    mt5.shutdown()
