import json, collections, datetime
p = r"C:\Users\Dehkade Computer\Documents\deepseek-harness\default-workspace\work\goldbot\var\xauusd_st_m15_120d.jsonl"
# tape lines are ticks; reconstruct bar times is heavy. Use tick hours only? Instead sample tick timestamps.
hours = collections.defaultdict(collections.Counter)
seen = set()
n = 0
for line in open(p, encoding="utf-8"):
    line = line.strip()
    if not line: continue
    d = json.loads(line)
    ts = d.get("ts")
    if ts is None: continue
    n += 1
    if n % 10 != 1: continue   # one tick per bar in the harvester
    dt = datetime.datetime(2026,1,1,tzinfo=datetime.timezone.utc) + datetime.timedelta(seconds=float(ts)) if ts > 1e9 else None
    if dt is None: continue
    server = dt + datetime.timedelta(hours=2)
    hours[server.weekday()][server.hour] += 1
names = ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"]
for wd in range(7):
    if not hours[wd]: 
        print(names[wd], "-- no bars")
        continue
    hs = sorted(hours[wd])
    print(names[wd], "hours:", hs[0], "..", hs[-1], "| counts sample:", {h: hours[wd][h] for h in hs[:3]}, "...", {h: hours[wd][h] for h in hs[-2:]})
print("total lines", n)
